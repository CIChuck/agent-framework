from pathlib import Path
import json,hashlib,gzip,subprocess
root=Path.cwd();pkt=root/'docs/planning/active/friday-telemetry-rewire';archive=root/'docs/archive/completed/2026/friday-telemetry-rewire-telem-02';tmp=Path('/private/tmp/telem-02');sha=lambda b:hashlib.sha256(b).hexdigest()
assert not archive.exists(),'Preserve existing acceptance';archive.mkdir(parents=True)
e=json.loads((pkt/'validation/VAL-007/evidence.json').read_text());assert e['outcome']=='VERIFIED' and not e['findings'];manifest=pkt/'authority-manifest-TELEM-02.yaml';controls=json.loads(manifest.read_text());assert sha(manifest.read_bytes())==e['authority_manifest_sha256'];assert all(sha((root/a['path']).read_bytes())==a['sha256'] for a in controls['authority'])
paths=['validation/VAL-007/report.md','validation/VAL-007/reviewer-report.md.gz','validation/VAL-007/evidence.json','validation/VAL-007/artifact-manifest.json','execution/TELEM-02-final/report.md','execution/TELEM-02-final/builder-report.md.gz','execution/TELEM-02-final/artifact-manifest.json','authority-manifest-TELEM-02.yaml']
record=dict(work_unit='TELEM-02',directive='CD-002 including approved A02',status='accepted',accepted_by='Chuck Russell',accepted_date='2026-10-06',timezone='America/New_York',recorded_at_utc='2026-10-07T03:05:22Z',explicit_response='accepted',decision_context='Response to TELEM-02 independently VERIFIED final report and explicit next gate of maintainer acceptance',product_candidate=e['candidate'],evidence_closeout_commit='10857936715f82049490e2f0e52671df3075e680',aggregate_base=e['aggregate_base'],verdict='VERIFIED',authority=controls['authority'],frozen_evidence=[dict(path=str((pkt/p).relative_to(root)),sha256=sha((pkt/p).read_bytes())) for p in paths],original_reviewer_report_sha256=sha(gzip.decompress((pkt/'validation/VAL-007/reviewer-report.md.gz').read_bytes())),lint_disposition=dict(id='WVR-004',status='expired after TELEM-02 acceptance',raw_exit=1,findings=327,historical_coverage='Valid for accepted TELEM-02 candidate; no continuation to TELEM-03',scope_sha256=sha((pkt/'validation/WVR-004-telem02-lint-scope.json').read_bytes())),initiative_work_state='started',delivery_state='local',next_gate='prepare TELEM-03 safe LLM metrics and role-service injection directive',later_implementation_authority='requires its own approved construction directive')
(archive/'acceptance-evidence.json').write_text(json.dumps(record,indent=2)+'\n')
(archive/'README.md').write_text('''# TELEM-02 accepted: owned OTel adapter and factory lifecycle

Status: accepted work unit. Initiative: friday-telemetry-rewire.
Accepted by: repository maintainer Chuck Russell.
Accepted at: 2026-10-06, America/New_York.
Acceptance evidence: explicit conversation response **"accepted"**, following
TELEM-02 independent VERIFIED and the stated acceptance gate.

The accepted product is `45f3114173a7e9ada128c7950fe1f7e63cb2ff28`, under CD-002
and approved A02. Evidence-only closeout is `10857936715f82049490e2f0e52671df3075e680`.
Independent VAL-007 reviews the full unit and complete aggregate from
`2155a0fc51f5b20dea4e35c6cfc70f1d52002735`, with no numbered findings.

- [Independent VERIFIED report](../../../../planning/active/friday-telemetry-rewire/validation/VAL-007/report.md).
- [Independent evidence](../../../../planning/active/friday-telemetry-rewire/validation/VAL-007/evidence.json).
- [Builder evidence](../../../../planning/active/friday-telemetry-rewire/execution/TELEM-02-final/report.md).
- [Exact acceptance and evidence hashes](acceptance-evidence.json).
- [Continuing initiative](../../../../planning/active/friday-telemetry-rewire/README.md).

Accepted behavior includes provider-neutral programmatic disabled/debug/OTel
construction, provider-owned SDK context/parent/event semantics, bounded scalar
validation, owned processor/exporter lifecycle and fixed native retry disablement.
Caller-owned Chat injection remains unchanged. Actual SDK/protobuf/console,
concurrency/privacy/cleanup and both exact synthetic loopback collector tests passed.
Root2,891, Chat+Telemetry828 and owning-tree2,873 tests passed, with only unchanged
optional/live skips. Changed-file lint and typing passed. Root Ruff remained raw
exit1 with exactly327 findings under the separately approved WVR-004 disposition.

WVR-004 expires after this acceptance under its existing terms. Its exact historical
scope and reviewed authority remain immutable; it is not renewed for later units.
REM-004-HIST-01 and REM-004-GENERIC-01 remain maintainer-owned policy follow-ups.

This archive records TELEM-02 acceptance only. The continuing initiative remains
started/local for TELEM-03 through TELEM-05. Its frozen authority, reports and raw
receipts remain at their existing paths and hashes. Next is preparation of the
TELEM-03 safe LLM metrics/role-service injection construction directive; that unit's
implementation requires its own approval. Remote/TLS/vendor activation and delivery
remain separate gates. No product source, dependency, configuration, push, merge,
release or deployment change is made by this acceptance record.
''')
c=pkt/'closeout-TELEM-02.md';c.write_text('''# TELEM-02 maintainer acceptance

Status: accepted work unit, 2026-10-06, by Chuck Russell.
Explicit acceptance evidence: **"accepted"** after the independent VERIFIED report
and stated next gate of TELEM-02 acceptance.

The [archived acceptance record](../../../archive/completed/2026/friday-telemetry-rewire-telem-02/README.md)
pins product candidate45f3114, independent VAL-007, exact evidence/control hashes
and WVR-004 expiry. TELEM-02 is complete and accepted. The continuing initiative
remains started/local for TELEM-03 through TELEM-05. Next is preparation of the
TELEM-03 safe LLM metrics and role-service injection directive; implementation
requires its own approved construction directive.
''')
old='maintainer acceptance of VERIFIED TELEM-02; then TELEM-03 directive preparation';new='prepare TELEM-03 safe LLM metrics and role-service injection directive'
r=pkt/'README.md';s=r.read_text();assert s.count('next_gate: '+old)==1;s=s.replace('next_gate: '+old,'next_gate: '+new,1).replace('execution_phase: closeout','execution_phase: planning',1).replace('validation_state: verified','validation_state: not_ready',1)
s=s.replace('Current TELEM-02 result:','Accepted TELEM-02 result:',1);oldtext='''remains. TELEM-02 is ready for maintainer acceptance, which is not recorded here.
The initiative remains started for later units; delivery remains local. After
acceptance, the next planning gate is TELEM-03's safe LLM metrics and role-service
injection construction directive. Its implementation requires separate authority.''';newtext='''remains. Chuck Russell explicitly accepted TELEM-02 on2026-10-06 by responding
"accepted". The [unit closeout](closeout-TELEM-02.md) and archived acceptance record
pin that decision and exact verified evidence. WVR-004 expired after this decision;
its historical scope is preserved, with no renewal to later units.
The initiative remains started for TELEM-03 through TELEM-05; delivery remains local.
Next is TELEM-03 safe LLM metrics/role-service injection directive preparation.
Header planning/not_ready now describes that next unit, not the accepted TELEM-02
verification result. TELEM-03 implementation requires its own approved directive.''';assert oldtext in s;s=s.replace(oldtext,newtext,1);r.write_text(s)
l=pkt/'execution-log.md';l.write_text(l.read_text()+'''\n## 2026-10-06 — TELEM-02 maintainer accepted

Chuck Russell explicitly replied "accepted" to TELEM-02's independent VERIFIED
report and stated acceptance gate. Archived unit acceptance pins product45f3114,
evidence closeout1085793, VAL-007 and exact19 authority/evidence hashes. No reviewed
source, tests, dependency/configuration, controls or historical evidence changes.
WVR-004 expires after this acceptance under its existing terms;327 raw root lint
findings remain historical debt, not renewed for the next unit. Maintainer-owned
archive/registry policy follow-ups remain open.

TELEM-02 is complete and accepted; TELEM-01 acceptance is unchanged. The continuing
initiative stays started/local for TELEM-03 through TELEM-05. execution_phase:
planning; validation_state: not_ready for the next unit. Next: prepare the TELEM-03
safe LLM metrics/role-service injection directive. That source implementation
requires its own approved directive; no delivery or external activation is inferred.
''')
refs='  - docs/archive/completed/2026/friday-telemetry-rewire-telem-02/README.md\n  - docs/archive/completed/2026/friday-telemetry-rewire-telem-02/acceptance-evidence.json\n'
event='''- task: friday-telemetry-rewire
  at: '2026-10-06'
  actor: Chuck Russell
  actor_role: maintainer
  action: accepted TELEM-02
  note: Explicit accepted response after VAL-007 VERIFIED at45f3114. WVR-004 expired under existing terms; historical authority unchanged. Initiative stays started/local for TELEM-03–05; next gate is TELEM-03 directive preparation, with separate implementation approval.
  evidence: docs/archive/completed/2026/friday-telemetry-rewire-telem-02/README.md
'''
def board(s):
 assert s.count('  next_gate: '+old)==1;s=s.replace('  next_gate: '+old,'  next_gate: '+new,1);start=s.index('- id: friday-telemetry-rewire\n');stop=s.index('\nevents:',start);part=s[start:stop];assert part.count('  approved_by:')==1;part=part.replace('  approved_by:',refs+'  approved_by:',1);return s[:start]+part+s[stop:]+event
for path,name in [('docs/planning/board.yaml','board.index'),('docs/planning/README.md','dashboard.index')]:
 clean=subprocess.check_output(['git','show','HEAD:'+path]).decode();work=(root/path).read_text()
 if path.endswith('.yaml'):clean=board(clean);work=board(work)
 else:
  assert clean.count(old)==1 and work.count(old)==1;clean=clean.replace(old,new,1);work=work.replace(old,new,1)
 (tmp/name).write_text(clean);(root/path).write_text(work)
selected=[str(p.relative_to(root)) for p in [r,l,c,archive]];(tmp/'acceptance-paths.json').write_text(json.dumps(selected));print('Acceptance recorded; original19controls/evidence immutable; no product change')
