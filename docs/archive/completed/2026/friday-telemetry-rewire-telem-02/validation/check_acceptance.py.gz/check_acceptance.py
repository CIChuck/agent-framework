from pathlib import Path
import importlib.util,json,shutil,hashlib,subprocess
spec=importlib.util.spec_from_file_location('acceptance_runner','/private/tmp/telem-02/builder-execution/runner.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner);out=Path('/private/tmp/telem-02/acceptance-validation');out.mkdir(exist_ok=True);runner.OUT=out;runner.helper.OUT=out
revision=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();snapshot=runner.prepare('metadata-check',revision);pkt='docs/planning/active/friday-telemetry-rewire';archive='docs/archive/completed/2026/friday-telemetry-rewire-telem-02';overlay={}
files=[('docs/planning/board.yaml','/private/tmp/telem-02/board.index'),('docs/planning/README.md','/private/tmp/telem-02/dashboard.index')]+[(pkt+'/'+x,pkt+'/'+x) for x in ['README.md','execution-log.md','closeout-TELEM-02.md']]+[(archive+'/'+x,archive+'/'+x) for x in ['README.md','acceptance-evidence.json']]
for path,source in files:
 b=Path(source).read_bytes();target=snapshot/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);overlay[path]=hashlib.sha256(b).hexdigest()
p=out/'metadata-check-snapshot.json';r=json.loads(p.read_text());r['acceptance_metadata_overlay']=overlay;r['tracked_hashes'].update(overlay);p.write_text(json.dumps(r,indent=2)+'\n')
for label,args in [('acceptance-board',['python','scripts/friday-dev-board.py','validate']),('acceptance-show',['python','scripts/friday-dev-board.py','show','friday-telemetry-rewire']),('acceptance-render',['python','scripts/friday-dev-board.py','render']),('acceptance-docs',['python','scripts/check-documentation-lifecycle.py'])]:
 assert runner.run('metadata-check',label,args)==0,label
assert (snapshot/'docs/planning/README.md').read_bytes()==Path('/private/tmp/telem-02/dashboard.index').read_bytes(),'Dashboard rendering mismatch'
print('Acceptance board, dashboard render and documentation checks passed; no product tests rerun')
