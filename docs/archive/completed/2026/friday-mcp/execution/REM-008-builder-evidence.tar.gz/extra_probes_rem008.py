import asyncio,importlib.util,sys,json,pathlib,dataclasses
spec=importlib.util.spec_from_file_location('val014public','/private/tmp/rem008-work/public_probes_rem008.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
async def budget():
 rt,m,store,emb=p.setup('exact-budget');calls=await p.persist_mcp_interaction(rt.memory,rt.transcript,rt.config.tools.mcp_provider.config.ingestion,p.turn());row=(await m.get_all())[0];cost=p.estimated_snippet_tokens(row['text']);full=await rt.memory.retrieve('fact',token_limit=cost);small=await rt.memory.retrieve('fact',token_limit=cost-1);p.check(row['text'] in full,'intact snapshot at exact estimate');p.check(not any('MCP snapshot' in s for s in small),'omit intact at cost minus one');return {'complete_cost':cost,'at_cost':full,'below_cost':small}
async def crash():
 rt,m,store,emb=p.setup('crash-pending');call=p.call();prepared=await rt.memory.prepare_mcp_memory(call,'never-appended',rt.config.tools.mcp_provider.config.ingestion);reloaded=p.CollectionManager(p.Embeddings(),path=str(p.OUT/'crash-pending'/'vectors'));p.check((await reloaded.get_mcp_snapshot(prepared.snapshot.record_id)).state=='pending','durable pending after restart');p.check(not (await reloaded.query('fact'))['short_term'],'crash pending excludes recall');p.check(not await reloaded.promote_memory(prepared.snapshot.record_id),'restart promotion guard');return {'pending_id':prepared.snapshot.record_id}
async def later_failure():
 rt,m,store,emb=p.setup('later-call-failure');orig=m.stage_mcp_snapshot;count=0
 async def stage(s,text):
  nonlocal count
  count+=1
  if count==2:raise RuntimeError(p.RAW)
  return await orig(s,text)
 m.stage_mcp_snapshot=stage;calls=await p.persist_mcp_interaction(rt.memory,rt.transcript,rt.config.tools.mcp_provider.config.ingestion,p.turn(calls=(p.call('first'),p.call('second'))));entry=await store.get_entry('entry');p.check(calls[0].mcp_provenance.memory_ingested,'first durable committed');p.check(not calls[1].mcp_provenance.memory_ingested,'second write failed truthful skip');p.check(await m.short_term.count()==1,'one snapshot');p.check(entry.tool_results[1].mcp_provenance==calls[1].mcp_provenance,'partial paired facts');return {'writes':count,'stored':1}
async def new_allowlist():
 rt,m,store,emb=p.setup('policy-future-only');calls=await p.persist_mcp_interaction(rt.memory,rt.transcript,rt.config.tools.mcp_provider.config.ingestion,p.turn());policy=p.MCPIngestionPolicy(long_term_memory_enabled=True,opted_in_servers=('other',));new=await rt.memory.prepare_mcp_memory(p.call('new'),'new-entry',policy);p.check(new.snapshot is None,'future denied');p.check(any('revocation=not_implemented' in s for s in await rt.memory.retrieve('fact',token_limit=9999)),'prior snapshot honest no revocation');return {'new_decision':new.decision}
async def main():
 for name,fn in [('exact-budget',budget),('crash-pending-reload',crash),('partial-multicall',later_failure),('changed-policy-future-only',new_allowlist)]:await p.run(name,fn)
 print('SUMMARY',len(p.rows),'probes',p.assertions,'assertions',sum(r['status']=='FAIL' for r in p.rows),'failures')
asyncio.run(main())
