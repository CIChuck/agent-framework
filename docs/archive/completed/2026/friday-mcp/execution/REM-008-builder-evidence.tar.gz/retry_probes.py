import asyncio
import importlib.util
import json
import pathlib
import sys

spec = importlib.util.spec_from_file_location('rem008public', '/private/tmp/rem008-work/public_probes_rem008.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)

async def retry_case(mode):
    rt, manager, store, embeds = p.setup('retry-' + mode)
    turn = p.turn('owned-entry')
    policy = rt.config.tools.mcp_provider.config.ingestion
    append = store.append_entry
    read = store.get_entry
    record = rt.transcript.record_mcp_interaction
    publish = rt.memory.publish_mcp_memory
    appended = False
    if mode == 'false-append':
        async def fail_append(entry): return False
        store.append_entry = fail_append
    elif mode == 'ambiguous':
        async def ambiguous(value):
            await record(value)
            raise RuntimeError('RAW_RETRY_EXCEPTION')
        rt.transcript.record_mcp_interaction = ambiguous
    elif mode == 'readback':
        async def append_then_fail(entry):
            nonlocal appended
            result = await append(entry)
            appended = True
            return result
        async def failed_read(entry_id):
            if appended: raise RuntimeError('RAW_RETRY_EXCEPTION')
            return await read(entry_id)
        store.append_entry = append_then_fail
        store.get_entry = failed_read
    elif mode == 'publish':
        async def false_publish(snapshot): return False
        rt.memory.publish_mcp_memory = false_publish
    elif mode == 'cancel':
        async def cancelled(value):
            await record(value)
            raise asyncio.CancelledError()
        rt.transcript.record_mcp_interaction = cancelled
    first_error = None
    try:
        await p.persist_mcp_interaction(rt.memory, rt.transcript, policy, turn)
    except asyncio.CancelledError:
        first_error = 'CancelledError'
    except Exception as exc:
        first_error = type(exc).__name__ + ': ' + str(exc)
        p.check('RAW_RETRY_EXCEPTION' not in first_error, 'safe fixed diagnostic')
    rows = await manager.get_all()
    p.check(len(rows) == 1, 'one owned record before retry')
    owned = rows[0]['id']
    writes = embeds.writes
    store.append_entry = append
    store.get_entry = read
    rt.transcript.record_mcp_interaction = record
    rt.memory.publish_mcp_memory = publish
    repeated = await p.persist_mcp_interaction(rt.memory, rt.transcript, policy, turn)
    p.check(repeated[0].mcp_provenance.memory_correlation_id == owned, 'stable owned id')
    p.check(embeds.writes == writes == 1, 'no retry embedding')
    p.check(await manager.short_term.count() == 1, 'one semantic record')
    p.check(await store.count_entries('retry-' + mode) == 1, 'one immutable entry')
    p.check((await manager.get_mcp_snapshot(owned)).state == 'committed', 'published after receipt')
    return {'mode': mode, 'first_error': first_error, 'owned_id': owned, 'embeddings': embeds.writes}

async def conflict_and_concurrency():
    rt, manager, store, embeds = p.setup('retry-conflict')
    turn = p.turn('owned-entry')
    policy = rt.config.tools.mcp_provider.config.ingestion
    calls = await asyncio.gather(*(
        p.persist_mcp_interaction(rt.memory, rt.transcript, policy, turn)
        for _ in range(2)
    ))
    p.check(calls[0] == calls[1], 'matching concurrent returns')
    original = (await store.get_entry('owned-entry')).model_dump()
    try:
        await p.persist_mcp_interaction(rt.memory, rt.transcript, policy,
                                        p.turn('owned-entry', calls=(p.call(text='changed'),)))
    except RuntimeError as exc:
        p.check('changed' not in str(exc), 'safe conflict diagnostic')
    else:
        raise AssertionError('conflicting payload accepted')
    changed_policy = p.MCPIngestionPolicy.model_validate({**policy.model_dump(), 'max_ingested_bytes': 32768})
    try:
        await p.persist_mcp_interaction(rt.memory, rt.transcript, changed_policy, turn)
    except RuntimeError:
        pass
    else:
        raise AssertionError('conflicting policy accepted')
    p.check((await store.get_entry('owned-entry')).model_dump() == original, 'immutable receipt')
    p.check(await manager.short_term.count() == 1 and embeds.writes == 1, 'no duplicate data')
    return {'matching_concurrent': True, 'conflicts_rejected': 2, 'embeddings': embeds.writes}

async def main():
    cases = []
    for mode in ('false-append', 'ambiguous', 'readback', 'publish', 'cancel'):
        cases.append(await retry_case(mode))
    cases.append(await conflict_and_concurrency())
    result = {'cases': cases, 'assertions': p.assertions, 'all_passed': True}
    (p.OUT / 'retry-probes.json').write_text(json.dumps(result, indent=2) + '\n')
    print('RETRY_PROBES', json.dumps(result))

asyncio.run(main())
