import datetime,json,os,pathlib,subprocess
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/REM-007-20260928')
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();(OUT/'source-test-candidate.txt').write_text(candidate+'\n')
commands=[c.replace('f24ed20f82eac0cbce17e4b86615497cc9993921',candidate) for c in json.loads((OUT/'required-original.json').read_text())]
commands.append('git diff --check 446e3a6f4e445a456dcbe6ef25058e60af54fe53..'+candidate)
(OUT/'required-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
extras={'PYTEST_ADDOPTS':'-p no:cacheprovider','MYPY_CACHE_DIR':str(OUT/'runtime/mypy-cache'),'RUFF_CACHE_DIR':str(OUT/'runtime/ruff-cache'),'TMPDIR':str(OUT/'runtime/tmp')}
env=os.environ.copy();env.update(extras)
for name in list(env):
 if any(x in name.upper() for x in ['API_KEY','ACCESS_TOKEN','SECRET','AUTHORIZATION']):env.pop(name)
for number,command in enumerate(commands,1):
 record={'number':number,'command':command,'cwd':str(ROOT),'extra_environment':extras,'candidate':candidate,'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (OUT/f'logs/required-{number:02}.log').open('wb') as log:r=subprocess.run(command,shell=True,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit=r.returncode,end=datetime.datetime.now(datetime.timezone.utc).isoformat());(OUT/f'logs/required-{number:02}.json').write_text(json.dumps(record,indent=2)+'\n');print(number,r.returncode,(OUT/f'logs/required-{number:02}.log').read_text(errors='replace')[-500:],flush=True)
