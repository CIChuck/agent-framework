import hashlib,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/REM-007-20260928');ARCHIVE=ROOT/'docs/planning/active/friday-mcp/execution/REM-006-evidence.tar.gz'
archive_digest=hashlib.sha256(ARCHIVE.read_bytes()).hexdigest();assert archive_digest=='13a70178162b27c49e404481fa7e97a35a7b6c6fea271e7b83f7a0b3a7e52ae9'
members=['baseline-chat.log','baseline-chat.json','baseline-integration.log','baseline-integration.json','baseline-mypy.log','baseline-mypy.json','baseline-catalog-recheck.log','baseline-catalog-recheck.json','baseline-imports.log','baseline-imports.json','package-commands.json','wheel-metadata.json','package-imports-fallback.log','package-imports-fallback.json','isolated-declared-dependencies.json']
proofs={}
with tarfile.open(ARCHIVE) as tar:
 for name in members:
  data=tar.extractfile(name).read();target=OUT/'reused'/name;target.parent.mkdir(exist_ok=True);target.write_bytes(data);proofs[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'fresh_execution':False}
unchanged={}
for p in ['packages/friday-chat/tests_chat/test_reorganization_terminal.py','packages/friday-chat/tests_chat/test_llm_adapter_migration.py','tests/integration/test_development_board.py','tests/integration/test_documentation_lifecycle.py']:
 blobs=[subprocess.check_output(['git','show',rev+':'+p],cwd=ROOT) for rev in ['a609f948fe2d869ac29d0cce29d22d9334cd7d08','HEAD']];unchanged[p]=blobs[0]==blobs[1];assert unchanged[p]
package_changes=subprocess.check_output(['git','diff','--name-only','f24ed20f82eac0cbce17e4b86615497cc9993921..HEAD','--','packages/friday-transcript','packages/friday-core','packages/friday-telemetry','uv.lock'],cwd=ROOT,text=True);assert not package_changes
report=subprocess.check_output(['git','show','f24ed20f82eac0cbce17e4b86615497cc9993921:docs/planning/active/friday-mcp/execution/REM-006-implementation-report.md'],cwd=ROOT)
(OUT/'historical-report-prefix.md').write_bytes(report)
(OUT/'reused-evidence.json').write_text(json.dumps({'source_archive':str(ARCHIVE),'source_archive_sha256':archive_digest,'members':proofs,'unchanged_failing_test_sources':unchanged,'Transcript_Core_Telemetry_lock_unchanged_since_reviewed_candidate':True,'rationale':'The guard fix changes only Chat loop classification. Original-base failure sources and all built Transcript/Core/Telemetry dependency/import bytes remain identical; REM-007 explicitly permits labelled unchanged evidence reuse. No reused result is described as a fresh REM-007 execution.','historical_report_sha256':hashlib.sha256(report).hexdigest()},indent=2)+'\n')
print('Historical package/baseline members copied byte-exact; unchanged-source proofs passed.')
