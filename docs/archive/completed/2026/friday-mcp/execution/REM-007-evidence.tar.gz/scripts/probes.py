import datetime,json,os,pathlib,subprocess
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/REM-007-20260928')
extras={'LITELLM_LOCAL_MODEL_COST_MAP':'true','UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_NO_SYNC':'true','UV_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(OUT/'runtime/tmp')};env=os.environ.copy();env.update(extras)
commands=[('native-controls-fixed',['uv','run','python',str(OUT/'scripts/native_controls.py'),'fixed']),('public-main',['uv','run','pytest',str(OUT/'scripts/test_independent.py'),'-q','--tb=short','-p','no:cacheprovider','--basetemp',str(OUT/'runtime/public-main')]),('public-supplement',['uv','run','pytest',str(OUT/'scripts/test_supplement.py'),'-q','--tb=short','-p','no:cacheprovider','--basetemp',str(OUT/'runtime/public-supplement')])]
records=[]
for name,argv in commands:
 record={'argv':argv,'cwd':str(ROOT),'environment':extras,'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (OUT/f'logs/{name}.log').open('wb') as log:r=subprocess.run(argv,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit=r.returncode,end=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record);(OUT/f'logs/{name}.json').write_text(json.dumps(record,indent=2)+'\n');print(name,r.returncode,(OUT/f'logs/{name}.log').read_text(errors='replace')[-500:],flush=True)
(OUT/'probe-command-records.json').write_text(json.dumps(records,indent=2)+'\n')
