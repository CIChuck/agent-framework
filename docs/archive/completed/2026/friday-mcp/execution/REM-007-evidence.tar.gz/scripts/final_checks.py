import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess

ROOT = pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT = pathlib.Path('/private/tmp/REM-007-20260928')
SOURCE = 'e425d6765a2689256d0e48ec8305a4ad183e4945'
DISPATCH = '5ff0831a9d9ef57b1630ef0f6330d5b60bf2d6d5'
REPORT = 'docs/planning/active/friday-mcp/execution/REM-006-implementation-report.md'
freeze = json.loads((OUT / 'start-manifest.json').read_text())
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
(OUT / 'full-candidate.txt').write_text(candidate + '\n')
commands = json.loads((OUT / 'required-commands.json').read_text())
selected = [(n, commands[n - 1].replace(SOURCE, candidate)) for n in (12, 13, 14, 15, 16, 17, 18, 19)]
selected.append(('preservation', 'python3 ' + str(OUT / 'scripts/preservation.py')))
extras = {'PYTEST_ADDOPTS': '-p no:cacheprovider', 'MYPY_CACHE_DIR': str(OUT / 'runtime/mypy-cache'), 'RUFF_CACHE_DIR': str(OUT / 'runtime/ruff-cache'), 'TMPDIR': str(OUT / 'runtime/tmp')}
env = os.environ.copy()
env.update(extras)
for name in list(env):
    if any(x in name.upper() for x in ['API_KEY', 'ACCESS_TOKEN', 'SECRET', 'AUTHORIZATION']):
        env.pop(name)
records = []
for number, command in selected:
    record = {'number': number, 'command': command, 'cwd': str(ROOT), 'extra_environment': extras, 'candidate': candidate, 'start': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (OUT / f'logs/final-{number}.log').open('wb') as log:
        result = subprocess.run(command, shell=True, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    record.update(exit=result.returncode, end=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (OUT / f'logs/final-{number}.json').write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    assert result.returncode == 0, record
(OUT / 'final-command-records.json').write_text(json.dumps(records, indent=2) + '\n')
shutil.copyfile('/private/tmp/rem007-preservation.json', OUT / 'closeout-preservation.json')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

approved = sorted(freeze['allowed'])
changed = git('diff', '--name-only', DISPATCH + '..' + candidate).decode().splitlines()
assert changed == approved, (changed, approved)
manifest = {'dispatch_base': DISPATCH, 'followup_base': freeze['followup_base_commit'], 'full_candidate': candidate, 'source_test_candidate': SOURCE, 'changed_paths': changed}
(OUT / 'followup-implementation-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for label, base in [('followup', freeze['followup_base_commit']), ('original-remediation', freeze['original_remediation_base']), ('aggregate', freeze['original_aggregate_base'])]:
    (OUT / (label + '.diff')).write_bytes(git('diff', base + '..' + candidate))
    (OUT / (label + '.name-status.txt')).write_bytes(git('diff', '--name-status', base + '..' + candidate))
for name in approved:
    data = git('show', candidate + ':' + name)
    assert data == (ROOT / name).read_bytes()
    target = OUT / 'candidate-sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    if name.endswith('.py'):
        target.with_suffix('.numbered.txt').write_text(''.join(f'{n:5}: {line}\n' for n, line in enumerate(data.decode().splitlines(), 1)))
report = (ROOT / REPORT).read_bytes()
old = (OUT / 'historical-report-prefix.md').read_bytes()
assert report.startswith(old) and report.endswith(b'\n') and not report.endswith(b'\n\n')
(OUT / 'REM-006-implementation-report.md').write_bytes(report)
inputs = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in freeze['inputs']}
assert inputs == freeze['inputs']
old_archive = ROOT / 'docs/planning/active/friday-mcp/execution/REM-006-evidence.tar.gz'
assert hashlib.sha256(old_archive.read_bytes()).hexdigest() == '13a70178162b27c49e404481fa7e97a35a7b6c6fea271e7b83f7a0b3a7e52ae9'
proof = {'full_candidate': candidate, 'exact_three_allowed_paths': changed == approved, 'source_test_candidate_unchanged': git('diff', SOURCE + '..' + candidate, '--', 'packages', 'tests', 'pyproject.toml', 'uv.lock') == b'', 'frozen_input_hashes': inputs, 'historical_report_prefix_bytes': len(old), 'historical_report_prefix_sha256': hashlib.sha256(old).hexdigest(), 'historical_prefix_byte_exact': True, 'report_eof_exactly_one_newline': True, 'original_REM006_archive_unchanged': True, 'all_final_commands_exit_zero': True}
(OUT / 'scope-and-history-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({'candidate': candidate, 'changed_paths': changed, 'final_checks': len(records), 'historical_prefix_bytes': len(old)}, indent=2))
