import gzip
import hashlib
import io
import json
import pathlib
import re
import tarfile

OUT = pathlib.Path('/private/tmp/REM-007-20260928')
ROOT = pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
ARCHIVE = 'REM-007-evidence.tar.gz'
candidate = (OUT / 'full-candidate.txt').read_text().strip()
source = (OUT / 'source-test-candidate.txt').read_text().strip()
freeze = json.loads((OUT / 'start-manifest.json').read_text())
excluded = {'evidence.json', 'delivery.json', 'artifact-verification.json', ARCHIVE}
root_files = [p for p in OUT.iterdir() if p.is_file() and p.name not in excluded]
files = root_files + [p for folder in ('scripts', 'logs', 'inputs', 'candidate-sources', 'reused') for p in (OUT / folder).rglob('*') if p.is_file()]
assert all(not p.is_symlink() for p in files)
contents = {p.relative_to(OUT).as_posix(): p.read_bytes() for p in sorted(files)}
assert all(not name.endswith(('.db', '.sqlite', '.sqlite3', '-wal', '-shm', '.pyc')) for name in contents)

def digest(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

report = contents['REM-006-implementation-report.md']
prefix = contents['historical-report-prefix.md']
assert report.startswith(prefix) and hashlib.sha256(prefix).hexdigest() == '99d856c508203693782386109fd8841b20a0cfaa266197299fa5a476dd3e6950'
references = sorted(set(re.findall(r'REM-007-evidence\.tar\.gz#([^`\s)]+)', report.decode())))
missing = [ref for ref in references if ref not in contents and not (ref.endswith('/') and any(n.startswith(ref) for n in contents))]
assert not missing, missing
required_logs = [f'logs/required-{n:02}.{ext}' for n in range(1, 20) for ext in ('json', 'log')]
assert all(name in contents for name in required_logs)
manifest = {'full_candidate': candidate, 'source_test_candidate': source, 'followup_base': freeze['followup_base_commit'], 'original_remediation_base': freeze['original_remediation_base'], 'original_aggregate_base': freeze['original_aggregate_base'], 'member_count_including_manifest': len(contents) + 1, 'members': {name: digest(data) for name, data in sorted(contents.items())}, 'manifest_self_hash': 'Excluded to avoid recursive hashing; delivery.json pins evidence.json.', 'followup_report_locators': references, 'numbered_required_command_log_members': required_logs, 'inherited_evidence': 'reused/ members are historical unchanged evidence, labelled fresh_execution:false in reused-evidence.json; mandatory checks and copied regression probes are new executions.'}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
(OUT / 'evidence.json').write_bytes(manifest_bytes)
contents['evidence.json'] = manifest_bytes

def archive_bytes():
    buf = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=buf, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(contents.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
    return buf.getvalue()

first = archive_bytes()
assert first == archive_bytes(), 'Non-deterministic archive'
(OUT / ARCHIVE).write_bytes(first)
with tarfile.open(OUT / ARCHIVE, 'r:gz') as tar:
    names = tar.getnames()
    assert names == sorted(contents)
    for name in names:
        data = tar.extractfile(name).read()
        assert data == contents[name]
        if name != 'evidence.json':
            assert digest(data) == manifest['members'][name]
verification = {'full_candidate': candidate, 'member_count': len(contents), 'all_member_hashes_match': True, 'manifest_exact_member_set': True, 'report_reference_count': len(references), 'all_followup_report_members_present': True, 'all_19_required_command_logs_present': True, 'runtime_databases_state_venvs_caches_excluded': True, 'historical_report_prefix_byte_exact': True, 'report_eof_exactly_one_newline': report.endswith(b'\n') and not report.endswith(b'\n\n'), 'deterministic_archive_byte_equal': True, 'errors': []}
(OUT / 'artifact-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
delivery = {'full_candidate': candidate, 'source_test_candidate': source, 'followup_base': freeze['followup_base_commit'], 'remediation_base': freeze['original_remediation_base'], 'original_aggregate_base': freeze['original_aggregate_base'], 'approved_implementation_paths': sorted(freeze['allowed']), 'artifacts': {name: digest((OUT / name).read_bytes()) for name in ('REM-006-implementation-report.md', 'evidence.json', ARCHIVE, 'artifact-verification.json')}, 'historical_REM006_archive_sha256': '13a70178162b27c49e404481fa7e97a35a7b6c6fea271e7b83f7a0b3a7e52ae9', 'independent_gate': 'Pending new fresh read-only VAL-013 delta plus complete original WS-05 aggregate; remediator regression checks are not an independent verdict or acceptance.'}
(OUT / 'delivery.json').write_text(json.dumps(delivery, indent=2) + '\n')
print(json.dumps({'delivery': delivery, 'verification': verification}, indent=2))
