import datetime,json,os,pathlib,subprocess
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/REM-006-20260928')
results=[]
for label,source in [('baseline',OUT/'baseline'),('corrected',ROOT)]:
 env=os.environ.copy();env.update({'LITELLM_LOCAL_MODEL_COST_MAP':'true','UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_NO_SYNC':'true','UV_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':os.pathsep.join(str(p) for p in sorted((source/'packages').glob('*/src')))})
 for stem in ['finding_repro','export_all_repro']:
  cmd=[str(ROOT/'.venv/bin/python'),str(OUT/(stem+'.py')),label]
  log=OUT/f'{stem}-{label}.log';start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with log.open('wb') as f:r=subprocess.run(cmd,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT)
  fact={'command':cmd,'cwd':str(source),'env':{k:env[k] for k in ['LITELLM_LOCAL_MODEL_COST_MAP','UV_CACHE_DIR','UV_NO_SYNC','UV_OFFLINE','PYTHONDONTWRITEBYTECODE','PYTHONPATH']},'start':start,'exit_code':r.returncode,'log':log.name};results.append(fact)
  print(stem,label,r.returncode,log.read_text(errors='replace')[-1400:],flush=True)
(OUT/'finding-command-records.json').write_text(json.dumps(results,indent=2)+'\n')
