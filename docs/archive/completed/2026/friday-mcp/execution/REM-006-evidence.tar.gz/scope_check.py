import hashlib,json,pathlib,subprocess
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/REM-006-20260928')
f=json.loads((OUT/'start-manifest.json').read_text());base=f['remediation_base'];aggregate=f['original_work_unit_base'];candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
allowed=set(f['allowed']);product=lambda x:x.startswith(('packages/','tests/')) or x in {'pyproject.toml','uv.lock'}
delta=git('diff','--name-only',base+'..'+candidate).decode().splitlines();full=git('diff','--name-only',aggregate+'..'+candidate).decode().splitlines()
original=set(git('diff','--name-only',aggregate+'..'+f['reviewed_candidate']).decode().splitlines())
errors=[]
if {p for p in delta if product(p)} != {p for p in allowed if product(p)}:errors.append('delta product manifest')
if {p for p in full if product(p)} != {p for p in original if product(p)}:errors.append('aggregate product manifest')
unchanged_failures={}
for p in ['packages/friday-chat/tests_chat/test_reorganization_terminal.py','packages/friday-chat/tests_chat/test_llm_adapter_migration.py','tests/integration/test_development_board.py','tests/integration/test_documentation_lifecycle.py']:
 unchanged_failures[p]=git('show',aggregate+':'+p)==git('show',candidate+':'+p)
 if not unchanged_failures[p]:errors.append(p)
for label,revision in [('delta',base),('aggregate',aggregate)]:
 (OUT/(label+'.diff')).write_bytes(git('diff','--binary',revision+'..'+candidate));(OUT/(label+'-name-status.txt')).write_bytes(git('diff','--name-status',revision+'..'+candidate))
result={'candidate':candidate,'remediation_base':base,'original_aggregate_base':aggregate,'exact_allowed_implementation':sorted(allowed),'delta_all_paths':delta,'delta_product_paths':[p for p in delta if product(p)],'aggregate_all_paths':full,'aggregate_product_paths':[p for p in full if product(p)],'unchanged_failing_sources':unchanged_failures,'dependency_metadata_lock_unchanged_vs_remediation_base':not git('diff','--name-only',base+'..'+candidate,'--','uv.lock','pyproject.toml','packages/friday-transcript/pyproject.toml'),'errors':errors}
(OUT/'scope-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['aggregate_all_paths','aggregate_product_paths']}));raise SystemExit(bool(errors))
