import asyncio,json,os,pathlib,subprocess,tarfile
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); OUT=pathlib.Path('/private/tmp/REM-006-20260928'); BASE=OUT/'baseline'
BASE.mkdir(exist_ok=True)
archive=OUT/'baseline-input.tar'
archive.write_bytes(subprocess.check_output(['git','archive','a609f948fe2d869ac29d0cce29d22d9334cd7d08'],cwd=ROOT))
with tarfile.open(archive) as tf: tf.extractall(BASE,filter='data')
env=os.environ.copy(); env.update({'LITELLM_LOCAL_MODEL_COST_MAP':'true','UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_NO_SYNC':'true','UV_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1','PYTEST_ADDOPTS':'-p no:cacheprovider','MYPY_CACHE_DIR':str(OUT/'baseline-mypy-cache'),'UV_PROJECT_ENVIRONMENT':str(ROOT/'.venv'),'PYTHONPATH':os.pathsep.join(str(p) for p in sorted((BASE/'packages').glob('*/src'))),'TMPDIR':str(OUT/'runtime-tmp')})
commands=[('imports', ['uv','run','python','-c','import friday_chat,friday_core,friday_transcript; print(friday_chat.__file__); print(friday_core.__file__); print(friday_transcript.__file__)']),('chat',['uv','run','pytest','packages/friday-chat/tests_chat','-q','--tb=short']),('integration',['uv','run','pytest','tests/integration','-q','--tb=short']),('mypy',['uv','run','mypy','packages/friday-core','packages/friday-mcp','packages/friday-chat','packages/friday-transcript','packages/friday-agent'])]
async def run(name,cmd):
 with (OUT/f'baseline-{name}.log').open('wb') as log:
  p=await asyncio.create_subprocess_exec(*cmd,cwd=BASE,env=env,stdout=log,stderr=asyncio.subprocess.STDOUT); exit_code=await p.wait()
 (OUT/f'baseline-{name}.json').write_text(json.dumps({'command':cmd,'cwd':str(BASE),'extra_env':{k:env[k] for k in ['LITELLM_LOCAL_MODEL_COST_MAP','UV_CACHE_DIR','UV_NO_SYNC','UV_OFFLINE','PYTHONDONTWRITEBYTECODE','PYTEST_ADDOPTS','MYPY_CACHE_DIR','UV_PROJECT_ENVIRONMENT','PYTHONPATH','TMPDIR']},'exit_code':exit_code},indent=2)+'\n')
 print(name,exit_code,(OUT/f'baseline-{name}.log').read_text(errors='replace')[-1400:],flush=True)
async def main():
 for command in commands:
  await run(*command)
asyncio.run(main())
