import hashlib,io,json,pathlib,re,tarfile
OUT=pathlib.Path('/private/tmp/REM-006-20260928');ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
def sha(data):return hashlib.sha256(data).hexdigest()
allowed_suffixes={'.py','.log','.json','.jsonl','.txt','.md','.diff'}
files=[p for p in OUT.iterdir() if p.is_file() and p.suffix in allowed_suffixes and p.name not in {'evidence.json','delivery.json','artifact-verification.json'}]
for folder in ['inputs','candidate-sources','wheels','catalog-bin']:
 files.extend(p for p in (OUT/folder).rglob('*') if p.is_file())
files=sorted(set(files),key=lambda p:p.relative_to(OUT).as_posix())
if any(p.suffix in {'.sqlite','.db','.sqlite3'} or p.name.endswith(('-wal','-shm')) for p in files):raise RuntimeError('Runtime database member')
manifest={p.relative_to(OUT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files}
report=OUT/'REM-006-implementation-report.md'
references=re.findall(r'REM-006-evidence\.tar\.gz#([^`\s)]+)',report.read_text())
missing=sorted(set(references)-set(manifest))
if missing:raise RuntimeError('Missing report members: '+repr(missing))
(OUT/'evidence.json').write_text(json.dumps({'full_candidate':(OUT/'full-candidate.txt').read_text().strip(),'source_test_candidate':(OUT/'product-candidate.txt').read_text().strip(),'remediation_base':'dd6a337eb2928ab4050ea70fb41dc77072210e34','original_aggregate_base':'a609f948fe2d869ac29d0cce29d22d9334cd7d08','members':manifest,'member_count':len(manifest),'report_member_references':len(references),'excluded':'Runtime DBs/temporary exports/baseline/package/venv/cache trees/unrelated artifacts; self manifest hash supplied in delivery.json'},indent=2)+'\n')
archive=OUT/'REM-006-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for p in [*files,OUT/'evidence.json']:
  b=p.read_bytes();info=tarfile.TarInfo(p.relative_to(OUT).as_posix());info.size=len(b);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;tar.addfile(info,io.BytesIO(b))
errors=[]
with tarfile.open(archive) as tar:
 members=tar.getmembers()
 if {p.name for p in members}!=set(manifest)|{'evidence.json'}:errors.append('member set')
 for p in members:
  content=tar.extractfile(p).read()
  if p.name=='evidence.json':
   if content!=(OUT/'evidence.json').read_bytes():errors.append(p.name)
  elif len(content)!=manifest[p.name]['bytes'] or sha(content)!=manifest[p.name]['sha256']:errors.append(p.name)
actual_report=(ROOT/'docs/planning/active/friday-mcp/execution/REM-006-implementation-report.md').read_bytes()
if actual_report!=report.read_bytes():errors.append('repository report copy')
(OUT/'artifact-verification.json').write_text(json.dumps({'member_count':len(members),'all_member_hashes_match':not errors,'report_reference_count':len(references),'all_report_members_present':not missing,'runtime_databases_excluded':True,'errors':errors},indent=2)+'\n')
delivery={'full_candidate':(OUT/'full-candidate.txt').read_text().strip(),'source_test_candidate':(OUT/'product-candidate.txt').read_text().strip(),'remediation_base':'dd6a337eb2928ab4050ea70fb41dc77072210e34','original_aggregate_base':'a609f948fe2d869ac29d0cce29d22d9334cd7d08','approved_implementation_paths':json.loads((OUT/'start-manifest.json').read_text())['allowed'],'artifacts':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in [report,OUT/'evidence.json',archive,OUT/'artifact-verification.json']},'independent_gate':'Pending fresh VAL-012; remediator has not verified or accepted its own candidate.'}
(OUT/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n');print(json.dumps(delivery,indent=2));print('archive verification:',errors)
if errors:raise SystemExit(1)
