import datetime,json,os,pathlib,subprocess
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/REM-006-20260928')
f=json.loads((OUT/'start-manifest.json').read_text());candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
env=os.environ.copy();env.update({'LITELLM_LOCAL_MODEL_COST_MAP':'true','UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_NO_SYNC':'true','UV_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1'})
commands=[('aggregate-whitespace',['git','diff','--check',f['original_work_unit_base']+'..'+candidate]),('delta-whitespace',['git','diff','--check',f['remediation_base']+'..'+candidate]),('candidate-source-equality',['git','diff','--exit-code',candidate,'--','packages','tests','pyproject.toml','uv.lock']),('candidate-report-equality',['git','diff','--exit-code',candidate,'--',f['allowed'][-1]]),('board-validate',['uv','run','python','scripts/friday-dev-board.py','validate']),('board-render',['uv','run','python','scripts/friday-dev-board.py','render','--check']),('docs',['uv','run','python','scripts/check-documentation-lifecycle.py']),('scope',['python3',str(OUT/'scope_check.py')]),('preservation',['python3',str(OUT/'preservation.py')])]
results=[]
for name,cmd in commands:
 record={'name':name,'command':cmd,'cwd':str(ROOT),'environment':{k:env[k] for k in ['LITELLM_LOCAL_MODEL_COST_MAP','UV_CACHE_DIR','UV_NO_SYNC','UV_OFFLINE','PYTHONDONTWRITEBYTECODE']},'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (OUT/('final-'+name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['exit_code']=r.returncode;record['end']=datetime.datetime.now(datetime.timezone.utc).isoformat();results.append(record);print(name,r.returncode,flush=True)
(OUT/'final-command-records.json').write_text(json.dumps(results,indent=2)+'\n')
(OUT/'closeout-preservation.json').write_bytes(pathlib.Path('/private/tmp/rem006-preservation.json').read_bytes())
(OUT/'full-candidate.txt').write_text(candidate+'\n')
paths=subprocess.check_output(['git','diff','--name-only','8edb522451f57ce56ec6a8396a7619fdee256ada..'+candidate],cwd=ROOT,text=True).splitlines()
if set(paths)!=set(f['allowed']):raise SystemExit('Exact remediator manifest mismatch')
(OUT/'remediator-name-status.txt').write_bytes(subprocess.check_output(['git','diff','--name-status','8edb522451f57ce56ec6a8396a7619fdee256ada..'+candidate],cwd=ROOT))
(OUT/'remediator.diff').write_bytes(subprocess.check_output(['git','diff','--binary','8edb522451f57ce56ec6a8396a7619fdee256ada..'+candidate],cwd=ROOT))
(OUT/'final-status.txt').write_bytes(subprocess.check_output(['git','status','--short'],cwd=ROOT))
for p in f['allowed']:
 destination=OUT/'candidate-sources'/p;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes((ROOT/p).read_bytes())
with (OUT/'source-numbered.txt').open('w') as output:
 for p in f['allowed']:
  output.write('\nFILE '+p+'\n')
  for i,line in enumerate((ROOT/p).read_text().splitlines(),1):output.write(f'{i:04d} {line}\n')
if any(r['exit_code'] for r in results):raise SystemExit(1)
