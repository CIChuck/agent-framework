import datetime,json,os,pathlib,subprocess
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/REM-006-20260928')
env=os.environ.copy();env.update({'PYTEST_ADDOPTS':'-p no:cacheprovider','MYPY_CACHE_DIR':str(OUT/'mypy-cache'),'TMPDIR':str(OUT/'runtime-tmp')})
commands=json.loads((OUT/'required-command-list.json').read_text())
for i,cmd in enumerate(commands,1):
 metadata={'id':i,'command':cmd,'cwd':str(ROOT),'extra_env':{k:env[k] for k in ['PYTEST_ADDOPTS','MYPY_CACHE_DIR','TMPDIR']},'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (OUT/f'command-{i:02}.log').open('wb') as log:
  proc=subprocess.run(cmd,shell=True,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT);metadata['exit_code']=proc.returncode
 metadata['end']=datetime.datetime.now(datetime.timezone.utc).isoformat();(OUT/f'command-{i:02}.json').write_text(json.dumps(metadata,indent=2)+'\n')
 print(i,metadata['exit_code'],(OUT/f'command-{i:02}.log').read_text(errors='replace')[-700:],flush=True)
