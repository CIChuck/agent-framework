from pathlib import Path
import hashlib,json,subprocess
root=Path('/Users/chuckrussell/Dev/gendev/agent-framework');s=json.loads(Path('/private/tmp/rem006-start-freeze.json').read_text());allowed=set(s['allowed']);errors=[]
for name,digest in s['inputs'].items():
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:errors.append('input:'+name)
for name,digest in s['product'].items():
 if name not in allowed and hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:errors.append('outside-scope:'+name)
actual={}
for name in s['unrelated']:
 p=root/name
 if not p.exists() and not p.is_symlink():actual[name]={'state':'absent'};continue
 paths=sorted(p.rglob('*')) if p.is_dir() else [p];d=hashlib.sha256();count=0
 for f in paths:
  if f.is_symlink():data=('symlink:'+str(f.readlink())).encode()
  elif f.is_file():data=f.read_bytes()
  else:continue
  d.update(str(f.relative_to(root)).encode()+b'\0'+data+b'\0');count+=1
 actual[name]={'files':count,'sha256':d.hexdigest(),'state':'present'}
if actual!=s['unrelated']:errors.append('unrelated fingerprints')
modified=set(subprocess.check_output(['git','diff','--name-only',s['remediation_base'],'--','packages','tests','pyproject.toml','uv.lock'],cwd=root,text=True).splitlines())
if modified-allowed:errors.append('product scope:'+str(sorted(modified-allowed)))
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','packages','tests'],cwd=root,text=True).splitlines())
expected={'packages/friday-chat/config.example.yaml.pre-typed-llm-20260828.bak','packages/friday-sandbox/docker/Dockerfile.audit'}
if untracked-allowed!=expected:errors.append('unexpected untracked product/test')
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'remediation_base':s['remediation_base'],'frozen_inputs_unchanged':len(s['inputs']),'outside_scope_product_files':len(set(s['product'])-allowed),'unrelated':actual,'changed_product_paths':sorted(modified),'errors':errors}
Path('/private/tmp/rem006-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='unrelated'}))
if errors:raise SystemExit(1)
