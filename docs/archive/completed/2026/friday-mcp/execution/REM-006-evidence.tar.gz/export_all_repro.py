import asyncio, json, os, pathlib, subprocess, sys
OUT=pathlib.Path('/private/tmp/REM-006-20260928')
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
if len(sys.argv)==1:
 for label,source in [('candidate',ROOT),('baseline',OUT/'baseline')]:
  env=os.environ.copy();env.update({'LITELLM_LOCAL_MODEL_COST_MAP':'true','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':os.pathsep.join(str(p) for p in sorted((source/'packages').glob('*/src')))})
  cmd=[str(ROOT/'.venv/bin/python'),str(OUT/'export_all_repro.py'),label]
  with (OUT/f'export-all-repro-{label}.log').open('wb') as log: result=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
  (OUT/f'export-all-repro-{label}.json').write_text(json.dumps({'command':cmd,'cwd':str(source),'extra_env':{k:env[k] for k in ['LITELLM_LOCAL_MODEL_COST_MAP','PYTHONDONTWRITEBYTECODE','PYTHONPATH']},'exit_code':result.returncode},indent=2)+'\n')
  print(label,result.returncode,(OUT/f'export-all-repro-{label}.log').read_text())
else:
 from friday_transcript import SQLiteTranscriptStore, CSVExporter
 import friday_transcript
 async def main():
  label=sys.argv[1];destination=OUT/f'export-all-{label}-tmp'
  store=SQLiteTranscriptStore(OUT/f'finding-{label}.sqlite')
  counts=await CSVExporter(store).export_all_sessions(destination)
  print(json.dumps({'label':label,'source':friday_transcript.__file__,'counts':counts,'sessions_csv_contains_configured_env_value':'VAL11_ENV_HEADER_MARK' in (destination/'sessions.csv').read_text(),'entries_csv_contains_configured_env_value':'VAL11_ENV_HEADER_MARK' in (destination/'entries.csv').read_text()},indent=2))
 asyncio.run(main())
