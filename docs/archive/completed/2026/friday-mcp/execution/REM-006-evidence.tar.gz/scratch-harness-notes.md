# Scratch harness provenance

Existing VAL-011 scripts were copied to this REM-006 scratch root. Original files were not modified. Each copied script substitutes only this root for the old scratch path. The baseline runner uses sequential commands. It extracts the approved original WS-05 base via Git archive; the package runner will use the final remediation product candidate.

The first new snapshot tests used an incorrect nested JSONL session-header expectation and omitted historical TranscriptSession.model_name. Those test setup assertions were corrected; their complete initial failing log is retained as transcript-initial.log. Source fixes were already sufficient for the copied public independent 27-test probe.

A system Python YAML parse attempt failed because PyYAML is available only in the existing workspace venv. No product/dependency edit was made. The script runner first lacked required-command-list.json; its exact traceback is retained in check-run.log. The existing uv environment was used for parsing, then all required commands ran sequentially.

Full tests continue to record independently reproduced unrelated failures, never filtered or waived by the remediator.
