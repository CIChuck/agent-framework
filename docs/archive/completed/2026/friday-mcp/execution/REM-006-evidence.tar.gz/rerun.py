import datetime,json,os,pathlib,subprocess
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/REM-006-20260928')
env=os.environ.copy();env.update({'PYTEST_ADDOPTS':'-p no:cacheprovider','MYPY_CACHE_DIR':str(OUT/'mypy-cache'),'TMPDIR':str(OUT/'runtime-tmp')})
commands=json.loads((OUT/'required-command-list.json').read_text())
selected=[('command-10-rerun',commands[9]),('command-01-rerun',commands[0]),('command-08-rerun',commands[7])]
for name,cmd in selected:
 metadata={'command':cmd,'cwd':str(ROOT),'extra_env':{k:env[k] for k in ['PYTEST_ADDOPTS','MYPY_CACHE_DIR','TMPDIR']},'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (OUT/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,shell=True,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 metadata['exit_code']=r.returncode;metadata['end']=datetime.datetime.now(datetime.timezone.utc).isoformat();(OUT/(name+'.json')).write_text(json.dumps(metadata,indent=2)+'\n');print(name,r.returncode,(OUT/(name+'.log')).read_text(errors='replace')[-900:],flush=True)
