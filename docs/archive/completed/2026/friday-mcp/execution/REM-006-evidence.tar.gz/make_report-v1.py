from pathlib import Path
import json
out=Path('/private/tmp/REM-006-20260928');root=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
product=(out/'product-candidate.txt').read_text().strip()
manifest=json.loads((out/'start-manifest.json').read_text())
intro=f'''# REM-006 implementation report

Status: Local remediation candidate prepared for fresh VAL-012; no independent verdict or acceptance.
Date: 2026-09-28 (America/New_York).
Remediator: separate authorized agent `/root/mcp_ws05_rem006`, fresh dispatch without inherited parent context; no builder/validator role and no child validator spawned.
Branch: `feature/friday-mcp-ws05-execution`.

The two High findings in the complete frozen VAL-011 report have bounded source fixes and fresh executable regression evidence. All required commands were executed. The final affected-source typing, focused tests and Ruff pass; the independently reproduced unrelated full-Chat/integration/default-typing failures remain explicit. These are remediator checks, not an independent `VERIFIED` result. REM006-AC06 remains pending the controller's new read-only VAL-012 covering the delta and complete original WS-05 aggregate.

## Authorization, revisions and exact implementation manifest

The maintainer's explicit "fix them - proceed" approved the complete eight-path REM-006 directive and separate remediator before code generation. Approval/start is `5145f0638fe644c97dc74e0dcf8f7657f8fbcd12`; controller dispatch metadata settled at `8edb522451f57ce56ec6a8396a7619fdee256ada`. AGENTS, policies, board validate/next/show, packet/build/tactical, WS-05 directive, REM-006 and complete VAL-011 were read. Board is started/granted/local on the named branch. Accepted WS-00 through WS-04 and all historical WS-05/VAL-011 inputs stay frozen.

- Remediation base: `dd6a337eb2928ab4050ea70fb41dc77072210e34`.
- Reviewed WS-05 product: `2388e747ba1bf8157881230ad36ae3ef3272b807`.
- Original aggregate base: `a609f948fe2d869ac29d0cce29d22d9334cd7d08`.
- Stable source/test candidate: `{product}`. Source/tests were committed in `6dae70c` and the scoped typing follow-up `{product}`.
- The final full candidate contains this report in its subsequent local report commit. Its full hash is pinned in `delivery.json` and the controller's VAL-012 freeze rather than recursively embedded in its own report bytes. Source/test bytes are exactly the stable product candidate above.

Exactly eight remediator implementation paths:

'''
text=intro+'\n'.join('- `'+p+'`' for p in manifest['allowed'])+'''

No other source/test/config/dependency path changed in remediation. Controller approval/dispatch records preceding the product candidate are distinct process metadata in the remediation-base delta. The remediator did not edit them, the board/dashboard, queue/log, or frozen WS-05/VAL-011 request/report/evidence. No broad staging, cleanup or delivery occurred. [Exact scope/diffs](REM-006-evidence.tar.gz#scope-audit.json), [original delta](REM-006-evidence.tar.gz#delta.diff), [complete original aggregate](REM-006-evidence.tar.gz#aggregate.diff).

## F-001: New-session MCP configuration privacy

`FrameworkTranscriptAdapter._ensure_session` at adapters.py:1313-1330 now supplies Pydantic's nested serialization exclusion for `tools.providers.mcp`. The entire MCP stanza is omitted from the new diagnostic snapshot. There are no env/header/argument copies, key summaries, hashes, connection/launch material or new configuration authority in the snapshot. All other config snapshot fields and native providers serialize as before. The original configuration is never mutated; runtime routing, command/argument/environment dispatch and exact original tool names remain intact.

`test_new_session_omits_mcp_launch_material_from_every_export` at test_mcp_execution_transcript.py:48-171 runs a real local stdio process, production TurnProcessor/SQLite, both streaming modes and normal/pending fallback completion. A wrapper audits booleans for exact environment and launch arguments; it records no sentinel values. Supported launch arguments include synthetic Authorization-header and URL credential copies plus a launch-path sentinel. The accepted strict stdio config has no HTTP headers field; tests use supported launch material and do not introduce HTTP or change config authority. The test checks original config equality, stored session/entry/context log, model continuation, returned/chunk/raw captures, JSONL with both metadata flags, Markdown default/opt-in, per-session CSV and public CSV export_all_sessions sessions.csv plus entries.csv. All sentinel absence checks pass; peer name/result semantics remain exact. Other native-provider snapshot shape is preserved.

`test_native_session_snapshot_shape_and_historical_snapshot_are_preserved` at test_mcp_execution_transcript.py:174-203 checks byte-compatible native config shape and confirms an existing stored snapshot is left untouched. This is prevention for newly captured sessions only. Historical databases may still contain previously recorded MCP snapshots and can export them; no migration, rewrite or cleanup is authorized here. Any historical cleanup needs separate authority.

Fresh diagnostic reproduction on the original approved base shows MCP env retained in the session, JSONL with metadata true and false, and all-session sessions.csv. Per-session entry CSV and Markdown do not contain it. The corrected public reproduction reports no env capture/export. [Baseline facts](REM-006-evidence.tar.gz#finding-results-baseline.json), [corrected facts](REM-006-evidence.tar.gz#finding-results-corrected.json), [baseline all-session CSV](REM-006-evidence.tar.gz#export_all_repro-baseline.log), [corrected all-session CSV](REM-006-evidence.tar.gz#export_all_repro-corrected.log).

## F-002: Coherent cross-iteration IDs and paired persistence

`tools/output.py:37-105` preserves valid unique MCP IDs and retries opaque UUID allocation if an ID is already reserved. `reconcile_mcp_call_ids` reserves each newly observed native ID, then changes only conflicting completed MCP records. It validates a fresh typed MCPToolCallProvenance with the replacement call ID, preserving every other accepted fact. Retained assistant request IDs and corresponding tool-result IDs move with the atomic record, matched by both canonical tool name and previous unique call ID. Repeated tool names therefore remain distinct. Explicit string guards narrow dynamic message values without casts or suppressions. Native records/IDs/execution are unchanged, completed tools are never rerun, and no execution/result/provenance fact is fabricated.

`tools/loop.py:94-110` reserves native IDs across every already supplied message before MCP allocation. `turns/processor.py:451-502` reconciles history/records immediately after every new model response, including the last pending fallback response, before another model invocation or turn persistence. Repeated later native claims can reassign the same earlier MCP record again. `processor.py:397-403,508-534` also reserves completed record IDs while sanitizing final pending MCP requests, so missing/invalid/duplicate pending IDs or reuse of an earlier executed ID receive distinct safe capture IDs. Pending calls do not become completed records.

Only turn-owned retained history changes. A previously submitted model wire request was internally paired when submitted and cannot be retroactively rewritten; the next invocation and retained diagnostic/history copies carry the coherent revised pair. Caller-owned ToolLoop input messages remain unchanged. Fake transcript adapters receive the same coherent final safe records; production adapters keep the existing strict call/result DTO guard and bind correlations to the actual entry ID. Shared DTOs/storage/schema/export code are unchanged.

Regressions:

- Security tests reserve native IDs in later supplied ToolLoop messages and reconcile concurrent repeated-name atomic records while preserving all non-ID provenance facts.
- `test_later_native_claims_rebind_complete_mcp_pairs_across_iterations` (transcript.py:206-332) crosses streaming/nonstreaming, fake/production and normal/fallback. Three executed iterations include native shared reuse, a later native claim of the opaque replacement itself, repeated/missing/invalid MCP IDs, an unexecuted native pending claim, and repeated canonical names. It asserts exact native IDs/results, complete retained request/result/record association, successful SQLite and actual entry correlations.
- `test_pending_mcp_reuse_gets_distinct_capture_id_without_execution` (transcript.py:335-401) covers final pending MCP reuse of an earlier MCP ID in both modes/adapters, unique coherent raw/capture IDs, preserved valid unique pending ID, and exactly one completed/persisted execution.
- `test_two_peers_later_native_reuse_persists_exact_execution_pairs` (integration.py:29-203) uses two actual peers, exact canonical/original routes and argument counters, repeated names, later native reuse, missing/invalid IDs, streaming/fallback, production SQLite and JSONL model round-trip. Four MCP executions occur exactly once; no completed call is rerun.

The original approved-base diagnostic reports duplicate continuation IDs but no exception and one stored entry. The pre-fix reviewed product public probe reproduces TurnPersistenceError. The corrected diagnostic has distinct opaque MCP/native IDs, native ID unchanged, no exception, one new entry and five true public cleanup booleans. This distinguishes the inherited ambiguous continuation from the WS-05-added persistence regression. [Diagnostic commands](REM-006-evidence.tar.gz#finding-command-records.json), [baseline facts](REM-006-evidence.tar.gz#finding-results-baseline.json), [corrected facts](REM-006-evidence.tar.gz#finding-results-corrected.json).

## Criteria and preserved WS-05 contracts

| Criterion | Remediator evidence / remaining gate |
| --- | --- |
| REM006-AC01 | Safe whole-stanza omission; four production streaming/fallback snapshot/export cases; exact config/env/launch audit, native shape and historical-preservation tests; corrected public reproduction. |
| REM006-AC02 | Multi-iteration and successive-native-claim matrix, concurrent atomic records, two peers/execution counters, fake and production paired records, actual entry correlations, JSONL round-trip; strict shared guard unchanged. |
| REM006-AC03 | Required focused 224 tests, full suites and 27 copied public probes cover existing caps, security, failures, cancellation, old/native serialization, fallback, accepted lifecycle/registry and WS-04 budget/selection. Reproduced unrelated broad failures remain explicit. |
| REM006-AC04 | Exact eight-path implementation scope; 41 frozen inputs, 971 outside-scope product files and all five dirty fingerprints preserved; no config/lock/shared DTO/storage changes, suppressions, historical rewrite, hashes or real credential material. |
| REM006-AC05 | Every required command/exits/full logs, fresh pre/post and approved-base findings/baselines, offline built imports, public process/task cleanup and lossless member hashes provided. |
| REM006-AC06 | Pending. Controller must freeze the full final candidate and dispatch new fresh read-only VAL-012 for remediation delta plus complete original WS-05 aggregate. Remediator checks are not independent approval. |

WS05-AC01 through AC10 and tactical MCP-05-01 through MCP-05-08 remain the aggregate review obligations. REM-006 changes only the failed privacy/correlation boundaries for AC02/06/07/08/09. Existing optional DTO/native four-field shape, byte sizes/fixed failure codes, disabled dedicated ingestion, complete UTF-8 cap and sanitizer policy, failure/cancellation, actual correlation, JSONL metadata flag and bounded Markdown/CSV decisions remain source-frozen. The 224-test focused run and 27-case public reproduction exercise these contracts. Native-only legacy duplicate-ID behavior remains compatible; uniqueness correction is confined to MCP facts. Ordinary conversation-memory behavior is unchanged and is not dedicated MCP ingestion. No telemetry, HTTP/SSE/resources/prompts/live refresh or later-phase functionality is introduced.

## Required command executions

Commands use the complete approved environment prefix `LITELLM_LOCAL_MODEL_COST_MAP=true UV_CACHE_DIR=/private/tmp/friday-uv-cache UV_NO_SYNC=true UV_OFFLINE=true PYTHONDONTWRITEBYTECODE=1`. Scratch-only extras are `PYTEST_ADDOPTS=-p no:cacheprovider`, `MYPY_CACHE_DIR=/private/tmp/REM-006-20260928/mypy-cache`, and `TMPDIR=/private/tmp/REM-006-20260928/runtime-tmp`. Cwd is the repository. Each linked JSON gives the exact command/environment/start/end/exit; full output is unfiltered. Commands ran sequentially. No network, paid/live model or external MCP service was used.

| # | Exact command | Exit / result | Full execution/output |
| --- | --- | --- | --- |
'''
results={1:'0; final 224 passed',2:'1; 567 passed, 5 skipped; unchanged PTY failure and 3 localhost errors',3:'0; 34 passed',4:'0; 209 passed',5:'0; 416 passed',6:'0; 680 passed, 1 skipped',7:'1; 77 passed; unchanged board-count failure',8:'0; final Ruff pass',9:'2; unchanged NumPy Python-3.10 syntax stop',10:'0 final; all 12 source files pass unfiltered Python-3.13 typing',11:'0; 208 packages, lock current',12:'0; board valid, 23 tasks',13:'0; dashboard current',14:'0; documentation lifecycle current'}
commands=json.loads((out/'required-command-list.json').read_text())
for i,cmd in enumerate(commands,1):
 name=f'command-{i:02}'
 if i in (1,8,10):name+='-final'
 text+=f'| {i} | `{cmd}` | {results[i]} | [JSON](REM-006-evidence.tar.gz#{name}.json) / [log](REM-006-evidence.tar.gz#{name}.log) |\n'
text+='''
The first meaningful typing run found two new key-index narrowing errors; a subsequent run found two local-variable assignment errors. Both were fixed inside output.py with explicit optional-value guards and distinct local names, without casts/ignores or scope expansion. The original command-10.log and command-10-rerun.log remain lossless evidence. Final command-10-final exited 0; final focused and Ruff reruns also exited 0. The broad suite was executed before this narrowing-only local correction; final focused/public regressions, all-source typing and Ruff validate the final source bytes. No failure is filtered or presented as passed.

Final commit-aware checks additionally record `git diff --check ORIGINAL_BASE..FULL_CANDIDATE`, `git diff --check REMEDIATION_BASE..FULL_CANDIDATE`, no working source/test/config diff vs the candidate, exact report bytes, board validate/render/documentation lifecycle, scope audit, and preservation. [Final command manifest](REM-006-evidence.tar.gz#final-command-records.json), [freeze](REM-006-evidence.tar.gz#closeout-preservation.json).

## Fresh public probes and baseline separation

The prior independent VAL-011 harness/peer were copied into this scratch root with only root-path substitutions; originals stay byte-exact. This is a fresh remediator execution, not a new independent verdict or sole evidence. Before edits the public probe reproduced exactly five failures/22 passes: four production snapshot variants and later-native persistence. After correction all 27 pass; a final committed-source replay also passes. New repository regressions add 21 cases across the three approved files. [Commands](REM-006-evidence.tar.gz#public-command-records.json), [pre-fix full output](REM-006-evidence.tar.gz#pre-fix-public.log), [candidate full output](REM-006-evidence.tar.gz#candidate-public.log), [probe](REM-006-evidence.tar.gz#test_independent.py), [peer](REM-006-evidence.tar.gz#peer.py).

Public peers cover original dispatch, echoed argument redaction, caps/normalization/marker escaping, protocol/tool/malformed/transport/timeouts, cancellation, cleanup retry/restart, both turn modes/fallback, production/fake, negative DTO/pair/correlation and human exports. Real peers stay under inherited wire-line bounds; larger decoded-output/scan cases use the prior public callable double. This proves neither inbound allocation bounds nor exact context token cost nor arbitrary secret/injection detection.

Fresh original-base archive uses `git archive a609f948fe2d869ac29d0cce29d22d9334cd7d08`, selected original source PYTHONPATH and the existing workspace environment without sync. Import logs prove Chat/Core/Transcript load under the baseline archive, not candidate source.

| Baseline | Fresh exact outcome | Candidate relationship |
| --- | --- | --- |
| Full Chat | Exit 1; 479 passed, 5 skipped, one same PTY acknowledgement assertion and three localhost fixture PermissionErrors. | Source bytes for both failing test files are identical to candidate; candidate still records the gate failed. |
| Full integration in archive | Exit 1; 68 passed, same board-count failure plus missing archive Git-catalog docs error. | Archive-only catalog limitation is distinct from product failure. |
| Baseline board/docs with read-only exact tree catalog | Exit 1; 11 passed, one board-count failure. | A wrapper answers only git ls-files using saved approved-base catalog; docs pass and board still asserts 22 while authority validates 23. No Git mutation. |
| Default five-package mypy | Exit 2; same installed NumPy __init__.pyi:737 type statement unsupported for Python-3.10 target. | Does not prove project typing passed; final unfiltered Python-3.13 affected-source check does pass. |
| F-001/F-002 original-base diagnostic | Exit 0; unsafe new snapshot/export and duplicate continuation IDs, one stored entry. | F-001 inherited privacy gap; F-002 inherited ambiguity plus pre-fix WS-05-added failure, now corrected. |

Exact commands/cwd/env/exits/logs: [baseline runner](REM-006-evidence.tar.gz#baseline.py), [import proof](REM-006-evidence.tar.gz#baseline-imports.log), [Chat](REM-006-evidence.tar.gz#baseline-chat.json), [integration](REM-006-evidence.tar.gz#baseline-integration.json), [mypy](REM-006-evidence.tar.gz#baseline-mypy.json), [catalog repair](REM-006-evidence.tar.gz#baseline-catalog-recheck.json), [failing-source identity](REM-006-evidence.tar.gz#scope-audit.json). Initial test/harness errors and their corrections are disclosed in [scratch notes](REM-006-evidence.tar.gz#scratch-harness-notes.md); complete initial logs remain archived.

## Offline built package and imports

Fresh Git archive of stable source/test candidate supplies Transcript/Core/Telemetry. Cached offline uv/hatchling builds all three wheels (exit 0). Built Transcript METADATA declares friday-framework-core==0.1.0a2; Core declares Telemetry and no reverse edge exists. No remediation dependency/lock/config edit occurred. [Exact build tools/argv/env/exits](REM-006-evidence.tar.gz#package-commands.json), [built metadata](REM-006-evidence.tar.gz#wheel-metadata.json), [harness](REM-006-evidence.tar.gz#package_check.py).

Fresh offline uv pip resolver installation fails (exit 1) because pydantic-settings is absent from the registry cache. No network fallback was attempted; this is an explicit resolver-cache limitation, not a claimed clean install. The mandatory built-artifact/import proof succeeds through the allowed existing environment: recursively version/marker-checked declared third-party dependency bytes are copied into a new venv without .pth/editable/bytecode hooks; framework bytes come only from extracted built wheels. Python -I proves Core/Transcript/Telemetry __file__ under the extracted-wheel root, no repository packages on sys.path, public SQLite/export/model imports and typed paired provenance JSON round-trip (exit 0). Declared closure versions and every copied file hash are archived. This proves built public imports without editable framework hooks; it does not prove network installation or a populated clean resolver cache. [Fallback harness](REM-006-evidence.tar.gz#package_fallback.py), [exact import invocation](REM-006-evidence.tar.gz#package-imports-fallback.json), [full output](REM-006-evidence.tar.gz#package-imports-fallback.log), [dependency hashes](REM-006-evidence.tar.gz#isolated-declared-dependencies.json), [isolated script](REM-006-evidence.tar.gz#wheel-import.py).

## Public cleanup, frozen preservation and lossless deliverables

Repository/new probes assert public stop clears metadata, provider-owned names and connections, children have exited with both streams EOF, and no owned tasks remain, before defensive finally cleanup. The fresh baseline and corrected diagnostic each report all five public cleanup booleans true. Finally blocks drain 4096-byte chunks, kill only their own unsettled children and reap under timeouts, also when an assertion fails. Public-cleanup success is distinct from defensive teardown.

Start/interim/product-candidate/final preservation checks compare all 41 frozen authority/report/evidence inputs, 971 tracked product files outside seven source/test paths, and recursive fingerprints of the five unrelated dirty paths; errors are empty. The source/test/config manifest stays confined to the approved paths. The original WS-05/VAL-011 reports/request/evidence and accepted predecessor bytes are not rewritten. The retained unrelated manifest is .DS_Store modified, family-tree.md absent, docker-bench-security/ untracked (57 files), Chat config backup untracked and sandbox Dockerfile.audit untracked. Exact fingerprints are in start-manifest.json and closeout-preservation.json.

Every deliverable member has an exact size and SHA-256 in evidence.json. delivery.json pins the final full candidate, report, manifest and archive hashes without recursive self-hashes. The deterministic archive preserves original member bytes and includes scripts, full logs, command JSON, probes/audits, numbered source copies, approved input copies and built wheels. Runtime SQLite DBs, export/temp trees, extracted baseline/package/venv trees, caches, unrelated artifacts and real secrets are excluded. No runtime DB is staged or delivered.

Remaining gates: controller freeze, fresh read-only VAL-012 delta plus complete original aggregate, explicit maintainer WS-05 acceptance after an independent VERIFIED outcome, future aggregate pre-merge review, and separate WS-06/07/08/later/delivery authority. This report neither self-validates nor closes WS-05 and does not authorize historical session cleanup or delivery.
'''
path=root/'docs/planning/active/friday-mcp/execution/REM-006-implementation-report.md';path.write_text(text)
(out/'REM-006-implementation-report.md').write_text(text)
