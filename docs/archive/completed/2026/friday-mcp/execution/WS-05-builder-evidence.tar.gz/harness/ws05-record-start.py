from pathlib import Path
from datetime import datetime, timezone
import yaml, hashlib, json, subprocess, re
p=Path('docs/planning/active/friday-mcp')
base='a609f948fe2d869ac29d0cce29d22d9334cd7d08'
d=p/'directives/ws-05-execution-provenance-transcript.md'
s=d.read_text().replace('Status: Reconciled draft; explicit maintainer approval pending','Status: Approved construction directive').replace('Execution base: the committed approved planning checkpoint, to be pinned before implementation',f'Execution base: `{base}`')
old='''The maintainer's latest "proceed" follows the WS-04 acceptance closeout's stated
WS-05 directive/readiness gate. It authorizes this planning reconciliation;
WS-05 product code remains unapproved. WS-00 through WS-04 stay accepted, and
VAL-010's frozen inputs remain unchanged. After explicit approval, record the
approval, pin the full work-unit base, create `feature/friday-mcp-ws05-execution`,
and reconcile board/packet/start before code generation.'''
new='''The maintainer explicitly approved this complete bounded directive on
2026-09-28 with "ws-05 is approved. proceed" after the planning checkpoint
`a609f94`. WS-00 through WS-04 stay accepted. Execution starts on
`feature/friday-mcp-ws05-execution` from the full base above; the board and
packet record that start before product generation. Approval covers exactly
this WS-05 slice and its required fresh independent review, not later workstreams
or delivery. Historical VAL-010 reviewed product remains the accepted predecessor;
only the new WS-05 approved paths may change.'''
assert old in s;s=s.replace(old,new);d.write_text(s)
idx=p/'README.md';s=idx.read_text().replace('next_gate: explicit approval of reconciled WS-05 construction directive','next_gate: implement approved WS-05 then freeze candidate for fresh VAL-011').replace('implementation_authority: granted for MCP-WS-00 through MCP-WS-04 with approved predecessor amendments','implementation_authority: granted for MCP-WS-00 through MCP-WS-05 with approved predecessor amendments').replace('execution_phase: planning','execution_phase: implementation')
s=s.replace('is explicit approval of the reconciled WS-05 directive. Current','is implementation of the approved WS-05 directive. Current').replace('phase planning/state not_ready describes that next-slice preparation, not a','phase implementation/state not_ready describes WS-05 construction, not a').replace('WS-05 is reconciled and unapproved; later slices remain draft.','WS-05 is approved; later slices remain draft.')
s+='''\n## 2026-09-28 — WS-05 Approved And Started\n\nMaintainer said "ws-05 is approved. proceed", approving the complete bounded\n23-path directive at planning checkpoint `a609f948fe2d869ac29d0cce29d22d9334cd7d08`.\nExecution starts on `feature/friday-mcp-ws05-execution` from that work-unit base.\nPhase implementation/state not_ready; next implement/test, freeze a stable\ncandidate and obtain fresh read-only complete-aggregate VAL-011. Accepted\npredecessors and unrelated local work remain intact. No later-slice, acceptance\nor delivery authority is inferred. Earlier pending-approval text is historical.\n''';idx.write_text(s)
q=p/'task-queue.md';s=q.read_text().replace('Status: WS-04 accepted; WS-05 planning reconciled, explicit directive approval pending','Status: WS-04 accepted; WS-05 explicitly approved, implementation started').replace('Branch: `feature/friday-mcp-ws04-chat-budget`','Branch: `feature/friday-mcp-ws05-execution`').replace('Planning reconciled in [checkpoint](execution/WS-05-readiness-checkpoint.md); explicit approval of the complete bounded directive is pending.','Approved with "ws-05 is approved. proceed"; implementation started from `a609f94`, stable candidate and fresh VAL-011 required.')
s+='''\n## 2026-09-28 — WS-05 Approved Execution\n\nExplicit maintainer approval: "ws-05 is approved. proceed". Task 8 is current:\nimplement the exact approved 23 paths, perform required checks/UAT, freeze a\ncandidate, obtain new fresh read-only complete-aggregate VAL-011, then propose\ncloseout for explicit acceptance. Work-unit base `a609f94`; branch\n`feature/friday-mcp-ws05-execution`; phase implementation/state not_ready.\nAccepted WS-00 through WS-04 remain intact. Later slices and delivery remain gated.\n''';q.write_text(s)
l=p/'execution-log.md';s=l.read_text()+'''\n## 2026-09-28 — WS-05 Explicit Approval And Start\n\nMaintainer explicitly said "ws-05 is approved. proceed" after complete bounded\ndirective/readiness review. Approved scope: exactly 23 implementation paths,\neight tactical tasks and ten criteria at `a609f948fe2d869ac29d0cce29d22d9334cd7d08`.\nDedicated branch created: `feature/friday-mcp-ws05-execution`. Board names that\nbranch and implementation gate before code generation. Phase implementation,\nvalidation state not_ready. Stable candidate, full required checks and fresh\nread-only complete-aggregate VAL-011 precede proposed work-unit acceptance.\nNo later-slice, push/merge/release or live-provider authority. Five unrelated\npath fingerprints are retained from the accepted predecessor audit.\n''';l.write_text(s)
board=Path('docs/planning/board.yaml');b=yaml.safe_load(board.read_text());t=next(x for x in b['tasks'] if x['id']=='friday-mcp');assert t['work_state']=='started' and t['implementation_authority']=='granted'
t['branch']='feature/friday-mcp-ws05-execution';t['next_gate']='implement approved WS-05 then freeze candidate for fresh VAL-011'
b['events'].append({'task':'friday-mcp','at':datetime.now(timezone.utc).isoformat(),'actor':'repository maintainer','actor_role':'maintainer','action':'note','note':'Explicit WS-05 approval: ws-05 is approved. proceed; complete reconciled 23-path directive at a609f94. Dedicated execution branch started; no later-slice or delivery authority.','evidence':str(d)})
board.write_text(yaml.safe_dump(b,sort_keys=False,width=1000))
# Freeze approved authority and all product files; exclusions are exact approved paths.
manifest=re.findall(r'^- `([^`]+)`$', d.read_text(),re.M)[:23]
assert len(manifest)==23
old=json.loads(Path('/private/tmp/ws04-dispatch-freeze.json').read_text())
inputs=dict(old['inputs']);inputs[str(d)]=hashlib.sha256(d.read_bytes()).hexdigest()
# Original WS-05 planning checkpoint remains historical; approval/start records above are separate.
product={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in subprocess.check_output(['git','ls-files','packages','tests','pyproject.toml','uv.lock'],text=True).splitlines()}
unrelated=json.loads(Path('/private/tmp/ws04-checks/preservation.json').read_text())['unrelated']
Path('/private/tmp/ws05-start-freeze.json').write_text(json.dumps({'base':base,'allowed':manifest,'inputs':inputs,'product':product,'unrelated':unrelated},indent=2)+'\n')
print('Recorded explicit WS-05 approval/start and frozen 30 authority/report inputs, 971 products and five unrelated paths.')
