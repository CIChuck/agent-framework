from pathlib import Path
import os, subprocess, json, zipfile, time
repo=Path.cwd();dest=Path('/private/tmp/ws05-packaging');dest.mkdir(exist_ok=True)
cache=Path('/private/tmp/friday-uv-cache/archive-v0')
modules=['hatchling','pathspec','tomlkit','trove_classifiers']
paths=[]
for mod in modules:
    found=sorted(cache.glob('*/'+mod+'/__init__.py'))
    if not found: raise RuntimeError('Offline build tool unavailable: '+mod)
    paths.append(str(found[0].parents[1]))
env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join(paths);env['LITELLM_LOCAL_MODEL_COST_MAP']='true'
records=[]
for pkg in ['friday-telemetry','friday-core','friday-transcript']:
    args=[str(repo/'.venv/bin/python'),'-m','build','--wheel','--no-isolation','--outdir',str(dest/'wheels'),str(repo/'packages'/pkg)]
    log=dest/(pkg+'.log');start=time.monotonic()
    with log.open('w') as out:r=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
    records.append({'command':args,'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log)})
    if r.returncode:print(log.read_text());raise RuntimeError('Offline build failed')
wheel=next((dest/'wheels').glob('friday_framework_transcript-*.whl'))
with zipfile.ZipFile(wheel) as z:
    name=next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))
    text=z.read(name).decode();assert 'Requires-Dist: friday-framework-core==0.1.0a2' in text
for wheel in (dest/'wheels').glob('*.whl'):
    with zipfile.ZipFile(wheel) as z:z.extractall(dest/'imports')
script=dest/'isolated_import.py'
script.write_text('''import sys, json\nfrom pathlib import Path\nsys.path.insert(0, '''+repr(str(repo/'.venv/lib/python3.13/site-packages'))+''')\nsys.path.insert(0, '''+repr(str(dest/'imports'))+''')\nfrom friday_transcript import ToolCall, ToolResult, TranscriptEntry\nfrom friday_core.mcp import MCPToolCallProvenance, MCPToolMetadata\nfrom friday_transcript.models.transcript import mcp_provenance_summary\nimport friday_transcript, friday_core, friday_telemetry\nallowed={'friday_transcript','friday_core','friday_telemetry'}\nloaded={n.split('.')[0] for n in sys.modules if n.startswith('friday_')}\nassert loaded <= allowed, loaded\nfor module in [friday_transcript, friday_core, friday_telemetry]:\n    assert str(Path(module.__file__).resolve()).startswith('''+repr(str(dest/'imports'))+'''), module.__file__\nf=MCPToolCallProvenance(tool=MCPToolMetadata(canonical_name='mcp_peer_read',server_name='peer',original_name='read',transport='stdio',trust_level='local'),status='succeeded',call_id='call1',output_sanitization_state='sanitized',model_result_size_bytes=4)\nc=ToolCall(id='call1',name=f.tool.canonical_name,mcp_provenance=f)\nr=ToolResult(tool_call_id='call1',output='safe',mcp_provenance=f)\nassert ToolCall.model_validate_json(c.model_dump_json())==c\nassert ToolResult.model_validate_json(r.model_dump_json())==r\nprint(json.dumps({'isolated_public_imports':True,'loaded_friday_packages':sorted(loaded),'typed_json_roundtrip':True}))\n''')
args=[str(repo/'.venv/bin/python'),'-S',str(script)]
with (dest/'isolated-import.log').open('w') as out:r=subprocess.run(args,cwd=dest,stdout=out,stderr=subprocess.STDOUT)
records.append({'command':args,'exit_code':r.returncode,'log':str(dest/'isolated-import.log')})
(dest/'summary.json').write_text(json.dumps({'offline_build_tool_paths':paths,'transcript_declares_core':True,'checks':records},indent=2)+'\n')
print(json.dumps(records),flush=True)
print((dest/'isolated-import.log').read_text())
if r.returncode:raise RuntimeError('Isolated import failed')
