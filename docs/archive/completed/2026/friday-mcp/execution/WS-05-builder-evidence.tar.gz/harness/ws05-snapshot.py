from pathlib import Path
p=Path('packages/friday-chat/src/friday_chat/turns/processor.py');s=p.read_text()
s=s.replace('    budget_status: BudgetStatus\n\n\nclass TurnProcessingError','    budget_status: BudgetStatus\n    mcp_tool_names: frozenset[str] = frozenset()\n\n\nclass TurnProcessingError')
s=s.replace('            prepared.tool_definitions,\n        )','            prepared.tool_definitions,\n            mcp_names=prepared.mcp_tool_names,\n        )',1)
s=s.replace('                prepared.tool_definitions,\n            )','                prepared.tool_definitions,\n                mcp_names=prepared.mcp_tool_names,\n            )',1)
s=s.replace('        retrieval_start = now_seconds()','        mcp_tool_names = frozenset(self._mcp_names())\n        retrieval_start = now_seconds()',1)
s=s.replace('            messages=messages,\n            budget_status=budget_status,','            messages=messages,\n            budget_status=budget_status,\n            mcp_tool_names=mcp_tool_names,',1)
s=s.replace('''        tool_definitions: tuple[ToolDefinition, ...],
    ) -> tuple[
''','''        tool_definitions: tuple[ToolDefinition, ...],
        *,
        mcp_names: frozenset[str] | None = None,
    ) -> tuple[
''',1)
s=s.replace('        llm_start = now_seconds()\n        model_response =','        llm_start = now_seconds()\n        mcp_names = mcp_names if mcp_names is not None else frozenset(self._mcp_names())\n        model_response =',1)
s=s.replace('                tool_definitions,\n            )\n        model_response = self._safe_model_response(model_response)','                tool_definitions,\n                mcp_names=mcp_names,\n            )\n        model_response = self._safe_model_response(model_response, mcp_names)',1)
s=s.replace('''        tool_definitions: tuple[ToolDefinition, ...],
    ) -> tuple[ChatModelResponse, tuple[ToolCallRecord, ...]]:''','''        tool_definitions: tuple[ToolDefinition, ...],
        *,
        mcp_names: frozenset[str],
    ) -> tuple[ChatModelResponse, tuple[ToolCallRecord, ...]]:''',1)
s=s.replace('response, tool_definitions, used_call_ids=used_call_ids\n','response, tool_definitions, used_call_ids=used_call_ids, mcp_names=mcp_names\n',1)
s=s.replace('                self._mcp_names(),\n','                set(mcp_names),\n',1)
s=s.replace('''    def _safe_model_response(self, response: ChatModelResponse) -> ChatModelResponse:
        """Drop any remaining MCP request prose/raw copies before return/capture."""
        mcp_names = self._mcp_names()''','''    def _safe_model_response(
        self, response: ChatModelResponse, mcp_names: frozenset[str],
    ) -> ChatModelResponse:
        """Drop any remaining MCP request prose/raw copies before return/capture."""''')
s=s.replace('        used_call_ids: set[str] | None = None,\n    ) -> tuple[ToolCallRecord, ...]:','        used_call_ids: set[str] | None = None,\n        mcp_names: frozenset[str] = frozenset(),\n    ) -> tuple[ToolCallRecord, ...]:',1)
s=s.replace('            used_call_ids=used_call_ids,\n        )\n        mcp_names = self._mcp_names()','            used_call_ids=used_call_ids,\n            mcp_tool_names=mcp_names,\n        )',1)
p.write_text(s)
p=Path('packages/friday-chat/src/friday_chat/tools/loop.py');s=p.read_text();s=s.replace('        used_call_ids: set[str] | None = None,\n    ) -> ToolLoopResult:','        used_call_ids: set[str] | None = None,\n        mcp_tool_names: frozenset[str] = frozenset(),\n    ) -> ToolLoopResult:',1).replace('        safe_messages: list[Mapping[str, Any]] = [','        mcp_names.update(mcp_tool_names)\n        safe_messages: list[Mapping[str, Any]] = [',1);p.write_text(s)
