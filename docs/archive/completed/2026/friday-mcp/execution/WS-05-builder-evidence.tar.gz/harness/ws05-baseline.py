from pathlib import Path
import subprocess, os, json, time, tarfile
repo=Path.cwd(); dest=Path('/private/tmp/ws05-baseline'); dest.mkdir(exist_ok=True); checkout=dest/'checkout'; checkout.mkdir(exist_ok=True)
archive=subprocess.check_output(['git','archive','a609f948fe2d869ac29d0cce29d22d9334cd7d08']); import io
with tarfile.open(fileobj=io.BytesIO(archive)) as tar: tar.extractall(checkout,filter='data')
env=os.environ.copy();env.update(LITELLM_LOCAL_MODEL_COST_MAP='true',UV_CACHE_DIR='/private/tmp/friday-uv-cache',PYTHONPATH=os.pathsep.join(str(p) for p in sorted((checkout/'packages').glob('*/src'))),PYTHONDONTWRITEBYTECODE='1')
python=str(repo/'.venv/bin/python'); packages=['packages/friday-core','packages/friday-mcp','packages/friday-chat','packages/friday-transcript','packages/friday-agent']
commands=[['pytest','packages/friday-chat/tests_chat','-q','--tb=short'],['pytest','tests/integration','-q','--tb=short'],['mypy',*packages,'--cache-dir',str(dest/'mypy-cache')],['mypy','--python-version','3.13',*[p for p in json.loads(Path('/private/tmp/ws05-start-freeze.json').read_text())['allowed'] if '/src/' in p and (checkout/p).exists()],'--cache-dir',str(dest/'mypy-13-cache')]]
records=[]
for i,args in enumerate(commands,1):
    start=time.monotonic(); log=dest/f'check-{i:02}.log'
    with log.open('w') as out: r=subprocess.run([python,'-m',*args],cwd=checkout,env=env,stdout=out,stderr=subprocess.STDOUT)
    record={'command':[python,'-m',*args],'cwd':str(checkout),'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log)}
    records.append(record);(dest/'summary.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
