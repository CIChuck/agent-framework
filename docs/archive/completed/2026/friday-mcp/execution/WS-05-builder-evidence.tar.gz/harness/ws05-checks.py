from pathlib import Path
import os, subprocess, json, time
root=Path.cwd();dest=Path('/private/tmp/ws05-checks');dest.mkdir(exist_ok=True)
env=os.environ.copy();env.update(LITELLM_LOCAL_MODEL_COST_MAP='true',UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_NO_SYNC='true',UV_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
manifest=json.loads(Path('/private/tmp/ws05-start-freeze.json').read_text())['allowed']
focused=[p for p in manifest if '/test' in p and p.endswith('.py') and '/fixtures/' not in p]+[
'packages/friday-chat/tests_chat/compat/test_tool_loop_parity.py','packages/friday-chat/tests_chat/compat/test_turn_contract_parity.py',
'packages/friday-chat/tests_chat/test_turn_processing.py','packages/friday-chat/tests_chat/test_transcript_production_commands.py','packages/friday-chat/tests_chat/test_transcript_export_commands.py']
commands=[
['uv','run','pytest',*focused,'-q','--tb=short'],
['uv','run','pytest','packages/friday-chat/tests_chat','-q','--tb=short'],
['uv','run','pytest','packages/friday-transcript/tests','-q','--tb=short'],
['uv','run','pytest','packages/friday-agent/tests_agent','-q','--tb=short'],
['uv','run','pytest','packages/friday-core/tests_core','packages/friday-mcp/tests_mcp','packages/friday-runtime/tests_runtime','-q','--tb=short'],
['uv','run','pytest','packages/friday-memory/tests_memory','-q','--tb=short'],
['uv','run','pytest','tests/integration','-q','--tb=short'],
['uv','run','ruff','check','packages/friday-core','packages/friday-mcp','packages/friday-chat','packages/friday-transcript','packages/friday-agent','tests/integration/test_mcp_execution_provenance.py'],
['uv','run','mypy','packages/friday-core','packages/friday-mcp','packages/friday-chat','packages/friday-transcript','packages/friday-agent'],
['uv','run','mypy','--python-version','3.13',*[p for p in manifest if '/src/' in p]],
['uv','lock','--check','--offline'],
['uv','run','python','scripts/friday-dev-board.py','validate'],
['uv','run','python','scripts/friday-dev-board.py','render','--check'],
['uv','run','python','scripts/check-documentation-lifecycle.py'],
['git','diff','--check'],
]
records=[]
for i,args in enumerate(commands,1):
    log=dest/f'check-{i:02}.log';start=time.monotonic()
    with log.open('w') as out:r=subprocess.run(args,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
    record={'id':i,'command':args,'environment':{k:env[k] for k in ['LITELLM_LOCAL_MODEL_COST_MAP','UV_CACHE_DIR','UV_NO_SYNC','UV_OFFLINE','PYTHONDONTWRITEBYTECODE']},'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log)}
    records.append(record);(dest/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(record),flush=True)
