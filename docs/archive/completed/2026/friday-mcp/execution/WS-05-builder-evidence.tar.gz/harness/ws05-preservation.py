from pathlib import Path
import json, hashlib, subprocess
root=Path.cwd();snapshot=json.loads(Path('/private/tmp/ws05-start-freeze.json').read_text());allowed=set(snapshot['allowed'])
for name,digest in snapshot['inputs'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
for name,digest in snapshot['product'].items():
    if name not in allowed:assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
tracked=set(subprocess.check_output(['git','ls-files','packages','tests','pyproject.toml','uv.lock'],text=True).splitlines())
assert tracked-set(snapshot['product']) <= allowed
modified=set(subprocess.check_output(['git','diff','--name-only',snapshot['base'],'--','packages','tests','pyproject.toml','uv.lock'],text=True).splitlines())
assert modified <= allowed, modified-allowed
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','packages','tests'],text=True).splitlines())
assert untracked-allowed == {'packages/friday-chat/config.example.yaml.pre-typed-llm-20260828.bak','packages/friday-sandbox/docker/Dockerfile.audit'}
actual={}
for name in snapshot['unrelated']:
    path=root/name
    if not path.exists() and not path.is_symlink():actual[name]={'state':'absent'};continue
    paths=sorted(path.rglob('*')) if path.is_dir() else [path];digest=hashlib.sha256();count=0
    for f in paths:
        if f.is_symlink():data=('symlink:'+str(f.readlink())).encode()
        elif f.is_file():data=f.read_bytes()
        else:continue
        digest.update(str(f.relative_to(root)).encode()+b'\0'+data+b'\0');count+=1
    actual[name]={'files':count,'sha256':digest.hexdigest(),'state':'present'}
assert actual==snapshot['unrelated'],actual
result={'base':snapshot['base'],'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'approved_inputs_unchanged':len(snapshot['inputs']),'product_files_unchanged_outside_scope':len([x for x in snapshot['product'] if x not in allowed]),'product_scope_valid':True,'unrelated':actual}
Path('/private/tmp/ws05-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='unrelated'},indent=2))
