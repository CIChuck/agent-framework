import sys, json
from pathlib import Path
sys.path.insert(0, '/Users/chuckrussell/Dev/gendev/agent-framework/.venv/lib/python3.13/site-packages')
sys.path.insert(0, '/private/tmp/ws05-packaging/imports')
from friday_transcript import ToolCall, ToolResult, TranscriptEntry
from friday_core.mcp import MCPToolCallProvenance, MCPToolMetadata
from friday_transcript.models.transcript import mcp_provenance_summary
import friday_transcript, friday_core, friday_telemetry
allowed={'friday_transcript','friday_core','friday_telemetry'}
loaded={n.split('.')[0] for n in sys.modules if n.startswith('friday_')}
assert loaded <= allowed, loaded
for module in [friday_transcript, friday_core, friday_telemetry]:
    assert str(Path(module.__file__).resolve()).startswith('/private/tmp/ws05-packaging/imports'), module.__file__
f=MCPToolCallProvenance(tool=MCPToolMetadata(canonical_name='mcp_peer_read',server_name='peer',original_name='read',transport='stdio',trust_level='local'),status='succeeded',call_id='call1',output_sanitization_state='sanitized',model_result_size_bytes=4)
c=ToolCall(id='call1',name=f.tool.canonical_name,mcp_provenance=f)
r=ToolResult(tool_call_id='call1',output='safe',mcp_provenance=f)
assert ToolCall.model_validate_json(c.model_dump_json())==c
assert ToolResult.model_validate_json(r.model_dump_json())==r
print(json.dumps({'isolated_public_imports':True,'loaded_friday_packages':sorted(loaded),'typed_json_roundtrip':True}))
