from pathlib import Path
import subprocess,os,json,zipfile,email,importlib.metadata as md,shutil,hashlib,tomllib
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name
ROOT=Path.cwd();OUT=Path('/private/tmp/ws06-work');WHEELS=OUT/'wheels';WHEELS.mkdir(exist_ok=True)
env={**os.environ,'UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1','LITELLM_LOCAL_MODEL_COST_MAP':'true'}
records=[]
def run(label,args):
 with (OUT/(label+'.log')).open('w') as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 record={'label':label,'command':args,'exit_code':r.returncode};records.append(record)
 print(label,r.returncode,flush=True)
 (OUT/'package-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 return r.returncode
workspace={}
for meta in ROOT.glob('packages/*/pyproject.toml'):
 p=tomllib.loads(meta.read_text())['project'];workspace[canonicalize_name(p['name'])]=(meta.parent,p)
selected=set();queue=['friday-chat','friday-framework-memory','friday-framework-core','friday-framework-transcript']
while queue:
 name=queue.pop();name=canonicalize_name(name)
 if name in selected:continue
 selected.add(name)
 for raw in workspace[name][1].get('dependencies',[]):
  req=Requirement(raw)
  if req.marker and not req.marker.evaluate({'extra':''}):continue
  if canonicalize_name(req.name) in workspace:queue.append(req.name)
for name in sorted(selected):
 path=workspace[name][0]
 if run('build-'+name,['uv','build','--offline','--wheel',str(path),'--out-dir',str(WHEELS)]):raise RuntimeError('Required offline build failed')
extracted=OUT/'extracted-wheels';extracted.mkdir(exist_ok=True);framework={};metadata={}
for wheel in sorted(WHEELS.glob('*.whl')):
 with zipfile.ZipFile(wheel) as z:
  raw=z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))).decode();m=email.message_from_string(raw)
  name=canonicalize_name(m['Name']);framework[name]=(m['Version'],m.get_all('Requires-Dist',[]));z.extractall(extracted)
  metadata[wheel.name]={'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'metadata':raw}
(OUT/'wheel-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
venv=OUT/'wheel-venv'
if run('wheel-venv',['uv','venv','--offline','--python',str(ROOT/'.venv/bin/python'),str(venv)]):raise RuntimeError('venv failed')
run('wheel-install',['uv','pip','install','--offline','--python',str(venv/'bin/python'),*[str(w) for w in WHEELS.glob('*.whl')]])
third=OUT/'declared-dependencies';third.mkdir(exist_ok=True);chosen={};deps={}
queue=[Requirement(r) for version,requirements in framework.values() for r in requirements]
while queue:
 req=queue.pop(0)
 if req.marker and not req.marker.evaluate({'extra':''}):continue
 name=canonicalize_name(req.name)
 if name in framework:
  if not req.specifier.contains(framework[name][0],prereleases=True):raise ValueError('Framework requirement version mismatch')
  continue
 if name in workspace:raise ValueError('Declared workspace distribution was not built')
 dist=md.distribution(req.name)
 if not req.specifier.contains(dist.version,prereleases=True):raise ValueError('Installed requirement version mismatch: '+str(req))
 if name in chosen:continue
 chosen[name]=dist;queue.extend(Requirement(r) for r in dist.requires or [])
for name,dist in chosen.items():
 files={}
 for item in dist.files or []:
  if '..' in item.parts or '__pycache__' in item.parts or str(item).endswith(('.pyc','.pth')):continue
  source=Path(dist.locate_file(item))
  if not source.is_file():continue
  dest=third/str(item);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
  files[str(item)]=hashlib.sha256(source.read_bytes()).hexdigest()
 deps[name]={'version':dist.version,'requires':dist.requires or [],'files':files}
(OUT/'declared-dependencies.json').write_text(json.dumps(deps,indent=2)+'\n')
if run('wheel-roundtrip',[str(venv/'bin/python'),'-I',str(OUT/'wheel_roundtrip.py'),str(extracted),str(third)]):raise RuntimeError('Required isolated roundtrip failed')
print('Declared-distribution proof passed.',flush=True)
