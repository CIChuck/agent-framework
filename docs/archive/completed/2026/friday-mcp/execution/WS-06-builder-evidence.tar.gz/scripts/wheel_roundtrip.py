import sys,asyncio,json,tempfile
from pathlib import Path
root=Path(sys.argv[1]);third=Path(sys.argv[2]);sys.path[:0]=[str(root),str(third)]
import friday_chat,friday_memory,friday_core,friday_transcript
from friday_chat.adapters import FrameworkMemoryAdapter,FrameworkTranscriptAdapter
from friday_chat.runtime import MCPTranscriptReceipt
from friday_chat.memory_mcp import persist_mcp_interaction
from friday_chat.turns.models import InteractionTurn,TurnMetrics
from friday_chat.tools.output import MCPOutputPolicy
from friday_chat.config import FridayChatConfig
from friday_memory import CollectionManager,MemoryController,NullGraphStore,InMemoryEpisodicStore
from friday_memory.models.mcp import MCPMemorySnapshot
from friday_core.mcp import MCPToolMetadata
from friday_transcript import SQLiteTranscriptStore
paths={m.__name__:m.__file__ for m in (friday_chat,friday_memory,friday_core,friday_transcript)}
if not all(Path(p).is_relative_to(root) for p in paths.values()):raise RuntimeError('Non-wheel source import')
if any('/Dev/gendev/agent-framework' in p for p in sys.path):raise RuntimeError('Workspace support leaked')
class Embeddings:
 async def embed_documents(self,texts):return [[1.,0.,0.,0.] for _ in texts]
 async def embed_query(self,text):return [1.,0.,0.,0.]
async def run():
 with tempfile.TemporaryDirectory(prefix='ws06-wheel-proof-') as tmp:
  cfg=FridayChatConfig.model_validate({'tools':{'providers':{'mcp':{'config':{'ingestion':{'long_term_memory_enabled':True,'opted_in_servers':['peer']}}}}}})
  cm=CollectionManager(Embeddings(),path=tmp+'/vectors');episodic=InMemoryEpisodicStore();graph=NullGraphStore()
  controller=MemoryController(cm.short_term,graph,episodic,cm)
  memory=FrameworkMemoryAdapter(controller,cm,cfg,'s',episodic,graph)
  transcript=FrameworkTranscriptAdapter(SQLiteTranscriptStore(tmp+'/transcript.sqlite'),cfg,'s')
  tool=MCPToolMetadata(canonical_name='mcp_peer_read',server_name='peer',original_name='read',transport='stdio',trust_level='local')
  record=MCPOutputPolicy(256).checked_record(tool,'call','benign',{})
  turn=InteractionTurn('entry','user','answer','','',(),TurnMetrics(0,0,0,0),tool_calls=(record,))
  calls=await persist_mcp_interaction(memory,transcript,cfg.tools.mcp_provider.config.ingestion,turn)
  stored=await cm.get_mcp_snapshot(calls[0].mcp_provenance.memory_correlation_id)
  if stored is None or stored.state!='committed':raise RuntimeError('Stored receipt failed')
  if MCPMemorySnapshot.model_validate_json(stored.snapshot.model_dump_json())!=stored.snapshot:raise RuntimeError('Typed roundtrip failed')
  if not any('MCP snapshot' in s for s in await memory.retrieve('benign',token_limit=1024)):raise RuntimeError('Retrieval failed')
asyncio.run(run())
print(json.dumps({'paths':paths,'sys_path':sys.path,'public_typed_chroma_sqlite_roundtrip':True,'editable_workspace_support':False},indent=2))
