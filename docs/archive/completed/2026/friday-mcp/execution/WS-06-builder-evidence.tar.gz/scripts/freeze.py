from pathlib import Path
import json,hashlib,subprocess
root=Path('/Users/chuckrussell/Dev/gendev/agent-framework');start=json.loads(Path('/private/tmp/ws06-work/start-freeze.json').read_text());errors=[]
for p,digest in start['outside_product'].items():
 if hashlib.sha256((root/p).read_bytes()).hexdigest()!=digest:errors.append('outside product: '+p)
frozen=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-013-frozen-inputs.json').read_text())
for row in [frozen['request'],*frozen['authority'],*frozen['candidate_reports'],*frozen['historical_evidence'],*frozen['builder_evidence']]:
 if hashlib.sha256((root/row['path']).read_bytes()).hexdigest()!=row['sha256']:errors.append('accepted authority/evidence: '+row['path'])
actual={}
for name in start['unrelated']:
 p=root/name
 if not p.exists() and not p.is_symlink():actual[name]={'state':'absent'};continue
 paths=sorted(p.rglob('*')) if p.is_dir() else [p];digest=hashlib.sha256();count=0
 for f in paths:
  if f.is_symlink():data=('symlink:'+str(f.readlink())).encode()
  elif f.is_file():data=f.read_bytes()
  else:continue
  digest.update(str(f.relative_to(root)).encode()+b'\0'+data+b'\0');count+=1
 actual[name]={'files':count,'sha256':digest.hexdigest(),'state':'present'}
if actual!=start['unrelated']:errors.append('unrelated fingerprints')
changed=set(subprocess.check_output(['git','diff','--name-only',start['base'],'--','packages','tests','pyproject.toml','uv.lock'],cwd=root,text=True).splitlines())
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','packages','tests'],cwd=root,text=True).splitlines())
expected={'packages/friday-chat/config.example.yaml.pre-typed-llm-20260828.bak','packages/friday-sandbox/docker/Dockerfile.audit'}
if changed-set(start['allowed']):errors.append('outside approved manifest: '+str(changed-set(start['allowed'])))
if untracked-set(start['allowed'])!=expected:errors.append('untracked scope')
result={'outside_product_files':len(start['outside_product']),'accepted_authorities':len(frozen['authority']),'accepted_reports':len(frozen['candidate_reports']),'accepted_historical_artifacts':len(frozen['historical_evidence']),'unrelated':actual,'changed_product_paths':sorted(changed),'errors':errors}
Path('/private/tmp/ws06-work/preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='unrelated'}))
if errors:raise SystemExit(1)
