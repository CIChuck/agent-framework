from pathlib import Path
import json,os,subprocess,sys,time
label=sys.argv[1];cmd=sys.argv[2:];root=Path('/private/tmp/ws06-work');start=time.monotonic()
env={**os.environ,'UV_NO_SYNC':'true','UV_CACHE_DIR':'/private/tmp/friday-uv-cache','LITELLM_LOCAL_MODEL_COST_MAP':'true'}
with (root/(label+'.log')).open('w') as out:
 try:
  result=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=240);status=result.returncode
 except subprocess.TimeoutExpired:
  status=124;out.write('\nCOMMAND TIMEOUT AFTER 240 SECONDS\n')
record={'command':cmd,'exit_code':status,'seconds':round(time.monotonic()-start,2),'log':str(root/(label+'.log'))}
(root/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
