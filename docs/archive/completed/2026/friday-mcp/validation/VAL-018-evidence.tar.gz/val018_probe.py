import asyncio, copy, os, pathlib, re, subprocess, sys, tempfile
import yaml
from friday_agent import DefaultToolRegistry
from friday_chat.config import FridayChatConfig, FridayChatConfigError, load_friday_py_config
from friday_runtime.config import MCPToolProviderConfig, RuntimeConfig, ToolsConfig
from friday_runtime.mcp_loading import RuntimeMCPProvider
from friday_runtime.tool_loading import ToolProviderLoadError
R=pathlib.Path.cwd(); guide=(R/'docs/guides/17-mcp-client.md').read_text()
snippets=[yaml.safe_load(s) for s in re.findall(r'```yaml\n(.*?)\n```',guide,re.S)]
assert len(snippets)==4,len(snippets)
for index,body in enumerate(snippets,1):
 p=MCPToolProviderConfig.from_dict(body['tools']['providers']['mcp'])
 rt=RuntimeConfig(workspace_root=str(R),runtime_data_root='/private/tmp/val018_runtime_state',install_root=str(R),tools_config=ToolsConfig.from_dict(body['tools']))
 ch=FridayChatConfig.model_validate({'llm':{'model':'local/test'},**body})
 assert (rt.tools.providers.mcp.enabled,ch.tools.mcp_provider.enabled)==(p.enabled,p.enabled)
 print('YAML',index,'runtime/chat OK','enabled',p.enabled,'selection',p.include_tools,p.include_categories)
templates=[]
for name in ['packages/friday-chat/config.example.yaml','packages/friday-chat/src/friday_chat/config_templates/config.example.yaml']:
 body=yaml.safe_load((R/name).read_text()); stanza=body['tools']['providers']['mcp']; templates.append(stanza)
 assert not MCPToolProviderConfig.from_dict(stanza).enabled
 RuntimeConfig(workspace_root=str(R),runtime_data_root='/private/tmp/val018_runtime_state',install_root=str(R),tools_config=ToolsConfig.from_dict({'providers':{'mcp':stanza}}))
 FridayChatConfig.model_validate(body)
 print('template',name,'runtime/chat OK')
assert templates[0]==templates[1]
with tempfile.TemporaryDirectory(prefix='val018_',dir='/private/tmp') as temp:
 path=pathlib.Path(temp)/'chat.yaml';path.write_text(yaml.safe_dump({'llm':{'model':'local/test'},**snippets[3]}))
 loaded=load_friday_py_config(path,env={'EXAMPLE_API_KEY':'SYNTHETIC-NONSECRET'})
 assert loaded.tools.mcp_provider.config.servers[0].env['EXAMPLE_API_KEY']=='SYNTHETIC-NONSECRET'
 try:load_friday_py_config(path,env={})
 except FridayChatConfigError:pass
 else:raise AssertionError('missing Chat environment value accepted')
for level in ['provider','config']:
 stanza={'enabled':False,'config':{'servers':[]}}
 if level=='provider':stanza['config_file']='missing.yaml'
 else:stanza['config']['config_file']='missing.yaml'
 for parse in [lambda:MCPToolProviderConfig.from_dict(stanza),lambda:FridayChatConfig.model_validate({'llm':{'model':'local/test'},'tools':{'providers':{'mcp':stanza}}})]:
  try:parse()
  except ValueError as e: assert 'reserved' in str(e)
  else:raise AssertionError('config_file accepted')
print('Chat env interpolation and config_file rejection OK')
example=re.findall(r'```python\n(.*?)\n```',(R/'packages/friday-mcp/README.md').read_text(),re.S)
assert len(example)==1
proc=subprocess.run([sys.executable,'-c',example[0]],cwd=R,capture_output=True,text=True,timeout=30)
assert proc.returncode==0,(proc.stdout,proc.stderr)
assert proc.stdout.strip()=="['mcp_demo_probe']",proc.stdout
print('friday-mcp README Python example OK')
async def probe(stanza,expect):
 p=RuntimeMCPProvider(MCPToolProviderConfig.from_dict(stanza),str(R)); names=None; outcome=None
 try:
  try:
   await p.start();registry=DefaultToolRegistry();await p.register_tools(registry);names=registry.list_names()
  except ToolProviderLoadError as e: outcome=str(e)
  life=tuple(x.outcome for x in p.operational_diagnostics.lifecycle)
  decisions=tuple(x.reason for x in p.operational_diagnostics.registration_decisions)
  if expect=='registered':assert names==['mcp_demo_probe'],(names,life,decisions)
  if expect=='continued':assert names==[],(names,life,decisions)
  if expect=='missing_include':assert outcome and 'missing_include' in outcome and 'connection_failed' in life,(outcome,life,decisions)
  if expect=='required_failure':assert outcome and 'connection_failed' in life,(outcome,life)
  print('lifecycle',expect,'names',names,'life',life,'decisions',decisions)
 finally:
  await p.stop()
  assert p.manager is None or not p.manager.connected_servers
async def lifecycle():
 strict=copy.deepcopy(snippets[0]['tools']['providers']['mcp']);category=copy.deepcopy(snippets[2]['tools']['providers']['mcp'])
 await probe(strict,'registered');await probe(category,'registered')
 strict['config']['servers'][0]['command']='/private/tmp/no-such-val018-peer'
 category['config']['servers'][0]['command']='/private/tmp/no-such-val018-peer'
 await probe(strict,'missing_include');await probe(category,'continued')
 category['config']['servers'][0]['required']=True
 await probe(category,'required_failure')
asyncio.run(lifecycle())
paths=['docs/guides/README.md','docs/guides/05-tools.md','docs/guides/10-configuration.md','docs/guides/11-advanced-topics.md','docs/guides/13-troubleshooting.md','docs/guides/17-mcp-client.md','packages/friday-mcp/README.md','packages/friday-runtime/README.md','packages/friday-chat/README.md']
broken=[];checked=0
for name in paths:
 content=(R/name).read_text()
 for url in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',content):
  target=url.split('#',1)[0].split(' ',1)[0]
  if not target or '://' in target or target.startswith('mailto:'):continue
  checked+=1
  dest=(R/target.lstrip('/') if target.startswith('/') else (R/name).parent/target)
  if not dest.exists():broken.append((name,url))
assert not broken,broken
print('relative links',checked,'OK')
