import os,pathlib,subprocess,time
root=pathlib.Path.cwd(); env=os.environ.copy(); env['UV_CACHE_DIR']='/private/tmp/friday-uv-cache'; env['LITELLM_LOCAL_MODEL_COST_MAP']='true'
checks=[
('runtime','uv run --no-sync pytest -q packages/friday-runtime/tests_runtime'),
('mcp','uv run --no-sync pytest -q packages/friday-mcp/tests_mcp'),
('focused','uv run --no-sync pytest -q packages/friday-runtime/tests_runtime/test_mcp_runtime_config.py packages/friday-chat/tests_chat/test_mcp_config_compatibility.py packages/friday-chat/tests_chat/test_mcp_turn_budget.py packages/friday-chat/tests_chat/test_mcp_memory.py'),
('integration','uv run --no-sync pytest -q tests/integration/test_mcp_runtime_lifecycle.py tests/integration/test_mcp_registry.py tests/integration/test_mcp_execution_provenance.py tests/integration/test_mcp_memory_ingestion.py'),
('chat','uv run --no-sync pytest -q packages/friday-chat/tests_chat'),
('cli','uv run --no-sync friday-chat --help'),
('docs','uv run --no-sync python scripts/check-documentation-lifecycle.py'),
('board','uv run --no-sync python scripts/friday-dev-board.py validate'),
('render','uv run --no-sync python scripts/friday-dev-board.py render --check'),
]
for name,cmd in checks:
 print('START',name,flush=True); t=time.monotonic(); p=subprocess.run(cmd.split(),cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=240)
 log=pathlib.Path('/private/tmp/val018_'+name+'.log');log.write_text(p.stdout)
 print('END',name,'exit',p.returncode,'seconds',round(time.monotonic()-t,1),'log',log,flush=True)
 print('\n'.join(p.stdout.splitlines()[-6:]),flush=True)
