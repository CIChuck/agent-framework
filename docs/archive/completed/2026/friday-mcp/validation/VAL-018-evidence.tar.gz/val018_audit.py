import hashlib, json, pathlib, subprocess, sys
root=pathlib.Path.cwd()
request=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-018-request.yaml').read_text())
manifest=json.loads((root/'docs/planning/active/friday-mcp/execution/REM-009-product-manifest.json').read_text())
prior=json.loads(pathlib.Path('/private/tmp/val017_start.json').read_text())
def git(*a): return subprocess.check_output(['git',*a],cwd=root)
def digest(b): return hashlib.sha256(b).hexdigest()
def files(p):
 if not p.exists(): return None
 if p.is_file(): return digest(p.read_bytes())
 return {str(f.relative_to(p)):digest(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file()}
product={p:digest(git('show',request['candidate_commit']+':'+p)) for p in manifest['product_paths']}
authority={a['path']:digest((root/a['path']).read_bytes()) for a in request['authority']}
unrelated={p:files(root/p) for p in manifest['unrelated']}
agg=set(git('diff','--name-only',request['base_commit']+'..'+request['candidate_commit']).decode().splitlines())
rem=set(git('diff','--name-only',request['remediation_base_commit']+'..'+request['candidate_commit']).decode().splitlines())
status=git('status','--short','--branch').decode()
head=git('rev-parse','HEAD').decode().strip()
out={'product':product,'authority':authority,'unrelated':unrelated,'aggregate_paths':sorted(agg),'remediation_paths':sorted(rem),'status':status,'head':head}
path=pathlib.Path('/private/tmp/val018_'+sys.argv[1]+'.json'); path.write_text(json.dumps(out,sort_keys=True,indent=2))
print('snapshot',path)
print('product',len(product),'matched',sum(product[p]==v for p,v in manifest['product_paths'].items()))
print('authority',len(authority),'matched',sum(authority[a['path']]==a['sha256'] for a in request['authority']))
print('unrelated match prior', {p: unrelated[p]==prior['unrelated'][p] for p in unrelated})
print('aggregate product scope',sorted(agg&set(product))==sorted(product),'product paths',len(agg&set(product)))
print('remediation product scope',sorted(rem&set(product)))
print('historical val017 unchanged', not git('diff','--name-only','e999152..'+request['candidate_commit'],'--','docs/planning/active/friday-mcp/validation/VAL-017-report.md','docs/planning/active/friday-mcp/validation/VAL-017-evidence.yaml','docs/planning/active/friday-mcp/validation/VAL-017-artifact-manifest.json'))
print('head',head,'status',repr(status))
