from pathlib import Path
import asyncio,contextlib,io,json,sys
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import build_runtime
from friday_chat.adapters import FrameworkTranscriptAdapter
from friday_chat.tools.mcp import MCPChatRegistry
from friday_chat.turns.models import ChatModelResponse,ToolCallRequest
from friday_transcript import SQLiteTranscriptStore,JSONLExporter,CSVExporter,MarkdownExporter
OUT=Path('/private/tmp/VAL-013-independent-20260928')
PEER=OUT/'scripts/peer.py'
ARG='VAL13_ARGUMENT_MARK';ENV='VAL13_ENV_MARK';HEADER='VAL13_HEADER_MARK';LAUNCH='VAL13_LAUNCH_MARK';ERROR='VAL13_ERROR_MARK';ATTACK='VAL13_ATTACK_MARK'
def configuration(directory,cap=256,iterations=3,peers=('alpha',),timeout=1):
 return FridayChatConfig.model_validate({'llm':{'model':'fake/independent'},'transcript':{'capture_raw_prompts':True},'tools':{'loop':{'max_iterations':iterations},'context':{'max_budget_ratio':1.0},'providers':{'native_extra':{'shape':'preserved'},'mcp':{'enabled':True,'mode':'all','config':{'servers':[{'name':tag,'command':sys.executable,'args':[str(PEER),tag,str(directory/f'audit-{tag}.jsonl'),LAUNCH,'Authorization: '+HEADER],'env':{'VAL13_ENV':ENV},'required':True,'retry_attempts':0,'timeout_seconds':timeout} for tag in peers],'limits':{'max_result_bytes':cap,'min_memory_retrieval_tokens':50,'reserved_tool_result_tokens':40}}}}}})
async def setup(directory,cap=256,iterations=3,peers=('alpha',),production=True,timeout=1):
 directory.mkdir(parents=True,exist_ok=True)
 cfg=configuration(directory,cap,iterations,peers,timeout)
 runtime=build_runtime(cfg); bridge=MCPChatRegistry(runtime.tools,cfg.tools.mcp_provider,str(directory));runtime.tools=runtime.mcp_tools=bridge
 store=SQLiteTranscriptStore(directory/'transcript.sqlite')
 if production:runtime.transcript=FrameworkTranscriptAdapter(store,cfg,'independent')
 await runtime.start_mcp_tools()
 runtime.tool_selection.inject_manual(tuple(bridge.tool_metadata)+('echo',))
 return runtime,bridge,store
async def exports(store,session,directory):
 outputs={}
 for label,exporter,options in [('jsonl',JSONLExporter(store),{}),('jsonl-off',JSONLExporter(store),{'include_metadata':False}),('markdown',MarkdownExporter(store),{}),('markdown-on',MarkdownExporter(store),{'include_tool_calls':True}),('csv',CSVExporter(store),{})]:
  file=io.StringIO();await exporter.export_session(session,file,**options);outputs[label]=file.getvalue()
 await CSVExporter(store).export_all_sessions(directory/'all-sessions')
 for file in sorted((directory/'all-sessions').glob('*.csv')):outputs['all-'+file.name]=file.read_text()
 return outputs
class Model:
 def __init__(self, responses=None):self.responses=responses or [];self.calls=[];self.current=None
 async def complete(self,messages,*,tools=()):
  self.current=messages; self.calls.append(json.loads(json.dumps(messages)))
  return self.responses.pop(0) if self.responses else ChatModelResponse.from_text('done')
 async def stream_complete(self,messages,*,tools=()):
  self.current=messages;self.calls.append(json.loads(json.dumps(messages)));yield 'native ';yield 'stream'
async def settle(bridges,children,initial):
 errors=[]
 for b in bridges:
  try:await asyncio.wait_for(b.stop(),15)
  except BaseException as e:errors.append(type(e).__name__)
 async def drain(s):
  if s:
   while await s.read(4096):pass
 for child in children:
  if child.returncode is None:
   with contextlib.suppress(ProcessLookupError):child.kill()
  await asyncio.wait_for(asyncio.gather(drain(child.stdout),drain(child.stderr)),3)
  await asyncio.wait_for(child.wait(),3)
 pending=[t for t in asyncio.all_tasks()-initial if t is not asyncio.current_task() and not t.done()]
 for t in pending:t.cancel()
 if pending:await asyncio.wait_for(asyncio.gather(*pending,return_exceptions=True),3)
 return errors
async def public_clean(bridge,children):
 await asyncio.wait_for(bridge.stop(),15)
 facts={'metadata_empty':not bridge.tool_metadata,'owned_names_empty':not bridge.provider.owned_tool_names,'connections_empty':not bridge.provider.manager.connected_servers,'children_reaped':all(p.returncode is not None for p in children),'pipes_eof':all(p.stdout.at_eof() and p.stderr.at_eof() for p in children)}
 assert all(facts.values()),facts
 return facts
