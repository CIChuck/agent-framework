import asyncio,json,sys
from pathlib import Path
from friday_chat.tools.loop import ToolLoop
from friday_chat.tools.registry import FakeToolRegistry
async def main():
 facts=[]
 for shape in ['flat','function']:
  for name in [{'bad':1},['bad']]:
   for present in [False,True]:
    for following in [False,True]:
     raw={'name':name,'arguments':{}} if shape=='flat' else {'function':{'name':name,'arguments':'{}'}}
     if present:raw['id']='malformed-present'
     calls=[raw]
     if following:calls.append({'name':'echo','arguments':{'text':'valid-after-malformed'},'id':'legacy/native-id'})
     registry=FakeToolRegistry();error=None;result=None
     try:result=await ToolLoop(registry,max_iterations=2).run([{'tool_calls':calls}],registry.list_tools())
     except Exception as e:error=type(e).__name__+': '+str(e)
     facts.append({'shape':shape,'name_type':type(name).__name__,'id_present':present,'valid_following':following,'exception':error,'records':None if result is None else [{'id':r.call_id,'name':r.name,'result':r.result} for r in result.tool_calls]})
 Path('/private/tmp/VAL-013-independent-20260928/native-controls-'+sys.argv[1]+'.json').write_text(json.dumps(facts,indent=2)+'\n')
 print(json.dumps(facts,indent=2))
asyncio.run(main())
