import ast,datetime,hashlib,importlib.metadata as md,json,pathlib,subprocess,sys,zipfile
S=pathlib.Path('/private/tmp/VAL-013-independent-20260928')
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
def run(args):
 p=subprocess.run(args,cwd=R,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 return {'command':args,'exit':p.returncode,'output':p.stdout}
versions={}
for name in ['pytest','pytest-asyncio','mypy','ruff','pydantic','pydantic-settings','hatchling','build','litellm','numpy']:
 try:versions[name]=md.version(name)
 except md.PackageNotFoundError:versions[name]=None
data={'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'executable':sys.executable,'system':run(['uname','-a']),'uv':run(['uv','--version']),'package_versions':versions,'wheel_build_tools':{},'branch':run(['git','branch','--show-current']),'head':run(['git','rev-parse','HEAD']),'status':run(['git','status','--short','--untracked-files=all'])}
for p in sorted((S/'wheels').glob('*.whl')):
 with zipfile.ZipFile(p) as z:
  n=next(n for n in z.namelist() if n.endswith('.dist-info/WHEEL'))
  data['wheel_build_tools'][p.name]=z.read(n).decode()
(S/'probes/environment.json').write_text(json.dumps(data,indent=2)+'\n')
req=json.loads((S/'input/VAL-013-frozen-inputs.json').read_text())
lines=[]
for path in req.get('tracked_product_bytes',{}):
 if path not in ['packages/friday-core/tests_core/test_mcp_contracts.py','packages/friday-mcp/tests_mcp/client/test_execution.py','packages/friday-chat/tests_chat/test_mcp_execution_security.py','packages/friday-chat/tests_chat/test_mcp_execution_transcript.py','packages/friday-chat/tests_chat/test_mcp_chat_bridge.py','packages/friday-transcript/tests/test_mcp_provenance.py','tests/integration/test_mcp_execution_provenance.py','packages/friday-chat/tests_chat/fixtures/mcp_execution_peer.py']:continue
 text=(R/path).read_text();tree=ast.parse(text);lines.append('\nFILE '+path+' SHA256 '+hashlib.sha256(text.encode()).hexdigest())
 for node in ast.walk(tree):
  if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
   lines.append(str(node.lineno)+' '+node.name+' decorators='+','.join(ast.unparse(d) for d in node.decorator_list))
  elif isinstance(node,ast.Assert):lines.append(str(node.lineno)+' ASSERT '+ast.unparse(node.test))
  elif isinstance(node,ast.With):
   for i in node.items:
    if 'raises' in ast.unparse(i.context_expr):lines.append(str(node.lineno)+' EXPECT '+ast.unparse(i.context_expr))
(S/'probes/candidate-test-review.txt').write_text('\n'.join(lines)+'\n')
print({'python':sys.version.split()[0],'versions':versions,'wheel_build_tools':data['wheel_build_tools'],'test_index_lines':len(lines)})
