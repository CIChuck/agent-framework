import pathlib,json,hashlib,tarfile,subprocess,yaml
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');S=pathlib.Path('/private/tmp/VAL-013-independent-20260928');request=yaml.safe_load((S/'input/VAL-013-request.yaml').read_text());f=json.loads((S/'input/VAL-013-frozen-inputs.json').read_text());facts={'archive_integrity':{},'scope':{},'unrelated_source_baselines':{}}
for label,group in [('VAL-011','validation'),('VAL-012','validation'),('REM-006','execution'),('REM-007','execution')]:
 d=R/'docs/planning/active/friday-mcp'/group;m=json.loads((d/(label+'-artifact-manifest.json')).read_text());tar=tarfile.open(d/(label+'-evidence.tar.gz'));entries=m.get('entries') or [{'member':k,**v} for k,v in m['members'].items()];errors=[]
 for e in entries:
  try:b=tar.extractfile(e['member']).read()
  except Exception as exc:errors.append({'member':e['member'],'error':str(exc)});continue
  if len(b)!=e['bytes'] or hashlib.sha256(b).hexdigest()!=e['sha256']:errors.append({'member':e['member'],'error':'bytes/hash'})
 facts['archive_integrity'][label]={'members_checked':len(entries),'archive_members':len(tar.getnames()),'errors':errors}
 if label=='REM-006':
  old=tar.extractfile('REM-006-implementation-report.md').read();git=subprocess.check_output(['git','show','f24ed20f82eac0cbce17e4b86615497cc9993921:docs/planning/active/friday-mcp/execution/REM-006-implementation-report.md'],cwd=R);current=(R/'docs/planning/active/friday-mcp/execution/REM-006-implementation-report.md').read_bytes();facts['original_rem006_report']={'archived_sha256':hashlib.sha256(old).hexdigest(),'git_f24_matches':old==git,'current_starts_with_original':current.startswith(old)}
for label,base,key in [('aggregate',f['base_commit'],'aggregate'),('remediation',f['remediation_base_commit'],'allowed_remediation_paths'),('followup',f['followup_base_commit'],'allowed_followup_paths')]:
 names=subprocess.check_output(['git','diff','--name-only',base+'..'+f['candidate_commit']],cwd=R,text=True).splitlines();allowed=(request['allowed_product_paths']+request['allowed_dependency_paths']+request['allowed_test_paths']+[request['allowed_implementation_report'],request['allowed_remediation_report']]) if key=='aggregate' else request[key]
 product=[p for p in names if p.startswith(('packages/','tests/')) or p in ['pyproject.toml','uv.lock'] or 'implementation-report.md' in p];unallowed=[p for p in product if p not in allowed];facts['scope'][label]={'implementation_paths':product,'implementation_count':len(product),'process_paths':[p for p in names if p not in product],'unallowed':unallowed}
 for section,prefixes in [('sources',['packages/']),('tests',['tests/'])]:
  args=['git','diff',base+'..'+f['candidate_commit'],'--']
  if section=='sources':args+=request['allowed_product_paths']+request['allowed_dependency_paths']
  else:args+=request['allowed_test_paths']
  (S/'input'/f'{label}-{section}.diff').write_bytes(subprocess.check_output(args,cwd=R))
for p in ['packages/friday-chat/tests_chat/test_reorganization_terminal.py','packages/friday-chat/tests_chat/test_llm_adapter_migration.py','tests/integration/test_development_board.py','tests/integration/test_documentation_lifecycle.py']:
 a=subprocess.check_output(['git','show',f['base_commit']+':'+p],cwd=R);b=(R/p).read_bytes();facts['unrelated_source_baselines'][p]={'unchanged':a==b,'base_sha256':hashlib.sha256(a).hexdigest(),'candidate_sha256':hashlib.sha256(b).hexdigest()}
(S/'probes/integrity.json').write_text(json.dumps(facts,indent=2)+'\n');print(json.dumps(facts,indent=2));assert not any(z['errors'] for z in facts['archive_integrity'].values());assert not any(z['unallowed'] for z in facts['scope'].values());assert all(z['unchanged'] for z in facts['unrelated_source_baselines'].values());assert facts['original_rem006_report']['git_f24_matches'] and facts['original_rem006_report']['current_starts_with_original']
