import gzip,hashlib,io,json,pathlib,re,shutil,subprocess,tarfile
S=pathlib.Path('/private/tmp/VAL-013-independent-20260928')
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
def record(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def write(name,data):(S/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
for p in sorted((S/'runtime').rglob('audit-*.jsonl')):
 dst=S/'audits'/p.relative_to(S/'runtime');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
for p in ['AGENTS.md','packages/friday-chat/tests_chat/test_reorganization_terminal.py','packages/friday-chat/tests_chat/test_llm_adapter_migration.py','tests/integration/test_development_board.py','tests/integration/test_documentation_lifecycle.py','pyproject.toml']:
 dst=S/'baselines'/p;dst.parent.mkdir(parents=True,exist_ok=True)
 dst.write_bytes(subprocess.check_output(['git','show','a609f948fe2d869ac29d0cce29d22d9334cd7d08:'+p],cwd=R))
report=(S/'report.md').read_bytes();assert report.endswith(b'\n') and not report.endswith(b'\n\n')
assert all(line==line.rstrip() for line in report.decode().splitlines())
links=re.findall(r'VAL-013-evidence\.tar\.gz#([^\s\)]+)',report.decode())
excludes={'runtime','VAL-013-evidence.tar.gz','artifact-manifest.json','delivery.json','archive-verification.json'}
files=[p for p in sorted(S.rglob('*')) if p.is_file() and p.relative_to(S).parts[0] not in excludes]
assert all(not p.is_symlink() for p in files)
assert all('__pycache__' not in p.parts and p.suffix not in {'.db','.sqlite','.sqlite3','.pyc'} for p in files)
members={p.relative_to(S).as_posix():record(p) for p in files}
assert all(member in members for member in links),(set(links)-set(members))
tables=[];current=[]
for line in report.decode().splitlines()+['']:
 if line.startswith('|'):current.append(line)
 elif current:
  widths=[len(row.split('|')) for row in current];assert len(set(widths))==1,widths
  assert len(current)>2 and re.fullmatch(r'\|(?:\s*:?-+:?\s*\|)+',current[1]);tables.append({'rows':len(current)-2,'columns':widths[0]-2});current=[]
manifest={'validation':'VAL-013','candidate_commit':'cca86b51105666d12c2e7ed571f8f9a05d2085f9','archive':'VAL-013-evidence.tar.gz','member_count':len(members),'members':members,'report':record(S/'report.md'),'manifest_note':'External manifest covers every archive member; manifest/delivery/verification remain outside archive to avoid recursive hashes. Their hashes and bytes are recorded in delivery/archive-verification.'}
write('artifact-manifest.json',manifest)
with (S/'VAL-013-evidence.tar.gz').open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as t:
   for p in files:
    b=p.read_bytes();n=p.relative_to(S).as_posix();info=tarfile.TarInfo(n);info.size=len(b);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o755 if p.stat().st_mode&0o111 else 0o644;t.addfile(info,io.BytesIO(b))
delivery={'validation':'VAL-013','reviewer':'/root/mcp_ws05_val013','fresh_context':True,'read_only':True,'branch':'feature/friday-mcp-ws05-execution','head':'ee8aa0367c92a1dfb79ea89737dfb8eb6311509e','candidate_commit':'cca86b51105666d12c2e7ed571f8f9a05d2085f9','request_preparation_commit':'f5510ed599cae1342f33ce8bc0ca977c2c1b0c06','delta_outcome':'VERIFIED','complete_remediation_delta_outcome':'VERIFIED','work_unit_aggregate_outcome':'VERIFIED','overall_outcome':'VERIFIED','acceptance':False,'delivery_authorized':False,'finding_closures':['VAL-012-F-001','VAL-011-F-001','VAL-011-F-002'],'required_commands':19,'criteria':20,'tasks':8,'independent_cases':{'main':35,'supplement':10,'new_matrix':24},'artifacts':{name:record(S/name) for name in ['report.md','artifact-manifest.json','VAL-013-evidence.tar.gz']},'paths':{name:str(S/name) for name in ['report.md','artifact-manifest.json','VAL-013-evidence.tar.gz','delivery.json','archive-verification.json']},'post_archive_verification':'archive-verification.json records delivery.json hash/size and all member/locator/whitespace checks.'}
write('delivery.json',delivery)
errors=[]
with tarfile.open(S/'VAL-013-evidence.tar.gz','r:gz') as t:
 names=t.getnames();assert len(names)==len(set(names));assert sorted(names)==sorted(members)
 for n in names:
  b=t.extractfile(n).read();actual={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
  if actual!=members[n]:errors.append(n)
 archived_report=t.extractfile('report.md').read();assert archived_report==report
assert not errors
verification={'validation':'VAL-013','verified':True,'errors':errors,'member_count':len(members),'verified_member_hashes_and_sizes':len(members),'all_members_manifested':True,'duplicate_members':False,'report_byte_exact':True,'portable_locator_occurrences':len(links),'portable_locator_unique':len(set(links)),'all_locators_resolve':True,'report_eof_exactly_one_newline':True,'report_trailing_whitespace':False,'contiguous_markdown_tables':tables,'runtime_db_cache_venv_state_excluded':True,'real_secrets_used':False,'owned_stdio_cleanup_proof':'Public child returncode/pipes-EOF assertions and fixture teardown in independently executed probes, including failed assertions. Host ps inventory is sandbox-denied and is not claimed.','deterministic_archive':'gzip mtime0, sorted paths, normalized tar timestamps/owners, preserved executable bit','artifacts':{name:record(S/name) for name in ['report.md','artifact-manifest.json','VAL-013-evidence.tar.gz','delivery.json']},'freeze_start':{'comparisons':2064,'failures':0},'freeze_closeout':{'comparisons':2064,'failures':0}}
write('archive-verification.json',verification)
print(json.dumps({'verified':True,'member_count':len(members),'locators':len(links),'artifacts':verification['artifacts'],'archive_verification':record(S/'archive-verification.json')},indent=2))
