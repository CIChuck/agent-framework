import pathlib,json,subprocess,tarfile,io,shutil
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');S=pathlib.Path('/private/tmp/VAL-013-independent-20260928');x=json.loads((S/'input/VAL-013-frozen-inputs.json').read_text());(S/'runtime/tmp').mkdir(parents=True,exist_ok=True)
for p in (S/'scripts/prior').glob('*.py'):
 t=p.read_text().replace('VAL-012-independent-20260928','VAL-013-independent-20260928').replace('VAL12','VAL13');(S/'scripts'/p.name).write_text(t)
for label,rev in [('candidate',x['candidate_commit']),('original-base',x['base_commit']),('remediation-base',x['remediation_base_commit']),('followup-base',x['followup_base_commit'])]:
 root=S/'runtime'/label;root.mkdir(exist_ok=True);b=subprocess.check_output(['git','archive',rev],cwd=R);t=tarfile.open(fileobj=io.BytesIO(b))
 for m in t:
  if not m.isfile() or m.name.endswith(('.db','.sqlite','.sqlite3','.bin','.pickle','.DS_Store')) or '/vector_bak/' in m.name:continue
  if not (m.name.startswith(('packages/','tests/','scripts/','docs/')) or m.name in ['pyproject.toml','uv.lock','conftest.py']):continue
  dst=root/m.name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(t.extractfile(m).read())
 paths=[str(d) for d in sorted((root/'packages').glob('*/src'))];(S/(label+'-imports.json')).write_text(json.dumps({'revision':rev,'root':str(root),'pythonpath':paths},indent=2)+'\n')
 if label=='candidate':
  for p in sorted({*x['tracked_product_bytes'].keys()}):
   if p.endswith(('.py','.toml')) or p=='uv.lock':
    dst=S/'sources'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((R/p).read_bytes())
print('Prepared four source-import trees; scripts explicitly adapted from published VAL-012 evidence, no verdict reused.')
