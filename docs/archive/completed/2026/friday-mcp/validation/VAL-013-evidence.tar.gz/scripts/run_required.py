import pathlib,os,subprocess,json,time,yaml,sys
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');S=pathlib.Path('/private/tmp/VAL-013-independent-20260928');x=yaml.safe_load((S/'input/VAL-013-request.yaml').read_text());env=os.environ.copy();env.update(PYTEST_ADDOPTS='-p no:cacheprovider',MYPY_CACHE_DIR=str(S/'runtime/mypy'),RUFF_CACHE_DIR=str(S/'runtime/ruff'),PYTHONDONTWRITEBYTECODE='1');summary=[]
for i,c in enumerate(x['required_checks'],1):
 p=S/'logs'/f'command-{i:02d}.log';start=time.time()
 with p.open('w') as f:
  f.write(f'COMMAND {c}\nCWD {R}\nADDITIONAL_ENV '+json.dumps({k:env[k] for k in ['PYTEST_ADDOPTS','MYPY_CACHE_DIR','RUFF_CACHE_DIR','PYTHONDONTWRITEBYTECODE']})+'\n');f.flush()
  try: q=subprocess.run(c,shell=True,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200);code=q.returncode
  except subprocess.TimeoutExpired: code=124;f.write('\nHARNESS TIMEOUT\n')
  elapsed=time.time()-start;f.write(f'\nEXIT {code}\nELAPSED_SECONDS {elapsed:.3f}\n')
 summary.append(dict(id=i,command=c,exit=code,elapsed_seconds=round(elapsed,3),log=p.name));(S/'probes/required-commands.json').write_text(json.dumps(summary,indent=2)+'\n');print(f'{i:02d} exit={code} time={elapsed:.1f}',flush=True)
