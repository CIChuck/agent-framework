"""Fresh VAL-013 matrix supplements independently rerun published reproductions."""
import asyncio,json,copy
import pytest
from test_independent import owned
from probe_common import OUT,public_clean
from friday_chat.tools.loop import ToolLoop
from friday_chat.tools.registry import FakeToolRegistry
RESULTS=[]
@pytest.mark.asyncio
@pytest.mark.parametrize('mixed',[False,True])
@pytest.mark.parametrize('form',['flat','function'])
@pytest.mark.parametrize('name',[{'bad':1},['bad']])
@pytest.mark.parametrize('present',[False,True])
async def test_invalid_name_then_valid_native_and_mcp(owned,mixed,form,name,present):
 create,children,directory=owned
 runtime,bridge,store=await create() if mixed else (None,None,None)
 registry=bridge if mixed else FakeToolRegistry()
 raw={'name':name,'arguments':{}} if form=='flat' else {'function':{'name':name,'arguments':'{}'}}
 if present:raw['id']='present-malformed'
 calls=[raw,{'name':'echo','arguments':{'text':'after-invalid'},'id':'legacy/native'}]
 if mixed:calls.append({'name':'mcp_alpha_probe_read','arguments':{'sequence':901},'id':'legacy/native'})
 messages=[{'role':'assistant','tool_calls':calls}];before=copy.deepcopy(messages)
 result=await ToolLoop(registry,max_iterations=2).run(messages,registry.list_tools())
 assert messages==before and not result.circuit_breaker_open
 assert len(result.tool_calls)==(2 if mixed else 1)
 native=result.tool_calls[0];assert native.call_id=='legacy/native' and native.name=='echo' and native.result=='after-invalid'
 assert native.arguments=={'text':'after-invalid'} and native.mcp_provenance is None
 if mixed:
  mcp=result.tool_calls[1];assert mcp.call_id!='legacy/native' and mcp.call_id==mcp.mcp_provenance.call_id
  assert mcp.arguments=={} and mcp.mcp_provenance.status=='succeeded'
  requests=[c for m in result.messages for c in m.get('tool_calls',[]) if isinstance(c.get('name'),str)]
  outputs=[m for m in result.messages if m.get('role')=='tool']
  assert [c['id'] for c in requests]==[r.call_id for r in result.tool_calls]==[m['tool_call_id'] for m in outputs]
  audit=[json.loads(l) for l in (directory/'audit-alpha.jsonl').read_text().splitlines()];assert sum(a['event']=='call' for a in audit)==1
 clean=await public_clean(bridge,children) if mixed else None
 RESULTS.append({'mixed':mixed,'form':form,'type':type(name).__name__,'id_present':present,'native_exact':True,'invalid_never_executed':True,'mcp_coherent':mixed,'public_cleanup':clean});(OUT/'probes/added-matrix.json').write_text(json.dumps(RESULTS,indent=2)+'\n')
@pytest.mark.asyncio
@pytest.mark.parametrize('form',['flat','function'])
@pytest.mark.parametrize('name',[{'bad':1},['bad']])
@pytest.mark.parametrize('present',[False,True])
async def test_existing_invalid_failure_threshold(form,name,present):
 registry=FakeToolRegistry();raw={'name':name} if form=='flat' else {'function':{'name':name}}
 if present:raw['id']='malformed'
 result=await ToolLoop(registry,max_iterations=1).run([{'tool_calls':[raw,{'name':'echo','arguments':{'text':'no'},'id':'native'}]}],registry.list_tools())
 assert result.circuit_breaker_open and not result.tool_calls and not registry.calls
