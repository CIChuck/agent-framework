import pathlib,json,hashlib,subprocess,sys
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');S=pathlib.Path('/private/tmp/VAL-013-independent-20260928');x=json.loads((S/'input/VAL-013-frozen-inputs.json').read_text());checks=[]
def add(k,p,expected,git=False):
 b=(R/p).read_bytes();h=hashlib.sha256(b).hexdigest();checks.append(dict(kind=k,path=p,expected=expected,actual=h,pass_=h==expected))
 if git:
  gb=subprocess.check_output(['git','show',x['candidate_commit']+':'+p],cwd=R);checks.append(dict(kind=k+'-git',path=p,pass_=hashlib.sha256(gb).hexdigest()==expected))
add('request',x['request']['path'],x['request']['sha256'])
for k in ['authority','candidate_reports','historical_evidence','builder_evidence']:
 for e in x[k]: add(k,e['path'],e['sha256'],k in ['authority','candidate_reports'])
for p,h in x['tracked_product_bytes'].items():add('product',p,h,True)
for p,e in x['preserved_unrelated'].items():
 path=R/p
 if e['state']=='absent': checks.append(dict(kind='unrelated',path=p,pass_=not path.exists()));continue
 files=sorted([path] if path.is_file() or path.is_symlink() else [f for f in path.rglob('*') if f.is_file() or f.is_symlink()]);h=hashlib.sha256()
 for f in files:
  rel=f.relative_to(R).as_posix();h.update(rel.encode()+b'\0');h.update(('symlink:'+str(f.readlink())).encode() if f.is_symlink() else f.read_bytes());h.update(b'\0')
 checks.append(dict(kind='unrelated',path=p,files=len(files),actual=h.hexdigest(),expected=e['sha256'],pass_=len(files)==e['files'] and h.hexdigest()==e['sha256']))
out={'phase':sys.argv[1],'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'checks':checks,'count':len(checks),'failed':[e for e in checks if not e['pass_']]};(S/'probes'/('freeze-'+sys.argv[1]+'.json')).write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='checks'});assert not out['failed']
