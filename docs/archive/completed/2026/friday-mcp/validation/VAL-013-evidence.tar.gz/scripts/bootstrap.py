import pathlib,json,hashlib,subprocess,shutil,os
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); S=pathlib.Path('/private/tmp/VAL-013-independent-20260928'); S.mkdir(exist_ok=True)
x=json.loads((R/'docs/planning/active/friday-mcp/validation/VAL-013-frozen-inputs.json').read_text())
print('request shape',x['request']);print('authority shape',x['authority'][0] if isinstance(x['authority'],list) else next(iter(x['authority'].items())))
for folder in ['input','sources','logs','scripts','probes','baselines','packaging']: (S/folder).mkdir(exist_ok=True)
for p in ['docs/planning/active/friday-mcp/validation/VAL-013-request.yaml','docs/planning/active/friday-mcp/validation/VAL-013-frozen-inputs.json']: shutil.copyfile(R/p,S/'input'/pathlib.Path(p).name)
for k in ['authority','candidate_reports','historical_evidence','builder_evidence']:
 for entry in x[k] if isinstance(x[k],list) else [{'path':p,'sha256':h} for p,h in x[k].items()]:
  p=entry['path']; dest=S/'input'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/p,dest)
for label,base in [('aggregate',x['base_commit']),('remediation',x['remediation_base_commit']),('followup',x['followup_base_commit'])]:
 d=subprocess.check_output(['git','diff',base+'..'+x['candidate_commit']],cwd=R);(S/'input'/f'{label}.diff').write_bytes(d)
 (S/'input'/f'{label}-names.txt').write_bytes(subprocess.check_output(['git','diff','--name-only',base+'..'+x['candidate_commit']],cwd=R))
print('scratch',S)
