import os,pathlib,json,subprocess,time
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');S=pathlib.Path('/private/tmp/VAL-013-independent-20260928');records=[]
def run(label,cmd,base='candidate'):
 imp=json.loads((S/(base+'-imports.json')).read_text());env=os.environ.copy();extras={'PYTHONPATH':str(S/'scripts')+':'+':'.join(imp['pythonpath']),'LITELLM_LOCAL_MODEL_COST_MAP':'true','PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(S/'runtime/tmp')};env.update(extras)
 with (S/'logs'/('extra-'+label+'.log')).open('w') as f:
  q=subprocess.run(cmd,cwd=imp['root'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 rec={'label':label,'argv':cmd,'cwd':imp['root'],'environment':extras,'exit':q.returncode};records.append(rec);(S/'probes/extra-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,q.returncode,flush=True)
py=str(R/'.venv/bin/python')
run('added',[py,'-m','pytest',str(S/'scripts/test_val013_added.py'),'-q','-p','no:cacheprovider','--basetemp',str(S/'runtime/added')])
run('supplement',[py,'-m','pytest',str(S/'scripts/test_supplement.py'),'-q','-p','no:cacheprovider','--basetemp',str(S/'runtime/supplement')])
for base in ['candidate','original-base','remediation-base','followup-base']:
 run('findings-'+base,[py,str(S/'scripts/findings_repro.py'),base],base)
 run('native-'+base,[py,str(S/'scripts/native_controls.py'),base],base)
