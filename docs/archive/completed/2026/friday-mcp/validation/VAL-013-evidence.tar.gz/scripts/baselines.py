from pathlib import Path
import subprocess,os,json,datetime,concurrent.futures
ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework'); OUT=Path('/private/tmp/VAL-013-independent-20260928'); BASE=OUT/'runtime/original-base'
catalog=subprocess.check_output(['git','ls-tree','-r','--name-only','a609f948fe2d869ac29d0cce29d22d9334cd7d08'],cwd=ROOT)
(OUT/'baseline-git-catalog.txt').write_bytes(catalog)
bin=OUT/'scripts/catalog-bin';bin.mkdir(exist_ok=True)
shim=bin/'git'
shim.write_text('#!/usr/bin/env python3\nimport sys,pathlib,os\nif sys.argv[1:]==["ls-files","--cached","--others","--exclude-standard"]:\n sys.stdout.write(pathlib.Path("'+str(OUT/'baseline-git-catalog.txt')+'").read_text())\nelse:\n os.execv("/usr/bin/git",["/usr/bin/git",*sys.argv[1:]])\n');shim.chmod(0o755)
env=os.environ.copy()
env.update({'LITELLM_LOCAL_MODEL_COST_MAP':'true','UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_NO_SYNC':'true','UV_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1','PYTEST_ADDOPTS':'-p no:cacheprovider','MYPY_CACHE_DIR':str(OUT/'runtime/baseline-mypy-cache'),'TMPDIR':str(OUT/'runtime/tmp'),'UV_PROJECT_ENVIRONMENT':str(ROOT/'.venv'),'PYTHONPATH':':'.join(json.loads((OUT/'original-base-imports.json').read_text())['pythonpath']),'PATH':str(bin)+':'+os.environ['PATH']})
commands={
 'imports':['uv','run','python','-c','import friday_chat,friday_core,friday_transcript;print(friday_chat.__file__);print(friday_core.__file__);print(friday_transcript.__file__)'],
 'chat':['uv','run','pytest','packages/friday-chat/tests_chat','-q','--tb=short'],
 'integration':['uv','run','pytest','tests/integration','-q','--tb=short'],
 'mypy':['uv','run','mypy','packages/friday-core','packages/friday-mcp','packages/friday-chat','packages/friday-transcript','packages/friday-agent']}
def run(name):
 record={'command':commands[name],'cwd':str(BASE),'environment':{k:env[k] for k in ['LITELLM_LOCAL_MODEL_COST_MAP','UV_CACHE_DIR','UV_NO_SYNC','UV_OFFLINE','PYTHONDONTWRITEBYTECODE','PYTEST_ADDOPTS','MYPY_CACHE_DIR','TMPDIR','UV_PROJECT_ENVIRONMENT','PYTHONPATH','PATH']},'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (OUT/f'logs/baseline-{name}.log').open('wb') as log:p=subprocess.run(commands[name],cwd=BASE,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit=p.returncode,end=datetime.datetime.now(datetime.timezone.utc).isoformat());(OUT/f'logs/baseline-{name}.json').write_text(json.dumps(record,indent=2)+'\n');print(name,p.returncode,flush=True)
run('imports')
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,['chat','integration','mypy']))
