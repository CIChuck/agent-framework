import asyncio
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml
from friday_agent import DefaultToolRegistry
from friday_chat.config import FridayChatConfig, FridayChatConfigError, load_friday_py_config
from friday_runtime.config import MCPToolProviderConfig, RuntimeConfig, ToolsConfig
from friday_runtime.mcp_loading import RuntimeMCPProvider
from friday_runtime.tool_loading import ToolProviderLoadError

ROOT = Path.cwd()
GUIDE = (ROOT / 'docs/guides/17-mcp-client.md').read_text()
SNIPPETS = [yaml.safe_load(s) for s in re.findall(r'```yaml\n(.*?)\n```', GUIDE, re.S)]
assert len(SNIPPETS) == 3, len(SNIPPETS)
for i, data in enumerate(SNIPPETS):
    mcp = data['tools']['providers']['mcp']
    p = MCPToolProviderConfig.from_dict(mcp)
    runtime = RuntimeConfig(workspace_root=str(ROOT), runtime_data_root='/private/tmp/val017_runtime', install_root=str(ROOT), tools_config=ToolsConfig.from_dict(data['tools']))
    chat = FridayChatConfig.model_validate({'llm': {'model': 'local/test'}, **data})
    assert runtime.tools.providers.mcp.enabled == chat.tools.mcp_provider.enabled == p.enabled
    print('guide snippet', i + 1, 'runtime/chat', p.enabled, len(p.config.servers))

template_stanzas = []
for relative in ('packages/friday-chat/config.example.yaml', 'packages/friday-chat/src/friday_chat/config_templates/config.example.yaml'):
    template = yaml.safe_load((ROOT / relative).read_text())
    stanza = template['tools']['providers']['mcp']
    p = MCPToolProviderConfig.from_dict(stanza)
    assert not p.enabled and not p.config.servers
    template_stanzas.append(stanza)
    print('template', relative, 'disabled')
assert template_stanzas[0] == template_stanzas[1]

with tempfile.TemporaryDirectory(prefix='val017_', dir='/private/tmp') as tmp:
    config_path = Path(tmp) / 'chat.yaml'
    config_path.write_text(yaml.safe_dump({'llm': {'model': 'local/test'}, **SNIPPETS[2]}))
    chat = load_friday_py_config(config_path, env={'EXAMPLE_API_KEY': 'SYNTHETIC-VALUE'})
    assert chat.tools.mcp_provider.config.servers[0].env['EXAMPLE_API_KEY'] == 'SYNTHETIC-VALUE'
    try:
        load_friday_py_config(config_path, env={})
    except FridayChatConfigError as error:
        assert 'EXAMPLE_API_KEY' in str(error)
    else:
        raise AssertionError('missing env was accepted')
    print('Chat env interpolation and missing env rejection')
    for field in ('outer', 'inner'):
        bad = {'enabled': False, 'config': {'servers': []}}
        if field == 'outer': bad['config_file'] = 'x'
        else: bad['config']['config_file'] = 'x'
        try:
            MCPToolProviderConfig.from_dict(bad)
        except ValueError as error:
            assert 'reserved' in str(error)
        else:
            raise AssertionError('config_file accepted: ' + field)
        try:
            FridayChatConfig.model_validate({'llm': {'model': 'local/test'}, 'tools': {'providers': {'mcp': bad}}})
        except ValueError as error:
            assert 'reserved' in str(error)
        else:
            raise AssertionError('Chat config_file accepted: ' + field)
    print('outer/inner config_file rejected by Runtime and Chat')

readme = (ROOT / 'packages/friday-mcp/README.md').read_text()
example = re.findall(r'```python\n(.*?)\n```', readme, re.S)
assert len(example) == 1
result = subprocess.run([sys.executable, '-c', example[0]], cwd=ROOT, text=True, capture_output=True, timeout=20)
assert result.returncode == 0, result.stderr
assert "['mcp_demo_probe']" in result.stdout, result.stdout
print('README Python example:', result.stdout.strip())

async def lifecycle():
    snippet = SNIPPETS[0]['tools']['providers']['mcp']
    provider = RuntimeMCPProvider(MCPToolProviderConfig.from_dict(snippet), str(ROOT))
    try:
        await provider.start()
        registry = DefaultToolRegistry()
        await provider.register_tools(registry)
        assert 'mcp_demo_probe' in registry.list_names()
        assert provider.operational_diagnostics.lifecycle[0].outcome == 'connected'
        print('selected stdio registration:', registry.list_names())
    finally:
        await provider.stop()
    assert not provider.manager or not provider.manager.connected_servers
    for required in (False, True):
        bad = {'enabled': True, 'mode': 'selected', 'include_tools': ['mcp_demo_probe'], 'config': {'servers': [{'name': 'demo', 'command': '/no-such-val017-command', 'required': required, 'retry_attempts': 0}]}}
        provider = RuntimeMCPProvider(MCPToolProviderConfig.from_dict(bad), str(ROOT))
        try:
            if required:
                try: await provider.start()
                except ToolProviderLoadError: pass
                else: raise AssertionError('required failure did not stop')
            else:
                await provider.start()
            assert provider.operational_diagnostics.lifecycle[0].outcome == 'connection_failed'
            print('failed server required=', required, 'outcome=connection_failed')
        finally:
            await provider.stop()
        assert not provider.manager or not provider.manager.connected_servers

asyncio.run(lifecycle())
