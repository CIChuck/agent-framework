import asyncio,json,pathlib,sys
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import build_runtime
from friday_chat.tools.mcp import MCPChatRegistry
from friday_telemetry import DebugTelemetryRecorder
async def main():
 peer=pathlib.Path('packages/friday-chat/tests_chat/fixtures/mcp_execution_peer.py').resolve()
 cfg=FridayChatConfig.model_validate({'tools':{'providers':{'mcp':{'enabled':True,'mode':'all','config':{'servers':[{'name':'peer','command':sys.executable,'args':[str(peer)],'required':True}]}}}}})
 recorder=DebugTelemetryRecorder();r=build_runtime(cfg);bridge=MCPChatRegistry(r.tools,r.config.tools.mcp_provider,'/private/tmp',telemetry=recorder);r.tools=bridge;r.mcp_tools=bridge
 try:
  await r.start_mcp_tools()
  bad=await bridge.call_tool_record('mcp_peer_read_file',{'case':'badcontent','value':'SECRET_ARGUMENT'})
  unsafe=await bridge.call_tool_record('mcp_peer_read_file',{'case':'unsafe'})
  assert bad.mcp_provenance.failure_code=='invalid_result'
  assert unsafe.mcp_provenance.status!='succeeded'
  assert 'WS05_PROTOCOL_ENV_HEADER_SECRET' not in repr((bad,unsafe,recorder.events))
  assert 'WS05_UNSAFE_OUTPUT_SECRET' not in repr((bad,unsafe,recorder.events))
  assert 'SECRET_ARGUMENT' not in repr((bad,unsafe,recorder.events))
  print(json.dumps({'invalid_failure':bad.mcp_provenance.failure_code,'unsafe_failure':unsafe.mcp_provenance.failure_code,'events':len(recorder.events)}))
 finally:
  await r.stop_mcp_tools()
  assert bridge.provider.manager.connected_servers==[]
asyncio.run(main())
