import asyncio, contextlib, json, pathlib, sys
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import build_runtime, FakeChatModel
from friday_chat.tools.mcp import MCPChatRegistry
from friday_chat.turns.models import ChatModelResponse, ToolCallRequest
from friday_chat.turns.processor import TurnProcessor
from friday_telemetry import DebugTelemetryRecorder
PEER=pathlib.Path('tests/integration/mcp_fake_server.py').resolve()
children=[]
original=asyncio.create_subprocess_exec
async def track(*a,**k):
 p=await original(*a,**k);children.append(p);return p
asyncio.create_subprocess_exec=track

def config(mode, *, required=True, category=None, includes=None):
 server={'name':'peer','command':sys.executable,'args':[str(PEER),mode],'required':required,'timeout_seconds':2}
 mcp={'enabled':True,'mode':'all','config':{'servers':[server],'limits':{'min_memory_retrieval_tokens':100,'reserved_tool_result_tokens':100}}}
 if category is not None:
  mcp['mode']='selected';mcp['include_categories']=[category]
 if includes is not None: mcp['include_tools']=includes
 return FridayChatConfig.model_validate({'tools':{'providers':{'mcp':mcp},'context':{'max_budget_ratio':1.0}}})
async def case(mode, *, required=True, category=None, includes=None, call=False):
 cfg=config(mode,required=required,category=category,includes=includes)
 recorder=DebugTelemetryRecorder();r=build_runtime(cfg)
 bridge=MCPChatRegistry(r.tools,r.config.tools.mcp_provider,'/private/tmp',telemetry=recorder)
 r.tools=bridge;r.mcp_tools=bridge
 try:
  await r.start_mcp_tools()
  names=[x.name for x in bridge.list_tools() if x.name.startswith('mcp_')]
  if call:
   assert names==['mcp_peer_read_file'],names
   direct=await bridge.call_tool_record(names[0],{'path':'probe/path'})
   assert direct.mcp_provenance.status=='succeeded'
   assert direct.arguments=={}
   assert 'probe/path' not in direct.result
   r.tool_selection.inject_manual((names[0],))
   r.chat_llm=FakeChatModel('fake',responses=[ChatModelResponse(tool_calls=(ToolCallRequest(names[0],{'path':'probe/path'},'turn-call'),)),ChatModelResponse.from_text('done')])
   turn=await TurnProcessor(r).process('read local fixture')
   assert turn.tool_calls and turn.tool_calls[0].mcp_provenance.status=='succeeded'
   assert r.transcript.interactions and r.transcript.interactions[-1].tool_calls
   assert 'mcp.tool_output_decision' in [e.name for e in recorder.events]
   assert 'SENTINEL-STDERR-SECRET' not in repr(recorder.events)
   return {'names':names,'direct':direct.mcp_provenance.status,'turn':turn.tool_calls[0].mcp_provenance.status,'transcript':len(r.transcript.interactions),'events':len(recorder.events)}
  return {'names':names,'connected':len(bridge.provider.manager.connected_servers)}
 finally:
  await r.stop_mcp_tools()
  assert bridge.provider.manager.connected_servers==[]
  assert bridge.provider.owned_tool_names==()
async def main():
 results={}
 results['success']=await case('registry_a',call=True)
 results['selected_category']=await case('registry_a',category='mcp')
 assert results['selected_category']['names']==['mcp_peer_read_file']
 results['optional_failure']=await case('list_fail',required=False)
 try: await case('list_fail',required=True)
 except RuntimeError: results['required_failure']='raised'
 else: raise AssertionError('required failure did not raise')
 try: await case('list_fail',required=False,includes=['missing'])
 except RuntimeError: results['strict_include_failure']='raised'
 else: raise AssertionError('strict include did not raise')
 # Each child must have settled after the public owner stopped.
 assert all(p.returncode is not None and p.stdout.at_eof() and p.stderr.at_eof() for p in children)
 results['settled_children']=len(children)
 print(json.dumps(results,indent=2))
try: asyncio.run(main())
finally:
 asyncio.create_subprocess_exec=original
 for p in children:
  if p.returncode is None:
   with contextlib.suppress(ProcessLookupError): p.kill()
