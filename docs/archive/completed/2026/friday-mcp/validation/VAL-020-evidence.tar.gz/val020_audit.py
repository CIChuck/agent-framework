import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
req=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-020-request.yaml').read_text())
manifest=json.loads((root/req['product_manifest']).read_text())
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
checks={}
checks['authority']={x['path']:{'expected':x['sha256'],'actual':sha(root/x['path'])} for x in req['authority']}
checks['product']={p:{'expected':h,'actual':sha(root/p)} for p,h in manifest['product_paths'].items()}
checks['unrelated']={}
for p,ref in manifest['unrelated'].items():
 if isinstance(ref,dict):
  actual={str(f.relative_to(root/p)):sha(f) for f in (root/p).rglob('*') if f.is_file()}
  checks['unrelated'][p]={'expected':ref,'actual':actual}
 else: checks['unrelated'][p]={'expected':ref,'actual':sha(root/p)}
cmd=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode().splitlines()
checks['aggregate']={'expected':manifest['full_changed_paths'],'actual':cmd('diff','--name-only',req['diff_range'])}
checks['delta']={'expected':manifest['product_delta_paths'],'actual':cmd('diff','--name-only',req['product_delta_range'],'--','packages')}
checks['historical_artifacts']={p:checks['authority'][p] for p in checks['authority'] if 'VAL-019-' in p}
result={'counts':{k:len(v) for k,v in checks.items()},'mismatch':{k:[p for p,v in val.items() if v['expected']!=v['actual']] if isinstance(val,dict) and k not in ('aggregate','delta') else (val['expected']!=val['actual']) for k,val in checks.items()},'head':cmd('rev-parse','HEAD')[0]}
out=pathlib.Path('/private/tmp/val020-'+sys.argv[1]+'.json');out.write_text(json.dumps({'summary':result,'checks':checks},indent=2))
print(json.dumps(result,indent=2))
