import json,os,pathlib,subprocess,time
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
req=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-020-request.yaml').read_text())
out=pathlib.Path('/private/tmp/val020-checks');out.mkdir(exist_ok=True)
env=os.environ.copy();env.update({'PYTHONDONTWRITEBYTECODE':'1','PYTEST_ADDOPTS':'-p no:cacheprovider','MYPY_CACHE_DIR':str(out/'mypy-cache'),'RUFF_CACHE_DIR':str(out/'ruff-cache'),'TMPDIR':str(out),'XDG_CACHE_HOME':str(out/'xdg-cache')})
results=[]
for i,cmd in enumerate(req['required_checks'],1):
 if not cmd.startswith(('UV_CACHE_DIR=','git diff --check')): continue
 log=out/f'{i:02d}.log'; print(f'RUN {i}: {cmd}',flush=True);start=time.time()
 with log.open('w') as f:
  p=subprocess.run(cmd,shell=True,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 tail=log.read_text(errors='replace').splitlines()[-8:]
 item={'number':i,'command':cmd,'exit':p.returncode,'seconds':round(time.time()-start,1),'log':str(log),'tail':tail};results.append(item)
 (out/'results.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(item),flush=True)
