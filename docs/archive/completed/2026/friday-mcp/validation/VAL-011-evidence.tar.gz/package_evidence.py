import gzip,hashlib,io,json,pathlib,re,tarfile
OUT=pathlib.Path('/private/tmp/VAL-011-independent-20260928')
sha=lambda b:hashlib.sha256(b).hexdigest()
excluded={'evidence.json','delivery.json','VAL-011-evidence.tar.gz'}
selected=[]
for p in OUT.iterdir():
 if p.is_file() and p.name not in excluded and p.suffix in {'.py','.log','.json','.txt','.diff','.md','.jsonl'}: selected.append(p)
for directory in ['inputs','wheels','catalog-bin']:
 selected.extend(p for p in (OUT/directory).rglob('*') if p.is_file())
selected=sorted(set(selected),key=lambda p:p.relative_to(OUT).as_posix())
entries=[{'member':p.relative_to(OUT).as_posix(),'source_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in selected]
manifest={'validation_id':'VAL-011','overall_outcome':'CHANGES_REQUESTED','report_member':'VAL-011-report.md','archive_filename':'VAL-011-evidence.tar.gz','hash_algorithm':'SHA-256','manifest_self_hash_policy':'This manifest is excluded from its own entries; delivery.json beside the archive hashes this exact manifest and archive.','member_reference_format':'VAL-011-evidence.tar.gz#member-name','runtime_databases_and_credentials_included':False,'entries':entries}
(OUT/'evidence.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
links=re.findall(r'\]\(VAL-011-evidence\.tar\.gz#([^)]*)\)',(OUT/'VAL-011-report.md').read_text())
known={e['member'] for e in entries}|{'evidence.json'}
missing=sorted(set(links)-known)
assert not missing,missing
archive=OUT/'VAL-011-evidence.tar.gz'
with archive.open('wb') as handle:
 with gzip.GzipFile(filename='',mode='wb',fileobj=handle,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for p in sorted(selected+[OUT/'evidence.json'],key=lambda p:p.relative_to(OUT).as_posix()):
    b=p.read_bytes();info=tarfile.TarInfo(p.relative_to(OUT).as_posix());info.size=len(b);info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mode=0o644;tf.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tf:
 assert set(tf.getnames())==known
 for e in entries:
  b=tf.extractfile(e['member']).read();assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['member']
 assert tf.extractfile('evidence.json').read()==(OUT/'evidence.json').read_bytes()
 assert tf.extractfile('VAL-011-report.md').read()==(OUT/'VAL-011-report.md').read_bytes()
delivery={'validation_id':'VAL-011','overall_outcome':'CHANGES_REQUESTED','findings':[{'id':'VAL-011-F-001','severity':'High'},{'id':'VAL-011-F-002','severity':'High'}],'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(known),'all_member_hashes_verified':True},'report':{'path':str(OUT/'VAL-011-report.md'),'member':'VAL-011-report.md','bytes':(OUT/'VAL-011-report.md').stat().st_size,'sha256':sha((OUT/'VAL-011-report.md').read_bytes())},'manifest':{'path':str(OUT/'evidence.json'),'member':'evidence.json','entries':len(entries),'bytes':(OUT/'evidence.json').stat().st_size,'sha256':sha((OUT/'evidence.json').read_bytes())},'portable_report_reference':'VAL-011-evidence.tar.gz#VAL-011-report.md','portable_manifest_reference':'VAL-011-evidence.tar.gz#evidence.json','report_archive_links_checked':len(links),'all_report_links_resolve':True,'self_hash_policy':'delivery.json is external and not inside the archive, to avoid recursive hashing.'}
(OUT/'delivery.json').write_text(json.dumps(delivery,indent=2,sort_keys=True)+'\n');print(json.dumps(delivery,indent=2))
