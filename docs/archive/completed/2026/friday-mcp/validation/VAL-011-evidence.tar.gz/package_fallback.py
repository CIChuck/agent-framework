import importlib.metadata as md,json,pathlib,shutil,subprocess
from packaging.requirements import Requirement
OUT=pathlib.Path('/private/tmp/VAL-011-independent-20260928');ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');TARGET=OUT/'wheel-venv';EXTRACT=OUT/'extracted-wheels'
names=['pydantic','aiosqlite','pydantic-settings','structlog'];seen={};pending=list(names)
while pending:
 name=pending.pop()
 if name in seen:continue
 dist=md.distribution(name);required=[]
 for line in dist.requires or []:
  req=Requirement(line)
  if req.marker is None or req.marker.evaluate({'extra':''}):
   installed=md.version(req.name)
   if req.specifier and installed not in req.specifier:raise ValueError(f'Unsatisfied dependency {req.name}')
   required.append(line);pending.append(req.name)
 seen[name]={'version':dist.version,'required':required,'files':[]}
 for file in dist.files or []:
  if str(file).endswith(('.pyc','.pth')) or str(file).startswith('../'):continue
  source=pathlib.Path(dist.locate_file(file))
  if not source.is_file():continue
  destination=TARGET/'lib/python3.13/site-packages'/str(file)
  destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination)
  import hashlib
  seen[name]['files'].append({'path':str(file),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
(OUT/'isolated-declared-dependencies.json').write_text(json.dumps(seen,indent=2)+'\n')
cmd=[str(TARGET/'bin/python'),'-I',str(OUT/'wheel-import.py'),str(EXTRACT)]
with (OUT/'package-imports-fallback.log').open('wb') as log:r=subprocess.run(cmd,cwd=OUT,stdout=log,stderr=subprocess.STDOUT)
(OUT/'package-imports-fallback.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'dependency_source':'Existing installed third-party declared dependency bytes, copied without pth or editable hooks. Built framework packages imported from extracted wheels.','dependency_names':list(seen)},indent=2)+'\n')
print((OUT/'package-imports-fallback.log').read_text());raise SystemExit(r.returncode)
