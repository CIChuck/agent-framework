import pathlib,sys
sys.path.insert(0,sys.argv[1])
import friday_core,friday_transcript,friday_telemetry
from friday_core.mcp import MCPToolMetadata,MCPToolCallProvenance
from friday_transcript import ToolCall,ToolResult,TranscriptEntry,SQLiteTranscriptStore,JSONLExporter,MarkdownExporter,CSVExporter
root=pathlib.Path(sys.argv[1])
for module in [friday_core,friday_transcript,friday_telemetry]:
 assert pathlib.Path(module.__file__).is_relative_to(root);print(module.__name__,module.__file__)
assert not any('agent-framework/packages' in p for p in sys.path)
meta=MCPToolMetadata(canonical_name='mcp_local_probe',server_name='local',original_name='Probe',transport='stdio',trust_level='local')
facts=MCPToolCallProvenance(tool=meta,call_id='wheel-call',status='succeeded',output_sanitization_state='sanitized',model_result_size_bytes=2,transcript_correlation_id='wheel-entry')
entry=TranscriptEntry(id='wheel-entry',session_id='wheel-session',turn_number=1,tool_calls=[ToolCall(id='wheel-call',name='mcp_local_probe',mcp_provenance=facts)],tool_results=[ToolResult(tool_call_id='wheel-call',output='ok',mcp_provenance=facts)])
assert TranscriptEntry.model_validate_json(entry.model_dump_json())==entry
print('Extracted-wheel public imports, declared dependencies and typed round-trip PASS')
