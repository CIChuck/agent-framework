import asyncio,contextlib,io,json,pathlib,sys
from friday_chat.adapters import FrameworkTranscriptAdapter
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import FakeChatModel,build_runtime
from friday_chat.tools.mcp import MCPChatRegistry
from friday_chat.turns.models import ChatModelResponse,ToolCallRequest
from friday_chat.turns.processor import TurnProcessor
from friday_transcript import SQLiteTranscriptStore,JSONLExporter,CSVExporter,MarkdownExporter
OUT=pathlib.Path(__file__).parent;LABEL=sys.argv[1];children=[]
async def main():
 orig=asyncio.create_subprocess_exec
 async def spawn(*args,**kwargs):
  child=await orig(*args,**kwargs);children.append(child);return child
 asyncio.create_subprocess_exec=spawn
 cfg=FridayChatConfig.model_validate({'transcript':{'capture_raw_prompts':True},'tools':{'loop':{'max_iterations':3},'context':{'max_budget_ratio':1.0},'providers':{'mcp':{'enabled':True,'mode':'all','config':{'servers':[{'name':'alpha','command':sys.executable,'args':[str(OUT/'peer.py'),str(OUT/f'finding-audit-{LABEL}.jsonl')],'required':True,'env':{'VAL11_SYNTHETIC_ENV':'VAL11_ENV_HEADER_MARK'},'timeout_seconds':1}],'limits':{'max_result_bytes':256,'min_memory_retrieval_tokens':100,'reserved_tool_result_tokens':80}}}}}})
 runtime=build_runtime(cfg);bridge=MCPChatRegistry(runtime.tools,cfg.tools.mcp_provider,str(OUT));runtime.tools=runtime.mcp_tools=bridge;store=SQLiteTranscriptStore(OUT/f'finding-{LABEL}.sqlite');runtime.transcript=FrameworkTranscriptAdapter(store,cfg,'repro-session')
 import friday_chat
 print('source',friday_chat.__file__)
 initial=set(asyncio.all_tasks());results={'label':LABEL}
 try:
  await runtime.start_mcp_tools();runtime.tool_selection.inject_manual(('mcp_alpha_probe_run','echo'))
  runtime.chat_llm=FakeChatModel('fake',responses=[ChatModelResponse(tool_calls=(ToolCallRequest('mcp_alpha_probe_run',{},'safe-first'),)),ChatModelResponse.from_text('done')])
  await TurnProcessor(runtime).process('synthetic env reproduction')
  session=await store.get_session('repro-session');results['F-001']={'session_config_contains_env_value':'VAL11_ENV_HEADER_MARK' in repr(session.config_snapshot),'exported_by':[]}
  for name,exporter,kwargs in [('JSONL',JSONLExporter(store),{}),('JSONL metadata false',JSONLExporter(store),{'include_metadata':False}),('CSV',CSVExporter(store),{}),('Markdown',MarkdownExporter(store),{})]:
   out=io.StringIO();await exporter.export_session('repro-session',out,**kwargs)
   if 'VAL11_ENV_HEADER_MARK' in out.getvalue():results['F-001']['exported_by'].append(name)
  entries_before=len(await store.get_entries('repro-session'))
  model=FakeChatModel('fake',responses=[ChatModelResponse(tool_calls=(ToolCallRequest('mcp_alpha_probe_run',{},'later-native'),)),ChatModelResponse(tool_calls=(ToolCallRequest('echo',{'text':'native benign'},'later-native'),)),ChatModelResponse.from_text('done')]);runtime.chat_llm=model
  try:
   result=await TurnProcessor(runtime).process('synthetic collision reproduction');failure=None;ids=[c.call_id for c in result.tool_calls]
  except Exception as e:
   failure=type(e).__name__;ids=[m['tool_call_id'] for m in model.calls[-1] if m.get('role')=='tool']
  results['F-002']={'exception_type':failure,'continuation_tool_ids':ids,'persisted_entries_added':len(await store.get_entries('repro-session'))-entries_before}
  await bridge.stop()
  results['public_cleanup']={'metadata_empty':bridge.tool_metadata=={},'owned_names_empty':bridge.provider.owned_tool_names==(),'connected_empty':bridge.provider.manager.connected_servers==[],'children_exited_and_eof':all(c.returncode is not None and c.stdout.at_eof() and c.stderr.at_eof() for c in children),'tasks_settled':not [t for t in asyncio.all_tasks()-initial if not t.done()]}
 finally:
  try:await bridge.stop()
  finally:
   async def drain(s):
    if s:
     while await s.read(4096):pass
   for c in children:
    if c.returncode is None:
     with contextlib.suppress(ProcessLookupError):c.kill()
    await asyncio.wait_for(asyncio.gather(drain(c.stdout),drain(c.stderr)),3);await asyncio.wait_for(c.wait(),3)
  asyncio.create_subprocess_exec=orig
 (OUT/f'finding-results-{LABEL}.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
asyncio.run(main())
