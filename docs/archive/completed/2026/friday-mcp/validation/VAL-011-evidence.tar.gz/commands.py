import asyncio,datetime,json,os,pathlib,sys,yaml
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT=pathlib.Path('/private/tmp/VAL-011-independent-20260928')
env=os.environ.copy()
env.update({'PYTEST_ADDOPTS':'-p no:cacheprovider','MYPY_CACHE_DIR':str(OUT/'mypy-cache'),'TMPDIR':str(OUT/'runtime-tmp')})
(OUT/'runtime-tmp').mkdir(exist_ok=True)
request=yaml.safe_load((ROOT/'docs/planning/active/friday-mcp/validation/VAL-011-request.yaml').read_text())
async def run(i,cmd,cwd=ROOT):
 name=f'command-{i:02d}'
 metadata={'id':name,'command':cmd,'cwd':str(cwd),'extra_env':{k:env[k] for k in ['PYTEST_ADDOPTS','MYPY_CACHE_DIR','TMPDIR']},'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (OUT/(name+'.log')).open('wb') as log:
  proc=await asyncio.create_subprocess_shell(cmd,cwd=cwd,env=env,stdout=log,stderr=asyncio.subprocess.STDOUT)
  metadata['exit_code']=await proc.wait()
 metadata['end']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/(name+'.json')).write_text(json.dumps(metadata,indent=2)+'\n')
 print(name,metadata['exit_code'],(OUT/(name+'.log')).read_text(errors='replace')[-1200:],flush=True)
async def main():
 await run(1,request['required_checks'][0])
 for start in range(1,len(request['required_checks']),3):
  await asyncio.gather(*(run(i+1,request['required_checks'][i]) for i in range(start,min(start+3,len(request['required_checks'])))))
asyncio.run(main())
