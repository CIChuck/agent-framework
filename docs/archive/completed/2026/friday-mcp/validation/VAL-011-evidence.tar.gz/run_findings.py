import json,os,pathlib,subprocess
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/VAL-011-independent-20260928')
for label,source in [('candidate',ROOT),('baseline',OUT/'baseline')]:
 env=os.environ.copy();env.update({'LITELLM_LOCAL_MODEL_COST_MAP':'true','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':os.pathsep.join(str(p) for p in sorted((source/'packages').glob('*/src')))})
 cmd=[str(ROOT/'.venv/bin/python'),str(OUT/'finding_repro.py'),label]
 with (OUT/f'finding-repro-{label}.log').open('wb') as log:r=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 (OUT/f'finding-repro-{label}.json').write_text(json.dumps({'command':cmd,'cwd':str(source),'extra_env':{k:env[k] for k in ['LITELLM_LOCAL_MODEL_COST_MAP','PYTHONDONTWRITEBYTECODE','PYTHONPATH']},'exit_code':r.returncode},indent=2)+'\n')
 print(label,r.returncode,(OUT/f'finding-repro-{label}.log').read_text(),flush=True)
