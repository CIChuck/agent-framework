import hashlib,json,pathlib,shutil,subprocess,tarfile,tomllib,zipfile,yaml
from packaging.requirements import Requirement
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/VAL-011-independent-20260928');REQ=yaml.safe_load((ROOT/'docs/planning/active/friday-mcp/validation/VAL-011-request.yaml').read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
changed=git('diff','--name-only',REQ['base_commit']+'..'+REQ['candidate_commit']).decode().splitlines()
allowed=[*REQ['allowed_product_paths'],*REQ['allowed_dependency_paths'],*REQ['allowed_test_paths'],REQ['allowed_implementation_report']]
product=[p for p in changed if p.startswith(('packages/','tests/')) or p in ['pyproject.toml','uv.lock'] or p==REQ['allowed_implementation_report']]
process=[p for p in changed if p not in product]
frozen=json.loads((ROOT/REQ['frozen_input_manifest']).read_text());outside=[]
for p,expected in frozen['tracked_product_bytes'].items():
 if p not in allowed and hashlib.sha256(git('show',REQ['base_commit']+':'+p)).hexdigest()!=expected:outside.append(p)
baseline_inputs=['packages/friday-chat/tests_chat/test_reorganization_terminal.py','packages/friday-chat/tests_chat/test_llm_adapter_migration.py','tests/integration/test_development_board.py','pyproject.toml']
baseline_diff=subprocess.run(['git','diff','--exit-code',REQ['base_commit']+'..'+REQ['candidate_commit'],'--',*baseline_inputs],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
graph={}
for p in (ROOT/'packages').glob('*/pyproject.toml'):
 data=tomllib.loads(p.read_text())['project'];graph[data['name']]=[Requirement(d).name for d in data.get('dependencies',[])]
def reach(name,seen=None):
 seen=set() if seen is None else seen
 if name in seen:return seen
 seen.add(name)
 for nxt in graph.get(name,[]):reach(nxt,seen)
 return seen
edge_acyclic='friday-framework-transcript' not in reach('friday-framework-core')
builder_path=ROOT/'docs/planning/active/friday-mcp/execution/WS-05-builder-evidence.yaml';builder=yaml.safe_load(builder_path.read_text());archive=builder_path.with_name(builder['archive']);builder_errors=[]
if hashlib.sha256(archive.read_bytes()).hexdigest()!=builder['archive_sha256']:builder_errors.append('archive')
with tarfile.open(archive) as tf:
 actual={m.name:m for m in tf.getmembers() if m.isfile()}
 for item in builder['members']:
  blob=tf.extractfile(actual[item['path']]).read()
  if len(blob)!=item['bytes'] or hashlib.sha256(blob).hexdigest()!=item['sha256']:builder_errors.append(item['path'])
 if set(actual)!={item['path'] for item in builder['members']}:builder_errors.append('member-set')
for p in changed:
 if p.endswith('.tar.gz'):continue
 target=OUT/'inputs/candidate'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(git('show',REQ['candidate_commit']+':'+p))
versions={}
for wheel in (OUT/'wheels').glob('*.whl'):
 with zipfile.ZipFile(wheel) as z:versions[wheel.name]=z.read(next(p for p in z.namelist() if p.endswith('/WHEEL'))).decode()
result={'changed_paths':changed,'exact_23_allowed_paths':set(allowed)==set(product),'implementation_deliverables':len(product),'approved_path_count':len(allowed),'controller_and_builder_evidence_paths':process,'unexpected_product_paths':sorted(set(product)-set(allowed)),'outside_allowed_changed_from_approved_base':outside,'outside_allowed_count':len(frozen['tracked_product_bytes'])-len([p for p in allowed if p in frozen['tracked_product_bytes']]),'baseline_source_diff':{'command':['git','diff','--exit-code',REQ['base_commit']+'..'+REQ['candidate_commit'],'--',*baseline_inputs],'exit_code':baseline_diff.returncode,'output':baseline_diff.stdout.decode()},'new_transcript_core_edge_acyclic':edge_acyclic,'core_reachable_dependencies':sorted(reach('friday-framework-core')),'wheel_build_generators':versions,'builder_archive_integrity':{'members':len(builder['members']),'errors':builder_errors,'conclusions_used_as_pass_evidence':False},'candidate_to_head_paths':git('diff','--name-only',REQ['candidate_commit']+'..HEAD').decode().splitlines()}
(OUT/'scope-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
