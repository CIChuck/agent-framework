import datetime,json,pathlib
OUT=pathlib.Path('/private/tmp/VAL-011-independent-20260928')
load=lambda name:json.loads((OUT/name).read_text())
def artifact(member,label=None):return f'[{label or member}](VAL-011-evidence.tar.gz#{member})'
def source(path,lines):return artifact('inputs/candidate/'+path,path+':'+lines)
report='''# VAL-011 independent work-unit aggregate report

**Outcome: CHANGES_REQUESTED**

Frozen WS-05 candidate `2388e747ba1bf8157881230ad36ae3ef3272b807` violates two mandatory requirement boundaries. Findings **VAL-011-F-001** and **VAL-011-F-002** are High severity. All required commands were independently executed; baseline failures were reproduced; the mandatory offline build/isolated extracted-wheel import proof was obtained. This is independent validation, with no implementation, remediation authorization, maintainer acceptance, merge, or delivery.

## Review identity, scope and authority

Reviewer: fresh independent Codex agent `/root/mcp_ws05_val011`, GPT-6 family (the exact serving model suffix is not exposed), review date 2026-09-28. Dispatch required a newly spawned conversation with `fork_turns=none`. No parent, builder or remediator session or private reasoning was accessed. The parent supplied only scope/freeze coordination and received public progress. Candidate tests and builder report were documentary inputs, never sole proof of correctness. The builder archive was checked for integrity only. A lightweight governance memory registry check was not used for WS-05 product conclusions; repository authority was checked directly.

Repository: `/Users/chuckrussell/Dev/gendev/agent-framework`; branch `feature/friday-mcp-ws05-execution`. Review mode is **work_unit_aggregate**, not last-commit-only. Approved work-unit base and full comparison: `a609f948fe2d869ac29d0cce29d22d9334cd7d08..2388e747ba1bf8157881230ad36ae3ef3272b807`. Authority revision is the candidate. Authorization/start commit `5e86df832a311a62509fb0838f6c45b6ecd6fdfa` records maintainer approval before product generation. Accepted predecessor product is `53d76d45cedea16122436e53b178de074c5bc322`. Request preparation `d9d86853c1a68b9473678e468228d5fb37923279` and subsequent controller metadata `2e3776ad7bd636ed1031b1d1201ad2c9a446b760` are process metadata, not product candidates. Initial orientation observed the former; start hashing and closeout both recorded the settled latter.

AGENTS.md was read first, then the exact request and frozen manifest. All 30 pinned authorities, four candidate reports, complete approved-base aggregate diff, all 12 changed sources and eight changed test/fixture paths were reviewed. Prior accepted validation/closeout reports define frozen contracts and are not a fresh verdict. The request, directive and build plan fix the task boundaries; no later-phase features, shared sanitizer changes, broad typing suppressions, transport allocation claims or universal arbitrary-secret/injection guarantee were inferred.

Evidence links below are portable archive-member references. Source labels specify original repository path and line numbers; the archive contains the exact source bytes and numbered authorities. `evidence.json` is the exact member hash/size manifest; `delivery.json`, supplied beside the archive, hashes the report, manifest and archive without a recursive self-hash.

## Frozen inputs and preservation

Request SHA-256: `e8d66cb27cd564ca0ac8b063c86b84481b906eebf535174effd758fff09542e3`.
Frozen-input manifest SHA-256: `6ecbe6044cb5f4f553ed82ce045c8378e56e89c341a72e02438a9d9aa668984d`.

At both start and closeout, the independent verifier compared **978 tracked product/config/test files** against the frozen manifest and candidate Git blobs, all 30 authorities and four reports against their working and pinned Git bytes, the request hash, and the recursive fingerprints of all five unrelated dirty paths. Both checks report `errors: []`; branch, dirty manifest, preserved fingerprints and governed hashes are identical. No governed files, Git state or board data were changed, and no unrelated/generated state was cleaned. Temporary peers, logs, SQLite databases, build inputs and probe state remained in the permitted scratch directory. Runtime DBs, extracted source/venv trees, cache state and unrelated user artifacts are excluded from the deliverable archive.

| Unrelated path | Preserved state | Exact fingerprint SHA-256 |
| --- | --- | --- |
| `.DS_Store` | Modified, one file | `726abde51b913404c3c5af3bf5ec36210f129b89ca33a0efc24dd4cd73fe98a9` |
| `family-tree.md` | Deleted/absent | Not applicable; absence retained |
| `docker-bench-security/` | Untracked, 57 files | `d7215d8bafcc427e5dde801fd1f80f88438fa5bc4215ff3262f86bfcea870f85` |
| `packages/friday-chat/config.example.yaml.pre-typed-llm-20260828.bak` | Untracked, one file | `b9164e100cf67ff37ff860ed82c5987981ed740e2fec88f8bcc25e815a9c7cea` |
| `packages/friday-sandbox/docker/Dockerfile.audit` | Untracked, one file | `8904c2cd686fb4acb2612f00b875f8bb03e4a284c3f2b4e4cb440ab7e2739884` |

Freeze evidence: [start](VAL-011-evidence.tar.gz#start-freeze.json), [closeout](VAL-011-evidence.tar.gz#closeout-freeze.json), [verifier](VAL-011-evidence.tar.gz#setup.py), [scope audit](VAL-011-evidence.tar.gz#scope-audit.json), [complete binary aggregate diff](VAL-011-evidence.tar.gz#aggregate.diff), [changed-path inventory](VAL-011-evidence.tar.gz#aggregate-name-status.txt).

The aggregate changes exactly **23 approved implementation deliverables**: 12 sources, two dependency/lock paths, eight tests/fixture paths, and the implementation report. Its 31 total paths additionally include six approval/controller process records and two builder-evidence artifacts. No unexpected product path changed. All 956 tracked product/config/test paths outside the allowed changed-product set remain byte-identical to the approved base. Candidate-to-current-HEAD differences are seven allowed process/request paths only. Builder archive SHA-256 is `580315100c04b655b2a1aa73f75a4500d5f03562fe16efdc7368a551d2ab9521`; all 67 members matched the builder manifest exactly. Its conclusions were not adopted.

## Numbered findings

### 1. VAL-011-F-001 — High — MCP runtime environment values are persisted and exported through session snapshots

**Observed requirement violation.** A successful public MCP turn with a configured synthetic server environment value causes the production transcript adapter to persist the complete MCP configuration in `TranscriptSession.config_snapshot`. The value then appears in the JSONL session header, including when `include_metadata=False`. Public `CSVExporter.export_all_sessions` also copies it into `sessions.csv`. Single-session CSV entry export, its `entries.csv` companion and Markdown session export did not expose this value in the probes. The finding concerns a known configured MCP runtime-sensitive input; it does not demand arbitrary secret classification or rewriting user/LLM prose.

**Authority.** WS05-AC02 explicitly requires that no env/header sentinel survive MCP-owned persistence/capture boundaries; WS05-AC07 requires safe production records; WS05-AC08 governs safe exports. The approved build plan, lines 118–120, says secret-bearing `env`, headers, command arguments, URLs and tool-call arguments are runtime-only input. WS-05 owns persistence/redaction enforcement (build plan 659 onward), and the directive's failed-call contract also forbids retained env/header/secret-bearing messages (159–170). The successful-turn reproduction alone establishes the general runtime-only snapshot violation. Configuration/SQLite schema redesign and later telemetry features remain outside scope.

**Affected sources.** `packages/friday-chat/src/friday_chat/adapters.py:1313–1324`, especially line 1323, passes `self.config.model_dump(mode="json")` directly to session creation. `packages/friday-transcript/src/friday_transcript/exporters/jsonl.py:68–74,162–175` writes that snapshot in the session header; the entry-only metadata flag logic at 178–205 does not remove it. `packages/friday-transcript/src/friday_transcript/exporters/csv.py:178–223,238–251,277–291` exports the same snapshot in the existing session CSV column.

**Inherited versus new.** The same successful-turn snapshot leak and all three exposing surfaces reproduce on the full approved work-unit base using archived original-source imports. This is inherited behavior, not a new line-level WS-05 regression. It nevertheless violates WS-05's explicitly approved aggregate runtime-only/no-sentinel persistence requirement and has no declared waiver. The allowed adapter/export paths make a bounded repair possible without changing configuration or storage schemas. Existing accepted predecessor status does not supersede this new work-unit criterion.

**Executable reproduction.** Run `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /private/tmp/VAL-011-independent-20260928/run_findings.py` from the repository after extracting the archived approved base as documented in `baseline.py`; this runner launches exact candidate and baseline source imports and a real synthetic stdio peer. Inspect `finding-results-candidate.json` and `finding-results-baseline.json`: `session_config_contains_env_value: true` and `exported_by: ["JSONL", "JSONL metadata false"]` in each. Then run the archived `export_all_repro.py` runner to observe `sessions_csv_contains_configured_env_value: true`, `entries_csv_contains_configured_env_value: false` on each. These diagnostic commands exit 0 when recording observations, not when requirements pass. The asserting public matrix exits 1 on all four production combinations (streaming/nonstreaming × normal/fallback); fake-adapter counterparts pass. The peer audit verifies original configured env reached execution without preserving its value in the audit.

**Risk and severity.** High: runtime-configured MCP environment credentials may become durable transcript state and travel in ordinary transcript exports. Disabling entry metadata does not protect the session header. No real credential was used; the probe's only sensitive-like value was the synthetic sentinel `VAL11_ENV_HEADER_MARK`.

**Concrete mitigation boundary and regression expectations.** Sanitize or omit MCP runtime-sensitive configuration values at the consumer's persisted session-snapshot boundary while preserving original runtime execution inputs. Maintain safe native configuration/metadata compatibility and existing CSV columns/privacy controls. Cover the explicitly documented runtime-sensitive surfaces (at minimum env values; configured command arguments can also hold secrets) without general configuration redesign, new settings, argument hashes or a historical DB migration. If older already-stored snapshots need export-time treatment, the controller/maintainer must bound that behavior explicitly. Verify a real peer receives original env/arguments; no synthetic configured value reaches session/entry SQLite JSON, raw/context capture, JSONL with metadata on/off, all-session CSV, entry CSV or Markdown, in both actual turn modes and fallback paths. Preserve old/native models and exporter contracts. Update the bounded implementation report to state the tested snapshot policy accurately.

Evidence: [real public candidate reproduction](VAL-011-evidence.tar.gz#finding-repro-candidate.log), [baseline reproduction](VAL-011-evidence.tar.gz#finding-repro-baseline.log), [candidate facts](VAL-011-evidence.tar.gz#finding-results-candidate.json), [baseline facts](VAL-011-evidence.tar.gz#finding-results-baseline.json), [all-session CSV candidate](VAL-011-evidence.tar.gz#export-all-repro-candidate.log), [all-session CSV baseline](VAL-011-evidence.tar.gz#export-all-repro-baseline.log), [asserting matrix](VAL-011-evidence.tar.gz#independent-probes-final-delivery.log), [reproduction script](VAL-011-evidence.tar.gz#finding_repro.py), [CSV script](VAL-011-evidence.tar.gz#export_all_repro.py).

### 2. VAL-011-F-002 — High — A later native call-ID collision leaves ambiguous continuation and newly prevents turn persistence

**Observed requirement violation.** An MCP call in the first tool-loop iteration with valid ID `later-native`, followed in the next iteration by a native `echo` call with the same ID, produces two continuation tool messages with identical `tool_call_id`. Their distinct records cannot satisfy the new MCP transcript pairing validator. With the real production adapter the completed turn raises `TurnPersistenceError`, adds zero transcript entries, and retains ambiguous IDs in the final model continuation. Both actual calls executed.

**Authority.** WS-05 directive 105–113 requires distinct mixed/repeated per-call facts and coherent unique MCP IDs while preserving native IDs; 178–194 requires paired compatible transcript persistence. WS05-AC06 and WS05-AC07 are violated; WS05-AC09's native/mixed compatibility is also affected. The request explicitly requires native collisions **across iterations**. Resolving only the current response's native IDs does not meet that requirement.

**Affected sources.** `packages/friday-chat/src/friday_chat/tools/loop.py:79–114` reserves native IDs appearing in the current response before allocating MCP IDs. `packages/friday-chat/src/friday_chat/turns/processor.py:452–481` shares a used-ID set across iterations but never repairs an earlier MCP ID when a future native call retains it. `packages/friday-transcript/src/friday_transcript/models/transcript.py:263–294`, particularly 277–289, correctly rejects ambiguous MCP call/result pairing. `packages/friday-chat/src/friday_chat/adapters.py:1141–1177` submits the records, and `turns/processor.py:548–598` wraps the validator failure as turn persistence failure. Weakening the validator would hide the upstream correlation fault.

**Inherited versus new.** The archived approved-base turn also has duplicate continuation IDs, but successfully persists one new entry. The candidate still has the inherited ambiguous continuation behavior and additionally raises persistence failure because of its new strict typed pairing validation. The regression is therefore the failed previously persistable turn; the approved WS-05 handling must also eliminate the inherited ambiguity rather than accept duplicate IDs. This exact distinction is independently captured with original-source imports in the two reproduction fact files.

**Executable reproduction.** The same `run_findings.py` runner builds actual TurnProcessor, production SQLite adapter and a real peer. Model iteration 1 requests `mcp_alpha_probe_run` with `{}` and ID `later-native`; iteration 2 requests native `echo` with `{"text":"native benign"}` and the identical ID; iteration 3 returns `done`. Candidate facts show `exception_type: "TurnPersistenceError"`, `continuation_tool_ids: ["later-native", "later-native"]`, `persisted_entries_added: 0`. Baseline facts show no exception, identical ambiguous IDs and one added entry. The asserting independent `test_cross_iteration_native_collision` fails on the candidate. Same-response native reservations, repeated MCP IDs, missing/invalid IDs, repeated tool names, concurrent peer calls and metadata association separately pass.

**Risk and severity.** High: a permitted mixed tool turn that completes its executions can fail transcript persistence, and the model cannot unambiguously associate subsequent tool results. Loss of the durable turn and incoherent per-call provenance violate core WS-05 behavior. No source fix was attempted.

**Concrete mitigation boundary and regression expectations.** Resolve IDs across the entire turn while retaining native-ID behavior. If a later native request collides with an earlier MCP ID, reassign the affected MCP ID and atomically update its retained assistant request, tool-result message, typed record/provenance and all relevant continuation/capture/history copies before subsequent model capture or persistence. Do not weaken paired validation, drop records, accept duplicates, rewrite native IDs or invent entry correlations. Add actual streaming/nonstreaming, fake/production, three-iteration preceding-MCP/later-native cases, repeated MCP names/IDs, multiple servers and concurrent calls. Assert every assistant request/result/record has coherent unique MCP identifiers, actual persisted entry IDs remain consistent, native IDs are preserved and the previously completed mixed turn stores successfully without migration. Existing same-iteration invalid/missing/duplicate/native collision tests must continue passing.

Evidence: [public reproduction script](VAL-011-evidence.tar.gz#finding_repro.py), [candidate exact command/environment](VAL-011-evidence.tar.gz#finding-repro-candidate.json), [baseline exact command/environment](VAL-011-evidence.tar.gz#finding-repro-baseline.json), [candidate facts](VAL-011-evidence.tar.gz#finding-results-candidate.json), [baseline facts](VAL-011-evidence.tar.gz#finding-results-baseline.json), [asserting cross-iteration failure](VAL-011-evidence.tar.gz#independent-probes-final-delivery.log).

## Eight tactical task assessments

The approved directive narrows the tactical phrase “redact or hash” to empty argument dictionaries and no hashes. Task assessments below apply that approved decision.

| Task | Assessment | Evidence and limit |
| --- | --- | --- |
| MCP-05-01 typed provenance | Supported | Public Core DTO, optional Chat field after four existing fields, fixed sizes/codes and paired Transcript types; required contracts and independent negative DTO/old-native serialization tests pass. |
| MCP-05-02 argument redaction | Requirement unmet | Original execution and MCP argument/request-prose removal pass at bridge, loop, turn/fallback/raw/context and entry boundaries; configured MCP env survives the production session snapshot and exports, F-001. No hashes were introduced. |
| MCP-05-03 byte limit | Supported | Direct public cap matrix, ToolLoop tiny-before-RPC rejection and both actual turn modes pass final UTF-8 bound including wrappers/notices, empty/exact/over/multibyte and above-default limits. |
| MCP-05-04 sanitize outputs | Supported | Explicit high-risk block/drop/log-off policy, high-offset retained attack, escaped closing-marker, normalization/echo and sanitizer-exception probes pass; only safe bounded text/facts remain. |
| MCP-05-05 per-call facts | Requirement unmet | Same-iteration mixed/repeated/concurrent metadata is atomic and correct; across-iteration native collision leaves duplicate IDs, F-002. |
| MCP-05-06 persistence/JSONL | Requirement unmet | Typed pairs with actual entry IDs round-trip normally; F-001 exposes runtime configuration and F-002 prevents a completed mixed turn being stored. |
| MCP-05-07 human export decision | Requirement unmet in aggregate | Markdown default off/opt-in safe summaries and unchanged CSV entry columns/safe cells pass; full structured JSONL and entry metadata flag behavior pass, but session-header/all-session CSV snapshot leak remains F-001. |
| MCP-05-08 failures/cancellation | Supported | Real protocol/tool/malformed/RPC/transport/timeout failures, blocked sanitizer outcome, safe fixed codes, cancellation propagation and public cleanup/owner retry all pass. The session-snapshot privacy finding still applies to production session creation generally. |

## Ten acceptance-criterion assessments with source evidence

“Supported” describes the reviewed boundary, not a separate overall verdict. Mandatory gaps remain even where surrounding tests pass.

'''
criteria=[
('WS05-AC01','Supported','Core mcp.py:179–231 provides one public DTO with optional nonnegative original/final byte counts and fixed failure codes, state/ingestion validation; schemas.py:29–40 preserves the four positional fields; Transcript models:55–136 loads and omits optional native provenance. Built dependency edge and isolated typed wheel round-trip pass.','packages/friday-core/src/friday_core/mcp.py','179–231','command-01.log'),
('WS05-AC02','Unmet, F-001','Real peer audit confirms original names/arguments/env execute. Direct records, request prose/extra fields, continuation/history, raw capture and entry arguments become empty; literal/escaped/normalized/partial echoes and safe DEBUG/error outputs pass. Production session config snapshot persists configured MCP env; JSONL and all-session CSV expose it. User-authored prose remains untouched.','packages/friday-chat/src/friday_chat/adapters.py','1313–1324','independent-probes-final-delivery.log'),
('WS05-AC03','Supported','Output policy preflights tiny caps, bounds final UTF-8 text after prefix/normalization/escape/wrapper/notice growth. Public direct caps 100,128,256,65536,300000; empty/exact/over/multibyte cases, loop tiny-cap no RPC/no fabricated record, and actual streaming/nonstreaming/fallback result limits pass.','packages/friday-chat/src/friday_chat/tools/output.py','51–150,221–236','test_independent.py'),
('WS05-AC04','Supported','Explicit high-risk normalization/detection/block with no detection samples/logging/raw/quarantine; capacities cover retained prefix above default. Offset 220000 attack blocks; one intact enclosing marker survives peer closing-marker injection. Sanitizer exception/repr never enters persisted/diagnostic output. Decoded-text double supplements accepted wire-bound real peers.','packages/friday-chat/src/friday_chat/tools/output.py','51–92,116–150,152–236','test_independent.py'),
('WS05-AC05','Supported','Client boolean isError and malformed flag/content get fixed safe failure; bridge records correct failed/blocked codes, unknown original sizes remain absent, cancellation propagates. Real peer tool_error/invalid_result/RPC/transport/timeout, sanitizer exception, tiny preflight, public stop/retry failure ownership and restart pass.','packages/friday-mcp/src/friday_mcp/client/base.py','255–294','independent-probes-final-delivery.log'),
('WS05-AC06','Unmet, F-002','Public bridge returns exact per-server/original/canonical facts; concurrent repeated names and same-iteration mixed, missing/invalid/repeated MCP IDs pass. Later native ID colliding with earlier MCP ID remains duplicated across iterations; continuation and records are ambiguous.','packages/friday-chat/src/friday_chat/tools/loop.py','79–160','finding-results-candidate.json'),
('WS05-AC07','Unmet, F-001 and F-002','Normal typed calls/results and actual entry correlation round-trip; fake context log and safe entry raw/capture paths pass, negative pairs/status/IDs/correlation/ingestion reject. Session snapshot is unsafe and production across-iteration mixed turn now fails persistence. Storage source/schema unchanged; no migration.','packages/friday-transcript/src/friday_transcript/models/transcript.py','55–136,263–320','finding-results-candidate.json'),
('WS05-AC08','Unmet, F-001','Entry-level JSONL full provenance and metadata-disabled omission, Markdown default-off/bounded escaped opt-in, existing CSV entry columns/summaries, markup/control/native compatibility pass. JSONL session header and public all-session CSV copy runtime env in config snapshot. No claim that metadata=False is a global session privacy filter; runtime-only secret exclusion is independent.','packages/friday-transcript/src/friday_transcript/exporters/jsonl.py','68–84,162–205','export-all-repro-candidate.log'),
('WS05-AC09','Unmet for mixed native persistence, F-002; remaining boundaries supported','Required parity, Agent/Core/Runtime/Memory suites and selection tests pass. WS-04 selection/reservation/memory floor source remains outside changed set; accepted lifecycle/registry ownership and public retry/cleanup pass. No direct dedicated MCP long-term ingestion, telemetry emission, HTTP/SSE/resources/prompts/live refresh or new config/server feature appears. Ordinary conversation-memory contract is unchanged.','packages/friday-chat/src/friday_chat/turns/processor.py','299–364,444–548','scope-audit.json'),
('WS05-AC10','Scope/evidence obligations supported; aggregate requirements still unmet','Exact allowed paths and narrow dependency/lock delta, all17 checks/exits/full outputs, real local-peer synthetic UAT, isolated wheel imports, reproduced baselines, public vs defensive cleanup and start/closeout hashes provided. Required commands2/7/9 retain reproduced predecessor/environment failures. F-001/F-002 preclude a clean aggregate.','packages/friday-transcript/pyproject.toml','dependencies','scope-audit.json')]
report+='| Criterion | Assessment | Source and independent evidence |\n| --- | --- | --- |\n'
for name,result,body,path,lines,log in criteria:report+=f'| {name} | {result} | {body} Source: {source(path,lines)}. Evidence: {artifact(log)}. |\n'
report+='''
## Independent public probe coverage and results

Final independent public-boundary matrix: **22 passed, 5 failed, 3.99 seconds, exit 1**. The five failures are the four production snapshot cases of F-001 and the cross-iteration collision case of F-002. Full captured DEBUG output and tracebacks are preserved; passing paths did not leak argument/error/unsafe sentinels. The synthetic configured env value is expected only in the explicit F-001 leak artifacts. This suite is independently authored in scratch and imports no candidate test/fixture implementation. Existing workspace deterministic FakeChatModel substitutes only for the paid/external model service.

Exact final matrix command, cwd repository, with no environment synchronization/network access:

```sh
LITELLM_LOCAL_MODEL_COST_MAP=true UV_CACHE_DIR=/private/tmp/friday-uv-cache UV_NO_SYNC=true UV_OFFLINE=true PYTHONDONTWRITEBYTECODE=1 uv run pytest /private/tmp/VAL-011-independent-20260928/test_independent.py -q --tb=short -p no:cacheprovider --basetemp=/private/tmp/VAL-011-independent-20260928/probe-final-delivery-tmp
```

| Public boundary/probe | Execution and assertions | Final result |
| --- | --- | --- |
| Two real stdio peers | Actual provider/manager/client/transport discover `Probe.Run`, `Aux.Read` on alpha/beta; original-name and argument/env dispatch is audited as booleans, not value copies | Pass |
| Direct bridge + final caps | Cap matrix, exact/empty/oversized/multibyte, normalization/HTML expansion, truncation/fixed failure notices, wrapper escaping and large retained attack | Pass |
| Wire-bound/decoded-text limit distinction | Real Unicode peer uses 24k UTF-8 under inherited 64KiB wire-line bound; public registry callable double supplies larger decoded text at 65536/300000 caps and attack offset220000 | Pass; not a transport allocation/token claim |
| Echo/capture redaction | Literal, JSON-escaped, normalized and partial argument echoes; MCP request content and extra raw fields removed before history/raw/fallback/continuation | Pass |
| Atomic per-call facts | Concurrent alpha/beta repeated tool names, exact provenance route, missing/invalid/duplicate/same-response native IDs | Pass |
| Protocol and failures | Real isError, malformed flag/content, RPC errors, peer exit, timeout, sanitizer exception; fixed accurate codes/status and safe DEBUG/repr | Pass |
| Actual turn matrix | Streaming/nonstreaming × fake/production × normal/pending fallback; bounded result, safe raw/capture/history, actual SQLite entry correlations and typed per-call facts | Four fake cases pass; four production cases fail only F-001 sentinel absence |
| Negative stored contracts | Invalid entry correlation, unmatched pairs, mismatch sizes/status/IDs, forbidden ingestion, old/native serialization | Pass |
| Later native collision | Two iterations reuse ID in MCP then native execution with real storage | Fail, F-002 |
| Shutdown while memory awaits | Public bridge shuts down before planned MCP execution; safe captured pending request, no invented completed call/persistence | Pass |
| Public lifecycle | Stop clears metadata/owned names/connections; all children exited, streams EOF, no owned tasks alive; injected public cleanup failure retains owner for retry, retry/restart succeeds | Pass |
| Human exporters | Attacker-like server/original labels, controls/markup, escaped bounded summaries, full original structured JSONL and old/native format parity | Pass except known session snapshot leak |
| Public all-session CSV follow-up | Export actual successful-turn SQLite session on candidate and baseline, inspect session and entry files separately | Confirms F-001 in sessions.csv only |

Own source and evidence: [final probes](VAL-011-evidence.tar.gz#test_independent.py), [real peer](VAL-011-evidence.tar.gz#peer.py), [final full log](VAL-011-evidence.tar.gz#independent-probes-final-delivery.log), [alpha audit](VAL-011-evidence.tar.gz#audit-alpha.jsonl), [beta audit](VAL-011-evidence.tar.gz#audit-beta.jsonl), [standalone finding runner](VAL-011-evidence.tar.gz#run_findings.py), [CSV follow-up runner](VAL-011-evidence.tar.gz#export_all_repro.py).

Fixtures assert public cleanup **before** defensive teardown. In `finally`, every child is drained in 4096-byte chunks, killed if necessary and reaped under time limits; remaining owned tasks are cancelled/joined under time limits even after assertion failure. Public assertions separately verify cleared metadata, empty owned registry and connections, EOF/returncode and no live owned tasks. The standalone candidate and baseline fact files show all five public cleanup booleans true. Defensive cleanup success is not substituted for a public lifecycle pass.

Scratch harness adjustments are disclosed, with original logs retained: initial echo assertions incorrectly expected an echoed argument to survive intentional argument redaction; early ASCII-escaped oversized Unicode exceeded the inherited stdio wire-line limit. Final peer emits real UTF-8 (`ensure_ascii=False`), real bounded peers are retained, and the public decoded-text callable supplements sizes above that wire bound. The first probe log was 10 failed/15 passed; after redaction and wire-bound corrections the intermediate counts were 5 failed/20 passed, then 10 failed/16 passed when the new UTF-8 peer still escaped JSON, then 5 failed/21 passed, and final 5 failed/22 passed. Full earlier logs and retained script versions are included. The first missing wheel-import-script setup attempt was fixed in scratch before successful isolated verification; no product source was changed. None of these harness corrections excuses a candidate failure.

## Required commands — exact executions and full output evidence

All 17 exact request commands were run independently. Commands 1–14 use the request prefix `LITELLM_LOCAL_MODEL_COST_MAP=true UV_CACHE_DIR=/private/tmp/friday-uv-cache UV_NO_SYNC=true UV_OFFLINE=true PYTHONDONTWRITEBYTECODE=1`. Cwd is the repository. Extra scratch-only environment: `PYTEST_ADDOPTS=-p no:cacheprovider`, `MYPY_CACHE_DIR=/private/tmp/VAL-011-independent-20260928/mypy-cache`, `TMPDIR=/private/tmp/VAL-011-independent-20260928/runtime-tmp`. Per-command JSON records exact strings, cwd, environment, UTC start/end and exit; full logs are unfiltered. No new ignores, filtered typing output or silent skipped gate were used.

'''
results={1:'201 passed, 3.60s',2:'548 passed, 5 skipped; 1 PTY acknowledgement failure and 3 localhost fixture PermissionErrors, 12.17s',3:'34 passed, 0.22s',4:'209 passed, 10 warnings, 0.15s',5:'416 passed, 7.91s',6:'680 passed, 1 skipped, 1 warning, 9.23s',7:'73 passed; 1 board task-count failure, 50.72s',8:'All checks passed',9:'Stops before project checking on installed NumPy __init__.pyi:737 unsupported type-statement syntax for Python3.10 target',10:'Success: no issues in all12 changed sources; unfiltered Python3.13 target',11:'Resolved208 packages; lock consistent',12:'Board valid:23 tasks',13:'Rendered documents current',14:'PASS:350 Markdown files',15:'No whitespace/diff errors',16:'No governed product/test/config working-tree delta vs candidate',17:'No delta in four frozen implementation reports'}
report+='| # | Exact command | Exit | Observed result | Full evidence |\n| --- | --- | --- | --- | --- |\n'
for i in range(1,18):
 d=load(f'command-{i:02}.json');report+=f'| {i} | `{d["command"]}` | {d["exit_code"]} | {results[i]} | {artifact(f"command-{i:02}.json","execution")} / {artifact(f"command-{i:02}.log","output")} |\n'
report+='''
## Independently reproduced predecessor baselines and harness limits

The full approved base was extracted with read-only `git archive`, with original imports selected using baseline package-source PYTHONPATH. Existing workspace `.venv` supplied allowed installed dependencies; `UV_PROJECT_ENVIRONMENT` explicitly selected it and no synchronization/network calls occurred. Baseline import logs verify `friday_chat`, `friday_core` and `friday_transcript` paths under the archive, not editable candidate source. Exact baseline commands, environment, cwd and exits are preserved in JSON and full logs.

| Baseline | Exit and reproduced result | Candidate relationship | Evidence |
| --- | --- | --- | --- |
| Full Chat on approved base | 1;479 passed,5 skipped, same PTY acknowledgement assertion and same3 localhost bind PermissionErrors,11.14s | Failing test sources unchanged; environment fixtures fail at127.0.0.1 ephemeral-port bind. Not a new WS-05 source failure, and candidate fullChat is still recorded failed | [command/env](VAL-011-evidence.tar.gz#baseline-chat.json) / [output](VAL-011-evidence.tar.gz#baseline-chat.log) |
| Full integration on archived base | 1;68 passed, same board task-count failure plus archive harness's absent Git-catalog docs error,50.61s | Board asserts22, canonical board validates23; test unchanged. Missing Git metadata is a separate scratch harness limitation | [command/env](VAL-011-evidence.tar.gz#baseline-integration.json) / [output](VAL-011-evidence.tar.gz#baseline-integration.log) |
| Read-only catalog repair, baseline board/docs subset | 1;11 passed, one same board-count failure,2.05s | Docs checker passes after a wrapper only answering `git ls-files --cached --others --exclude-standard` from saved approved-base tree catalog. No Git repository mutation | [command/env](VAL-011-evidence.tar.gz#baseline-catalog-recheck.json) / [output](VAL-011-evidence.tar.gz#baseline-catalog-recheck.log) / [wrapper](VAL-011-evidence.tar.gz#catalog-bin/git) |
| Default five-package mypy on approved base | 2; same installed NumPy __init__.pyi:737 type-statement syntax error | Same target/environment limitation; does not prove project typing pass. Required unfiltered changed-source Python3.13 run does pass | [command/env](VAL-011-evidence.tar.gz#baseline-mypy.json) / [output](VAL-011-evidence.tar.gz#baseline-mypy.log) |
| Targeted F-001 on approved base | Diagnostic runner0; env survives session config, JSONL on/off and all-session CSV | Inherited requirement gap, no waiver under approved WS-05 boundary | [facts](VAL-011-evidence.tar.gz#finding-results-baseline.json) / [all-session CSV](VAL-011-evidence.tar.gz#export-all-repro-baseline.log) |
| Targeted F-002 on approved base | Diagnostic runner0; ambiguous duplicate IDs, no exception, one persisted entry added | Candidate adds persistence failure for same completed mixed turn; upstream ambiguity inherited | [facts](VAL-011-evidence.tar.gz#finding-results-baseline.json) |

[Baseline extraction/execution](VAL-011-evidence.tar.gz#baseline.py), [original imports](VAL-011-evidence.tar.gz#baseline-imports.log), [catalog repair](VAL-011-evidence.tar.gz#baseline_catalog.py), [exact approved catalog](VAL-011-evidence.tar.gz#baseline-git-catalog.txt) and [unchanged failing-source proof](VAL-011-evidence.tar.gz#scope-audit.json) make the comparisons reproducible. Historical four `profiles.py` mypy errors were not asserted as current failures and were not used as a waiver.

## Offline package/import check and dependency assessment

Candidate Transcript, Core and Telemetry package trees were copied using read-only candidate Git archive into scratch. Cached offline build tools produced three wheels. Tool versions: `uv 0.11.3` (Homebrew2026-04-01, aarch64), Python3.13.10 in the fresh venv, wheel generator `hatchling1.32.4`. Built METADATA declares Transcript → `friday-framework-core==0.1.0a2`, Core → Telemetry with Pydantic/settings/structlog. No reverse Transcript edge or dependency cycle exists. `uv.lock` adds only the declared Core requirement/edge in Transcript; there are no new third-party versions/upgrades. The exact built METADATA and dependency closure inventory are preserved.

'''
report+='| Package operation | Exact argv and environment record | Exit | Result/log |\n| --- | --- | --- | --- |\n'
for d in load('package-commands.json'):
 name=d['name'];log='package-'+name+'.log'
 report+=f'| {name} | `{json.dumps(d["command"])}`; env `{json.dumps(d["env"],sort_keys=True)}`; cwd scratch | {d["exit_code"]} | {artifact(log)} |\n'
report+='''
The clean offline `uv pip install` resolver **failed** because `pydantic-settings` was not in the registry cache. This is an explicit harness/package-check limitation, not a product source finding and not proof of a clean fresh resolver install. Network access was not attempted. The mandatory built-package/import check was completed using the permitted existing environment: only declared third-party dependency bytes were copied into the fresh venv, with requirement versions and markers checked recursively and without `.pth`, editable hooks or bytecode. Framework source was not copied from editable installs.

The fresh venv's Python ran with `-I`; extracted built wheels were the sole source of Core/Telemetry/Transcript imports. The script asserts all three `__file__` paths point inside the extracted-wheel root and no original repository `packages` path appears on `sys.path`; public Core DTO and Transcript SQLite/export/model imports and typed provenance JSON round-trip passed (exit0). Exact third-party closure: structlog, pydantic-settings, typing-inspection, typing-extensions, python-dotenv, pydantic, pydantic-core, annotated-types and aiosqlite. Each version, distribution requirement and copied file hash is recorded. This proves built artifact metadata/public import functionality without editable hooks; it does **not** prove network registry installation or complete clean resolver cache availability.

Evidence: [package harness](VAL-011-evidence.tar.gz#package_check.py), [build/install commands](VAL-011-evidence.tar.gz#package-commands.json), [built metadata](VAL-011-evidence.tar.gz#wheel-metadata.json), [acyclic scope/lock audit](VAL-011-evidence.tar.gz#scope-audit.json), [isolated fallback harness](VAL-011-evidence.tar.gz#package_fallback.py), [dependency versions/file hashes](VAL-011-evidence.tar.gz#isolated-declared-dependencies.json), [isolated import script](VAL-011-evidence.tar.gz#wheel-import.py), [exact import invocation](VAL-011-evidence.tar.gz#package-imports-fallback.json), [successful import output](VAL-011-evidence.tar.gz#package-imports-fallback.log). All three wheels are archived under `wheels/` and hashed in the manifest.

## Documentation, configuration, migration and remaining gates

The candidate report describes the approved output/provenance/export decision, controlled baseline failures and package checks, but its broad safe-persistence/ID handling claims do not cover the two independently demonstrated failures. Required bounded remediation must correct the actual behavior and its report, then freeze a new candidate for fresh independent review. No remediation is automatically authorized by this report.

No configuration model/schema, shared Agent sanitizer, SQLite storage source/schema, RuntimeKernel registry-wide policy or dependency version was changed by this review. Candidate schema changes are optional DTO/model fields and the declared Transcript Core edge; old/native serialization is retained by explicit validators/omission. The no-migration claim is supported by aggregate scope and existing JSON encoding rather than a proposed migration. Direct dedicated MCP long-term ingestion and telemetry remain disabled/outside WS-05. Ordinary conversation memory remains the accepted existing behavior. No real credentials, external services, HTTP/network UAT, paid models or delivery were used.

Remaining gates: bounded controller/maintainer remediation authorization, a newly frozen candidate with regression evidence, independent validation of that candidate, explicit WS-05 maintainer acceptance, future aggregate pre-merge review and all later-phase/delivery approvals. Current VAL-011 does not advance acceptance or authorize later work.

## Complete authority/report inventory

All inventory hashes below were checked against the request, working bytes and pinned revision at start and closeout. The exact authority source copies and candidate reports are archived; the request/frozen manifest also enumerate their revisions and every tracked product byte. This table is a source inventory, not an adoption of historical conclusions.

| Input | Revision/hash SHA-256 | Exact bytes |
| --- | --- | --- |
'''
f=load('inputs/docs/planning/active/friday-mcp/validation/VAL-011-frozen-inputs.json')
for item in [f['request'],*f['authority'],*f['candidate_reports']]:
 p=item['path'];member='inputs/candidate/'+p if item in f['candidate_reports'] and not (OUT/'inputs'/p).exists() else 'inputs/'+p
 report+=f'| `{p}` | Revision `{item.get("revision","request preparation metadata")}`; `{item["sha256"]}` | {artifact(member,"source")} |\n'
report+='''
## Artifact manifest and byte preservation

`evidence.json` enumerates every archived report/source/script/log/probe/wheel/input member with exact byte size and SHA-256. The manifest excludes itself from its own member hash list; `delivery.json` gives its exact hash, the report hash and archive hash. Archive-member set integrity and each decompressed member hash were independently checked after packaging. Archive members preserve original bytes; deterministic tar ownership/timestamps affect only container metadata. Original scripts and full logs, including intermediate scratch failures, are included. Runtime databases, cache/venv trees, extracted product trees, temporary export files and unrelated artifacts are deliberately omitted. The controller can preserve the full report byte-for-byte without editing its portable member references.

The sole overall outcome is **CHANGES_REQUESTED**.
'''
(OUT/'VAL-011-report.md').write_text(report)
print('report bytes',len(report.encode()))
