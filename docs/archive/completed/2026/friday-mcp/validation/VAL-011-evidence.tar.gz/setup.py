import hashlib,json,os,pathlib,subprocess,shutil,sys
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT=pathlib.Path('/private/tmp/VAL-011-independent-20260928')
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def fingerprint(name):
 p=ROOT/name
 if not p.exists() and not p.is_symlink(): return {'state':'absent'}
 files=sorted([x for x in p.rglob('*') if x.is_file() or x.is_symlink()]) if p.is_dir() else [p]
 h=hashlib.sha256()
 for f in files:
  b=('symlink:'+os.readlink(f)).encode() if f.is_symlink() else f.read_bytes()
  h.update(f.relative_to(ROOT).as_posix().encode()+b'\0'+b+b'\0')
 return {'state':'present','files':len(files),'sha256':h.hexdigest()}
def freeze(label):
 f=json.loads((ROOT/'docs/planning/active/friday-mcp/validation/VAL-011-frozen-inputs.json').read_text())
 errors=[]; checks={}
 for item in [f['request'],*f['authority'],*f['candidate_reports']]:
  p=item['path']; actual=sha((ROOT/p).read_bytes()); checks[p]=actual
  if actual!=item['sha256']: errors.append(p)
  if 'revision' in item and sha(git('show',item['revision']+':'+p))!=actual: errors.append('git:'+p)
 for p,expected in f['tracked_product_bytes'].items():
  actual=sha((ROOT/p).read_bytes())
  if actual!=expected or sha(git('show',f['candidate_commit']+':'+p))!=expected: errors.append(p)
 unrelated={p:fingerprint(p) for p in f['preserved_unrelated']}
 for p,expected in f['preserved_unrelated'].items():
  if unrelated[p]!=expected: errors.append('unrelated:'+p)
 result={'label':label,'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'status':git('status','--short').decode(),'request_manifest_sha256':sha((ROOT/'docs/planning/active/friday-mcp/validation/VAL-011-frozen-inputs.json').read_bytes()),'checked_product_files':len(f['tracked_product_bytes']),'authority_report_hashes':checks,'unrelated':unrelated,'errors':errors}
 (OUT/(label+'-freeze.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='authority_report_hashes'},indent=2))
 return f
if __name__=='__main__':
 f=freeze(sys.argv[1] if len(sys.argv)>1 else 'start')
 if len(sys.argv)==1:
  for item in [f['request'],{'path':'docs/planning/active/friday-mcp/validation/VAL-011-frozen-inputs.json'},*f['authority']]:
   target=OUT/'inputs'/item['path']; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(ROOT/item['path'],target)
  (OUT/'aggregate.diff').write_bytes(git('diff','--binary',f['base_commit']+'..'+f['candidate_commit']))
  (OUT/'aggregate-name-status.txt').write_bytes(git('diff','--name-status',f['base_commit']+'..'+f['candidate_commit']))
  with (OUT/'authority-numbered.txt').open('w') as dst:
   for item in f['authority']:
    dst.write('\nFILE '+item['path']+'\n')
    for i,line in enumerate((ROOT/item['path']).read_text().splitlines(),1): dst.write(f'{i:04d} {line}\n')
