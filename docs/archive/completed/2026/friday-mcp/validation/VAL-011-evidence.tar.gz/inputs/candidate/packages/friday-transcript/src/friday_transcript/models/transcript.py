"""
Transcript data models.

Defines the core data structures for conversation transcripts:
- TranscriptEntry: Single turn in a conversation (immutable once written)
- TranscriptSession: Session-level metadata and aggregates
- ToolCall/ToolResult: Tool execution tracking
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from hashlib import sha256
from typing import Any
from uuid import uuid4

from friday_core.mcp import MCPSafeIdentifier, MCPToolCallProvenance
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    TypeAdapter,
    field_validator,
    model_serializer,
    model_validator,
)


def mcp_provenance_summary(
    provenance: MCPToolCallProvenance,
) -> dict[str, str | int | bool | None]:
    """Bounded human-export fields; no raw original name or tool payload."""
    server = provenance.tool.server_name
    if len(server) > 64 or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", server) is None:
        server = (
            "mcp-server-"
            + sha256(server.encode("utf-8", errors="surrogatepass")).hexdigest()[:16]
        )
    return {
        "provider": "mcp",
        "server": server,
        "name": provenance.tool.canonical_name,
        "call_id": provenance.call_id,
        "status": provenance.status,
        "sanitization": provenance.output_sanitization_state,
        "truncated": provenance.result_truncated,
        "result_size_bytes": provenance.result_size_bytes,
        "model_result_size_bytes": provenance.model_result_size_bytes,
    }


class _MCPRecordingModel(BaseModel):
    """Optional typed MCP facts with unchanged native serialization shape."""

    mcp_provenance: MCPToolCallProvenance | None = None
    model_config = ConfigDict(hide_input_in_errors=True)

    @field_validator("mcp_provenance", mode="before")
    @classmethod
    def _load_provenance(cls, value: object) -> MCPToolCallProvenance | None:
        """Use the shared JSON contract for persisted arrays/strict tuples."""
        if value is None:
            return None
        try:
            if isinstance(value, MCPToolCallProvenance):
                return MCPToolCallProvenance.model_validate_json(
                    value.model_dump_json()
                )
            if isinstance(value, dict):
                return MCPToolCallProvenance.model_validate_json(json.dumps(value))
        except (TypeError, ValueError):
            raise ValueError("Invalid MCP transcript provenance") from None
        raise ValueError("Invalid MCP transcript provenance")

    @model_serializer(mode="wrap")
    def _serialize_optional_provenance(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, Any]:
        data: dict[str, Any] = handler(self)
        if self.mcp_provenance is None:
            data.pop("mcp_provenance", None)
        return data


class ToolCall(_MCPRecordingModel):
    """Record of a tool invocation by the assistant."""

    id: str = Field(description="Unique identifier for this tool call")
    name: str = Field(description="Name of the tool/function called")
    arguments: dict[str, Any] = Field(
        default_factory=dict, description="Arguments passed to the tool"
    )

    @model_validator(mode="after")
    def _validate_mcp_call(self) -> ToolCall:
        provenance = self.mcp_provenance
        if provenance is not None and (
            self.arguments
            or self.id != provenance.call_id
            or self.name != provenance.tool.canonical_name
            or provenance.output_sanitization_state == "not_checked"
        ):
            raise ValueError("MCP transcript call requires redacted, correlated facts")
        return self


class ToolResult(_MCPRecordingModel):
    """Result of a tool execution."""

    tool_call_id: str = Field(description="ID of the corresponding ToolCall")
    output: Any = Field(default=None, description="Result data from the tool")
    error: str | None = Field(
        default=None, description="Error message if execution failed"
    )

    @model_validator(mode="after")
    def _validate_mcp_result(self) -> ToolResult:
        provenance = self.mcp_provenance
        if provenance is not None:
            if self.tool_call_id != provenance.call_id or not isinstance(
                self.output, str
            ):
                raise ValueError("MCP transcript result requires correlated safe text")
            if self.error is not None and self.error != provenance.failure_code:
                raise ValueError("MCP transcript error must be a fixed failure code")
            if provenance.model_result_size_bytes != len(self.output.encode("utf-8")):
                raise ValueError(
                    "MCP transcript result byte size does not match provenance"
                )
            if provenance.output_sanitization_state == "not_checked":
                raise ValueError(
                    "MCP transcript result must be checked before persistence"
                )
        return self


class TranscriptEntry(BaseModel):
    """
    Single turn in a transcript - immutable once written.

    Captures the complete record of a conversation turn including:
    - User and assistant messages
    - Tool calls and results
    - Timing information
    - Token usage metrics
    - Model/context information

    In multi-agent scenarios, agent_id tracks which agent generated
    the response for provenance and auditing.
    """

    # Identity
    id: str = Field(description="Unique identifier (UUID)")
    session_id: str = Field(description="Parent session identifier")
    turn_number: int = Field(description="Sequence number within session (1-indexed)")

    # Messages
    user_message: str | None = Field(
        default=None, description="User's input (None for system-initiated turns)"
    )
    assistant_message: str | None = Field(
        default=None, description="Assistant's response"
    )

    # Agent tracking (for multi-agent provenance)
    agent_id: str | None = Field(
        default=None,
        description="Which agent generated this response (e.g., 'researcher', 'coder')",
    )
    workflow_id: str | None = Field(
        default=None,
        description="Workflow identifier for execution provenance",
    )
    execution_id: str | None = Field(
        default=None,
        description="Workflow execution identifier for provenance",
    )
    pipeline_id: str | None = Field(
        default=None,
        description="Pipeline identifier for execution provenance",
    )
    task_id: str | None = Field(
        default=None,
        description="Task identifier for execution provenance",
    )
    assignment_id: str | None = Field(
        default=None,
        description="Assignment identifier for execution provenance",
    )
    llm_service: str | None = Field(
        default=None,
        description="Resolved runtime LLM service name for the entry",
    )
    provider_name: str | None = Field(
        default=None,
        description="LLM provider attribution for the entry",
    )

    # Tool execution
    tool_calls: list[ToolCall] = Field(
        default_factory=list, description="Tools invoked by assistant"
    )
    tool_results: list[ToolResult] = Field(
        default_factory=list, description="Results from tool executions"
    )

    # Timing
    timestamp: datetime = Field(
        default_factory=datetime.now, description="When the turn started"
    )
    response_started_at: datetime | None = Field(
        default=None, description="When first token was received"
    )
    response_completed_at: datetime | None = Field(
        default=None, description="When last token was received"
    )

    # Metrics
    prompt_tokens: int | None = Field(default=None, description="Tokens in the prompt")
    completion_tokens: int | None = Field(
        default=None, description="Tokens in the completion"
    )
    total_tokens: int | None = Field(default=None, description="Total tokens used")
    latency_ms: float | None = Field(
        default=None, description="Total response time in milliseconds"
    )

    # Context
    model_name: str | None = Field(default=None, description="Which LLM model was used")
    temperature: float | None = Field(
        default=None, description="Temperature setting used"
    )
    context_tokens_used: int | None = Field(
        default=None, description="How much of context window was filled"
    )

    # Extensible metadata
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata"
    )

    # Processing state
    consolidated: bool = Field(
        default=False,
        description="Whether this entry has been extracted to long-term memory",
    )
    compacted: bool = Field(
        default=False,
        description=(
            "Whether this entry has been summarized by "
            "InSessionCompactor and excluded from raw history "
            "retrieval."
        ),
    )

    model_config = ConfigDict(frozen=False, hide_input_in_errors=True)

    @model_validator(mode="after")
    def validate_mcp_correlations(self) -> TranscriptEntry:
        """MCP records require unique paired facts and real entry correlations."""
        mcp_calls = [
            call for call in self.tool_calls if call.mcp_provenance is not None
        ]
        mcp_results = [
            result for result in self.tool_results if result.mcp_provenance is not None
        ]
        if not mcp_calls and not mcp_results:
            return self
        try:
            TypeAdapter(MCPSafeIdentifier).validate_python(self.id)
        except ValueError:
            raise ValueError("Invalid MCP transcript entry identifier") from None
        call_ids = [call.id for call in self.tool_calls]
        result_ids = [result.tool_call_id for result in self.tool_results]
        for call in mcp_calls:
            matches = [
                result for result in mcp_results if result.tool_call_id == call.id
            ]
            if (
                call_ids.count(call.id) != 1
                or result_ids.count(call.id) != 1
                or len(matches) != 1
                or matches[0].mcp_provenance != call.mcp_provenance
            ):
                raise ValueError("MCP transcript requires unique paired provenance")
        for result in mcp_results:
            if not any(call.id == result.tool_call_id for call in mcp_calls):
                raise ValueError("MCP transcript result has no paired call")
            facts = result.mcp_provenance
            if facts is not None and facts.transcript_correlation_id not in {
                None,
                self.id,
            }:
                raise ValueError("MCP transcript correlation does not match entry")
        return self

    @model_validator(mode="after")
    def sync_provenance_metadata(self) -> TranscriptEntry:
        """Mirror workflow provenance fields into metadata and load from metadata."""
        provenance_fields = (
            "workflow_id",
            "execution_id",
            "pipeline_id",
            "task_id",
            "assignment_id",
            "llm_service",
            "provider_name",
        )
        metadata = dict(self.metadata)
        for field_name in provenance_fields:
            field_value = getattr(self, field_name)
            if field_value is None and field_name in metadata:
                setattr(self, field_name, metadata[field_name])
            elif field_value is not None:
                metadata[field_name] = field_value
        self.metadata = metadata
        return self

    def compute_latency(self) -> float | None:
        """Compute latency from timestamps if not explicitly set."""
        if self.latency_ms is not None:
            return self.latency_ms
        if self.timestamp and self.response_completed_at:
            delta = self.response_completed_at - self.timestamp
            return delta.total_seconds() * 1000
        return None


class TranscriptSession(BaseModel):
    """
    Session-level metadata for a conversation transcript.

    Tracks session lifecycle and aggregates for analytics.
    """

    session_id: str = Field(description="Unique session identifier")
    user_id: str | None = Field(default=None, description="User identifier (if known)")
    started_at: datetime = Field(
        default_factory=datetime.now, description="Session start time"
    )
    ended_at: datetime | None = Field(
        default=None, description="Session end time (None if active)"
    )

    # Configuration snapshot
    model_name: str = Field(description="Primary model used for this session")
    system_prompt: str | None = Field(default=None, description="System prompt used")
    config_snapshot: dict[str, Any] = Field(
        default_factory=dict, description="Configuration at session start"
    )

    # Aggregates (updated as entries are added)
    total_turns: int = Field(default=0, description="Number of turns in session")
    total_tokens: int = Field(default=0, description="Total tokens used")
    total_latency_ms: float = Field(
        default=0.0, description="Cumulative latency in milliseconds"
    )

    # Extensible metadata
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional session metadata"
    )

    # Archive state
    archived: bool = Field(
        default=False,
        description="Whether this session is archived (excluded from context assembly)",
    )

    def is_active(self) -> bool:
        """Check if session is still active."""
        return self.ended_at is None


class ContextLogEntry(BaseModel):
    """
    Raw prompt and response data for context engineering analysis.

    Stores the full messages array sent to the LLM and the complete response,
    enabling deep analysis of context engineering while keeping the entries
    table clean and lean.

    Relationship:
    - Primary: sessions -> context_log (one-to-many via session_id)
    - Optional: entries -> context_log (via entry_id for joining)
    """

    id: str = Field(
        default_factory=lambda: str(uuid4()),
        description="Unique identifier for this context log entry",
    )
    session_id: str = Field(
        ...,
        description="FK to sessions.session_id (primary relationship)",
    )
    turn_number: int = Field(
        ...,
        description="Turn number for ordering within session",
    )
    entry_id: str | None = Field(
        default=None,
        description="Optional FK to entries.id for joining with transcript entries",
    )
    raw_prompt: str = Field(
        ...,
        description="JSON-serialized messages array sent to LLM",
    )
    raw_response: str | None = Field(
        default=None,
        description="JSON-serialized LLM response with metadata",
    )
    captured_at: datetime = Field(
        default_factory=datetime.now,
        description="Timestamp when this context was captured",
    )
