import email,json,os,pathlib,subprocess,sys,tarfile,zipfile
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=pathlib.Path('/private/tmp/VAL-011-independent-20260928');TARGET=OUT/'package-input';TARGET.mkdir(exist_ok=True);WHEELS=OUT/'wheels';WHEELS.mkdir(exist_ok=True)
env=os.environ.copy();env.update({'UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1'})
results=[]
def run(name,cmd,cwd=OUT):
 with (OUT/f'package-{name}.log').open('wb') as log:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'cwd':str(cwd),'env':{'UV_CACHE_DIR':env['UV_CACHE_DIR'],'UV_OFFLINE':env['UV_OFFLINE'],'PYTHONDONTWRITEBYTECODE':env['PYTHONDONTWRITEBYTECODE']},'exit_code':r.returncode})
 (OUT/'package-commands.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,(OUT/f'package-{name}.log').read_text(errors='replace')[-1600:],flush=True)
 if r.returncode:sys.exit(r.returncode)
run('tools',['uv','--version'])
archive=OUT/'package-input.tar';archive.write_bytes(subprocess.check_output(['git','archive','2388e747ba1bf8157881230ad36ae3ef3272b807','packages/friday-transcript','packages/friday-core','packages/friday-telemetry'],cwd=ROOT))
with tarfile.open(archive) as tf:tf.extractall(TARGET,filter='data')
for name in ['telemetry','core','transcript']:run('build-'+name,['uv','build','--offline','--wheel',str(TARGET/'packages'/('friday-'+name)),'--out-dir',str(WHEELS)])
metadata={}
EXTRACT=OUT/'extracted-wheels';EXTRACT.mkdir(exist_ok=True)
for wheel in sorted(WHEELS.glob('*.whl')):
 with zipfile.ZipFile(wheel) as z:
  z.extractall(EXTRACT);m=email.message_from_bytes(z.read(next(p for p in z.namelist() if p.endswith('/METADATA'))));metadata[wheel.name]={'Requires-Dist':m.get_all('Requires-Dist'),'name':m['Name'],'version':m['Version']}
(OUT/'wheel-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
assert 'friday-framework-core==0.1.0a2' in next(v['Requires-Dist'] for v in metadata.values() if v['name']=='friday-framework-transcript')
VENV=OUT/'wheel-venv';run('venv',['uv','venv','--offline',str(VENV)])
run('install',['uv','pip','install','--offline','--python',str(VENV/'bin/python'),*[str(w) for w in sorted(WHEELS.glob('*.whl'))]])
code='''import json,pathlib,sys\nsys.path.insert(0,sys.argv[1])\nimport friday_core,friday_transcript,friday_telemetry\nfrom friday_core.mcp import MCPToolMetadata,MCPToolCallProvenance\nfrom friday_transcript import ToolCall,ToolResult,TranscriptEntry,SQLiteTranscriptStore,JSONLExporter,MarkdownExporter,CSVExporter\nroot=pathlib.Path(sys.argv[1]);modules=[friday_core,friday_transcript,friday_telemetry]\nfor module in modules:\n assert pathlib.Path(module.__file__).is_relative_to(root);print(module.__name__,module.__file__)\nassert not any('agent-framework/packages' in p for p in sys.path)\nmeta=MCPToolMetadata(canonical_name='mcp_local_probe',server_name='local',original_name='Probe',transport='stdio',trust_level='local')\nfacts=MCPToolCallProvenance(tool=meta,call_id='wheel-call',status='succeeded',output_sanitization_state='sanitized',model_result_size_bytes=2,transcript_correlation_id='wheel-entry')\nentry=TranscriptEntry(id='wheel-entry',session_id='wheel-session',turn_number=1,tool_calls=[ToolCall(id='wheel-call',name='mcp_local_probe',mcp_provenance=facts)],tool_results=[ToolResult(tool_call_id='wheel-call',output='ok',mcp_provenance=facts)])\nassert TranscriptEntry.model_validate_json(entry.model_dump_json())==entry\nprint('Extracted-wheel public imports, declared dependencies and typed round-trip PASS')\n'''
(OUT/'wheel-import.py').write_text(code)
run('imports',[str(VENV/'bin/python'),'-I',str(OUT/'wheel-import.py'),str(EXTRACT)])
