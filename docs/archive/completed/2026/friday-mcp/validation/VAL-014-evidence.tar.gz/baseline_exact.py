import os,pathlib,json,subprocess,time
out=pathlib.Path('/private/tmp/val014-independent');root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');base=out/'base';r=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-014-request.yaml').read_text());env=os.environ.copy();env.update({k:v for k,v in r['environment'].items() if k!='permitted'});env.update(UV_PROJECT_ENVIRONMENT=str(root/'.venv'),PYTEST_ADDOPTS='-p no:cacheprovider',MYPY_CACHE_DIR=str(out/'baseline-mypy-cache'));env['PYTHONPATH']=os.pathsep.join(str(p/'src') for p in (base/'packages').glob('*') if (p/'src').is_dir());rows=[]
commands=[(f'B{i:02d}-exact',r['required_commands'][i-1]) for i in [3,4,8,9,10]]+[('B09-common','uv run --no-sync ruff check packages/friday-memory packages/friday-chat packages/friday-transcript')]
for identity,cmd in commands:
 log=out/(identity+'.log');start=time.time()
 with log.open('w') as f:
  f.write('$ '+cmd+'\nbase source selected through PYTHONPATH; installed interpreter selected through UV_PROJECT_ENVIRONMENT; no sync\n');f.flush();p=subprocess.run(cmd,shell=True,executable='/bin/zsh',cwd=base,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=420)
 rows.append({'id':identity,'command':cmd,'cwd':str(base),'exit':p.returncode,'seconds':round(time.time()-start,3),'log':log.name});(out/'baselines-exact.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
