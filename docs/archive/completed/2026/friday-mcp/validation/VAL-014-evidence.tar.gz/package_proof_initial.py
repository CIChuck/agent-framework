import pathlib,subprocess,os,json,zipfile,email,importlib.metadata as im,shutil,sys
from packaging.requirements import Requirement
from packaging.markers import default_environment
from packaging.utils import canonicalize_name
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');out=pathlib.Path('/private/tmp/val014-independent');src=out/'package-sources';wheels=out/'wheels';src.mkdir(exist_ok=True);wheels.mkdir(exist_ok=True)
env=os.environ.copy();env.update(UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_NO_SYNC='true',LITELLM_LOCAL_MODEL_COST_MAP='true',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
rows=[]
for pkg in sorted((root/'packages').glob('friday-*')):
 if not (pkg/'pyproject.toml').exists():continue
 target=src/pkg.name;shutil.copytree(pkg,target,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','dist','*.egg-info'),dirs_exist_ok=True)
 cmd=['uv','build','--wheel','--offline','--no-build-isolation','--out-dir',str(wheels),str(target)]
 p=subprocess.run(cmd,cwd=out,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'build-{pkg.name}.log').write_text(p.stdout);rows.append(dict(command=cmd,exit=p.returncode,log=f'build-{pkg.name}.log'));print(pkg.name,p.returncode,flush=True)
(out/'builds.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit'] for r in rows):sys.exit(1)
venv=out/'isolated';subprocess.run([sys.executable,'-m','venv','--without-pip',str(venv)],check=True);site=next((venv/'lib').glob('python*/site-packages'))
framework={}
for wheel in wheels.glob('*.whl'):
 with zipfile.ZipFile(wheel) as z:
  meta=email.message_from_bytes(z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))));framework[canonicalize_name(meta['Name'])]=(wheel,meta)
queue=[('friday-chat',set()),('friday-framework-memory',set()),('friday-framework-transcript',set()),('friday-framework-core',set())];done={};edges=[];copied=[]
while queue:
 name,extras=queue.pop(0);name=canonicalize_name(name)
 if name in done and extras<=done[name]:continue
 extras=extras|done.get(name,set());done[name]=extras
 if name in framework:
  wheel,meta=framework[name]
  with zipfile.ZipFile(wheel) as z:z.extractall(site)
  version=meta['Version'];requires=meta.get_all('Requires-Dist',[]);copied.append({'name':name,'version':version,'origin':wheel.name})
 else:
  dist=im.distribution(name);version=dist.version;requires=dist.requires or []
  for f in dist.files or []:
   rel=pathlib.Path(str(f))
   if rel.is_absolute() or '..' in rel.parts or rel.suffix=='.pth':continue
   source=pathlib.Path(dist.locate_file(f)).resolve()
   if not source.is_file():continue
   if '/site-packages/' not in str(source):raise RuntimeError('non-distribution source '+str(source))
   target=site/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
  copied.append({'name':name,'version':version,'origin':'installed non-editable distribution files'})
 for raw in requires:
  req=Requirement(raw);active=not req.marker or any(req.marker.evaluate({**default_environment(),'extra':x}) for x in extras|{''})
  if not active:continue
  dependency=canonicalize_name(req.name);v=framework[dependency][1]['Version'] if dependency in framework else im.version(dependency)
  if v not in req.specifier:raise RuntimeError('version mismatch '+raw+' '+v)
  edges.append({'parent':name,'requirement':raw,'resolved':v,'marker_active':active});queue.append((dependency,set(req.extras)))
(out/'declared-dependencies.json').write_text(json.dumps({'edges':edges,'distributions':copied,'python':sys.version,'site':str(site)},indent=2)+'\n')
clean=out/'clean-resolver';p=subprocess.run(['uv','venv','--offline',str(clean)],env=env,cwd=out,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=p.stdout
p=subprocess.run(['uv','pip','install','--offline','--python',str(clean/'bin/python'),'--find-links',str(wheels),'friday-chat==0.1.0a2'],env=env,cwd=out,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log+=p.stdout;(out/'clean-install.log').write_text(log);(out/'clean-install.json').write_text(json.dumps({'exit':p.returncode,'mode':'offline resolver install'},indent=2)+'\n')
print('ISOLATED_READY',site,'declared dependency edges',len(edges),'distributions',len(done),'clean resolver exit',p.returncode,flush=True)
