import pathlib,json,hashlib,subprocess
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');out=pathlib.Path('/private/tmp/val014-independent');r=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-014-request.yaml').read_text());f=json.loads((root/r['preservation_manifest']).read_text());h=lambda b:hashlib.sha256(b).hexdigest();difflist=subprocess.check_output(['git','diff','--name-only',r['diff_range']],cwd=root,text=True).splitlines();allowed=set(r['allowed_product_paths']+r['allowed_test_paths']+[r['allowed_implementation_report']]+r['allowed_controller_artifacts']);violations=set(difflist)-allowed;changed_source=[x for x in difflist if '/src/' in x];source=r['allowed_product_paths'];revisions=[]
for group in ['authority','candidate_report_hashes','builder_evidence']:
 for a in r[group]:
  b=subprocess.check_output(['git','show',a['revision']+':'+a['path']],cwd=root);revisions.append({'path':a['path'],'revision':a['revision'],'sha256':h(b),'matches':h(b)==a['sha256']})
products=[]
for path,sha in f['tracked_product_bytes'].items():
 b=subprocess.check_output(['git','show',r['candidate_commit']+':'+path],cwd=root);products.append({'path':path,'sha256':h(b),'matches':h(b)==sha})
base=[]
for path in subprocess.check_output(['git','ls-tree','-r','--name-only',r['base_commit']],cwd=root,text=True).splitlines():
 p=out/'base'/path
 if p.is_file():
  original=subprocess.check_output(['git','show',r['base_commit']+':'+path],cwd=root);base.append({'path':path,'sha256':h(p.read_bytes()),'matches':p.read_bytes()==original})
result={'diff_paths':difflist,'outside_allowed':sorted(violations),'source_paths_exact':set(changed_source)==set(source),'candidate_revision_hashes':revisions,'candidate_products':products,'base_archive_files':base,'request_matches':h((root/f['request']['path']).read_bytes())==f['request']['sha256'],'request_sha256':h((root/f['request']['path']).read_bytes()),'manifest_sha256':h((root/r['preservation_manifest']).read_bytes()),'candidate_prepared_is_ancestor':subprocess.run(['git','merge-base','--is-ancestor',r['candidate_commit'],'548da4e'],cwd=root).returncode==0}
(out/'scope-and-revision-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'outside_allowed':result['outside_allowed'],'source_paths_exact':result['source_paths_exact'],'candidate_inputs':len(revisions),'candidate_products':len(products),'base_files':len(base),'all_hashes_match':all(x['matches'] for x in revisions+products+base),'request_matches':result['request_matches']}))
