import subprocess,os,json,time,pathlib
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); dest=pathlib.Path('/private/tmp/val014-independent')
request=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-014-request.yaml').read_text()); env=os.environ.copy();env.update({k:v for k,v in request['environment'].items() if k!='permitted'});env.update(PYTEST_ADDOPTS='-p no:cacheprovider',MYPY_CACHE_DIR=str(dest/'mypy-cache'))
results=[]
for i,cmd in enumerate(request['required_commands'],1):
 log=dest/f'check-{i:02d}.log';start=time.time()
 with log.open('w') as f:
  f.write('$ '+cmd+'\n');f.flush()
  try:
   p=subprocess.run(cmd,shell=True,executable='/bin/zsh',cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=420);code=p.returncode
  except subprocess.TimeoutExpired:code=124;f.write('\nVALIDATOR TIMEOUT 420s\n')
 row=dict(id=f'C{i:02d}',command=cmd,cwd=str(root),exit=code,seconds=round(time.time()-start,3),log=log.name);results.append(row);(dest/'checks.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
