import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');out=pathlib.Path('/private/tmp/val014-independent');r=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-014-frozen-inputs.json').read_text());results={};mismatch=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
for group in ['authority','candidate_reports','builder_evidence','historical_evidence']:
 results[group]=[]
 for row in r[group]:
  actual=sha((root/row['path']).read_bytes());results[group].append({'path':row['path'],'sha256':actual,'matches':actual==row['sha256']})
  if actual!=row['sha256']: mismatch.append(row['path'])
for path,expected in r['tracked_product_bytes'].items():
 actual=sha((root/path).read_bytes());results.setdefault('product',[]).append({'path':path,'sha256':actual,'matches':actual==expected})
 if actual!=expected:mismatch.append(path)
results['unrelated']={}
for path,expected in r['unrelated'].items():
 p=root/path
 if not p.exists():actual={'state':'absent'}
 else:
  fs=sorted(x for x in p.rglob('*') if x.is_file()) if p.is_dir() else [p];h=hashlib.sha256()
  for f in fs:h.update(str(f.relative_to(root)).encode()+b'\0'+f.read_bytes()+b'\0')
  actual={'state':'present','files':len(fs),'sha256':h.hexdigest()}
 results['unrelated'][path]={'actual':actual,'matches':actual==expected}
 if actual!=expected:mismatch.append(path)
results['request_sha256']=sha((root/'docs/planning/active/friday-mcp/validation/VAL-014-request.yaml').read_bytes());results['manifest_sha256']=sha((root/'docs/planning/active/friday-mcp/validation/VAL-014-frozen-inputs.json').read_bytes());results['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();results['status']=subprocess.check_output(['git','status','--short'],cwd=root,text=True);results['mismatches']=mismatch
(out/('freeze-'+sys.argv[1]+'.json')).write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'groups':{g:len(results[g]) for g in ['authority','candidate_reports','builder_evidence','historical_evidence','product']},'unrelated':results['unrelated'],'mismatches':mismatch,'head':results['head']}))
