import os,pathlib,json,subprocess,time
out=pathlib.Path('/private/tmp/val014-independent');root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');base=out/'base';request=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-014-request.yaml').read_text());env=os.environ.copy();env.update({k:v for k,v in request['environment'].items() if k!='permitted'});env.update(PYTEST_ADDOPTS='-p no:cacheprovider',MYPY_CACHE_DIR=str(out/'baseline-mypy-cache'));env['PYTHONPATH']=os.pathsep.join(str(p/'src') for p in (base/'packages').glob('*') if (p/'src').is_dir());rows=[]
for i in [3,4,8,9,10]:
 cmd=request['required_commands'][i-1];args=cmd.split()[3:];executable=root/'.venv/bin'/args[0];log=out/f'base-check-{i:02d}.log';start=time.time()
 with log.open('w') as f:
  f.write('$ '+cmd+'\nimmutable base via absolute installed executable; PYTHONPATH contains only base src directories\n');f.flush()
  try:p=subprocess.run([str(executable),*args[1:]],cwd=base,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=420);code=p.returncode
  except subprocess.TimeoutExpired:code=124;f.write('\nTIMEOUT\n')
 rows.append({'id':f'B{i:02d}','command':cmd,'actual_argv':[str(executable),*args[1:]],'cwd':str(base),'exit':code,'seconds':round(time.time()-start,3),'log':log.name});(out/'baselines.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
