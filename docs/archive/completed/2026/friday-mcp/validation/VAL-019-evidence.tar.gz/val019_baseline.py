import json,os,pathlib,subprocess,time
base=pathlib.Path('/private/tmp/val019-baseline');root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); python=str(root/'.venv/bin/python');src=[str(p) for p in sorted((base/'packages').glob('*/src'))];env=os.environ.copy();env.update(PYTHONPATH=os.pathsep.join(src),PYTHONDONTWRITEBYTECODE='1',PYTEST_ADDOPTS='-p no:cacheprovider',LITELLM_LOCAL_MODEL_COST_MAP='true',MYPY_CACHE_DIR='/private/tmp/val019-baseline-mypy',TMPDIR='/private/tmp')
checks=[['-m','pytest','-q','packages/friday-chat/tests_chat/test_reorganization_terminal.py::test_provider_free_pty_acknowledges_before_bounded_progress_completes','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_chat_adapter_controls_reach_final_http_json','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_chat_adapter_typed_stream_reuses_generation_defaults','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_provider_option_target_mismatch_fails_before_http'],['-m','pytest','-q','tests/integration/test_development_board.py::test_repository_development_board_is_valid_and_rendered'],['-m','mypy','--python-version','3.13','packages/friday-memory/src/friday_memory']]
results=[]
for i,args in enumerate(checks,1):
 log=pathlib.Path(f'/private/tmp/val019-baseline-{i}.log');print('START',i,args,flush=True);t=time.time()
 with log.open('wb') as f:p=subprocess.run([python,*args],cwd=base,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 o={'id':i,'exit':p.returncode,'seconds':round(time.time()-t,1),'log':str(log)};results.append(o);print('DONE',o,flush=True)
pathlib.Path('/private/tmp/val019-baseline-results.json').write_text(json.dumps(results,indent=2))
