import asyncio, json, sys, tempfile
from pathlib import Path
from friday_chat.adapters import FrameworkTranscriptAdapter
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import FakeChatModel, build_runtime
from friday_chat.tools.mcp import MCPChatRegistry
from friday_chat.turns.models import ChatModelResponse, ToolCallRequest
from friday_chat.turns.processor import TurnProcessor
from friday_transcript import SQLiteTranscriptStore
PEER=Path('/Users/chuckrussell/Dev/gendev/agent-framework/packages/friday-chat/tests_chat/fixtures/mcp_execution_peer.py')
async def main():
 spawned=[]; orig=asyncio.create_subprocess_exec
 async def track(*a,**kw):
  p=await orig(*a,**kw);spawned.append(p);return p
 asyncio.create_subprocess_exec=track
 base={"enabled":True,"mode":"selected","include_categories":["mcp"],"config":{"servers":[{"name":"demo","command":sys.executable,"args":[str(PEER)],"required":True}],"limits":{"max_result_bytes":256,"reserved_tool_result_tokens":80,"min_memory_retrieval_tokens":100}}}
 with tempfile.TemporaryDirectory(dir='/private/tmp',prefix='val019-probe-') as tmp:
  cfg=FridayChatConfig.model_validate({'tools':{'context':{'max_budget_ratio':1.0},'providers':{'mcp':base}}})
  runtime=build_runtime(cfg);bridge=MCPChatRegistry(runtime.tools,cfg.tools.mcp_provider,tmp);runtime.tools=runtime.mcp_tools=bridge
  store=SQLiteTranscriptStore(Path(tmp)/'probe.sqlite');runtime.transcript=FrameworkTranscriptAdapter(store,cfg,'val019')
  runtime.chat_llm=FakeChatModel('fake',responses=[ChatModelResponse(tool_calls=(ToolCallRequest('mcp_demo_read_file',{'case':'success'},'call-1'),)),ChatModelResponse.from_text('done')])
  try:
   await runtime.start_mcp_tools();names=[x.name for x in bridge.list_tools()];assert 'mcp_demo_read_file' in names and 'mcp_demo_other_tool' in names
   runtime.tool_selection.inject_manual(('mcp_demo_read_file',))
   result=await TurnProcessor(runtime).process('Read file via demo')
   assert result.assistant_message=='done' and len(result.tool_calls)==1
   call=result.tool_calls[0];assert call.mcp_provenance and call.mcp_provenance.tool.canonical_name=='mcp_demo_read_file'
   assert 'completed Read.File' in call.result and call.mcp_provenance.ingestion_decision=='disabled'
   entry=(await store.get_entries('val019'))[0];assert entry.tool_calls[0].mcp_provenance==entry.tool_results[0].mcp_provenance
   failed=await bridge.call_tool_record('mcp_demo_read_file',{'case':'badcontent'})
   assert failed.mcp_provenance and failed.mcp_provenance.failure_code=='invalid_result'
   diag=bridge.provider.operational_diagnostics
   print(json.dumps({'category_names':[n for n in names if n.startswith('mcp_')],'chat_result':result.assistant_message,'provenance':call.mcp_provenance.model_dump(mode='json'),'checked_failure':failed.mcp_provenance.failure_code,'diagnostic_counts':{'registered':diag.provider.registered_tools if hasattr(diag,'provider') else None}},default=str))
  finally:await bridge.stop()
  assert not bridge.provider.owned_tool_names and bridge.provider.manager and not bridge.provider.manager.connected_servers
  optional={"enabled":True,"mode":"selected","include_categories":["mcp"],"config":{"servers":[{"name":"missing","command":"/private/tmp/val019-command-does-not-exist","required":False}]}}
  cfg2=FridayChatConfig.model_validate({'tools':{'providers':{'mcp':optional}}});rt2=build_runtime(cfg2);b2=MCPChatRegistry(rt2.tools,cfg2.tools.mcp_provider,tmp)
  try:await b2.start();assert not b2.tool_metadata;print('optional_missing_category=started')
  finally:await b2.stop()
  optional['include_tools']=['mcp_missing_read_file'];cfg3=FridayChatConfig.model_validate({'tools':{'providers':{'mcp':optional}}});rt3=build_runtime(cfg3);b3=MCPChatRegistry(rt3.tools,cfg3.tools.mcp_provider,tmp)
  try:
   try:await b3.start()
   except Exception as e:print('optional_missing_explicit_include=',type(e).__name__)
   else:raise AssertionError('explicit include unexpectedly succeeded')
  finally:await b3.stop()
  assert all(p.returncode is not None and p.stdout.at_eof() and p.stderr.at_eof() for p in spawned)
  print('owned_children_settled=',len(spawned))
asyncio.run(main())
