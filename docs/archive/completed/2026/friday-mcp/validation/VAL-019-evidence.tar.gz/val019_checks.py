import json,os,pathlib,subprocess,sys,time
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); Q=json.loads((R/'docs/planning/active/friday-mcp/validation/VAL-019-request.yaml').read_text()); cmds=Q['required_checks'][:11]; env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_ADDOPTS='-p no:cacheprovider',MYPY_CACHE_DIR='/private/tmp/val019-mypy',RUFF_CACHE_DIR='/private/tmp/val019-ruff',TMPDIR='/private/tmp')
results=[]
for i,cmd in enumerate(cmds,1):
 print('START',i,cmd,flush=True); t=time.time(); log=pathlib.Path(f'/private/tmp/val019-check-{i:02}.log')
 with log.open('wb') as f:
  try:p=subprocess.run(cmd,shell=True,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 result={'id':i,'command':cmd,'exit':code,'seconds':round(time.time()-t,1),'log':str(log)};results.append(result);print('DONE',result,flush=True);pathlib.Path('/private/tmp/val019-check-results.json').write_text(json.dumps(results,indent=2))
