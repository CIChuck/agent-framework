import asyncio,json,sys,tempfile
from pathlib import Path
from friday_chat.adapters import FrameworkMemoryAdapter,FrameworkTranscriptAdapter
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import FakeChatModel,build_runtime
from friday_chat.tools.mcp import MCPChatRegistry
from friday_chat.turns.models import ChatModelResponse,ToolCallRequest
from friday_chat.turns.processor import TurnProcessor
from friday_memory import CollectionManager,InMemoryEpisodicStore,MemoryController,NullGraphStore
from friday_transcript import SQLiteTranscriptStore
PEER='/Users/chuckrussell/Dev/gendev/agent-framework/packages/friday-chat/tests_chat/fixtures/mcp_execution_peer.py'
class Embeddings:
 def __init__(self):self.writes=0
 async def embed_documents(self,texts):self.writes+=len(texts);return [[1.0,0.0,0.0,0.0] for _ in texts]
 async def embed_query(self,text):return [1.0,0.0,0.0,0.0]
async def main():
 spawned=[];orig=asyncio.create_subprocess_exec
 async def tracked(*a,**kw):
  p=await orig(*a,**kw);spawned.append(p);return p
 asyncio.create_subprocess_exec=tracked
 with tempfile.TemporaryDirectory(dir='/private/tmp',prefix='val019-memory-') as tmp:
  cfg=FridayChatConfig.model_validate({'tools':{'context':{'max_budget_ratio':1.0},'providers':{'mcp':{'enabled':True,'mode':'selected','include_tools':['mcp_demo_read_file'],'config':{'servers':[{'name':'demo','command':sys.executable,'args':[PEER],'required':True}],'limits':{'max_result_bytes':256,'reserved_tool_result_tokens':80,'min_memory_retrieval_tokens':100},'ingestion':{'long_term_memory_enabled':True,'opted_in_tools':['mcp_demo_read_file']}}}}}})
  runtime=build_runtime(cfg);bridge=MCPChatRegistry(runtime.tools,cfg.tools.mcp_provider,tmp);runtime.tools=runtime.mcp_tools=bridge
  embed=Embeddings();manager=CollectionManager(embed,path=str(Path(tmp)/'vectors'));episodic=InMemoryEpisodicStore();graph=NullGraphStore();controller=MemoryController(manager.short_term,graph,episodic,manager)
  runtime.memory=FrameworkMemoryAdapter(controller,manager,cfg,'val019-memory',episodic,graph)
  store=SQLiteTranscriptStore(Path(tmp)/'transcript.sqlite');runtime.transcript=FrameworkTranscriptAdapter(store,cfg,'val019-memory')
  runtime.chat_llm=FakeChatModel('fake',responses=[ChatModelResponse(tool_calls=(ToolCallRequest('mcp_demo_read_file',{'case':'success'},'mcall'),)),ChatModelResponse.from_text('done')])
  try:
   await runtime.start_mcp_tools();runtime.tool_selection.inject_manual(('mcp_demo_read_file',));result=await TurnProcessor(runtime).process('Read demo data')
   call=result.tool_calls[0];entry=(await store.get_entries('val019-memory'))[0];saved=await manager.find_mcp_snapshot(entry.id,call.call_id)
   assert saved is not None and saved.state=='committed' and call.mcp_provenance.memory_ingested and call.mcp_provenance.memory_correlation_id==saved.snapshot.record_id
   assert saved.snapshot.call==entry.tool_calls[0].mcp_provenance==entry.tool_results[0].mcp_provenance
   print(json.dumps({'memory_state':saved.state,'record_id':saved.snapshot.record_id,'embedding_writes':embed.writes,'receipt_entry':entry.id,'ingestion':call.mcp_provenance.ingestion_decision,'telemetry_ingestion_counts':bridge.provider.operational_diagnostics.ingestion_decisions},default=str))
  finally:await bridge.stop()
  assert all(p.returncode is not None and p.stdout.at_eof() and p.stderr.at_eof() for p in spawned)
  print('owned_children_settled=',len(spawned))
asyncio.run(main())
