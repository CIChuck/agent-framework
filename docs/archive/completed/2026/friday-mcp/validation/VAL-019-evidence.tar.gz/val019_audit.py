import hashlib,json,pathlib,subprocess,sys
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); Q=json.loads((R/'docs/planning/active/friday-mcp/validation/VAL-019-request.yaml').read_text()); M=json.loads((R/Q['product_manifest']).read_text()); phase=sys.argv[1] if len(sys.argv)>1 else 'start'
def sha(x):return hashlib.sha256(x).hexdigest()
def blob(commit,p):
 z=subprocess.run(['git','show',f'{commit}:{p}'],cwd=R,capture_output=True);return z.stdout if z.returncode==0 else None
changed=subprocess.check_output(['git','diff','--name-only',f"{Q['baseline_commit']}..{Q['candidate_commit']}"],cwd=R,text=True).splitlines()
print('phase',phase,'branch',subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip(),'HEAD',subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip());print('authority',len(Q['authority']),'all working hash match',all((R/a['path']).exists() and sha((R/a['path']).read_bytes())==a['sha256'] for a in Q['authority']))
print('diff count',len(changed),'matches exact manifest',set(changed)==set(M['full_changed_paths']),'product',len(M['product_paths']),'process',len(M['process_paths']),'partition',set(changed)==set(M['product_paths'])|set(M['process_paths']),'disjoint',not(set(M['product_paths'])&set(M['process_paths'])))
prod=[]
for p,h in M['product_paths'].items():
 c=blob(Q['candidate_commit'],p);w=(R/p).read_bytes() if (R/p).exists() else None
 if c is None or sha(c)!=h or w is None or sha(w)!=h:prod.append((p, None if c is None else sha(c),None if w is None else sha(w),h))
print('product hash mismatches',prod)
def fingerprints(x,prefix):
 if isinstance(x,str):return {prefix:x}
 if x is None:return {prefix:None}
 d={}
 for k,v in x.items():d.update(fingerprints(v,prefix+k))
 return d
flat={}
for k,v in M['unrelated'].items():flat.update(fingerprints(v,k if not isinstance(v,dict) else k))
out={p:(sha((R/p).read_bytes()) if (R/p).is_file() else None) for p in flat}
print('unrelated root paths',list(M['unrelated']),'file fingerprints',len(flat),'mismatches',[(p,flat[p],out[p]) for p in flat if flat[p]!=out[p]])
path=f'/private/tmp/val019-{phase}-fingerprints.json';pathlib.Path(path).write_text(json.dumps(out,indent=2,sort_keys=True));print('snapshot',path)
