import json,hashlib,pathlib,subprocess
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');req=json.loads((root/'docs/planning/active/friday-mcp/validation/VAL-016-request.yaml').read_text());manifest=json.loads((root/'docs/planning/active/friday-mcp/execution/WS-07-product-manifest.json').read_text());start=json.loads(pathlib.Path('/private/tmp/val016_scope_start.json').read_text())
authority={x['path']:hashlib.sha256((root/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in req['authority']}
product={p:hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in manifest['changed_product_paths'].items()}
items={}
for p in manifest['unrelated']:
 f=root/p
 if f.is_file():items[p]={'state':'present','files':1,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
 elif f.is_dir():
  files=sorted(x for x in f.rglob('*') if x.is_file())
  items[p]={'state':'present','files':len(files),'entries':[(str(x.relative_to(root)),hashlib.sha256(x.read_bytes()).hexdigest()) for x in files]}
 else:items[p]={'state':'absent'}
unrelated={p:json.loads(json.dumps(items[p]))==start[p] for p in start}
changed=subprocess.check_output(['git','diff','--name-only',req['base_commit'],req['candidate_commit']],cwd=root,text=True).splitlines()
status=subprocess.check_output(['git','status','--short','--branch'],cwd=root,text=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
revision_changes=subprocess.check_output(['git','diff','--name-only',req['candidate_commit'],'HEAD','--','packages'],cwd=root,text=True).splitlines()
result={'authority':authority,'product':product,'unrelated':unrelated,'aggregate_paths':changed,'exact_manifest':set(changed)==set(manifest['changed_product_paths']),'head':head,'head_package_changes_since_candidate':revision_changes,'status':status}
pathlib.Path('/private/tmp/val016_close.json').write_text(json.dumps(result,indent=2,sort_keys=True))
print('authority',len(authority),all(authority.values()))
print('product',len(product),all(product.values()))
print('unrelated',len(unrelated),all(unrelated.values()))
print('exact_manifest',result['exact_manifest'],'head_package_changes',revision_changes)
print(status)
