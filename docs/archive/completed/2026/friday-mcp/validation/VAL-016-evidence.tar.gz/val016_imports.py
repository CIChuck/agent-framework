import pathlib,sys,json,hashlib,zipfile,importlib
wheels=pathlib.Path('/private/tmp/val016_wheels');out=pathlib.Path('/private/tmp/val016_dist');out.mkdir(exist_ok=True)
roots=[]
for wheel in sorted(wheels.glob('*.whl')):
 target=out/wheel.stem;target.mkdir(exist_ok=True)
 with zipfile.ZipFile(wheel) as z:z.extractall(target)
 roots.append(str(target))
sys.path[:0]=roots
modules=['friday_telemetry','friday_telemetry.models.mcp','friday_telemetry.helpers.mcp','friday_mcp.client.adapter','friday_runtime.mcp_loading','friday_chat.tools.mcp','friday_chat.memory_mcp','friday_chat.turns.processor']
paths={}
for name in modules:
 mod=importlib.import_module(name);p=str(mod.__file__);assert p.startswith(str(out)),(name,p);paths[name]=p
from friday_telemetry import MCPEvent,MCPTelemetryHelper,DebugTelemetryRecorder
rec=DebugTelemetryRecorder();MCPTelemetryHelper(rec).emit('tool_call_finish',server_id='hidden-server',tool_name='hidden-tool',reason='success')
assert len(rec.events)==1 and set(rec.events[0].data)=={'server_ref','tool_ref','reason'}
assert 'hidden' not in repr(rec.events)
assert MCPEvent(name='disconnect',reason='success').attributes()=={'reason':'success'}
print(json.dumps({'wheel_count':len(roots),'paths':paths,'event':{'name':rec.events[0].name,'keys':sorted(rec.events[0].data)}},indent=2))
