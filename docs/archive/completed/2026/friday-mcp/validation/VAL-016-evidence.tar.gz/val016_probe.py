import asyncio, importlib.util, json, pathlib, sys
from unittest.mock import AsyncMock
import pytest
from friday_agent import DefaultToolRegistry
from friday_mcp.client.manager import MCPClientManager
from friday_runtime.config import MCPToolProviderConfig
from friday_runtime.mcp_loading import RuntimeMCPProvider
from friday_runtime.tool_loading import ToolProviderLoadError
from friday_telemetry import DebugTelemetryRecorder

P=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,P/path)
 m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
fixture=load('val016_fixture','packages/friday-runtime/tests_runtime/test_mcp_loading.py')
execution=load('test_mcp_execution_security','packages/friday-chat/tests_chat/test_mcp_execution_security.py')
memorytest=load('val016_memory_fixture','packages/friday-chat/tests_chat/test_mcp_memory.py')
S='VAL016_SECRET_HEADER_ENV_COMMAND_CWD_SCHEMA_DESCRIPTION_ARGUMENT_RESULT_EXCEPTION_MEMORY'

def harness(monkeypatch, modes, catalogs):
 clients=[];tracker={'active':0,'peak':0,'discovery_active':0,'discovery_peak':0}
 def create(self, config):
  mode=modes.get(config.name,'good')
  if isinstance(mode,list):mode=mode.pop(0)
  c=fixture.TestClient(config.name,mode,tracker,catalogs.get(config.name,[]));clients.append(c);return c
 monkeypatch.setattr(MCPClientManager,'_create_client',create)
 return clients,tracker

async def settle(clients):
 for c in clients:
  c.transport.fail_cleanup=False;c.transport.pause_cleanup=False
  await c.disconnect()

@pytest.mark.asyncio
async def test_large_catalog_redaction_and_native_boundary(monkeypatch,tmp_path):
 tools=[{'name':'safe','inputSchema':{'type':'object'}}]+[{'name':f'bad{i}','description':S,'inputSchema':{'type':'object','description':S}} for i in range(3000)]
 clients,_=harness(monkeypatch,{}, {'peer':tools})
 cfg=MCPToolProviderConfig.from_dict({'enabled':True,'mode':'all','config':{'servers':[{'name':'peer','command':'fake','env':{'HEADER':S},'retry_attempts':0}], 'limits':{'max_tools_per_server':1}}})
 rec=DebugTelemetryRecorder();provider=RuntimeMCPProvider(cfg,str(tmp_path),rec);reg=DefaultToolRegistry()
 reg.register(name='native',func=lambda:'native',category='native')
 try:
  await provider.start();await provider.register_tools(reg)
  assert len(rec.get_all_events('mcp.tool_skipped'))==1
  assert rec.get_all_events('mcp.tool_skipped')[0]['count']==3000
  assert len(rec.events)<20
  assert reg.get('native') is not None
  c=provider.manager.get_client('peer');c.call_tool=AsyncMock(return_value=S)
  assert await reg.get_callable('mcp_peer_safe')(argument=S)==S
  assert c.call_tool.await_count==1
  assert S not in repr(rec.events)
  assert all(set(e.data)<={'server_ref','tool_ref','reason','count','required'} for e in rec.events)
 finally:
  await provider.stop();await settle(clients)

@pytest.mark.asyncio
async def test_retry_failure_cleanup_and_cancel_truth(monkeypatch,tmp_path):
 modes={'peer':['connection_failed','good']};clients,_=harness(monkeypatch,modes,{'peer':[{'name':'safe','inputSchema':{'type':'object'}}]})
 cfg=MCPToolProviderConfig.from_dict({'enabled':True,'mode':'all','config':{'servers':[{'name':'peer','command':'fake','retry_attempts':1,'required':True}]}})
 rec=DebugTelemetryRecorder();provider=RuntimeMCPProvider(cfg,str(tmp_path),rec)
 try:
  await provider.start()
  assert len(clients)==2
  assert [e.name for e in rec.events].count('mcp.connection_finish')==1
  assert [e.name for e in rec.events].count('mcp.connection_failure')==0
  await provider.stop()
  assert rec.events[-1].data['reason']=='success'
 finally:await settle(clients)
 # Failed discovery with cleanup failure must not export a successful disconnect.
 modes={'peer':'discovery_cleanup_failed'};clients,_=harness(monkeypatch,modes,{'peer':[]})
 cfg=MCPToolProviderConfig.from_dict({'enabled':True,'mode':'all','config':{'servers':[{'name':'peer','command':'fake','retry_attempts':0,'required':False}]}})
 rec=DebugTelemetryRecorder();provider=RuntimeMCPProvider(cfg,str(tmp_path),rec)
 try:
  with pytest.raises(ToolProviderLoadError):await provider.start()
  assert provider.lifecycle[0].outcome=='cleanup_failed'
  assert any(e.name=='mcp.disconnect' and e.data['reason']=='cleanup_failed' for e in rec.events)
  assert all(e.data['reason']!='success' for e in rec.events if e.name=='mcp.disconnect')
  clients[0].transport.fail_cleanup=False
  await provider.stop()
  assert rec.events[-1].data['reason']=='success'
 finally:await settle(clients)
 # Cancel a live discovery after connection. Exactly one failed list-tools outcome and owned cleanup.
 modes={'peer':'discovery_timeout'};clients,_=harness(monkeypatch,modes,{'peer':[]})
 rec=DebugTelemetryRecorder();provider=RuntimeMCPProvider(cfg,str(tmp_path),rec)
 try:
  task=asyncio.create_task(provider.start())
  for _ in range(100):
   if any(e.name=='mcp.list_tools_start' for e in rec.events):break
   await asyncio.sleep(.01)
  task.cancel()
  with pytest.raises(asyncio.CancelledError):await task
  assert len(rec.get_all_events('mcp.list_tools_failure'))==1
  assert rec.get_all_events('mcp.list_tools_failure')[0]['reason']=='cancelled'
  assert [e.name for e in rec.events].count('mcp.disconnect')==1
  assert not provider.manager.connected_servers
 finally:await settle(clients)

@pytest.mark.asyncio
async def test_collision_both_sources_without_exporting_names(monkeypatch,tmp_path):
 catalogs={'peer':[{'name':'Read.File','inputSchema':{'type':'object'}},{'name':'read-file','inputSchema':{'type':'object'}}]}
 clients,_=harness(monkeypatch,{},catalogs)
 cfg=MCPToolProviderConfig.from_dict({'enabled':True,'mode':'all','config':{'servers':[{'name':'peer','command':'fake','retry_attempts':0}]}})
 rec=DebugTelemetryRecorder();provider=RuntimeMCPProvider(cfg,str(tmp_path),rec)
 try:
  await provider.start()
  with pytest.raises(ToolProviderLoadError):await provider.register_tools(DefaultToolRegistry())
  d=provider.operational_diagnostics.registration_decisions[-1]
  assert d.collision is not None and d.collision.first.provider==d.collision.second.provider=='mcp'
  assert d.collision.first.original_name_summary.fingerprint!=d.collision.second.original_name_summary.fingerprint
  assert 'Read.File' not in repr(rec.events) and 'read-file' not in repr(rec.events)
  assert any(e.data.get('reason')=='name_collision' for e in rec.events)
 finally:await provider.stop();await settle(clients)

@pytest.mark.asyncio
async def test_chat_checked_outputs_and_memory_pending(monkeypatch,tmp_path):
 from friday_chat.runtime import build_runtime
 from friday_chat.tools.mcp import MCPChatRegistry
 from friday_chat.memory_mcp import persist_mcp_interaction
 from friday_chat.tools.output import MCPOutputPolicy
 # Fully local synthetic peer: same public bridge path, distinct assertions.
 runtime=build_runtime(execution.config())
 rec=DebugTelemetryRecorder();bridge=execution.install(runtime,tmp_path,telemetry=rec)
 try:
  await bridge.start()
  results=[]
  for case in ('large','unsafe','error'):
   record=await bridge.call_tool_record('mcp_peer_read_file',{'case':case,'token':S})
   results.append((case,record.mcp_provenance.failure_code,record.mcp_provenance.result_truncated))
  assert len(rec.get_all_events('mcp.tool_call_start'))==3
  assert len(rec.get_all_events('mcp.tool_output_decision'))==3
  assert S not in repr(rec.events)
  assert bridge.provider.operational_diagnostics.truncated_results>=1
 finally:await bridge.stop()
 # Actual storage owner and immutable receipt: false publication leaves pending, retry publishes same record.
 rt,mem,manager,store=memorytest.setup(tmp_path/'mem',enabled=True)
 call=MCPOutputPolicy(256).checked_record(execution.metadata(),'id','safe result',{})
 turn=memorytest.make_turn('val016-turn',calls=(call,))
 observed=[];orig=mem.publish_mcp_memory
 async def fail_publish(snapshot):return False
 monkeypatch.setattr(mem,'publish_mcp_memory',fail_publish)
 try:
  first=await persist_mcp_interaction(mem,rt.transcript,rt.config.tools.mcp_provider.config.ingestion,turn,observe=lambda n,o: observed.append(o))
  assert observed==['pending']
  owned=first[0].mcp_provenance.memory_correlation_id
  assert (await manager.get_mcp_snapshot(owned)).state=='pending'
  monkeypatch.setattr(mem,'publish_mcp_memory',orig)
  second=await persist_mcp_interaction(mem,rt.transcript,rt.config.tools.mcp_provider.config.ingestion,turn,observe=lambda n,o: observed.append(o))
  assert observed==['pending','published']
  assert second[0].mcp_provenance.memory_correlation_id==owned
  assert await store.count_entries('memory-session')==1
 finally:
  monkeypatch.setattr(mem,'publish_mcp_memory',orig)

@pytest.mark.asyncio
async def test_chat_budget_snapshot_rejection_and_no_rpc(tmp_path):
 from friday_chat.config import FridayChatConfig
 from friday_chat.runtime import FakeChatModel,build_runtime
 from friday_chat.turns.models import ChatModelResponse
 from friday_chat.turns.processor import TurnProcessor
 from friday_chat.tools.mcp import MCPChatRegistry
 bridge_tests=load('val016_bridge_fixture','packages/friday-chat/tests_chat/test_mcp_chat_bridge.py')
 values=bridge_tests.cfg().model_dump();values['tools']['context']['max_mcp_tools']=0
 rt=build_runtime(FridayChatConfig.model_validate(values));rec=DebugTelemetryRecorder()
 bridge=MCPChatRegistry(rt.tools,rt.config.tools.mcp_provider,str(tmp_path),telemetry=rec)
 rt.tools=bridge;rt.mcp_tools=bridge;rt.chat_llm=FakeChatModel('fake',responses=[ChatModelResponse.from_text('done')])
 try:
  result=await TurnProcessor(rt).process('read fixture')
  skips=rec.get_all_events('mcp.budget_skip')
  assert len(skips)==1 and skips[0]['reason']=='mcp_count_limit'
  assert bridge.provider.operational_diagnostics.budget_skips==1
  assert not rec.get_all_events('mcp.tool_call_start')
 finally:await rt.stop_mcp_tools()
