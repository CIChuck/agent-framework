import os, subprocess, time, json, pathlib
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
out=pathlib.Path('/private/tmp/val016_checks')
out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_NO_SYNC='true',LITELLM_LOCAL_MODEL_COST_MAP='true')
checks=[
('focused','uv run --no-sync pytest -q packages/friday-telemetry/tests_telemetry/test_mcp_telemetry.py packages/friday-runtime/tests_runtime/test_mcp_loading.py packages/friday-runtime/tests_runtime/test_mcp_registration.py packages/friday-mcp/tests_mcp/client/test_adapter.py packages/friday-mcp/tests_mcp/client/test_execution.py packages/friday-chat/tests_chat/test_mcp_chat_bridge.py packages/friday-chat/tests_chat/test_mcp_execution_security.py packages/friday-chat/tests_chat/test_mcp_turn_budget.py packages/friday-chat/tests_chat/test_mcp_memory.py'),
('telemetry','uv run --no-sync pytest -q packages/friday-telemetry/tests_telemetry'),
('runtime','uv run --no-sync pytest -q packages/friday-runtime/tests_runtime'),
('mcp','uv run --no-sync pytest -q packages/friday-mcp/tests_mcp'),
('chat','uv run --no-sync pytest -q packages/friday-chat/tests_chat'),
('integration','uv run --no-sync pytest -q tests/integration'),
('mcp_integration','uv run --no-sync pytest -q tests/integration/test_mcp_execution_provenance.py tests/integration/test_mcp_registry.py tests/integration/test_mcp_runtime_lifecycle.py tests/integration/test_mcp_memory_ingestion.py'),
('ruff','uv run --no-sync ruff check packages/friday-telemetry packages/friday-runtime packages/friday-mcp packages/friday-chat'),
('mypy','uv run --no-sync mypy --python-version 3.13 --follow-imports=silent packages/friday-telemetry/src/friday_telemetry/models/mcp.py packages/friday-telemetry/src/friday_telemetry/helpers/mcp.py packages/friday-runtime/src/friday_runtime/mcp_loading.py packages/friday-runtime/src/friday_runtime/di.py packages/friday-mcp/src/friday_mcp/client/adapter.py packages/friday-chat/src/friday_chat/runtime.py packages/friday-chat/src/friday_chat/tools/mcp.py packages/friday-chat/src/friday_chat/turns/processor.py packages/friday-chat/src/friday_chat/memory_mcp.py'),
('lock','uv lock --check --offline'),
('board_validate','uv run --no-sync python scripts/friday-dev-board.py validate'),
('board_next','uv run --no-sync python scripts/friday-dev-board.py next'),
('board_show','uv run --no-sync python scripts/friday-dev-board.py show friday-mcp'),
('board_render','uv run --no-sync python scripts/friday-dev-board.py render --check'),
('docs','uv run --no-sync python scripts/check-documentation-lifecycle.py'),
('diff_check','git diff --check c05882e45d78dc83ad48ee17b156aa9efff6fff0..2e36613eae6060a99c1255cce04fcb7a27bc7374')]
results=[]
for name,cmd in checks:
 print('START',name,flush=True)
 t=time.time()
 with (out/f'{name}.log').open('w') as f:
  p=subprocess.run(cmd,shell=True,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 rec=dict(name=name,cmd=cmd,exit=p.returncode,seconds=round(time.time()-t,1))
 results.append(rec)
 (out/'results.json').write_text(json.dumps(results,indent=2))
 print('END',rec,flush=True)
