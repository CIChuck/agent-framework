import pathlib,subprocess,os,time,json
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
out=pathlib.Path('/private/tmp/val016_wheels');out.mkdir(exist_ok=True)
logs=pathlib.Path('/private/tmp/val016_wheel_logs');logs.mkdir(exist_ok=True)
env=os.environ.copy();env.update(UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_NO_SYNC='true',LITELLM_LOCAL_MODEL_COST_MAP='true')
results=[]
for pyproject in sorted((root/'packages').glob('*/pyproject.toml')):
 name=pyproject.parent.name
 cmd=['uv','build','--wheel','--offline','--out-dir',str(out),str(pyproject.parent)]
 t=time.time()
 with (logs/f'{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 row={'package':name,'exit':p.returncode,'seconds':round(time.time()-t,1)};results.append(row)
 (logs/'results.json').write_text(json.dumps(results,indent=2))
 print(row,flush=True)
