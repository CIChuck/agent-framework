import os,pathlib,subprocess,json
base=pathlib.Path('/private/tmp/val016_base');repo=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join(str(p) for p in sorted((base/'packages').glob('*/src')))
env.update(UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_NO_SYNC='true',LITELLM_LOCAL_MODEL_COST_MAP='true')
python=repo/'.venv/bin/python'
checks={
 'chat_pty':['packages/friday-chat/tests_chat/test_reorganization_terminal.py::test_provider_free_pty_acknowledges_before_bounded_progress_completes'],
 'chat_bind':['packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_chat_adapter_controls_reach_final_http_json','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_chat_adapter_typed_stream_reuses_generation_defaults','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_provider_option_target_mismatch_fails_before_http'],
 'board_count':['tests/integration/test_development_board.py::test_repository_development_board_is_valid_and_rendered']}
results={}
with (pathlib.Path('/private/tmp/val016_baseline_import.log')).open('w') as f:subprocess.run([str(python),'-c','import friday_chat.runtime,friday_runtime.mcp_loading;print(friday_chat.runtime.__file__);print(friday_runtime.mcp_loading.__file__)'],cwd=base,env=env,stdout=f,stderr=subprocess.STDOUT)
for name,tests in checks.items():
 with pathlib.Path(f'/private/tmp/val016_baseline_{name}.log').open('w') as f:p=subprocess.run([str(python),'-m','pytest','-q',*tests],cwd=base,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
 results[name]=p.returncode;print(name,p.returncode,flush=True)
pathlib.Path('/private/tmp/val016_baseline_results.json').write_text(json.dumps(results,indent=2))
