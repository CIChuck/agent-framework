import asyncio
from unittest.mock import AsyncMock
from friday_core.mcp import MCPToolMetadata
from friday_mcp.client.adapter import MCPToolWrapper,MCPValidatedDefinition
from friday_telemetry import MCPTelemetryHelper

async def main():
 client=AsyncMock();client.call_tool.return_value='ok'
 m=MCPToolMetadata(canonical_name='mcp_peer_safe',server_name='peer',original_name='safe',transport='stdio',trust_level='local',discovery_state='discovered',schema_sanitization_state='sanitized',filter_state='included')
 w=MCPToolWrapper.from_validated(client,m,MCPValidatedDefinition('safe','{"type":"object"}'))
 def cancelled(*args):raise asyncio.CancelledError('recorder error')
 w.set_call_observer(cancelled)
 try:await w.execute()
 except BaseException as exc:print('observer_result',type(exc).__name__,'rpc_count',client.call_tool.await_count)
 class Recorder:
  def capture_event(self,*args):raise asyncio.CancelledError('recorder error')
 try:MCPTelemetryHelper(Recorder()).emit('connection_start',server_id='peer')
 except BaseException as exc:print('telemetry_result',type(exc).__name__)
asyncio.run(main())
