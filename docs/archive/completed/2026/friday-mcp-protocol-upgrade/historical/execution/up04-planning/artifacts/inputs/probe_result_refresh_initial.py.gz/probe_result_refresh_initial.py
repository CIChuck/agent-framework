"""Read-only synthetic protocol-peer planning probes; no network or product edits."""
import asyncio,json
from friday_mcp.client.base import MCPClientBase
from friday_mcp.client.adapter import MCPToolAdapter
from friday_mcp.exceptions import MCPToolExecutionError
from friday_mcp.protocols import MCPTransport

class Peer:
    def __init__(self):
        self.queue=asyncio.Queue();self.fail_list=False;self.calls=0;self.error_result=False
    async def connect(self):pass
    async def disconnect(self):pass
    @property
    def is_connected(self):return True
    async def receive(self):return await self.queue.get()
    async def send(self,message):
        method=message['method'];ident=message.get('id')
        if ident is None:return
        if method=='server/discover':
            result={'resultType':'complete','supportedVersions':['2026-07-28'],'capabilities':{'tools':{}},'ttlMs':0,'cacheScope':'private'}
        elif method=='tools/list':
            if self.fail_list:
                await self.queue.put({'jsonrpc':'2.0','id':ident,'error':{'code':-32603,'message':'synthetic discovery failure'}});return
            result={'resultType':'complete','ttlMs':0,'cacheScope':'private','tools':[{'name':'echo','inputSchema':{'type':'object'},'outputSchema':{'type':'object','properties':{'v':{'type':'integer'}},'required':['v']}}]}
        else:
            self.calls+=1
            result={'resultType':'complete','isError':True,'content':'not-a-content-list'} if self.error_result else {'resultType':'complete','content':[],'structuredContent':{'v':'not-an-integer'}}
        await self.queue.put({'jsonrpc':'2.0','id':ident,'result':result})

class Client(MCPClientBase):
    def __init__(self):
        super().__init__('synthetic',protocol_profile='modern');self.peer=Peer()
    async def _create_transport(self)->MCPTransport:return self.peer

async def run():
    c=Client();await c.connect();facts={}
    try:
        c.peer.error_result=True
        try:await c.call_tool('echo',{})
        except MCPToolExecutionError as exc:facts['malformed_isError_content_classification']=exc.failure_code
        c.peer.error_result=False
        adapter=MCPToolAdapter(c,prefix='mcp_probe_');initial=await adapter.get_tools()
        try:await c.call_tool('echo',{})
        except MCPToolExecutionError as exc:facts['pre_refresh_schema_enforced']=exc.failure_code=='invalid_result'
        c.peer.fail_list=True
        try:await adapter.get_tools(refresh=True)
        except Exception as exc:facts['explicit_refresh_failed']=type(exc).__name__
        stale=await adapter.get_tools()
        facts['adapter_returns_prior_wrappers_after_failure']=bool(stale) and stale[0] is initial[0]
        try:
            value=await stale[0].execute()
            facts['invalid_structured_result_accepted_after_failed_refresh']=json.loads(value)=={'v':'not-an-integer'}
        except MCPToolExecutionError:facts['invalid_structured_result_accepted_after_failed_refresh']=False
        facts['issued_calls']=c.peer.calls
    finally:await c.disconnect()
    facts['pending_requests_after_stop']=len(c._pending_requests)
    print(json.dumps({'profile':'2026-07-28 stdio-like synthetic in-memory transport','effects':'no network/processes/credentials/user stores','observations':facts},indent=2))
asyncio.run(run())
