from pathlib import Path
import hashlib,json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';d=b/'up06-baseline';revision='c90ed023a053943b63d085b70452bbbb11dd28e9'
if d.exists():raise RuntimeError('Baseline exists')
omitted=json.loads((b/'work-snapshot.json').read_text())['omitted_before_checkout']
subprocess.run(['git','clone','--no-checkout','--no-hardlinks',str(w),str(d)],check=True,capture_output=True)
subprocess.run(['git','config','core.sparseCheckout','true'],cwd=d,check=True)
f=d/'.git/info/sparse-checkout';f.write_text('/*\n'+''.join('!/'+x+'\n' for x in omitted));subprocess.run(['git','checkout',revision],cwd=d,check=True,capture_output=True)
if subprocess.check_output(['git','status','--porcelain'],cwd=d,text=True).strip():raise RuntimeError('Dirty baseline')
result={'root':str(d),'revision':revision,'omitted_before_checkout':omitted,'sparse_patterns_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'boundary':'Protected tracked contents excluded before checkout; path names only, no protected contents read; no product changes'};(b/'up06-baseline-snapshot.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'baseline':revision,'omitted_protected_paths':len(omitted),'source_edits':0}))
