from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';d=p/'execution/rem006-planning';directive=p/'directives/REM-MCP-UP-006-server-boundary-and-stdio-ownership.md';proposal=p/'proposals/REM-MCP-UP-006-authority-manifest.json';items=[]
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def req(c,m):
 if not c:raise RuntimeError(m)
def dump(f,j):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(j,indent=2)+'\n')
def archive(name,raw):
 f=d/'finalization-artifacts'/(name+'.gz');req(not f.exists(),'Archive overwrite');f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(gzip.compress(raw,mtime=0));items.append({'path':str(f.relative_to(d)),'original_path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(f),'encoding':'gzip'})
req(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()=='ec810869916ca6b605423c123c83177da26107b2','HEAD drift')
cmd=['git','diff','--cached','--check'];failed=subprocess.run(cmd,cwd=w,capture_output=True);req(failed.returncode==2,'Expected original whitespace failure');archive('original-whitespace-failure/stdout',failed.stdout);archive('original-whitespace-failure/stderr',failed.stderr);archive('original-whitespace-failure/receipt.json',(json.dumps({'argv':cmd,'exit_code':failed.returncode,'stdout_sha256':hashlib.sha256(failed.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(failed.stderr).hexdigest()},indent=2)+'\n').encode());archive('initial-proposal/directive.md',directive.read_bytes());archive('initial-proposal/authority-manifest.json',proposal.read_bytes());archive('initial-proposal/planning-manifest.json',(d/'manifest.json').read_bytes())
directive.write_text(directive.read_text().rstrip()+'\n');m=json.loads(proposal.read_text())
for x in m['controls']:
 if x['path']==str(directive.relative_to(w)):x['sha256']=h(directive)
dump(proposal,m)
for key,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show',m['initiative']],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 label='rem006-planning-corrected-'+key;subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP05.py'),label,'work',str(b/'venv/bin/python'),*args],check=True);req(json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']==0,'Corrected process check failed')
 for name in ['preflight.json','receipt.json','stdout','stderr']:archive('corrected-checks/'+key+'/'+name,(b/'checks'/label/name).read_bytes())
archive('finish_rem006_proposal.py',Path(__file__).read_bytes());dump(d/'finalization.json',{'status':'proposed/not_granted','proposal_sha256':h(proposal),'directive_sha256':h(directive),'initial_manifest_sha256':h(d/'manifest.json'),'artifacts':items,'correction':'Trim generated unapproved directive EOF whitespace only; initial failure/control bytes retained; six-path/four-finding scope unchanged'})
for x in m['controls']:req(h(w/x['path'])==x['sha256'],'Control drift')
for path,digest in m['full_original_product_hashes'].items():req(h(w/path)==digest,'Product drift')
for x in items:req(hashlib.sha256(gzip.decompress((d/x['path']).read_bytes())).hexdigest()==x['sha256'],'Archive drift')
paths=[str(x.relative_to(w)) for x in [directive,proposal,d]];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Propose bounded separate modern MCP server remediation'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(json.dumps({'proposal_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'product_paths':6,'findings':len(m['findings']),'source_edits':0,'implementation_authority':'not_granted'}))
