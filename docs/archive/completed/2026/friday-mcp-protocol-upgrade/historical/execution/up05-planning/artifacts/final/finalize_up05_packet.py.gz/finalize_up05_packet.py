from pathlib import Path
import hashlib,json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def dump(f,j):f.write_text(json.dumps(j,indent=2)+'\n')
if subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()!='0e794b2c42a0c75f4c28fb8dc6cc91194b26c435' or subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip():raise RuntimeError('HEAD or checkout drift')
sf=p/'execution/current-process-state.json';s=json.loads(sf.read_text());s['prior_unsuccessful_remediation_cycles']=0;s['prior_finding_disposition']={};dump(sf,s)
c=p/'up05-server-contract.md';text=c.read_text();text=text.replace('Registration of\nsynchronous blocking handlers is rejected or explicitly adapted without violating\nowned cancellation; do not add an unbounded thread/executor path.','Registration of\nsynchronous handlers is rejected; the modern API accepts cooperative async\nhandlers and the typed async registry bridge. Do not add a thread/executor path.');c.write_text(text)
manifest=p/'proposals/UP-05-authority-manifest.json';m=json.loads(manifest.read_text())
for row in m['controls']:
 if row['path']==str(c.relative_to(w)):row['sha256']=h(c)
dump(manifest,m)
log=p/'execution-log.md';log.write_text(log.read_text()+'\n\nFinal UP-05 planning reconciliation resets remediation-cycle counters for the new\nunit (UP-04 history remains in its accepted receipt/process snapshot) and fixes\nthe modern handler contract to cooperative async registration only, with no\nthread/executor adaptation. Proposed controls are re-pinned before any approval.\nThe reproducible initial planning command-count bookkeeping failure and script\nare retained losslessly; the corrected profile contains20 actual commands.\n')
for key,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show','friday-mcp-protocol-upgrade'],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 label='up05-planning-final-'+key;subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP05.py'),label,'work',str(b/'venv/bin/python'),*args],check=True)
 if json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']:raise RuntimeError('Planning check failed')
for row in m['controls']+m['prior_frozen_manifests']:
 if h(w/row['path'])!=row['sha256']:raise RuntimeError('Control drift')
for row in m['product_paths']:
 if h(w/row['path'])!=row['baseline_sha256']:raise RuntimeError('Product edit')
for path,d in m['preserved_product_hashes'].items():
 if h(w/path)!=d:raise RuntimeError('Preserved product drift')
for path,d in m['metadata_hashes'].items():
 if h(w/path)!=d:raise RuntimeError('Metadata drift')
paths=[str(x.relative_to(w)) for x in [sf,c,manifest,log]];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Finalize modern server proposal and separate unit process state'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(json.dumps({'proposal_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'products':18,'criteria':12,'checks':20,'UP04':'accepted','UP05':'proposed/not_granted','product_edits':0}))
