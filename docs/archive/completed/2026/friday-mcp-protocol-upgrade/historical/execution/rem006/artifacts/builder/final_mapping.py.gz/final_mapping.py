import ast,json,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';e=b/'rem006-builder-evidence';p=w/'docs/planning/active/friday-mcp-protocol-upgrade'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def ref(path,symbol):
 tree=ast.parse((w/path).read_text())
 for n in ast.walk(tree):
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name==symbol:
   return {'path':path,'symbol':symbol,'line':n.lineno,'end_line':n.end_lineno,'sha256':h(w/path),'assertion_lines':[x.lineno for x in ast.walk(n) if isinstance(x,ast.Assert)]}
 raise RuntimeError('missing '+symbol)
a=json.loads((p/'authority-REM-MCP-UP-006.json').read_text());plan=json.loads((e/'prospective-plan.json').read_text());d=json.loads((e/'existing-modern-actual-mapping.json').read_text())
# Rebind every inherited pointer to this frozen candidate, keeping all inventories.
for bundle in d['bundles'].values():
 for kind in ['source','assertions']:
  bundle[kind]=[ref(x['path'],x['symbol']) for x in bundle[kind]]
src='packages/friday-mcp/src/friday_mcp/server/';tests='packages/friday-mcp/tests_mcp/server/'
by_id={x['id']:x for x in plan['findings']}
new_tests={
'VAL-UP05-001': [('modern_stdio','test_backpressured_rejections_keep_reader_responsive'),('modern_stdio','test_rejection_output_saturation_closes_without_unbounded_work'),('server_lifecycle','test_multiple_operation_writers_are_serialized_and_owned'),('server_lifecycle','test_cancelled_writer_cannot_emit_after_resistant_lock_release')],
'VAL-UP05-002': [('server_lifecycle','test_resistant_output_shutdown_blocks_restart_until_settlement'),('server_lifecycle','test_partial_start_resistant_read_truthful_ownership'),('server_lifecycle','test_stale_finalizer_and_signal_do_not_touch_replacement'),('server_lifecycle','test_close_wait_is_bounded_owned_and_retryable'),('server_lifecycle','test_resistant_native_partial_start_blocks_restart_and_closes_old_transport')],
'VAL-UP05-003': [('modern_stdio','test_first_byte_deadline_expires_fragmented_frame_without_handler'),('modern_stdio','test_fragment_assembly_consumes_handler_and_output_deadline'),('modern_stdio','test_idle_before_frame_does_not_consume_frame_budget'),('modern_stdio','test_partial_eof_uses_frame_deadline_and_closes')],
'VAL-UP05-004': [('streamable_http','test_custom_header_invalid_bytes_exact_mismatch_before_body'),('streamable_http','test_recognized_custom_header_invalid_encoding_zero_handler'),('streamable_http','test_custom_header_duplicate_exact_mismatch_before_body'),('streamable_http','test_access_failures_keep_exact_status_and_private_body'),('streamable_http','test_custom_header_interior_tab_and_unknown_valid_header_preserved')]
}
source_symbols={
'VAL-UP05-001': [('modern_stdio','reject'),('modern_stdio','write_response'),('modern_stdio','line'),('modern_stdio','dispatch')],
'VAL-UP05-002': [('modern_stdio','_Connection'),('modern_stdio','start'),('modern_stdio','_stop_connection'),('modern_stdio','_clear'),('modern_stdio','serve'),('modern_stdio','_serve_connection'),('modern_stdio','terminate'),('modern_stdio','serving_done')],
'VAL-UP05-003': [('modern_stdio','_serve_connection'),('modern_stdio','line'),('modern_stdio','dispatch'),('modern_stdio','write_response')],
'VAL-UP05-004': [('http_policy','validate'),('http_policy','decode_header'),('http_policy','validate_rpc_headers')]
}
finding_rows=[]
for finding in a['findings']:
 fid=finding['id'];row=by_id[fid].copy();row['severity']=finding['severity'];row['criteria']=finding['criteria'];row['disposition']='implemented with passing builder regression evidence; fresh independent delta/full review pending';row['sources']=[ref(src+f+'.py',n) for f,n in source_symbols[fid]];row['assertions']=[ref(tests+'test_'+f+'.py',n) for f,n in new_tests[fid]]
 row['field_references']=[x for x in d['fields'] if x['declaration'] in (['HeaderMismatchError','JSONRPCErrorResponse'] if fid=='VAL-UP05-004' else ['CancelledNotificationParams','CancelledNotification','JSONRPCResponse','JSONRPCErrorResponse'])]
 row['paragraph_references']=[x for x in d['clauses'] if ((fid=='VAL-UP05-004' and 'streamable-http' in x['source'] and any(s in x['paragraph'].lower() for s in ['header validation','invalid characters','-32020','case-insensitive'])) or (fid!='VAL-UP05-004' and ('stdio' in x['source'] or 'cancellation' in x['source']) and any(s in x['paragraph'].lower() for s in ['cancel','timeout','end-of-file','exit promptly'])))]
 row['successful_raw_check_refs']=['checks/rem006-builder-server-focused-006/receipt.json','checks/rem006-builder-corrected-probes-001/receipt.json','checks/rem006-builder-ruff-006/receipt.json','checks/rem006-builder-narrow-mypy-006/receipt.json','checks/rem006-builder-mcp-mypy-006/receipt.json']
 row['unchanged_contract_requirement_refs']=finding['violated_requirements'];finding_rows.append(row)
 for bundle in ['headers','access'] if fid=='VAL-UP05-004' else ['stdio','ownership']:
  d['bundles'][bundle]['assertions'].extend(row['assertions'])
  d['bundles'][bundle]['source'].extend(row['sources'])
  d['bundles'][bundle]['implementation']+=' REM006 correction: '+row['design']
d['product_candidate']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();d['status']='REM006 extended complete modern2026 mapping; builder evidence, independent verdict pending';d['rem006_findings']=finding_rows;d['prospective_rem006_plan_sha256']=h(e/'prospective-plan.json');d['authority_rem006_sha256']=h(p/'authority-REM-MCP-UP-006.json');d['base_candidate']='cc8725d7af8f00540f264b5052e077a1f6655011';d['built_at_utc']=datetime.now(timezone.utc).isoformat();d['guide']['sha256']=h(w/d['guide']['path']);d['all18_products']={name:h(w/name) for name in a['full_original_product_hashes']};d['changed_six_products']={r['path']:h(w/r['path']) for r in a['product_paths']};d['required_profile_unchanged']=a['required_checks'];d['limitations']+=' REM006 builder checks are development evidence; controller stable-candidate full20 and fresh read-only review remain required. Original454 archived artifacts, old2025 plan and earlier controls remain unchanged.'
(e/'final-actual-modern-mapping.json').write_text(json.dumps(d,indent=2)+'\n')
print('Extended155 declarations/337 fields and316 paragraphs; four finding rows; content-pinned all inherited/new pointers')
