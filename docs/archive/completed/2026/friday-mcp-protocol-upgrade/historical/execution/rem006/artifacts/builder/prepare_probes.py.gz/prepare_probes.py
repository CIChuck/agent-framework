from pathlib import Path
import gzip,hashlib,json
b=Path('/private/tmp/friday-mcp-upgrade');e=b/'rem006-builder-evidence';p=b/'work/docs/planning/active/friday-mcp-protocol-upgrade/validation/VAL-UP05-01'
d=json.loads((p/'stored-manifest.json').read_text());checked=[]
for row in d['artifacts']:
 raw=(p/row['path']).read_bytes()
 if hashlib.sha256(raw).hexdigest()!=row['stored_sha256']:raise RuntimeError(row['path'])
 data=gzip.decompress(raw)
 if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise RuntimeError(row['original_path'])
 checked.append({'path':row['path'],'bytes':len(raw),'sha256':row['stored_sha256']})
 if row['original_path']=='test_independent_probes.py':
  (e/'original-test_independent_probes.py').write_bytes(data)
(e/'original-archive-integrity.json').write_text(json.dumps({'archive_artifacts':len(checked),'distinction':'433 original reviewer entries plus reviewer manifest plus20 controller closeout raw files =454 archived entries','stored_manifest_sha256':hashlib.sha256((p/'stored-manifest.json').read_bytes()).hexdigest(),'entries':checked},indent=2)+'\n')
s=(e/'original-test_independent_probes.py').read_text()
s=s.replace("await asyncio.sleep(.1);r.feed_data(raw[20:]+b'\\n');await asyncio.sleep(.01)","await asyncio.sleep(.1);assert r.at_eof();await asyncio.sleep(.01)")
s=s.replace("assert any('result' in json.loads(x) for x in w.data)","assert not w.data and s.active_requests==0 and w.release.is_set()")
s=s.replace("assert not cancelled.is_set();w.release.set();await asyncio.wait_for(cancelled.wait(),.05)","assert cancelled.is_set();w.release.set();await asyncio.wait_for(cancelled.wait(),.05)")
s=s.replace("['code']==-32600", "['code']==-32020")
start=s.index(" await s.stop();print('RESISTANT_REJECTION_STOP'")
s=s[:start]+''' with pytest.raises(TimeoutError,match='incomplete'):await s.stop()
 generation=s._generation
 print('RESISTANT_REJECTION_STOP_CORRECTED',json.dumps({'old_serving_done':old.done(),'retained_output_owners':len(generation.outputs),'writer_retained':s._writer is w}))
 assert len(generation.outputs)==1 and s._writer is w
 with pytest.raises(RuntimeError):s.start()
 r2=asyncio.StreamReader();w2=NextWriter()
 with pytest.raises(RuntimeError):await s.serve(reader=r2,writer=w2)
 w.release.set();await asyncio.gather(old,return_exceptions=True);await s.stop()
 new=asyncio.create_task(s.serve(reader=r2,writer=w2));r2.feed_data(rpc(rid='new')+b'\\n');await w2.draining.wait()
 await s._stop_connection(generation)
 print('STALE_REJECTION_RESTART_CORRECTED',json.dumps({'new_writer_closed':w2.closed,'new_reply':[json.loads(x) for x in w2.data]}))
 assert not w2.closed and json.loads(w2.data[0])['id']=='new'
 await s.stop();await new
'''
(e/'test_corrected_probes.py').write_text(s)
(e/'probe-adaptation.md').write_text('Original archived test_independent_probes.py preserved byte-for-byte. Corrected independent probes switch observed-deficiency assertions to required behavior. The expired-frame fixture no longer feeds an already-closed asyncio.StreamReader; it asserts EOF and zero output after the original100ms delay. Resistant-write fixture expects incomplete stop, blocked restart, then explicit release/retry before successful replacement; it re-enters captured old cleanup and asserts replacement remains open. Original raw observations and archived454 entries remain immutable.\n')
