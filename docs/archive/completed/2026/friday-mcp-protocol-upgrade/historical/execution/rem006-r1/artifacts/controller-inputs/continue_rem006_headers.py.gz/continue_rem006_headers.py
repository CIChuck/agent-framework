from pathlib import Path
import hashlib,importlib.util,json,subprocess
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';parent=p/'authority-REM-MCP-UP-006.json';old=json.loads(parent.read_text());sf=p/'execution/current-process-state.json';s=json.loads(sf.read_text());report=p/'validation/VAL-UP05-02/report.md';review=json.loads((b/'independent-review-UP05-002/evidence-manifest.json').read_text());base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def req(v,m):
 if not v:raise RuntimeError(m)
def dump(f,j):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(j,indent=2)+'\n')
req(review['outcome']=='CHANGES_REQUESTED' and {x['id'] for x in review['findings']}=={'VAL-UP05-005'},'Reconcile finding scope');req(s['prior_unsuccessful_remediation_cycles']==1 and s['validation_state']=='changes_requested','Cycle/state mismatch');req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Dirty candidate')
paths=['packages/friday-mcp/src/friday_mcp/server/http_policy.py','packages/friday-mcp/tests_mcp/server/test_streamable_http.py','docs/guides/18-mcp-server.md'];req(set(paths).issubset({x['path'] for x in old['product_paths']}),'Scope expansion');full={path:h(w/path) for path in old['full_original_product_hashes']};directive=p/'directives/REM-MCP-UP-006-R1-standard-header-byte-grammar.md'
text='''# REM-MCP-UP-006-R1: Standard metadata-header byte grammar

Status: bounded continuation within the **already approved REM-MCP-UP-006** scope.
No new maintainer approval is claimed or requested. Existing receipt and original
six-path directive remain immutable and controlling. This continuation narrows to
three of those paths and enforces the same mandatory HTTP header grammar and exact
wire errors under SRV-AC-01/05/06/12; it adds no feature, dependency, interface,
protocol role or external effect. Original four fixes passed64 independent cases;
new VAL-UP05-005 is a further malformed-header error-category case in the same
approved policy module and complete-work-unit verification requirement.

Authority: [approved REM006](../authority-REM-MCP-UP-006.json), its pinned original
CD005/AMEND001/002 contract, and [original independent report](../validation/VAL-UP05-02/report.md).
The tactical plan authorizes bounded remediation within existing authority and
requests new scope only when the repair exceeds it. A separate remediator remains
required; no builder/reviewer self-approval. This is remediation cycle2 after one
unsuccessful formal correction review; stop after a second unsuccessful cycle.

## Allowed existing paths

'''+''.join('- `'+path+'`\n' for path in paths)+'''
All other15 original UP05 products, all19 metadata/60 accepted product hashes and
original controls/runner/guard/libraries remain unchanged. Board/process evidence
and new prospective/final mappings may be recorded separately. Preserve root
unrelated files and two-task/three-event board overlay; no broad git operations.

## Exact correction

Validate plain Mcp-Method and MCP-Protocol-Version header bytes before comparing
with the UTF8 JSON body. Reject C0 controls except permitted horizontal tab, DEL
and raw non-ASCII with fixed HTTP400/-32020 HeaderMismatch and zero handler effects.
Keep RFC field-value visibleASCII/space/HTAB semantics and exact case-sensitive
header/body matching. Do not strip/normalize values or reclassify invalid bytes as
unknown methods/versions. Keep existing valid unknown ASCII method404/-32601 and
unknown ASCII version400/-32022 with required supported/requested data. Preserve
standard-header duplicate/missing/mismatch behavior, Mcp-Name/Mcp-Param Base64,
Unicode decoded values, authentication/Host/Origin/TLS/media access statuses,
optional capabilities and privacy/no-id-before-body grammar. Never replay a call.

## Required evidence and checks

Before source edits, read the original report/probes and all three allowed files
plus relevant immutable protocol/HTTP contracts; freeze a prospective clause/
field/variant/source/test/command plan. Add exact-code zero-handler negatives for
both standard fields with matching body values, C0 boundary/sweep excluding valid
HTAB, DEL/non-ASCII; valid visibleASCII/space/HTAB and existing unknown method/version
errors; original Name/Param sentinel and access-policy cases. Independently preserved
original failing probes plus disclosed corrected counterparts are required. Guide
may clarify byte grammar without changing defaults or unsupported-role claims.

Repeat all20 unchanged exact commands plus Mypy columns, full normalized327 Ruff
objects/fixes and4 inherited complete Mypy diagnostics, complete skip/warning
comparisons and strict before-first/after-last dependency snapshots. All12 criteria
and all18 products remain in the fresh read-only remediation delta then full UP05
review. Original four mitigation regressions must remain passing. VERIFIED required
before completion proposal; maintainer acceptance, UP06 and publication separate.
Only the existing synthetic guarded subprocess/literal127 privateTLS/ASGI effects
are permitted; no installs/public network/user stores/credentials/providers/scope
expansion. No source suppression, Any/cast/checker weakening or unrelated repair.

## Original new finding

```json
'''+json.dumps(review['findings'][0],indent=2)+'\n```\n';directive.write_text(text)
a=dict(old);a.update(status='approved_scope_bounded_continuation',implementation_authority='granted',parent_authority={'path':str(parent.relative_to(w)),'sha256':h(parent)},authorization_basis={'type':'existing maintainer-approved REM006 scope and mandatory original12 criteria','maintainer_approval':old['approval'],'new_maintainer_decision':'none; no fabricated approval','scope_narrowed_from':6,'scope_narrowed_to':3},findings=review['findings'],resolved_parent_findings=[x['id'] for x in old['findings']],product_paths=[{'path':path,'baseline_sha256':full[path]} for path in paths],full_original_product_hashes=full,reviewed_baseline=review['candidate_commit'],execution_baseline=base,remediation_cycle=2,prior_unsuccessful_remediation_cycles=1,continuation_directive=str(directive.relative_to(w)))
a['controls']=old['controls']+[old['approval'],old['approved_proposal'],{'path':str(parent.relative_to(w)),'sha256':h(parent)},{'path':str(report.relative_to(w)),'sha256':h(report)},{'path':str((p/'validation/VAL-UP05-02/stored-manifest.json').relative_to(w)),'sha256':h(p/'validation/VAL-UP05-02/stored-manifest.json')},{'path':str(directive.relative_to(w)),'sha256':h(directive)}]
af=p/'authority-REM-MCP-UP-006-R1.json';dump(af,a);s.update(execution_phase='remediation',validation_state='not_ready',remediation_status='bounded_continuation',remediation_implementation_authority='granted',current_execution_authority=str(af.relative_to(w)),remediation_directive=str(directive.relative_to(w)),prior_finding_disposition={f['id']:'Resolved in fresh independent64-case assessment; final unit still blocked by VAL-UP05-005' for f in old['findings']},note='Further standard-header byte case covered by already approved header-grammar/three-of-six file scope; no new approval fabricated',next_gate='Separate remediator fixes bounded REM006-R1 standard-header grammar; full20 and fresh delta/full review; stop after second unsuccessful cycle');dump(sf,s)
log=p/'execution-log.md';log.write_text(log.read_text()+'\n\n## REM006 cycle1 result and bounded same-scope standard-header continuation\n\nFresh report preserves64 passing original-finding cases and VAL-UP05-005: plain\nmethod/version headers with control/DEL/rawUnicode matching body choose incorrect\nwire errors. This is covered by original mandatory header grammar/all12 criteria\nand three of six already-approved files. REM006-R1 records a narrowed separate-\nremediator continuation, not a new maintainer decision or broader source authority.\nOriginal reports/control/approval bytes remain immutable. Cycle2; a second failed\nformal correction review stops for maintainer disposition.\n')
spec=importlib.util.spec_from_file_location('board',w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);board=m.load_board(w);t=next(x for x in board['tasks'] if x['id']==old['initiative']);t['next_gate']=s['next_gate'];m._append_event(board,task_id=t['id'],actor='Codex controller',actor_role='agent',action='bounded REM006 continuation within existing approved header scope',note='New standard-header case under original mandatory grammar; three of six files; no new maintainer approval claimed; cycle2 stop applies',evidence=str(directive.relative_to(w)));m._save_board_and_dashboard(board,w)
for key,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show',old['initiative']],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 label='rem006-r1-start-'+key;subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP05.py'),label,'work',str(b/'venv/bin/python'),*args],check=True);req(json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']==0,'Continuation process failure')
for x in a['controls']:req(h(w/x['path'])==x['sha256'],'Control drift')
for path,digest in full.items():req(h(w/path)==digest,'Unapproved edit before continuation')
paths_to_stage=[str(x.relative_to(w)) for x in [directive,af,sf,log]]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths_to_stage],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Continue approved MCP header grammar correction within bounded scope'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(json.dumps({'continuation_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'paths':3,'new_maintainer_approval':False,'remediation_cycle':2}))
