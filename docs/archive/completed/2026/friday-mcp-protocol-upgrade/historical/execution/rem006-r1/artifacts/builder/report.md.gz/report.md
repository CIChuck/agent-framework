# REM-MCP-UP-006-R1 separate remediation report

Candidate: `a8ef5b78054f1d0008706cc09a265c50a58fc0ac`. Base: `bffa9df1de3be145ec4119ba7337526752a371f1`. Branch: `feature/friday-mcp-protocol-upgrade`. Role: separate security/architecture remediator `/root/rem006_server_remediator`, Codex/GPT-6 agent instance. Recorded 2026-10-13T21:30:22.276382+00:00.

This is the already-authorized bounded REM006 continuation, formal remediation cycle2. No new approval, independent VERIFIED result, completion, acceptance, UP06, delivery or publication is claimed. The existing exact maintainer approval and all original controlling artifacts remain immutable.

VAL-UP05-005 is implemented by four added source lines at HTTPServerPolicy.validate: plain Mcp-Method/MCP-Protocol-Version values permit visibleASCII/SP/HTAB only and reject every other byte with fixed400/-32020 before body consumption or RPC routing. Values are neither normalized nor Base64-decoded. Exact matching valid unknown ASCII method remains404/-32601, valid unknown ASCII version remains400/-32022 with supported/requested data. Name/Param Base64, decoded Unicode, custom duplicates and access-specific statuses remain separate and unchanged.

Exactly the three approved product paths changed. All other15 original UP05 products,19 metadata,60 accepted products, original guard/runner, libraries and controls are unchanged. The guide now states the plain-field byte grammar and the separate Name/Param sentinel rules. No public API/default/dependency/checker/optional role, stdio ownership source, accepted client/legacy/Core/Runtime/Chat/telemetry source or board/process authority changed.

The pre-edit prospective-plan.json freezes complete relevant clause/field/byte/variant/source/test/command coverage. final-actual-modern-mapping.json retains all155 declarations/337 field references/316 normative paragraphs, rebinds all inherited pointers to this candidate and adds exactly one R1 finding row with concrete source, field, paragraph, variant, assertion-line and command references. Ten historical _meta field line offsets reported by VAL-UP05-02 are corrected explicitly in this new evidence ledger only; original inventories/reports/captures remain untouched. Inventory counts are not independent conformance verdicts.

Final builder evidence:

- Guarded board validate/next/show passed before edits with started/granted/approved continuation authority.
- Complete scoped server-focused-002:1108 passed, including original ownership/frame fixes, real official SDK2.3.0 stdio and verified privateTLS JSON/SSE.
- Standard HTTP test suite:605 passed. New tests include both fields ×160 forbidden bytes and ×96 permitted bytes, matchingUTF8 boundaries, exact equality without case/whitespace/Base64 normalization, and actual verifiedTLS rawUTF8/no-handler/child-exit assertions.
- Scoped16-file Ruff,7-source Mypy,28-source MCP Mypy, documentation557-file lifecycle and whitespace pass. All child receipt exits were inspected.
- The byte-identical original test_review_edges.py assertion counterpart passes all70 tests, including64 independent original-fix cases and all six new mandatory standard-field negatives.
- Two corrected live probe tests retain every original request and raw observation: app-level UTF8 requests yield exact400/-32020/no-id safe JSON; C0/DEL requests remain h11 pre-ASGI400 fixedplaintext. Both modes have0 handler starts, active_final0 and child_exit0. This disclosed assertion-only distinction follows the sealed review's middleware/app separation; no parser/dependency change or weakened app assertion is used.

Original VAL-UP05-02 report and scripts remain unchanged. Original script copies are byte-identical. original-archive-integrity.json checks all374 original stored artifacts against stored and decompressed byte counts/hashes. probe-adaptation.md explains the separate live counterpart; all original failures remain preserved.

before-first-check.json and after-last-check.json chronologically bracket every builder child command, with identical actual hashes for21992 unique library paths/22009 inventory references/192 distributions, metadata19, accepted products60, other15 products and frozen controls/guard/runner. check-summary.json records full argv/exits/timestamps and verifies the comparison. Fresh unique guarded HOME/cache destinations and approved loopback escalation were used. Evidence excludes runtime HOME/cache/TMP/store contents and private TLS keys; retained approved relative-CWD synthetic root fixture artifacts were not cleaned.

The sole new development failure is Ruff SIM117 in the new test's nested async contexts. Raw attempt is retained, and its in-scope test formatting correction passes subsequent checks. These development checks are not the independent formal cycle result. No public network/DNS, user credentials/stores, live provider/tools, installation/sync/shared environment write, broad staging or external publication occurred.

Controller must execute the unchanged full20 stable-candidate profile, explicit-column Mypy and complete inherited diagnostic/fix/skip/warning comparisons, then commission fresh read-only remediation delta and full18-path/12-criterion UP05 review. A second unsuccessful formal remediation result requires stopping under policy. Existing cancellation-resistant transport behavior remains honestly owned and blocks unsafe restart; no broader optional/OAuth/server role conformance is claimed.

| Changed product | Candidate SHA256 |
| --- | --- |
| `packages/friday-mcp/src/friday_mcp/server/http_policy.py` | `3ccba7ebfa47aa03429177afa2ce84646699daf7a0b3f638724174c12373c1ce` |
| `packages/friday-mcp/tests_mcp/server/test_streamable_http.py` | `294fec1d2d0b5af65418ed53b0bb1685b9eb4bff251c82f85cac6248b4a21fad` |
| `docs/guides/18-mcp-server.md` | `fd5ce94dbefb8eaef11e62e84a5e607633e34c0f66dc9c794d061158adcf0362` |
