from pathlib import Path
import json,hashlib
b=Path('/private/tmp/friday-mcp-upgrade');site=b/'venv/lib/python3.13/site-packages';groups=json.loads((b/'reused-library-manifest.json').read_text())['copied']+json.loads((b/'additional-validation-libraries.json').read_text())['added'];bad=[];count=0
for g in groups:
 for row in g['files']:
  f=site/row['path'];actual=hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
  if actual!=row['sha256']:bad.append({'path':row['path'],'expected':row['sha256'],'actual':actual})
  else:count+=1
result={'matching_files':count,'distributions':len(groups),'mismatches':bad};(b/'up05-amend2-library-before.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if count!=22009 or len(groups)!=192 or bad:raise RuntimeError('Library drift')
