from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,importlib.util
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';root=Path('/Users/chuckrussell/Dev/gendev/agent-framework');p=w/'docs/planning/active/friday-mcp-protocol-upgrade';expected='11e36b87f0e752f6df9894d46f22ef1b00669578'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def dump(f,j):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(j,indent=2)+'\n')
if subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()!=expected or subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip():raise RuntimeError('Private HEAD or checkout drift')
proposalpath=p/'proposals/UP-05-authority-manifest.json';j=json.loads(proposalpath.read_text())
for x in j['controls']+j['prior_frozen_manifests']:
 if h(w/x['path'])!=x['sha256']:raise RuntimeError('Authority drift')
for key in ['preserved_product_hashes','metadata_hashes']:
 for path,digest in j[key].items():
  if h(w/path)!=digest:raise RuntimeError('Preserved hash drift: '+path)
for x in j['product_paths']:
 if h(w/x['path'])!=x['baseline_sha256']:raise RuntimeError('Product drift')
preserve=b/'up05-execution-root-preservation';preserve.mkdir(exist_ok=False)
for name in ['board.yaml','README.md']:(preserve/name).write_bytes((root/'docs/planning'/name).read_bytes())
oldpres=b/'up05-planning-root-preservation';known=json.loads((oldpres/'preservation.json').read_text())
for x,d in known.items():
 if h(root/x)!=d:raise RuntimeError('Unrelated path drift')
dump(preserve/'preservation.json',known)
spec=importlib.util.spec_from_file_location('board',w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);board=m.load_board(w);dirty=m.load_board(root);clean={x['id']:x for x in board['tasks']};overlay={'tasks':{x['id']:x for x in dirty['tasks'] if x['id'] not in clean or x!=clean[x['id']]},'events':[x for x in dirty['events'] if x not in board['events']]}
if set(overlay['tasks'])!={'friday-telemetry-rewire','friday-tool-manifest-continuity'}:raise RuntimeError('Unexpected overlay')
dump(preserve/'board-overlay.json',overlay)
receipt={'directive':'CD-MCP-UP-005','work_unit':'MCP-UP-05','status':'approved','approved_by':'Chuck Russell','maintainer_statement':'approved, continue','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'proposal_commit':expected,'proposal_manifest_sha256':h(proposalpath),'scope':'Exact18 product paths,12 criteria,20 required commands and bounded private fixture effects of immutable directive/contract/profile/manifest','later_unit_or_delivery_authority':'not granted'};rf=p/'approval-UP-05.json';dump(rf,receipt)
authority=dict(j);authority.update(status='approved_execution',implementation_authority='granted',approval={'path':str(rf.relative_to(w)),'sha256':h(rf)},approved_proposal={'path':str(proposalpath.relative_to(w)),'sha256':h(proposalpath)},execution_baseline=expected);dump(p/'authority-UP-05.json',authority)
sf=p/'execution/current-process-state.json';s=json.loads(sf.read_text());s.update(execution_phase='construction',validation_state='not_ready',directive_status='approved',unit_implementation_authority='granted',next_gate='Implement exact CD-MCP-UP-005, complete all required checks, freeze stable candidate for fresh independent full-unit validation');dump(sf,s)
log=p/'execution-log.md';log.write_text(log.read_text()+'\n\n## 2026-10-13 - exact UP-05 construction approved\n\nChuck Russell explicitly stated “approved, continue” in response to the complete\nCD-MCP-UP-005 packet. Separate approval-UP-05.json and authority-UP-05.json pin\nthe immutable18-path/12-criterion/20-check proposal. Current UP-05 enters\nconstruction/not_ready/granted. No dependency, later-unit or publication authority\nis inferred. Preserve accepted evidence and all unrelated root changes.\n')
t=next(x for x in board['tasks'] if x['id']=='friday-mcp-protocol-upgrade');t['next_gate']=s['next_gate'];m._append_event(board,task_id=t['id'],actor='Chuck Russell',actor_role='maintainer',action='approved exact CD-MCP-UP-005',note='Exact statement: approved, continue. Exact18-path UP-05 scope, full checks and independent review; local only',evidence=str(rf.relative_to(w)));m._save_board_and_dashboard(board,w)
for label,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show','friday-mcp-protocol-upgrade'] ,'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 subprocess.run([str(b/'venv/bin/python'),str(b/'run_check.py'),'up05-approved-'+label,'work',str(b/'venv/bin/python'),*args],check=True)
 if json.loads((b/'checks'/('up05-approved-'+label)/'receipt.json').read_text())['exit_code']:raise RuntimeError('Board check failed')
paths=[str((p/x).relative_to(w)) for x in ['approval-UP-05.json','authority-UP-05.json','execution/current-process-state.json','execution-log.md']]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','commit','-m','Record exact MCP modern tools server construction approval'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip())
