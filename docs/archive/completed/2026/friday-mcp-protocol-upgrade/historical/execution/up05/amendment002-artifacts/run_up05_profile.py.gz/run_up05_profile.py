from pathlib import Path
import json,hashlib,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=json.loads((p/'authority-UP-05-amendment-001.json').read_text());runner=b/'run_check_UP05.py'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def require(c,msg):
 if not c:raise RuntimeError(msg)
require(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Dirty candidate')
controls=a['controls']+a['prior_frozen_manifests']+[a['approval'],a['approved_proposal'],a['amendment_approval'],a['approved_amendment'],a['amendment_document'],a['parent_authority']]
for x in controls:require(h(w/x['path'])==x['sha256'],'Control drift')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();hashes={x['path']:h(w/x['path']) for x in a['product_paths']};pin=h(p/'authority-UP-05-amendment-001.json');require(h(runner)==a['runner']['UP05_sha256'],'Runner drift');require(h(b/'guard/sitecustomize.py')==a['guard']['sha256'],'Guard drift')
freeze={'candidate':head,'products':hashes,'amended_authority_sha256':pin,'approval_and_controls':controls,'runner_sha256':h(runner),'checks':a['required_checks']};(b/'up05-profile-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for c in a['required_checks']:
 require(head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip() and hashes=={path:h(w/path) for path in hashes} and pin==h(p/'authority-UP-05-amendment-001.json'),'Candidate drift')
 label='up05-full-'+c['id'];require(not (b/'checks'/label).exists(),'Label exists')
 subprocess.run([str(b/'venv/bin/python'),str(runner),label,c['snapshot'],*c['argv']],check=True)
 receipt=json.loads((b/'checks'/label/'receipt.json').read_text());print(json.dumps({'id':c['id'],'child_exit':receipt['exit_code']}),flush=True)
 expected=1 if c['id'] in ['root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy'] else 0
 if receipt['exit_code']!=expected:
  print((b/'checks'/label/'stdout').read_text()[-8000:],flush=True);raise RuntimeError('Required check failed '+c['id'])
print('UP05_PROFILE_COMMANDS_COMPLETE',flush=True)
