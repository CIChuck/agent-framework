from pathlib import Path
import json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');a=json.loads((b/'work/docs/planning/active/friday-mcp-protocol-upgrade/authority-UP-05-amendment-001.json').read_text())
for name in ['full-mypy','baseline-full-mypy']:
 c=next(x for x in a['required_checks'] if x['id']==name);label='up05-'+name+'-columns';subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP05.py'),label,c['snapshot'],*c['argv'],'--show-column-numbers','--no-pretty'],check=True)
 if json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']!=1:raise RuntimeError('Unexpected inherited typing result')
