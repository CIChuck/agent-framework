import hashlib
import importlib.metadata
import json
import shutil
import sysconfig
from pathlib import Path

from packaging.requirements import Requirement

out = Path('/private/tmp/friday-mcp-upgrade')
source = Path(sysconfig.get_paths()['purelib']).resolve()
target = out / 'venv/lib/python3.13/site-packages'
target.mkdir(parents=True, exist_ok=True)
distributions = {d.metadata['Name'].lower().replace('_', '-'): d for d in importlib.metadata.distributions()}
requirements = (out / 'validation-requirements.txt').read_text()
blocks = []
for line in requirements.splitlines(keepends=True):
    if line and line[0] not in ' #-' and '==' in line:
        blocks.append([line])
    elif blocks:
        blocks[-1].append(line)
copied = []
install = []
for block in blocks:
    requirement = Requirement(block[0].strip().removesuffix(' \\'))
    if requirement.marker and not requirement.marker.evaluate():
        continue
    name = requirement.name.lower().replace('_', '-')
    distribution = distributions.get(name)
    if distribution is None or distribution.version not in requirement.specifier:
        install.append(''.join(block))
        continue
    files = []
    for file in distribution.files or []:
        path = Path(distribution.locate_file(file)).resolve()
        if not path.is_relative_to(source) or path.suffix == '.pyc':
            continue
        relative = path.relative_to(source)
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        if hashlib.sha256(destination.read_bytes()).hexdigest() != before:
            raise RuntimeError('Library copy mismatch')
        files.append({'path': str(relative), 'sha256': before})
    copied.append({'distribution': name, 'version': distribution.version, 'files': files})
(out / 'reused-library-manifest.json').write_text(json.dumps({'source': str(source), 'destination': str(target), 'copied': copied, 'method': 'Copy existing version-matching library/metadata files only; no old console scripts or workspace editable links; validate every copied file SHA256. No shared environment mutation.'}, indent=2) + '\n')
(out / 'new-validation-requirements.txt').write_text(''.join(install))
print(json.dumps({'reused_distributions': len(copied), 'new_artifact_installations': len(install)}))
