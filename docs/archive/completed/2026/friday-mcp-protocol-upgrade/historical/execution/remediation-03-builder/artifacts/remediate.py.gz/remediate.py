from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, subprocess, sys
B=Path('/private/tmp/friday-mcp-upgrade'); W=B/'work'; E=B/'remediation-UP03-003-builder'; P='docs/planning/active/friday-mcp-protocol-upgrade/'
START='dabe21258b5e5082e603cfe5e23351c1a7ea523c'; TARGET='docs/guides/10-configuration.md'
h=lambda raw:hashlib.sha256(raw).hexdigest()
hf=lambda p:h(p.read_bytes())
load=lambda p:json.loads(p.read_text())
write=lambda p,data:p.write_text(json.dumps(data,indent=2)+'\n')
a=load(W/P/'authority-REM-MCP-UP-003.json'); up=load(W/P/'authority-UP-03.json'); profile=load(W/P/'verification-profile-UP-03.json')
wrapper_env={'PATH':'/opt/homebrew/bin:/usr/bin:/bin','HOME':str(B/'homes/rem003-controller'),'PYTHONDONTWRITEBYTECODE':'1'}
(B/'homes/rem003-controller').mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=W,env=wrapper_env,text=True).strip()
refs=[]; owners=set(); frozen_paths=set()
def scan(data,owner):
 if isinstance(data,dict):
  if isinstance(data.get('path'),str) and isinstance(data.get('sha256'),str):
   rel=data['path']; f=Path(rel) if rel.startswith('/') else W/rel
   actual=hf(f) if f.is_file() else None
   refs.append({'owner':owner,'path':rel,'expected':data['sha256'],'actual':actual,'match':actual==data['sha256']})
   if actual!=data['sha256']:raise RuntimeError('Pinned authority mismatch: '+rel)
   frozen_paths.add(rel)
  for child in data.values():scan(child,owner)
 elif isinstance(data,list):
  for child in data:scan(child,owner)
for name in ['authority-REM-MCP-UP-003.json','authority-UP-03.json','approval-UP-03.json','validation-request-UP-03.json','authority-manifest.json','authority-UP-02B.json','authority-REM-MCP-UP-002.json','proposals/UP-03-authority-manifest.json']:
 rel=P+name
 if rel not in owners:owners.add(rel);scan(load(W/rel),rel)
frozen_paths.update(owners)
frozen_paths.update(['AGENTS.md','docs/reference/policies/repository-engineering-policy.md','docs/reference/policies/development-task-lifecycle.md','docs/reference/policies/independent-validation-policy.md','docs/planning/board.yaml','docs/planning/README.md',P+'execution/current-process-state.json','scripts/friday-dev-board.py','scripts/check-documentation-lifecycle.py','docs/planning/board.schema.json','packages/friday-mcp/src/friday_mcp/client/http_policy.py',str(B/'independent-review-UP03/probe_address_semantics.py'),str(E/'remediate.py')])
initial_products=a['original_product_hashes']; metadata=a['metadata_hashes']
expected_corrected=h((W/TARGET).read_bytes().replace(a['exact_replacement']['old'].encode(),a['exact_replacement']['new'].encode()))
phase=sys.argv[1]
def freeze(name,corrected=False):
 products={p:hf(W/p) for p in initial_products}; meta={p:hf(W/p) for p in metadata}
 expected=dict(initial_products)
 if corrected:expected[TARGET]=expected_corrected
 if products!=expected:raise RuntimeError('Product hash drift')
 if meta!=metadata:raise RuntimeError('Metadata hash drift')
 authority={p:hf(Path(p) if p.startswith('/') else W/p) for p in frozen_paths}
 state=load(W/P/'execution/current-process-state.json')
 if git('branch','--show-current')!=up['planned_branch'] or state['work_state']!='started' or state['unit_implementation_authority']!='granted':raise RuntimeError('State/branch mismatch')
 data={'recorded_utc':datetime.now(timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'status':git('status','--porcelain'),'product_hashes':products,'metadata_hashes':meta,'preserved_authority_hashes':authority,'pinned_reference_checks':refs,'exact_replacement':a['exact_replacement'],'effects':'Only existing no-I/O policy probe and read-only board/docs/render/git checks; no new runtime effects','runner_sha256':hf(B/'run_check.py'),'guard_sha256':hf(B/'guard/sitecustomize.py')}
 dest=E/name;dest.mkdir(parents=True,exist_ok=False);write(dest/'freeze.json',data)
 for rel in sorted(set(products)|set(meta)|frozen_paths):
  source=Path(rel) if rel.startswith('/') else W/rel
  stored=dest/'sources'/('private/'+str(source.relative_to(B)) if rel.startswith('/') else rel)
  stored=stored.with_name(stored.name+'.gz');stored.parent.mkdir(parents=True,exist_ok=True);stored.write_bytes(gzip.compress(source.read_bytes(),mtime=0))
 return data

def check(name,argv,corrected=False):
 label='rem003-'+name;dest=B/'checks'/label
 if dest.exists():raise RuntimeError('Evidence already exists')
 f=freeze('freeze-'+name,corrected)
 home=B/'homes'/label
 env={'PATH':str(B/'venv/bin')+':/opt/homebrew/bin:/usr/bin:/bin','HOME':str(home),'TMPDIR':str(B/'tmp'),'PYTHONPATH':':'.join([str(B/'guard')]+[str(p) for p in sorted((W/'packages').glob('*/src'))]+[str(W/'packages/friday-chat/tests_chat')]),'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0','PYTEST_ADDOPTS':'--import-mode=importlib','UV_CACHE_DIR':str(B/'cache'),'UV_NO_SYNC':'1','UV_OFFLINE':'1','UV_PROJECT_ENVIRONMENT':str(B/'venv'),'VIRTUAL_ENV':str(B/'venv'),'FRIDAY_TELEMETRY_ENABLED':'false','ANONYMIZED_TELEMETRY':'false','TOKENIZERS_PARALLELISM':'false','XDG_CACHE_HOME':str(home/'.cache'),'MPLCONFIGDIR':str(home/'mpl')}
 dest.mkdir(parents=True);write(dest/'before-execution.json',{**f,'argv':argv,'environment':env,'wrapper_argv':[str(B/'venv/bin/python'),str(B/'run_check.py'),label,'work',*argv],'wrapper_environment':wrapper_env})
 subprocess.run([str(B/'venv/bin/python'),str(B/'run_check.py'),label,'work',*argv],env=wrapper_env,check=True)
 receipt=load(dest/'receipt.json')
 shutil.copytree(dest,E/'checks'/name)
 if receipt['environment']!=env or receipt['argv']!=argv or receipt['exit_code']!=0:raise RuntimeError('Failed child/receipt mismatch '+name)
 if {p:hf(W/p) for p in initial_products}!=f['product_hashes'] or {p:hf(W/p) for p in metadata}!=f['metadata_hashes'] or {p:hf(Path(p) if p.startswith('/') else W/p) for p in frozen_paths}!=f['preserved_authority_hashes']:raise RuntimeError('Source changed during '+name)
 print(json.dumps({'check':name,'child_exit':receipt['exit_code'],'stdout':(dest/'stdout').read_text(),'stderr':(dest/'stderr').read_text()}),flush=True)

py=str(B/'venv/bin/python')
if phase=='preflight':
 if git('rev-parse','HEAD')!=START or git('status','--porcelain'):raise RuntimeError('Initial candidate unstable')
 archive=gzip.decompress((W/P/'validation/VAL-UP03-01/artifacts/probe_address_semantics.py.gz').read_bytes())
 if archive!=(B/'independent-review-UP03/probe_address_semantics.py').read_bytes():raise RuntimeError('Original probe mismatch')
 freeze('initial')
 for name in ['board','next','show']:
  item=next(x for x in profile['checks'] if x['id']==name);check('pre-'+name,item['argv'])
 write(E/'preflight-success.json',{'start_commit':START,'pinned_reference_count':len(refs),'all_refs_match':True,'product_count':len(initial_products),'metadata_count':len(metadata),'probe_archive_exact':True})
elif phase=='edit':
 if not (E/'preflight-success.json').exists():raise RuntimeError('Missing preflight')
 before=(W/TARGET).read_bytes();old=a['exact_replacement']['old'].encode();new=a['exact_replacement']['new'].encode()
 if h(before)!=initial_products[TARGET] or before.count(old)!=1:raise RuntimeError('Replacement precondition failed')
 (W/TARGET).write_bytes(before.replace(old,new))
 freeze('corrected',True)
 diff=subprocess.check_output(['git','diff','--',TARGET],cwd=W,env=wrapper_env)
 (E/'exact-one-path.diff').write_bytes(diff)
 if git('diff','--name-only')!=TARGET:raise RuntimeError('Extra product edit')
 write(E/'exact-replacement.json',{'path':TARGET,'before_sha256':h(before),'after_sha256':hf(W/TARGET),'diff_sha256':h(diff),'exact_literal_replacement':True})
 # Inspection is source-level: permits uses address-membership OR eligible global-IP predicates,
 # parse independently requires selected allowed_ports; guide17 describes default/public opt-ins.
 write(E/'semantic-inspection.json',{'policy_path':'packages/friday-mcp/src/friday_mcp/client/http_policy.py','policy_sha256':hf(W/'packages/friday-mcp/src/friday_mcp/client/http_policy.py'),'address_expression':'str(ip) in self.allowed_addresses or (ip.is_global and exclusions)','address_lines':[57,72],'port_expression':'port not in policy.allowed_ports -> ValueError','port_lines':[99,106],'guide17_path':'docs/guides/17-mcp-client.md','guide17_sha256':hf(W/'docs/guides/17-mcp-client.md'),'guide17_lines':[218,224],'conclusion':'Corrected explanation matches unchanged accepted additive address permissions and independent selected-port constraint.'})
 check('address-semantics',[py,str(B/'independent-review-UP03/probe_address_semantics.py')],True)
 for name in ['board','next','show','docs','render']:
  item=next(x for x in profile['checks'] if x['id']==name);check('post-'+name,item['argv'],True)
 check('worktree-whitespace',['git','diff','--check'],True)
else:raise RuntimeError('Unsupported phase')
