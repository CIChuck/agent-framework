from pathlib import Path
from datetime import datetime,timezone
import copy,difflib,gzip,hashlib,importlib.util,json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';d=p/'execution/up06-fixture-stop';a=json.loads((p/'authority-UP-06.json').read_text());private=b/'up06-blocker-evidence';fixture='packages/friday-mcp/tests_mcp/fixtures/friday_modern_tools_server.py'
def req(c,m):
 if not c:raise RuntimeError(m)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def dump(f,j):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(j,indent=2)+'\n')
req(not d.exists(),'Stop evidence overwrite');req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Dirty before frozen amendment')
for path,digest in (a['current_accepted_product_hashes']|a['metadata_hashes']).items():req(h(w/path)==digest,'Accepted product changed')
for x in a['controls']+[a['approval'],a['approved_proposal']]:req(h(w/x['path'])==x['sha256'],'Control changed')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();d.mkdir(parents=True)
receipts={};labels=['up06-development-001-pair','up06-development-002-runtime','up06-development-003-runtime-corrected','up06-development-004-fixture-diagnosis','up06-development-005-fixture-diagnosis-corrected']
for label in labels:receipts[label]=json.loads((b/'checks'/label/'receipt.json').read_text())
before=json.loads((b/'up06-library-development-before.json').read_text());after=json.loads((b/'up06-library-development-after.json').read_text());req(before['actual_hashes']==after['actual_hashes'] and not before['mismatches'] and not after['mismatches'],'Library drift');req(before['finished_utc']<=min(r['started_utc'] for r in receipts.values()) and after['started_utc']>=max(r['finished_utc'] for r in receipts.values()),'Development check integrity not bracketed')
req(receipts[labels[0]]['exit_code']==0 and receipts[labels[2]]['exit_code']==1 and receipts[labels[4]]['exit_code']==0,'Observed outcomes changed')
finding={'id':'BUILD-UP06-001','severity':'medium','classification':'named synthetic fixture catalog mismatch; pre-formal construction stop','affected_product':fixture,'observed':'Actual Friday programmatic stdio/auto/TLSJSON/TLSSSE and cancel/timeout pairs:10 pass. Corrected Runtime YAML cases:HTTPSJSON/SSE pass, stdio rejects echo as invalid_schema then missing_include. Separate real Runtime and Chat loader/public registry diagnosis reproduces same fixed rejection with zero handlers and final active0.','cause':'Fixture populate emits text.x-mcp-header:Text for every transport. Accepted mcp_registration.py only validates/strips HTTP binding annotations for modern HTTP entries; stdio admission intentionally retains its strict schema policy.','source_locations':[{'path':fixture,'symbol':'populate','requirement':'Produce a representative plain stdio tool and annotated HTTP tool without changing semantic echo/hold/fail behavior'},{'path':'packages/friday-runtime/src/friday_runtime/mcp_registration.py','symbol':'_schema/sanitize_definition/prepare_registration','requirement':'Existing HTTP-only annotation admission stays unchanged'}],'required_mitigation':'Transport-specific text schema in this single fixture: plain type:string for ModernStdioMCPServer; same x-mcp-header:Text for StreamableHTTPMCPServer JSON/SSE. Preserve handlers/names/result/output schema/CLI modes/counters/ownership.','required_verification':'Update only the already-authorized new aggregate test expectations by transport; prove raw fixture catalogs and admitted Runtime/Chat stdio and HTTP tools, HTTP Unicode binding remains correct; repeat all24 and fresh whole-feature aggregate review.','no_runtime_defect_claim':'The accepted strict admission policy is behaving as designed; no production source, trust policy or schema/default relaxation proposed.','authority_boundary':'CD006 explicitly freezes existing fixtures and requires stopping for an extra fixture/path; exact maintainer exception needed before editing this eighth product path.','formal_verdict':'Not applicable; this is builder diagnostic evidence, no formal independent review/VERIFIED claim'}
dump(d/'finding.json',finding)
original=(w/fixture).read_text();proposed=original.replace('def populate(server, counter):\n','def populate(server, counter):\n    text_schema = {"type": "string"}\n    if isinstance(server, StreamableHTTPMCPServer):\n        text_schema["x-mcp-header"] = "Text"\n\n').replace('"text": {"type": "string", "x-mcp-header": "Text"},','"text": text_schema,');req(proposed!=original,'No illustrative fixture delta');patch=''.join(difflib.unified_diff(original.splitlines(True),proposed.splitlines(True),fromfile='a/'+fixture,tofile='b/'+fixture));(d/'proposed-fixture.patch').write_text(patch)
extra={'path':fixture,'baseline_sha256':h(w/fixture),'change':'existing','kind':'synthetic test fixture'};req(fixture in a['preserved_product_hashes'],'Fixture already in scope');protected={k:v for k,v in a['preserved_product_hashes'].items() if k!=fixture};req(len(protected)==74,'Frozen budget mismatch')
runner=b/'run_check_UP06_amend1.py';req(not runner.exists(),'Copied runner overwrite');runner.write_text((b/'run_check_UP06.py').read_text().replace("profile_path = base / 'work/docs/planning/active/friday-mcp-protocol-upgrade/authority-UP-06.json'", "profile_path = base / 'work/docs/planning/active/friday-mcp-protocol-upgrade/authority-UP-06-amendment-001.json'\nif not profile_path.is_file():\n    profile_path = base / 'work/docs/planning/active/friday-mcp-protocol-upgrade/authority-UP-06.json'"))
af=p/'directives/AMEND-MCP-UP-006-001-fixture-transport-catalog.md';af.write_text('''# AMEND-MCP-UP-006-001: Transport-specific synthetic fixture catalog

Status: Proposed; exact maintainer fixture exception approval pending.
Parent CD-MCP-UP-006 is already approved. No repeat approval of its seven paths,
criteria or effects is requested. This amendment adds exactly one existing test
fixture path; no runtime implementation/dependency/default/policy change.

## Reproduced gap

[BUILD-UP06-001](../execution/up06-fixture-stop/finding.json) records10 passing
actual Friday programmatic pair/cancellation/timeout cases. Corrected Runtime
YAML cases pass for verifiedTLSJSON/SSE but reject the stdio catalog. Independent
of that test harness, real Runtime and Chat loaders/public registry reproduce
`invalid_schema` followed by `missing_include`, with0 handlers/final active0.
The shared fixture emits HTTP x-mcp-header:Text even in its stdio mode. Current
accepted admission permits this extension only on explicitly modern HTTP peers;
its strict stdio policy remains controlling. The named fixture does not represent
an admissible plain stdio tool for the new integrated cross-peer proof.

## Exact exception and illustrative patch

Only add `'''+fixture+'''` to the product budget.
[Concrete proposed patch](../execution/up06-fixture-stop/proposed-fixture.patch)
uses a plain text schema for stdio and retains the identical Text binding for HTTP
JSON/SSE. Exactly the same echo/hold/fail handlers, tool name, structured result,
output schema, modes/arguments/counters/process settlement remain. Existing
production registration policy, clients/server implementation and templates are
frozen. Do not relax validation or replace required integration assertions with
xfail/skips, fake MCP registry or an in-process peer.

Parent budget7 becomes8; five existing docs/new migration guide/new aggregate
module remain approved.74 earlier accepted products/all19 metadata stay frozen.
Parent all12 aggregate/all8 initiative criteria and all24 EXACT commands remain;
the frozen Ruff command already includes this fixture. The only new control-runner
copy selects the separately approved amended authority; original runner/guard bytes,
allowlisted environment/checker flags/source scope/effects are retained unchanged.
No additional fixture, CLI mode, subprocess entry point or external effect.

## Required evidence after approval

Restore the intact private draft aggregate module at its approved path, correct
its per-transport catalog expectations without weakening HTTP header proof, and
verify raw catalogs plus actual Runtime/Chat plain-stdio/verifiedTLSJSON/SSE
admission/calls, Unicode binding and unchanged SDK/legacy counterpart suites.
Complete remaining docs/example/lifecycle/telemetry/provenance proof under the
original CD006, all24 checks and exact inherited debt/skip/warning comparisons,
strict source/control/library before/after and fresh read-only whole-feature review.
Original failed attempts/false harness accesses are preserved separately from the
actual fixture gap; existing acceptance/report/control bytes remain immutable.

## Stop and acceptance boundary

No product edits occurred after identifying the extra-path need. The controller-
created draft test is retained byte-for-byte as private/evidence artifact; shared
root receives approval/plan/stop/amendment process metadata only. Approved CD006
construction remains stopped at its explicit fixture/path condition until this
exception is approved. No formal verdict or remediation-cycle failure is inferred.
Any additional source/path/effect/mandatory conflict stops for exact disposition.
Whole MCP stays started/local; independent VERIFIED/completion/whole acceptance,
publication and Langfuse remain later separate gates.
''')
proposal={'initiative':a['initiative'],'unit':'MCP-UP-06','amendment':'AMEND-MCP-UP-006-001','status':'proposed/not_granted','parent_directive':'CD-MCP-UP-006','parent_authority':{'path':str((p/'authority-UP-06.json').relative_to(w)),'sha256':h(p/'authority-UP-06.json')},'approved_parent_scope':'Seven original paths/12 aggregate and8 initiative criteria/24 commands remain approved; no repeat scope approval requested','finding':finding,'baseline':head,'added_product_path':extra,'amended_product_paths':a['product_paths']+[extra],'preserved_product_hashes':protected,'metadata_hashes':a['metadata_hashes'],'required_checks_unchanged':a['required_checks'],'amendment_directive':{'path':str(af.relative_to(w)),'sha256':h(af)},'illustrative_patch':{'path':str((d/'proposed-fixture.patch').relative_to(w)),'sha256':h(d/'proposed-fixture.patch'),'status':'proposed bytes only; no fixture edited'},'draft_preservation':{'original_product_path':'packages/friday-mcp/tests_mcp/test_upgrade_aggregate.py','private_retained_path':str(private/'draft-test_upgrade_aggregate.py'),'sha256':h(private/'draft-test_upgrade_aggregate.py'),'status':'intact controller-owned draft; moved out of private product checkout for clean process freeze, not discarded or weakened'},'replacement_runner':{'path':str(runner),'sha256':h(runner),'original_UP06_sha256':h(b/'run_check_UP06.py'),'rule':'Only additional amended-authority selection; same guard/effects/argv/environment/source freezing'},'guard':a['guard'],'permitted_effects_unchanged':a['permitted_effects'],'approval':None,'no_production_scope_extension':True};mp=p/'proposals/UP-06-amendment-001.json';dump(mp,proposal)
items=[]
def archive(name,raw):
 f=d/'artifacts'/(name+'.gz');req(not f.exists(),'Artifact overwrite');f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(gzip.compress(raw,mtime=0));items.append({'original_path':name,'path':str(f.relative_to(d)),'encoding':'gzip','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(f)})
for f in sorted(private.iterdir()):
 if f.is_file():archive('private-drafts-and-probes/'+f.name,f.read_bytes())
for label in labels:
 for n in ['preflight.json','receipt.json','stdout','stderr']:archive('development-checks/'+label+'/'+n,(b/'checks'/label/n).read_bytes())
for n in ['up06-library-development-before.json','up06-library-development-after.json','freeze_up06_plan.py','rehash_up06_libraries.py','approve_up06.py','prepare_up06_amendment001.py','run_check_UP06.py','run_check_UP06_amend1.py']:archive('controller-inputs/'+n,(b/n).read_bytes())
archive('controller-inputs/copied-runner-authority-selection.diff',subprocess.run(['diff','-u',str(b/'run_check_UP06.py'),str(runner)],capture_output=True,check=False).stdout)
(d/'report.md').write_text('# UP-06 construction stop: named stdio fixture catalog\n\nStatus: pre-formal builder stop, not product VERIFIED or independent verdict.\n\n10 actual Friday direct transport/cancellation/timeout cases pass; corrected\nRuntime YAML positives pass forHTTPSJSON/SSE. The actual stdio required-tool\ncase remains failing. A separate Runtime/Chat public loader/registry diagnostic\npasses both expected rejection assertions: invalid_schema then missing_include,\n0 handlers/final active0. [Finding](finding.json) and [illustrative patch](proposed-fixture.patch)\nidentify one existing fixture exception. Original Runtime harness used an invalid\nprovider.config access; corrected public Kernel config assertions isolate the\nremaining stdio failure. The initial diagnostic used status instead of code and\nomitted required Chat llm.model context; those harness errors and corrected\nreruns remain unchanged evidence. Existing LiteLLM import attempts public cost-map\nlookup; the unchanged guard blocks DNS and the library uses its local fallback.\nNo public network effect/credential/provider execution or runtime edit occurred.\n\nActual library hashes strictly bracket all five development checks and match\n22009 references/21992 unique paths/192 distributions. All78 accepted products/\n19 metadata/approved controls remain unchanged. No shared product edits; the new\ncontroller-owned untracked draft is retained intact outside the private product\ncheckout and in [lossless explicit safe evidence](stored-manifest.json). Original\nbyte snapshots/raw failures are preserved, no assertions disabled or rewritten\nas xfail. No full24 profile or independent aggregate verdict is claimed.\n\nNext: [exact one-file amendment](../../directives/AMEND-MCP-UP-006-001-fixture-transport-catalog.md).\nOnly that eighth fixture path is new authority; original CD006 is already approved.\n')
sf=p/'execution/current-process-state.json';s=json.loads(sf.read_text());s.update(execution_phase='planning',validation_state='not_ready',unit_completion='not proposed; aggregate construction stopped at fixture-scope boundary',pending_amendment=str(af.relative_to(w)),construction_stop='BUILD-UP06-001 requires one existing fixture path outside approved seven-path scope',open_findings=[finding],next_gate='Approve AMEND-MCP-UP-006-001 one existing fixture catalog exception; then resume already-approved CD006, all24 checks and fresh whole-feature review',note='Direct pairs10 pass; RuntimeHTTPS2 pass; actual stdio fixture rejected by accepted Runtime/Chat schema policy. Original seven paths remain approved; construction stops for eighth fixture. Shared product bytes unchanged, draft retained safely.');dump(sf,s)
log=p/'execution-log.md';log.write_text(log.read_text()+'\n\n## UP-06 pre-formal fixture-scope construction stop\n\nBUILD-UP06-001 reproduces named stdio fixture HTTP annotation rejected by accepted\nRuntime/Chat admission.10 direct pair/lifecycle cases and2 RuntimeHTTPS cases pass;\nstdio required-tool assertion remains failing after public config harness fix.\nIndependent diagnostic of both real loaders/public registries reproduces\ninvalid_schema/missing_include with0 handlers/final active0. Original harness\nerrors/raw reruns retained. No source/fixture edit or admission-policy relaxation.\nApproved CD006 explicitly stops at extra fixture path. Propose one existing fixture\nexception (7->8 paths;75->74 frozen earlier products;12+8 criteria/24 checks/effects\nunchanged). Controller-owned partial new test is retained intact private+archive;\nroot receives process-only approval/plan/stop proposal. Whole MCP started/local;\nno formal verdict/remediation-cycle failure/completion/acceptance/publication.\n')
spec=importlib.util.spec_from_file_location('board',w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);board=m.load_board(w);t=next(x for x in board['tasks'] if x['id']==a['initiative']);t['next_gate']=s['next_gate'];m._append_event(board,task_id=t['id'],actor='Codex controller',actor_role='agent',action='stopped UP06 at exact fixture-scope boundary',note='BUILD-UP06-001 named stdio catalog; one fixture exception proposed; original CD006 remains approved; product draft preserved; no runtime policy change',evidence=str(af.relative_to(w)));m._save_board_and_dashboard(board,w)
for k,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show',t['id']],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 label='up06-amend1-proposal-'+k;req(not (b/'checks'/label).exists(),'Check reuse');subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP06.py'),label,'work',str(b/'venv/bin/python'),*args],check=True);req(json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']==0,'Stop process check failed')
 for n in ['preflight.json','receipt.json','stdout','stderr']:archive('stop-process-checks/'+k+'/'+n,(b/'checks'/label/n).read_bytes())
dump(d/'stored-manifest.json',{'status':'Construction stop evidence only; no formal independent verdict','artifacts':items,'boundary':'Exact original controller-owned draft/probes/raw failed attempts/snapshots/scripts; no runtime private stores/HOME/TLS keys/user state'});
for x in items:req(hashlib.sha256(gzip.decompress((d/x['path']).read_bytes())).hexdigest()==x['sha256'],'Archived artifact drift')
for path,digest in (a['current_accepted_product_hashes']|a['metadata_hashes']).items():req(h(w/path)==digest,'Product changed while stopped')
for x in a['controls']+[a['approval'],a['approved_proposal']]:req(h(w/x['path'])==x['sha256'],'Original control changed')
paths=[str(x.relative_to(w)) for x in [af,mp,d,sf,log]]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Record aggregate fixture gap and propose one-file catalog exception'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(json.dumps({'proposal_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'finding':finding['id'],'new_authority_paths':1,'proposed_total_paths':8,'criteria':12,'checks_unchanged':24,'product_edits_on_shared_candidate':0,'safe_artifacts':len(items)}))
