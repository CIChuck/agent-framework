import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

base = Path('/private/tmp/friday-mcp-upgrade')
label, snapshot, *argv = sys.argv[1:]
if snapshot not in {'work','up06-baseline'}: raise RuntimeError('Invalid UP06 snapshot')
work = base / snapshot
output = base / 'checks' / label
output.mkdir(parents=True, exist_ok=False)
home = base / 'homes' / label
home.mkdir(parents=True, exist_ok=True)
pythonpath = [str(base / 'guard')] + [str(p) for p in sorted((work / 'packages').glob('*/src'))] + [str(work / 'packages/friday-chat/tests_chat')]
environment = {
    'PATH': str(base / 'venv/bin') + ':/opt/homebrew/bin:/usr/bin:/bin',
    'HOME': str(home), 'TMPDIR': str(base / 'tmp' / label), 'PYTHONPATH': ':'.join(pythonpath),
    'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0',
    'PYTEST_ADDOPTS': '--import-mode=importlib',
    'UV_CACHE_DIR': str(base / 'cache'), 'UV_NO_SYNC': '1', 'UV_OFFLINE': '1',
    'UV_PROJECT_ENVIRONMENT': str(base / 'venv'), 'VIRTUAL_ENV': str(base / 'venv'),
    'FRIDAY_TELEMETRY_ENABLED': 'false', 'ANONYMIZED_TELEMETRY': 'false',
    'TOKENIZERS_PARALLELISM': 'false',
    'XDG_CACHE_HOME': str(home / '.cache'), 'MPLCONFIGDIR': str(home / 'mpl'),
}
(base / 'tmp' / label).mkdir(parents=True, exist_ok=False)
environment['MYPY_CACHE_DIR'] = str(home / 'mypy')
environment['RUFF_CACHE_DIR'] = str(home / 'ruff')
environment['PYTEST_ADDOPTS'] += ' -o cache_dir=' + str(home / 'pytest')
profile_path = base / 'work/docs/planning/active/friday-mcp-protocol-upgrade/authority-UP-06.json'
if not profile_path.is_file():
    profile_path = base / 'work/docs/planning/active/friday-mcp-protocol-upgrade/proposals/UP-06-authority-manifest.json'
profile = json.loads(profile_path.read_text())
source_paths = sorted(set(profile['current_accepted_product_hashes']) | {x['path'] for x in profile['product_paths']})
source_hashes = {x: hashlib.sha256((work/x).read_bytes()).hexdigest() if (work/x).is_file() else None for x in source_paths}
controls = profile['controls'] + profile['prior_frozen_manifests']
if profile.get('approval'): controls.append(profile['approval'])
preflight = {'argv': argv, 'environment': environment, 'source_hashes': source_hashes,
 'candidate_commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
 'authority_sha256': hashlib.sha256(profile_path.read_bytes()).hexdigest(),
 'authority_path': str(profile_path),
 'control_hashes': {x['path']: hashlib.sha256((base/'work'/x['path']).read_bytes()).hexdigest() for x in controls},
 'metadata_hashes': {x: hashlib.sha256((work/x).read_bytes()).hexdigest() for x in profile['metadata_hashes']},
 'preserved_product_hashes': {x: hashlib.sha256((work/x).read_bytes()).hexdigest() for x in profile['preserved_product_hashes']},
 'UP05_runner_sha256': hashlib.sha256((base/'run_check_UP05.py').read_bytes()).hexdigest(),
 'UP06_runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'guard_sha256': hashlib.sha256((base/'guard/sitecustomize.py').read_bytes()).hexdigest()}
(output / 'preflight.json').write_text(json.dumps(preflight,indent=2)+'\n')
started = datetime.now(timezone.utc).isoformat()
with (output / 'stdout').open('wb') as stdout, (output / 'stderr').open('wb') as stderr:
    process = subprocess.run(argv, cwd=work, env=environment, stdout=stdout, stderr=stderr)
receipt = {'argv': argv, 'cwd': str(work), 'environment': environment, 'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': process.returncode, 'stdout_sha256': hashlib.sha256((output / 'stdout').read_bytes()).hexdigest(), 'stderr_sha256': hashlib.sha256((output / 'stderr').read_bytes()).hexdigest(), 'guard_sha256': hashlib.sha256((base / 'guard/sitecustomize.py').read_bytes()).hexdigest()}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'check': label, 'exit': process.returncode, 'evidence': str(output)}))
