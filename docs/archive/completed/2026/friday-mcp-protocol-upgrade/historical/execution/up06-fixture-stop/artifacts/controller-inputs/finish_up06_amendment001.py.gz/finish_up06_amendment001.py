from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';d=p/'execution/up06-fixture-stop';a=json.loads((p/'authority-UP-06.json').read_text());items=[]
def req(c,m):
 if not c:raise RuntimeError(m)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def dump(f,j):f.write_text(json.dumps(j,indent=2)+'\n')
for f in sorted((d/'artifacts').rglob('*.gz')):
 raw=gzip.decompress(f.read_bytes());name=str(f.relative_to(d/'artifacts'))[:-3];items.append({'original_path':name,'path':str(f.relative_to(d)),'encoding':'gzip','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(f)})
def archive(name,raw):
 f=d/'artifacts'/(name+'.gz');req(not f.exists(),'Artifact overwrite');f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(gzip.compress(raw,mtime=0));items.append({'original_path':name,'path':str(f.relative_to(d)),'encoding':'gzip','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(f)})
notes={'initial_process_error':'Documentation lifecycle check caught report link to stored-manifest.json before that manifest was written. No product/control change.','fix':'Write provisional safe artifact index before lifecycle check; retain original incomplete attempt/failed child and complete fresh unique process checks; final index includes all originals','guarded_fixture_gap':'BUILD-UP06-001 unchanged; no runtime/schema policy relaxation or fixture edit','source_draft':'Moved intact controller-owned draft outside private product checkout for process-only commit; original and corrected source/probes preserved'};dump(d/'process-attempt-notes.json',notes)
archive('controller-inputs/finish_up06_amendment001.py',Path(__file__).read_bytes());archive('controller-inputs/process-attempt-notes.json',(d/'process-attempt-notes.json').read_bytes())
for n in ['preflight.json','receipt.json','stdout','stderr']:archive('failed-stop-process-checks/docs/'+n,(b/'checks/up06-amend1-proposal-docs'/n).read_bytes())
def write_manifest():dump(d/'stored-manifest.json',{'status':'Construction stop evidence only; no formal independent verdict','artifacts':items,'boundary':'Exact original draft/probes/raw failed and corrected attempts/strict snapshots; no HOME/runtime stores/TLS keys/user state; originals retained losslessly'})
write_manifest()
for k,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show',a['initiative']],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 label='up06-amend1-proposal-final-'+k;req(not (b/'checks'/label).exists(),'Label reuse');subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP06.py'),label,'work',str(b/'venv/bin/python'),*args],check=True);req(json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']==0,'Final stop check failed')
 for n in ['preflight.json','receipt.json','stdout','stderr']:archive('final-stop-process-checks/'+k+'/'+n,(b/'checks'/label/n).read_bytes())
write_manifest()
for x in items:req(hashlib.sha256(gzip.decompress((d/x['path']).read_bytes())).hexdigest()==x['sha256'],'Archive drift')
for path,digest in (a['current_accepted_product_hashes']|a['metadata_hashes']).items():req(h(w/path)==digest,'Product changed')
for x in a['controls']+[a['approval'],a['approved_proposal']]:req(h(w/x['path'])==x['sha256'],'Control changed')
mp=p/'proposals/UP-06-amendment-001.json';m=json.loads(mp.read_text());req(len(m['amended_product_paths'])==8 and len(m['preserved_product_hashes'])==74 and m['required_checks_unchanged']==a['required_checks'],'Amendment budget mismatch')
req(not (w/'packages/friday-mcp/tests_mcp/test_upgrade_aggregate.py').exists(),'Draft still in product checkout');req(h(Path(m['draft_preservation']['private_retained_path']))==m['draft_preservation']['sha256'],'Draft changed')
paths=[str(x.relative_to(w)) for x in [p/'directives/AMEND-MCP-UP-006-001-fixture-transport-catalog.md',mp,d,p/'execution/current-process-state.json',p/'execution-log.md']]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Record aggregate fixture gap and propose one-file catalog exception'],cwd=w,check=True,stdout=subprocess.DEVNULL);req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Private dirty');print(json.dumps({'proposal_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'finding':'BUILD-UP06-001','new_authority_paths':1,'total_paths_after_approval':8,'checks_unchanged':24,'safe_artifacts':len(items),'shared_product_edits':0}))
