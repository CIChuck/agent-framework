from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
b=Path('/private/tmp/friday-mcp-upgrade');site=b/'venv/lib/python3.13/site-packages';phase=sys.argv[1]
if phase not in ['development-before','development-after','profile-before','profile-after']:raise RuntimeError('Invalid snapshot phase')
start=datetime.now(timezone.utc).isoformat();inputs=[b/'reused-library-manifest.json',b/'additional-validation-libraries.json'];groups=json.loads(inputs[0].read_text())['copied']+json.loads(inputs[1].read_text())['added'];actual={};bad=[];refs=0
for group in groups:
 for row in group['files']:
  f=site/row['path'];d=hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None;actual[row['path']]=d;refs+=1
  if d!=row['sha256']:bad.append(row['path'])
j={'phase':phase,'started_utc':start,'finished_utc':datetime.now(timezone.utc).isoformat(),'inventory_references':refs,'unique_paths':len(actual),'distributions':len(groups),'actual_hashes':actual,'input_hashes':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in inputs},'mismatches':bad};f=b/('up06-library-'+phase+'.json')
if f.exists():raise RuntimeError('Snapshot overwrite')
f.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({k:j[k] for k in ['phase','inventory_references','unique_paths','distributions','mismatches']}))
if refs!=22009 or len(actual)!=21992 or len(groups)!=192 or bad:raise RuntimeError('Library integrity mismatch')
