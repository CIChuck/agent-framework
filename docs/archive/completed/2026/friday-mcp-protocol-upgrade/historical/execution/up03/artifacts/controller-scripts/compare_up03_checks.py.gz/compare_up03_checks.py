from pathlib import Path
import collections,hashlib,json,re,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';baseline=b/'up03-baseline';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';d=p/'execution/up03';a=json.loads((p/'authority-UP-03.json').read_text());h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
profile=json.loads((p/'verification-profile-UP-03.json').read_text());receipts={}
for item in profile['checks']:
 path=b/'checks'/('stable-up03-'+item['id']);receipt=json.loads((path/'receipt.json').read_text());before=json.loads((path/'before-execution.json').read_text());assert receipt['argv']==item['argv'];assert receipt['environment']==before['environment'];assert receipt['guard_sha256']==profile['guard']['sha256'];assert before['product_hashes']=={f['path']:h(w/f['path']) for f in a['product_paths']}
 expected=1 if item['id'] in {'root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy'} else 0;assert receipt['exit_code']==expected,(item['id'],receipt['exit_code']);receipts[item['id']]=receipt

def normalize(value,snapshot):
 if isinstance(value,str):return value.replace(str(snapshot),'<snapshot>')
 if isinstance(value,list):return [normalize(v,snapshot) for v in value]
 if isinstance(value,dict):return {k:normalize(v,snapshot) for k,v in value.items()}
 return value
ruff=[]
for key,snapshot in [('root-ruff',w),('baseline-root-ruff',baseline)]:ruff.append(normalize(json.loads((b/'checks'/('stable-up03-'+key)/'stdout').read_text()),snapshot))
objects=[collections.Counter(json.dumps(row,sort_keys=True) for row in rows) for rows in ruff];assert objects[0]==objects[1];assert len(ruff[0])==327
mypy=[]
for key in ['full-mypy','baseline-full-mypy']:
 output=(b/'checks'/('stable-up03-'+key)/'stdout').read_text();mypy.append([line for line in output.splitlines() if ': error:' in line or ': note:' in line])
assert mypy[0]==mypy[1] and len(mypy[0])==4 and all('friday_core/profiles.py:' in line and '[no-any-return]' in line for line in mypy[0])
pytest={}
for key,snapshot in [('root',w),('baseline-root',baseline)]:
 text=(b/'checks'/('stable-up03-'+key)/'stdout').read_text().replace(str(snapshot),'<snapshot>')
 skip=[line for line in text.splitlines() if line.startswith('SKIPPED')]
 match=re.search(r'=+ warnings summary =+\n(.*?)\n-- Docs:',text,re.S);assert match
 warnings=match.group(1);summary=text.splitlines()[-1]
 pytest[key]={'skips':skip,'warnings':warnings,'summary':summary}
assert pytest['root']['skips']==pytest['baseline-root']['skips'];assert pytest['root']['warnings']==pytest['baseline-root']['warnings']
def controls(manifest):
 for row in manifest.get('controls',[]):assert h(w/row['path'])==row['sha256'],row['path']
 for row in manifest.get('prior_frozen_manifests',[]):assert h(w/row['path'])==row['sha256'];controls(json.loads((w/row['path']).read_text()))
controls(a)
for row in [a['approval'],a['approved_proposal']]:assert h(w/row['path'])==row['sha256']
allowed={f['path'] for f in a['product_paths']};changed=set(subprocess.check_output(['git','diff','--name-only',a['execution_baseline']+'..HEAD'],cwd=w,text=True).splitlines());process_scope={'docs/planning/board.yaml','docs/planning/README.md',str((p/'authority-UP-03.json').relative_to(w)),str((p/'approval-UP-03.json').relative_to(w)),str((p/'execution/current-process-state.json').relative_to(w)),str((p/'execution-log.md').relative_to(w))};assert changed<=allowed|process_scope,changed-allowed-process_scope;changed=changed & allowed
for path,digest in a['accepted_http_product_baseline'].items():
 if path not in allowed:assert h(w/path)==digest,path
metadata=[path for path in subprocess.check_output(['git','ls-files'],cwd=w,text=True).splitlines() if path.endswith('pyproject.toml') or path=='uv.lock'];assert all((w/path).read_bytes()==(baseline/path).read_bytes() for path in metadata)
report={'root_ruff':{'diagnostics':327,'complete_normalized_diagnostic_and_fix_multiset_equal':True},'full_mypy':{'diagnostics':mypy[0],'complete_path_line_code_message_equal':True},'pytest':pytest,'protected_scope':{'authorized_products':len(allowed),'changed_products':len(changed),'metadata_files_preserved':len(metadata),'accepted_http_outside_overlap_preserved':True,'recursive_authority_controls_preserved':True},'checks':{key:{'exit_code':value['exit_code'],'stdout_sha256':value['stdout_sha256'],'stderr_sha256':value['stderr_sha256']} for key,value in receipts.items()},'verdict_boundary':'Builder comparison only; fresh independent review required.'}
(d/'verification-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':len(receipts),'root':pytest['root']['summary'],'baseline':pytest['baseline-root']['summary'],'ruff':327,'mypy':4,'debt_and_skips_and_warnings_equal':True,'changed_products':len(changed)}))
