from pathlib import Path
p=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/src/friday_mcp/client');f=p/'protocol.py';s=f.read_text()
a=s.index('        content = result.get("content")',s.index('    elif method == "tools/call":'));z=s.index('\n\ndef validate_message(',a)
s=s[:a]+'''        ToolResult.parse(result, False, limits, compatibility=True)
'''+s[z:]
s=s.replace('''        raise ProtocolFailure("input_required_unsupported")''','''        if isinstance(requests, dict):
            _validate_input_requests(requests)
        raise ProtocolFailure("input_required_unsupported")''',1)
index=s.index('\ndef complete_result(')
s=s[:index]+'''
def _validate_input_requests(requests: dict[str, JSONValue]) -> None:
    for request in requests.values():
        if not isinstance(request, dict):
            raise ProtocolFailure("invalid_result")
        method = request.get("method")
        params = request.get("params", {})
        if not isinstance(params, dict):
            raise ProtocolFailure("invalid_result")
        if "_meta" in params:
            _metadata(params["_meta"])
        if method == "roots/list":
            continue
        if method == "sampling/createMessage":
            messages, tokens = params.get("messages"), params.get("maxTokens")
            if not isinstance(messages, list) or isinstance(tokens, bool) or not isinstance(tokens, (int, float)):
                raise ProtocolFailure("invalid_result")
            for message in messages:
                if not isinstance(message, dict) or message.get("role") not in ("user", "assistant"):
                    raise ProtocolFailure("invalid_result")
                content = message.get("content")
                for block in content if isinstance(content, list) else [content]:
                    if not isinstance(block, dict):
                        raise ProtocolFailure("invalid_result")
                    _validate_content_block(block)
        elif method == "elicitation/create":
            if not isinstance(params.get("message"), str):
                raise ProtocolFailure("invalid_result")
            if params.get("mode", "form") == "url":
                if not isinstance(params.get("url"), str):
                    raise ProtocolFailure("invalid_result")
            elif params.get("mode", "form") == "form":
                schema = params.get("requestedSchema")
                if not isinstance(schema, dict) or schema.get("type") != "object" or not isinstance(schema.get("properties"), dict):
                    raise ProtocolFailure("invalid_result")
            else:
                raise ProtocolFailure("invalid_result")
        else:
            raise ProtocolFailure("invalid_result")


def _validate_content_block(block: dict[str, JSONValue]) -> bool:
    """Check all declared mandatory fields before unsupported/error disposition."""
    kind = block.get("type")
    _text_optional_fields(block)
    if kind == "text":
        if not isinstance(block.get("text"), str):
            raise ProtocolFailure("invalid_result")
        return True
    if kind in ("image", "audio"):
        if not isinstance(block.get("data"), str) or not isinstance(block.get("mimeType"), str):
            raise ProtocolFailure("invalid_result")
    elif kind == "resource_link":
        if not isinstance(block.get("uri"), str) or not isinstance(block.get("name"), str):
            raise ProtocolFailure("invalid_result")
        _strings(block, "description", "mimeType", "title")
        _icons(block)
        size = block.get("size")
        if "size" in block and (isinstance(size, bool) or not isinstance(size, (int, float))):
            raise ProtocolFailure("invalid_result")
    elif kind == "resource":
        resource = block.get("resource")
        if not isinstance(resource, dict) or not isinstance(resource.get("uri"), str):
            raise ProtocolFailure("invalid_result")
        _strings(resource, "mimeType")
        if "_meta" in resource:
            _metadata(resource["_meta"])
        if not isinstance(resource.get("text"), str) and not isinstance(resource.get("blob"), str):
            raise ProtocolFailure("invalid_result")
        _strings(resource, "text", "blob")
    else:
        raise ProtocolFailure("invalid_result")
    return False

'''+s[index:]
s=s.replace('    def parse(cls, value: object, modern: bool, limits: ProtocolLimits) -> ToolResult:', '''    def parse(
        cls, value: object, modern: bool, limits: ProtocolLimits, *, compatibility: bool = False
    ) -> ToolResult:''',1)
a=s.index('        # Tool failure classification',s.index('class ToolResult:'));z=s.index('        structured = (',a)
s=s[:a]+'''        content = result.get("content")
        if not isinstance(content, list):
            raise ProtocolFailure("invalid_result")
        if compatibility:
            if "_meta" in result:
                _metadata(result["_meta"])
            if "structuredContent" in result and not isinstance(result["structuredContent"], dict):
                raise ProtocolFailure("invalid_result")
        texts: list[str] = []
        unsupported = False
        for block in content:
            if isinstance(block, str) and not modern and not compatibility:
                texts.append(block)
            elif isinstance(block, dict) and isinstance(block.get("type"), str):
                if modern or compatibility:
                    supported = _validate_content_block(block)
                else:
                    supported = block["type"] == "text"
                if supported:
                    text = block.get("text")
                    if not isinstance(text, str):
                        raise ProtocolFailure("invalid_result")
                    texts.append(text)
                else:
                    unsupported = True
            else:
                raise ProtocolFailure("invalid_result")
'''+s[z:]
s=s.replace('        if unsupported and (modern or (not any(texts) and structured is None)):', '        if unsupported and not result.get("isError", False) and (modern or compatibility or (not any(texts) and structured is None)):')
f.write_text(s)
# Cache operations must not put an unbounded adapter lock ahead of client deadline.
f=p/'adapter.py';s=f.read_text().replace('        self._cache_lock = asyncio.Lock()\n','');a=s.index('        async with self._cache_lock:');z=s.index('\n    async def get_tool(',a);block=s[a:z];lines=block.splitlines()[1:];s=s[:a]+'\n'.join(line[4:] for line in lines)+'\n'+s[z:];f.write_text(s)
# Previously incomplete unsupported fixture now includes its mandatory MIME type.
f=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/client/test_modern_protocol.py');s=f.read_text().replace('{"type": "image", "data": "SENTINEL"}', '{"type": "image", "data": "SENTINEL", "mimeType": "image/png"}');f.write_text(s)
