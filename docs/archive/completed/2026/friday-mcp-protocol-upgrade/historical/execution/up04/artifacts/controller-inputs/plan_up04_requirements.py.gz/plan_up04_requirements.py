from pathlib import Path
import json,gzip,re,hashlib,subprocess,copy
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';e=p/'execution/up04';e.mkdir(exist_ok=True)
def h(raw):return hashlib.sha256(raw).hexdigest()
prior=json.loads((b/'up03-normative-clause-ledger.json').read_text());plan=copy.deepcopy(prior)
plan.update(status='Preconstruction planned mapping; no candidate evidence',source_count=19,candidate_product_commit=None,preconstruction_plan_sha256=None,criterion_ledger_sha256=None)
route={'core':['RES-AC-04','RES-AC-05','RES-AC-06','RES-AC-10'],'wire':['RES-AC-07','RES-AC-08','RES-AC-10'],'headers':['RES-AC-03','RES-AC-07'],'catalog':['RES-AC-01','RES-AC-02','RES-AC-03','RES-AC-05'],'results':['RES-AC-04','RES-AC-05','RES-AC-06'],'safety':['RES-AC-06','RES-AC-09'],'lifecycle':['RES-AC-02','RES-AC-08']}
for c in plan['clauses']:
 c['accepted_prior_mapping']={k:c[k] for k in ['criteria','positive','negative','applicability','reason'] if k in c}
 c['planned_criteria']=route.get(c.get('group'),['RES-AC-09','RES-AC-10'])
 c['planned_positive']='Retain exact accepted transport/assembly evidence and rerun full profile; add applicable public refresh/result success in test_result_refresh.py and real SDK test_result_refresh_interop.py'
 c['planned_negative']='Retain accepted negative evidence and exercise malformed/error/task content, failure/cancellation/overlapping catalog changes, stale/no-replay/header/schema races; full Runtime/Chat security regressions'
 if c['source'].endswith('/2026-07-28/index.md') and c.get('mandatory_occurrences')==3:c['mandatory_occurrences']=5
sources=[]
for n in ['research-sources/manifest.json','research-sources/up02b/manifest.json','research-sources/up04/manifest.json']:
 mf=p/n
 for s in json.loads(mf.read_text())['sources']:
  raw=gzip.decompress((mf.parent/s['artifact']).read_bytes());text=raw.decode();sources.append({'url':s['url'],'sha256':h(raw),'bytes':len(raw),'complete_capture_parsed':True})
  if n.endswith('up04/manifest.json'):
   line=1;section=''
   for para in re.split(r'\n\s*\n',text):
    if para.startswith('#'):section=para.splitlines()[0]
    tokens=re.findall(r'\b(?:MUST(?: NOT)?|SHALL(?: NOT)?|REQUIRED)\b',para)
    if tokens:
     applies='taskSupport' in para or 'transport specification' in para
     plan['clauses'].append({'source':s['url'],'source_sha256':h(raw),'line':line,'section':section,'paragraph':para,'mandatory_occurrences':len(tokens),'applicability':'applicable_non_task_boundary' if applies else 'unsupported_role','reason':'Required-task exclusion and normal non-task requests; existing dated transport remains controlling' if applies else 'Friday declares no Tasks capability, creates/receives no tasks and performs no Tasks RPC; these conditional Tasks-role duties do not activate','planned_criteria':['RES-AC-05','RES-AC-07','RES-AC-08'],'planned_positive':'Normal absent/forbidden/optional tools, no Tasks request metadata; retained dated transport regressions','planned_negative':'Required tools excluded including inconsistent capabilities; explicit excluded names rejected before I/O; unsolicited CreateTaskResult rejected without polling or persistence'})
    line+=para.count('\n')+2
for s in plan['selected_schema_interfaces']:
 s['planned_criteria']=route.get(s.get('group'),['RES-AC-04','RES-AC-05','RES-AC-10'])
 s['planned_evidence']='Existing exact field mapping retained; complete dated result/content/metadata negatives, immutable catalog exports and non-task exclusion exercised by required focused/interop/full suites'
plan['source_integrity']=sources;plan['mandatory_occurrences']=sum(c['mandatory_occurrences'] for c in plan['clauses']);plan['original_sources_raw_occurrences']=349;plan['note']='Original accepted218 clauses/98 selected interfaces/231 fields preserved with explicit BCP14 count correction. New complete Tasks clauses mapped by non-task versus unsupported role. Each planned obligation must resolve to actual candidate source/test/check evidence before review.'
out=e/'preconstruction-requirement-plan.json';out.write_text(json.dumps(plan,indent=2)+'\n')
subprocess.run(['git','add','--',str(out.relative_to(w))],cwd=w,check=True);subprocess.run(['git','commit','-m','Freeze MCP result and refresh requirement test plan'],cwd=w,check=True,stdout=subprocess.DEVNULL)
print(json.dumps({'complete_sources':len(sources),'clauses':len(plan['clauses']),'mandatory_occurrences':plan['mandatory_occurrences'],'selected_interfaces':len(plan['selected_schema_interfaces']),'selected_fields':plan['selected_schema_fields'],'preconstruction_sha256':h(out.read_bytes())}))
