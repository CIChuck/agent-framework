from pathlib import Path
import collections,hashlib,json,re,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';baseline=b/'up04-baseline';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';d=b/'rem004-controller-evidence';a=json.loads((p/'authority-REM-MCP-UP-004.json').read_text());profile=json.loads((p/'verification-profile-REM-MCP-UP-004.json').read_text());original=json.loads((p/'authority-UP-04.json').read_text());d.mkdir(exist_ok=True)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def require(c,m):
 if not c:raise RuntimeError(m)
receipts={}
for item in profile['checks']:
 path=b/'checks'/('rem004-full-'+item['id']);receipt=json.loads((path/'receipt.json').read_text());before=json.loads((path/'preflight.json').read_text())
 require(receipt['argv']==item['argv'],'argv drift');require(receipt['environment']==before['environment'],'env drift');require(receipt['guard_sha256']==profile['guard']['sha256'],'guard drift')
 snapshot=w if item['snapshot']=='work' else baseline
 require(before['source_hashes']=={x['path']:h(snapshot/x['path']) if (snapshot/x['path']).is_file() else None for x in original['product_paths']},'source freeze drift')
 expected=1 if item['id'] in {'root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy'} else 0;require(receipt['exit_code']==expected,'wrong child exit '+item['id']);receipts[item['id']]=receipt

def normalize(value,snapshot):
 if isinstance(value,str):return value.replace(str(snapshot),'<snapshot>')
 if isinstance(value,list):return [normalize(v,snapshot) for v in value]
 if isinstance(value,dict):return {k:normalize(v,snapshot) for k,v in value.items()}
 return value
ruff=[normalize(json.loads((b/'checks'/('rem004-full-'+key)/'stdout').read_text()),snapshot) for key,snapshot in [('root-ruff',w),('baseline-root-ruff',baseline)]]
require(collections.Counter(json.dumps(x,sort_keys=True) for x in ruff[0])==collections.Counter(json.dumps(x,sort_keys=True) for x in ruff[1]),'Ruff objects changed');require(len(ruff[0])==327,'Ruff count drift')
mypy=[]
for key in ['full-mypy','baseline-full-mypy']:
 output=(b/'checks'/('rem004-full-'+key)/'stdout').read_text();mypy.append([x for x in output.splitlines() if ': error:' in x or ': note:' in x])
require(mypy[0]==mypy[1] and len(mypy[0])==4,'Mypy objects changed')
pytest={}
for key,snapshot in [('root',w),('baseline-root',baseline)]:
 text=(b/'checks'/('rem004-full-'+key)/'stdout').read_text().replace(str(snapshot),'<snapshot>');skip=[x for x in text.splitlines() if x.startswith('SKIPPED')];match=re.search(r'=+ warnings summary =+\n(.*?)\n-- Docs:',text,re.S);require(match is not None,'warning summary missing')
 pytest[key]={'skips':skip,'warnings':match.group(1),'summary':text.splitlines()[-1]}
require(pytest['root']['skips']==pytest['baseline-root']['skips'],'skip drift');require(pytest['root']['warnings']==pytest['baseline-root']['warnings'],'warning drift')
visited=set()
def controls(manifest):
 for row in manifest.get('controls',[]):require(h(w/row['path'])==row['sha256'],'control drift '+row['path'])
 for row in manifest.get('prior_frozen_manifests',[]):
  require(h(w/row['path'])==row['sha256'],'prior manifest drift')
  if row['path'] not in visited:visited.add(row['path']);controls(json.loads((w/row['path']).read_text()))
controls(a)
for row in [a['approval'],a['approved_proposal']]:require(h(w/row['path'])==row['sha256'],'approval drift')
allowed={x['path'] for x in a['product_paths']};changed=set(subprocess.check_output(['git','diff','--name-only',a['execution_baseline']+'..HEAD'],cwd=w,text=True).splitlines());require(all(x in allowed or x.startswith('docs/planning/') for x in changed),'scope drift')
for path,digest in a['metadata_hashes'].items():require(h(w/path)==digest,'metadata drift')
library=json.loads((b/'rem004-library-integrity.json').read_text());require(not library['mismatches'] and library['matching_files']==22009 and library['distributions']==192,'library drift')
columns=[]
for key in ['full-mypy-columns','baseline-full-mypy-columns']:
 output=(b/'checks'/('rem004-'+key)/'stdout').read_text();require(json.loads((b/'checks'/('rem004-'+key)/'receipt.json').read_text())['exit_code']==1,'Column check wrong exit');columns.append([x for x in output.splitlines() if ': error:' in x or ': note:' in x])
require(columns[0]==columns[1] and columns[0]==json.loads((b/'up04-mypy-column-comparison.json').read_text())['diagnostics'],'Full column objects changed')
report={'mypy_columns':columns[0],'root_ruff':{'diagnostics':327,'complete_normalized_diagnostic_and_fix_multiset_equal':True},'full_mypy':{'diagnostics':mypy[0],'complete_path_line_code_message_equal':True},'pytest':pytest,'protected_scope':{'authorized_delta_products':3,'changed_products':len(changed&allowed),'metadata_files_preserved':len(a['metadata_hashes']),'recursive_authority_controls_preserved':True},'library_integrity':library,'checks':{k:{'exit_code':v['exit_code'],'stdout_sha256':v['stdout_sha256'],'stderr_sha256':v['stderr_sha256']} for k,v in receipts.items()},'verdict_boundary':'Builder comparisons only; fresh independent review required.'}
(d/'verification-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':len(receipts),'root':pytest['root']['summary'],'baseline':pytest['baseline-root']['summary'],'ruff':327,'mypy':4,'debt_skips_warnings_equal':True,'changed_products':len(changed&allowed)}))
