# REM-MCP-UP-002 criterion and clause delta

Builder mapping only; fresh independent delta/full review is required. The original normative ledger remains byte-for-byte unchanged.

| Finding | Criteria | Frozen clauses | Regression evidence |
| --- | --- | --- | --- |
| VAL-UP02B-001 | HTTP-AC-03, HTTP-AC-04, HTTP-AC-09 | 2026-07-28/basic/transports/streamable-http.md:365,379,403 | `test_content_schema_invalid_tools_are_counted_after_atomic_catalog`, `test_schema_looking_application_data_is_opaque`, `test_content_schema_annotations_are_unreachable_even_under_properties`, `test_unreachable_annotation_schema_maps` |
| VAL-UP02B-002 | HTTP-AC-04, HTTP-AC-05, HTTP-AC-06, HTTP-AC-08 | 2025-11-25/basic/transports.md:198 | `test_old_generation_404_cannot_disconnect_recovered_session`, `test_stale_recovery_waiter_deadline_does_not_invalidate_active_recovery`, `test_timed_out_recovery_retains_disconnected_state_until_explicit_connect` |
| VAL-UP02B-003 | HTTP-AC-01, HTTP-AC-04, HTTP-AC-10 | 2025-11-25/basic/index.md:146,182 | `test_2025_default_and_declared_input_dialect_are_validated_without_retrieval`, `test_2025_unsupported_input_dialect_discards_entire_catalog`, `test_2024_opaque_metadata_and_input_dialect_defaults_are_preserved`, `test_modern_dialect_and_reserved_result_metadata_remain_strict` |
| VAL-UP02B-004 | HTTP-AC-01, HTTP-AC-02, HTTP-AC-10 | 2025-11-25/basic/index.md:207 | `test_2025_metadata_grammar_preserves_opaque_values_and_application_json`, `test_2025_malformed_metadata_is_rejected_at_each_boundary`, `test_2024_opaque_metadata_and_input_dialect_defaults_are_preserved`, `test_modern_dialect_and_reserved_result_metadata_remain_strict` |

All 218 original clause records and 347 mandatory occurrences across 18 complete captures are reconciled in `delta-normative-clause-ledger.json`. Original declared exclusions and accepted stdio/telemetry/security profiles remain controlled by the pinned original authority; the full required suites are rerun.

The metadata name segment (2025 basic/index lines 215-217) permits empty names and otherwise bounded alphanumeric ends with internal hyphen/underscore/dot characters. The tests cover prefixed, unprefixed and empty names independently from malformed prefixes/slashes/name forms. Both TypeScript schemas remain pinned; received selected 2025 metadata-bearing fields are enumerated in the delta ledger.

JSON Schema 2020-12 schema-bearing keyword audit adds contentSchema and the deprecated schema-valued dependencies location. Schema URI keywords are never fetched; ordinary example/default/const/enum JSON is opaque. Every other schema-map/child/array class is covered by direct unreachable-annotation tests.
