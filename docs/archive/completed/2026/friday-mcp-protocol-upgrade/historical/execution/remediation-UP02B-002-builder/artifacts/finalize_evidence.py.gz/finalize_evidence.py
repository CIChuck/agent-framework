import hashlib
import json
import re
import shutil
from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade');d=b/'remediation-UP02B-002-builder'
for src in sorted((b/'checks').glob('rem002-*')):
 target=d/'checks'/src.name
 if not target.exists():shutil.copytree(src,target)
receipts=[]
for path in sorted((d/'checks').iterdir()):
 x=json.loads((path/'receipt.json').read_text());x['label']=path.name
 for stream in ['stdout','stderr']:
  assert hashlib.sha256((path/stream).read_bytes()).hexdigest()==x[stream+'_sha256']
 receipts.append(x)
(d/'command-ledger.json').write_text(json.dumps(receipts,indent=2)+'\n')
norm=lambda s:s.replace(str(b/'http-baseline'),'<snapshot>').replace(str(b/'work'),'<snapshot>')
a=json.loads(norm((d/'checks/rem002-final-root-ruff/stdout').read_text()));c=json.loads(norm((d/'checks/rem002-final-baseline-ruff/stdout').read_text()))
ruff={'candidate_findings':len(a),'baseline_findings':len(c),'full_normalized_diagnostic_and_fix_objects_identical':a==c,'new_findings':[] if a==c else [x for x in a if x not in c],'removed_findings':[] if a==c else [x for x in c if x not in a]}
(d/'ruff-comparison.json').write_text(json.dumps(ruff,indent=2)+'\n');assert ruff['full_normalized_diagnostic_and_fix_objects_identical'] and len(a)==327
candidate=(d/'checks/rem002-final-root/stdout').read_text();baseline=(d/'checks/rem002-final-baseline-root/stdout').read_text()
summary=lambda s:re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings',s).groups()
warning=lambda s:norm(s.split('warnings summary')[1].split('-- Docs:')[0])
prior=json.loads((b/'independent-review-UP-02B/baseline-comparison.json').read_text())
comparison={'candidate_summary':summary(candidate),'baseline_summary':summary(baseline),'new_test_count':int(summary(candidate)[0])-int(summary(baseline)[0]),'warning_and_skip_counts_unchanged':summary(candidate)[1:]==summary(baseline)[1:],'complete_normalized_warning_section_identical':warning(candidate)==warning(baseline),'inherited_skip_details_reference':'Preserved independent-review-UP-02B/baseline-comparison.json (earlier exact -rs identity); current unchanged skip counts and no new skip markers','inherited_skip_groups':prior['candidate_skips'],'scope':'Root configured discovery only; live-provider skips are not deterministic acceptance'}
(d/'baseline-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');assert comparison['new_test_count']==297 and comparison['complete_normalized_warning_section_identical'] and comparison['warning_and_skip_counts_unchanged']
frozen=json.loads((d/'derived-frozen-environments.json').read_text());env_errors=[]
for key,entry in frozen['entries'].items():
 actual=json.loads((d/'checks'/entry['label']/'receipt.json').read_text())
 if actual['environment']!=entry['environment'] or actual['argv']!=entry['argv']:env_errors.append(key)
(d/'environment-reconciliation.json').write_text(json.dumps({'errors':env_errors,'frozen_entries':len(frozen['entries']),'runner_sha256':hashlib.sha256((b/'run_check.py').read_bytes()).hexdigest(),'guard_sha256':hashlib.sha256((b/'guard/sitecustomize.py').read_bytes()).hexdigest()},indent=2)+'\n');assert not env_errors
print(json.dumps({'checks':len(receipts),'ruff':ruff,'baseline':comparison['candidate_summary'],'environment_errors':env_errors}))
