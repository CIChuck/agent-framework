import gzip
import hashlib
import json
import subprocess
import tomllib
from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';d=b/'remediation-UP02B-002-builder';p='docs/planning/active/friday-mcp-protocol-upgrade/'
h=lambda data:hashlib.sha256(data).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=w,text=True)
pre=json.loads((d/'pre-edit-inventory.json').read_text());rem=json.loads((w/(p+'authority-REM-MCP-UP-002.json')).read_text());orig=json.loads((w/(p+'authority-UP-02B.json')).read_text());f=json.loads((d/'stable-check-freeze.json').read_text());scope={x['path'] for x in rem['product_scope']};errors=[];controls=[]
for x in pre['hashes']:
 if x['path'] in scope:continue
 actual=h((w/x['path']).read_bytes());controls.append({'path':x['path'],'sha256':actual,'preserved':actual==x['actual']})
 if actual!=x['actual']:errors.append(x['path'])
for path,expected in f['product_sha256'].items():
 actual=h((w/path).read_bytes())
 if actual!=expected:errors.append('final freeze: '+path)
for path,expected in rem['unchanged_original_products'].items():
 if path not in scope and h((w/path).read_bytes())!=expected:errors.append('outside six: '+path)
source_records=[]
for sub in ['research-sources','research-sources/up02b']:
 manifest=json.loads((w/(p+sub+'/manifest.json')).read_text())
 for x in manifest['sources']:
  raw=(w/(p+sub+'/'+x['artifact'])).read_bytes();plain=gzip.decompress(raw)
  valid=h(raw)==x['artifact_sha256'] and h(plain)==x['sha256']
  source_records.append({'source':x['url'],'raw_sha256':h(plain),'stored_sha256':h(raw),'preserved':valid})
  if not valid:errors.append(x['artifact'])
artifact_records=[]
for dirname in ['execution/http','validation/VAL-UP02B-01']:
 manifest=json.loads((w/(p+dirname+'/stored-manifest.json')).read_text())
 for x in manifest['artifacts']:
  raw=(w/(p+dirname+'/'+x['path'])).read_bytes();plain=gzip.decompress(raw)
  valid=h(raw)==x['stored_sha256'] and h(plain)==x['sha256'] and len(plain)==x['bytes']
  artifact_records.append({'path':p+dirname+'/'+x['path'],'sha256':h(raw),'preserved':valid})
  if not valid:errors.append(x['path'])
changed=git('diff','--name-only',pre['head']).splitlines();overall=git('diff','--name-only',orig['product_baseline']).splitlines();allowed14={x['path'] for x in orig['product_paths']};products=[x for x in overall if x.startswith('packages/') or x=='uv.lock'];outside=[x for x in products if x not in allowed14]
if set(changed)-scope:errors.extend(set(changed)-scope)
if outside:errors.extend(outside)
lock=tomllib.loads((w/'uv.lock').read_text());baseline=tomllib.loads(git('show',orig['product_baseline']+':uv.lock'))
for package in lock['package']:
 if package['name']=='friday-framework-mcp':
  package['dependencies']=[x for x in package['dependencies'] if x.get('name')!='httpcore']
  package['metadata']['requires-dist']=[x for x in package['metadata']['requires-dist'] if x.get('name')!='httpcore']
if lock!=baseline:errors.append('original dependency delta drift')
report={'errors':sorted(set(errors)),'head_before_product_commit':git('rev-parse','HEAD').strip(),'branch':git('branch','--show-current').strip(),'status':git('status','--short'),'six_path_delta':changed,'fourteen_path_overall_products':products,'outside_scope':outside,'controls':controls,'complete_sources':source_records,'stored_original_artifacts':artifact_records,'original_direct_httpcore_edge_only_lock_delta':lock==baseline,'unchanged_dependency_files':{path:h((w/path).read_bytes()) for path in ['uv.lock','packages/friday-mcp/pyproject.toml']},'guard_sha256':h((b/'guard/sitecustomize.py').read_bytes()),'runner_sha256':h((b/'run_check.py').read_bytes()),'final_freeze_sha256':h((d/'stable-check-freeze.json').read_bytes())}
(d/'final-inventory.json').write_text(json.dumps(report,indent=2)+'\n');(d/'product.diff').write_text(git('diff',pre['head'],'--',*sorted(scope)));(d/'overall-product.diff').write_text(git('diff',orig['product_baseline'],'--',*sorted(allowed14)))
print(json.dumps({'errors':report['errors'],'six_paths':len(changed),'overall_products':len(products),'original_artifacts':len(artifact_records),'sources':len(source_records),'controls':len(controls)}))
if errors:raise SystemExit(1)
