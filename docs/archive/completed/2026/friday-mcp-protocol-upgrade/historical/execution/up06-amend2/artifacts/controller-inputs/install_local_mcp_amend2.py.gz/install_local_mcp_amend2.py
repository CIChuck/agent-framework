"""Advance the existing feature branch and preserve its unrelated board overlay."""
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

root = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
private = Path('/private/tmp/friday-mcp-upgrade')
expected, folder, candidate = sys.argv[1:]
preserved = private / folder

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
branch = subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip()
if head != expected or branch != 'feature/friday-mcp-protocol-upgrade':
    raise RuntimeError('Root revision/branch changed; reconcile before transfer')
for relative, filename in [('docs/planning/board.yaml', 'board.yaml'), ('docs/planning/README.md', 'README.md')]:
    if (root/relative).read_bytes() != (preserved/filename).read_bytes():
        raise RuntimeError('Unrelated planning overlay changed; reconcile before transfer')
receipts = json.loads((preserved/'preservation.json').read_text())
def verify_unrelated():
    for relative, expected in receipts.items():
        actual = hashlib.sha256((root/relative).read_bytes()).hexdigest() if (root/relative).is_file() else None
        if actual != expected:
            raise RuntimeError('Unrelated change altered: '+relative)
verify_unrelated()
subprocess.run(['git', 'fetch', '--no-tags', str(private/'work'), candidate], cwd=root, check=True, capture_output=True)
advanced = False
try:
    for relative in ['docs/planning/board.yaml', 'docs/planning/README.md']:
        (root/relative).write_bytes(subprocess.check_output(['git','show','HEAD:'+relative], cwd=root))
    subprocess.run(['git', 'merge', '--ff-only', candidate], cwd=root, check=True, capture_output=True)
    advanced = True
finally:
    if not advanced:
        (root/'docs/planning/board.yaml').write_bytes((preserved/'board.yaml').read_bytes())
        (root/'docs/planning/README.md').write_bytes((preserved/'README.md').read_bytes())
if advanced:
    spec = importlib.util.spec_from_file_location('board', root/'scripts/friday-dev-board.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    board = module.load_board(root)
    overlay = json.loads((preserved/'board-overlay.json').read_text())
    tasks = {t['id']: t for t in board['tasks']}
    tasks.update(overlay['tasks'])
    board['tasks'] = list(tasks.values())
    for event in overlay['events']:
        if event not in board['events']:
            board['events'].append(event)
    module._save_board_and_dashboard(board, root)
verify_unrelated()
print(json.dumps({'feature_candidate': candidate, 'unrelated_paths_preserved':len(receipts), 'board_overlay_tasks':list(overlay['tasks']), 'publication':'none'}))
