import json,shutil,re,hashlib
from pathlib import Path
base=Path('/private/tmp/friday-mcp-upgrade');d=base/'independent-review-UP-02B'
extras={'probes':'probes','probes-02':'probes-02','compatibility-probes':'compatibility-probes','regression-probes':'regression-probes','root-skip-details':'root-skip-details','baseline-skip-details':'baseline-skip-details','environment':'environment','ruff-version':'ruff-version'}
for key,label in extras.items():shutil.copytree(base/'checks'/('independent-UP02B-'+label),d/'checks'/key,dirs_exist_ok=True)
ledger=[]
for p in sorted((d/'checks').iterdir()):
 receipt=json.loads((p/'receipt.json').read_text());receipt['label']=p.name
 for name in ['stdout','stderr']:
  assert hashlib.sha256((p/name).read_bytes()).hexdigest()==receipt[name+'_sha256']
 ledger.append(receipt)
(d/'command-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
def normalize(x):return x.replace(str(base/'http-baseline'),'<snapshot>').replace(str(base/'work'),'<snapshot>')
a=(d/'checks/root-skip-details/stdout').read_text();b=(d/'checks/baseline-skip-details/stdout').read_text()
sa=[normalize(s) for s in a.splitlines() if s.startswith('SKIPPED ')];sb=[normalize(s) for s in b.splitlines() if s.startswith('SKIPPED ')]
def warning(x):return normalize(x.split('warnings summary')[1].split('-- Docs:')[0])
result={'candidate_skips':sa,'baseline_skips':sb,'identical_skip_groups':sa==sb,'identical_warning_section':warning(a)==warning(b),'candidate_summary':a.splitlines()[-1],'baseline_summary':b.splitlines()[-1]}
(d/'baseline-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
print((d/'checks/environment/stdout').read_text());print((d/'checks/ruff-version/stdout').read_text())
