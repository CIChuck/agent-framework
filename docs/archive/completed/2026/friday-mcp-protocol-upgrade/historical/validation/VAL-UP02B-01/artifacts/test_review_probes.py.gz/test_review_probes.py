import asyncio,importlib.util,sys
from pathlib import Path
import pytest
from friday_mcp.client.http_protocol import HTTP_COMPAT_VERSION
from friday_mcp.client.protocol import ProtocolFailure
spec=importlib.util.spec_from_file_location('review_peer',Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/client/test_http_lifecycle.py'))
h=importlib.util.module_from_spec(spec);sys.modules[spec.name]=h;spec.loader.exec_module(h)
@pytest.mark.asyncio
async def test_unreachable_content_schema_header_tool_is_excluded():
 peer=h.Peer();peer.tools.append({'name':'bad','inputSchema':{'type':'object','properties':{'payload':{'type':'string','contentMediaType':'application/json','contentSchema':{'type':'object','properties':{'v':{'type':'string','x-mcp-header':'Hidden'}}}}}}})
 client,_,_=await h.ready_client(peer=peer)
 try:
  assert [t['name'] for t in await client.list_tools()]==['echo']
  assert client.rejected_http_tools==1
 finally:await client.disconnect()
@pytest.mark.asyncio
async def test_old_generation_404_cannot_disconnect_recovered_session():
 release=asyncio.Event()
 class Stream(h.WireStream):
  async def read(self,max_bytes,timeout=None):
   await self.ready.wait()
   if b'"text":"late"' in self.outgoing:await release.wait()
   return await super().read(max_bytes,timeout)
 class Peer(h.Peer):
  async def connect_tcp(self,host,port,timeout=None,local_address=None,socket_options=None):
   self.connections.append((host,port));s=Stream(self);self.streams.append(s);return s
 peer=Peer(HTTP_COMPAT_VERSION);client,_,_=await h.ready_client(peer=peer);late=None
 try:
  peer.hook=lambda verb,headers,r:h.Reply(status=404) if r.get('method')=='tools/call' else None
  late=asyncio.create_task(client.call_tool('echo',{'text':'late'}))
  while peer.methods().count('tools/call')<1:await asyncio.sleep(0)
  await asyncio.gather(client.call_tool('echo',{'text':'fast'}),return_exceptions=True)
  assert client.is_connected
  release.set();await asyncio.gather(late,return_exceptions=True)
  assert peer.methods().count('initialize')==2
  assert peer.methods().count('tools/call')==2
  assert client.is_connected
  peer.hook=None
  assert await client.call_tool('echo',{'text':'next'})=='next'
 finally:
  release.set()
  if late is not None:await asyncio.gather(late,return_exceptions=True)
  await client.disconnect()
@pytest.mark.asyncio
async def test_2025_unsupported_input_dialect_fails_catalog():
 peer=h.Peer(HTTP_COMPAT_VERSION);peer.tools[0]['inputSchema']['$schema']='https://unsupported.example/unknown-schema'
 client,_,_=h.make_client(peer=peer);await client.connect()
 try:
  with pytest.raises(ProtocolFailure) as failure:await client.list_tools()
  assert failure.value.failure_code=='unsupported_schema'
  assert not client._catalog
 finally:await client.disconnect()
@pytest.mark.asyncio
@pytest.mark.parametrize('location',['tool','result','text'])
async def test_2025_malformed_protocol_metadata_is_rejected(location):
 peer=h.Peer(HTTP_COMPAT_VERSION)
 if location=='tool':peer.tools[0]['_meta']={'bad/name/key':1}
 client,_,_=h.make_client(peer=peer);await client.connect()
 try:
  if location=='tool':
   with pytest.raises(ProtocolFailure):await client.list_tools()
  else:
   await client.list_tools()
   def hook(verb,headers,r):
    if r.get('method')!='tools/call':return None
    block={'type':'text','text':'ok'};result={'content':[block]}
    (result if location=='result' else block)['_meta']={'bad/name/key':1}
    return peer.rpc(r,result)
   peer.hook=hook
   with pytest.raises(h.MCPToolExecutionError):await client.call_tool('echo',{'text':'x'})
 finally:await client.disconnect()
