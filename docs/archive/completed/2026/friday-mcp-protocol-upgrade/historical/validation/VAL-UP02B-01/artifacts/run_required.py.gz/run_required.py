import json, subprocess, shutil
from pathlib import Path
base=Path('/private/tmp/friday-mcp-upgrade'); dest=base/'independent-review-UP-02B'; work=base/'work'
r=json.loads((work/'docs/planning/active/friday-mcp-protocol-upgrade/validation-request-UP-02B.json').read_text())
checks=[]
for name,argv in r['required_checks'].items(): checks.append((name,'work',argv))
for name,argv in [('baseline-root',r['required_checks']['root']),('baseline-ruff',r['required_checks']['root-ruff'])]: checks.append((name,'http-baseline',argv))
ledger=[]
for name,snapshot,argv in checks:
 label='independent-UP02B-'+name
 p=subprocess.run([str(base/'venv/bin/python'),str(base/'run_check.py'),label,snapshot,*argv],capture_output=True,text=True)
 print(p.stdout.strip(),flush=True)
 if p.stderr: print(p.stderr,flush=True)
 src=base/'checks'/label
 if src.exists():
  target=dest/'checks'/name; shutil.copytree(src,target,dirs_exist_ok=True)
  ledger.append(json.loads((target/'receipt.json').read_text()))
 (dest/'command-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
