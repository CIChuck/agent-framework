import gzip,hashlib,json,subprocess
from pathlib import Path
w=Path('/private/tmp/friday-mcp-upgrade/work');d=Path('/private/tmp/friday-mcp-upgrade/independent-review-UP-02B');p='docs/planning/active/friday-mcp-protocol-upgrade/'
def h(b):return hashlib.sha256(b).hexdigest()
req=json.loads((w/(p+'validation-request-UP-02B.json')).read_text());m=json.loads((w/(p+'authority-UP-02B.json')).read_text());old=json.loads((w/(p+'authority-manifest.json')).read_text());errors=[];records=[]
items=[req['authority_manifest'],m['approval'],m['prior_frozen_manifest'],m['approved_proposal'],*m['controls'],*old['controls'],old['approval'],*req['evidence_inputs']]
for x in items:
 data=(w/x['path']).read_bytes();got=h(data);records.append({'path':x['path'],'sha256':got,'expected':x['sha256']})
 if got!=x['sha256']:errors.append(x['path'])
for path,expected in req['product_hashes'].items():
 got=h((w/path).read_bytes());records.append({'path':path,'sha256':got,'expected':expected})
 if got!=expected:errors.append(path)
for x in m['product_paths']:
 if x['baseline_sha256']:
  data=subprocess.check_output(['git','show',m['product_baseline']+':'+x['path']],cwd=w)
  if h(data)!=x['baseline_sha256']:errors.append('baseline '+x['path'])
controls=[]
for x in old['controls']:
 path=w/x['path']
 if path.suffix in ('.md','.json','.yaml'):
  controls.append('\n\nFILE '+x['path']+'\n'+path.read_text())
(d/'pinned-controls.txt').write_text(''.join(controls))
norm=d/'normative';norm.mkdir(exist_ok=True)
for sub in ['research-sources','research-sources/up02b']:
 manifest=json.loads((w/(p+sub+'/manifest.json')).read_text())
 for x in manifest['sources']:
  b=(w/(p+sub+'/'+x['artifact'])).read_bytes();data=gzip.decompress(b)
  if h(b)!=x['artifact_sha256'] or h(data)!=x['sha256']:errors.append(x['artifact'])
  (norm/x['artifact'].removesuffix('.gz')).write_bytes(data)
(d/'inventory.json').write_text(json.dumps({'errors':errors,'hashes':records,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=w,text=True),'guard_sha256':h(Path('/private/tmp/friday-mcp-upgrade/guard/sitecustomize.py').read_bytes())},indent=2)+'\n')
(d/'full.diff').write_bytes(subprocess.check_output(['git','diff',m['product_baseline']+'..HEAD'],cwd=w))
print(json.dumps({'errors':errors,'verified_hashes':len(records),'normative_files':len(list(norm.iterdir()))}))
