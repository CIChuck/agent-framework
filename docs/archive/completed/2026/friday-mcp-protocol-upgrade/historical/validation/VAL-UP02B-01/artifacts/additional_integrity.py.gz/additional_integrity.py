import gzip,hashlib,json,subprocess,tomllib
from pathlib import Path
w=Path('/private/tmp/friday-mcp-upgrade/work');d=Path('/private/tmp/friday-mcp-upgrade/independent-review-UP-02B');p='docs/planning/active/friday-mcp-protocol-upgrade/';baseline='256d09d2f6a89846b5b77c4ae6436750d9bdbd95';h=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((w/(p+'authority-manifest.json')).read_text());changed_controls=[]
for x in [*old['controls'],old['approval']]:
 try:b=subprocess.check_output(['git','show',baseline+':'+x['path']],cwd=w,stderr=subprocess.DEVNULL)
 except subprocess.CalledProcessError:changed_controls.append({'path':x['path'],'reason':'absent in baseline'});continue
 if b!=(w/x['path']).read_bytes():changed_controls.append({'path':x['path'],'reason':'bytes changed'})
s=json.loads((w/(p+'execution/http/stored-manifest.json')).read_text());artifact_errors=[]
for x in s['artifacts']:
 b=(w/(p+'execution/http/'+x['path'])).read_bytes();data=gzip.decompress(b)
 if h(b)!=x['stored_sha256'] or h(data)!=x['sha256'] or len(data)!=x['bytes']:artifact_errors.append(x['path'])
a=tomllib.loads((w/'uv.lock').read_text());b=tomllib.loads(subprocess.check_output(['git','show',baseline+':uv.lock'],cwd=w,text=True))
# Only permitted direct edge and declaration removed for normalized whole-lock equality.
for package in a['package']:
 if package['name']=='friday-framework-mcp':
  package['dependencies']=[x for x in package['dependencies'] if x.get('name')!='httpcore']
  package['metadata']['requires-dist']=[x for x in package['metadata']['requires-dist'] if x.get('name')!='httpcore']
paths=subprocess.check_output(['git','diff','--name-only',baseline+'..HEAD'],cwd=w,text=True).splitlines();m=json.loads((w/(p+'authority-UP-02B.json')).read_text());allowed={x['path'] for x in m['product_paths']};product=[x for x in paths if x.startswith('packages/') or x=='uv.lock'];outside=[x for x in paths if x not in allowed and not x.startswith(p) and x not in ('docs/planning/board.yaml','docs/planning/README.md')]
identity={'work_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'baseline_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/private/tmp/friday-mcp-upgrade/http-baseline',text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=w,text=True),'product_paths':product,'unexpected_paths':outside,'old_frozen_controls_changed':changed_controls,'stored_artifacts_count':len(s['artifacts']),'stored_artifact_errors':artifact_errors,'lock_normalized_equal_after_only_two_httpcore_edges_removed':a==b}
(d/'additional-integrity.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity,indent=2))
