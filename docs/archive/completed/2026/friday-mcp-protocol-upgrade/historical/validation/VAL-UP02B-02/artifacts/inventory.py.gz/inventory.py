import gzip,hashlib,json,subprocess,tomllib
from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';d=b/'independent-review-UP02B-002';p='docs/planning/active/friday-mcp-protocol-upgrade/'
h=lambda v:hashlib.sha256(v).hexdigest();records=[];errors=[]
def check(path,sha):
 got=h((w/path).read_bytes());records.append(dict(path=path,expected=sha,actual=got));
 if got!=sha:errors.append(path)
req=json.loads((w/(p+'validation-request-REM-MCP-UP-002.json')).read_text());rem=json.loads((w/(p+'authority-REM-MCP-UP-002.json')).read_text());cd=json.loads((w/(p+'authority-UP-02B.json')).read_text());old=json.loads((w/(p+'authority-manifest.json')).read_text());origreq=json.loads((w/(p+'validation-request-UP-02B.json')).read_text())
for x in [req['authority_manifest'],req['original_cd2_authority'],rem['approval'],rem['approved_proposal'],*rem['controls'],cd['approval'],cd['prior_frozen_manifest'],cd['approved_proposal'],*cd['controls'],*old['controls'],old['approval'],*origreq['evidence_inputs']]:check(x['path'],x['sha256'])
for path,sha in req['product_hashes'].items():check(path,sha)
norm=d/'normative';norm.mkdir(exist_ok=True)
for sub in ['research-sources','research-sources/up02b']:
 manifest=json.loads((w/(p+sub+'/manifest.json')).read_text())
 for x in manifest['sources']:
  raw=(w/(p+sub+'/'+x['artifact'])).read_bytes();v=gzip.decompress(raw);check(p+sub+'/'+x['artifact'],x['artifact_sha256']);
  if h(v)!=x['sha256'] or len(v)!=x['bytes']:errors.append(x['artifact']+' uncompressed')
  (norm/x['artifact'].removesuffix('.gz')).write_bytes(v)
for sub in ['execution/http','validation/VAL-UP02B-01','execution/remediation-UP02B-002-builder']:
 m=json.loads((w/(p+sub+'/stored-manifest.json')).read_text())
 for x in m['artifacts']:
  raw=(w/(p+sub+'/'+x['path'])).read_bytes();v=gzip.decompress(raw)
  if h(raw)!=x['stored_sha256'] or h(v)!=x['sha256'] or len(v)!=x['bytes']:errors.append(sub+'/'+x['path'])
 gitbase='05118298b10a396d5aff5de61f074a4ff251b695'
 if sub!='execution/remediation-UP02B-002-builder':
  for x in m['artifacts']:
   path=p+sub+'/'+x['path'];v=subprocess.check_output(['git','show',gitbase+':'+path],cwd=w)
   if v!=(w/path).read_bytes():errors.append('mutated historical artifact '+path)
baseline=req['product_baseline'];changed=subprocess.check_output(['git','diff','--name-only',baseline+'..HEAD'],cwd=w,text=True).splitlines();delta=subprocess.check_output(['git','diff','--name-only',req['remediation_baseline']+'..HEAD'],cwd=w,text=True).splitlines();products=lambda paths:[x for x in paths if x.startswith('packages/') or x=='uv.lock'];allowed=set(req['product_hashes']);scope=set(req['six_path_remediation_scope'])
if set(products(changed))!=allowed:errors.append('fourteen path scope')
if set(products(delta))!=scope:errors.append('six path scope')
for path in changed:
 if path not in allowed and not path.startswith(p) and path not in ['docs/planning/board.yaml','docs/planning/README.md']:errors.append('unexpected '+path)
for x in [*old['controls'],old['approval']]:
 if subprocess.check_output(['git','show',baseline+':'+x['path']],cwd=w)!=(w/x['path']).read_bytes():errors.append('old control drift '+x['path'])
lock=tomllib.loads((w/'uv.lock').read_text());base_lock=tomllib.loads(subprocess.check_output(['git','show',baseline+':uv.lock'],cwd=w,text=True))
for pkg in lock['package']:
 if pkg['name']=='friday-framework-mcp':
  pkg['dependencies']=[v for v in pkg['dependencies'] if v.get('name')!='httpcore'];pkg['metadata']['requires-dist']=[v for v in pkg['metadata']['requires-dist'] if v.get('name')!='httpcore']
if lock!=base_lock:errors.append('dependency churn')
for path in ['uv.lock','packages/friday-mcp/pyproject.toml']:
 if subprocess.check_output(['git','show',req['remediation_baseline']+':'+path],cwd=w)!=(w/path).read_bytes():errors.append('remediation dependency drift')
for label,sha in [('full',baseline),('remediation',req['remediation_baseline'])]:
 diff=subprocess.check_output(['git','diff',sha+'..HEAD'],cwd=w);(d/(label+'.diff')).write_bytes(diff)
 productdiff=subprocess.check_output(['git','diff',sha+'..HEAD','--',*allowed],cwd=w);(d/(label+'-product.diff')).write_bytes(productdiff)
 for line in productdiff.decode().splitlines():
  if line.startswith('+') and not line.startswith('+++') and any(v in line for v in ['# type: ignore','# mypy:','# noqa']):errors.append('new suppression '+line)
if h(gzip.decompress((w/(p+'validation/VAL-UP02B-01/artifacts/report.md.gz')).read_bytes()))!='e97e199a556be162ff99a46d6d3ec6db75de3ef61cff5985447b47fbd73487c3':errors.append('prior report bytes')
data=dict(errors=errors,hashes=records,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),branch=subprocess.check_output(['git','branch','--show-current'],cwd=w,text=True).strip(),status=subprocess.check_output(['git','status','--short'],cwd=w,text=True),overall_products=products(changed),delta_products=products(delta),guard_sha256=h((b/'guard/sitecustomize.py').read_bytes()),baseline_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=b/'http-baseline',text=True).strip())
(d/'inventory.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({'errors':errors,'hashes':len(records),'captures':len(list(norm.iterdir())),'head':data['head'],'status':data['status']}))
