"""Reviewer reconciliation of every frozen clause and selected schema field."""
import json,re,gzip,hashlib
from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';d=b/'independent-review-UP02B-002';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';original=json.loads((p/'execution/http/normative-clause-ledger.json').read_text());sources={}
for sub in ['research-sources','research-sources/up02b']:
 for x in json.loads((p/sub/'manifest.json').read_text())['sources']:
  sources[x['url']]=dict(text=gzip.decompress((p/sub/x['artifact']).read_bytes()).decode(),sha=x['sha256'],artifact=x['artifact'].removesuffix('.gz'))

# Independent semantic families, source implementation, and reproduced evidence.
families={
 'core':{'reason':'Selected JSON-RPC, per-request metadata, versions and honest capabilities: unique IDs, matching envelopes, fixed errors, exact modern result tags, typed known metadata. Opaque application JSON remains data. No trace propagation or subscription opt-in.','source':['http.py:_decode/_request_budget/_handshake','protocol.py:validate_message/complete_result/Discovery.parse/_metadata'],'checks':['http','original','original-reproducers','fresh-probes-corrected'],'criteria':['HTTP-AC-01','HTTP-AC-02','HTTP-AC-10']},
 'wire':{'reason':'Each request/control is one POST to configured endpoint; exact Accept and content types, UTF-8 JSON/SSE, status/envelope/ID validation, concurrent stream isolation. Server-only clauses establish adverse-peer validation, not a client server implementation claim.','source':['http.py:_headers/_exchange/_server_message','http_protocol.py:SSEDecoder/response_headers/content_type'],'checks':['http','original'],'criteria':['HTTP-AC-01','HTTP-AC-02','HTTP-AC-04','HTTP-AC-09']},
 'headers':{'reason':'Properties-only reachable scalar annotations, safe token/name uniqueness, safe integer/header encoding, null/absent omission, invalid schema-location annotations exclude entire tool after complete atomic catalog validation. All 2020-12 schema-bearing children audited; example/default/const values opaque.','source':['http_protocol.py:header_bindings/HeaderBinding.extract/header_value','http.py:list_tools/_headers'],'checks':['http','original-reproducers','fresh-probes-corrected'],'criteria':['HTTP-AC-03','HTTP-AC-04','HTTP-AC-09']},
 'results':{'reason':'Bounded catalog pagination and complete/result/schema parsing; 2025 input declarations reject unsupported dialects before publication; modern/2024 behavior preserved. Supported text/structured results and output schema snapshot retained; unsupported content/schema/input-required fail explicitly without I/O/replay. Annotations retained as untrusted, never grants authority.','source':['http.py:list_tools/_request_budget/call_tool','protocol.py:ToolDefinition/CatalogPage/ToolResult/validate_compatibility_fields/validate_output_schema/validate_structured','base.py:call_tool'],'checks':['http','original','original-reproducers','fresh-probes-corrected'],'criteria':['HTTP-AC-01','HTTP-AC-04','HTTP-AC-05','HTTP-AC-10']},
 'compat':{'reason':'Exact 2025 initialize precedes normal calls, validates negotiated revision/identity/capabilities, initialized then origin-scoped session headers; generation-aware serialized one recovery without old ID or mutation replay, bounded DELETE. Failure/deadline/shutdown owns only its generation.','source':['http.py:connect/_handshake/_exchange/_request_budget/disconnect','http_protocol.py:session_id','protocol.py:validate_compatibility_fields'],'checks':['http','original-reproducers','fresh-probes-corrected'],'criteria':['HTTP-AC-01','HTTP-AC-04','HTTP-AC-05','HTTP-AC-06','HTTP-AC-08']},
 'cancel':{'reason':'Modern HTTP cancellation closes its owned stream only; 2025 cancellation is issued non-initialize requests only, bounded control preserves primary errors. Retained-resistant task/stream/pool owners remain observable, capacity-bounded and retryable; borrowed providers are not closed.','source':['http.py:_start/_wait/_request_budget/_close_response/_disconnect_owned'],'checks':['http','fresh-probes-corrected','original'],'criteria':['HTTP-AC-04','HTTP-AC-05','HTTP-AC-08']},
 'safety':{'reason':'Verified HTTPS and exact endpoint/port, every DNS candidate checked at actual connect, numeric connector address with original SNI; no second DNS, redirects/proxies/cookies/ambient credential fetch. Origin-scoped supplied bearer only; fixed payload-free diagnostics, fail-closed transport DEBUG. No peer URL fetch or rendering.','source':['http_policy.py:HTTPEndpoint/HTTPEndpointPolicy/PolicyHTTPBackend/AsyncioHTTPBackend/BoundedHTTPStream','http.py:safe_http_logging/_headers/_exchange'],'checks':['http','cross','root'],'criteria':['HTTP-AC-07','HTTP-AC-08','HTTP-AC-10']},
 'excluded':{'reason':'Outside this explicitly approved programmatic tools profile: OAuth discovery/login/redirect/refresh and authorization server, proxy/server features, icon rendering, subscriptions/GET/resumption, MRTR fulfillment, sampling/roots/elicitation/resources/prompts/tasks and one-click configuration. No successful operation or advertised capability for these; unsupported input/content fails safely.','source':['http.py:_request_budget/_server_message','protocol.py:complete_result/ToolResult'],'checks':['http','original','cross'],'criteria':['HTTP-AC-01','HTTP-AC-05','HTTP-AC-10']},
 'preserved':{'reason':'Separate accepted stdio transport; source unchanged and all four original focused client files rerun with SDK child and exact legacy peer. Modern stdio notifications/cancellation and auto fallback remain accepted behavior; HTTP does not select it.','source':['client/stdio.py unchanged','base.py:_create_transport/call_tool'],'checks':['original','package','root'],'criteria':['HTTP-AC-01','HTTP-AC-10']},
}

def classify(i,x):
 url=x['source'];text=x['paragraph'];g=x.get('group')
 if i==0:return 'excluded','Terminology only; two SHALL occurrences were omitted from original347 count, both are definitions, not duties.'
 if i in (25,26,27,155,156,157,172,174,178,181,182,183,184,185,186,187,188,190,191,192,193,194,195,196,197,204,208,213,214,215,216,217):return 'excluded',None
 if 91<=i<=107 or i in (112,114,115,116,117,118,119):return 'excluded',None
 if i in (108,109,110,111,113):return 'safety','Explicit bearer origin binding applies; acquisition/audience assurance belongs to the supplying secret provider, no OAuth machinery is claimed.'
 if 79<=i<=90:
  return ('core',None) if i==80 else ('excluded','MRTR request input is unsupported; requestState is never interpreted, constructed or replayed. Conditional retry obligations do not trigger.')
 if i in (171,173):return 'wire','POST and optional-stream clauses reconciled separately; POST Accept/single envelope apply. GET/resumption excluded; concurrent requests each own their response.'
 if i==175:return 'compat',None
 if i in (179,180,205,206,207,209,210,128,129):return 'cancel','Issued non-initialize cancellation rules apply; tasks/subscription-specific clauses excluded. Modern HTTP closes its stream; original stdio notification rules independently preserved.'
 if i in (33,34,35,36,37,38,167):return 'preserved',None
 if 120<=i<=141:
  if i in (133,135,136,137,138,139,140,141):return 'excluded',None
  if i in (124,125,126):return 'wire',None
  if i==127:return 'excluded','Input-required returns explicit unsupported disposition; no continuation or state replay.'
  if i==134:return 'results','Cache scope/TTL shape validated, no cross-authorization cache reuse; catalogs refreshed explicitly.'
  return 'core',None
 if i==211:return 'compat',None
 if i==212:return 'excluded',None
 if i==189:return 'safety','OAuth URL fetching is excluded; programmatic endpoint SSRF mitigation is separately enforced before and at connect.'
 if i==198:return 'safety','Received URLs retained as bounded untrusted metadata and never dereferenced/opened/rendered; only configured endpoint can produce network I/O.'
 if i in (12,13,14,15,16,149,150,151):return 'results',None
 if g in families:return g,None
 return 'excluded',None

rows=[];issues=[]
for i,x in enumerate(original['clauses']):
 s=sources[x['source']];paragraph=x['paragraph'];normalized=lambda v:' '.join(v.split())
 if normalized(paragraph) not in normalized(s['text']):issues.append('clause source mismatch '+str(i))
 if x['source_sha256']!=s['sha']:issues.append('clause source hash '+str(i))
 family,note=classify(i,x);e=families[family]
 rows.append({'id':f'CLAUSE-{i+1:03d}','original_index':i,'source':x['source'],'artifact':s['artifact'],'source_sha256':s['sha'],'line':x['line'],'paragraph':paragraph,'independent_mandatory_tokens':len(re.findall(r'\b(?:MUST|SHALL|REQUIRED)\b',paragraph)),'disposition':'PROFILE_EXCLUDED' if family=='excluded' else 'PASS_OR_PEER_VALIDATION','family':family,'reason':note or e['reason'],'source_evidence':e['source'],'command_evidence':e['checks'],'criteria':e['criteria']})
# Independently scan the complete captures for missing mandatory paragraphs.
covered={' '.join(x['paragraph'].split()) for x in rows};missing=[]
for url,s in sources.items():
 for paragraph in re.split(r'\n\s*\n',s['text']):
  if re.search(r'\b(?:MUST|SHALL|REQUIRED)\b',paragraph) and ' '.join(paragraph.split()) not in covered:missing.append({'source':url,'paragraph':paragraph})
if missing:issues.append('mandatory paragraphs missing')
# Reconcile every selected schema interface and each of its231 frozen fields.
schemas=[]
for x in original['selected_schema_interfaces']:
 s=sources[x['source']];source_lines=s['text'].splitlines();kind=x['type']
 if x['definition'] not in s['text']:issues.append('schema definition '+kind)
 for f in x['fields']:
  if f['declaration'] not in source_lines[f['line']-1]:issues.append('schema field '+kind+':'+str(f['line']))
 family='core'
 if kind in ('Tool','ToolAnnotations','TextContent','Annotations','CallToolResult','CallToolResultResponse','ListToolsResult','ListToolsResultResponse','PaginatedResult','CacheableResult'):family='results'
 elif kind.startswith('CallTool') or kind.startswith('ListTools') or kind.startswith('PaginatedRequest'):family='wire'
 elif kind in ('Icon','Icons','InputRequest','InputRequests','InputRequiredResult','TaskAugmentedRequestParams','ToolExecution'):family='excluded'
 elif kind.startswith('Initialize') or kind=='InitializedNotification':family='compat'
 elif kind.startswith('Cancelled'):family='cancel'
 elif kind.endswith('Error'):family='wire'
 fields=[]
 for f in x['fields']:
  declaration=f['declaration'];override=None
  if kind=='RequestMetaObject' and any(key in declaration for key in ('progressToken','logLevel')):override='No progress token or log level is advertised/sent; not enabled.'
  if kind in ('ClientCapabilities','ServerCapabilities'):override='Client capabilities are empty; known received server capability members validated, unsupported feature members do not enable execution. Unknown bounded capability objects remain untrusted.'
  if kind=='Tool' and 'inputSchema' in declaration:override='2020-12 declared/default input-schema validation. Unknown/malformed declaration fails unsupported_schema before complete catalog publication; no schema retrieval. HTTP annotations only in modern profile.'
  fields.append({**f,'family':family,'reason':override or families[family]['reason'],'source_evidence':families[family]['source'],'command_evidence':families[family]['checks']})
 schemas.append({'source':x['source'],'source_sha256':s['sha'],'type':kind,'line':x['line'],'definition':x['definition'],'family':family,'fields':fields,'command_evidence':families[family]['checks']})
data={'status':'Independent source/candidate reconciliation; builder mappings not used as verdict','capture_count':len(sources),'frozen_clause_count':len(rows),'frozen_mandatory_occurrences':347,'independent_mandatory_token_count':sum(x['independent_mandatory_tokens'] for x in rows),'terminology_count_note':'349 versus347 differs solely by two SHALL terms in BCP14 terminology definition; no missing obligation','missing_mandatory_paragraphs':missing,'selected_schema_interfaces':schemas,'schema_interface_count':len(schemas),'schema_field_count':sum(len(x['fields']) for x in schemas),'clauses':rows,'families':families,'issues':issues}
(d/'normative-clause-schema-review.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({k:data[k] for k in ['capture_count','frozen_clause_count','independent_mandatory_token_count','schema_interface_count','schema_field_count','issues']}))
