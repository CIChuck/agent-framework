"""Fresh reviewer assertions; reuse controlled wire peer only, not builder tests."""
import asyncio
import importlib.util
import json
import sys
from copy import deepcopy
from pathlib import Path
import pytest
from friday_mcp.client.protocol import ProtocolFailure, ProtocolLimits, ToolDefinition, ToolResult, validate_message, validate_compatibility_fields, META_PREFIX
from friday_mcp.client.http_protocol import header_bindings, HTTP_COMPAT_VERSION
spec=importlib.util.spec_from_file_location('fresh_wire_peer',Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/client/test_http_lifecycle.py'))
h=importlib.util.module_from_spec(spec);sys.modules[spec.name]=h;spec.loader.exec_module(h)

# Audit every 2020-12 schema-bearing keyword, plus preserved draft aliases.
@pytest.mark.parametrize('keyword',['$defs','definitions','dependencies','patternProperties','dependentSchemas','items','contains','additionalItems','additionalProperties','unevaluatedItems','unevaluatedProperties','propertyNames','contentSchema','not','if','then','else','allOf','anyOf','oneOf','prefixItems'])
def test_unreachable_schema_vocabulary(keyword):
 child={'type':'string','x-mcp-header':'ValidToken'}
 if keyword in ('$defs','definitions','dependencies','patternProperties','dependentSchemas'):child={'node':child}
 elif keyword in ('allOf','anyOf','oneOf','prefixItems'):child=[child]
 schema={'type':'object',keyword:child}
 with pytest.raises(ProtocolFailure):header_bindings(schema)

@pytest.mark.asyncio
async def test_invalid_header_catalog_count_opaque_json_exact_wire_and_no_issue():
 peer=h.Peer();opaque={'contentSchema':{'x-mcp-header':'bad name'},'_meta':{'bad/name/key':1}}
 peer.tools[0]['inputSchema']['properties']['text']['examples']=[opaque]
 peer.tools[0]['inputSchema']['properties']['text']['default']=opaque
 peer.tools[0]['inputSchema']['examples']=[opaque]
 for i,annotation in enumerate(['Good','bad name',7,None,{},'']):
  peer.tools.append({'name':f'bad{i}','inputSchema':{'type':'object','properties':{'payload':{'type':'string','contentSchema':{'contentSchema':{'properties':{'x':{'type':'integer','x-mcp-header':annotation}}}}}}}})
 c,_,_=await h.ready_client(peer=peer)
 try:
  assert [t['name'] for t in await c.list_tools()]==['echo'];assert c.rejected_http_tools==6
  before=len(peer.requests)
  for i in range(6):
   with pytest.raises(h.MCPToolExecutionError):await c.call_tool(f'bad{i}',{'payload':'x'})
  assert len(peer.requests)==before
  assert await c.call_tool('echo',{'text':' =?base64?QQ==?= '})==' =?base64?QQ==?= '
  assert peer.requests[-1][1][b'mcp-param-text']==b'=?base64?ID0/YmFzZTY0P1FRPT0/PSA=?='
 finally:await c.disconnect()
 assert c.outstanding_http_owners==0 and all(s.closed for s in peer.streams)

@pytest.mark.parametrize('key',['.name','name.','_name','name_','a/9_x_','a.-b/key','a.b-/key','a.9b/key','a_b/key','a//','a/b/c','/','a/\n'])
@pytest.mark.parametrize('boundary',['tool','result','text','initialize','list','request','notification'])
def test_dated_invalid_metadata_independent_boundaries(key,boundary):
 meta={key:{'private':'payload'}};result={}
 if boundary in ('request','notification'):
  message={'jsonrpc':'2.0','method':'unsupported','params':{'_meta':meta}}
  if boundary=='request':message['id']='server'
  invoke=lambda:validate_message(message,ProtocolLimits(),compatibility=True)
 elif boundary=='tool':
  invoke=lambda:validate_compatibility_fields({'tools':[{'name':'a','inputSchema':{'type':'object'},'_meta':meta}]},'tools/list',ProtocolLimits())
 elif boundary=='text':invoke=lambda:validate_compatibility_fields({'content':[{'type':'text','text':'ok','_meta':meta}]},'tools/call',ProtocolLimits())
 else:
  result={'_meta':meta}
  if boundary=='initialize':result.update(serverInfo={'name':'a','version':'1'},capabilities={})
  elif boundary=='list':result['tools']=[]
  else:result['content']=[]
  invoke=lambda:validate_compatibility_fields(result,{'list':'tools/list','initialize':'initialize'}.get(boundary,'tools/call'),ProtocolLimits())
 with pytest.raises(ProtocolFailure) as caught:invoke()
 assert caught.value.failure_code=='invalid_protocol' and str(caught.value)=='Invalid MCP protocol message'

@pytest.mark.parametrize('key',['','9','0.a-9_Z','A1.B2/','A1.B2/9','io.modelcontextprotocol/serverInfo','io.modelcontextprotocol/subscriptionId'])
def test_dated_valid_metadata_is_opaque_legacy_and_modern_context_distinct(key):
 opaque={'bad/name/key':{'_meta':{'/bad':1}}}
 result={'content':[{'type':'text','text':'ok','_meta':{key:opaque}}],'_meta':{key:opaque},'structuredContent':opaque}
 validate_compatibility_fields(result,'tools/call',ProtocolLimits())
 assert json.loads(ToolResult.parse(result,False,ProtocolLimits()).text(ProtocolLimits()))['structuredContent']==opaque
 legacy={'name':'a','inputSchema':{'type':'object','$schema':'unknown'},'_meta':{'/bad':1}}
 assert ToolDefinition.parse(legacy,ProtocolLimits()).name=='a'
 with pytest.raises(ProtocolFailure):validate_message({'jsonrpc':'2.0','id':'r','result':{'resultType':'complete','_meta':{META_PREFIX+'serverInfo':opaque}}},ProtocolLimits(),modern=True)

@pytest.mark.asyncio
@pytest.mark.parametrize('dialect',[False,[],123,'https://json-schema.org/draft/2020-12/schema#','http://json-schema.org/draft/2020-12/schema'])
async def test_later_page_dialect_failure_removes_old_catalog_and_zero_schema_fetch(dialect):
 peer=h.Peer(HTTP_COMPAT_VERSION);c,_,resolver=await h.ready_client(peer=peer)
 bad=deepcopy(peer.tools[0]);bad['name']='late';bad['inputSchema']['$schema']=dialect
 def hook(verb,headers,r):
  if r.get('method')=='tools/list':return peer.rpc(r,{'tools':[bad]} if 'cursor' in r['params'] else {'tools':peer.tools,'nextCursor':'second'})
 peer.hook=hook
 try:
  before=len(peer.requests)
  with pytest.raises(ProtocolFailure) as caught:await c.list_tools()
  assert caught.value.failure_code=='unsupported_schema';assert c._catalog==() and not c._bindings
  assert len(peer.requests)==before+2 and resolver.calls==len(peer.requests)
  # No call is issued by catalog validation. The preserved 2025 low-level
  # API permits explicit uncatalogued calls; modern mandatory bindings differ.
  assert 'tools/call' not in peer.methods()
 finally:await c.disconnect()

class OrderedStream(h.WireStream):
 async def read(self,n,timeout=None):
  await self.ready.wait()
  if b'"text":"old"' in self.outgoing:await self.connector.release_old.wait()
  return await super().read(n,timeout)
class OrderedPeer(h.Peer):
 def __init__(self):super().__init__(HTTP_COMPAT_VERSION);self.release_old=asyncio.Event();self.old_issued=asyncio.Event()
 async def connect_tcp(self,host,port,timeout=None,local_address=None,socket_options=None):
  self.connections.append((host,port));s=OrderedStream(self);self.streams.append(s);return s
 def dispatch(self,verb,headers,r):
  if r.get('method')=='tools/call' and r['params']['arguments'].get('text')=='old':self.old_issued.set()
  return super().dispatch(verb,headers,r)

@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['healthy','failed','deadline','disconnect-during-recovery'])
async def test_generation_owned_recovery_serialization_and_cleanup(mode):
 peer=OrderedPeer();c,_,_=await h.ready_client(peer=peer);recover_started=asyncio.Event();recover_release=asyncio.Event();failed=False
 def hook(verb,headers,r):
  nonlocal failed
  if r.get('method')=='tools/call':return h.Reply(status=404)
  if r.get('method')=='initialize':
   if mode=='failed' and not failed:failed=True;return h.Reply(body=b'bad')
   if mode in ('deadline','disconnect-during-recovery'):
    recover_started.set();peer.sessions+=1
    return peer.rpc(r,{'protocolVersion':HTTP_COMPAT_VERSION,'serverInfo':{'name':'p','version':'1'},'capabilities':{'tools':{}}},headers=[('MCP-Session-Id',f'session-{peer.sessions}')],stall=recover_release)
 peer.hook=hook;old=asyncio.create_task(c.call_tool('echo',{'text':'old'}));fast=None;closing=None
 try:
  await asyncio.wait_for(peer.old_issued.wait(),1)
  fast=asyncio.create_task(c._request('tools/call',{'name':'echo','arguments':{'text':'fast'}},timeout=.07 if mode=='deadline' else 1))
  if mode=='disconnect-during-recovery':
   await asyncio.wait_for(recover_started.wait(),1);closing=asyncio.create_task(c.disconnect());await asyncio.sleep(0);recover_release.set()
  result=await asyncio.gather(fast,return_exceptions=True);assert isinstance(result[0],(ProtocolFailure,asyncio.CancelledError))
  if closing is not None:await closing
  if mode!='healthy':
   assert not c.is_connected;peer.hook=None;await c.connect()
  peer.hook=None;await c.list_tools();catalog=c._catalog;generation=c._generation;session=c._session_id
  peer.release_old.set();oldresult=await asyncio.gather(old,return_exceptions=True);assert isinstance(oldresult[0],(h.MCPToolExecutionError,asyncio.CancelledError))
  assert c.is_connected and c._catalog is catalog and c._generation==generation and c._session_id==session
  assert peer.methods().count('tools/call')==2
  assert peer.methods().count('initialize')==(2 if mode=='healthy' else 3)
  assert all(b'mcp-session-id' not in headers for _,headers,r in peer.requests if r.get('method')=='initialize')
  assert await c.call_tool('echo',{'text':'explicit'})=='explicit'
  assert peer.methods().count('tools/call')==3
 finally:
  peer.release_old.set();recover_release.set()
  await asyncio.gather(*(t for t in (old,fast,closing) if t is not None),return_exceptions=True);await c.disconnect()
 assert c.outstanding_http_owners==0 and c._pool is None and all(s.closed for s in peer.streams)