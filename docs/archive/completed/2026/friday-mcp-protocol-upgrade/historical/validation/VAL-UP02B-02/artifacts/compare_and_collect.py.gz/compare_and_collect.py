import json,shutil,re,hashlib
from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade');d=b/'independent-review-UP02B-002';ledger=[]
for src in sorted((b/'checks').glob('review-rem002-*')):
 if (src/'receipt.json').exists():
  n=src.name.removeprefix('review-rem002-');target=d/'checks'/n;shutil.copytree(src,target,dirs_exist_ok=True);r=json.loads((target/'receipt.json').read_text());r['label']=n;ledger.append(r)
(d/'command-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')

def normalize(value):
 if isinstance(value,str):return value.replace(str(b/'http-baseline'),'<snapshot>').replace(str(b/'work'),'<snapshot>')
 if isinstance(value,list):return [normalize(x) for x in value]
 if isinstance(value,dict):return {k:normalize(v) for k,v in value.items()}
 return value
cand=normalize(json.loads((d/'checks/root-ruff/stdout').read_text()));base=normalize(json.loads((d/'checks/baseline-ruff/stdout').read_text()));dump=lambda v:json.dumps(v,sort_keys=True)
cs={dump(x) for x in cand};bs={dump(x) for x in base};ruff={'candidate_count':len(cand),'baseline_count':len(base),'full_normalized_diagnostic_fix_objects_equal':sorted(map(dump,cand))==sorted(map(dump,base)),'new':[json.loads(x) for x in sorted(cs-bs)],'removed':[json.loads(x) for x in sorted(bs-cs)],'candidate_objects':cand,'baseline_objects':base}
(d/'ruff-comparison.json').write_text(json.dumps(ruff,indent=2)+'\n')

def extract(name):
 t=normalize((d/'checks'/name/'stdout').read_text());warn=t.split('=============================== warnings summary ===============================\n',1)[-1].split('-- Docs:',1)[0] if 'warnings summary' in t else ''
 skips=[line for line in t.splitlines() if line.startswith('SKIPPED [')];summary=[line for line in t.splitlines() if re.search(r'\d+ passed',line)][-1]
 classes=sorted(set(re.findall(r'([A-Z][A-Za-z0-9_]*(?:Warning|DeprecatedSince\d+)): ',warn)))
 return {'summary':summary,'skips':skips,'full_warning_section':warn,'warning_classes':classes}
a=extract('root-skip-details');c=extract('baseline-skip-details');comparison={'candidate':a,'baseline':c,'exact_skip_locations_reasons_equal':a['skips']==c['skips'],'full_normalized_warning_sections_equal':a['full_warning_section']==c['full_warning_section'],'warning_classes_equal':a['warning_classes']==c['warning_classes']}
(d/'baseline-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');print(json.dumps({'ruff':{k:ruff[k] for k in ['candidate_count','baseline_count','full_normalized_diagnostic_fix_objects_equal','new','removed']},'candidate_root':a['summary'],'baseline_root':c['summary'],'skip_reasons_equal':comparison['exact_skip_locations_reasons_equal'],'warning_sections_equal':comparison['full_normalized_warning_sections_equal'],'classes':a['warning_classes'],'checks':len(ledger)}))
