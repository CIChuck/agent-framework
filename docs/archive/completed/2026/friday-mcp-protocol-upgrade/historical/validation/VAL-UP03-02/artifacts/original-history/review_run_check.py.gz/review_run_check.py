import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

base = Path('/private/tmp/friday-mcp-upgrade')
label, snapshot, *argv = sys.argv[1:]
work = base / snapshot
output = base / 'independent-review-UP03' / 'checks' / label
output.mkdir(parents=True, exist_ok=True)
home = base / 'independent-review-UP03' / 'runtime' / 'homes' / label
home.mkdir(parents=True, exist_ok=True)
pythonpath = [str(base / 'guard')] + [str(p) for p in sorted((work / 'packages').glob('*/src'))] + [str(work / 'packages/friday-chat/tests_chat')]
environment = {
    'PATH': str(base / 'venv/bin') + ':/opt/homebrew/bin:/usr/bin:/bin',
    'HOME': str(home), 'TMPDIR': str(base / 'independent-review-UP03' / 'runtime' / 'tmp'), 'PYTHONPATH': ':'.join(pythonpath),
    'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0',
    'PYTEST_ADDOPTS': '--import-mode=importlib -o cache_dir=' + str(home / 'pytest-cache'),
    'MYPY_CACHE_DIR': str(home / 'mypy-cache'), 'RUFF_CACHE_DIR': str(home / 'ruff-cache'),
    'UV_CACHE_DIR': str(base / 'independent-review-UP03' / 'runtime' / 'cache'), 'UV_NO_SYNC': '1', 'UV_OFFLINE': '1',
    'UV_PROJECT_ENVIRONMENT': str(base / 'venv'), 'VIRTUAL_ENV': str(base / 'venv'),
    'FRIDAY_TELEMETRY_ENABLED': 'false', 'ANONYMIZED_TELEMETRY': 'false',
    'TOKENIZERS_PARALLELISM': 'false',
    'XDG_CACHE_HOME': str(home / '.cache'), 'MPLCONFIGDIR': str(home / 'mpl'),
}
(base / 'independent-review-UP03' / 'runtime' / 'tmp').mkdir(parents=True,exist_ok=True)
started = datetime.now(timezone.utc).isoformat()
freeze_path = output / 'before-execution.json'
freeze = json.loads(freeze_path.read_text()) if freeze_path.exists() else {}
freeze['environment'] = environment
freeze['review_runner_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
freeze['started_utc'] = started
freeze_path.write_text(json.dumps(freeze, indent=2) + '\n')
with (output / 'stdout').open('wb') as stdout, (output / 'stderr').open('wb') as stderr:
    process = subprocess.run(argv, cwd=work, env=environment, stdout=stdout, stderr=stderr)
receipt = {'argv': argv, 'cwd': str(work), 'environment': environment, 'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': process.returncode, 'stdout_sha256': hashlib.sha256((output / 'stdout').read_bytes()).hexdigest(), 'stderr_sha256': hashlib.sha256((output / 'stderr').read_bytes()).hexdigest(), 'guard_sha256': hashlib.sha256((base / 'guard/sitecustomize.py').read_bytes()).hexdigest()}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'check': label, 'exit': process.returncode, 'evidence': str(output)}))
