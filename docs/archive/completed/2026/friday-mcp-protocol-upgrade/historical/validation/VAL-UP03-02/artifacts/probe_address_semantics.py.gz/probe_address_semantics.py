"""No-I/O independent proof of accepted address policy semantics."""
import json
from friday_mcp.client import HTTPEndpointPolicy
policy=HTTPEndpointPolicy(allowed_addresses=('127.0.0.1',),allowed_ports=(443,))
print(json.dumps({'listed_private_address_permitted':policy.permits('127.0.0.1'),'different_unlisted_public_address_permitted':policy.permits('93.184.216.34'),'different_unlisted_private_address_denied':not policy.permits('10.0.0.1'),'conclusion':'allowed_addresses adds exact private permissions; eligible public addresses remain permitted'}))
if not policy.permits('93.184.216.34'):
 raise RuntimeError('Policy no longer has the semantics observed in source')
