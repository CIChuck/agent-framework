import hashlib,json,os,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade'); r=b/'independent-review-UP03'; w=b/'work'; req=json.loads((w/'docs/planning/active/friday-mcp-protocol-upgrade/validation-request-UP-03.json').read_text())
for c in req['required_checks']:
    if c['id'] != 'narrow-mypy': continue
    label='probe-warm-'+c['id']; check=r/'checks'/label; check.mkdir(parents=True,exist_ok=True)
    snapshot=b/c['snapshot']; hashes={p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in req['product_hashes']}; metadata={p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in req['metadata_hashes']}
    freeze={'utc':datetime.now(timezone.utc).isoformat(),'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True),'argv':c['argv'],'snapshot':str(snapshot),'product_hashes':hashes,'metadata_hashes':metadata,'guard_sha256':hashlib.sha256((b/'guard/sitecustomize.py').read_bytes()).hexdigest(),'pinned_runner_sha256':hashlib.sha256((b/'run_check.py').read_bytes()).hexdigest(),'review_runner_sha256':hashlib.sha256((r/'review_run_check.py').read_bytes()).hexdigest(),'effects':req['permitted_effects']}
    (check/'before-execution.json').write_text(json.dumps(freeze,indent=2)+'\n')
    result=subprocess.run([sys.executable,str(r/'review_run_check.py'),label,c['snapshot'],*c['argv']],capture_output=True,text=True)
    (check/'orchestrator.stdout').write_text(result.stdout); (check/'orchestrator.stderr').write_text(result.stderr)
    print(result.stdout.strip(),flush=True)
    if result.returncode: print('RUNNER FAILURE',result.returncode,flush=True); sys.exit(1)
