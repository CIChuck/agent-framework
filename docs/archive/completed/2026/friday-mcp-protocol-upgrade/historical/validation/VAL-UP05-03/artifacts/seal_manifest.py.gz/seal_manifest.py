import hashlib,json
from pathlib import Path
from datetime import datetime,timezone
R=Path('/private/tmp/friday-mcp-upgrade/independent-review-UP05-003')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
top=[
'snapshot.py','run_check_UP05.py','run_profile.py','run_probes.py','compare_checks.py','assess_mapping.py','finalize_report.py','format_report.py','seal_manifest.py',
'before-first-command.json','after-last-command.json','final-after-all-checks.json','final-integrity-chronology.json','review-setup-observations.json','scope-proof.json',
'runner-destinations-only.diff','remediation.diff','full-unit.diff','source-capture-integrity.json','full-unit-field-clause-assessment.json','actual-assertion-extracts.json',
'root-ruff-normalized-objects.json','baseline-root-ruff-normalized-objects.json','full-mypy-column-objects.json','baseline-full-mypy-column-objects.json',
'root-warnings-skips.json','baseline-root-warnings-skips.json','exact-profile-comparison.json','findings.json','report.md',
'test_review_edges.py','test_standard_header_live.py','test_application_header_boundary.py','test_field_variants.py']
selected=[R/n for n in top]
selected+=sorted(p for p in (R/'inputs').rglob('*') if p.is_file())
checks=list((R/'checks').iterdir());assert len(checks)==27
for d in checks:
 assert d.is_dir();selected.extend(d/n for n in ['preflight.json','receipt.json','stdout','stderr'])
assert len(selected)==len(set(selected))
for p in selected:
 relative=p.relative_to(R);assert not p.is_symlink() and p.is_file()
 assert not any(part in ['runtime','.git','__pycache__','homes','tmp','cache','.friday'] for part in relative.parts)
 assert p.suffix not in ['.pem','.key','.pyc','.gz','.zip','.tgz','.sqlite3','.db','.bin']
entries=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(selected)]
for e in entries:
 p=R/e['path'];assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256']
verification={'outcome':'VERIFIED','candidate':'012430089bcd1b60b12c071b8c8220f20d2bac79','sealed_at_utc':datetime.now(timezone.utc).isoformat(),'entry_count':len(entries)+1,'every_preexisting_safe_entry_verified':True,'report_sha256':sha(R/'report.md'),'explicit_exclusions':['runtime HOME','TMP','caches','stores','TLS certificates/private keys','.git','bytecode','generated archives'],'original_candidate_governed_state_stable':True,'evidence_mutations_stop_after_seal':True}
(R/'seal-verification.json').write_text(json.dumps(verification,indent=2)+'\n');p=R/'seal-verification.json';entries.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)});entries.sort(key=lambda e:e['path'])
manifest={'schema':'explicit-safe-evidence-v1','outcome':'VERIFIED','reviewer':'/root/rem006_r1_fresh_full_validator','candidate':'012430089bcd1b60b12c071b8c8220f20d2bac79','entry_count':len(entries),'artifacts':entries,'exclusions':verification['explicit_exclusions']}
(R/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for e in entries:
 p=R/e['path'];assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256']
digest=sha(R/'evidence-manifest.json');(R/'evidence-manifest.sha256').write_text(digest+'  evidence-manifest.json\n')
print(json.dumps({'outcome':'VERIFIED','SEALED':True,'report_sha256':sha(R/'report.md'),'manifest_sha256':digest,'entry_count':len(entries),'verified_every_safe_entry':True,'candidate_stable':True}))
