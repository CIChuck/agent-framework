"""Independent dependent-field omission/null/wrong-type checks through actual APIs."""
import copy,json
import pytest
from friday_mcp.server import ModernToolsMCPServer,RegisteredTool,ToolCallResult,ServerWireError
from friday_mcp.server.protocol import ServerRequest,ServerLimits
P='io.modelcontextprotocol/';V='2026-07-28'
def rpc(meta):return json.dumps({'jsonrpc':'2.0','id':5,'method':'server/discover','params':{'_meta':meta}}).encode()
@pytest.mark.asyncio
async def test_implementation_all_fields_omission_null_and_bad_types():
 s=ModernToolsMCPServer();base={P+'protocolVersion':V,P+'clientCapabilities':{}}
 full={'name':'fixture','version':'1','title':'title','description':'description','websiteUrl':'https://example.invalid','icons':[{'src':'data:image/png;base64,AA==','mimeType':'image/png','sizes':['any'],'theme':'dark'}]}
 assert 'result' in await s.handle(rpc({**base,P+'clientInfo':full}))
 count=0
 for field in full:
  omitted=copy.deepcopy(full);omitted.pop(field);q=await s.handle(rpc({**base,P+'clientInfo':omitted}))
  assert ('error' in q)==(field in ['name','version'])
  for bad in [None,False,3,{}]:
   value=copy.deepcopy(full);value[field]=bad;q=await s.handle(rpc({**base,P+'clientInfo':value}));assert q['error']=={'code':-32602,'message':'Invalid params'};count+=1
 for field in full['icons'][0]:
  omitted=copy.deepcopy(full);omitted['icons'][0].pop(field);q=await s.handle(rpc({**base,P+'clientInfo':omitted}));assert ('error' in q)==(field=='src')
  for bad in [None,False,3,{}]:
   value=copy.deepcopy(full);value['icons'][0][field]=bad;q=await s.handle(rpc({**base,P+'clientInfo':value}));assert q['error']['code']==-32602;count+=1
 assert s.active_requests==0;await s.stop();print('FRESH_IMPLEMENTATION_FIELDS',count,'invalid variations plus mandatory/optional omission')
def test_tool_text_fields_and_notification_omission_null_boundaries():
 async def h(a):return ToolCallResult.text('ok')
 basic={'name':'synthetic','inputSchema':{'type':'object'}}
 optional={'title':'t','description':'d','outputSchema':{'type':'integer'},'icons':[{'src':'data:image/png;base64,AA==','mimeType':'image/png','sizes':['any'],'theme':'light'}],'annotations':{'title':'t','readOnlyHint':True,'destructiveHint':False,'idempotentHint':True,'openWorldHint':False},'_meta':{'example.org/a':'safe'}}
 assert RegisteredTool.from_definition({**basic,**optional},h).definition()=={**basic,**optional}
 for field in optional:
  value={**basic,**optional};value.pop(field);RegisteredTool.from_definition(value,h)
  with pytest.raises((ValueError,ServerWireError)):RegisteredTool.from_definition({**basic,**optional,field:None},h)
 for field in optional['annotations']:
  omit=copy.deepcopy(optional);omit['annotations'].pop(field);RegisteredTool.from_definition({**basic,**omit},h)
  bad=copy.deepcopy(optional);bad['annotations'][field]=None
  with pytest.raises((ValueError,ServerWireError)):RegisteredTool.from_definition({**basic,**bad},h)
 annotations={'audience':['user','assistant'],'priority':.5,'lastModified':'2026-10-13T21:00:00Z'}
 for field in annotations:
  omit=copy.deepcopy(annotations);omit.pop(field);ToolCallResult.from_value({'content':[{'type':'text','text':'safe','annotations':omit}]})
  bad=copy.deepcopy(annotations);bad[field]=None
  with pytest.raises(ServerWireError):ToolCallResult.from_value({'content':[{'type':'text','text':'safe','annotations':bad}]})
 for params in [{'requestId':1},{'requestId':1,'reason':'safe'},{'requestId':1,'_meta':{P+'subscriptionId':'safe'}}]:
  assert ServerRequest.parse(json.dumps({'jsonrpc':'2.0','method':'notifications/cancelled','params':params}).encode(),ServerLimits()).request_id is None
 for params in [{},{'requestId':None},{'requestId':1,'reason':None},{'requestId':1,'_meta':None},{'requestId':1,'_meta':{P+'subscriptionId':None}}]:
  with pytest.raises(ServerWireError) as error:ServerRequest.parse(json.dumps({'jsonrpc':'2.0','method':'notifications/cancelled','params':params}).encode(),ServerLimits())
  assert error.value.code==-32602
 print('FRESH_TOOL_TEXT_NOTIFICATION_FIELDS','optional omissions preserve; explicit null refused; no handler')
