"""Independent public API concurrency limit probe."""
import asyncio,json
from peer_helpers import Peer
from friday_mcp.client.base import MCPClientBase
from friday_mcp.client.adapter import MCPToolAdapter
from friday_mcp.client.protocol import ProtocolLimits
class Client(MCPClientBase):
 def __init__(self):super().__init__("review",protocol_profile="modern",limits=ProtocolLimits(concurrent_requests=1));self.peer=Peer()
 async def _create_transport(self):return self.peer
async def main():
 c=Client();await c.connect()
 c.peer.result={"resultType":"complete","content":[{"type":"text","text":"ok"}],"structuredContent":{"v":7}}
 try:
  old=(await MCPToolAdapter(c).get_tools())[0];facts={}
  async def second():
   try:await c.refresh_tool_catalog()
   except Exception as ex:
    facts["second_failure"]=getattr(ex,"failure_code",type(ex).__name__)
    facts["snapshot_still_available"]=c.current_catalog_snapshot is not None
    before=c.peer.calls
    try:facts["old_wrapper_result"]=await old.execute()
    except Exception as ex:facts["old_wrapper_failure"]=getattr(ex,"failure_code",type(ex).__name__)
    facts["old_wrapper_mutating_calls"]=c.peer.calls-before
  first=asyncio.create_task(c.refresh_tool_catalog());two=asyncio.create_task(second())
  results=await asyncio.gather(first,two,return_exceptions=True)
  facts["first_result_type"]=type(results[0]).__name__
 finally:await c.disconnect()
 print(json.dumps(facts,indent=2))
asyncio.run(main())
