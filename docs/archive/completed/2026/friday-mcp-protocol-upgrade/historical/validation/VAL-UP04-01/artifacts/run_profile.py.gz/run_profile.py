"""Reproduce the frozen profile sequentially with fresh label-specific caches."""
import json,subprocess
from pathlib import Path
base=Path('/private/tmp/friday-mcp-upgrade')
evidence=base/'independent-review-UP04-001'
request=json.loads((evidence/'inputs/request.json').read_text())
for check in request['required_checks']:
    subprocess.run([str(base/'venv/bin/python'),str(evidence/'review_run_check.py'),'REPRO-'+check['id'],check['snapshot'],*check['argv']],check=True)
    receipt=json.loads((evidence/'checks'/('REPRO-'+check['id'])/'receipt.json').read_text())
    print(check['id'],receipt['exit_code'],flush=True)
