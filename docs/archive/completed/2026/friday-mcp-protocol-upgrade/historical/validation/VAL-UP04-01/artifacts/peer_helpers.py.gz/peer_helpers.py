"""Independent, in-memory public API probes; no network or candidate writes."""
import asyncio,json
from friday_mcp.client.base import MCPClientBase,MCPToolExecutionError
from friday_mcp.client.adapter import MCPToolAdapter
from friday_mcp.client.protocol import ToolResult,ProtocolLimits,ProtocolFailure
class Peer:
 def __init__(self):self.queue=asyncio.Queue();self.fail=False;self.calls=0;self.result={"resultType":"complete","content":[],"structuredContent":{"v":"wrong"}}
 async def connect(self):pass
 async def disconnect(self):pass
 @property
 def is_connected(self):return True
 async def receive(self):return await self.queue.get()
 async def send(self,m):
  if "id" not in m:return
  method=m["method"]
  if method=="server/discover":r={"resultType":"complete","supportedVersions":["2026-07-28"],"capabilities":{"tools":{}},"ttlMs":0,"cacheScope":"private"}
  elif method=="tools/list":
   if self.fail:
    await self.queue.put({"jsonrpc":"2.0","id":m["id"],"error":{"code":-32603,"message":"synthetic"}});return
   r={"resultType":"complete","ttlMs":0,"cacheScope":"private","tools":[{"name":"echo","inputSchema":{"type":"object"},"outputSchema":{"type":"object","properties":{"v":{"type":"integer"}},"required":["v"]}}]}
  else:self.calls+=1;r=self.result
  await self.queue.put({"jsonrpc":"2.0","id":m["id"],"result":r})
class Client(MCPClientBase):
 def __init__(self):super().__init__("review",protocol_profile="modern");self.peer=Peer()
 async def _create_transport(self):return self.peer
async def classify(c,value):
 c.peer.result=value;before=c.peer.calls
 try:value=await c.call_tool("echo",{});return {"value":value,"calls":c.peer.calls-before}
 except Exception as ex:return {"exception":type(ex).__name__,"failure_code":getattr(ex,"failure_code",None),"safe_message":str(ex),"calls":c.peer.calls-before}
async def main():
 c=Client();await c.connect();facts={}
 try:
  facts["malformed_error"]=await classify(c,{"resultType":"complete","isError":True,"content":"bad"})
  adapter=MCPToolAdapter(c);old=(await adapter.get_tools())[0]
  facts["schema_before_failure"]=await classify(c,{"resultType":"complete","content":[],"structuredContent":{"v":"wrong"}})
  c.peer.fail=True
  try:await adapter.get_tools(refresh=True)
  except Exception as ex:facts["refresh_failure"]=type(ex).__name__
  try:
   stale=await adapter.get_tools();facts["stale_cache"]=bool(stale) and stale[0] is old
  except Exception as ex:facts["cache_read_failure"]=type(ex).__name__
  before=c.peer.calls
  try:facts["old_wrapper_value"]=await old.execute()
  except Exception as ex:facts["old_wrapper_failure"]=getattr(ex,"failure_code",type(ex).__name__)
  facts["old_wrapper_calls"]=c.peer.calls-before
  c.peer.fail=False;await adapter.get_tools(refresh=True)
  cases={
   "valid_sampling_text":{"method":"sampling/createMessage","params":{"messages":[{"role":"user","content":{"type":"text","text":"x"}}],"maxTokens":5}},
   "valid_sampling_tool_use":{"method":"sampling/createMessage","params":{"messages":[{"role":"assistant","content":{"type":"tool_use","id":"a","name":"echo","input":{}}}],"maxTokens":5}},
   "valid_sampling_tool_result":{"method":"sampling/createMessage","params":{"messages":[{"role":"assistant","content":{"type":"tool_use","id":"a","name":"echo","input":{}}},{"role":"user","content":{"type":"tool_result","toolUseId":"a","content":[{"type":"text","text":"x"}]}}],"maxTokens":5}},
   "invalid_sampling_resource_link":{"method":"sampling/createMessage","params":{"messages":[{"role":"user","content":{"type":"resource_link","uri":"https://invalid.test","name":"x"}}],"maxTokens":5}},
   "invalid_form_property":{"method":"elicitation/create","params":{"message":"x","requestedSchema":{"type":"object","properties":{"x":42}}}},
   "invalid_form_property_missing_type":{"method":"elicitation/create","params":{"message":"x","requestedSchema":{"type":"object","properties":{"x":{}}}}},
  }
  facts["input_required"]={}
  for name,request in cases.items():facts["input_required"][name]=await classify(c,{"resultType":"input_required","inputRequests":{"x":request}})
 finally:await c.disconnect()
 facts["pending_after_disconnect"]=len(c._pending_requests)
 print(json.dumps(facts,indent=2))

