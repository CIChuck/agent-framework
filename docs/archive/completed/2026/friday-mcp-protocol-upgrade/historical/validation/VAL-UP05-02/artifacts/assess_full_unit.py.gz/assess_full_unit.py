from pathlib import Path
import json,ast,hashlib,subprocess
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP05-002';W=B/'work';P=W/'docs/planning/active/friday-mcp-protocol-upgrade'
M=json.loads((R/'inputs/builder__final-actual-modern-mapping.json').read_text());Q=json.loads((P/'validation-request-REM-MCP-UP-006.json').read_text())
review={
'envelope':'Reviewed bounded finite JSON, duplicate/nonfinite/error grammar, mandatory/null IDs and params metadata, fixed own-ID errors, no batch/response dispatch.',
'metadata':'Reviewed required per-request version/capability objects, optional Implementation/Icon/log/progress fields and dependent types/key grammar. Reserved W3C formats checked without trust/forwarding. Metadata does not authorize.',
'version':'Reviewed2026-only mode, no prior discovery/state, discover and exact supported/requested variant with official SDK model checks and bounded owner-local echo. Standard malformed header classification remains failed.',
'catalog':'Reviewed immutable staged sorted catalogs, atomic failure, byte/count complete pagination, worst-ID reserve, bounded revision-bound opaque cursors,0/private cache metadata and complete/serverInfo on empty/nonempty pages.',
'tooldefinition':'Reviewed accepted public ToolDefinition.parse plus complete optional field preservation, immutable schemas, bounded draft2020-12 subset and static primitive header bindings. Unsupported refs/regex/dialects/keywords fail without publication.',
'toolcall':'Reviewed captured definition/schema/handler, arguments before one async invocation, successful captured output validation, complete ordered text/structured arbitrary JSON including null versus omission, metadata/annotations and fixed legitimate isError results. No replay.',
'unsupported':'Reviewed dispatch allowlist/complete-only output and explicit state refusal. MRTR/input_required, resources/prompts/media/subscriptions/Tasks/callback/logging roles are not activated; no outgoing requests. Missing-capability constructor inactive.',
'stdio':'Reviewed native newline UTF8, clean stdout, captured generation, bounded serialized rejection/output owners, original first-byte budget and idle separation. Own32 cancellation/EOF,16 resistant read/lock/drain/close and4 deadline cases pass; product native-start/signal/saturation/race limits1..4 pass.',
'notification':'Reviewed separate no-ID metadata, requestId/reason cancellation, malformed/unknown/completed ignore and no stdio reply. No activated core HTTP client notification role; safe no-ID errors.',
'http':'Reviewed exact stateless POST JSON/final SSE, framing caps, original body/handler/send deadline, request-owned disconnect and no headers/handler replay. Required real SDK verified TLS passes; own standard-header error cases fail.',
'headers':'Reviewed raw custom CR/LF/NUL/invalid encoding/equal/conflicting duplicates, Base64 sentinel, nested primitive bindings, Decimal safe integer equality and null/absent omission before effects. Own12 JSON/SSE custom cases pass. Method/Version raw-value ASCII/control classification fails VAL-UP05-005.',
'access':'Reviewed typed Host/Origin/bind/path/TLS policy, exact Host400/Origin403/Bearer401 and query/header bounds, supplied nonrepr in-memory constant-time token and no discovery. Static gate does not implement OAuth. Standard-header error exception remains.',
'ownership':'Reviewed lower-only owner/body/schema/output/catalog/rate/deadline limits, resistant owner retention and stop/retry/start, captured generation cleanup/write/ID/signal guards, one handler and no executor. Own and full-profile cancellation/EOF/resistant cases pass.',
'registry':'Reviewed public Core ToolRegistry/ToolDefinition and actual DefaultToolRegistry fixture, captured execute reference, atomic filter/prefix/collision/schema staging, distinct instances and no implicit application/tool loading.',
'compatibility':'Reviewed new typed exports and lazy optional imports; legacy constructor/config/YAML/version/enum and accepted hashes unchanged.1505 original client cases,1528 cross-package cases and full root regressions pass.',
'observation':'Reviewed injected public TelemetryInterface, single admitted start/terminal, safe method/outcome/registered-tool hash, observer failures/no replay and privacy: no raw peer IDs/names/args/results/schema/credentials/URLs/traces.',
'interop':'Reviewed official SDK2.3.0/cacheNone/mode2026/no callbacks through real named Friday stdio and verified literal127 TLS JSON/SSE; actual discovery/version/counters/cancel/disconnect/wrongcert/exit. Independent live malformed standard headers reproduce wrong errors in both modes with0 handler starts and child exit0.'}
groups={}
for name,b in M['bundles'].items():
 refs=[]
 for kind in ['source','assertions']:
  for e in b[kind]:
   p=W/e['path'];tree=ast.parse(p.read_text());nodes=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name==e['symbol'].split('.')[-1]]
   refs.append({'kind':kind,'path':e['path'],'symbol':e['symbol'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'current_ranges':[{'line':n.lineno,'end_line':n.end_lineno,'assertion_lines':[a.lineno for a in ast.walk(n) if isinstance(a,ast.Assert)]} for n in nodes]})
 groups[name]={'independent_assessment':review[name],'fresh_current_source_assertion_references':refs,'required_check_ids':b['check_ids'],'exception':['VAL-UP05-005'] if name in ['headers','http','access'] else []}
schema=(R/'inputs/normative/modelcontextprotocol--modelcontextprotocol--main--schema--2026-07-28--schema.ts').read_text().splitlines();fields=[];offsets=[]
for f in M['fields']:
 line=f['schema_line']
 if schema[line-1].strip()!=f['field']:
  assert schema[line].strip()==f['field'];offsets.append({'declaration':f['declaration'],'field':f['field'],'inventory_line':line,'actual_line':line+1});line+=1
 role=f['disposition'];assessment='Activated field enforcement and immutable construction reviewed through current implementation and assertions.' if role=='supported_boundary' else 'Conditional role not advertised/activated; optional field omitted or unsupported RPC/state/content variant refused. No all-role conformance claim.'
 fields.append({'declaration':f['declaration'],'inventory_schema_line':f['schema_line'],'actual_schema_line':line,'field':f['field'],'selected_role':role,'review':assessment,'evidence_groups':f['bundles'],'exception':['VAL-UP05-005'] if f['declaration']=='HeaderMismatchError' else []})
clauses=[]
for c in M['clauses']:
 state='2025 historical only' if '2025-11-25' in c['source'] else 'conditional OAuth role not activated' if c['disposition']=='inactive_optional_oauth_or_client_authorization_role' else 'documented SHOULD tradeoff or application owner responsibility' if c['disposition'] in ['documented_should_tradeoff','application_owner_should'] else 'other-role duty; applicable server portions covered by linked current implementation' if c['disposition']=='other_role_or_conditional_client_duty' else 'normative interpretation' if c['disposition']=='normative_interpretation' else 'selected-role implementation or explicit inactive variant reviewed'
 clauses.append({'id':c['id'],'source':c['source'],'source_sha256':c['sha256'],'line':c['line'],'paragraph':c['paragraph'],'tokens':c['tokens'],'review':state,'evidence_groups':c['bundles'],'exception':['VAL-UP05-005'] if c['id'] in ['SRV-CLAUSE-0094','SRV-CLAUSE-0095'] else []})
criteria=[]
for i in range(1,13):
 k=f'SRV-AC-{i:02}';criteria.append({'id':k,'requirement':Q['acceptance_criteria'][k],'evidence_groups':[n for n,b in M['bundles'].items() if k in b['criteria']],'status':'CHANGES_REQUESTED' if i in [1,5,6] else 'independent gate not passed; other checks/docs/scope supported' if i==12 else 'supported by current source and fresh evidence','finding':['VAL-UP05-005'] if i in [1,5,6,12] else []})
changed=subprocess.check_output(['git','diff','--name-only','b57c25d9fc4933059f64ed836783291f5753b9a8','HEAD'],cwd=W,text=True).splitlines();products=[x for x in changed if not x.startswith('docs/planning/')];assert set(products)==set(Q['delta_product_paths'])
other=[x for x in Q['full_work_unit_product_paths'] if x not in products];assert len(other)==12
for x in other:assert subprocess.check_output(['git','show','b57c25d9fc4933059f64ed836783291f5753b9a8:'+x],cwd=W)==(W/x).read_bytes()
assessment={'mode':'Independent remediation delta then complete18-path/12-criterion review','inventory_usage':'Builder declaration/field/paragraph/test mappings are input inventories only. Current-source review and fresh exact command/probe evidence supply assessment; counts are not per-variant pass totals.','schema_sha256':'742750af0bb8c716e7030c4977c992b55d1adc4407e9e66997db5846baedc2cd','schema_upstream':'271ecc9accafdd9b83a3c869fa67c22953b2af80','primary_sources':19,'declarations':M['declarations'],'field_assessments':fields,'field_reference_line_offsets_corrected':offsets,'clause_assessments':clauses,'groups':groups,'criteria':criteria,'delta_changed_products':products,'unchanged_other12_products':other,'all18_products':Q['product_hashes'],'historical_schema':M['historical_schema'],'limits':'No blanket MCP/OAuth conformance; inactive and historical/client-role fields/paragraphs remain separate from the activated bounded tools server.'}
(R/'full-unit-field-clause-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n');print(json.dumps({'fields':len(fields),'clauses':len(clauses),'declarations':len(M['declarations']),'builder_field_line_offsets':len(offsets),'all_products':len(Q['product_hashes']),'unchanged_products':len(other)}))
