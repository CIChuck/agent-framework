import asyncio,json
import pytest,httpx
from friday_mcp.server import ModernStdioMCPServer,StreamableHTTPMCPServer,HTTPServerPolicy,ServerLimits,ToolCallResult
V='2026-07-28';P='io.modelcontextprotocol/'
def rpc(method='server/discover',rid=1,**args):
 return json.dumps({'jsonrpc':'2.0','id':rid,'method':method,'params':{'_meta':{P+'protocolVersion':V,P+'clientCapabilities':{}},**args}}).encode()+b'\n'
def cancel(rid): return json.dumps({'jsonrpc':'2.0','method':'notifications/cancelled','params':{'requestId':rid}}).encode()+b'\n'
async def until(p):
 for _ in range(400):
  if p():return
  await asyncio.sleep(0)
 assert p()
class Writer:
 def __init__(self,resistant=False):self.data=[];self.draining=asyncio.Event();self.release=asyncio.Event();self.resistant=resistant;self.closed=False;self.writers=0;self.maximum=0
 def write(self,b):self.data.append(b)
 async def drain(self):
  self.draining.set();self.writers+=1;self.maximum=max(self.maximum,self.writers)
  try:
   while not self.release.is_set():
    try:await self.release.wait()
    except asyncio.CancelledError:
     if not self.resistant:raise
  finally:self.writers-=1
 def close(self):self.closed=True
 async def wait_closed(self):pass
@pytest.mark.asyncio
@pytest.mark.parametrize('n',[1,2,3,4])
@pytest.mark.parametrize('kind',['malformed','duplicate','admission','oversize'])
@pytest.mark.parametrize('block',['lock','drain'])
async def test_independent_cancellation_and_eof(n,kind,block):
 s=ModernStdioMCPServer(limits=ServerLimits(active_requests=n,timeout_seconds=.3,shutdown_seconds=.02));r=asyncio.StreamReader();w=Writer();starts=[];ends=[]
 async def held(a):
  starts.append(a['i'])
  try:await asyncio.Event().wait()
  finally:ends.append(a['i'])
 s.register_tool({'name':'held','inputSchema':{'type':'object'}},held)
 t=asyncio.create_task(s.serve(reader=r,writer=w))
 for i in range(n):r.feed_data(rpc('tools/call',i,name='held',arguments={'i':i}))
 await until(lambda:len(starts)==n);g=s._generation
 if block=='lock':await g.lock.acquire()
 r.feed_data({'malformed':b'{}\n','duplicate':rpc('tools/call',0,name='held'),'admission':rpc('tools/call',99,name='held'),'oversize':b'x'*65537+b'\n'}[kind])
 await until(lambda:len(g.outputs)==1)
 if block=='drain':await w.draining.wait()
 r.feed_data(cancel(0));await until(lambda:0 in ends)
 assert len(starts)==n and len(g.outputs)<=n and len(g.dispatchers)<=n and w.maximum<=1
 assert len(w.data)==int(block=='drain')
 r.feed_eof();await asyncio.wait_for(t,.2)
 assert not g.outputs and not g.dispatchers and s._generation is None and s.active_requests==0
 if block=='lock':g.lock.release()
 print('CANCEL_EOF',n,kind,block,len(starts),len(ends),w.maximum)
@pytest.mark.asyncio
@pytest.mark.parametrize('n',[1,2,3,4])
@pytest.mark.parametrize('kind',['drain','read','close','lock'])
async def test_independent_resistant_owner_retry_and_stale_generation(n,kind):
 gate=asyncio.Event();entered=asyncio.Event()
 async def resist():
  entered.set()
  while not gate.is_set():
   try:await gate.wait()
   except asyncio.CancelledError:pass
 class Reader(asyncio.StreamReader):
  async def read(self,n=-1):await resist();return b''
 class CloseWriter(Writer):
  async def wait_closed(self):await resist()
 class Lock:
  async def __aenter__(self):await resist()
  async def __aexit__(self,*a):pass
 s=ModernStdioMCPServer(limits=ServerLimits(active_requests=n,timeout_seconds=.03,shutdown_seconds=.01));r=Reader() if kind=='read' else asyncio.StreamReader();w=CloseWriter() if kind=='close' else Writer(kind=='drain')
 old=asyncio.create_task(s.serve(reader=r,writer=w));await until(lambda:s._generation is not None);g=s._generation
 if kind=='lock':g.lock=Lock()
 if kind in ['lock','drain']:
  r.feed_data(b'{}\n');await asyncio.wait_for(w.draining.wait() if kind=='drain' else entered.wait(),.1)
 if kind=='read':await entered.wait()
 try:
  with pytest.raises(TimeoutError,match='incomplete'):await s.stop()
  assert s._generation is g and not g.settled
  with pytest.raises(RuntimeError):s.start()
  with pytest.raises(RuntimeError):await s.serve(reader=asyncio.StreamReader(),writer=Writer())
 finally:
  gate.set();w.release.set();await asyncio.gather(old,return_exceptions=True);await s.stop()
 assert s._generation is None and not g.outputs and not g.dispatchers
 r2=asyncio.StreamReader();w2=Writer();w2.release.set();new=asyncio.create_task(s.serve(reader=r2,writer=w2));r2.feed_data(rpc(rid='replacement'));await until(lambda:bool(w2.data))
 await s._stop_connection(g);assert not w2.closed and s._generation is not g
 await s.stop();await new;assert s._generation is None
 print('RESISTANT_RETRY',n,kind)
@pytest.mark.asyncio
@pytest.mark.parametrize('n',[1,2,3,4])
async def test_independent_idle_fragments_and_output_budget(n):
 s=ModernStdioMCPServer(limits=ServerLimits(active_requests=n,timeout_seconds=.08,shutdown_seconds=.02));r=asyncio.StreamReader();w=Writer();w.release.set();calls=[]
 async def handler(a):calls.append(1);return ToolCallResult.text('done')
 s.register_tool({'name':'held','inputSchema':{'type':'object'}},handler);t=asyncio.create_task(s.serve(reader=r,writer=w));await asyncio.sleep(.1);assert not t.done()
 raw=rpc('tools/call',name='held');r.feed_data(raw[:10]);await asyncio.sleep(.025);r.feed_data(raw[10:20]);await asyncio.sleep(.09);await asyncio.wait_for(t,.2)
 assert calls==[] and w.data==[] and s._generation is None
 r=asyncio.StreamReader();w=Writer();t=asyncio.create_task(s.serve(reader=r,writer=w));raw=rpc();r.feed_data(raw[:10]);await asyncio.sleep(.045);r.feed_data(raw[10:]);await w.draining.wait();await asyncio.wait_for(t,.09)
 assert len(w.data)==1 and w.closed and s._generation is None
 print('ABSOLUTE_FRAME_OUTPUT',n)
@pytest.mark.asyncio
@pytest.mark.parametrize('value',[b'a\r',b'a\n',b'a\0',b'a\x7f',b'\xff',b'=?base64?%%%?='])
@pytest.mark.parametrize('mode',['json','sse'])
async def test_independent_custom_headers_exact_code(value,mode):
 s=StreamableHTTPMCPServer(response_mode=mode);calls=[]
 async def h(a):calls.append(1);return ToolCallResult.text('done')
 s.register_tool({'name':'held','inputSchema':{'type':'object','properties':{'x':{'type':'string','x-mcp-header':'X'}}}},h)
 headers=[(b'content-type',b'application/json'),(b'accept',b'application/json,text/event-stream'),(b'mcp-protocol-version',V.encode()),(b'mcp-method',b'tools/call'),(b'mcp-name',b'held'),(b'mcp-param-x',value)]
 async with httpx.AsyncClient(transport=httpx.ASGITransport(app=s.create_app()),base_url='http://127.0.0.1:8000') as c:
  q=await c.post('/mcp',headers=headers,content=rpc('tools/call',name='held',arguments={'x':'a'}));body=q.json();assert q.status_code==400 and body['error']=={'code':-32020,'message':'Header mismatch'} and not calls
  for duplicate in ['a','b']:
   hs=headers[:-1]+[(b'Mcp-Param-X',b'a'),(b'mcp-param-x',duplicate.encode())];q=await c.post('/mcp',headers=hs,content=rpc('tools/call',name='held',arguments={'x':'a'}));assert q.status_code==400 and q.json()=={'jsonrpc':'2.0','error':{'code':-32020,'message':'Header mismatch'}}
 await s.stop();print('HEADER_EXACT',mode,value.hex())
@pytest.mark.asyncio
@pytest.mark.parametrize('field',['mcp-method','mcp-protocol-version'])
@pytest.mark.parametrize('suffix',['\x01','\x7f','世界'])
async def test_standard_metadata_header_invalid_characters_exact_code(field,suffix):
 s=StreamableHTTPMCPServer();method='server/discover';version=V
 if field=='mcp-method':method+=suffix
 else:version+=suffix
 body=json.dumps({'jsonrpc':'2.0','id':91,'method':method,'params':{'_meta':{P+'protocolVersion':version,P+'clientCapabilities':{}}}}).encode()
 headers=[(b'content-type',b'application/json'),(b'accept',b'application/json,text/event-stream'),(b'mcp-protocol-version',version.encode()),(b'mcp-method',method.encode())]
 async with httpx.AsyncClient(transport=httpx.ASGITransport(app=s.create_app()),base_url='http://127.0.0.1:8000') as c:
  q=await c.post('/mcp',headers=headers,content=body)
  print('INVALID_STANDARD_HEADER',field,suffix.encode().hex(),q.status_code,q.json())
  assert q.status_code==400 and q.json()['error']['code']==-32020
 await s.stop()
