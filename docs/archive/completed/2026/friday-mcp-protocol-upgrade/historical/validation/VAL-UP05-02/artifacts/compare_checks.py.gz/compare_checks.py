import json,re,collections,hashlib
from pathlib import Path
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP05-002';W=B/'work';P=W/'docs/planning/active/friday-mcp-protocol-upgrade'
request=json.loads((P/'validation-request-REM-MCP-UP-006.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def normalized(v,root):
 if isinstance(v,str):return v.replace(str(root),'<snapshot>')
 if isinstance(v,list):return [normalized(x,root) for x in v]
 if isinstance(v,dict):return {k:normalized(x,root) for k,x in v.items()}
 return v
checks=[]
for c in request['required_checks']:
 p=R/'checks'/('full-001-'+c['id']);receipt=json.loads((p/'receipt.json').read_text());pre=json.loads((p/'preflight.json').read_text());expect=1 if c['id'] in ['root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy'] else 0
 assert receipt['argv']==c['argv'] and receipt['exit_code']==expect
 assert receipt['environment']==pre['environment'] and receipt['stdout_sha256']==digest(p/'stdout') and receipt['stderr_sha256']==digest(p/'stderr')
 assert pre['guard_sha256']==request['guard']['sha256']
 assert pre['original_runner_sha256']=='ceec1b2316f4be3bce36fb778eb80b5d472561920d6d6fe35b8b30735e1776f0'
 assert pre['UP05_runner_sha256']==digest(R/'run_check_UP05.py')
 assert pre['candidate_commit']==('2b536516068f9e946572d165636211a24a93638d' if c['snapshot']=='work' else 'f876603c74d8a90639fb5dc90d287d17ab523705')
 if c['snapshot']=='work':assert pre['source_hashes']==request['product_hashes']
 assert pre['metadata_hashes']==request['metadata_hashes'] and pre['preserved_product_hashes']==request['preserved_product_hashes']
 checks.append({'id':c['id'],'argv':c['argv'],'exit_code':receipt['exit_code'],'started':receipt['started_utc'],'finished':receipt['finished_utc']})
def out(label):return (R/'checks'/label/'stdout').read_text()
ruff=[]
for label,root in [('root-ruff',W),('baseline-root-ruff',B/'up05-baseline')]:
 objects=normalized(json.loads(out('full-001-'+label)),root);ruff.append(objects);(R/(label+'-normalized-objects.json')).write_text(json.dumps(objects,indent=2)+'\n')
assert len(ruff[0])==len(ruff[1])==327 and collections.Counter(json.dumps(x,sort_keys=True) for x in ruff[0])==collections.Counter(json.dumps(x,sort_keys=True) for x in ruff[1])
mypy=[]
for label in ['full-mypy','baseline-full-mypy']:
 objects=[]
 for line in out('columns-001-'+label).splitlines():
  m=re.fullmatch(r'(.+?):(\d+):(\d+): (error|note|warning): (.*?)(?:  \[([^\]]+)\])?',line)
  if m:objects.append({'path':m[1],'line':int(m[2]),'column':int(m[3]),'severity':m[4],'message':m[5],'code':m[6]})
 receipt=json.loads((R/'checks'/('columns-001-'+label)/'receipt.json').read_text());assert receipt['exit_code']==1 and receipt['argv'][-2:]==['--show-column-numbers','--no-pretty']
 mypy.append(objects);(R/(label+'-column-objects.json')).write_text(json.dumps(objects,indent=2)+'\n')
assert len(mypy[0])==4 and mypy[0]==mypy[1]
pytest=[]
for label,root in [('root',W),('baseline-root',B/'up05-baseline')]:
 raw=out('full-001-'+label).replace(str(root),'<snapshot>');m=re.search(r'=+ warnings summary =+\n(.*?)\n-- Docs:',raw,re.S);assert m
 obj={'skip_locations_reasons':[x for x in raw.splitlines() if x.startswith('SKIPPED')],'complete_warning_section':m[1],'result_summary':raw.splitlines()[-1]};pytest.append(obj);(R/(label+'-warnings-skips.json')).write_text(json.dumps(obj,indent=2)+'\n')
assert sum(int(re.search(r'\[(\d+)\]',x)[1]) for x in pytest[0]['skip_locations_reasons'])==14 and pytest[0]['skip_locations_reasons']==pytest[1]['skip_locations_reasons'] and pytest[0]['complete_warning_section']==pytest[1]['complete_warning_section']
comparison={'required_checks':checks,'ruff_complete_diagnostic_and_fix_objects_equal':True,'mypy_complete_path_line_column_severity_code_message_objects_equal':True,'pytest_full_warnings_and_skip_locations_reasons_equal':True,'root':pytest[0]['result_summary'],'baseline':pytest[1]['result_summary']}
(R/'exact-profile-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');print(json.dumps(comparison))
