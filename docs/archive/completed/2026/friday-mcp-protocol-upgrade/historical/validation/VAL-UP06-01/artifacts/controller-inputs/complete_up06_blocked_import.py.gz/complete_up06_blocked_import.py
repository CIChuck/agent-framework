from pathlib import Path
import gzip,hashlib,json,re,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';d=p/'validation/VAL-UP06-01';r=b/'independent-review-UP06-001';mf=json.loads((r/'evidence-manifest.json').read_text());stored=json.loads((d/'stored-manifest.json').read_text());items=stored['artifacts'];safe={x['path']:x for x in mf['entries']}
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def req(ok,msg):
 if not ok:raise RuntimeError(msg)
def archive(name,raw):
 f=d/'artifacts'/(name+'.gz');req(not f.exists(),'Archive overwrite');f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(gzip.compress(raw,mtime=0));items.append({'original_path':name,'path':str(f.relative_to(d)),'encoding':'gzip','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(f)})
req(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()=='92c6f6742df9be84b7046a89a830a6dcc3f67dc8','Candidate drift');req(h(d/'report.md')==h(r/'report.md'),'Original report drift')
# Retain original report verbatim; materialize only its safe linked artifacts.
for target in re.findall(r'\]\(([^)]+)\)',(r/'report.md').read_text()):
 if target.endswith('/'):
  req(target=='primary-captures/','Unlisted report directory');folder=d/target;folder.mkdir(exist_ok=True);rows=[x for x in items if x['original_path'].startswith(target)];(folder/'index.json').write_text(json.dumps({'original_captures':[{'original_path':x['original_path'],'lossless_gzip':'../'+x['path'],'sha256':x['sha256']} for x in rows]},indent=2)+'\n');continue
 req(target in safe or target=='evidence-manifest.json','Unlisted safe link '+target);source=r/target;raw=source.read_bytes();destination=d/target
 if destination.exists():req(destination.read_bytes()==raw,'Linked evidence differs')
 else:destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(raw)
# Original failed process check, including the missing-link diagnostic, stays intact.
existing={x['original_path'] for x in items}
for folder in sorted((b/'checks').glob('up06-amend2-proposal-*')):
 for name in ['preflight.json','receipt.json','stdout','stderr']:
  f=folder/name;key='controller-proposal-original/'+folder.name+'/'+name
  if f.is_file() and key not in existing:archive(key,f.read_bytes())
archive('controller-inputs/record_up06_blocked_and_propose_amend2.py',(b/'record_up06_blocked_and_propose_amend2.py').read_bytes());archive('controller-inputs/complete_up06_blocked_import.py',Path(__file__).read_bytes());archive('controller-inputs/report-link-materialization-note.json',json.dumps({'cause':'Original sealed report uses relative safe-artifact links; gzip-only import left37 links missing','resolution':'Materialize exact safe referenced artifacts and a complete capture index; original report/manifest/failed check unchanged','product_changes':0},indent=2).encode())
for key,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show','friday-mcp-protocol-upgrade'],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 label='up06-amend2-proposal-linked-'+key;subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP06_amend1.py'),label,'work',str(b/'venv/bin/python'),*args],check=True);req(json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']==0,'Proposal check failed '+key)
 for name in ['preflight.json','receipt.json','stdout','stderr']:archive('controller-proposal-linked/'+key+'/'+name,(b/'checks'/label/name).read_bytes())
stored['artifacts']=items;stored['original_report_links_materialized']='Exact original safe artifacts; primary-capture index points to lossless archived bytes';(d/'stored-manifest.json').write_text(json.dumps(stored,indent=2)+'\n')
for x in items:req(hashlib.sha256(gzip.decompress((d/x['path']).read_bytes())).hexdigest()==x['sha256'],'Archive drift')
proposal=json.loads((p/'proposals/UP-06-amendment-002.json').read_text())
for row in proposal['added_product_paths']:req(h(w/row['path'])==row['baseline_sha256'],'Proposed source edit before approval')
comparison=json.loads((p/'execution/up06-amend1/verification-comparison.json').read_text());req(comparison['source_hashes']=={path:h(w/path) if (w/path).is_file() else None for path in comparison['source_hashes']},'MCP product drift');paths=[str(x.relative_to(w)) for x in [d,p/'directives/AMEND-MCP-UP-006-002-historical-authority-backing.md',p/'proposals/UP-06-amendment-002.json',p/'execution/up06-closeout-stop',p/'execution/current-process-state.json',p/'execution-log.md']]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Record MCP aggregate authority stop and bounded board proposal'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(json.dumps({'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'verdict':'BLOCKED','original_report_sha256':h(r/'report.md'),'original_entries':len(mf['entries']),'new_source_changes':0}))
