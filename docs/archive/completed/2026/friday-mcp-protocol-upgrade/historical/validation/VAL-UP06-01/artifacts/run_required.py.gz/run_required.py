from pathlib import Path
import json,subprocess,shutil
b=Path('/private/tmp/friday-mcp-upgrade');e=b/'independent-review-UP06-001';w=b/'work';a=json.loads((w/'docs/planning/active/friday-mcp-protocol-upgrade/authority-UP-06-amendment-001.json').read_text());results=[]
for c in a['required_checks']:
 label='independent-UP06-001-'+c['id']
 subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP06_amend1.py'),label,c['snapshot'],*c['argv']],check=True)
 dest=e/'checks'/c['id'];dest.mkdir(parents=True,exist_ok=False)
 for name in ('preflight.json','receipt.json','stdout','stderr'):shutil.copyfile(b/'checks'/label/name,dest/name)
 r=json.loads((dest/'receipt.json').read_text());results.append({'id':c['id'],'label':label,'exit_code':r['exit_code'],'success_contract':c['success']});print(json.dumps(results[-1]),flush=True)
 (e/'required-check-results.json').write_text(json.dumps(results,indent=2)+'\n')
