from pathlib import Path
import json,gzip,hashlib,subprocess,tomllib,shutil
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';e=b/'independent-review-UP04-002';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';r=json.loads((p/'validation-request-REM-MCP-UP-004.json').read_text());a=json.loads((p/'authority-REM-MCP-UP-004.json').read_text())
products=[]
for path,h in r['product_hashes'].items():
 actual=hashlib.sha256((w/path).read_bytes()).hexdigest();assert actual==h
 before=hashlib.sha256(subprocess.check_output(['git','show','138fb68e33b94d20c17bbaff79ec6be3c8bfc3fb:'+path],cwd=w)).hexdigest();assert before==a['all_original_up04_product_hashes'][path]
 try:base=hashlib.sha256(subprocess.check_output(['git','show',r['base_commit']+':'+path],cwd=w,stderr=subprocess.DEVNULL)).hexdigest()
 except subprocess.CalledProcessError:base=None
 products.append({'path':path,'original_hash':before,'candidate_hash':actual,'accepted_base_hash':base,'remediation_changed':before!=actual})
assert {x['path'] for x in products if x['remediation_changed']}==set(r['delta_product_paths'])
metadata=[]
for path,h in r['metadata_hashes'].items():
 actual=hashlib.sha256((w/path).read_bytes()).hexdigest();base=hashlib.sha256(subprocess.check_output(['git','show',r['base_commit']+':'+path],cwd=w)).hexdigest();assert actual==base==h;metadata.append({'path':path,'sha256':h})
for name,base in [('delta',r['remediation_base']),('full',r['base_commit'])]:
 data=subprocess.check_output(['git','diff',base,'HEAD'],cwd=w);(e/(name+'-candidate.diff')).write_bytes(data)
 paths=subprocess.check_output(['git','diff','--name-only',base,'HEAD'],cwd=w,text=True).splitlines();(e/(name+'-paths.json')).write_text(json.dumps(paths,indent=2)+'\n')
 unexpected=[x for x in paths if not x.startswith(('docs/planning/','docs/archive/completed/2026/friday-mcp-protocol-upgrade-up-03/')) and x not in r['product_hashes']];assert not unexpected,unexpected
(e/'product-scope.json').write_text(json.dumps({'products':products,'metadata':metadata},indent=2)+'\n')
libs=[]
for name,key in [('reused-library-manifest.json.gz','copied'),('additional-validation-libraries.json.gz','added')]:
 src=p/'execution/up04/artifacts/controller-inputs'/name;d=json.loads(gzip.decompress(src.read_bytes()));counts=0;issues=[];dist=[]
 for x in d[key]:
  dist.append({k:v for k,v in x.items() if k!='files'})
  for f in x['files']:
   dest=b/'venv/lib/python3.13/site-packages'/f['path'];assert '..' not in Path(f['path']).parts
   actual=hashlib.sha256(dest.read_bytes()).hexdigest() if dest.is_file() else None
   if actual!=f['sha256']:issues.append({'path':f['path'],'expected':f['sha256'],'actual':actual})
   counts+=1
 libs.append({'manifest':name,'distributions':dist,'distribution_count':len(dist),'file_count':counts,'issues':issues})
(e/'library-integrity.json').write_text(json.dumps(libs,indent=2)+'\n');print([(x['distribution_count'],x['file_count'],len(x['issues'])) for x in libs])
lock=tomllib.loads((w/'uv.lock').read_text());selected=[x for x in lock['package'] if x['name'] in ['mcp','mcp-types','jsonschema','referencing','httpcore','httpx','idna','ruff','mypy','uvicorn']];(e/'dependency-artifacts-edges.json').write_text(json.dumps(selected,indent=2)+'\n')
print('products',len(products),'delta',sum(x['remediation_changed'] for x in products),'metadata',len(metadata))
for name in ['peer_helpers.py','refresh_limit_constructor_probe.py','refresh_limit_probe.py','supplemental_probe.py']:
 src=b/'independent-review-UP04-001'/name;dest=e/'probes/original'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
