import json,gzip,hashlib,subprocess
from pathlib import Path
B=Path('/private/tmp/friday-mcp-upgrade');W=B/'work';P=W/'docs/planning/active/friday-mcp-protocol-upgrade';R=B/'independent-review-UP04-003'
def h(raw):return hashlib.sha256(raw).hexdigest()
records=[]
selectors={'supplemental_probe.py','refresh_limit_probe.py','refresh_limit_constructor_probe.py','peer_helpers.py','probes/recovery_overlap.py','probes/recovery_overlap_budgets.py'}
for unit in ['VAL-UP04-01','VAL-UP04-02']:
 f=P/'validation'/unit/'stored-manifest.json';d=json.loads(f.read_text());entries=[]
 assert h((f.parent/'report.md').read_bytes())==d['original_report_sha256']
 (R/'inputs'/f.relative_to(W)).parent.mkdir(parents=True,exist_ok=True);(R/'inputs'/f.relative_to(W)).write_bytes(f.read_bytes());(R/'inputs'/(f.parent/'report.md').relative_to(W)).write_bytes((f.parent/'report.md').read_bytes())
 for a in d['artifacts']:
  path=f.parent/a['path'];assert path.resolve().is_relative_to(f.parent.resolve());stored=path.read_bytes();raw=gzip.decompress(stored);assert h(stored)==a['stored_sha256'] and h(raw)==a['sha256'] and len(raw)==a['bytes'];entries.append({'path':a['path'],'sha256':h(raw),'stored_sha256':h(stored),'bytes':len(raw)})
  if a['original_path'] in selectors or a['original_path'].startswith('probes/original/'):
   candidate=R/'probes'/Path(a['original_path']).name
   if candidate.exists():assert candidate.read_bytes()==raw
 records.append({'unit':unit,'artifacts':len(entries),'report_sha256':d['original_report_sha256'],'entries':entries})
(R/'prior-evidence-probe-integrity.json').write_text(json.dumps(records,indent=2)+'\n')
paths=['docs/planning/active/friday-mcp-protocol-upgrade/validation/VAL-UP04-01','docs/planning/active/friday-mcp-protocol-upgrade/validation/VAL-UP04-02','docs/planning/active/friday-mcp-protocol-upgrade/execution/rem004','docs/planning/active/friday-mcp-protocol-upgrade/research-sources','docs/planning/active/friday-mcp-protocol-upgrade/authority-UP-04.json','docs/planning/active/friday-mcp-protocol-upgrade/authority-REM-MCP-UP-004.json']
out=subprocess.check_output(['git','diff','--name-status','b24c19ed4a2c210d9dc0eef60fa9f869b72a6e36','HEAD','--',*paths],cwd=W,text=True);assert not out
(R/'original-controls-preserved.json').write_text(json.dumps({'comparison_base':'b24c19ed4a2c210d9dc0eef60fa9f869b72a6e36','paths':paths,'delta':out,'explanation':'VAL-UP04-02 was added after its reviewed 0fac commit; it is unchanged against REM005 proposal base, rather than falsely labeled changed evidence against its own prior candidate.'},indent=2)+'\n')
print(json.dumps({'original_reports_preserved':True,'original_probe_copies_exact':True,'archives':[{'unit':x['unit'],'artifacts':x['artifacts']} for x in records]}))
