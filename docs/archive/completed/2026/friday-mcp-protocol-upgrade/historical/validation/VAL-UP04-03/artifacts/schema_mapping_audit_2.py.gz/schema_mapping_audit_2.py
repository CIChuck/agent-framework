import json,gzip,hashlib,re,ast,importlib.util,sys
from pathlib import Path
B=Path('/private/tmp/friday-mcp-upgrade');W=B/'work';P=W/'docs/planning/active/friday-mcp-protocol-upgrade';R=B/'independent-review-UP04-003'
def h(b):return hashlib.sha256(b).hexdigest()
def save(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
source_by_url={}
for rel in ['research-sources','research-sources/up02b','research-sources/up04']:
 root=P/rel
 for x in json.loads((root/'manifest.json').read_text())['sources']:
  source_by_url[x['url']]=gzip.decompress((root/x['artifact']).read_bytes()).decode()
modern=next(v for k,v in source_by_url.items() if '/2026-07-28/schema.ts' in k);compat=next(v for k,v in source_by_url.items() if '/2025-11-25/schema.ts' in k)
original=json.loads(gzip.decompress((P/'execution/up04/artifacts/normative-clause-ledger.json.gz').read_bytes()))
clauses=[]
for c in original['clauses']:
 raw=source_by_url[c['source']];para=c['paragraph'];count=len(re.findall(r'\b(?:MUST|SHALL|REQUIRED)\b',para));assert para in raw and count==c['mandatory_occurrences']
 clauses.append({k:c.get(k) for k in ['source','line','mandatory_occurrences','applicability','reason','group','criteria','positive','negative']})
assert sum(c['mandatory_occurrences'] for c in clauses)==393
raw_counts={k:len(re.findall(r'\b(?:MUST|SHALL|REQUIRED)\b',v)) for k,v in source_by_url.items()}
assert sum(raw_counts.values())==393
interfaces=[]
for entry in original['selected_schema_interfaces']:
 raw=source_by_url[entry['source']];assert entry['definition'] in raw
 for f in entry['fields']:assert f['declaration'] in raw.splitlines()[f['line']-1].strip()
 interfaces.append({'type':entry['type'],'source':entry['source'],'line':entry['line'],'fields':len(entry['fields']),'definition_sha256':h(entry['definition'].encode()),'profile_limit':entry['profile_limit']})
extra=json.loads((R/'archive-inputs/rem004/builder/final-requirement-test-mapping.json').read_text());defs=[]
for d in extra['definitions']:
 assert d['fragment'] in modern and h(modern.encode())==d['schema_sha256']
 assert modern.splitlines()[d['line']-1].startswith('export ')
 defs.append({'definition':d['definition'],'line':d['line'],'fragment_sha256':h(d['fragment'].encode()),'case_ids':d['case_ids'],'valid_ids':d['valid_ids'],'invalid_ids':d['invalid_ids']})
path=W/'packages/friday-mcp/tests_mcp/client/test_result_refresh.py'
import copy,pytest
namespace={'copy':copy,'pytest':pytest}
tree=ast.parse(path.read_text());selected=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'sampling_request','form_request','input_variant_cases'}],type_ignores=[])
exec(compile(selected,str(path),'exec'),namespace)
cases=namespace['input_variant_cases']();ids={c.id for c in cases};assert len(cases)==len(ids)==380
assert all(set(d['case_ids'])<=ids for d in defs)
actual=[{'id':c.id,'request':c.values[0],'expected':c.values[1]} for c in cases];save('independent-380-cases.json',actual)
rem=json.loads((R/'archive-inputs/rem005/builder/final-requirement-test-mapping.json').read_text());variants=rem['actual_variants'];assert len(variants)==67
names={n.name for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
assert all(v['nodeid'].split('::')[-1].split('[')[0] in names for v in variants)
assert h((R/'archive-inputs/rem005/builder/preconstruction-plan.md').read_bytes())==rem['preconstruction_plan']['sha256']
save('dependent-schema-audit.json',{'original_interfaces':interfaces,'original_field_count':sum(i['fields'] for i in interfaces),'supplemental_definitions':defs,'case_count':380,'public_paths':['stdio','2026-07-28'],'modern_sha256':h(modern.encode()),'compat_sha256':h(compat.encode()),'upstream':'271ecc9accafdd9b83a3c869fa67c22953b2af80','rem005_actual_variants':variants,'rem005_preconstruction_plan_bound':True})
save('independent-clause-mapping-audit.json',{'raw_counts':raw_counts,'original18_raw':sum(raw_counts.values())-raw_counts['https://modelcontextprotocol.io/specification/2025-11-25/basic/utilities/tasks.md'],'all19_raw':sum(raw_counts.values()),'clauses':clauses})
print(json.dumps({'raw_occurrences':sum(raw_counts.values()),'original18_raw':349,'clauses':len(clauses),'interfaces':len(interfaces),'fields':sum(i['fields'] for i in interfaces),'dependent_definitions':len(defs),'cases':len(cases),'REM005_variants':len(variants)}))
