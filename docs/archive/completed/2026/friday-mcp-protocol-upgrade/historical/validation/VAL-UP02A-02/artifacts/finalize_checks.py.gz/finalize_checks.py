from pathlib import Path
import ast, collections, gzip, hashlib, json, re, subprocess
from datetime import datetime,timezone
w=Path('/private/tmp/friday-mcp-upgrade/work'); r=Path('/private/tmp/friday-mcp-upgrade/independent-review-remediation-01'); packet=w/'docs/planning/active/friday-mcp-protocol-upgrade'; old=packet/'validation/VAL-UP02A-01'
def digest(b):return hashlib.sha256(b).hexdigest()
def write(name,x):(r/name).write_text(json.dumps(x,indent=2)+'\n')
def git(*a,root=w):return subprocess.check_output(['git',*a],cwd=root).decode()
nav=json.loads((old/'navigation-provenance.json').read_text()); rows=[]
for item in json.loads((old/'stored-manifest.json').read_text())['artifacts']:
 b=(old/item['path']).read_bytes(); raw=gzip.decompress(b) if item['encoding']=='gzip' else b
 rows.append({'path':item['path'],'stored_matches':digest(b)==item['stored_sha256'],'raw_matches':digest(raw)==item['sha256'],'bytes_match':len(raw)==item['bytes']})
views=[]
for v in nav['views']:
 p=old/v['path']; kind=v['kind']
 ok=True
 if kind=='byte-identical linked raw artifact':ok=digest(p.read_bytes())==v['sha256']
 elif kind.startswith('archive navigation pointer'):ok=digest(p.read_bytes())==v['pointer_sha256'] and digest(gzip.decompress((old/v['raw_archive']).read_bytes()))==v['sha256']
 elif kind=='readable formatting-only presentation':
  raw=gzip.decompress((old/v['raw_archive']).read_bytes())
  def program(data):
   tree=ast.parse(data);tree.body=[node for node in tree.body if not isinstance(node,(ast.Import,ast.ImportFrom)) and not (isinstance(node,ast.Expr) and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str))];return ast.dump(tree,include_attributes=False)
  literal_match=ast.dump(ast.parse(raw),include_attributes=False)==ast.dump(ast.parse(p.read_bytes()),include_attributes=False)
  program_match=program(raw)==program(p.read_bytes())
  ok=digest(raw)==v['original_sha256'] and digest(p.read_bytes())==v['presentation_sha256'] and program_match
 else:ok=p.is_dir() and (p/'README.md').exists()
 views.append({'path':v['path'],'kind':kind,'verified':ok, **({'literal_module_ast_matches':literal_match,'definitions_and_main_ast_matches_after_import_docstring_normalization':program_match,'presentation_limit':'Provenance docstring, reordered imports and removed unused META_PREFIX import differ; executed original raw bytes remain unchanged.'} if kind=='readable formatting-only presentation' else {})})
write('original-evidence-integrity.json',{'report_matches':digest((old/'report.md').read_bytes())==nav['report_sha256'],'report_sha256':digest((old/'report.md').read_bytes()),'archives':rows,'navigation':views,'all_pass':all(all(x[k] for k in ['stored_matches','raw_matches','bytes_match']) for x in rows) and all(x['verified'] for x in views)})
skips={}
for label in ['root-pytest','baseline-pytest']:
 text=(r/'checks'/label/'stdout').read_text();skips[label]=[line for line in text.splitlines() if line.startswith('SKIPPED ')];skips[label+'-summary']=text.splitlines()[-1]
write('skip-comparison.json',{'candidate':skips['root-pytest'],'baseline':skips['baseline-pytest'],'identical':skips['root-pytest']==skips['baseline-pytest'],'summaries':{k:v for k,v in skips.items() if k.endswith('-summary')}})
original=json.loads((old/'normative-clause-ledger.json').read_text()); identities={(x['source'],x['line']) for x in original['rows']}
# Fresh extraction and explicitly reevaluated applicability against inspected current code.
app={
 'schema.ts':{37,42,43,48,229,232,575,624,876,1104},
 'basic--index.md':{19,29,48,49,50,72,73,75,85,86,87,105,106,107,120,123,127,128,140,162,174,259,293,294,299,303,307,330,336,337,345,370},
 'basic--patterns--mrtr.md':{22,132,262,264},
 'basic--transports--stdio.md':{15,22,38,83,146},
 'basic--versioning.md':{88,124},
 'server--tools.md':{18,293,305}}
notes={
 'schema.ts':('Generic metadata is opaque; named result/notification/Tool/Text fields and prefix grammar are validated; legacy missing tags complete; state stays opaque; cancellation uses issued IDs; cache is never shared because no cache exists.','protocol.py:_metadata/_server_capabilities/complete_result/CacheHint; base.py:_request/_cancel_request; checks/focused, checks/adversarial-probes'),
 'basic--index.md':('Inspected JSON-RPC envelopes/type-sensitive unique IDs/tag handling, fixed safe wire/local error distinction, per-request metadata, 2020-12 bounded schema evaluation and disabled external retrieval.','protocol.py:validate_message/response_from_message/complete_result/validate_output_schema/validate_structured; base.py:_request/_handle_message; checks/focused, checks/package, checks/scope-mypy'),
 'basic--patterns--mrtr.md':('Required request metadata emitted; input-required stops safely without decoding state, responding, retrying or transferring state to another request.','base.py:_request; protocol.py:complete_result; tests:test_modern_result_tags_and_content_have_safe_no_replay_outcomes; checks/focused'),
 'basic--transports--stdio.md':('Canonical newline JSON requests/notifications, no modern client responses, bounded cancellation only for issued requests, varied non-modern fallback; three recognized modern errors do not fallback.','stdio.py:send/receive; base.py:_initialize/_cancel_request/_handle_server_message; checks/focused, checks/adversarial-probes'),
 'basic--versioning.md':('Server extension names have required valid prefixes/settings objects; this client advertises no extensions and performs only core behavior.','protocol.py:_server_capabilities; base.py:_request; checks/focused'),
 'server--tools.md':('Required request metadata, valid object inputSchema under 2020-12, typed annotations/icons remain bounded untrusted data and never authorize decisions.','protocol.py:ToolDefinition/_tool_optional_fields; base.py:_request; checks/focused, checks/package')}
ledger=[]
for p in sorted((r/'normative').iterdir()):
 lines=p.read_text().splitlines(); short=p.name.split('--2026-07-28--')[-1]
 for idx,line in enumerate(lines,1):
  if not re.search(r'\b(MUST|REQUIRED|SHALL)\b',line):continue
  status='PASS' if idx in app.get(short,set()) else 'NOT_APPLICABLE'
  if status=='PASS':reason,evidence=notes[short]
  elif short=='basic--authorization.md':reason='HTTP/OAuth authorization profile is deferred; this is credential-free synthetic stdio review.';evidence='protocol-contract.md:Supported profiles; CD-MCP-UP-001:Non-goals'
  elif short=='basic--transports--streamable-http.md':reason='Modern HTTP binding is UP-02B, explicitly outside approved UP-02A stdio client profile.';evidence='tactical-plan.md:Ordered slices; exact 12-path source diff'
  elif short=='basic--index.md' and idx==426:reason='Conditional emitter-format duty is inactive: this client emits no traceparent/tracestate/baggage and does not extract, forward, inject, parse or trust received opaque values. This prose establishes no receiver-validation step; schema MetaObject declares generic values unknown, unlike typed ResultMetaObject.serverInfo. Passive bounded ignored reception is not trace propagation.';evidence='frozen basic/index.md:420-429 and schema.ts:35-54,143-156; base.py:_request; protocol.py:_metadata; checks/trace-boundary'
  elif short=='basic--patterns--mrtr.md' and idx in {258,261,263}:reason='Mandatory duties apply before/when retrying; this declared profile never retries or supplies inputs and advertises no handlers.';evidence='protocol-contract.md:Modern client core; protocol.py:complete_result; checks/focused'
  elif short=='basic--index.md' and idx in {466,478,481}:reason='Icon rendering/fetch consumer duties are inactive: metadata is shape-checked, bounded and untrusted, no icon fetched, rendered or used for authorization.';evidence='CD-MCP-UP-001:no reference/link fetch; protocol.py:_icons; exact source diff'
  else:reason='Clause is server/other role, unsupported optional interaction, conditional retry/subscription/render duty, or BCP14 terminology; no such handler/effect/capability is declared by this bounded tools-only stdio client.';evidence='CD-MCP-UP-001:Required behavior/Non-goals; protocol-contract.md:Supported profiles; base.py:_request/_handle_server_message'
  ledger.append({'id':f'N-{len(ledger)+1:03d}','source':p.name,'line':idx,'keyword_occurrences':len(re.findall(r'\b(MUST|REQUIRED|SHALL)\b',line)),'source_context':'\n'.join(lines[max(0,idx-3):idx+3]),'status':status,'reason':reason,'evidence':evidence})
structures=[
 ('RequestMetaObject/RequestParams/CallToolRequestParams','PASS','base.py:_request emits revision, package identity, empty honest capabilities with unchanged name/arguments; checks/focused'),
 ('JSONRPCRequest/Notification/Response/Error','PASS','protocol.py:validate_message/response_from_message; base.py:_handle_message; envelope/IDs/privacy/no-modern-response tests and checks/focused'),
 ('MetaObject/ResultMetaObject/NotificationMetaObject','PASS','protocol.py:_metadata uses frozen key grammar and declared-context typed serverInfo/subscriptionId only; checks/focused and trace-boundary'),
 ('DiscoverResult/ServerCapabilities/Implementation/Icons','PASS','protocol.py:Discovery/_server_capabilities/_implementation/_icons; optional flags/identity shapes and extension key/settings regressions; checks/focused'),
 ('CacheableResult/PaginatedResult/ListToolsResult/Tool/ToolAnnotations','PASS','protocol.py:CacheHint/CatalogPage/ToolDefinition/_tool_optional_fields; complete catalog and malformed laterpage invalidation; checks/focused'),
 ('CallToolResult/TextContent/Annotations','PASS','protocol.py:ToolResult/_text_optional_fields; valid text/JSON scalar,array,null, absent distinction, annotations and typed metadata; checks/focused'),
 ('InputRequiredResult/InputRequests','PASS_WITH_LIMITATION','protocol.py:complete_result checks outer state/request map and emits fixed unsupported outcome; no inner optional input handler/continuation/retry; checked source and checks/focused'),
 ('CancelledNotificationParams','PASS','base.py:_cancel_request, stdio.py:_issued_requests; real issued cancellation/timeout ownership tests; checks/focused'),
 ('ImageContent/AudioContent/ResourceLink/EmbeddedResource','UNSUPPORTED_SAFE','protocol.py:ToolResult returns fixed unsupported_content, no fetching/rendering; tests and checks/focused'),
 ('Other schema structures','NOT_APPLICABLE','HTTP/server/resources/prompts/sampling/roots/elicitation/subscriptions/Tasks/Apps/Skills are outside declared first tools-only stdio client profile.')]
write('normative-clause-ledger.json',{'origin':'Fresh extraction of all ten independently hash-verified frozen sources; original 222-row identity/context input reevaluated against current source, not adopted as verdict. One source-line row with wrapped context is not one independent requirement.','counts':dict(collections.Counter(x['status'] for x in ledger)),'original_row_identity_set_matches':{(x['source'],x['line']) for x in ledger}==identities,'rows':ledger,'schema_structures':[{'structure':a,'status':b,'evaluation':c} for a,b,c in structures],'fallback_prose':'basic/versioning.md and stdio.md non-MUST recognized-modern-error prose is additionally binding under protocol-contract; checks/adversarial-probes prove -32020/-32021/-32022 remain modern failures.'})
inv=json.loads((r/'inventory.json').read_text()); current={p:digest((w/p).read_bytes()) for p in inv['candidate_products']}; hashes={c['path']:digest((w/c['path']).read_bytes()) for c in inv['controls']}
base=Path('/private/tmp/friday-mcp-upgrade/baseline'); baselinehead=git('rev-parse','HEAD',root=base).strip(); bd=git('diff','--name-only','46005353046553477417a730f05ff21ead64a00d..'+baselinehead).splitlines()
write('baseline-identity.json',{'snapshot_head':baselinehead,'original_product_baseline':'46005353046553477417a730f05ff21ead64a00d','intervening_changed_paths':bd,'only_process_docs':all(p.startswith('docs/') for p in bd),'baseline_clean':git('status','--porcelain',root=base)==''})
write('freeze-closeout.json',{'date_utc':datetime.now(timezone.utc).isoformat(),'head':git('rev-parse','HEAD').strip(),'branch':git('branch','--show-current').strip(),'status':git('status','--porcelain'),'product_hashes_unchanged':current==inv['candidate_products'],'control_hashes_unchanged':all(hashes[c['path']]==c['actual'] for c in inv['controls']),'authority_sha256':digest((packet/'authority-manifest.json').read_bytes()),'review_request_sha256':digest((packet/'validation-request-remediation-01.json').read_bytes()),'remediation_product_commit':'58f0000b209f76b9deb8e919091c208c5d593a6d','request_recorded_product_candidate':'9283146f10defcb8095270cd7a1b740aa2830112','recorded_product_refs_match_HEAD':all(git('diff','--name-only',ref+'..HEAD','--','packages','uv.lock','pyproject.toml')=='' for ref in ['58f0000b209f76b9deb8e919091c208c5d593a6d','9283146f10defcb8095270cd7a1b740aa2830112']), 'remediation_changed_product_paths':git('diff','--name-only','4f3574c..HEAD','--','packages','uv.lock','pyproject.toml').splitlines()})
write('command-ledger.json',[json.loads(p.read_text())|{'label':p.parent.name} for p in sorted((r/'checks').glob('*/receipt.json'))])
print(json.dumps({'normative_rows':len(ledger),'counts':dict(collections.Counter(x['status'] for x in ledger)),'archives_verified':len(rows),'original_integrity':all(all(x[k] for k in ['stored_matches','raw_matches','bytes_match']) for x in rows),'freeze':json.loads((r/'freeze-closeout.json').read_text())},indent=2))
