from pathlib import Path
import json,gzip,re,hashlib,collections
b=Path('/private/tmp/friday-mcp-upgrade');e=b/'independent-review-UP05-001';w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';mapping=json.loads((p/'execution/up05/amendment002-final/actual-requirement-mapping.json').read_text());captures=json.loads((p/'execution/up05-planning/source-capture-integrity.json').read_text())['captures'];sources=[];paragraphs=[];schemas=[]
keywords=re.compile(r'\b(?:MUST(?: NOT)?|SHALL(?: NOT)?|SHOULD(?: NOT)?|REQUIRED|RECOMMENDED)\b')
for row in captures:
 data=gzip.decompress((w/row['artifact']).read_bytes());text=data.decode();assert hashlib.sha256(data).hexdigest()==row['content_sha256'];historical='2025-11-25' in row['url'];sources.append({'url':row['url'],'sha256':row['content_sha256'],'role':'historical2025 preservation, not current server proof' if historical else 'modern2026 pinned server-role source'})
 for match in re.finditer(r'(?:\A|(?<=\n\n))[^\n]*(?:\n(?!\n)[^\n]*)*',text):
  para=match.group();tokens=keywords.findall(para)
  if tokens:paragraphs.append({'source':row['url'],'line':text[:match.start()].count('\n')+1,'paragraph':para,'tokens':tokens,'role':'historical2025' if historical else 'modern2026'})
 if not row['url'].endswith('schema.ts'):continue
 declarations=[];matches=list(re.finditer(r'^export (?:interface|type) (\w+)',text,re.M))
 for i,m in enumerate(matches):
  end=matches[i+1].start() if i+1<len(matches) else len(text);chunk=text[m.start():end];fields=[]
  for f in re.finditer(r'^\s*(?:"[^"]+"|[A-Za-z_$][\w$]*)(?:\?)?:[^\n]*',chunk,re.M):
   fields.append({'line':text[:m.start()+f.start()].count('\n')+1,'field':f.group().strip()})
  declarations.append({'name':m[1],'line':text[:m.start()].count('\n')+1,'sha256':hashlib.sha256(chunk.encode()).hexdigest(),'complete_declaration':chunk,'fields':fields})
 schemas.append({'role':'historical2025' if historical else 'modern2026','sha256':row['content_sha256'],'declarations':declarations,'counts':{'declarations':len(declarations),'field_references':sum(len(x['fields']) for x in declarations)}})
modern=next(s for s in schemas if s['role']=='modern2026');assert modern['sha256']=='742750af0bb8c716e7030c4977c992b55d1adc4407e9e66997db5846baedc2cd';assert modern['counts']=={'declarations':155,'field_references':337}
assert [(d['name'],d['line'],d['sha256']) for d in modern['declarations']]==[(d['name'],d['schema_line'],d['complete_declaration_sha256']) for d in mapping['declarations']]
assert [(d['name'],f['line'],f['field']) for d in modern['declarations'] for f in d['fields']]==[(f['declaration'],f['schema_line'],f['field']) for f in mapping['fields']]
# Every builder source/assertion reference is checked for bytes and actual AST symbol range.
refs=[]
for bundle in mapping['bundles'].values():
 for kind in ['source','assertions']:
  for row in bundle[kind]:
   data=(w/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];lines=data.decode().splitlines();assert row['line']<=len(lines) and row['end_line']<=len(lines)
   assert all('assert' in lines[n-1] or 'assert' in '\n'.join(lines[max(0,n-4):n]) for n in row['assertion_lines'])
   refs.append({'bundle':bundle['id'],'kind':kind,'path':row['path'],'symbol':row['symbol'],'line':row['line'],'end_line':row['end_line'],'bytes_match':True,'limitation':'Pointer verification does not establish requirement or variant coverage.'})
(e/'independent-normative-inventory.json').write_text(json.dumps({'sources':sources,'paragraphs':paragraphs,'schemas':schemas,'mapping_reference_integrity':refs,'boundary':'Independent extraction from SHA-selected originals. Counts are inventories; see report for role exclusions, requirement assessment and failing probes.'},indent=2)+'\n');print(json.dumps({'sources':len(sources),'paragraphs':len(paragraphs),'schema_counts':{s['role']:s['counts'] for s in schemas},'mapping_references_checked':len(refs)}))
