from pathlib import Path
import json,re,collections,hashlib,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');e=b/'independent-review-UP05-001';w=b/'work';base=b/'up05-baseline';r=json.loads((w/'docs/planning/active/friday-mcp-protocol-upgrade/validation-request-UP05.json').read_text())
def normalize(v,snap):
 if isinstance(v,str):return v.replace(str(snap),'<snapshot>')
 if isinstance(v,list):return [normalize(x,snap) for x in v]
 if isinstance(v,dict):return {k:normalize(x,snap) for k,x in v.items()}
 return v
checks={}
for c in r['required_checks']:
 d=e/'final-checks'/c['id'];receipt=json.loads((d/'receipt.json').read_text());pre=json.loads((d/'preflight.json').read_text());snap=b/c['snapshot'];expected=1 if c['id'] in ['root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy'] else 0
 assert receipt['argv']==c['argv'] and receipt['exit_code']==expected,(c['id'],receipt['exit_code']);assert pre['candidate_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=snap,text=True).strip();assert pre['environment']==receipt['environment'];assert receipt['guard_sha256']==r['guard']['sha256']
 assert pre['source_hashes']=={f:hashlib.sha256((snap/f).read_bytes()).hexdigest() if (snap/f).is_file() else None for f in r['product_paths']}
 assert pre['metadata_hashes']==r['metadata_hashes'] and pre['preserved_product_hashes']==r['preserved_product_hashes']
 proposal=json.loads((w/'docs/planning/active/friday-mcp-protocol-upgrade/proposals/UP-05-authority-manifest.json').read_text())
 assert pre['control_hashes']=={x['path']:x['sha256'] for x in proposal['controls']+proposal['prior_frozen_manifests']}
 assert pre['original_runner_sha256']=='ceec1b2316f4be3bce36fb778eb80b5d472561920d6d6fe35b8b30735e1776f0'
 assert pre['UP05_runner_sha256']==hashlib.sha256((e/'review_runner_final.py').read_bytes()).hexdigest()
 for f in ['stdout','stderr']:assert hashlib.sha256((d/f).read_bytes()).hexdigest()==receipt[f+'_sha256']
 checks[c['id']]={'exit_code':receipt['exit_code'],'argv':receipt['argv'],'stdout':str((d/'stdout').relative_to(e)),'stderr':str((d/'stderr').relative_to(e)),'receipt':str((d/'receipt.json').relative_to(e)),'last_line':(d/'stdout').read_text().splitlines()[-1] if (d/'stdout').read_text().splitlines() else ''}
rr=[]
for id,snap in [('root-ruff',w),('baseline-root-ruff',base)]:
 objs=normalize(json.loads((e/'final-checks'/id/'stdout').read_text()),snap);(e/(id+'-complete-normalized.json')).write_text(json.dumps(objs,indent=2)+'\n');rr.append(collections.Counter(json.dumps(x,sort_keys=True) for x in objs))
assert rr[0]==rr[1] and sum(rr[0].values())==327
mypy=[]
for id in ['full-mypy','baseline-full-mypy']:
 text=(e/'final-checks'/(id+'-columns')/'stdout').read_text();objs=[]
 assert json.loads((e/'final-checks'/(id+'-columns')/'receipt.json').read_text())['exit_code']==1
 for line in text.splitlines():
  m=re.fullmatch(r'(.+?):(\d+):(\d+): (error|note): (.*?)(?:  \[([^\]]+)\])?',line)
  if m:objs.append({'path':m[1],'line':int(m[2]),'column':int(m[3]),'severity':m[4],'message':m[5],'code':m[6]})
 (e/(id+'-complete-column-objects.json')).write_text(json.dumps(objs,indent=2)+'\n');mypy.append(objs)
assert mypy[0]==mypy[1] and len(mypy[0])==4
roots={}
for id,snap in [('root',w),('baseline-root',base)]:
 text=(e/'final-checks'/id/'stdout').read_text().replace(str(snap),'<snapshot>');warnings=re.search(r'=+ warnings summary =+\n(.*?)\n-- Docs:',text,re.S);assert warnings
 roots[id]={'skips':[l for l in text.splitlines() if l.startswith('SKIPPED')],'warnings_complete':warnings[1],'summary':text.splitlines()[-1]}
 (e/(id+'-normalized-warnings-skips.json')).write_text(json.dumps(roots[id],indent=2)+'\n')
assert roots['root']['skips']==roots['baseline-root']['skips'] and roots['root']['warnings_complete']==roots['baseline-root']['warnings_complete']
changed=json.loads((e/'candidate-changed-paths.json').read_text());assert len(set(changed)&set(r['product_paths']))==18;assert all(x in r['product_paths'] or x.startswith('docs/planning/') for x in changed)
summary={'checks':checks,'root_ruff_complete327_objects_and_fixes_equal':True,'mypy_complete4_objects_equal':True,'mypy_objects':mypy[0],'roots':roots,'scope_product_paths':18,'other_changed_paths':'docs/planning only','boundary':'Deterministic profile and debt comparisons do not establish unmet semantic criteria.'}
(e/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['checks','roots','mypy_objects']}));print(roots['root']['summary']);print(roots['baseline-root']['summary'])
