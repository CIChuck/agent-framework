from pathlib import Path
import json,hashlib,subprocess,sys,gzip
b=Path('/private/tmp/friday-mcp-upgrade');e=b/'independent-review-UP05-001';w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';r=json.loads((p/'validation-request-UP05.json').read_text());a=json.loads((p/'authority-UP-05-amendment-002.json').read_text())
def h(f): return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
rows=r['controls']+[r['authority_manifest']]+a['controls']+a['prior_frozen_manifests']+[a[k] for k in ['approval','approved_proposal','amendment_approval','approved_amendment','amendment_document','parent_authority','prior_amendment_authority','prior_amendment_approval','prior_approved_amendment','prior_amendment_document','corrected_prospective_plan']]
protected={**r['product_hashes'],**r['metadata_hashes'],**r['preserved_product_hashes'],**{v['path']:v['sha256'] for v in rows}}
bad=[{'path':f,'expected':digest,'actual':h(w/f)} for f,digest in protected.items() if h(w/f)!=digest]
source=[]
for row in json.loads((p/'execution/up05-planning/source-capture-integrity.json').read_text())['captures']:
 data=(w/row['artifact']).read_bytes();plain=gzip.decompress(data);source.append({'path':row['artifact'],'artifact_match':hashlib.sha256(data).hexdigest()==row['artifact_sha256'],'content_match':hashlib.sha256(plain).hexdigest()==row['content_sha256'],'bytes_match':len(plain)==row['bytes']})
groups=json.loads((b/'reused-library-manifest.json').read_text())['copied']+json.loads((b/'additional-validation-libraries.json').read_text())['added'];libbad=[];count=0
for g in groups:
 for row in g['files']:
  f=b/'venv/lib/python3.13/site-packages'/row['path'];actual=h(f);count+=1
  if actual!=row['sha256']:libbad.append({'path':row['path'],'expected':row['sha256'],'actual':actual})
out={'candidate_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'git_status':subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True),'protected_mismatches':bad,'metadata_count':len(r['metadata_hashes']),'accepted_product_count':len(r['preserved_product_hashes']),'library_files':count,'distributions':len(groups),'library_mismatches':libbad,'captures':source,'runner_hashes':{f:h(b/f) for f in ['run_check.py','run_check_UP05.py','guard/sitecustomize.py']},'protected_actual':{f:h(w/f) for f in protected}}
(e/('stability-'+sys.argv[1]+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='protected_actual'}));assert not bad and not libbad and count==22009 and len(groups)==192 and len(source)==19 and all(all(v for k,v in x.items() if k!='path') for x in source)
