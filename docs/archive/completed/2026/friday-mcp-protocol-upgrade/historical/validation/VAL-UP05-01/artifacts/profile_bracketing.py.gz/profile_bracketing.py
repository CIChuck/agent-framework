from pathlib import Path
import json,hashlib,datetime,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');e=b/'independent-review-UP05-001';w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';r=json.loads((p/'validation-request-UP05.json').read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
receipts=[]
for label in [c['id'] for c in r['required_checks']]+['full-mypy-columns','baseline-full-mypy-columns']:
 j=json.loads((e/'final-checks'/label/'receipt.json').read_text());receipts.append({'id':label,'started_utc':j['started_utc'],'finished_utc':j['finished_utc'],'exit_code':j['exit_code']})
start=min(datetime.datetime.fromisoformat(j['started_utc']) for j in receipts);end=max(datetime.datetime.fromisoformat(j['finished_utc']) for j in receipts)
before=e/'stability-before-final-profile.json';after=e/'stability-after-final-profile.json';before_time=datetime.datetime.fromtimestamp(before.stat().st_mtime,datetime.timezone.utc);after_time=datetime.datetime.fromtimestamp(after.stat().st_mtime,datetime.timezone.utc);assert before_time<start and after_time>end
for previous,current in zip(receipts,receipts[1:]):assert datetime.datetime.fromisoformat(previous['finished_utc'])<=datetime.datetime.fromisoformat(current['started_utc'])
pre=json.loads(before.read_text());post=json.loads(after.read_text());assert pre==post
assert pre['candidate_commit']=='b57c25d9fc4933059f64ed836783291f5753b9a8' and not pre['git_status'];assert not pre['protected_mismatches'] and not pre['library_mismatches'];assert pre['library_files']==22009 and pre['distributions']==192
(e/'profile-bracketing.json').write_text(json.dumps({'snapshot_before':{'path':before.name,'sha256':sha(before),'written_utc':before_time.isoformat()},'snapshot_after':{'path':after.name,'sha256':sha(after),'written_utc':after_time.isoformat()},'first_check_started_utc':start.isoformat(),'last_check_finished_utc':end.isoformat(),'all22_checks_sequential':True,'before_after_complete_objects_equal':True,'receipts':receipts},indent=2)+'\n')
