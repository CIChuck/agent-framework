import gzip
import hashlib
import json
import re
import subprocess
import tomllib
from pathlib import Path

work = Path('/private/tmp/friday-mcp-upgrade/work')
out = Path('/private/tmp/friday-mcp-upgrade/independent-review')
packet = work / 'docs/planning/active/friday-mcp-protocol-upgrade'
authority = json.loads((packet / 'authority-manifest.json').read_text())
def digest(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=work)
controls = [{'path': c['path'], 'expected': c['sha256'], 'actual': digest((work/c['path']).read_bytes())} for c in authority['controls']]
normative = []
for source in json.loads((packet/'research-sources/manifest.json').read_text())['sources']:
    artifact = packet/'research-sources'/source['artifact']
    raw = artifact.read_bytes()
    data = gzip.decompress(raw)
    normative.append({'path': str(artifact.relative_to(work)), 'bytes': len(data), 'expected': source['sha256'], 'actual': digest(data), 'artifact_expected': source['artifact_sha256'], 'artifact_actual': digest(raw)})
    target = out/'normative'/source['artifact'].removesuffix('.gz')
    target.parent.mkdir(exist_ok=True)
    target.write_bytes(data)
product = {p:digest((work/p).read_bytes()) for p in authority['product_scope']}
baseline_checks = {}
for path, expected in authority['product_scope'].items():
    baseline_checks[path] = None if expected is None else digest(git('show', authority['product_baseline']+':'+path)) == expected
changed = git('diff','--name-only','9e11fb7..4f3574c').decode().splitlines()
product_changes = [p for p in changed if p.startswith('packages/') or p in ('uv.lock','pyproject.toml')]
locks = [tomllib.loads(git('show',authority['product_baseline']+':uv.lock').decode()),tomllib.loads((work/'uv.lock').read_text())]
versions = [{n: sorted({p['version'] for p in l['package'] if p['name']==n}) for n in {p['name'] for p in l['package']}} for l in locks]
delta = {n:[old,versions[1].get(n)] for n,old in versions[0].items() if old!=versions[1].get(n)}
new = {n:v for n,v in versions[1].items() if n not in versions[0]}
receipt = {'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--porcelain').decode(),'authority_sha256':digest((packet/'authority-manifest.json').read_bytes()), 'controls':controls,'normative':normative,'baseline_product_hashes_match':baseline_checks,'candidate_products':product,'exact_product_changes': product_changes, 'unauthorized_product_paths':sorted(set(product_changes)-set(authority['product_scope'])),'existing_version_changes':delta,'new_versions':new, 'lock_matches_approved_decompressed_proposal':digest((work/'uv.lock').read_bytes())==digest(gzip.decompress((packet/'execution/dependency-conflict/proposed-uv.lock.gz').read_bytes())), 'guard_sha256':digest(Path('/private/tmp/friday-mcp-upgrade/guard/sitecustomize.py').read_bytes())}
(out/'inventory.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'full.diff').write_bytes(git('diff','--binary','9e11fb7..4f3574c'))
for label,root in [('baseline-ruff','/private/tmp/friday-mcp-upgrade/baseline'),('root-ruff',str(work))]:
    rows=json.loads((out/'checks'/label/'stdout').read_text())
    identities={(r['filename'].removeprefix(root+'/'),r['code'],r['location']['row'],r['location']['column']) for r in rows}
    if label=='baseline-ruff': baseline=identities
    else: candidate=identities
(out/'ruff-comparison.json').write_text(json.dumps({'baseline_count':len(baseline),'candidate_count':len(candidate),'new':sorted(candidate-baseline),'removed':sorted(baseline-candidate)},indent=2)+'\n')
print(json.dumps({'controls':len(controls),'mismatches':[c for c in controls if c['actual']!=c['expected']],'normative_mismatches':[c for c in normative if c['actual']!=c['expected'] or c['artifact_actual']!=c['artifact_expected']],'products':len(product_changes),'version_delta':delta,'ruff_new':len(candidate-baseline)}))
