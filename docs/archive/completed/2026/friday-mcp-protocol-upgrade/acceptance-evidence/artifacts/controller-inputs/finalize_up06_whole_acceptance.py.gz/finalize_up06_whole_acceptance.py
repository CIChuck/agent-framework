from pathlib import Path
import gzip,hashlib,json,subprocess
import yaml
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';root=Path('/Users/chuckrussell/Dev/gendev/agent-framework');p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=w/'docs/archive/completed/2026/friday-mcp-protocol-upgrade';out=a/'acceptance-evidence';out.mkdir(exist_ok=False);pres=b/'up06-whole-acceptance-root-preservation'
def req(ok,msg):
    if not ok:raise RuntimeError(msg)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
base=yaml.safe_load(subprocess.check_output(['git','show','HEAD:docs/planning/board.yaml'],cwd=root,text=True));actual=yaml.safe_load((root/'docs/planning/board.yaml').read_text());overlay=json.loads((pres/'board-overlay.json').read_text());tasks={t['id']:t for t in base['tasks']};tasks.update(overlay['tasks']);req(tasks=={t['id']:t for t in actual['tasks']},'Root task overlay changed');events=list(base['events'])
for event in overlay['events']:
    if event not in events:events.append(event)
req(events==actual['events'],'Root event overlay changed')
items=[]
def store(name,raw):
    f=out/'artifacts'/(name+'.gz');f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(gzip.compress(raw,mtime=0));items.append({'original_path':name,'path':str(f.relative_to(out)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(f)})
for name in ['record_up06_whole_acceptance.py','finalize_up06_whole_acceptance.py']:store('controller-inputs/'+name,(b/name).read_bytes())
checks={}
for name in ['board','next','show','docs','render','whitespace']:
    folder=b/'checks'/('up06-whole-acceptance-'+name);receipt=json.loads((folder/'receipt.json').read_text());req(receipt['exit_code']==0,'Acceptance check failed');checks[name]=receipt['exit_code']
    for file in ['preflight.json','receipt.json','stdout','stderr']:store('checks/'+name+'/'+file,(folder/file).read_bytes())
for row in json.loads((a/'historical-authority.json').read_text())['files']:req(h(w/row['path'])==row['sha256'],'Historical backing changed')
receipt=json.loads((a/'acceptance.json').read_text())
for name,sha in receipt['accepted_source_hashes'].items():req(h(w/name)==sha,'Accepted source drift')
for name,sha in receipt['metadata_hashes'].items():req(h(w/name)==sha,'Dependency metadata drift')
for row in items:req(hashlib.sha256(gzip.decompress((out/row['path']).read_bytes())).hexdigest()==row['sha256'],'Evidence archive mismatch')
(out/'stored-manifest.json').write_text(json.dumps({'artifacts':items,'checks':checks,'work_state':'accepted','delivery_state':'local','original_backing_unchanged':True,'source_changes':0},indent=2)+'\n')
paths=['docs/planning/review/friday-mcp-protocol-upgrade','docs/archive/completed/2026/friday-mcp-protocol-upgrade','docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Record maintainer acceptance and archive verified MCP upgrade'],cwd=w,check=True,stdout=subprocess.DEVNULL);req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Private candidate not clean');print(json.dumps({'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'checks':checks,'acceptance_receipt':str((a/'acceptance.json').relative_to(w)),'work_state':'accepted','delivery_state':'local'},indent=2))
