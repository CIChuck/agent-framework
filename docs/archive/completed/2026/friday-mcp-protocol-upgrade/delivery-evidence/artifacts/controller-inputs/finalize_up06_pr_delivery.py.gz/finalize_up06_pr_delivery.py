from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';a=w/'docs/archive/completed/2026/friday-mcp-protocol-upgrade';out=a/'delivery-evidence';out.mkdir(exist_ok=False)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def req(ok,msg):
    if not ok:raise RuntimeError(msg)
rows=[]
def store(name,raw):
    dest=out/'artifacts'/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));rows.append({'original_path':name,'path':str(dest.relative_to(out)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(dest)})
for name in ['record_up06_pr_delivery.py','finalize_up06_pr_delivery.py','mcp-upgrade-pr-body.md']:store('controller-inputs/'+name,(b/name).read_bytes())
checks={}
for key in ['board','docs','render','show','whitespace']:
    folder=b/'checks'/('up06-pr-delivery-'+key);code=json.loads((folder/'receipt.json').read_text())['exit_code'];req(code==0,'Delivery check failed');checks[key]=code
    for name in ['preflight.json','receipt.json','stdout','stderr']:store('checks/'+key+'/'+name,(folder/name).read_bytes())
accepted=json.loads((a/'acceptance.json').read_text())
for name,sha in accepted['accepted_source_hashes'].items():req(h(w/name)==sha,'Source drift')
for name,sha in accepted['metadata_hashes'].items():req(h(w/name)==sha,'Dependency metadata drift')
for row in json.loads((a/'historical-authority.json').read_text())['files']:req(h(w/row['path'])==row['sha256'],'Historical backing drift')
for row in rows:req(hashlib.sha256(gzip.decompress((out/row['path']).read_bytes())).hexdigest()==row['sha256'],'Archive mismatch')
(out/'stored-manifest.json').write_text(json.dumps({'artifacts':rows,'checks':checks,'source_changes':0,'delivery':'pushed','pull_request':'https://github.com/CIChuck/agent-framework/pull/8'},indent=2)+'\n')
paths=['docs/planning/board.yaml','docs/planning/README.md',str((a/'README.md').relative_to(w)),str((a/'closeout.md').relative_to(w)),str((a/'current-process-state.json').relative_to(w)),str((a/'delivery.json').relative_to(w)),str(out.relative_to(w))];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Record MCP branch publication and pull request 8'],cwd=w,check=True,stdout=subprocess.DEVNULL);req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Private paths uncommitted');print(json.dumps({'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'checks':checks,'source_changes':0}))
