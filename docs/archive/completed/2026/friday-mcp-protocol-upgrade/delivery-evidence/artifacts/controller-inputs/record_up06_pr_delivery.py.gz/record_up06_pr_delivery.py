from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,subprocess,sys
import yaml
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';root=Path('/Users/chuckrussell/Dev/gendev/agent-framework');a=w/'docs/archive/completed/2026/friday-mcp-protocol-upgrade';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';expected='6dca42e8333a0e7c9f1ff68c4d1930500509c48e';url='https://github.com/CIChuck/agent-framework/pull/8'
def req(ok,msg):
    if not ok:raise RuntimeError(msg)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for checkout in [w,root]:req(subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip()==expected,'HEAD changed')
req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Private candidate dirty')
accepted=json.loads((a/'acceptance.json').read_text())
for name,sha in accepted['accepted_source_hashes'].items():req(h(w/name)==h(root/name)==sha,'Source changed')
for row in json.loads((a/'historical-authority.json').read_text())['files']:req(h(w/row['path'])==h(root/row['path'])==row['sha256'],'Backing drift')
prior=b/'up06-whole-acceptance-root-preservation';pres=b/'up06-pr-delivery-root-preservation';pres.mkdir(exist_ok=False)
for name,sha in json.loads((prior/'preservation.json').read_text()).items():req((h(root/name) if (root/name).is_file() else None)==sha,'Unrelated file drift')
for name in ['preservation.json','board-overlay.json']:(pres/name).write_bytes((prior/name).read_bytes())
(pres/'board.yaml').write_bytes((root/'docs/planning/board.yaml').read_bytes());(pres/'README.md').write_bytes((root/'docs/planning/README.md').read_bytes())
base=yaml.safe_load(subprocess.check_output(['git','show','HEAD:docs/planning/board.yaml'],cwd=root,text=True));actual=yaml.safe_load((root/'docs/planning/board.yaml').read_text());overlay=json.loads((pres/'board-overlay.json').read_text());tasks={t['id']:t for t in base['tasks']};tasks.update(overlay['tasks']);req(tasks=={t['id']:t for t in actual['tasks']},'Root board overlay changed');events=list(base['events'])
for event in overlay['events']:
    if event not in events:events.append(event)
req(events==actual['events'],'Root board events changed')
receipt={'initiative':'friday-mcp-protocol-upgrade','maintainer':'Chuck Russell','maintainer_statement':'I think we should commit the local branch, Submit PR to master.','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'authorized_actions':['Commit MCP delivery metadata','Push feature/friday-mcp-protocol-upgrade','Submit pull request to master'],'delivery_state':'pushed','pull_request':url,'base_branch':'master','base_commit':'1302b5fe3091304c08d1df77ea5fb1d2a4ec3666','head_branch':'feature/friday-mcp-protocol-upgrade','initial_published_commit':expected,'source_changes':0,'acceptance_receipt_sha256':h(a/'acceptance.json'),'historical_authority_manifest_sha256':h(a/'historical-authority.json')}
(a/'delivery.json').write_text(json.dumps(receipt,indent=2)+'\n');statepath=a/'current-process-state.json';state=json.loads(statepath.read_text());state.update(delivery_state='pushed',pull_request=url,next_gate='Review PR #8 against master; merge remains a separate decision',delivery_receipt=str((a/'delivery.json').relative_to(w)),note='Whole upgrade remains accepted; branch published and PR #8 submitted under explicit maintainer instruction; frozen source and historical evidence unchanged');statepath.write_text(json.dumps(state,indent=2)+'\n')
readme=a/'README.md';readme.write_text(readme.read_text().replace('Delivery: **local**.','Delivery: **pushed**.').replace('Next gate: PR delivery planning. Langfuse remains separately queued.','Next gate: review [PR #8]('+url+') against `master`. [Delivery receipt](delivery.json). Langfuse remains separately queued.'))
closeout=a/'closeout.md';closeout.write_text(closeout.read_text().replace('Delivery remains local; PR delivery and optional Langfuse implementation are later steps.','Branch pushed and [PR #8]('+url+') submitted against `master`. Merge and optional Langfuse implementation remain separate later steps.'))
spec=importlib.util.spec_from_file_location('up06_delivery_board',w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);board=m.load_board(w);task=next(t for t in board['tasks'] if t['id']==receipt['initiative']);req(task['work_state']=='accepted' and task['delivery_state']=='local','Unexpected task state');task['next_gate']=state['next_gate'];m._save_board_and_dashboard(board,w)
subprocess.run([str(b/'venv/bin/python'),str(w/'scripts/friday-dev-board.py'),'set-delivery',receipt['initiative'],'pushed','--actor','Codex','--actor-role','agent','--note','Explicit maintainer instruction to commit branch and submit PR to master; branch published, PR #8 open','--evidence',url],cwd=w,check=True)
req(m.validate_board(m.load_board(w),w)==[],'Delivery board invalid');print(json.dumps({'pull_request':url,'work_state':'accepted','delivery_state':'pushed','source_changes':0}))
