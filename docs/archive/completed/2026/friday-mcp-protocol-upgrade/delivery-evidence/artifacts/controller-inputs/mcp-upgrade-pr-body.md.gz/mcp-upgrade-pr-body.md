Friday can now connect to and serve the declared modern MCP tools profiles, using the pinned MCP **2026-07-28** specification. Runtime and real Chat load MCP connections from `tools.providers.mcp.config.servers` in YAML. Existing connections retain their legacy default; modern and automatic stdio selection are explicit.

The upgrade adds modern stdio and HTTPS Streamable HTTP clients, explicit **2025-11-25 HTTP client compatibility**, and programmatic **2026-07-28 modern servers**. Streamable HTTP accepts JSON or request-scoped SSE responses. Retained legacy HTTP+SSE APIs remain available separately. This is a bounded tools implementation; optional resources, prompts, OAuth, subscriptions, resumption and Tasks fulfillment are outside the declared profile.

Catalog/schema admission, structured results, errors, cancellation, deadlines, transport cleanup, remote trust settings and telemetry redaction are covered across the MCP package and Runtime/Chat integration. Updated client/server guides and the [migration guide](https://github.com/CIChuck/agent-framework/blob/feature/friday-mcp-protocol-upgrade/docs/guides/19-mcp-migration.md) explain configuration, compatibility and limits. Dependency changes follow the approved manifest, including IDNA 3.11 → 3.20; the MCP SDK is a development interoperability counterpart.

The development board also gains explicit SHA-pinned historical authority backing. A completed or accepted task has one canonical review/archive packet while its original approvals and sealed evidence remain immutable. Strict ownership, path, digest and state checks preserve ordinary orphan rejection and maintainer-only acceptance.

Validation:

- Fresh independent **VERIFIED** review of the entire feature: all 12 aggregate and eight initiative criteria, and all **27 required checks** met their contracts.
- Workspace suite: **5,901 passed, 14 skipped**; accepted baseline: 5,852 passed, 14 skipped. Complete warning and skip details match the baseline.
- **49 aggregate MCP tests** exercise actual Friday subprocess stdio, verified TLS JSON/SSE peers, Runtime/Chat loaders and published configurations. **54 board tests** and an independent full-current-board closeout rehearsal pass.
- Scoped Ruff and Mypy gates pass. Full checks retain exactly the baseline's **327 Ruff diagnostic/fix objects and four Mypy diagnostics**, with no new debt or weakened checker settings.
- Source/control/dependency integrity and all 655 safe independent evidence entries verified. Original failed attempts and declared limitations remain disclosed in the [sealed report](https://github.com/CIChuck/agent-framework/blob/feature/friday-mcp-protocol-upgrade/docs/planning/active/friday-mcp-protocol-upgrade/validation/VAL-UP06-02/report.md).

Chuck Russell accepted the whole upgrade on 2026-10-14; [accepted closeout](https://github.com/CIChuck/agent-framework/blob/feature/friday-mcp-protocol-upgrade/docs/archive/completed/2026/friday-mcp-protocol-upgrade/README.md). Langfuse remains separately queued. Unrelated local work is excluded from this PR.
