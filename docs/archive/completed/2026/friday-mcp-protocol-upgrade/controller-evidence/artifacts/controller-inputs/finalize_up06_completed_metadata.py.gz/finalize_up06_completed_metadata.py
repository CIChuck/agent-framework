from pathlib import Path
import gzip, hashlib, json, subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';review=w/'docs/planning/review/friday-mcp-protocol-upgrade';r=b/'independent-review-UP06-002';d=p/'validation/VAL-UP06-02';out=review/'controller-evidence';out.mkdir(exist_ok=False)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def req(ok,msg):
    if not ok:raise RuntimeError(msg)
items=[]
def store(name,raw):
    dest=out/'artifacts'/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));items.append({'original_path':name,'path':str(dest.relative_to(out)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(dest)})
for name in ['prepare_up06_verified_completion.py','finalize_up06_completed_metadata.py']:
    store('controller-inputs/'+name,(b/name).read_bytes())
results={}
for folder in sorted((b/'checks').glob('up06-amend2-completion-*')):
    receipt=json.loads((folder/'receipt.json').read_text());results[folder.name]=receipt['exit_code']
    for name in ['preflight.json','receipt.json','stdout','stderr']:
        store('checks/'+folder.name+'/'+name,(folder/name).read_bytes())
for key,value in results.items():
    req(value==(1 if key.endswith('root-ruff') or key.endswith('completion-docs') else 0),'Unexpected controller check result')
ruff=json.loads((b/'checks/up06-amend2-completion-root-ruff/stdout').read_text());prior=json.loads((b/'checks/up06-amend2-corrected-root-ruff/stdout').read_text());req(ruff==prior and len(ruff)==327,'Imported evidence adds lint debt')
source=json.loads((p/'execution/up06-amend2/verification-comparison.json').read_text())['source_hashes']
for name,sha in source.items():req(h(w/name)==sha,'Product drift')
request=json.loads((p/'validation-request-UP-06-amendment-002.json').read_text())
for row in request['controls']:req(h(w/row['path'])==row['sha256'],'Control drift')
manifest=json.loads((r/'evidence-manifest.json').read_text())
for row in manifest['entries']:req(h(r/row['path'])==row['sha256'],'Sealed original evidence drift')
req(h(r/'report.md')==h(d/'report.md')=='85419bf1971132a18d896f057ae53f350b2efc56ce9e8cb6549309447d1abe01','Original report drift')
req(h(r/'evidence-manifest.json')==h(d/'evidence-manifest.json')=='84385ea8214479993ad4f42e5d16683741ac7db6d363fe890d2cb25d4476a894','Original manifest drift')
stored=json.loads((d/'stored-manifest.json').read_text())
for row in stored['artifacts']:
    f=d/row['path'];req(h(f)==row['stored_sha256'] and hashlib.sha256(gzip.decompress(f.read_bytes())).hexdigest()==row['sha256'],'Archive drift')
summary={'checks':results,'new_source_changes':0,'source_paths':len(source),'original_safe_entries_verified':len(manifest['entries']),'root_ruff_complete_objects_identical':327,'controller_correction':'New canonical README needed literal Status: label for existing documentation checker; failed receipt retained, current metadata fixed; no source/report/control edits','work_state':'completed','delivery_state':'local','whole_acceptance':'pending','publication':'none'}
(out/'verification.json').write_text(json.dumps(summary,indent=2)+'\n');(out/'stored-manifest.json').write_text(json.dumps({'artifacts':items},indent=2)+'\n')
for row in items:req(hashlib.sha256(gzip.decompress((out/row['path']).read_bytes())).hexdigest()==row['sha256'],'Controller archive drift')
paths=[str(x.relative_to(w)) for x in [d,review,p/'execution/current-process-state.json',p/'execution-log.md']]+['docs/planning/board.yaml','docs/planning/README.md']
subprocess.run(['git','add','--',*paths],cwd=w,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True)
subprocess.run(['git','commit','-m','Propose verified MCP upgrade completion with immutable authority backing'],cwd=w,check=True,stdout=subprocess.DEVNULL)
req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Uncommitted private paths')
print(json.dumps({'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),**summary},indent=2))
