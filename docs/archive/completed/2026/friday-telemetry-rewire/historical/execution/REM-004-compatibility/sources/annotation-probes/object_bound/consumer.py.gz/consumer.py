from converted import CommandRegistry
class Parent: pass
class Child(Parent): pass
def parent_to_child(value: CommandRegistry[Parent]) -> CommandRegistry[Child]:
    return value

def child_to_parent(value: CommandRegistry[Child]) -> CommandRegistry[Parent]:
    return value
