"""Pre-build synthetic LLM probes: provider dispatch replaced before execution."""
import asyncio
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch

import litellm


async def forbidden(*args, **kwargs):
    raise RuntimeError("unapproved live dispatch")


# Patch both dispatch points before importing any Friday product service.
litellm.acompletion = forbidden
litellm.aembedding = forbidden

from friday_llm import ChatCompletionRequest, LiteLLMService, ResilienceConfig
from friday_llm.embeddings import LiteLLMEmbeddingService
from friday_llm.telemetry_models import ConversationContext
from friday_telemetry import DebugTelemetryRecorder


SENTINEL = "private-baseline-sentinel"
response = NS(
    choices=[NS(message=NS(content="done", tool_calls=[], reasoning_content=None),
                finish_reason="stop")],
    usage=NS(prompt_tokens=3, completion_tokens=4, total_tokens=7),
    model=SENTINEL, id=SENTINEL,
)


class Stream:
    def __init__(self, *, fail=None):
        self.count = 0
        self.closed = False
        self.fail = fail

    def __aiter__(self):
        return self

    async def __anext__(self):
        self.count += 1
        if self.count == 1:
            return NS(usage=None, choices=[NS(delta=NS(content="done"), finish_reason=None)])
        if self.fail:
            raise self.fail
        if self.count == 2:
            return NS(usage=NS(prompt_tokens=3, completion_tokens=4, total_tokens=7),
                      choices=[NS(delta=None, finish_reason="stop")])
        raise StopAsyncIteration

    async def aclose(self):
        self.closed = True


class CaptureSink(DebugTelemetryRecorder):
    def __init__(self):
        super().__init__()
        self.delivered = []

    def capture_event(self, name, data):
        self.delivered.append((name, data))
        super().capture_event(name, data)


class FailingSink(CaptureSink):
    def capture_event(self, name, data):
        raise RuntimeError("sink-failure")


def service(sink):
    return LiteLLMService(model_name="gpt-4", telemetry=sink,
                         resilience=ResilienceConfig.disabled())


async def main():
    results = {}
    request = ChatCompletionRequest(messages=({"role": "user", "content": SENTINEL},))
    for api in ["typed", "legacy"]:
        sink = CaptureSink()
        client = service(sink)
        with patch.object(litellm, "acompletion", AsyncMock(return_value=response)) as dispatch:
            if api == "typed":
                result = await client.chat_completion_request(request)
            else:
                result = await client.chat_completion(
                    [{"role": "user", "content": SENTINEL}],
                    conversation_context=ConversationContext(session_id=SENTINEL),
                )
        results[api] = dict(content=result.content, actual_dispatches=dispatch.await_count,
                            events=[x[0] for x in sink.delivered],
                            sentinel_exported=SENTINEL in json.dumps(sink.delivered))
    for api in ["typed_stream", "legacy_stream"]:
        sink = CaptureSink()
        stream = Stream()
        client = service(sink)
        with patch.object(litellm, "acompletion", AsyncMock(return_value=stream)):
            generator = (client.chat_completion_events(request) if api == "typed_stream"
                         else client.chat_completion_stream([{"role": "user", "content": SENTINEL}]))
            values = [value async for value in generator]
        results[api] = dict(delivered_count=len(values), events=[x[0] for x in sink.delivered],
                            chunks_read=stream.count, closed=stream.closed)
    for api in ["typed_stream", "legacy_stream"]:
        sink = CaptureSink()
        stream = Stream(fail=asyncio.CancelledError())
        client = service(sink)
        cancelled = False
        with patch.object(litellm, "acompletion", AsyncMock(return_value=stream)):
            generator = (client.chat_completion_events(request) if api == "typed_stream"
                         else client.chat_completion_stream([{"role": "user", "content": "safe"}]))
            try:
                async for _ in generator:
                    pass
            except asyncio.CancelledError:
                cancelled = True
        results[api + "_cancel"] = dict(cancelled=cancelled, closed=stream.closed,
                                       events=[x[0] for x in sink.delivered])
    sink = CaptureSink()
    embedding = LiteLLMEmbeddingService(model_name="text-embedding-3-small", telemetry=sink,
                                       resilience=ResilienceConfig.disabled())
    fake_embedding = NS(data=[NS(index=0, embedding=[1.0, 2.0])], usage=None)
    with patch.object(litellm, "aembedding", AsyncMock(return_value=fake_embedding)) as dispatch:
        await embedding.embed_documents([])
        await embedding.embed_query(SENTINEL)
        await embedding.embed_query(SENTINEL)
    results["embedding"] = dict(actual_dispatches=dispatch.await_count,
                                events=[x[0] for x in sink.delivered],
                                missing_usage_projected_zero=any(
                                    data.get("gen_ai.usage.input_tokens") == 0 for _, data in sink.delivered))
    client = service(FailingSink())
    with patch.object(litellm, "acompletion", AsyncMock(return_value=response)):
        try:
            await client.chat_completion([{"role": "user", "content": "safe"}])
        except RuntimeError as error:
            results["sink_failure"] = dict(replaced_application_result=error.args == ("sink-failure",))
    # Record default-service alias identity without creating memory/persistence.
    from friday_chat.adapters import _build_extraction_llm_service
    from friday_chat.config import FridayChatConfig
    config = FridayChatConfig.model_validate({"llm": {"model": "gpt-4"}})
    results["extraction_default_alias"] = _build_extraction_llm_service(config, client) is client
    results["mode"] = "true pre-build synthetic probes; patched dispatch; no SDK construction"
    sources = {
        str(Path(module.__file__).resolve()): hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
        for module in __import__("sys").modules.copy().values()
        if getattr(module, "__file__", None) and "/packages/" in module.__file__ and module.__file__.endswith(".py")
    }
    results["resolved_source_hashes"] = sources
    print(json.dumps(results, indent=2))


asyncio.run(main())
