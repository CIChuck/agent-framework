"""Sanitized tracked-snapshot TELEM-02 checks; never copies original runtime state."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

REPO = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT = Path('/private/tmp/telem-02/builder-execution')
PREFIX = 'packages/friday-telemetry/'
SOURCE = [PREFIX+'src/friday_telemetry/'+p for p in ['providers/otel.py', 'config.py', '__init__.py', 'lifecycle.py', 'factory.py', 'providers/_otel_processor.py', 'providers/_otel_exporter.py']]
TESTS = [PREFIX+'tests_telemetry/'+p for p in ['test_providers.py', 'test_mcp_telemetry.py', 'test_otel_contract.py', 'test_telemetry_factory.py', 'test_otlp_collector.py']]
PRODUCT = SOURCE + TESTS + [PREFIX+'README.md']
spec = importlib.util.spec_from_file_location('baseline_prepare', '/private/tmp/telem-02/builder-baseline/prepare.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.OUT = OUT

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def prepare(name, revision):
    root, receipt = helper.prepare(name, revision)
    audit = OUT / 'pytest_source_audit.py'
    if audit.exists():
        (root/'pytest_source_audit.py').write_bytes(audit.read_bytes())
        receipt['private_execution_helpers'] = {'pytest_source_audit.py': helper.sha(audit.read_bytes())}
        save(name+'-snapshot.json', receipt)
    for lane in ['active', 'queued', 'review', 'blocked', 'deferred', 'backlog']:
        (root / 'docs/planning' / lane).mkdir(exist_ok=True)
    return root

def overlay(name, revision):
    root = prepare(name, revision)
    receipt = json.loads((OUT/(name+'-snapshot.json')).read_text())
    receipt['tracked_before_overlay'] = dict(receipt['tracked_hashes'])
    receipt['overlay'] = []
    for path in PRODUCT:
        source = REPO / path
        target = root / path
        if not target.exists() or target.read_bytes() != source.read_bytes():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
            receipt['overlay'].append(path)
        receipt['tracked_hashes'][path] = helper.sha(target.read_bytes())
    save(name+'-snapshot.json', receipt)
    return root

def run(name, label, arguments, timeout=600):
    root = OUT / name
    receipt = json.loads((OUT / (name + '-snapshot.json')).read_text())
    if any(helper.sha((root / p).read_bytes()) != h for p, h in receipt['tracked_hashes'].items()):
        raise RuntimeError('Tracked source drift before check')
    env = helper.environment(root, label)
    env['PYTEST_ADDOPTS'] = '-o cache_dir=' + env['TMPDIR'] + '/pytest'
    if arguments and arguments[0] == 'pytest':
        arguments = arguments + ['-p', 'pytest_source_audit', '--source-audit-output='+str(OUT/(label+'-source-audit.json'))]
    command = (['/opt/homebrew/bin/uv'] + arguments[1:]
               if arguments and arguments[0] == 'uv'
               else ['/opt/homebrew/bin/uv', 'run', '--no-sync'] + arguments)
    log = OUT / (label + '.log')
    if log.exists():
        raise RuntimeError('Retain earlier run; choose new label')
    start = time.time()
    with log.open('wb') as stream:
        result = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
    unchanged = all(helper.sha((root / p).read_bytes()) == h for p, h in receipt['tracked_hashes'].items())
    save(label + '-receipt.json', dict(command=command, cwd=str(root), revision=receipt['revision'], environment=env, started_epoch=start, finished_epoch=time.time(), seconds=time.time()-start, exit_code=result.returncode, tracked_unchanged=unchanged, log_sha256=helper.sha(log.read_bytes()), snapshot_sha256=helper.sha((OUT/(name+'-snapshot.json')).read_bytes())))
    print(label, result.returncode, str(log), flush=True)
    print(log.read_text()[-3000:], flush=True)
    if not unchanged:
        raise RuntimeError('Tracked source drift after check')
    return result.returncode

if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == 'prepare-overlay':
        overlay(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == 'run':
        sys.exit(run(sys.argv[2], sys.argv[3], sys.argv[4:]))
