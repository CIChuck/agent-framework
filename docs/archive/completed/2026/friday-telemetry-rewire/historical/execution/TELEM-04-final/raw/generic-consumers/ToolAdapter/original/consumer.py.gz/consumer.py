from boundary import ToolAdapter
class Parent:pass
class Child(Parent):pass
def assignments(parent: ToolAdapter[Parent], child: ToolAdapter[Child]) -> None:
 parent = child
 child = parent
