from pathlib import Path
import ast,hashlib,importlib.util,json,subprocess,time
repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');out=Path('/private/tmp/telem-04/construction');root=out/'frozen-candidate'
spec=importlib.util.spec_from_file_location('prep','/private/tmp/telem-02/builder-baseline/prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.OUT=out
sha=lambda b:hashlib.sha256(b).hexdigest()
classes=[('packages/friday-cli/src/friday_cli/commands.py','CommandRegistry'),('packages/friday-cli/src/friday_cli/session.py','SessionContext'),('packages/friday-cli/src/friday_cli/session.py','SessionManager'),('packages/friday-core/src/friday_core/interfaces/tools.py','ToolAdapter'),('packages/friday-moltbook/src/friday_moltbook/responses.py','MoltbookResponse'),('packages/friday-chat/src/friday_chat/memory_views.py','MemoryMetric')]
results={}
for rel,name in classes:
    result={}
    for label,revision in [('original','2155a0fc51f5b20dea4e35c6cfc70f1d52002735'),('candidate','1547fae7cac6450ec9ad7440f19d1f1162598fe2')]:
        data=subprocess.check_output(['git','-C',str(repo),'show',revision+':'+rel]);tree=ast.parse(data);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)
        folder=out/'generic-consumers'/name/label;folder.mkdir(parents=True,exist_ok=False)
        (folder/'boundary.py').write_bytes(data)
        consumer=f'from boundary import {name}\nclass Parent:pass\nclass Child(Parent):pass\ndef assignments(parent: {name}[Parent], child: {name}[Child]) -> None:\n parent = child\n child = parent\n'
        (folder/'consumer.py').write_text(consumer)
        command=['/opt/homebrew/bin/uv','run','--no-sync','--offline','--no-python-downloads','mypy','--python-version','3.13','--follow-imports=silent','consumer.py'];env=h.environment(root,'generic-'+name+'-'+label);start=time.time();run=subprocess.run(command,cwd=folder,env=env,capture_output=True,timeout=120)
        log=out/('generic-'+name+'-'+label+'.stdout');log.write_bytes(run.stdout);(out/('generic-'+name+'-'+label+'.stderr')).write_bytes(run.stderr)
        receipt={'command':command,'cwd':str(folder),'revision':revision,'environment':env,'started_epoch':start,'seconds':time.time()-start,'exit_code':run.returncode,'source_path':rel,'source_sha256':sha(data),'class_ast_sha256':sha(ast.dump(cls,include_attributes=False).encode()),'consumer_sha256':sha(consumer.encode()),'stdout_sha256':sha(run.stdout),'stderr_sha256':sha(run.stderr)}
        (out/('generic-'+name+'-'+label+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
        result[label]={'exit':run.returncode,'assignment_diagnostics':[line for line in run.stdout.decode().splitlines() if 'consumer.py:' in line]}
    result['same_consumer_diagnostics']=result['original']['assignment_diagnostics']==result['candidate']['assignment_diagnostics']
    if not result['same_consumer_diagnostics'] or len(result['candidate']['assignment_diagnostics'])!=2:raise RuntimeError('Generic variance regression '+name)
    results[name]=result
(out/'generic-consumer-results.json').write_text(json.dumps(results,indent=2)+'\n')
print('Six actual generic Parent/Child consumers preserve both invariant assignment errors')
