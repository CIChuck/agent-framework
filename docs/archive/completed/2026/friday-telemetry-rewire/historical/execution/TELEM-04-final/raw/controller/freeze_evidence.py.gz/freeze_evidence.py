from pathlib import Path
import gzip,hashlib,json
repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');out=Path('/private/tmp/telem-04/construction');dest=repo/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-04-final';dest.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest();records=[]
def copy(source,relative):
    data=source.read_bytes();compressed=gzip.compress(data,mtime=0);target=dest/'raw'/relative;target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() and target.read_bytes()!=compressed:raise RuntimeError('Frozen artifact overwrite '+str(target))
    target.write_bytes(compressed);records.append({'original':str(source),'stored':str(target.relative_to(dest)),'original_sha256':sha(data),'stored_sha256':sha(compressed),'bytes':len(data)})
for source in sorted(p for p in out.iterdir() if p.is_file()):copy(source,Path('controller')/(source.name+'.gz'))
paths=json.loads((out/'actual-product-paths.json').read_text())
for name in ['iteration-01','iteration-02','iteration-03','iteration-04','review-prep','frozen-candidate']:
    for p in paths:
        source=out/name/p
        if source.exists():copy(source,Path(name)/'sources'/(p+'.gz'))
for source in sorted((out/'generic-consumers').rglob('*')):
    if source.is_file() and source.name in ['boundary.py','consumer.py']:copy(source,Path('generic-consumers')/(str(source.relative_to(out/'generic-consumers'))+'.gz'))
candidate=json.loads((out/'candidate.json').read_text())['candidate'];manifest=json.loads((repo/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-04.yaml').read_text())
(dest/'artifact-manifest.json').write_text(json.dumps({'candidate':candidate,'unit_base':manifest['base'],'aggregate_base':manifest['aggregate_base'],'mode':'builder evidence only; independent verdict and maintainer acceptance separate','gzip_mtime':0,'artifacts':records},indent=2)+'\n')
print('Builder artifacts frozen',len(records))
