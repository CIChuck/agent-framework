"""Bounded mechanical indentation of existing await/try bodies; no AST regeneration."""
from pathlib import Path
r=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
def wrap(text,start,end,header):
 a=text.index(start);b=text.index(end,a);body=text[a:b]
 return text[:a]+header+'\n'+''.join('    '+line if line.strip() else line for line in body.splitlines(keepends=True))+text[b:]
p=r/'packages/friday-chat/src/friday_chat/turns/processor.py';s=p.read_text()
s=wrap(s,'        memories = await self._runtime.memory.retrieve(','        retrieval_seconds =', '        with operation_scope(self._runtime.telemetry, "memory_retrieve") as observation:')
s=s.replace('        retrieval_seconds = elapsed_seconds(retrieval_start)','            observation.count = len(memories)\n            observation.count_kind = "items"\n        retrieval_seconds = elapsed_seconds(retrieval_start)')
s=wrap(s,'                async for chunk in self._runtime.chat_llm.stream_complete(','            finally:', '                with operation_scope(self._runtime.telemetry, "model_call"):')
s=wrap(s,'                timeout = self._runtime.config.llm.timeout_seconds','            except TimeoutError as exc:', '                with operation_scope(self._runtime.telemetry, "model_call"):')
s=s.replace('            heartbeat_factory=self._heartbeat_factory,\n        )\n        try:\n            tool_result', '            heartbeat_factory=self._heartbeat_factory,\n            observer=self._runtime.telemetry,\n        )\n        try:\n            tool_result')
s=wrap(s,'            await self._runtime.memory.store_turn(user_message, assistant_message)','            metrics = TurnMetrics(', '            with operation_scope(self._runtime.telemetry, "persistence"):') if False else s
# Whole persistence try body is observed, preserving the original exception/rollback layer.
s=wrap(s,'            await self._runtime.memory.store_turn(user_message, assistant_message)','        except Exception as exc:', '            with operation_scope(self._runtime.telemetry, "persistence") as persistence:')
s=s.replace('                await self._runtime.memory.store_turn(user_message, assistant_message)','                with operation_scope(self._runtime.telemetry, "memory_store_turn"):\n                    await self._runtime.memory.store_turn(user_message, assistant_message)')
s=s.replace('                await self._runtime.transcript.record_turn(user_message, assistant_message)','                with operation_scope(self._runtime.telemetry, "transcript_record_turn"):\n                    await self._runtime.transcript.record_turn(user_message, assistant_message)')
s=wrap(s,'                    await self._runtime.transcript.record_context_log(','                metrics = TurnMetrics(', '                    with operation_scope(self._runtime.telemetry, "transcript_context_log"):')
s=wrap(s,'                tool_calls = await persist_mcp_interaction(','        except Exception as exc:', '                with operation_scope(self._runtime.telemetry, "transcript_interaction"):')
# Completed here means the existing full coordination returned, not an atomic store commit.
s=s.replace('        except Exception as exc:\n            _rollback_fake_memory_turn(', '                persistence.persistence_state = "completed"\n        except Exception as exc:\n            _rollback_fake_memory_turn(')
# Safe selection snapshot is delivered only through the observer's strict dynamic entry.
anchor='        mcp_tool_names = frozenset(self._mcp_names())'
selection='''        observer = self._runtime.telemetry
        frame = observer.correlation.current() if observer is not None else None
        if observer is not None and frame is not None:
            mcp_names = self._mcp_names()
            fields = {
                **frame.context.identity().model_dump(), "toolset_ref": uuid4().hex,
                "selected_native": sum(t.name not in mcp_names for t in tool_definitions),
                "selected_mcp": sum(t.name in mcp_names for t in tool_definitions),
                "rejected_native": sum(t.name not in mcp_names for t in selection.budget.rejections),
                "rejected_mcp": sum(t.name in mcp_names for t in selection.budget.rejections),
                "schema_tokens": selection.budget.schema_tokens, "context_budget_tokens": context_budget_tokens,
            }
            observer.capture_event("execution.selection", fields)
            for reason in ToolRejectionReason:
                count = sum(rejection.reason == reason for rejection in selection.budget.rejections)
                if count:
                    observer.capture_event("execution.selection", {**fields, "rejection_reason": reason.value, "rejection_count": count})
'''
s=s.replace(anchor,selection+'\n'+anchor)
anchor='            response = await self._complete_with_retries(\n                messages,'
reasoning='''            observer = self._runtime.telemetry
            frame = observer.correlation.current() if observer is not None else None
            if observer is not None and frame is not None:
                present = isinstance(response.reasoning_content, str) and bool(response.reasoning_content)
                observer.capture_event("execution.reasoning_history", {
                    **frame.context.identity().model_dump(), "iteration": _iteration + 1,
                    "present": present,
                    "preserved": present and assistant_message.get("reasoning_content") == response.reasoning_content,
                    "eligible": not any(call.name in mcp_names for call in response.tool_calls),
                    "message_count": len(messages),
                })
'''
s=s.replace(anchor,reasoning+anchor)
# A failed selection records the categorical rejection without fabricated selected entries.
s=s.replace('        except ToolSelectionError as exc:\n            bridge', '''        except ToolSelectionError as exc:
            observer = self._runtime.telemetry
            frame = observer.correlation.current() if observer is not None else None
            if observer is not None and frame is not None:
                observer.capture_event("execution.selection", {
                    **frame.context.identity().model_dump(), "toolset_ref": uuid4().hex,
                    "selected_native": 0, "selected_mcp": 0, "rejected_native": 0,
                    "rejected_mcp": 0, "schema_tokens": 0, "context_budget_tokens": 0,
                    "rejection_reason": exc.reason.value, "rejection_count": len(exc.names),
                })
            bridge''')
p.write_text(s)
p=r/'packages/friday-chat/src/friday_chat/tools/loop.py';s=p.read_text()
s=wrap(s,'                        raw_id = call.get("id")','                    except KeyError:', '                        with operation_scope(self._observer, "mcp_tool" if name in mcp_names else "native_tool") as observation:')
anchor='                    except KeyError:'
finish='''                            if name in mcp_names and record.mcp_provenance is not None:
                                facts = record.mcp_provenance
                                if facts.status != "succeeded":
                                    observation.outcome = "blocked" if facts.status == "blocked" else "failed"
                                    observation.reason = facts.failure_code or "execution_error"
                            observation.count = 1
                            observation.count_kind = "calls"
'''
s=s.replace(anchor,finish+anchor)
# Rejection does not count as an executed tool operation.
s=s.replace('                    if not isinstance(name, str) or name not in allowed:\n                        consecutive_failures', '''                    if not isinstance(name, str) or name not in allowed:
                        if self._observer is not None:
                            frame = self._observer.correlation.current()
                            if frame is not None:
                                self._observer.capture_event("execution.selection", {
                                    **frame.context.identity().model_dump(), "toolset_ref": __import__("uuid").uuid4().hex,
                                    "selected_native": 0, "selected_mcp": 0, "rejected_native": 1,
                                    "rejected_mcp": 0, "schema_tokens": 0, "context_budget_tokens": 0,
                                    "rejection_reason": "unknown_tool", "rejection_count": 1,
                                })
                        consecutive_failures''')
p.write_text(s)
print('Existing turn/tool bodies instrumented; algorithms retained')
