from boundary import SessionManager
class Parent:pass
class Child(Parent):pass
def assignments(parent: SessionManager[Parent], child: SessionManager[Child]) -> None:
 parent = child
 child = parent
