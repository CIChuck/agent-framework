import asyncio,json,sys,threading
from pathlib import Path
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import build_runtime,FakeTranscriptStore,FakeChatModel,PendingExtractionTurn
from friday_chat.turns.processor import TurnProcessor,TurnPersistenceError,TurnCircuitBreakerOpenError
from friday_chat.turns.models import ChatModelResponse,ToolCallRequest
from friday_chat.tools.loop import ToolLoop
from friday_chat.tools.registry import FakeToolRegistry
from friday_chat.tools.schemas import ToolDefinition
from friday_chat.tools.output import MCPOutputPolicy
from friday_chat.adapters import FrameworkMaintenanceAdapter
from friday_core.mcp import MCPToolMetadata
from friday_memory import ExtractionCommitCompletedUnderCancellation

records=[]
def config(tools=False):return FridayChatConfig.model_validate({'llm':{'model':'fake/test'},'tools':{'enabled':tools},'telemetry':{'enabled':True}})
def record(case,runtime,**data):
 names=[e.name for e in runtime.telemetry.snapshot().events]
 if any(n.startswith('execution.') for n in names):raise RuntimeError('Baseline unexpectedly instrumented')
 records.append(dict(case=case,event_names=names,**data))
class BrokenTranscript(FakeTranscriptStore):
 async def record_turn(self,*args):raise OSError('sentinel')
class CancelTranscript(FakeTranscriptStore):
 async def record_turn(self,*args):raise asyncio.CancelledError()
class Recorder(FakeToolRegistry):
 def is_mcp_tool(self,name):return name=='mcp_peer_private'
 async def call_tool_record(self,name,arguments,**kwargs):
  m=MCPToolMetadata(canonical_name=name,server_name='peer',original_name='private',transport='stdio',trust_level='local')
  policy=MCPOutputPolicy(4096)
  return policy.failed_record(m,'safe_call','tool_error')
async def main():
 for streaming in [False,True]:
  r=build_runtime(config());processor=TurnProcessor(r);chunks=[]
  async def capture(chunk):chunks.append(chunk)
  result=await processor.process_streaming('safe',on_chunk=capture) if streaming else await processor.process('safe')
  record('stream' if streaming else 'completion',r,result=result.assistant_message,context_present=hasattr(result,'correlation_context'),chunks=chunks)
 for store,label,error in [(BrokenTranscript(),'persist_failure',TurnPersistenceError),(CancelTranscript(),'persist_cancel',asyncio.CancelledError)]:
  r=build_runtime(config());r.transcript=store
  try:await TurnProcessor(r).process('safe')
  except error:record(label,r,memory_turn_count=len(r.memory.stored_turns))
  else:raise RuntimeError('Expected persistence failure')
 r=build_runtime(config())
 try:await TurnProcessor(r,circuit_breaker_open=True).process('safe')
 except TurnCircuitBreakerOpenError:record('circuit_block',r)
 r=build_runtime(config(True));r.chat_llm=FakeChatModel('fake',responses=[ChatModelResponse(tool_calls=(ToolCallRequest('echo',{'text':'safe'},'raw-call'),),reasoning_content='reasoning_sentinel'),ChatModelResponse.from_text('done')])
 result=await TurnProcessor(r).process('use echo')
 record('native_followup',r,tool_count=len(result.tool_calls),reasoning_preserved=any(m.get('reasoning_content')=='reasoning_sentinel' for m in r.chat_llm.calls[-1]))
 loop=ToolLoop(Recorder([ToolDefinition('mcp_peer_private','safe')]))
 result=await loop.run([{'tool_calls':[{'name':'mcp_peer_private','arguments':{},'id':'safe_call'}]}],[ToolDefinition('mcp_peer_private','safe')])
 if result.tool_calls[0].mcp_provenance.status!='failed':raise RuntimeError('MCP failed return changed')
 records.append(dict(case='mcp_failed_record',tool_count=len(result.tool_calls),status=result.tool_calls[0].mcp_provenance.status))
 for mode in ['success','failure','cancel','committed_cancel','none']:
  seen=[]
  class Extractor:
   async def extract(self,turn):
    seen.append(turn.id)
    if len(seen)==1:
     if mode=='failure':raise RuntimeError('sentinel')
     if mode=='cancel':raise asyncio.CancelledError()
     if mode=='committed_cancel':raise ExtractionCommitCompletedUnderCancellation()
    return {}
  a=FrameworkMaintenanceAdapter(config(), 'private', None,None,None,{}, {},extractor=None if mode=='none' else Extractor())
  a.pending_extraction=[PendingExtractionTurn('item1','u','a'),PendingExtractionTurn('item2','u2','a2')]
  try:await a.extract_buffered_turns(trigger_reason='baseline')
  except BaseException as e:
   if not isinstance(e,(RuntimeError,asyncio.CancelledError)):raise
  records.append(dict(case='extraction_'+mode,seen=seen,requeued=[t.turn_id for t in a.pending_extraction],context_present=hasattr(PendingExtractionTurn('x','u','a'),'correlation_context')))
 forbidden=[t.name for t in threading.enumerate() if t.name=='FridayTelemetryExporter' or t.name.startswith('SyntheticOTLP')]
 if forbidden:raise RuntimeError('Worker activation')
 Path(sys.argv[1]).write_text(json.dumps(dict(records=records,owned_workers_remaining=forbidden,sdk_activated=False),indent=2)+'\n')
 print('BASELINE:',len(records),'fake behavior cases; no execution events/context; no SDK/provider/listener construction')
asyncio.run(main())
