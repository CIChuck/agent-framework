import run,json
run.run('baseline-sdk_probe',['python',str(run.OUT/'sdk_probe.py')],run.OUT/'frozen-baseline')
r=json.loads((run.OUT/'baseline-sdk_probe.stdout').read_text())
m=json.loads((run.OUT/'baseline-findings.json').read_text())
m['findings']['F01']={'reproduced':any(x['issue']=='background_sdk_span_inherits_foreground' for x in r['issues']),'issue_count':len(r['issues']),'all_owned_resources_closed':r['exporter_closed'] and r['all_chat_spans_closed'] and r['all_debug_spans_closed'] and not r['workers_remaining'],'global_unchanged':r['global_unchanged']}
run.h.save('baseline-findings.json',m)
print(m)
