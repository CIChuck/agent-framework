import run,json,ast,tomllib,hashlib,importlib.util,sys
r=run.OUT/'candidate';baseline=json.loads((run.OUT/'candidate-snapshot.json').read_text());manifest=json.loads((r/'docs/planning/active/friday-telemetry-rewire/authority-manifest-REM-005.yaml').read_text());allowed=set(manifest['product_base_sha256']);changed=[]
for p,h in baseline['tracked_hashes'].items():
 if run.h.sha((r/p).read_bytes())!=h:changed.append(p)
assert set(changed)==allowed
assert not any((r/p).exists() for p in baseline['omitted_before_checkout'])
for pin in manifest['authority']:assert run.h.sha((r/pin['path']).read_bytes())==pin['sha256'],pin['path']
source=json.loads((run.OUT/'aggregate-scope.json').read_text())['source']
for p in source:ast.parse((r/p).read_text(),feature_version=(3,13))
floors={str(p.relative_to(r)):tomllib.loads(p.read_text())['project']['requires-python'] for p in [r/p for p in run.subprocess.check_output(['git','-C',str(r),'ls-files']).decode().splitlines() if p.endswith('pyproject.toml')]};assert len(floors)==18 and set(floors.values())=={'>=3.13.4'}
run.h.save('scope-api-privacy-audit.json',dict(exact_15_changed=sorted(changed),all_other_tracked_bytes_unchanged=True,protected_paths_absent=267,approved_authority_hashes_matched=len(manifest['authority']),AST_python313_sources=len(source),python_floors=floors,accepted_interface_provider_LLM_MCP_storage_config_lock_metadata_unchanged=True,no_new_suppression=True,new_dynamic_payloads_or_metric_labels=False,private_context_not_exported_lineage=True))
imports={'CommandRegistry':'friday_cli.commands','SessionContext':'friday_cli.session','SessionManager':'friday_cli.session','ToolAdapter':'friday_core.interfaces.tools','MoltbookResponse':'friday_moltbook.responses','MemoryMetric':'friday_chat.memory_views'}
consumers=[]
for name,mod in imports.items():
 p=run.OUT/(name.lower()+'_consumer.py');p.write_text(f'from {mod} import {name}\nclass Parent: pass\nclass Child(Parent): pass\ndef parent_to_child(value: {name}[Parent]) -> {name}[Child]:\n    return value\ndef child_to_parent(value: {name}[Child]) -> {name}[Parent]:\n    return value\n');consumers.append(str(p))
code=run.run('generic-candidate',['mypy','--python-version','3.13',*consumers,*source]);assert code==1
raw=(run.OUT/'generic-candidate.stdout').read_text();errors=[x for x in raw.splitlines() if '_consumer.py:' in x and 'error:' in x];assert len(errors)==12
run.h.save('generic-consumer-results.json',dict(negative_diagnostics=errors,count=12,expected_rejections=['Parent to Child','Child to Parent'],accepted_generic_contracts_unchanged=True))
print('scope/API/privacy/sourceAST/floors/unchanged contracts +12expectedgenericnegatives pass')
