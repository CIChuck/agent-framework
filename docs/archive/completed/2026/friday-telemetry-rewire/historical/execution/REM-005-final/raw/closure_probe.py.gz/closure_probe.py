import asyncio,json
from friday_chat.runtime import build_runtime
from friday_chat.config import FridayChatConfig
from friday_chat.turns.processor import TurnProcessor
async def main():
 r=build_runtime(FridayChatConfig.model_validate({'llm':{'model':'fake/test'},'tools':{'enabled':False},'telemetry':{'enabled':True}}));closed=[];error=RuntimeError('PRIVATE_PRIMARY')
 class Model:
  def __init__(self):self.iterator=None
  def stream_complete(self,*args,**kwargs):
   async def gen():
    try:yield 'first';yield 'second'
    finally:closed.append(True)
   self.iterator=gen();return self.iterator
 m=Model();r.chat_llm=m
 async def callback(chunk):raise error
 try:await TurnProcessor(r).process_streaming('PRIVATE',on_chunk=callback)
 except RuntimeError as raised:assert raised is error
 await asyncio.sleep(0)
 print(json.dumps(dict(model_iterator_closed_before_return=bool(closed),primary_preserved=True)))
 await m.iterator.aclose()
asyncio.run(main())
