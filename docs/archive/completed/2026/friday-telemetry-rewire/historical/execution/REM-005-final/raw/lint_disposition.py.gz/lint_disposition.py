from pathlib import Path
import ast,hashlib,json,sys,tomllib
out=Path('/private/tmp/telem-04/REM-005/builder');root=out/sys.argv[1];label=sys.argv[2];raw=out/(sys.argv[3]+'.stdout')
l=json.loads((root/'docs/planning/active/friday-telemetry-rewire/validation/WVR-006-telem04-lint-scope.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
diagnostics=json.loads(raw.read_text())
normalized=[dict(path=str(Path(d['filename']).relative_to(root)),code=d['code'],location=d['location'],end_location=d['end_location'],message=d['message']) for d in diagnostics]
key=lambda d:(d['path'],d['code'],d['location']['row'],d['location']['column'],d['end_location']['row'],d['end_location']['column'],d['message'])
if sorted(normalized,key=key)!=sorted(l['diagnostics'],key=key) or len(normalized)!=327:raise RuntimeError('Lint identity drift')
for collection in ['archived_files','lint_configurations']:
    for p,digest in l[collection].items():
        if sha(root/p)!=digest:raise RuntimeError('Pinned lint input drift '+p)
reg=next(d['path'] for d in l['diagnostics'] if not d['path'].startswith('docs/'))
cls=next(n for n in ast.parse((root/reg).read_bytes()).body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry')
if sha(root/reg)!=l['command_registry_source_sha256'] or hashlib.sha256(ast.dump(cls,include_attributes=False).encode()).hexdigest()!=l['command_registry_class_ast_sha256']:raise RuntimeError('Registry drift')
if tomllib.loads((root/'pyproject.toml').read_text())['tool']['ruff']['target-version']!='py313':raise RuntimeError('Target drift')
(out/(label+'-lint-disposition.json')).write_text(json.dumps({'raw_exit':1,'count':327,'exact_identities':True,'archive_count':326,'live_count':1,'new_findings':[],'approved_waiver':'WVR-006','expiry':'TELEM-04 acceptance or input drift','archive_registry_config_hashes_match':True,'identities':normalized},indent=2)+'\n')
print('WVR-006 EXACT327 reconciliation PASS; raw root Ruff remains exit1')
