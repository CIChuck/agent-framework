import run,json,datetime,hashlib,re
from pathlib import Path
out=run.OUT;r=out/'candidate';product=json.loads((out/'final-product-manifest-v2.json').read_text());sha=run.h.sha
for p,h in product['files'].items():assert sha((r/p).read_bytes())==h,p
labels=['focused-final-r2','test-chat-llm-telemetry-r3','test-root-collect-r3','test-root-r3','test-owning-r3','ruff-rem-r2','ruff-unit-r2','ruff-aggregate-r2','ruff-root-r2','mypy-unit-r2','mypy-aggregate-r2','offline-lock-r2','docs-r2','board-validate-final-r2','board-next-final-r2','board-show-final-r2','board-render-final-r2','committed-diff-rem','committed-diff-unit','committed-diff-aggregate','generic-candidate-r2','lint-final-r2','resolution-final']
checks=[]
for label in labels:
 rec=json.loads((out/(label+'-receipt.json')).read_text());expected=1 if label in {'ruff-root-r2','generic-candidate-r2'} else 0
 assert rec['exit_code']==expected,(label,rec['exit_code'])
 assert sha((out/(label+'.stdout')).read_bytes())==rec['stdout_sha256']
 assert sha((out/(label+'.stderr')).read_bytes())==rec['stderr_sha256']
 if 'product_sha256' in rec and label != 'resolution-final':assert rec['product_sha256']==product['files'],label
 elif 'source_sha256' in rec and label != 'resolution-final':
  assert all(rec['source_sha256'].get(p)==h for p,h in product['files'].items() if '/src/' in p),label
 checks.append(dict(label=label,command=rec['command'],exit_code=rec['exit_code'],stdout_summary=(out/(label+'.stdout')).read_text().splitlines()[-1] if (out/(label+'.stdout')).stat().st_size else '',receipt=label+'-receipt.json'))
fixtures=json.loads((r/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-04-planning/listener-scope.json').read_text())
roottext=(out/'test-root-r3.stdout').read_text()
for n in fixtures['existing_nodes']:assert 'PASSED '+n in roottext,n
skip="SKIPPED [1] packages/friday-memory/tests_memory/test_adapters/test_graph.py:250: could not import 'scipy': No module named 'scipy'"
for label in ['focused-final-r2','test-chat-llm-telemetry-r3','test-root-r3','test-owning-r3']:
 text=(out/(label+'.stdout')).read_text();skips=[x for x in text.splitlines() if x.startswith('SKIPPED')];assert skips==([skip] if label in {'test-root-r3','test-owning-r3'} else [])
follow=[]
for name in ['fake_probe','tools_reasoning_probe','closure_probe','schema_probe','sdk_probe']:
 label='followup-'+name+'-r3';rec=json.loads((out/(label+'-receipt.json')).read_text());assert rec['exit_code']==0 and rec['product_before_after_stable'] and rec['product_after_sha256']==product['files'],label
 data=json.loads((out/(label+'.stdout')).read_text())
 if name in ['fake_probe','tools_reasoning_probe','sdk_probe']:assert not data['issues']
 if name=='closure_probe':assert data['model_iterator_closed_before_return'] and data['primary_preserved']
 if name=='schema_probe':assert all(not row['counter_after_invalid_input'] and row['rejected_after_invalid_input']==1 and not row['delivered_finish'] for row in data)
 if name=='sdk_probe':
  assert data['global_unchanged'] and data['exporter_closed'] and not data['workers_remaining']
  assert all(data[x] for x in ['all_chat_spans_closed','all_composite_spans_closed','all_debug_spans_closed','correlation_restored','active_foreground_restored','provider_still_owned_and_open','safe_events'])
  assert 'PRIVATE' not in repr(data['sdk_spans'])
 follow.append(dict(probe=name,receipt=label+'-receipt.json',exit_code=0,findings_repaired=True))
initial=json.loads((out/'candidate-snapshot.json').read_text());changed=[p for p,h in initial['tracked_hashes'].items() if sha((r/p).read_bytes())!=h];assert set(changed)==set(product['files']);assert not any((r/p).exists() for p in initial['omitted_before_checkout'])
run.h.save('final-reconciliation.json',dict(candidate='5c3a0e6dc8ba995bad9e7dfb8c574f5dfd335bc8',finished_utc=datetime.datetime.now(datetime.UTC).isoformat(),authority_commit=product['authority_commit'],product_manifest='final-product-manifest-v2.json',product_hashes=product['files'],exact15_overlay_stable=True,all_other_tracked_bytes_unchanged=True,protected_paths_absent_count=267,scope_counts={n:len(json.loads((out/(n+'-scope.json')).read_text())['source']) for n in ['unit','aggregate']},required_checks=checks,original_finding_followups=follow,approved_existing_loopback_nodes_ran=fixtures['existing_nodes'],only_skip=skip,snapshots_excluded=['candidate/','frozen-baseline/','unit-base/'],builder_result='Completed builder verification; independent VAL-010 pending, no VERIFIED/acceptance/delivery claim'))
report='''# REM-005 architectural remediator builder report

Builder: separate Codex architectural remediator `/root/rem005_remediator`, GPT-6 based; exact runtime model identifier unavailable. This is builder evidence, not independent VERIFIED, completion, acceptance or delivery authority.

Approved authority `3e07707d13f1db7c023d660d721e0b817661bdad`; frozen failing product `1547fae7cac6450ec9ad7440f19d1f1162598fe2`; controller committed final candidate `5c3a0e6dc8ba995bad9e7dfb8c574f5dfd335bc8`. Final15-file source manifest is [final-product-manifest-v2.json](final-product-manifest-v2.json), SHA8d3de24c11b126656b6de6cecad8754c8c2aa53d11188127695df5aa386b1497. Private candidate source is frozen. Root alone copied/staged/committed original-worktree product bytes; builder made no original worktree/index/HEAD/governance mutation. Root's authorized governance changes run concurrently and are outside the builder preservation assertion.

All five original findings were reproduced before product writes in a fresh actual1547fae tracked checkout. Hash-exact original probes were copied from original VAL-009 manifest. SDK F01 baseline ran only after readiness effect release. F04 additionally reproduced at actual unit basee6209e3, proving inherited closure gap. [baseline-findings.json](baseline-findings.json), baseline raw stdout/stderr/receipts, source snapshots and [preparation-audit.json](preparation-audit.json) retain evidence. Independent CDR-020 cleared authority/effects/lint; controller then explicitly released construction. Audited helper SHAcd3963d50f55b5c2c18f2cf83f38a1ac4e13cb9bfc8ae3b3e31522d8492a9586 and guard SHA6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81 were recovered exactly; original missing-path reads are disclosed. Each snapshot excludes267 protected paths before checkout. Installed Python3.13.10/Ruff0.14.10/Mypy1.19.1/Pytest9.0.2/OTel1.39.1, private caches and credential-free offline/no-sync environment are recorded; no provisioning or original runtime state was used.

| Finding | Final behavior | Evidence |
| --- | --- | --- |
| F01 | Private active-frame Context roots/copies isolate synchronous sink start/event/end; owned active parents remain explicit; close occurs in binding before reset. | ContextVar fakes, composite nested/siblings, preemption/resume/post-close/shutdown tests; original SDK followup-r3 zero issues, closed owned resources, unchanged global provider and borrowed ownership |
| F02 | Omitted origin inherits ordinarily; explicit None detaches to session-only. Every extraction item detaches/rebinds its origin and preserves object identity/order/requeue/accounting. Malformed/foreign origins retain diagnosis. | Mixed valid/None foreground batches, retry/no-extractor/empty, actual coordinator preemption/resume/shutdown and malformed-origin privacy tests; original fake followup-r3 zero issues |
| F03 | Rejection counts use already computed trusted MCP membership, with unchanged control flow and zero rejected dispatches. | Mixed MCP/native/unknown/malformed rejection regression verifies exact counts/no extra lookups; original tools followup-r3 zero issues |
| F04 | Declared typed optional closure capability awaits acquired actual iterators through processor and both adapter paths, preserving active primary exceptions including cleanup error/cancellation. | Strongly retained direct/legacy/typed iterators through36 completion/failure/cancellation/cleanup combinations and6 public early-close cases; original closure followup-r3 closed-before-return=true/primary=true |
| F05 | Actual integer1 required before normalization; execution union revalidates forged root models. No rejected record/sink/metric contribution. | Bool/float/string/wrong integer/model/forgedRootModel observer negatives; default/exact1 positives; original schema followup-r3 rejected count1/no sink or metrics for each invalid input |

Only the seven sources, six regression modules and two package READMEs in approved15-path manifest changed. Exact paths/hashes are in final-product-manifest-v2.json. ExecutionContext/TurnResult/model complete and aggregation ASTs remain unchanged. All other tracked bytes, accepted interface/providers/LLM/MCP/storage/config/dependencies/lock/defaults and metadata stay fixed. No new suppression, task, listener, SDK registration, raw payload or dynamic metric label was added. [scope-api-privacy-audit.json](scope-api-privacy-audit.json), [final-source-audit.json](final-source-audit.json), source resolution/tool hashes and exact lint disposition provide checks.

Final byte-stable gates:

| Gate | Result | Receipt |
| --- | --- | --- |
| Six exact regression modules |132 passed,0 skipped |focused-final-r2-receipt.json |
| Chat/LLM/Telemetry |1247 passed,0 skipped,5 warnings |test-chat-llm-telemetry-r3-receipt.json |
| Root collection |3129 collected |test-root-collect-r3-receipt.json |
| Root full suite |3128 passed,1 existing optional SciPy skip,15 warnings |test-root-r3-receipt.json |
|13 aggregate owning trees |3110 passed,same1 SciPy skip,15 warnings |test-owning-r3-receipt.json |
| Exact REM/unit19/aggregate133 Ruff |exit0 |ruff-rem-r2/ruff-unit-r2/ruff-aggregate-r2-receipt.json |
| Raw root Ruff |genuine exit1,exact327 WVR-006 identities and pinned inputs |ruff-root-r2-receipt.json;final-v2-lint-disposition.json |
| Genuine changed-source Mypy |unit12/aggregate81 source files,exit0 |mypy-unit-r2/mypy-aggregate-r2-receipt.json |
| Public generic consumers |12 expected Parent→Child/Child→Parent invariant rejections; no extra source diagnostic |generic-candidate-r2-receipt.json;generic-consumer-results.json |
| Offline lock, board validate/next/show/render, docs |exit0 |*-r2 receipts |
| REM/unit/aggregate committed diff checks |exit0 against5c3a0e6 |committed-diff-*-receipt.json |
| Original five finding followups |all exit0; repaired findings; same final bytes |followup-*-r3 receipts |

Every approved13 loopback node ran in final root suite; no new listener. Initial sandbox attempts denied these effects and remain raw failing evidence. Authorized normal-user reruns used the same13 nodes with literal loopback/finite deadline/retry0/proxy0/owned cleanup; actual SDK probe is separate, owned in-memory, with no network/global registration. Only the exact two live-LMStudio modules are excluded. Only preexisting optional SciPy skip remains. Full final root/owning results and327 identity disposition are independently reconciled by [final-reconciliation.json](final-reconciliation.json). All18 tracked Python floors and Python3.13 source ASTs are checked, including tests/lab metadata.

Failed attempts and evidence limitations are explicit. Initial source Mypy caught an undefined local delivery variable and retained its original raw result. Initial focused attempt was interrupted because its new fake fixture left extraction interval-1; its buffered stdout was unavailable after interruption, and only tool traceback/session evidence plus focused-initial-interruption.json remain. This is not claimed as a complete raw artifact. Focused-r2 preserves nine failures: forged execution RootModel lacked revalidation and typed early-close fixture used empty messages; both were corrected within scope. Initial aggregate Mypy found reused str/event iterator variable typing. Its358-byte failed stdout was recovered exactly from tool output after inadvertent same-label rerun overwrote original metadata; initial-mypy-aggregate-reconstructed-receipt.json is clearly reconstructed, not an original receipt. Subsequent run labels prevent overwrite and raw failures/reruns are retained. Two private audit-helper floor-count failures omitted tests/lab before correcting the exact18-file enumeration; no product change. Owning sandbox initial attempt was deliberately interrupted before source rename; stdout/stderr and KeyboardInterrupt receipt remain. No failure is converted into a pass by suppression/skip/waiver.

Private aggregate-final.diff is the complete base-to-authority-plus-product-overlay snapshot diff and contains source-equivalent15 final product bytes, with its frozen authority metadata. It excludes protected runtime paths. Controller committed aggregate diff separately includes later authorized governance/evidence metadata and is the candidate's canonical aggregate review input. Private diff size or metadata scope does not replace the committed full aggregate review.

The first frozen v1 manifest and successful v1 full-suite receipts remain explicitly superseded source evidence. Controller released only a malformed-origin diagnostic guard correction plus four fake regressions. v2 then reran focused/static/all five probes and the complete final broad suite. [freeze-v1-supersession.json](freeze-v1-supersession.json) and byte-identical retained v1 manifests distinguish them. Root committed only v2 bytes. New fresh independent VAL-010 review is pending; builder cannot grant VERIFIED or propose accepted/completed/delivered state.
'''
(out/'report.md').write_text(report)
excluded=['candidate/','frozen-baseline/','unit-base/','tmp/','__pycache__/']
files={p.name:dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(out.iterdir()) if p.is_file() and p.name!='artifact-manifest.json'}
artifact=dict(candidate='5c3a0e6dc8ba995bad9e7dfb8c574f5dfd335bc8',authority_commit=product['authority_commit'],builder='/root/rem005_remediator',result='Builder complete; no independent VERIFIED',files=files,count=len(files),snapshot_exclusions=excluded,snapshot_source_and_omission_receipts=['candidate-snapshot.json','frozen-baseline-snapshot.json','unit-base-snapshot.json'],final_product_manifest='final-product-manifest-v2.json',evidence_limitations=['initial focused buffered stdout unavailable after controlled interruption; session traceback and explicit interruption record retained','initial aggregate Mypy failed stdout recovered from tool output; metadata reconstruction explicitly labeled; originalreceipt overwritten'],immutable_after_manifest=True)
(out/'artifact-manifest.json').write_text(json.dumps(artifact,indent=2)+'\n')
print('report',sha((out/'report.md').read_bytes()))
print('manifest',sha((out/'artifact-manifest.json').read_bytes()),'files',len(files))
