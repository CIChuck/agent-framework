import run
for p in ['fake_probe.py','tools_reasoning_probe.py','closure_probe.py','schema_probe.py','sdk_probe.py']:
 run.run('followup-'+p[:-3],['python',str(run.OUT/p)])
