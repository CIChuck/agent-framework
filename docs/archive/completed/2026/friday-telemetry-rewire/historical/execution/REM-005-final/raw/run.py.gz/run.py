from pathlib import Path
import importlib.util,subprocess,time,datetime,json,sys
OUT=Path('/private/tmp/telem-04/REM-005/builder')
spec=importlib.util.spec_from_file_location('h',OUT/'prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
h.OUT=OUT;h.GUARD=Path('/private/tmp/telem-04/REM-005/readiness/network-guard')
def run(label,args,root=None,timeout=900):
 root=root or OUT/'candidate'
 requested_label=label;attempt=1
 while (OUT/(label+'.stdout')).exists() or (OUT/(label+'-receipt.json')).exists():
  attempt+=1;label=requested_label+'-r'+str(attempt)
 env=h.environment(root,label)
 command=['uv','run','--no-sync',*args] if args[0] not in ('uv','git') else args
 product_paths=json.loads((OUT/"candidate/docs/planning/active/friday-telemetry-rewire/authority-manifest-REM-005.yaml").read_text())["product_base_sha256"]
 product_before={p:h.sha((root/p).read_bytes()) for p in product_paths}
 started=time.time()
 stdout_path=OUT/(label+'.stdout');stderr_path=OUT/(label+'.stderr')
 with stdout_path.open('wb') as fout, stderr_path.open('wb') as ferr:
  process=subprocess.Popen(command,cwd=root,env=env,stdout=fout,stderr=ferr)
  try:
   code=process.wait(timeout=timeout)
  except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
   process.terminate()
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:process.kill();process.wait()
   code=type(error).__name__
 stdout=stdout_path.read_bytes();stderr=stderr_path.read_bytes()
 h.save(label+'-receipt.json',dict(command=command,cwd=str(root),environment=env,exit_code=code,product_before_sha256=product_before,product_after_sha256={p:h.sha((root/p).read_bytes()) for p in product_paths},product_before_after_stable=all(h.sha((root/p).read_bytes())==v for p,v in product_before.items()),product_sha256={p:h.sha((root/p).read_bytes()) for p in json.loads((OUT/"candidate/docs/planning/active/friday-telemetry-rewire/authority-manifest-REM-005.yaml").read_text())["product_base_sha256"]},started_utc=datetime.datetime.fromtimestamp(started,datetime.UTC).isoformat(),seconds=time.time()-started,stdout_sha256=h.sha(stdout),stderr_sha256=h.sha(stderr),source_sha256={str(p.relative_to(root)):h.sha(p.read_bytes()) for p in root.glob('packages/*/src/**/*.py')},helper_sha256=h.sha((OUT/'prepare.py').read_bytes()),probe_sha256=h.sha(Path(args[1]).read_bytes()) if args[0]=='python' and Path(args[1]).is_file() else None))
 print(label,code,len(stdout),len(stderr),flush=True)
 return code
if __name__=='__main__':run(sys.argv[1],sys.argv[2:])
