from pathlib import Path
import gzip
import hashlib
import json
import subprocess

repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
out=Path('/private/tmp/telem-03/construction')
dest=repo/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-03-final'
dest.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((repo/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-03.yaml').read_text())
paths=[p for v in manifest['product_manifest'].values() for p in v if isinstance(p,str)]
changed=subprocess.check_output(['git','diff','--name-only',manifest['base'],'dd543fd6a6819ec0c4fb2529fa384fea886f5509']).decode().splitlines()
changed=[p for p in changed if p in paths]
records=[]
# Every private top-level command receipt, log, frozen script and snapshot manifest;
# never traverse cache/temp/runtime state or original unrelated payload directories.
for source in sorted(p for p in out.iterdir() if p.is_file()):
 target=dest/'raw'/('controller/'+source.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 data=source.read_bytes();compressed=gzip.compress(data,mtime=0);target.write_bytes(compressed)
 records.append(dict(original=str(source),stored=str(target.relative_to(dest)),original_sha256=sha(data),stored_sha256=sha(compressed),bytes=len(data)))
# Retain exact target source versions for every construction iteration with a run,
# allowing earlier failures to be reproduced instead of overwritten by fixes.
for snapshot in ['iteration-01','iteration-02','iteration-03','iteration-04','iteration-05','frozen-candidate']:
 root=out/snapshot
 if not root.exists():continue
 for p in changed:
  source=root/p
  if not source.exists():continue
  target=dest/'raw'/snapshot/'sources'/(p+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
  data=source.read_bytes();compressed=gzip.compress(data,mtime=0);target.write_bytes(compressed)
  records.append(dict(original=str(source),stored=str(target.relative_to(dest)),original_sha256=sha(data),stored_sha256=sha(compressed),bytes=len(data)))
(dest/'artifact-manifest.json').write_text(json.dumps(dict(candidate='dd543fd6a6819ec0c4fb2529fa384fea886f5509',unit_base=manifest['base'],aggregate_base=manifest['aggregate_base'],mode='builder evidence; no independent verdict or maintainer acceptance',gzip_mtime=0,artifacts=records),indent=2)+'\n')
print('Frozen builder artifacts:',len(records))
