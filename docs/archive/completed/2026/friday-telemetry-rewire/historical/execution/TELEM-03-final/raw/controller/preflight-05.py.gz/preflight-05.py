from pathlib import Path
import ast
import hashlib
import json
import subprocess

repo = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
out = Path('/private/tmp/telem-03/construction')
root = out/'iteration-05'
pkt = 'docs/planning/active/friday-telemetry-rewire/'
manifest = json.loads((root/pkt/'authority-manifest-TELEM-03.yaml').read_text())
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for authority in manifest['authority']:
    if sha(root/authority['path']) != authority['sha256']:
        raise RuntimeError('Authority drift: '+authority['path'])
listeners = json.loads((root/pkt/'execution/TELEM-03-planning/listener-scope.json').read_text())
for p,h in listeners['fixture_hashes'].items():
    if sha(root/p)!=h: raise RuntimeError('Effect fixture drift '+p)
new = [p for p in manifest['product_manifest']['tests'] if p.endswith(('test_llm_events.py','test_safe_llm.py','test_safe_telemetry.py','test_llm_telemetry_injection.py'))]
records={}
for p in new:
    tree=ast.parse((root/p).read_text(),feature_version=(3,13))
    imports=[ast.unparse(n) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))]
    calls=sorted({ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n,ast.Call)})
    forbidden=[n for n in imports+calls if any(v in n for v in ['grpc.','OTel','create_telemetry','socket.','HTTPServer','Chroma','readiness','os.environ'])]
    if forbidden: raise RuntimeError('New fixture effect outside fakes '+repr(forbidden))
    records[p]=dict(sha256=sha(root/p),imports=imports,calls=calls,effect='fake-only; inert backends, scoped mocked LiteLLM dispatch; no SDK/channel/listener')
conftests={str(p.relative_to(root)):sha(p) for p in root.rglob('conftest.py') if '.git' not in p.parts}
result=dict(revision='816dc9a with explicit product overlay',snapshot_sha256=sha(out/'iteration-05-snapshot.json'),authority_pins=len(manifest['authority']),approved_effects=listeners,approval_record_sha256=sha(root/pkt/'directives/CD-003-approval-record.md'),new_tests=records,conftests=conftests,network_guard_sha256=sha(Path('/private/tmp/telem-01/REM-001/network-guard/sitecustomize.py')),review='Static imports/helper/fixture source reviewed before collection. Thirteen unchanged loopback regression nodes authorized by explicit CD003 approval; two native GRPC fixtures assert literal loopback, no TLS/proxy/retry and finite owned cleanup. New tests do not use those fixtures. Import resolution and owned-worker audit required after every collection/test gate.')
(out/'iteration-05-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print('PREFLIGHT PASS: 24 authority pins, 13 existing listeners, 4 fake-only new tests')
