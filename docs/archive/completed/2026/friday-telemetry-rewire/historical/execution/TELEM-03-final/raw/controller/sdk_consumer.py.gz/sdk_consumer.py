"""Separate owned actual SDK probe; synthetic in-memory exporter, no channel."""
import asyncio
import hashlib
import json
import sys
import threading
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch

import litellm

async def forbidden(**kwargs):
    raise RuntimeError('Unexpected provider dispatch')
litellm.acompletion = forbidden
litellm.aembedding = forbidden
# Mock dispatch is installed before importing Friday consumers.
from friday_chat.telemetry import ChatTelemetryObserver
from friday_llm import ChatCompletionRequest, LiteLLMService, ResilienceConfig
from friday_telemetry import CompositeProvider, DebugTelemetryRecorder, OTelConfig, TelemetryFactoryConfig, create_telemetry
from friday_telemetry.providers import _otel_exporter
from opentelemetry import trace
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult

secret='PRIVATE_SDK_CONTENT_SENTINEL'
recorded=[]
exporters=[]
initial=set(threading.enumerate())
global_before=trace.get_tracer_provider()
class Recording(SpanExporter):
    def __init__(self, stream):
        self.closed=False
        exporters.append(self)
    def export(self, batch):
        recorded.extend(batch)
        return SpanExportResult.SUCCESS
    def shutdown(self):
        self.closed=True

raw=NS(choices=[NS(message=NS(content=secret, reasoning_content=secret, tool_calls=[]),finish_reason='stop')],
       usage=NS(prompt_tokens=3,completion_tokens=4,total_tokens=7),model=secret,id=secret)
async def main():
    with patch.object(_otel_exporter,'SafeConsoleExporter',Recording), patch.object(trace,'set_tracer_provider',side_effect=RuntimeError('No global registration')):
        handle=create_telemetry(TelemetryFactoryConfig(provider='otel',otel=OTelConfig(exporter='console')))
        try:
            debug=DebugTelemetryRecorder()
            observer=ChatTelemetryObserver(enabled=True,session_id=secret,provider=CompositeProvider([debug,handle.telemetry]))
            service=LiteLLMService(model_name='gpt-4',telemetry=observer,resilience=ResilienceConfig(max_retries=0))
            request=ChatCompletionRequest(messages=({'role':'user','content':secret},))
            with patch.object(litellm,'acompletion',AsyncMock(return_value=raw)) as dispatch:
                assert (await service.chat_completion_request(request)).content==secret
                parent=observer.start_span('chat.application')
                assert (await service.chat_completion([{'role':'user','content':secret}])).content==secret
                assert (await service.chat_completion_request(request)).content==secret
                observer.end_span(parent)
                assert dispatch.await_count==3
            assert handle.flush().status=='success'
            assert trace.get_tracer_provider() is global_before
            assert len(recorded)==4
            sdk_events=[(e.name,dict(e.attributes)) for s in recorded for e in s.events]
            expected=[(e.name,e.data) for e in debug.events]
            assert len(sdk_events)==len(expected)==9
            assert sorted(sdk_events,key=lambda e:(e[1]['request_id'],e[0]))==sorted(expected,key=lambda e:(e[1]['request_id'],e[0]))
            assert [len(s.events) for s in recorded]==[1,1,1,6]
            assert all(s.parent is None for s in recorded)
            assert all(isinstance(d['duration_ms'],float) for n,d in sdk_events if n.endswith('finish'))
            assert secret not in json.dumps(sdk_events)
            result={'sdk_event_count':9,'exported_spans':4,'standalone_spans':3,'accepted_application_span_events':6,
                    'new_llm_spans':0,'scalars_match_debug_and_composite':True,'global_provider_unchanged':True,
                    'raw_content_absent':True,'events':sdk_events}
        finally:
            closed=handle.shutdown()
            if closed.status!='success' or handle.snapshot().worker_alive:
                raise RuntimeError('Owned shutdown failed')
    assert all(e.closed for e in exporters)
    assert not [t for t in threading.enumerate() if t not in initial and t.name=='FridayTelemetryExporter']
    result.update(owned_exporters_closed=True,owned_workers_remaining=False,transport_channels_created=0)
    output=Path(sys.argv[1]);output.write_text(json.dumps(result,indent=2)+'\n')
    print('ACTUAL SDK CONSUMER PASS: 9 matching safe events, standalone/current accepted spans, closed worker/exporter, no channel')
asyncio.run(main())
