from pathlib import Path
import importlib.util
import json
import sys

spec = importlib.util.spec_from_file_location('runner', '/private/tmp/telem-02/builder-execution/runner.py')
x = importlib.util.module_from_spec(spec)
spec.loader.exec_module(x)
x.OUT = Path('/private/tmp/telem-03/construction')
x.helper.OUT = x.OUT
m = json.loads((x.REPO/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-03.yaml').read_text())
x.PRODUCT = [p for group in m['product_manifest'].values() for p in group if isinstance(p,str) and (x.REPO/p).is_file()]
original_environment = x.helper.environment
def environment(root, label):
    env = original_environment(root, label)
    env['PYTHONPATH'] += ':' + str(x.OUT)
    return env
x.helper.environment = environment
if sys.argv[1] == 'overlay':
    root = x.overlay(sys.argv[2], sys.argv[3])
    (root/'pytest_source_audit.py').unlink(missing_ok=True)
elif sys.argv[1] == 'run':
    sys.exit(x.run(sys.argv[2], sys.argv[3], sys.argv[4:]))
