from pathlib import Path
import ast
import hashlib
import json
import subprocess
import yaml

out=Path('/private/tmp/telem-03/construction')
root=out/'frozen-candidate'
repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
pkt='docs/planning/active/friday-telemetry-rewire/'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
controls={}
for manifest in ['authority-manifest-TELEM-03.yaml','authority-manifest.yaml','authority-manifest-TELEM-02.yaml']:
 d=yaml.safe_load((root/pkt/manifest).read_text());pins=d['authority']
 for pin in pins:
  if sha(root/pin['path'])!=pin['sha256'] or sha(repo/pin['path'])!=pin['sha256']:
   raise RuntimeError('Control drift '+pin['path'])
 controls[manifest]=dict(sha256=sha(root/pkt/manifest),pins=len(pins),all_match_live_and_candidate=True)
paths=json.loads((out/'gate-paths.json').read_text())['aggregate_python']
for p in paths:ast.parse((root/p).read_text(),feature_version=(3,13))
base='4ca9baecdcdcf26fc5e8055b326c3a54cda36cb7';service='packages/friday-llm/src/friday_llm/service.py'
old=ast.parse(subprocess.check_output(['git','-C',str(repo),'show',base+':'+service]));new=ast.parse((root/service).read_text())
names=['_build_langfuse_metadata','_parse_response','_parse_typed_response','_events_from_response','_iterate_with_timeout']
for name in names:
 a=next(n for n in ast.walk(old) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
 b=next(n for n in ast.walk(new) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
 if ast.dump(a,include_attributes=False)!=ast.dump(b,include_attributes=False):
  raise RuntimeError('Unapproved parser/callback/timeout drift '+name)
(out/'frozen-control-audit.json').write_text(json.dumps(dict(authority_and_accepted_controls=controls,aggregate_python_ast_count=len(paths),unchanged_langfuse_application_parser_timeout_methods=names),indent=2)+'\n')
print('FROZEN STATIC AUDIT PASS:24+19+19 pins,120 ASTs and unchanged callbacks/application parsing/timeout')
