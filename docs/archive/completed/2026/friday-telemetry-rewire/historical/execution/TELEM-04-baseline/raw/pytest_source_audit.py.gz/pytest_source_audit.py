"""Read-only module resolution and owned-worker audit for isolated pytest gates."""

import hashlib
import json
import sys
import threading
from pathlib import Path

REPO = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT = Path('/private/tmp/telem-04/construction')


def pytest_addoption(parser):
    parser.addoption('--source-audit-output', action='store')


def pytest_sessionfinish(session, exitstatus):
    imports = {}
    leaks = {}
    for name, module in tuple(sys.modules.items()):
        path = getattr(module, '__file__', None)
        if not isinstance(path, str):
            continue
        resolved = Path(path).resolve()
        if resolved.is_relative_to(REPO) and not resolved.is_relative_to(REPO/'.venv'):
            leaks[name] = str(resolved)
        if name.startswith(('friday_', 'opentelemetry', 'grpc')) and resolved.is_file():
            imports[name] = dict(path=str(resolved), sha256=hashlib.sha256(resolved.read_bytes()).hexdigest())
    workers = [t.name for t in threading.enumerate() if t.name == 'FridayTelemetryExporter' or t.name.startswith('SyntheticOTLP')]
    record = dict(original_product_import_leaks=leaks, owned_workers_remaining=workers,
                  imported_boundary_modules=imports, pytest_exitstatus=int(exitstatus))
    output = session.config.getoption('--source-audit-output')
    if output:
        target = Path(output)
        if not target.is_relative_to(OUT):
            raise RuntimeError('Private audit output required')
        target.write_text(json.dumps(record, indent=2)+'\n')
    if leaks or workers:
        session.exitstatus = 1
        print('SOURCE/OWNED-WORKER AUDIT FAILED', record)
