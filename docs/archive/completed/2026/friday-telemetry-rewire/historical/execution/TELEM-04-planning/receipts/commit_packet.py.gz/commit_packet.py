from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import yaml

repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');out=Path('/private/tmp/telem-04/planning');pkt=repo/'docs/planning/active/friday-telemetry-rewire'
git=lambda *args,**kw:subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-C',str(repo),*args],**kw)
sha=lambda b:hashlib.sha256(b).hexdigest()
if git('diff','--cached','--name-only').strip():raise RuntimeError('Unexpected preexisting staged changes')
if git('rev-parse','HEAD').decode().strip()!='e6209e3156216afde1655758e280690229f7d3e6':raise RuntimeError('Head drift')
m=json.loads((pkt/'authority-manifest-TELEM-04.yaml').read_text())
for pin in m['authority']:
 if sha((repo/pin['path']).read_bytes())!=pin['sha256']:raise RuntimeError('Controlling input changed')
dest=pkt/'execution/TELEM-04-planning';a=json.loads((dest/'artifact-manifest.json').read_text())
if len({v['stored'] for v in a['artifacts']})!=len(a['artifacts']):raise RuntimeError('Duplicate artifact')
for v in a['artifacts']:
 data=(dest/v['stored']).read_bytes()
 if sha(data)!=v['stored_sha256'] or sha(gzip.decompress(data))!=v['original_sha256']:raise RuntimeError('Stored artifact mismatch')
for p,digest in json.loads((out/'unrelated-before.json').read_text()).items():
 if (sha((repo/p).read_bytes()) if (repo/p).is_file() else None)!=digest:raise RuntimeError('Unrelated work changed')
paths=[pkt/p for p in ['README.md','closeout-TELEM-03.md','execution-log.md','authority-manifest-TELEM-04.yaml','telem04-contract.md','verification-profile-TELEM-04.md','directives/CD-004-correlated-execution.md','validation/WVR-006-telem04-lint-disposition.md','validation/WVR-006-telem04-lint-scope.json']]
paths += [p for p in dest.rglob('*') if p.is_file()]
paths += [p for p in (repo/'docs/archive/completed/2026/friday-telemetry-rewire-telem-03').rglob('*') if p.is_file()]
relative=sorted(str(p.relative_to(repo)) for p in paths)
git('add','--',*relative)
for source,target in [('clean-board.yaml','docs/planning/board.yaml'),('clean-README.md','docs/planning/README.md')]:
 digest=git('hash-object','-w','--stdin',input=(out/source).read_bytes()).decode().strip()
 git('update-index','--cacheinfo','100644',digest,target)
staged=git('diff','--cached','--name-only').decode().splitlines()
if set(staged)!=set(relative+['docs/planning/board.yaml','docs/planning/README.md']):raise RuntimeError('Unexpected staging scope')
git('diff','--cached','--check')
subprocess.run(['git','-c','core.hooksPath=/dev/null','-C',str(repo),'commit','-q','-m','Prepare TELEM-04 execution telemetry directive and close TELEM-03'],check=True)
if git('diff','--cached','--name-only').strip():raise RuntimeError('Index not clean')
for p,digest in json.loads((out/'unrelated-before.json').read_text()).items():
 if (sha((repo/p).read_bytes()) if (repo/p).is_file() else None)!=digest:raise RuntimeError('Unrelated postcommit work changed')
clean=yaml.safe_load(git('show','HEAD:docs/planning/board.yaml'));live=yaml.safe_load((repo/'docs/planning/board.yaml').read_text())
extra={k:[v for v in live[k] if v not in clean[k]] for k in ['tasks','events']}
if extra!=json.loads((out/'planning-dirty-before.json').read_text()):raise RuntimeError('Unrelated board changes altered')
candidate=git('rev-parse','HEAD').decode().strip()
product_delta=git('diff','e6209e3',candidate,'--','packages').decode()
if product_delta:raise RuntimeError('Planning commit changed product')
(out/'commit-preservation.json').write_text(json.dumps(dict(candidate=candidate,staged_paths=staged,index_clean=True,product_delta_empty=True,unrelated_files_preserved=True,unrelated_board_objects_identical=True),indent=2)+'\n')
print('Planning candidate:',candidate,'; exact paths:',len(staged),'; no product delta; unrelated work preserved')
