"""Expand exact current-unit and preparation-base aggregate verification targets."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import subprocess
import sys

OUT = Path('/private/tmp/telem-02/builder-execution')
ROOT = OUT / sys.argv[1]
REPO = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
spec = importlib.util.spec_from_file_location('runner', OUT/'runner.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
snapshot = json.loads((OUT/(ROOT.name+'-snapshot.json')).read_text())
revision = snapshot['revision']
base = '2155a0fc51f5b20dea4e35c6cfc70f1d52002735'
prior = subprocess.check_output(['git','--no-optional-locks','-C',str(REPO),'diff','--name-only',base,revision,'--','*.py']).decode().splitlines()
aggregate = set(prior) | set(runner.SOURCE + runner.TESTS)
changed = []
for path in sorted(aggregate):
    old = subprocess.run(['git','--no-optional-locks','-C',str(REPO),'show',base+':'+path], capture_output=True)
    if old.returncode or old.stdout != (ROOT/path).read_bytes():
        changed.append(path)
sources = [p for p in changed if '/src/' in p]
owners = sorted({p.split('/')[1] for p in sources})
trees = sorted(str(t.relative_to(ROOT)) for owner in owners for t in (ROOT/'packages'/owner).glob('tests_*') if t.is_dir())
focused = ['packages/friday-chat/tests_chat/'+p for p in ['test_telemetry.py','test_cli.py','test_runtime.py','test_app_lifecycle.py','compat/test_config_compatibility.py']] + ['packages/friday-telemetry/tests_telemetry/test_providers.py']
for path in changed:
    ast.parse((ROOT/path).read_text(), feature_version=(3,13))
record = dict(revision=revision,overlay=snapshot.get('overlay',[]),unit_source=runner.SOURCE,unit_python=runner.SOURCE+runner.TESTS,unit_product=runner.PRODUCT,unit_source_count=len(runner.SOURCE),unit_python_count=len(runner.SOURCE+runner.TESTS),aggregate_python=changed,aggregate_source=sources,aggregate_source_count=len(sources),aggregate_python_count=len(changed),aggregate_owners=owners,owning_trees=trees,focused=focused,root_exclusions=['packages/friday-chat/tests_chat/test_live_lmstudio.py','packages/friday-llm/tests_llm/test_live_lmstudio.py'],ast_feature_version='3.13',all_changed_python_parsed=True,changed_hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in changed})
(OUT/(ROOT.name+'-expanded-targets.json')).write_text(json.dumps(record,indent=2)+'\n')
print('EXPANDED',len(runner.SOURCE),'unit source;',len(runner.SOURCE+runner.TESTS),'unit Python;',len(sources),'aggregate source;',len(changed),'aggregate Python;',len(trees),'owning trees')
