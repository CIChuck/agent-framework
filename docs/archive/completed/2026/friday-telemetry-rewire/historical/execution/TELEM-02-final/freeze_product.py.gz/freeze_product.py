"""Exact-path stable product freeze; preserves mixed checkout and empty index."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess

REPO = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT = Path('/private/tmp/telem-02/builder-execution')
EXPECTED = '37a428c89ada5d736ed22163bfc525aefe8e0b5c'
spec = importlib.util.spec_from_file_location('runner', OUT/'runner.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
def git(*args):
    return subprocess.check_output(['git','--no-optional-locks','-c','core.hooksPath=/dev/null','-C',str(REPO),*args])
assert git('rev-parse','HEAD').decode().strip() == EXPECTED
assert git('branch','--show-current').decode().strip() == 'feature/friday-telemetry-rewire'
assert not git('diff','--cached','--name-only')
before_status = git('status','--porcelain=v1','-z')
paths = runner.PRODUCT
before = {p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in paths}
(OUT/'product-working.diff').write_bytes(git('diff','--no-ext-diff','HEAD','--',*paths))
git('add','--',*paths)
staged = git('diff','--cached','--name-only').decode().splitlines()
assert set(staged) == set(paths) and len(staged) == 13
(OUT/'product-staged.diff').write_bytes(git('diff','--no-ext-diff','--cached'))
git('diff','--cached','--check')
git('commit','-m','Add owned OpenTelemetry context and bounded factory lifecycle')
candidate = git('rev-parse','HEAD').decode().strip()
assert not git('diff','--cached','--name-only')
assert set(git('diff','--name-only',EXPECTED,candidate).decode().splitlines()) == set(paths)
assert before == {p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in paths}
record = dict(base=EXPECTED,candidate=candidate,product_paths=paths,source_hashes=before,status_before_hex=before_status.hex(),status_after_hex=git('status','--porcelain=v1','-z').hex(),exact_product_only_commit=True,index_empty_after=True)
(OUT/'product-freeze.json').write_text(json.dumps(record,indent=2)+'\n')
print(candidate)
