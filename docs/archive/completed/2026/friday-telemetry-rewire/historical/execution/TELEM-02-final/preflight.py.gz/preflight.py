"""Static test/import/transport freeze before any pytest collection or execution."""
from pathlib import Path
import ast
import hashlib
import json
import sys

OUT = Path('/private/tmp/telem-02/builder-execution')
root = OUT / sys.argv[1]
label = sys.argv[2]
sha = lambda b: hashlib.sha256(b).hexdigest()
snapshot = json.loads((OUT / (root.name + '-snapshot.json')).read_text())
prior_pytest_receipts = []
for receipt_path in OUT.glob('*-receipt.json'):
    receipt = json.loads(receipt_path.read_text())
    if receipt.get('cwd') == str(root) and 'pytest' in receipt.get('command', []):
        prior_pytest_receipts.append(receipt_path.name)
inventory = json.loads((root / 'docs/planning/active/friday-telemetry-rewire/execution/TELEM-02-planning/listener-scope.json').read_text())
nodes = inventory['existing_nodes'] + inventory['new_nodes']
assert len(nodes) == len(set(nodes)) == 13
frozen = {}
for path in snapshot['tracked_hashes']:
    if path.endswith('.py') and ('/src/' in path or '/tests_' in path or '/tests/' in path or path.endswith('conftest.py')):
        data = (root / path).read_bytes()
        tree = ast.parse(data, feature_version=(3, 13))
        imports = [ast.unparse(n) for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))]
        frozen[path] = dict(sha256=sha(data), imports=imports,
                            conftest=Path(path).name == 'conftest.py')
for path, expected in inventory['existing_fixture_hashes'].items():
    assert sha((root / path).read_bytes()) == expected
for node in nodes:
    path, name = node.split('::')
    function = name.split('[')[0]
    assert any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == function for n in ast.walk(ast.parse((root / path).read_text())))
new_test = 'packages/friday-telemetry/tests_telemetry/test_otlp_collector.py'
new_tree = ast.parse((root / new_test).read_text())
assert {n.name for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')} == {n.split('::')[1] for n in inventory['new_nodes']}
guard = Path('/private/tmp/telem-01/REM-001/network-guard/sitecustomize.py')
assert sha(guard.read_bytes()) == '6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81'
baseline = json.loads(Path('/private/tmp/telem-02/builder-baseline/approved-candidate-source-api.json').read_text())
interface = 'packages/friday-telemetry/src/friday_telemetry/interface.py'
assert sha((root / interface).read_bytes()) == baseline['hashes'][interface]
chat_config = 'packages/friday-chat/src/friday_chat/config.py'
assert sha((root / chat_config).read_bytes()) == baseline['hashes'][chat_config]
prefix = 'packages/friday-telemetry/src/friday_telemetry/'
config_tree = ast.parse((root / prefix / 'config.py').read_text())
legacy = next(n for n in config_tree.body if isinstance(n, ast.ClassDef) and n.name == 'TelemetryConfig')
old_config = ast.parse((Path('/private/tmp/telem-02/builder-baseline/approved-candidate') / prefix / 'config.py').read_text())
old_legacy = next(n for n in old_config.body if isinstance(n, ast.ClassDef) and n.name == 'TelemetryConfig')
assert ast.dump(legacy) == ast.dump(old_legacy)
init_tree = ast.parse((root / prefix / '__init__.py').read_text())
exports = next(ast.literal_eval(n.value) for n in init_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == '__all__' for t in n.targets))
assert set(baseline['public_exports']) <= set(exports)
adapter_tree = ast.parse((root / prefix / 'providers/otel.py').read_text())
provider = next(n for n in adapter_tree.body if isinstance(n, ast.ClassDef) and n.name == 'OpenTelemetryProvider')
constructor = next(n for n in provider.body if isinstance(n, ast.FunctionDef) and n.name == '__init__')
assert [n.arg for n in constructor.args.args] == ['self', 'service_name', 'endpoint']
assert ast.literal_eval(constructor.args.defaults[0]) is None
helper_paths = ['packages/friday-telemetry/tests_telemetry/test_otlp_collector.py', prefix+'providers/_otel_exporter.py', prefix+'providers/_otel_processor.py', prefix+'providers/otel.py']
helper_records = {}
for path, expected in snapshot.get('private_execution_helpers', {}).items():
    data = (root/path).read_bytes()
    assert sha(data) == expected
    ast.parse(data, feature_version=(3,13))
    helper_records[path] = dict(sha256=expected, execution_only=True)
for path in helper_paths:
    data = (root/path).read_text()
    tree = ast.parse(data)
    functions = {f'{getattr(c,"name", "module")}.{n.name}': sha(ast.get_source_segment(data,n).encode()) for c in [tree]+[x for x in tree.body if isinstance(x,ast.ClassDef)] for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    helper_records[path] = dict(sha256=sha(data.encode()), functions=functions)
record = dict(phase='pre-collection static freeze; candidate effects require actual later tests', snapshot=root.name, revision=snapshot['revision'], snapshot_sha256=sha((OUT/(root.name+'-snapshot.json')).read_bytes()), overlay=snapshot.get('overlay',[]), exact_parameter_expanded_listener_nodes=nodes, listener_inventory_sha256=sha((root/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-02-planning/listener-scope.json').read_bytes()), protected_omission_count=snapshot['omitted_count'], existing_listener_helpers_unchanged=inventory['existing_fixture_hashes'], imports_conftests_helpers=frozen, owned_transport_helpers=helper_records, expected_effects='Exactly existing11 syntheticHTTP and new2 syntheticgRPC:127.0.0.1:0; all other positivegrpc/HTTPS cases mock channel/credentials; no otherlisteners/remote/TLS/credential activation', native_guard_limitation='Python socket guard does not cover all nativegRPC I/O. Collector fixture validates literal127.0.0.1 ephemeral bind, interceptedexacttarget/options, nosecurebranch and ownedchannel/server/executor/workercleanup; these actual outcomes must be recorded later.', guard_sha256=sha(guard.read_bytes()), legacy_api_defaults_and_exports_preserved=True, prior_pytest_receipts_for_this_snapshot=prior_pytest_receipts)
(OUT/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print('PREFLIGHT FROZEN', len(frozen), 'source/test/helper modules;', sum(x['conftest'] for x in frozen.values()), 'conftests; exact13nodes')
