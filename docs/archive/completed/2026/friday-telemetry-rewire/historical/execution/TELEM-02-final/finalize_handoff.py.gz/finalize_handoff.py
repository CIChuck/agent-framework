"""Freeze portable builder evidence without changing product or authority."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

OUT = Path('/private/tmp/telem-02/builder-execution')
ROOT = OUT / 'candidate01'
REPO = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
BASE = Path('/private/tmp/telem-02/builder-baseline')
HANDOFF = Path('/private/tmp/telem-02/builder-handoff')
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda name: json.loads((OUT/name).read_text())
write = lambda name, data: (OUT/name).write_text(json.dumps(data, indent=2)+'\n')
freeze = read('product-freeze.json')
candidate = freeze['candidate']
targets = read('candidate01-expanded-targets.json')
metadata = read('final-metadata-authority-receipt.json')
preflight = read('candidate01-pre-collection.json')
assert candidate == '45f3114173a7e9ada128c7950fe1f7e63cb2ff28'
assert not preflight['prior_pytest_receipts_for_this_snapshot']
assert len(preflight['exact_parameter_expanded_listener_nodes']) == 13
assert targets['unit_source_count'] == 7 and targets['unit_python_count'] == 12
assert len(metadata['authority_pins']) == 19
assert all(sha((ROOT/p).read_bytes()) == h for p,h in freeze['source_hashes'].items())
assert sha((BASE/'report.md').read_bytes()) == '6ef6850cc780067cca52ffa9ec818c593d459a04bd03b1a3fdbd03842e0520ee'
assert sha((BASE/'artifact-manifest.json').read_bytes()) == 'c032f08470b8b1d0d4855fe0019a0ebf47b97e91a7a1a4b091bd8a88fd33f229'

env = {'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','TMPDIR':'/private/tmp','PYTHONDONTWRITEBYTECODE':'1'}
commands=[]
def git(cwd,*args):
    start=time.time()
    cmd=['/usr/bin/git','-c','core.fsmonitor=false',*args]
    result=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True)
    commands.append(dict(command=cmd,cwd=str(cwd),environment=env,started_epoch=start,finished_epoch=time.time(),exit_code=result.returncode,stdout=result.stdout.decode(),stderr=result.stderr.decode()))
    assert result.returncode == 0
    return result.stdout

assert git(REPO,'rev-parse','HEAD').decode().strip() == candidate
assert git(REPO,'diff','--cached','--name-only') == b''
status=git(REPO,'status','--porcelain=v1','-z','--untracked-files=normal')
assert all(sha((REPO/p).read_bytes()) == h for p,h in freeze['source_hashes'].items())
for pin in metadata['authority_pins']:
    assert sha((REPO/pin['path']).read_bytes()) == pin['sha256']
manifest_path='docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-02.yaml'
assert sha((REPO/manifest_path).read_bytes()) == metadata['current_authority_manifest_sha256']
delta=git(ROOT,'diff','--name-only',freeze['base'],candidate).decode().splitlines()
assert set(delta)==set(freeze['product_paths']) and len(delta)==13
git(ROOT,'diff','--check',freeze['base'],candidate)
git(ROOT,'diff','--check','2155a0fc51f5b20dea4e35c6cfc70f1d52002735',candidate)
write('final-scope-whitespace-preservation.json',dict(candidate=candidate,commands=commands,index_empty=True,product_hashes_unchanged=True,authority_19_pins_and_manifest_unchanged=True,exact_product_delta=delta,status_names_only_hex=status.hex(),unrelated_payloads_read=False,transient_claude_left_uninspected=True))

zero=['final-new-contract','final-original-focused','final-chat-telemetry','final-root-collection','final-root-full','final-owning-trees','final-unit-ruff','final-aggregate-ruff','final-unit-mypy','final-aggregate-mypy','final-native-lock','final-board','final-docs','final-public-consumer','final-cold-public-api','final-async-cleanup']
negative=['final-registry-invariance','preparation-base-registry-invariance','final-negative-consumer']
gates={}
for label in zero+negative+['final-root-ruff','final-root-ruff-json']:
    receipt=read(label+'-receipt.json')
    expected=0 if label in zero else 1
    assert receipt['exit_code']==expected and receipt['tracked_unchanged']
    assert sha((OUT/(label+'.log')).read_bytes())==receipt['log_sha256']
    if label!='preparation-base-registry-invariance':
        assert receipt['revision']==candidate
    gates[label]=dict(receipt=label+'-receipt.json',log=label+'.log',raw_exit=expected,tracked_unchanged=True)
for label in ['final-registry-invariance','preparation-base-registry-invariance']:
    errors=[l.split(': error: ',1)[1] for l in (OUT/(label+'.log')).read_text().splitlines() if ': error: ' in l]
    assert len(errors)==2 and all('[assignment]' in x for x in errors)
assert [l.split(': error: ',1)[1] for l in (OUT/'final-registry-invariance.log').read_text().splitlines() if ': error: ' in l] == [l.split(': error: ',1)[1] for l in (OUT/'preparation-base-registry-invariance.log').read_text().splitlines() if ': error: ' in l]
negative_text=(OUT/'final-negative-consumer.log').read_text()
assert negative_text.count(': error: ')==2 and '[attr-defined]' in negative_text and '[assignment]' in negative_text

expected_summaries={'final-new-contract':(90,0),'final-original-focused':(135,0),'final-chat-telemetry':(828,5),'final-root-full':(2891,1),'final-owning-trees':(2873,1)}
for label,(passed,skipped) in expected_summaries.items():
    raw=(OUT/(label+'.log')).read_text()
    assert f'{passed} passed' in raw
    assert (f'{skipped} skipped' in raw) if skipped else (' skipped' not in raw)
    gates[label].update(passed=passed,skipped=skipped)
assert '2892 tests collected' in (OUT/'final-root-collection.log').read_text()
gates['final-root-collection']['collected']=2892

audits={}
native=[]
for label in ['final-new-contract','final-original-focused','final-chat-telemetry','final-root-collection','final-root-full','final-owning-trees']:
    audit=read(label+'-source-audit.json')
    assert not audit['original_product_import_leaks'] and not audit['owned_workers_remaining']
    audits[label]=dict(receipt=label+'-source-audit.json',original_product_import_leaks={},owned_workers_remaining=[])
    for line in (OUT/(label+'.log')).read_text().splitlines():
        if line.startswith('{"node":'):
            obj=json.loads(line)
            assert obj['bind']=='127.0.0.1:0' and obj['target'].startswith('127.0.0.1:')
            assert obj['request_count']==1 and obj['channel_count']==1
            assert obj['channels_closed_by_owner'] and obj['server_stopped'] and not obj['executor_workers_remaining']
            assert obj['options']==[['grpc.enable_http_proxy',0],['grpc.enable_retries',0],['grpc.max_send_message_length',4194304],['grpc.max_receive_message_length',4194304]]
            obj['log']=label+'.log'
            if obj['node'].startswith('tests_telemetry/'):
                obj['canonical_node']='packages/friday-telemetry/'+obj['node']
            else:
                obj['canonical_node']=obj['node']
            native.append(obj)
rootpass=set(re.findall(r'^PASSED (.+)$',(OUT/'final-root-full.log').read_text(),re.M))
assert set(preflight['exact_parameter_expanded_listener_nodes']) <= rootpass
async_cleanup=json.loads((OUT/'final-async-cleanup.log').read_text().strip())
assert async_cleanup['no_new_pending_tasks'] and async_cleanup['both_provider_workers_reaped'] and async_cleanup['all_threads_restored']

chat='packages/friday-chat/tests_chat/test_live_lmstudio.py'
graph='packages/friday-memory/tests_memory/test_adapters/test_graph.py'
skip_files={}
for path in [chat,graph]:
    current=sha((ROOT/path).read_bytes())
    assert current==sha((BASE/'approved-candidate'/path).read_bytes())==sha((BASE/'preparation-base'/path).read_bytes())
    skip_files[path]=current
reason='set FRIDAY_CHAT_LIVE=1 to authorize loopback LM Studio requests'
skips=[dict(node=chat+'::'+name,reason=reason,gate='final-chat-telemetry',baseline='unchanged opt-in mark/source at preparation-base and frozen prebuild candidate') for name in ['test_live_primary_complete_accepts_supported_controls[disabled]','test_live_primary_complete_accepts_supported_controls[enabled]','test_live_primary_stream_exposes_visible_text_only','test_live_primary_automatic_tool_selection','test_live_bounded_turn_processor_flow']]
skips.append(dict(node=graph+'::TestElementXGraphStore::test_rank_nodes_pagerank',reason="could not import 'scipy': No module named 'scipy'",gate='final-root-full and final-owning-trees',baseline='unchanged importorskip source; accepted REM-004-final/report.md:42 records same optional SciPy skip'))
write('final-skips-effects-cleanup.json',dict(full_skip_identities=skips,skip_source_hashes=skip_files,no_new_skips=True,exact_13_listener_nodes_passed=preflight['exact_parameter_expanded_listener_nodes'],actual_native_effects=native,source_audits=audits,async_cleanup=async_cleanup,native_guard_limitation='Python socket guard does not cover all native gRPC I/O; actual intercepted literal loopback targets/options and explicit channel/server/executor cleanup establish the authorized native effects. No remote TLS/native trust-root activation was performed. Existing eleven synthetic HTTP effects retain unchanged helper hashes and approved guard.',node_normalization='Package-root focused pytest uses tests_telemetry/...; canonical node prepends packages/friday-telemetry/. Root full logs use canonical nodes directly.'))

mapping={
 'AC02-01':dict(behavior='Strict additive models/default-disabled factory; zero SDK effects for disabled/debug; exact legacy two-argument constructor, no-SDK nested no-op compatibility, safe rejected config/environment/exporter dependencies.',tests=['test_defaults_api_and_lazy_disabled_debug','test_strict_additive_models_reject_invalid_settings','test_destination_validation_precedes_channel','test_conflicting_environment_names_rejected_without_reading_values','test_missing_sdk_legacy_noop_and_explicit_factory_safe_failure','test_incompatible_sdk_rejected','test_missing_explicit_exporter_never_falls_back'],evidence=['final-new-contract.log','candidate01-pre-collection.json','final-cold-public-api.log']),
 'AC02-02':dict(behavior='Instance-owned public SDK provider; correct explicit/implicit roots, parents, standalone/current events; unchanged foreign ambient/global provider.',tests=['test_actual_parent_events_scalars_and_global_isolation'],evidence=['final-new-contract.log','sources/product/packages/friday-telemetry/src/friday_telemetry/providers/otel.py']),
 'AC02-03':dict(behavior='Context isolation across tasks/threads/providers; out-of-order/cross-context/unknown/repeated end; active cap128 and cumulative retained counters.',tests=['test_out_of_order_cross_context_foreign_and_duplicate_end','test_task_thread_and_provider_contexts_are_independent','test_active_limit_cancelled_close_idempotent_and_frozen','test_standalone_event_respects_provider_active_cap_in_another_context'],evidence=['final-new-contract.log','final-async-cleanup.log']),
 'AC02-04':dict(behavior='Owned queue512/batch128/200ms processor with actual exporter results, drops/failure recovery; absolute monotonic flush/shutdown budgets include concurrent lock wait, cancellation and bounded reaping; console stream ownership.',tests=['test_queue_overflow_flush_deadline_failure_recovery_and_cleanup','test_shutdown_cancels_cooperative_in_flight_with_one_deadline','test_concurrent_shutdown_uses_each_callers_budget_and_retains_completed_result','test_noncooperative_double_reports_unreaped_then_is_released_in_finally','test_sparse_queue_exports_on_bounded_interval_without_explicit_flush','test_actual_console_closed_capture_stream_cleanup'],evidence=['final-new-contract.log','final-skips-effects-cleanup.json','sources/product/packages/friday-telemetry/src/friday_telemetry/providers/_otel_processor.py']),
 'AC02-05':dict(behavior='Exactly two native synthetic literal127.0.0.1:0 collector tests; protobuf parent/events/scalars/resources; UNAVAILABLE actual failure, received count1; exact four fixed options incl A02 retries0.',tests=preflight['exact_parameter_expanded_listener_nodes'][-2:],evidence=['final-skips-effects-cleanup.json','final-new-contract.log','final-root-full.log']),
 'AC02-06':dict(behavior='Actual accepted Chat build_runtime observer injection and two-provider Composite using caller-owned managed OTel; no ownership seizure, safe payloads, local diagnostics on sink failure.',tests=['test_real_chat_observer_two_providers_borrowed_ownership_and_privacy'],evidence=['final-new-contract.log','final-chat-telemetry.log','final-original-focused.log','final-async-cleanup.log']),
 'AC02-07':dict(behavior='Strict scalar bounds/no repr; closed content-free results, exact resource; environment key-only rejection, no credential/proxy/SDK loader/global registration/atexit; HTTPS public None-root arguments mocked, safe failure without fallback.',tests=['test_unrepresentable_attributes_rejected_before_sdk','test_names_rejected_without_sdk_warning','test_scalar_and_name_limits_accept_exact_boundaries_without_repr','test_public_grpc_transport_arguments_encoder_and_no_loaders','test_mocked_tls_failure_no_plaintext_fallback_or_exception_content','test_constructor_failure_releases_partial_owned_state'],evidence=['final-new-contract.log','final-skips-effects-cleanup.json','final-metadata-authority-receipt.json']),
 'AC02-08':dict(behavior='All builder verification-profile checks complete on stable tracked candidate; exact source scope/API/registry/AST and unchanged lock/metadata; package migration docs; fresh independent delta+aggregate validator remains responsible for VERIFIED verdict.',tests=[],evidence=list(gates)+['candidate01-expanded-targets.json','final-root-lint-disposition.json','final-scope-whitespace-preservation.json'],status='BUILDER_CHECKS_COMPLETE; independent VERIFIED pending')
}
evidence=dict(role='BUILDER_CHECKS_COMPLETE',candidate=candidate,product_base=freeze['base'],aggregate_base='2155a0fc51f5b20dea4e35c6cfc70f1d52002735',frozen_at_utc=datetime.datetime.now(datetime.UTC).isoformat(),product_manifest=freeze['source_hashes'],gates=gates,acceptance_criteria=mapping,prebuild_reference=dict(report=str(BASE/'report.md'),report_sha256=sha((BASE/'report.md').read_bytes()),manifest=str(BASE/'artifact-manifest.json'),manifest_sha256=sha((BASE/'artifact-manifest.json').read_bytes()),portable_copy='prebuild-reference/',true_prebuild_only=True),precollection_receipt='candidate01-pre-collection.json',expanded_targets='candidate01-expanded-targets.json',scope_preservation='final-scope-whitespace-preservation.json',effects_skips_cleanup='final-skips-effects-cleanup.json',root_lint_disposition=read('final-root-lint-disposition.json'),dependency_tool_sdk_metadata=metadata,current_authority_manifest_path=manifest_path,formal_independent_verdict='pending; builder does not self-approve or mark VERIFIED',limitations=['No exact-floor Python3.13.4 runtime test: installed runtime3.13.10; all18 metadata floors>=3.13.4 unchanged.','Native gRPC is not fully covered by Python socket guard; only exact two synthetic loopback tests activate native transport. HTTPS/native public-root handling was mocked, with no remote connection.','Deliberately noncooperative testdouble reports timeout/unreaped honestly, then is released/joined in finally; no outstanding worker remains.'],retained_failed_attempts=['initial-unit-ruff.log:8 preliminary findings, corrected only within authorized product paths before freeze','static-receipts-attempt01.md:private metadata enumeration initially omitted tests/lab project; corrected to exact18 tracked projects, no product/test/authority weakening'],intended_negative_checks=negative,raw_root_ruff_pass=False)
write('evidence.json',evidence)

report=['# TELEM-02 builder implementation and checks','',f'Role: **BUILDER_CHECKS_COMPLETE**. Stable product candidate `{candidate}` atop `{freeze["base"]}`. This is builder evidence; independent delta/aggregate verification and maintainer acceptance remain separate gates.','', 'The implementation adds strict disabled/debug/OTel construction and explicit caller-owned lifecycle while preserving the three-method TelemetryInterface and legacy `OTelProvider(service_name, endpoint=None)` call shape. OTel owns its public SDK provider, context/parent/event state, bounded processor and exporter; it never globally registers the provider, installs an atexit hook, creates Resource through detectors, or adopts raw legacy hooks. Missing SDK keeps the legacy service-only path an opaque-ID compatible nested no-op; explicit factory construction reports a fixed safe error.','', 'Attributes preserve bool/int64/finite float/string scalars, reject arbitrary objects without repr, and enforce64 attributes,128 ASCII name/key characters,1024 UTF-8 string bytes and128 active spans. Queue512/batch128/interval200ms, one-second RPC and default/max five-second monotonic lifecycle budgets are explicit. Concurrent shutdown includes lock waiting/cancellation in the same deadline; results retain cumulative actual export/failure/drop/cancel outcomes. Noncooperative doubles truthfully report unreaped and are deterministically released by test cleanup.','', 'The owned public gRPC stub/encoder uses no compression, no application retry, finite deadlines and the A02-approved literal options: proxy0, retries0, send4194304, receive4194304. HTTPS uses public native credentials with root/private-key/certificate-chain None; that branch was mocked without remote activation. Console keeps caller stream ownership. README documents1.39.1, migration, trust and activation boundaries.','', 'Exact product scope is seven source files, five test files and package README, listed with immutable hashes in product-freeze.json/evidence.json. Unit targets are12Python/7source; preparation-base aggregate is110Python/70source with13 owning trees. Stable gates use a fresh tracked sparse snapshot with267 protected tracked artifacts omitted before checkout; preliminary overlays are separately labelled and retained. Original runtime/credential/dirty payloads were never copied or inspected.','', '## Stable verification results','', '| Gate | Result |','|---|---|','| New contract/MCP modules |90 passed;0 skipped; raw0|','| Original focused modules |135 passed; raw0|','| Complete Chat+telemetry |828 passed;5 unchanged opt-in live skips; raw0|','| Root collection, only2 named live-module exclusions |2892 collected; raw0|','| Full root, same exclusions |2891 passed;1 unchanged optional SciPy skip; raw0|','|13 owning trees, same exclusions |2873 passed;1 unchanged optional SciPy skip; raw0|','| Unit Ruff/Mypy |12Python/7source; both raw0|','| Aggregate Ruff/Mypy |110Python/70source; both raw0|','| Root Ruff |raw1; exactly327 approved WVR-004 identities; **not PASS**|','| Offline native lock check |raw0; unchanged lock/18 dependency manifests and Python floors|','| AST3.13/API/registry probes |all110 AST parsed; legacy/API/additive exports preserved; positive consumer raw0; intended negative consumers exact errors|','| Board/docs/selected+aggregate whitespace |raw0;24 tasks/449 Markdown documents|','', 'Raw command arrays, cwd, explicit environments, stable revision, exits, elapsed times, log hashes and tracked before/after integrity are in individual receipts. WVR-004 match additionally freezes17 lint configurations,4 archive files, CommandRegistry source+AST, Ruff0.14.10 and targetpy313. No broad suppression or lint/test weakening was introduced. ExactSDK/API/exporter1.39.1 source/API hashes, grpc1.67.1, protobuf6.33.2, Python3.13.10 and Mypy1.19.1 metadata are in final-metadata-authority-receipt.json; all match prebuild metadata. Installed HTTP exporter remains absent.','', 'All13 approved parameter-expanded listener nodes passed in root full. Every actual native collector receipt records literal loopback target, exact four options, one synthetic request, owner channel close, stopped server and joined executor. Source audits report no original checkout product imports and no owned worker at exit. The async two-provider probe restores thread/task state and creates no native listener/channel. Python socket guard cannot cover all native gRPC I/O; intercepted native targets/options and explicit cleanup provide the permitted native evidence. No remote TLS trust-root activation is claimed.','', 'Exact six skipped node identities/reasons and unchanged prebuild/preparation-base source hashes are in final-skips-effects-cleanup.json. Complete Chat includes five previously authorized opt-in LM Studio skips because no live flag is set; full root/owners exclude only the two named live modules and retain the unchanged missing optional SciPy PageRank skip. No new contract node skips.','', '## Acceptance-criterion evidence','']
for ac,value in mapping.items():
    report += [f'**{ac}** — {value["behavior"]}', '', 'Tests: '+(', '.join('`'+x+'`' for x in value['tests']) or 'mandatory stable profile gates and source/API receipts')+'.', '', 'Evidence: '+', '.join('`'+x+'`' for x in value['evidence'])+'.', '']
report += ['## Prebuild, preservation and retained attempts','',f'Independent true prebuild reference: `{BASE}/report.md` SHA256 `{sha((BASE/"report.md").read_bytes())}`; manifest SHA256 `{sha((BASE/"artifact-manifest.json").read_bytes())}`. It froze old source/API/defaults/exports and scoped fake-only defects before the first product edit. It ran no pytest or actual SDK/native worker. Its report/receipts/scripts are copied byte-for-byte to prebuild-reference; baseline originals and timestamps remain untouched.', '', 'The final scope receipt checks current original HEAD, empty index, exact13 committed product paths, product hashes,19 current authority pins+manifest and both whitespace ranges using metadata-only commands. Named unrelated dirty work and transient .claude remain uninspected; product scope changes only through explicit path staging. Parent separately owns preservation authority and governance metadata.', '', 'Initial unit Ruff had8 preliminary findings; corrected in the same authorized paths before candidate freeze, with failed raw log retained. One private static-receipt enumeration initially missed tests/lab; exact tracked18-project enumeration corrected it without changing product tests or authority. Expected negative Mypy probes retain raw1: borrowed interface has no flush/lifecycle assignment; CommandRegistry remains invariant in both directions at preparation base and current candidate. Raw root Ruff remains raw1 under exact temporary WVR-004 disposition.', '', 'Portable artifact-manifest.json lists byte hashes/sizes of reports, command receipts/logs, probes, expanded targets, source/SDK/authority snapshots, freeze and prebuild references. Private Git snapshots/clones/cache/tmp materialization are excluded. No self-approval, VERIFIED marking, push/merge/deploy, dependency install/sync/download or user live activation was performed.', '']
text='\n'.join(report)
(OUT/'implementation-report.md').write_text(text)
(OUT/'report.md').write_text(text)

def copy(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(source.read_bytes())
    assert sha(source.read_bytes())==sha(target.read_bytes())
for path in freeze['product_paths']:
    copy(ROOT/path,OUT/'sources/product'/path)
for pin in metadata['authority_pins']:
    copy(ROOT/pin['path'],OUT/'sources/authority'/pin['path'])
copy(ROOT/manifest_path,OUT/'sources/authority'/manifest_path)
for path,info in metadata['current_installed_metadata']['sdk_sources'].items():
    installed=REPO/'.venv/lib/python3.13/site-packages'/path
    assert sha(installed.read_bytes())==info['sha256']
    copy(installed,OUT/'sources/sdk'/path)
for path in ['packages/friday-telemetry/src/friday_telemetry/interface.py','packages/friday-telemetry/src/friday_telemetry/providers/composite.py','packages/friday-telemetry/src/friday_telemetry/providers/debug.py','packages/friday-chat/src/friday_chat/telemetry.py','packages/friday-chat/src/friday_chat/runtime.py','packages/friday-cli/src/friday_cli/commands.py',chat,graph]:
    copy(ROOT/path,OUT/'sources/unchanged-boundary'/path)
for source in sorted(BASE.iterdir()):
    if source.is_file():
        copy(source,OUT/'prebuild-reference'/source.name)
assert not HANDOFF.exists()
HANDOFF.mkdir()
for source in sorted(OUT.iterdir()):
    if source.is_file():
        copy(source,HANDOFF/source.name)
for folder in ['sources','prebuild-reference']:
    for source in sorted((OUT/folder).rglob('*')):
        if source.is_file():
            copy(source,HANDOFF/source.relative_to(OUT))
files={str(p.relative_to(HANDOFF)):dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(HANDOFF.rglob('*')) if p.is_file()}
manifest=dict(role='BUILDER_CHECKS_COMPLETE',candidate=candidate,files=files,exclusions=['private tracked Git snapshots/clones','Git objects/index','cache/tmp materialization','original protected runtime/credentials/unrelated dirty payloads'],manifest_self_excluded=True)
(HANDOFF/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
copy(HANDOFF/'artifact-manifest.json',OUT/'artifact-manifest.json')
assert all(sha((HANDOFF/p).read_bytes())==v['sha256'] for p,v in files.items())
print(json.dumps(dict(handoff=str(HANDOFF),candidate=candidate,file_count=len(files),manifest_sha256=sha((HANDOFF/'artifact-manifest.json').read_bytes()),report_sha256=sha((HANDOFF/'report.md').read_bytes()),evidence_sha256=sha((HANDOFF/'evidence.json').read_bytes()))))
