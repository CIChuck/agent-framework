"""Finalize pre-build receipts without importing optional runtime dependencies."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys

OUT = Path('/private/tmp/telem-02/builder-baseline')
REPO = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
GUARD = Path('/private/tmp/telem-01/REM-001/network-guard/sitecustomize.py')
def sha(data):
    return hashlib.sha256(data).hexdigest()
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

guard_hash = sha(GUARD.read_bytes())
if guard_hash != '6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81':
    raise RuntimeError('Inherited network guard drift')
base = json.loads((OUT / 'preparation-base-source-api.json').read_text())
candidate = json.loads((OUT / 'approved-candidate-source-api.json').read_text())
metadata = json.loads((OUT / 'tooling-and-sdk-source.json').read_text())
request = json.loads(Path('/private/tmp/telem-02/reconciled-request.json').read_text())
pins = []
for pin in request['authority'] + [dict(path=request['manifest_path'], sha256=request['manifest_sha256'])]:
    actual = sha((OUT / 'approved-candidate' / pin['path']).read_bytes())
    pins.append(dict(**pin, actual_sha256=actual, matches=actual == pin['sha256']))
source_current = {p: sha((REPO / p).read_bytes()) for p in candidate['hashes']}
assert base == candidate
assert source_current == candidate['hashes']
assert all(p['matches'] for p in pins)
assert not metadata['sdk_loaded_modules']
save('baseline-consistency.json', dict(preparation_candidate_source_api_identical=True, current_selected_original_sources_match_frozen_candidate=True, original_metadata_unchanged=json.loads((OUT / 'original-before.json').read_text()) == json.loads((OUT / 'original-after.json').read_text()), guard_sha256=guard_hash, pins=pins))
env = json.loads((OUT / 'approved-candidate-fake-probe-receipt.json').read_text())['environment']
versions = []
for executable, args in [('python', ['--version']), ('ruff', ['--version']), ('mypy', ['--version'])]:
    cmd = [str(REPO / '.venv/bin' / executable)] + args
    result = subprocess.run(cmd, cwd=OUT / 'approved-candidate', env=env, capture_output=True, timeout=15)
    versions.append(dict(command=cmd, exit_code=result.returncode, stdout=result.stdout.decode(), stderr=result.stderr.decode(), environment=env))
    if result.returncode:
        raise RuntimeError('Tool version invocation failed')
save('tool-version-commands.json', versions)
site = Path(metadata['versions']['opentelemetry-sdk']['location'])
observations = []
for rel, needles in [
 ('opentelemetry/sdk/trace/__init__.py', ['shutdown_on_exit: bool = True', 'atexit.register(self.shutdown)', 'def force_flush']),
 ('opentelemetry/sdk/_shared_internal/__init__.py', ['self._worker_thread.start()', 'def shutdown(self, timeout_millis: int = 30000)', 'def force_flush(self, timeout_millis: Optional[int] = None)', 'self._export(BatchExportStrategy.EXPORT_ALL)', 'return True']),
 ('opentelemetry/sdk/trace/export/__init__.py', ['return self._batch_processor.shutdown()', 'return self._batch_processor.force_flush(timeout_millis)']),
]:
    lines = (site / rel).read_text().splitlines()
    observations.append(dict(path=rel, sha256=sha((site / rel).read_bytes()), matched_lines=[dict(line=i, text=line.strip()) for i, line in enumerate(lines, 1) if any(n in line for n in needles)]))
save('sdk-source-observations.json', observations)
scripts = ['prepare.py', 'fake_probe.py', 'finalize.py']
for p in scripts:
    ast.parse((OUT / p).read_text(), feature_version=(3, 13))
save('private-helper-source-hashes.json', {p: sha((OUT / p).read_bytes()) for p in scripts})
print('Frozen baseline consistency, 18 authority/manifest pins, actual tool versions and source-only SDK observations confirmed')
