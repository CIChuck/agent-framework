import pathlib,tomllib,json,sys
from packaging.specifiers import SpecifierSet
ROOT=pathlib.Path(sys.argv[1]);OUT=pathlib.Path('/private/tmp/telem-01/REM-003');BASE=OUT/'baseline-checkout'
projects=[ROOT/'pyproject.toml',*sorted((ROOT/'packages').glob('*/pyproject.toml')),ROOT/'tests/lab/pyproject.toml'];records=[]
for p in projects:
 d=tomllib.loads(p.read_text());requirement=d['project']['requires-python'];spec=SpecifierSet(requirement)
 if requirement!='>=3.13.4':raise RuntimeError(str(p)+' wrong minimum')
 for v in ['3.10.19','3.11.14','3.12.12','3.13.0','3.13.1','3.13.2','3.13.3']:
  if v in spec:raise RuntimeError('accepted unsupported '+v)
 for v in ['3.13.4','3.13.10']:
  if v not in spec:raise RuntimeError('rejected supported '+v)
 original=tomllib.loads((BASE/p.relative_to(ROOT)).read_text())
 for key in ['dependencies','optional-dependencies']:
  if d['project'].get(key)!=original['project'].get(key):raise RuntimeError('dependency constraints changed '+str(p))
 if 'tool' in d and 'ruff' in d['tool'] and d['tool']['ruff'].get('target-version')!='py313':raise RuntimeError('wrong Ruff '+str(p))
 records.append({'path':str(p.relative_to(ROOT)),'requires_python':requirement})
root=tomllib.loads((ROOT/'pyproject.toml').read_text())
if root['tool']['mypy']['python_version']!='3.13':raise RuntimeError('wrong mypy')
if (ROOT/'.python-version').read_text().strip()!='3.13':raise RuntimeError('wrong interpreter preference')
if any(c.endswith(('3.10','3.11','3.12')) for c in root['project']['classifiers']):raise RuntimeError('obsolete classifiers')
old=tomllib.loads((BASE/'uv.lock').read_text());new=tomllib.loads((ROOT/'uv.lock').read_text())
if new['requires-python']!='>=3.13.4':raise RuntimeError('wrong lock minimum')
def package_keys(d):return {(p['name'],p['version'],json.dumps(p['source'],sort_keys=True)) for p in d['package']}
before=package_keys(old);after=package_keys(new);added=after-before
if added:raise RuntimeError('new dependency versions or sources: '+repr(added))
if not any(p['name']=='litellm' and p['version']=='1.100.1' for p in new['package']):raise RuntimeError('LiteLLM changed')
report={'projects':records,'total_projects':len(projects),'lock_packages_before':len(before),'lock_packages_after':len(after),'new_package_version_sources':list(added),'removed_unreachable_packages':sorted(before-after),'dependency_constraints_unchanged':True,'supported_patch_floor_checks':'reject <=3.13.3; accept 3.13.4 and 3.13.10','mypy':'3.13','ruff':'py313','interpreter_preference':'3.13','litellm':'1.100.1'}
(OUT/'metadata-check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
