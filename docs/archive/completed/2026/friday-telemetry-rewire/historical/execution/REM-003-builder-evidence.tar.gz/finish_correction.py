import pathlib,gzip,hashlib,json,re,subprocess
root=pathlib.Path.cwd();out=pathlib.Path('/private/tmp/telem-01/REM-003');pre='docs/planning/active/friday-telemetry-rewire/validation/VAL-004';p=root/pre
for f in (p/'raw').iterdir():
 if f.is_file() and not f.name.endswith('.gz'):
  (f.with_name(f.name+'.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0));f.unlink()
f=p/'report.md';s=f.read_text();s=re.sub(r'\]\(raw/([^)]+)\)',lambda m:'](raw/'+m.group(1)+'.gz)',s);s+='\nRaw artifacts are gzip-compressed byte-for-byte copies. Original names and content hashes remain in the evidence record; decompress a linked artifact to inspect it.\n';f.write_text(s)
(p/'sha256.json').write_text(json.dumps({str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(p.rglob('*')) if f.is_file() and f.name!='sha256.json'},indent=2))
subprocess.run(['git','add','--all','--',pre],check=True);subprocess.run(['git','diff','--cached','--check'],check=True);subprocess.run(['git','commit','-m','Preserve supported Python dependency selections'],check=True)
c=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();(out/'corrected-candidate.txt').write_text(c);print(c)
