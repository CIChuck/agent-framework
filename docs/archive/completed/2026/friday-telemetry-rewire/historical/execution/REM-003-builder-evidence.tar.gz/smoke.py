import sys,importlib.metadata as m
from friday_chat.telemetry import ChatTelemetryObserver
from friday_telemetry import CompositeProvider,DebugTelemetryRecorder
if sys.version_info < (3,13,4):raise RuntimeError('Unsupported interpreter')
a,b=DebugTelemetryRecorder(),DebugTelemetryRecorder(); composite=CompositeProvider([a,b]);observer=ChatTelemetryObserver(enabled=True,session_id='synthetic-rem003',provider=composite)
parent=observer.start_span('chat.runtime');child=observer.start_span('chat.application',parent);observer.emit('runtime_ready');observer.end_span(child);observer.end_span(parent)
if observer.snapshot().state!='active' or observer.snapshot().failure_count:raise RuntimeError('Observer lifecycle failure')
for recorder in [a,b]:
 if len(recorder.spans)!=2 or not all(s.end_time is not None for s in recorder.spans.values()):raise RuntimeError('Unclosed child spans')
 if recorder.event_names!=['chat.runtime_ready']:raise RuntimeError('Lifecycle event mismatch')
print('Genuine Chat observer / Composite lifecycle passed')
print('Python',sys.version.split()[0],'LiteLLM',m.version('litellm'))
print('observer source:',sys.modules['friday_chat.telemetry'].__file__)
print('composite source:',sys.modules['friday_telemetry.providers.composite'].__file__)
