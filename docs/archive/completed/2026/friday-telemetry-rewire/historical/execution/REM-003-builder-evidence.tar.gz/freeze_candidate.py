import pathlib,json,subprocess,shutil
root=pathlib.Path.cwd();out=pathlib.Path('/private/tmp/telem-01/REM-003');p='docs/planning/active/friday-telemetry-rewire/';packet=root/p
review=packet/'validation/CDR-006';review.mkdir(parents=True,exist_ok=True)
for n in ['report.md','evidence.json']:shutil.copyfile(out/'readiness'/n,review/n)
shutil.copyfile(out/'readiness-request.json',review/'request.json')
report='''# REM-003 Python support migration implementation report

Date: 2026-10-05. Maintainer approved "Make it happen."; CD-001 A04/REM-003.
Delta base: 09fe69090f33ae9c047e2e101fe87727d52f9734. Fresh CDR-006 READY at
816e64f35d58b4b1334388dd3b5b6fb312534176 preceded product metadata execution.

All 18 project declarations now require Python >=3.13.4; root/package Ruff
uses py313, mypy uses 3.13, and .python-version selects the 3.13 minor series.
Root README, active setup/contributor guides, scaffold and Docker FROM examples
match the new minimum. Generated public web artifacts are excluded from this
source change and await a normal documentation build; no website publication
or Docker image build/pull/run occurred.

The cache-only first lock attempt lacked LiteLLM metadata. Credential-free
public PyPI resolution without --upgrade succeeded but selected PyPika0.51.1;
that result was rejected. The complete original PyPika0.48.9 package/artifact
block (including hashes) was restored before offline regeneration and check.
Both offline uv lock and uv lock --check then passed. Graph comparison finds
200 packages versus208 at delta base: only8 unreachable old-Python package
versions removed; zero newly selected dependency versions/sources. All manifest
dependency constraints remain byte-equivalent as TOML data. LiteLLM stays1.100.1.
No shared environment synchronization, source build or interpreter download.

SpecifierSet checks reject Python3.10/3.11/3.12 and3.13.0-3.13.3, accept3.13.4
and installed3.13.10. These establish metadata semantics, not an exact-floor
runtime run. Actual supported-runtime execution uses3.13.10. Baseline focused
six-module tests pass135; genuine Chat observer/Composite lifecycle passes.
Broader package/root suites remain nonzero and are being compared against the
stable candidate. Static/runtime/governance results and independent review will
be appended in the closeout without altering controlling authority.

No Python source/test body changed. Historical3.10 failures remain intact and
are superseded only as current support obligations; no baseline gate waiver,
aggregate VERIFIED, completion, acceptance or delivery is claimed. Raw commands,
logs, metadata inventory, exact source-resolution/preflight and preservation
records are in /private/tmp/telem-01/REM-003 and will be archived with closeout.
'''
(packet/'execution/REM-003-implementation-report.md').write_text(report)
old='execute approved Python 3.13.4 minimum migration after fresh readiness review; no waiver approved';new='validate Python 3.13.4 support migration and resolve remaining AC-06 baseline gates; no waiver approved'
for name in ['docs/planning/board.yaml','docs/planning/README.md',p+'README.md']:
 f=root/name;f.write_text(f.read_text().replace(old,new))
readypaths=['  - '+p+'validation/CDR-006/'+n+'\n' for n in ['report.md','evidence.json']]
b=root/'docs/planning/board.yaml';s=b.read_text();anchor='  - '+p+'validation/VAL-003/evidence.json\n';s=s.replace(anchor,anchor+''.join(readypaths));event='''- task: friday-telemetry-rewire
  at: '2026-10-05'
  actor: Codex
  actor_role: agent
  action: implemented approved Python support migration after CDR-006 READY
  note: Python >=3.13.4 metadata and tooling aligned; dependency pins preserved; fresh review pending and aggregate gates unresolved.
  evidence: docs/planning/active/friday-telemetry-rewire/execution/REM-003-implementation-report.md
''';b.write_text(s+event)
f=packet/'execution-log.md';f.write_text(f.read_text()+'''\n## 2026-10-05 — REM-003 stable candidate preparation\n\nFresh CDR-006 READY at816e64f preceded product edits. All18 projects require\n>=3.13.4; tooling/scaffold/setup/image guidance is aligned. Offline lock check\nand graph inventory pass with LiteLLM1.100.1 and all surviving pins preserved.\nA rejected PyPika resolver upgrade was corrected before freeze; no shared .venv\nsync occurred. No source/test edits. Candidate static, broad and genuine runtime\nchecks are next, followed by fresh independent delta/aggregate review.\n''')
f=packet/'README.md';f.write_text(f.read_text()+'''\n[CDR-006](validation/CDR-006/report.md) returned READY for A04. The approved\n[REM-003 implementation](execution/REM-003-implementation-report.md) now aligns\nall18 project minimums and tooling/setup with Python >=3.13.4. Frozen dependency\nversions remain unchanged; candidate verification and fresh independent review\nare pending. All other aggregate AC-06 failures remain unresolved.\n''')
# Commit only authorized complete paths, and only our hunks in mixed board/dashboard.
def git(*a,**kw):return subprocess.check_output(['git',*a],**kw)
if git('diff','--cached','--name-only').strip():raise RuntimeError('Unexpected staged changes')
manifest=json.loads((out/'allowed-paths.json').read_text());paths=manifest['product']+manifest['documentation']+[p+'validation/CDR-006/'+n for n in ['report.md','evidence.json','request.json']]+[p+n for n in ['README.md','execution-log.md','execution/REM-003-implementation-report.md']]
git('add','--',*paths)
for name in ['docs/planning/board.yaml','docs/planning/README.md']:
 staged=git('show','HEAD:'+name).decode().replace(old,new)
 if name.endswith('board.yaml'):staged=staged.replace(anchor,anchor+''.join(readypaths))+event
 h=git('hash-object','-w','--stdin',input=staged.encode()).decode().strip();git('update-index','--cacheinfo','100644',h,name)
git('diff','--cached','--check');print(git('diff','--cached','--stat').decode());git('commit','-m','Require Python 3.13.4 across the Friday workspace');c=git('rev-parse','HEAD').decode().strip();(out/'candidate.txt').write_text(c);print(c)
