import pathlib,json,re
root=pathlib.Path.cwd();out=pathlib.Path('/private/tmp/telem-01/REM-003');m=json.loads((out/'allowed-paths.json').read_text())
for name in m['product']+m['documentation']:
 p=root/name
 if name in ['uv.lock','AGENTS.md']:continue
 if name=='.python-version':p.write_text('3.13\n');continue
 s=p.read_text();s=s.replace('requires-python = ">=3.10"','requires-python = ">=3.13.4"').replace('target-version = "py310"','target-version = "py313"').replace('python_version = "3.10"','python_version = "3.13"')
 s=re.sub(r'^\s*"Programming Language :: Python :: 3\.(10|11|12)",\n','',s,flags=re.M)
 s=s.replace('**Python 3.10 or higher** (3.11+ recommended for best performance)','**Python 3.13.4 or higher**').replace('**Python 3.10 or higher** (3.11+ recommended)','**Python 3.13.4 or higher**').replace('Python 3.10 or higher (3.11+ recommended)','Python 3.13.4 or higher')
 s=s.replace('Python 3.10+','Python 3.13.4+').replace('python:3.11-slim','python:3.13.4-slim')
 if name=='README.md':
  marker='## Repository Layout';s=s.replace(marker,'## Python requirement\n\nFriday requires **Python 3.13.4 or newer**. Python 3.10, 3.11, 3.12 and\n3.13.0–3.13.3 are unsupported. The workspace selects the Python 3.13 series\nthrough `.python-version`; package metadata enforces the patch minimum.\n\nFor an existing checkout using an older interpreter, select Python 3.13.4 or\nnewer and recreate the environment with `uv sync --python 3.13`. Dependency\nconstraints are unchanged, including LiteLLM 1.100.1.\n\n'+marker)
 if name in ['docs/guides/02-getting-started.md','friday-web/content/docs/getting-started/_index.md','friday-web/content/docs/contributing/setup.md','docs/guides/15-contributing.md']:
  # Place migration guidance directly after the prerequisite statement.
  lines=s.splitlines(keepends=True)
  for i,line in enumerate(lines):
   if 'Python 3.13.4 or higher' in line:
    lines[i+1:i+1]=['\n','Existing environments using an older Python must be recreated with a supported\n','interpreter. Use `uv python install 3.13` if needed, then `uv sync --python 3.13`.\n','The minimum patch version is 3.13.4.\n','\n'];break
  s=''.join(lines)
 if s!=p.read_text():p.write_text(s)
print('Applied Python >=3.13.4 metadata, tooling, scaffold, image and guide migration')
