import pathlib,re,json,tomllib
out=pathlib.Path('/private/tmp/telem-01/REM-003');p=pathlib.Path('uv.lock');original=(out/'baseline-checkout/uv.lock').read_text();current=p.read_text();(out/'rejected-grpcio-selection.lock').write_text(current)
pattern=r'\[\[package\]\]\nname = "grpcio"\nversion = "1\.67\.1"\n.*?(?=\n\[\[package\]\]|\Z)';block=re.search(pattern,original,re.S).group();block=re.sub(r'resolution-markers = \[\n.*?\n\]\n','resolution-markers = [\n    "python_full_version < \'3.14\'",\n]\n',block,flags=re.S)
# Retain original version/artifact provenance, prune interpreter-specific wheels
# which cannot be selected under the new Python minimum.
block='\n'.join(l for l in block.split('\n') if not ('url =' in l and re.search(r'-cp3(?:10|11|12)-',l)))
anchor='[[package]]\nname = "grpcio"\nversion = "1.76.0"\nsource = { registry = "https://pypi.org/simple" }\n'
if current.count(anchor)!=1:raise RuntimeError('unexpected grpcio layout')
current=current.replace(anchor,block+'\n'+anchor+'resolution-markers = [\n    "python_full_version >= \'3.14\'",\n]\n')
edge='    { name = "grpcio" },';replacement='    { name = "grpcio", version = "1.67.1", source = { registry = "https://pypi.org/simple" }, marker = "python_full_version < \'3.14\'" },\n    { name = "grpcio", version = "1.76.0", source = { registry = "https://pypi.org/simple" }, marker = "python_full_version >= \'3.14\'" },'
if current.count(edge)!=2:raise RuntimeError('unexpected grpcio edge count')
current=current.replace(edge,replacement).replace('requires-python = ">=3.13.4"\n','requires-python = ">=3.13.4"\nresolution-markers = [\n    "python_full_version < \'3.14\'",\n    "python_full_version >= \'3.14\'",\n]\n',1)
p.write_text(current);tomllib.loads(current);print('Restored existing grpcio1.67.1 Python3.13 /1.76.0 Python3.14 branches')
