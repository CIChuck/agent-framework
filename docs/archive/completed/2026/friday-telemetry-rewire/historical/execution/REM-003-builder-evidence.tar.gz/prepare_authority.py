import pathlib,json,hashlib,yaml
root=pathlib.Path.cwd(); packet=root/'docs/planning/active/friday-telemetry-rewire'; out=pathlib.Path('/private/tmp/telem-01/REM-003')
manifest=json.loads((out/'allowed-paths.json').read_text())
def edit(path,old,new):
 p=root/path;s=p.read_text();
 if old not in s: raise RuntimeError(f'missing match {path}: {old}')
 p.write_text(s.replace(old,new))
paths=manifest['product']+manifest['documentation']
directive='''# Approved REM-003: Python 3.13.4 supported minimum

Status: Approved by repository maintainer, 2026-10-05.
Approval evidence: "Make it happen." in response to the recommendation to require
Python 3.13.4 or newer and align metadata, tooling, lockfile and active verification.
Initiative: friday-telemetry-rewire. Work unit: TELEM-01 / REM-003; CD-001 A04.
Delta base: 09fe69090f33ae9c047e2e101fe87727d52f9734.
Branch: feature/friday-telemetry-rewire. No lightweight exemption or waiver.

## Authority and objective

Explicit maintainer direction changes the support contract: all workspace
packages and the lab project require Python >=3.13.4. This supersedes the
3.10-minimum obligation in CD-001 A01/A03 and REM-002 prospectively. It does
not reinterpret historical results, repair LiteLLM, waive repository failures,
or change telemetry source behavior. Repository policies, the build/tactical
plans and CD-001 remain controlling outside this amendment.

Map VAL-003-F01 once: its minimum-runtime component is resolved by this explicit
support-policy change and current supported-runtime evidence. The root lint,
PTY timing, native-tool, optional-reader, guarded-Web and listener failures
remain unresolved; aggregate AC-06 stays nonpassing until separately resolved.
This directive authorizes no remediation or waiver of those components.

## Exact allowed files

Only Python requirement/tool-target statements, matching classifiers, interpreter
selection, setup/version guidance and Docker FROM versions may change in:

'''+''.join(f'- `{p}`\n' for p in paths)+'''
Planning scope: this packet's CD-001, verification profile, tactical/build plan,
authority manifest, index, append-only execution log, REM-003 records and fresh
review artifacts; telemetry-only board/dashboard changes preserving prior dirty
changes. Generated friday-web/public outputs are excluded; source documentation
is updated for its next normal build. Historical accepted packets, prior review
requests/reports and execution artifacts remain immutable.

## Implementation and migration

- Set every project requires-python to >=3.13.4. Remove obsolete Python 3.10,
  3.11 and 3.12 classifiers. Keep the Python 3.13 classifier.
- Set root and package Ruff targets to py313 and root mypy to 3.13 without
  weakening rules or adding suppressions. Set .python-version to 3.13 (minor
  preference); the exact patch floor is enforced by package/lock metadata.
- Update scaffold defaults, contributor/setup guides and Python Docker examples
  to the new requirement; use python:3.13.4-slim[-bookworm] in FROM statements.
  Do not build, pull, run or publish images under this directive.
- Regenerate uv.lock using existing pins as preferences, cache/offline first,
  never --upgrade. Reject changes to surviving dependency versions or sources;
  removal of now-unreachable Python/platform alternatives is allowed. Public
  credential-free PyPI metadata/artifacts may be read if cache is insufficient.
  No source builds, interpreter downloads, new dependencies or shared .venv
  synchronization. Keep LiteLLM==1.100.1 and all manifest dependency constraints.
- Python <3.13.4 is unsupported. Existing installations must select a supported
  interpreter and recreate their environment through normal uv sync. The current
  3.13.10 environment already meets the requirement and remains unchanged.

## Criteria and required verification

R3-01: All 17 workspace projects plus lab declare >=3.13.4; packaging SpecifierSet
rejects 3.10/3.11/3.12 and 3.13.0-3.13.3, accepts 3.13.4 and installed 3.13.10.
R3-02: Tool targets, interpreter preference, scaffolds, Docker statements and
current installation/contribution guides match support policy; no source edits.
R3-03: uv lock --offline --check succeeds; TOML/lock graph comparison proves no
surviving dependency version/source changed and LiteLLM remains 1.100.1.
R3-04: Fresh-context read-only review of stable scope/authority and then candidate;
Python 3.13 syntax, changed-source mypy, changed-file Ruff, focused six-module
suite and synthetic Chat-observer/Composite import/lifecycle pass on installed
3.13.10 with no credentials, services or original application data.
R3-05: Board/docs validation and git diff --check pass. Capture root Ruff and
complete affected-package/root pytest against isolated base/candidate under
current guard/importlib profile; report failures as aggregate AC-06 failures,
never waive them or imply full initiative verification. Compare normalized
Ruff findings under old/new targets; target-driven diagnostics are explicitly
reported rather than suppressed. Exactly two live modules remain excluded from
root pytest. No new test exclusions or deadline changes.

Use /private/tmp/telem-01/REM-003 for disposable checkouts/evidence. Run tests
under the credential-free environment allowlist and unchanged non-loopback
network guard from REM-002; permit only already-approved three Chat fixture
privileged reruns if needed. Read-only test execution otherwise remains
unprivileged. Preserve original dirty paths and runtime state; no source/test
patches, provider calls, exporter activation, push, merge, release or deployment.
Retain existing synthetic ignored audit summaries only within isolated test roots.

Before product metadata/image/scaffold edits, freeze this amended authority and
obtain fresh directive readiness review. After implementation, commit a stable
candidate and request fresh delta and aggregate read-only review with exact
hashes, commands, exclusions and evidence. A delta result never substitutes for
aggregate VERIFIED. Stop on dependency version drift, unsafe tests, unapproved
paths/effects or incompatible authority. Correct bounded mechanical metadata
and documentation findings within this scope and submit a fresh candidate.
'''
(packet/'remediation/REM-003-python-minimum-directive.md').write_text(directive)
edit('AGENTS.md','Python 3.10+,','Python 3.13.4+,')
cd='docs/planning/active/friday-telemetry-rewire/directives/CD-001-local-telemetry-assembly.md'
edit(cd,'Date: 2026-10-04.','Amendment A04 approved at: 2026-10-05, with REM-003.\nAmendment evidence: "Make it happen." after recommendation to require Python\n3.13.4 or newer. The [REM-003 directive](../remediation/REM-003-python-minimum-directive.md)\nextends metadata/setup scope and supersedes the old minimum-runtime checks.\nNo dependency upgrade, source change, baseline waiver or acceptance is approved.\nDate: 2026-10-04.')
edit(cd,'All other product files, including','Outside the explicit A04/REM-003 metadata/setup extension, all other product files, including')
edit(cd,'uv run mypy --python-version 3.10 <exact changed source files>\n','')
edit(cd,'Python 3.10 syntax/API evidence','Python 3.13 syntax/API and supported-runtime evidence')
p=packet/'verification-profile.md';s=p.read_text().replace('CD-001 amendments A01 and A03','CD-001 amendments A01, A03 and A04')
s=s.replace('not product behavior, package minimum versions, or allowed product paths.','not telemetry behavior. A04 explicitly changes package minimum versions and\nmetadata/setup scope under [REM-003](remediation/REM-003-python-minimum-directive.md),\napproved by the maintainer\'s "Make it happen." on 2026-10-05.')
a=s.index(' A03 explicitly authorizes\na separate temporary Python 3.10 environment');b=s.index('\nIf a discovered test',a)
s=s[:a]+''' A03's completed Python 3.10 provisioning remains historical evidence.
A04/REM-003 replaces the supported minimum with Python 3.13.4. Tests use the
already-installed Python 3.13.10 environment without synchronization. Only
REM-003 permits bounded lock regeneration, cache/offline first with optional
credential-free public PyPI reads; surviving dependency pins must not change.
No interpreter download, source build or shared environment mutation is allowed.
'''+s[b:]
a=s.index('## Advertised Python 3.10 compatibility');b=s.index('## Baselines, frozen requests',a)
s=s[:a]+'''## Supported Python 3.13.4 minimum

All workspace projects and the lab project require Python >=3.13.4 under A04.
Run `uv run mypy --python-version 3.13 <exact changed source files>` with root
configuration; do not weaken typing. Python 3.10 checks are historical and are
no longer current acceptance gates. This is an explicit support-contract change,
not a waiver or a claim that the old Python 3.10 runtime passed.

Parse the exact changed-source list with `ast.parse(..., feature_version=(3, 13))`.
Syntax alone does not establish API/runtime compatibility. Review changed
stdlib/dependency APIs against Python 3.13 and the frozen dependency pins.
Independently smoke-test the real public Chat observer and Composite lifecycle
on installed Python 3.13.10, using synthetic providers, temporary state, the
same guard and no credentials. Record the actual interpreter patch version;
do not claim an exact 3.13.4 runtime run when only 3.13.10 is installed.
Package SpecifierSet checks establish that 3.13.3 is rejected and 3.13.4 accepted.
No exact-floor interpreter download is authorized; do not silently waive a
missing required runtime check. Repeat applicable supported-runtime checks on
preparation base/candidate, omitting then-absent new observer source explicitly.

'''+s[b:]
s=s.replace('distinguish 3.13 typing from minimum-version evidence','distinguish 3.13 typing, the metadata patch floor, and actual runtime evidence');p.write_text(s)
edit('docs/planning/active/friday-telemetry-rewire/tactical-plan.md','changed-source Python 3.10 and 3.13 mypy plus minimum-version syntax/API evidence','changed-source Python 3.13 mypy plus syntax/API and Python >=3.13.4 supported-runtime evidence')
p=packet/'build-plan.md';p.write_text(p.read_text()+'''\n## Python support amendment A04 — 2026-10-05\n\nThe maintainer approved Python >=3.13.4 for the workspace ("Make it happen.").\n[REM-003](remediation/REM-003-python-minimum-directive.md) binds the exact\nmetadata/setup migration and supersedes the old Python 3.10 runtime obligation.\nTelemetry source behavior and remaining AC-06 repository failures are unchanged.\n''')
old='scope remaining AC-06 baseline and frozen 3.10 dependency remediation; no waiver approved'; new='execute approved Python 3.13.4 minimum migration after fresh readiness review; no waiver approved'
for path in ['docs/planning/board.yaml','docs/planning/README.md','docs/planning/active/friday-telemetry-rewire/README.md']:edit(path,old,new)
p=packet/'README.md';p.write_text(p.read_text()+'''\nThe maintainer's "Make it happen." approves [REM-003](remediation/REM-003-python-minimum-directive.md)\nand CD-001 A04: require Python >=3.13.4 across the workspace and align tooling,\nlockfile and current setup docs. Prior 3.10 evidence remains historical; the\nnew support policy removes that obligation without waiving other AC-06 failures.\nFresh readiness review precedes implementation, then fresh candidate review.\n''')
p=packet/'execution-log.md';p.write_text(p.read_text()+'''\n## 2026-10-05 — approved Python minimum migration\n\nThe maintainer rejected a practical need for 3.10 and explicitly said "Make it\nhappen." after the recommendation to require Python >=3.13.4. REM-003/CD-001 A04\nrecords that bounded contract migration. Existing product candidate is 09fe690;\ntelemetry source, LiteLLM pin, shared environment and prior evidence are unchanged.\nOriginal dirty changes are preserved in /private/tmp/telem-01/REM-003/preserved.json.\nBoard remains started on feature/friday-telemetry-rewire. Board selection returned\nAWAITING_APPROVAL memory-v2; explicit maintainer direction continues this already\nstarted initiative. Fresh directive readiness review is the next execution gate.\n''')
p=root/'docs/planning/board.yaml';p.write_text(p.read_text()+'''- task: friday-telemetry-rewire\n  at: '2026-10-05'\n  actor: repository maintainer\n  actor_role: maintainer\n  action: approved REM-003 Python support migration\n  note: Require Python >=3.13.4 and align workspace metadata, tooling, lock and setup docs; no baseline waiver.\n  evidence: docs/planning/active/friday-telemetry-rewire/remediation/REM-003-python-minimum-directive.md\n''')
p=packet/'authority-manifest.yaml';m=yaml.safe_load(p.read_text());m['authority'].append({'path':'docs/planning/active/friday-telemetry-rewire/remediation/REM-003-python-minimum-directive.md'})
for item in m['authority']: item['sha256']=hashlib.sha256((root/item['path']).read_bytes()).hexdigest()
m['external_services']='Test execution: synthetic loopback only, existing network guard, no credentials, live models, remote exporters or real data. A04/REM-003 lock regeneration: offline/cache first, optional credential-free public PyPI reads, preserve surviving dependency versions/sources; no source builds, interpreter download, image build/pull/run, or shared environment synchronization. A03 provisioning completed and historical.'
m['authority_amendment']='CD-001 A01/A02/A03 historical approvals, A04/REM-003 Python >=3.13.4 support migration; no waiver';p.write_text(yaml.safe_dump(m,sort_keys=False,width=90))
(out/'authority-paths.json').write_text(json.dumps([i['path'] for i in m['authority']],indent=2))
print('A04/REM-003 authority reconciled; no product metadata edits yet')
