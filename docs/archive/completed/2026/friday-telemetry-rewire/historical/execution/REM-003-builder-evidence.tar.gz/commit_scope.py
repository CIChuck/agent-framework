import pathlib,subprocess,sys
root=pathlib.Path.cwd();packet='docs/planning/active/friday-telemetry-rewire/'
def git(*a,**kw):return subprocess.check_output(['git',*a],**kw)
if git('diff','--cached','--name-only').strip():raise RuntimeError('Unexpected staged work')
mode=sys.argv[1]
if mode=='authority':
 paths=['AGENTS.md']+[packet+p for p in ['README.md','build-plan.md','tactical-plan.md','directives/CD-001-local-telemetry-assembly.md','verification-profile.md','remediation/REM-003-python-minimum-directive.md','execution-log.md','authority-manifest.yaml']]
 git('add','--',*paths)
 old='scope remaining AC-06 baseline and frozen 3.10 dependency remediation; no waiver approved';new='execute approved Python 3.13.4 minimum migration after fresh readiness review; no waiver approved'
 for p in ['docs/planning/board.yaml','docs/planning/README.md']:
  original=git('show','HEAD:'+p).decode();staged=original.replace(old,new)
  if p.endswith('board.yaml'):
   current=(root/p).read_text();event=current[current.rindex('- task: friday-telemetry-rewire\n'):];staged+=event
  h=git('hash-object','-w','--stdin',input=staged.encode()).decode().strip();git('update-index','--cacheinfo','100644',h,p)
 git('diff','--cached','--check');print(git('diff','--cached','--stat').decode());git('commit','-m','Approve Python 3.13.4 support migration')
else:raise RuntimeError('Unknown mode')
print(git('rev-parse','HEAD').decode().strip())
