import pathlib,shutil,gzip,re,json,hashlib,subprocess,tarfile
root=pathlib.Path.cwd();o=pathlib.Path('/private/tmp/telem-01/REM-003');pre='docs/planning/active/friday-telemetry-rewire/';packet=root/pre;src=o/'validation-corrected';dst=packet/'validation/VAL-005';raw=dst/'raw'
report=(src/'report.md').read_text()
if not report.startswith('CHANGES_REQUESTED'):raise RuntimeError('Read actual verdict before closing')
# No unresolved migration/lock finding may be silently closed.
print(report[:1000])
raw.mkdir(parents=True,exist_ok=True)
for f in src.iterdir():
 if f.is_file():(raw/(f.name+'.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0))
reader=re.sub(r'\]\(([^)]+)\)',lambda m:'](raw/'+m.group(1)+'.gz)' if (src/m.group(1)).is_file() else m.group(),report)
reader+='\nRaw artifacts are gzip-compressed byte-for-byte copies. Original names/content hashes remain in the evidence record; decompress linked artifacts to inspect them.\n'
(dst/'report.md').write_text(reader);shutil.copyfile(src/'evidence.json',dst/'evidence.json');shutil.copyfile(o/'corrected-validation-request.json',dst/'request.json');(dst/'sha256.json').write_text(json.dumps({str(f.relative_to(dst)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(dst.rglob('*')) if f.is_file() and f.name!='sha256.json'},indent=2))
# Preserve controller evidence outside caches, mutable checkouts, package state.
archive=packet/'execution/REM-003-builder-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(o.iterdir()):
  if f.is_file():t.add(f,arcname=f.name)
close='''# REM-003 execution closeout: Python support minimum

Date: 2026-10-05. Approved scope: CD-001 A04/REM-003, maintainer "Make it happen."
Reviewed corrected candidate: 4c0afdb11b663e11ae08a927950dd3e968bbb566.
Delta base: 09fe69090f33ae9c047e2e101fe87727d52f9734.

The requested support migration is implemented: all18 projects require Python
>=3.13.4; Ruff targets py313, mypy targets3.13, .python-version selects3.13.
Current setup/contributor guides, scaffold and Docker FROM statements agree.
Existing3.13.10 meets the requirement. Users on older Python must select a
supported interpreter and recreate their environment through normal uv sync.
No Python source/test edit, dependency constraint change, interpreter download,
completed shared-environment synchronization, image execution or publication occurred.
The failed nested documentation-helper sync attempt and unchanged195 installed
distribution/RECORD hashes are recorded in the implementation/evidence reports.

Fresh [VAL-005](../validation/VAL-005/report.md) independently supports all
REM-003 migration-specific criteria, including154 supported interpreter,
platform and default/all-extra graph contexts with zero selected version/source
or dependency-edge drift, and1833 retained artifact records preserved. LiteLLM
remains1.100.1, PyPika0.48.9, grpcio1.67.1 on3.13 and1.76.0 on3.14.
Offline lock consistency, negative/positive patch-floor metadata checks,
changed-source mypy/syntax3.13, changed-file Ruff, focused135 tests, genuine
public Chat observer/Composite lifecycle on3.13.10 and governance/diff checks pass.
The three permitted synthetic localhost Chat fixture tests also pass.
This is not an exact3.13.4 runtime or Docker build claim.

The aggregate verdict remains CHANGES_REQUESTED because AC-06 mandatory root
lint and complete package/root suites remain nonzero and unwaived. Root Ruff
now has459 diagnostics versus337 at the prior3.10 target (122 additions from
retargeting existing code). No source suppression or opportunistic cleanup.
Remaining test/permission failure IDs and command outcomes are preserved in
VAL-005; narrower successes do not turn those commands into PASS.

The prior3.10 import failure remains true historical evidence. It is no longer
a current support obligation under the explicit maintainer-approved minimum
change. VAL-004's lock-selection finding is resolved in the corrected reviewed
candidate; prior reports are retained and superseded for decision purposes.
No baseline waiver, aggregate VERIFIED, task completion, maintainer acceptance,
push, merge or release is claimed. The initiative stays started/remediation with
validation_state changes_requested; next gate is remaining AC-06 lint/test scope.

Controller raw commands, scripts, preflight, lock/version/artifact inventory and
preservation results are retained in [builder evidence](REM-003-builder-evidence.tar.gz).
Only this initiative's board/dashboard hunks were staged; unrelated original
working-tree edits, user config, data and caches were preserved.
'''
(packet/'execution/REM-003-closeout.md').write_text(close)
f=packet/'README.md';s=f.read_text();old='validate Python 3.13.4 support migration and resolve remaining AC-06 baseline gates; no waiver approved';new='resolve remaining AC-06 lint and test gates; Python 3.13.4 migration supported by fresh review; no waiver approved';s=s.replace(old,new);s+='''\nFresh [VAL-005](validation/VAL-005/report.md) supports the Python >=3.13.4\nmigration and corrected lock selections; its sole remaining finding concerns\nunwaived aggregate AC-06 lint/test gates. [REM-003 execution closeout](execution/REM-003-closeout.md)\nrecords completed requested migration, unchanged dependency selections and\nremaining failures. Work stays started; no aggregate VERIFIED or acceptance.\n''';f.write_text(s)
f=packet/'execution-log.md';f.write_text(f.read_text()+'''\n## 2026-10-05 — REM-003 execution closeout / VAL-005\n\nFresh VAL-005 reviewed corrected4c0afdb. All migration-specific checks pass,\nincluding154 lock graph contexts and1833 retained artifact records with no\nselected dependency/version/source/edge drift. Python >=3.13.4 is now the\ndeclared supported minimum; actual runtime evidence uses3.13.10. Root Ruff\n459 and unwaived broad test/permission failures retain aggregate\nCHANGES_REQUESTED. The requested support migration is implemented and\nindependently supported, while full telemetry acceptance remains open.\nOnly review/execution/board metadata changes after the reviewed candidate.\nNo source, lock or controlling-authority change; original dirty paths preserved.\n''')
event='''- task: friday-telemetry-rewire
  at: '2026-10-05'
  actor: Codex
  actor_role: agent
  action: recorded VAL-005 and Python minimum migration execution closeout
  note: Python >=3.13.4 migration supported; dependency selections preserved; remaining aggregate lint/test gates unwaived.
  evidence: docs/planning/active/friday-telemetry-rewire/execution/REM-003-closeout.md
'''
anchor='  - '+pre+'validation/VAL-004/evidence.json\n';add='  - '+pre+'validation/VAL-005/report.md\n  - '+pre+'validation/VAL-005/evidence.json\n'
for name in ['docs/planning/board.yaml','docs/planning/README.md']:
 f=root/name;s=f.read_text().replace(old,new)
 if name.endswith('board.yaml'):s=s.replace(anchor,anchor+add)+event
 f.write_text(s)
# Stage only authorized closeout paths and scoped hunks in mixed files.
def git(*a,**kw):return subprocess.check_output(['git',*a],**kw)
if git('diff','--cached','--name-only').strip():raise RuntimeError('Unexpected staged changes')
git('add','--',pre+'validation/VAL-005',pre+'execution/REM-003-closeout.md',pre+'execution/REM-003-builder-evidence.tar.gz',pre+'README.md',pre+'execution-log.md')
for name in ['docs/planning/board.yaml','docs/planning/README.md']:
 staged=git('show','HEAD:'+name).decode().replace(old,new)
 if name.endswith('board.yaml'):staged=staged.replace(anchor,anchor+add)+event
 h=git('hash-object','-w','--stdin',input=staged.encode()).decode().strip();git('update-index','--cacheinfo','100644',h,name)
git('diff','--cached','--check')
# Validate with no nested sync; this call can see all original preserved docs.
env={'PATH':str(root/'.venv/bin')+':/opt/homebrew/bin:/usr/bin:/bin','UV_PROJECT_ENVIRONMENT':str(root/'.venv'),'UV_NO_SYNC':'true','UV_OFFLINE':'true','UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_PYTHON_DOWNLOADS':'never'}
subprocess.run([str(root/'.venv/bin/python'),'scripts/friday-dev-board.py','validate'],env=env,check=True)
subprocess.run([str(root/'.venv/bin/python'),'scripts/check-documentation-lifecycle.py'],env=env,check=True)
git('commit','-m','Close Python minimum migration execution');print(git('rev-parse','HEAD').decode().strip())
