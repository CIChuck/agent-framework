import pathlib,tomllib,json,sys,collections
from packaging.markers import Marker,default_environment
OUT=pathlib.Path('/private/tmp/telem-01/REM-003');BASE=OUT/'baseline-checkout';ROOT=pathlib.Path(sys.argv[1])
old=tomllib.loads((BASE/'uv.lock').read_text());new=tomllib.loads((ROOT/'uv.lock').read_text())
def selected(lock,env):
 groups=collections.defaultdict(list)
 for p in lock['package']:
  if not p.get('resolution-markers') or any(Marker(m).evaluate(env) for m in p['resolution-markers']):groups[p['name']].append(p)
 queue=list(lock['manifest']['members']);seen={};problems=[]
 while queue:
  name=queue.pop()
  if name in seen:continue
  choices=groups.get(name,[])
  if len(choices)!=1:raise RuntimeError('ambiguous/missing '+name+': '+str([(c['name'],c['version']) for c in choices]))
  p=choices[0];seen[name]=(p['version'],p['source'])
  edges=list(p.get('dependencies',[]))
  for key in ['optional-dependencies','dev-dependencies']:
   for es in p.get(key,{}).values():edges+=es
  for edge in edges:
   if edge.get('marker') and not Marker(edge['marker']).evaluate(env):continue
   if edge.get('version') and (len(groups.get(edge['name'],[]))!=1 or groups[edge['name']][0]['version']!=edge['version']):raise RuntimeError('edge version mismatch '+str(edge))
   queue.append(edge['name'])
 return seen
records=[]
for v in ['3.13.4','3.13.10','3.14.0','3.14.2']:
 for platform in ['win32','darwin','linux']:
  for machine in ['x86_64','aarch64']:
   env=default_environment();env.update({'python_full_version':v,'python_version':'.'.join(v.split('.')[:2]),'sys_platform':platform,'os_name':'nt' if platform=='win32' else 'posix','platform_system':{'win32':'Windows','darwin':'Darwin','linux':'Linux'}[platform],'platform_machine':machine,'extra':''})
   before=selected(old,env);after=selected(new,env);changes={n:{'before':before.get(n),'after':after.get(n)} for n in before.keys()|after.keys() if before.get(n)!=after.get(n)}
   records.append({'python':v,'platform':platform,'machine':machine,'selected_packages':len(after),'grpcio':after['grpcio'][0],'changes':changes})
   if changes:raise RuntimeError('selection drift '+json.dumps(records[-1]))
old_artifacts={a['url']:a['hash'] for p in old['package'] for a in ([p['sdist']] if 'sdist' in p else [])+p.get('wheels',[])}
new_artifacts={a['url']:a['hash'] for p in new['package'] for a in ([p['sdist']] if 'sdist' in p else [])+p.get('wheels',[])}
changed={u:h for u,h in new_artifacts.items() if old_artifacts.get(u)!=h}
if changed:raise RuntimeError('new/changed artifacts '+repr(changed))
(OUT/'supported-lock-selection-check.json').write_text(json.dumps({'contexts':records,'contexts_checked':len(records),'retained_artifacts':len(new_artifacts),'new_or_changed_artifacts':changed,'all_selected_version_sources_preserved':True},indent=2));print('All selected dependency versions/sources preserved across',len(records),'supported Python/platform/architecture contexts;',len(new_artifacts),'artifact URLs/hashes preserved')
