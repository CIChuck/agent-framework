import pathlib,subprocess,os,sys,time,json,hashlib,tarfile,io
OUT=pathlib.Path('/private/tmp/telem-01/REM-003'); REPO=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); UV='/opt/homebrew/bin/uv';PY=REPO/'.venv/bin/python';GUARD=pathlib.Path('/private/tmp/telem-01/REM-001/network-guard')
SOURCES=['packages/friday-chat/src/friday_chat/'+p for p in ['app.py','cli.py','config.py','runtime.py','telemetry.py']]+['packages/friday-telemetry/src/friday_telemetry/providers/composite.py']
CHANGED=SOURCES+['packages/friday-chat/tests_chat/'+p for p in ['compat/test_config_compatibility.py','test_cli.py','test_telemetry.py']]+['packages/friday-telemetry/tests_telemetry/test_providers.py']
TESTS=['packages/friday-chat/tests_chat/'+p for p in ['test_telemetry.py','test_cli.py','test_runtime.py','test_app_lifecycle.py','compat/test_config_compatibility.py']]+['packages/friday-telemetry/tests_telemetry/test_providers.py']
ROOT_ARGS=['--import-mode=importlib','--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(commit,target):
 target.mkdir(parents=True)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',str(REPO),'archive',commit]))) as t:t.extractall(target,filter='data')
 (OUT/(target.name+'-revision.txt')).write_text(commit)
def env(root,label,name):
 tmp=OUT/'tmp'/label/name;tmp.mkdir(parents=True,exist_ok=True)
 return {'PATH':str(REPO/'.venv/bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','UV_PROJECT_ENVIRONMENT':str(REPO/'.venv'),'UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_NO_SYNC':'true','UV_OFFLINE':'true','LITELLM_LOCAL_MODEL_COST_MAP':'true','ANONYMIZED_TELEMETRY':'False','TERM':'xterm-256color','PYTHONPATH':os.pathsep.join([str(GUARD)]+[str(p) for p in sorted((root/'packages').glob('*/src'))]+[str(root/'packages/friday-chat/tests_chat'),str(root)]),'TMPDIR':str(tmp),'PYTHONDONTWRITEBYTECODE':'1','RUFF_CACHE_DIR':str(tmp/'ruff-cache'),'MYPY_CACHE_DIR':str(tmp/'mypy-cache'),'PYTEST_ADDOPTS':'-o cache_dir='+str(tmp/'pytest-cache')}
def run(label,name,args):
 root=OUT/(label+'-checkout');e=env(root,label,name);log=OUT/(label+'-'+name+'.log');t=time.time()
 with log.open('w') as f:proc=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 data={'label':label,'name':name,'command':[str(a) for a in args],'cwd':str(root),'environment':e,'exit_code':proc.returncode,'seconds':round(time.time()-t,3),'log_sha256':sha(log)}
 (OUT/(label+'-'+name+'.json')).write_text(json.dumps(data,indent=2));print(label,name,proc.returncode,round(time.time()-t,1),flush=True)
def preflight(label):
 root=OUT/(label+'-checkout');prior=pathlib.Path('/private/tmp/telem-01/VAL-003-review');files=sorted(list((root/'packages').glob('*/tests_*/**/*.py'))+list((root/'experiments').glob('*/tests/**/*.py'))+list((root/'packages').glob('*/src/**/*.py')))
 mismatches=[str(p.relative_to(root)) for p in files if not (prior/p.relative_to(root)).is_file() or sha(p)!=sha(prior/p.relative_to(root))]
 if mismatches:raise RuntimeError('Source/test preflight changed: '+repr(mismatches))
 for p in ['.env','.friday','chroma_db']:
  if (root/p).exists():raise RuntimeError('Original state in snapshot')
 (OUT/(label+'-preflight.json')).write_text(json.dumps({'review_basis':'unchanged complete source/test inventory against independently inspected VAL-003 candidate; same testpaths/config, frozen guard and sanitized environment','source_test_files':len(files),'mismatches':mismatches,'guard_sha256':sha(GUARD/'sitecustomize.py'),'tracked_hashes':{str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}},indent=2));print(label,'preflight',len(files),'source/test hashes match',flush=True)
if __name__=='__main__':
 label=sys.argv[1];action=sys.argv[2];root=OUT/(label+'-checkout')
 if action=='create':snapshot(sys.argv[3],root)
 elif action=='preflight':preflight(label)
 elif action=='static':
  run(label,'root-ruff',[UV,'run','--no-sync','ruff','check','.','--output-format','json'])
  run(label,'changed-ruff',[UV,'run','--no-sync','ruff','check',*CHANGED])
  run(label,'mypy313',[UV,'run','--no-sync','mypy','--python-version','3.13',*SOURCES])
  run(label,'syntax313',[PY,'-c','import ast,sys,pathlib; [ast.parse(pathlib.Path(p).read_text(), filename=p, feature_version=(3,13)) for p in sys.argv[1:]]; print("Python 3.13 syntax passed")',*SOURCES])
  run(label,'board',[PY,'scripts/friday-dev-board.py','validate'])
  run(label,'docs',[PY,'scripts/check-documentation-lifecycle.py'])
 elif action=='suites':
  run(label,'focused',[UV,'run','--no-sync','pytest',*TESTS])
  run(label,'packages',[UV,'run','--no-sync','pytest','packages/friday-chat/tests_chat','packages/friday-telemetry/tests_telemetry'])
  run(label,'root-collect',[UV,'run','--no-sync','pytest',*ROOT_ARGS,'--collect-only'])
  run(label,'root',[UV,'run','--no-sync','pytest',*ROOT_ARGS])
 elif action=='smoke':run(label,'smoke',[PY,str(OUT/'smoke.py')])
 elif action=='lock':run(label,'lock-check',[UV,'lock','--offline','--check','--no-python-downloads','--no-build'])
 else:raise RuntimeError(action)
