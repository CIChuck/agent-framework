import sys
sys.argv.append('loopback')
import review
names=['test_chat_adapter_controls_reach_final_http_json','test_chat_adapter_typed_stream_reuses_generation_defaults','test_provider_option_target_mismatch_fails_before_http']
review.run('three-loopback',[review.UV,'run','--no-sync','pytest',*['packages/friday-chat/tests_chat/test_llm_adapter_migration.py::'+n for n in names]])
