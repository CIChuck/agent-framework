exec(open('/private/tmp/telem-01/REM-003/validation-corrected/metadata_graph.py').read().split('contexts=[]')[0])
def adjacency(lock,e):
 idx={}
 for p in lock['package']:
  if active(p,e):idx.setdefault(p['name'],[]).append(p)
 reachable,_,err=reach(lock,e,'all');out={}
 for name,variants in idx.items():
  for p in variants:
   if key(p) not in reachable:continue
   groups={'dependencies':p.get('dependencies',[])}
   for kind in ['optional-dependencies','dev-dependencies']:
    for group,ds in p.get(kind,{}).items():groups[kind+':'+group]=ds
   for g,ds in groups.items():
    extra=g.split(':',1)[1] if g.startswith('optional-dependencies:') else '';selected=[]
    for d in ds:
     if d.get('marker') and not Marker(d['marker']).evaluate(dict(e,extra=extra)):continue
     q=[q for q in idx.get(d['name'],[]) if (not d.get('version') or q['version']==d['version']) and (not d.get('source') or q['source']==d['source'])]
     if len(q)!=1:raise RuntimeError((key(p),g,d))
     selected.append((key(q[0]),tuple(d.get('extras',[]))))
    out[(key(p),g)]=tuple(sorted(selected))
 return out
checks=[]
for v in ['3.13.4','3.13.10','3.14.0','3.14.10','3.15.0']:
 for plat,on,system in [('linux','posix','Linux'),('darwin','posix','Darwin'),('win32','nt','Windows')]:
  e=default_environment();e.update(python_version='.'.join(v.split('.')[:2]),python_full_version=v,implementation_version=v,sys_platform=plat,os_name=on,platform_system=system)
  a=adjacency(old,e);b=adjacency(new,e);diff=[repr(k) for k in a.keys()|b.keys() if a.get(k)!=b.get(k)]
  checks.append(dict(version=v,platform=plat,group_count=len(a),differences=diff))
save('individual-dependency-group-edges',checks);print('each reachable dependency/extra/dev group preserved:',all(not c['differences'] for c in checks),checks[0]['group_count'],'groups per context')
