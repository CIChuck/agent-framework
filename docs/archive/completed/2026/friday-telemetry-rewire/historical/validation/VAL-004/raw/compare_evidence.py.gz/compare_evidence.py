import collections,hashlib,json,pathlib,re,tomllib
from packaging.markers import Marker,default_environment
O=pathlib.Path('/private/tmp/telem-01/REM-003/validation');R=O.parent/'candidate-checkout';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=tomllib.loads((O/'baseline.lock').read_text());new=tomllib.loads((R/'uv.lock').read_text());rows=[]
for ver in ['3.13.4','3.13.10','3.14.0']:
 for platform in ['win32','darwin','linux']:
  e=default_environment();e.update(python_full_version=ver,python_version='.'.join(ver.split('.')[:2]),sys_platform=platform,platform_system={'win32':'Windows','darwin':'Darwin','linux':'Linux'}[platform])
  def active(lock):
   return {p['name']:{'version':p.get('version'),'source':p['source']} for p in lock['package'] if not p.get('resolution-markers') or any(Marker(m).evaluate(e) for m in p['resolution-markers'])}
  a,b=active(old),active(new);drift={k:{'baseline':a[k],'candidate':b.get(k)} for k in a if k in b and a[k]!=b[k]};removed=[k for k in a if k not in b];rows.append({'python':ver,'platform':platform,'selected_dependency_drift':drift,'removed_active_packages':removed})
(O/'lock-selection-comparison.json').write_text(json.dumps(rows,indent=2));print('lock selection drift',json.dumps(rows[0]['selected_dependency_drift']))
base=json.loads((O.parent/'baseline-root-ruff.log').read_text());cand=json.loads((O/'root-ruff.log').read_text())
def normal(items):
 return {(p['filename'].split('checkout/',1)[-1],p['code'],p['location']['row'],p['location']['column'],p['message']) for p in items}
a,b=normal(base),normal(cand);newdiag=sorted(b-a);removed=sorted(a-b);comparison={'baseline_count':len(base),'candidate_count':len(cand),'new_count':len(newdiag),'removed_count':len(removed),'new_by_code':dict(collections.Counter(x[1] for x in newdiag)),'new_diagnostics':newdiag,'removed_diagnostics':removed}
(O/'ruff-comparison.json').write_text(json.dumps(comparison,indent=2));print('Ruff',comparison['baseline_count'],comparison['candidate_count'],'new',comparison['new_count'],'removed',comparison['removed_count'],comparison['new_by_code'])
for name in ['focused','packages','root-collect','root']:
 p=O/(name+'.log')
 if p.exists():
  lines=p.read_text().splitlines();print(name,lines[-1:] if lines else [])
