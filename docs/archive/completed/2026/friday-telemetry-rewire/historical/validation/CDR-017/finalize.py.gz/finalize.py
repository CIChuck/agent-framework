import datetime
import hashlib
import json
from pathlib import Path

out = Path(__file__).parent
e = json.loads((out / 'capture.json').read_text())
prefix = 'docs/planning/active/friday-telemetry-rewire/'
expected_changed = [prefix + p for p in ['directives/CD-002-otel-adapter-lifecycle.md', 'telem02-contract.md', 'verification-profile-TELEM-02.md']]
expected_added = sorted(prefix + p for p in ['directives/CD-002-A02-approval-record.md', 'directives/CD-002-A02-native-retry-disable.md'])
def raw(n):
    return (out / f'raw/{n:03d}.stdout').read_text()
expected_paths = sorted(prefix + p for p in ['authority-manifest-TELEM-02.yaml', 'directives/CD-002-A02-approval-record.md', 'directives/CD-002-A02-native-retry-disable.md', 'directives/CD-002-otel-adapter-lifecycle.md', 'execution-log.md', 'telem02-contract.md', 'verification-profile-TELEM-02.md'])
actual_paths = sorted(line.split('\t', 1)[1] for line in raw(24).splitlines())
e['checks'].update({
    'exact_seven_planning_paths': actual_paths == expected_paths,
    'exact_three_existing_pin_changes': e['pin_delta']['changed'] == expected_changed,
    'exact_two_added_pins': e['pin_delta']['added'] == expected_added,
    'no_removed_pins': e['pin_delta']['removed'] == [],
    'accepted_controls_and_archive_diff_empty': raw(49) == '',
    'selected_diff_check_zero_and_empty': raw(27) == '',
    'approved_A02_proposal_to_base_diff_empty': raw(84) == '',
    'exact_13_unique_listener_ids': e['listener_counts'] == {'existing': 11, 'new': 2} and len(set(json.loads(raw(81))['existing_nodes'] + json.loads(raw(81))['new_nodes'])) == 13,
    'exact_327_wvr_identities': e['wvr_counts'] == {'diagnostics': 327, 'archive': 326, 'live': 1, 'lint_configs': 17},
})
if not all(e['checks'].values()):
    raise RuntimeError(e['checks'])
e.update({
    'verdict': 'READY',
    'review_mode': 'fresh-context read-only approved-amendment construction readiness; affected fixed option/native gate only; not product verification',
    'review_date_local': '2026-10-06 America/New_York',
    'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'context_and_independence': 'Separate reviewer context received the request and frozen revisions. Builder reasoning and prior report verdicts were not adopted. Parent preservation claims were not used as evidence. Static git objects independently checked. General memory registry was consulted only for workflow orientation.',
    'authority_interpretation': 'Explicit A02 approval record binds exactly fixed grpc.enable_retries=0 on both branches; directive, contract and profile reconcile that option without expanding any paths/effects/waivers. All other mandatory gates retain force.',
    'approved_question': 'Approve CD-002 A02 to require the fixed option `grpc.enable_retries=0`?\nThis disables gRPC’s internal retries to meet the approved no-retry requirement.\nIndependent review returned READY; the other authorized work continues.',
    'approval_response': 'approved',
    'approval_actor': 'Chuck Russell',
    'scope': {'included': expected_paths, 'excluded': 'All original uncommitted product/unrelated paths, protected state, credentials, live/native behavior and product verification.'},
    'manual_requirement_checks': [
        {'id': 'A02-R01', 'result': 'PASS', 'receipts': [20, 21, 84, 85], 'fact': 'Pinned explicit decision approves exact one-option A02; substantive proposal retained and approval labels/link reconciled.'},
        {'id': 'A02-R02', 'result': 'PASS', 'receipts': [12, 13, 14, 20, 26], 'fact': 'Both channel branches require fixed retries0, proxy0 and bounded message sizes. Mocked construction plus the two already approved native nodes verify exact options, one public Export per batch, finite timeout and wait_for_ready=False; no added retry experiment.'},
        {'id': 'A02-R03', 'result': 'PASS', 'receipts': [1, 2, 24, 26], 'fact': '19 current pins match; prior17 retains14 unchanged pins, changes only3 exact approved controls and adds2 amendment pins; delta exactly7 planning files.'},
        {'id': 'A02-R04', 'result': 'PASS', 'receipts': [29, 49, 50, 51, 52, 53, 54, 55, 56, 57], 'fact': 'Accepted19 control hashes match and their diff is empty; exact listener and WVR scope/expiry/approval blobs are byte-identical between frozen base and candidate.'},
        {'id': 'A02-R05', 'result': 'PASS', 'receipts': [15, 20, 21, 26, 27], 'fact': 'No added paths, effects, credentials, dependencies, native retry experiments or waived gates. Existing lint disposition stays temporary and all product checks/preflight remain mandatory. Diff whitespace check exits0.'},
    ],
    'residual_limitations': [
        'This READY authorizes implementing the fixed option and progressing the affected native gate under CD-002; native execution still requires its final expanded fixture/import/effect/target/options/environment preflight and bounded cleanup.',
        'No imports, SDK/channel creation, pytest collection/tests, Ruff/type/tool execution, native retry or network experiments, protected state/credential reads, installation, commits or repository edits were performed.',
        '327 diagnostic identities and tool/AST/config pins were statically preserved; this review does not claim fresh root Ruff reproduction or recomputed AST semantics. Registry source bytes and all22 covered archive/config/source hashes match frozen pins.',
        'Approval is assessed from the pinned exact maintainer decision record and explicit dispatch direction. Prior CDR-015/CDR-016 verdicts are historical and not substitutes for this review.',
        'Product verification, final delta/full2155a0f aggregate VERIFIED, maintainer acceptance and later remote/TLS activation remain separate.',
    ],
    'capture_implementation_note': 'Initial static capture assumed JSON for the accepted YAML manifest and stopped with JSONDecodeError before verdict creation. The local receipt script was corrected to parse its exact path/hash lines with a standard-library regex and rerun. No repository content was changed.',
    'memory_orientation': {'file': 'MEMORY.md', 'lines': '81-91', 'rollout_id': '01a1079c-0038-74f0-9319-c89801c7e94e'},
})
(out / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')
report = '''# READY — CD-002 A02 approved-amendment readiness

Reviewer: `/root/telem02_a02_approved_readiness`, separate fresh context; GPT-6 Codex (exact build unavailable). Review date: 2026-10-06 America/New_York; capture: 2026-10-07 00:42:54 UTC. Mode: read-only static approved-amendment construction readiness for the affected option/native gate only.

Frozen candidate: `9f5c4b70b03b105d89e1cf0c9cd65cb3f467e8cd`. Frozen base: `e600cb29f025f1ffe7290dcb6b0f2b2d5a80d25c`. Reviewed exact base..candidate delta. Current manifest SHA-256: `5eda19c81a429584634ee535e19098264e4735e76fae6da8ac0aa631d8a427c2`. Request, prior manifest, every control and raw receipt hash appear in `evidence.json`; exact command stdout/stderr reside under `raw/`.

## Decision

**READY.** The recorded explicit Chuck Russell response **"approved"** approves A02's fixed `grpc.enable_retries=0` on both insecure literal-loopback and mocked secure-channel branches. The exact question and answer are pinned in the new decision record (`raw/021.stdout`). The proposal-to-base amendment diff is empty (`raw/084.stdout`), and proposal-to-candidate changes reconcile approval status/link/wording without changing its one-option substance (`raw/085.stdout`). Prior proposal/readiness verdicts are not adopted as current approval evidence.

The builder may implement this fixed option and progress the affected native gate under the existing approved CD-002. Native test execution still requires CD-002's final expanded fixture/import/effect/environment/target/options preflight and bounded cleanup. No renewed maintainer approval is required for the reviewed amendment.

## Independent evidence

| Check | Result and receipts |
| --- | --- |
| Frozen controls | All19 current pins match exact candidate bytes, and request authority equals manifest authority. Prior17 has14 unchanged pins, only3 changed hashes (directive, contract, profile), and only2 added pins (A02, exact approval record). `raw/001–021.stdout`, `evidence.json: pins/pin_delta`. |
| Exact delta | Exactly7 planning files; no product/test/dependency/config changes. Whole delta manually read. `raw/024–026.stdout`; whitespace diff check exits0 with empty output, `raw/027.stdout`. |
| Option/native semantics | Contract/directive/profile consistently require fixed retries0, proxy0 and bounded message sizes on both branches. Mocked-channel and two existing native-node evidence cover exact options, one public Export per batch, finite timeout, `wait_for_ready=False`, deterministic success/UNAVAILABLE and cleanup. HTTPS remains mocked. No extra native retry fault-injection experiment is required or granted. `raw/012–014.stdout`, `raw/020.stdout`, `raw/026.stdout`. |
| Accepted TELEM-01 | Its original manifest and19 control pins independently match; selected archive/control diff is empty. Entire candidate delta also excludes accepted evidence. `raw/029–049.stdout`. |
| Listener scope | Exact listener-scope bytes preserved;11 existing +2 new unique IDs =13. Existing fixture hashes independently match frozen candidate bytes. No new effects. `raw/050–051.stdout`, `raw/081–083.stdout`. |
| Lint disposition | WVR scope, disposition and original approval byte-identical at base/candidate:327 identities (326 archive +1 registry), same17 lint configs, tool/target and source/AST pins, same expiry after TELEM-02 acceptance or covered drift. Four archive +17 configuration +1 registry source hashes independently match. `raw/052–080.stdout`, `evidence.json: covered_hashes`. |
| Mandatory gates | No gate waiver, lint renewal, added paths/listeners/dependencies/credentials, remote/TLS activation, acceptance or retry experiment is granted. All existing verification requirements remain. `raw/012–015.stdout`, `raw/020–021.stdout`, `raw/026.stdout`. |

There are no findings requiring changes within this narrow readiness scope.

## Limitations and preservation

This review provides construction authority readiness, **not product VERIFIED or acceptance**. It uses only frozen git objects, static comparisons and SHA-256; it does not assess uncommitted implementation, SDK/native behavior, fresh Ruff reproduction, or recomputed AST semantics. Existing registry source bytes and the AST pin are preserved. Final product delta/full2155a0f aggregate validation remains required.

No code import, pytest collection/test, SDK/channel/native/network operation, state/credential access, installation, commit, source edit, index/checkout mutation or approval renewal occurred. Review artifacts are confined to the requested private temporary directory. Builder and parent preservation claims were not relied upon. General memory was consulted only for workflow orientation. The initial receipt helper's JSON assumption for the historical YAML manifest caused a local parse failure; its read-only parser was corrected and all static checks rerun successfully.

`artifact-manifest.json` hashes every review artifact other than itself; `evidence.json` records command arguments, cwd, exits, exact stdout/stderr hashes, reviewer identity, inputs and limitations.
'''
(out / 'report.md').write_text(report)
manifest = {'reviewer': e['reviewer'], 'verdict': 'READY', 'candidate': e['candidate'], 'self_exclusion': 'artifact-manifest.json; a manifest cannot hash itself', 'files': []}
for path in sorted(out.rglob('*')):
    if path.is_file() and path.name != 'artifact-manifest.json':
        data = path.read_bytes()
        manifest['files'].append({'path': path.relative_to(out).as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(out / 'artifact-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'verdict': 'READY', 'report_sha256': hashlib.sha256((out / 'report.md').read_bytes()).hexdigest(), 'evidence_sha256': hashlib.sha256((out / 'evidence.json').read_bytes()).hexdigest(), 'artifact_count': len(manifest['files']), 'checks': e['checks']}, indent=2))
