import datetime
import hashlib
import json
import re
from pathlib import Path
import subprocess

repo = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
out = Path('/private/tmp/telem-02/a02-approved-readiness')
out.mkdir(parents=True, exist_ok=True)
(out / 'raw').mkdir(exist_ok=True)
request_bytes = Path('/private/tmp/telem-02/a02-approved-request.json').read_bytes()
(out / 'request.json').write_bytes(request_bytes)
request = json.loads(request_bytes)
candidate, base = request['candidate'], request['base']
receipts = []
def git(*args):
    index = len(receipts) + 1
    proc = subprocess.run(['git', *args], cwd=repo, capture_output=True)
    stem = f'raw/{index:03d}'
    (out / (stem + '.stdout')).write_bytes(proc.stdout)
    (out / (stem + '.stderr')).write_bytes(proc.stderr)
    receipt = {'id': index, 'argv': ['git', *args], 'cwd': str(repo), 'exit_code': proc.returncode, 'stdout': stem + '.stdout', 'stderr': stem + '.stderr', 'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(proc.stderr).hexdigest()}
    receipts.append(receipt)
    if proc.returncode:
        raise RuntimeError(receipt)
    return proc.stdout
def sha(data):
    return hashlib.sha256(data).hexdigest()
manifest_bytes = git('show', candidate + ':' + request['manifest_path'])
manifest = json.loads(manifest_bytes)
old_bytes = git('show', base + ':' + request['manifest_path'])
old = json.loads(old_bytes)
checks = {'manifest_hash_match': sha(manifest_bytes) == request['manifest_sha256'], 'request_matches_manifest': request['authority'] == manifest['authority']}
pins = []
for entry in manifest['authority']:
    data = git('show', candidate + ':' + entry['path'])
    pins.append({**entry, 'actual_sha256': sha(data), 'matches': sha(data) == entry['sha256']})
checks['all_19_pins_match'] = len(pins) == 19 and all(e['matches'] for e in pins)
prior = {e['path']: e['sha256'] for e in old['authority']}
current = {e['path']: e['sha256'] for e in manifest['authority']}
pin_delta = {'prior_count': len(prior), 'current_count': len(current), 'removed': sorted(set(prior) - set(current)), 'added': sorted(set(current) - set(prior)), 'changed': [p for p in prior if p in current and prior[p] != current[p]], 'unchanged': [p for p in prior if p in current and prior[p] == current[p]]}
git('show', '--format=fuller', '--no-patch', candidate)
git('show', '--format=fuller', '--no-patch', base)
git('diff', '--name-status', base + '..' + candidate)
git('diff', '--stat', base + '..' + candidate)
git('diff', base + '..' + candidate)
git('diff', '--check', base + '..' + candidate)
git('ls-tree', '-r', '--name-only', candidate, 'docs')
archive = 'docs/archive/completed/2026/friday-telemetry-rewire-telem-01/'
old_control = 'docs/planning/active/friday-telemetry-rewire/authority-manifest.yaml'
old_control_data = git('show', candidate + ':' + old_control)
accepted_manifest = {'authority': [{'path': path, 'sha256': digest} for path, digest in re.findall(r'^- path: (.+)\n  sha256: ([0-9a-f]{64})$', old_control_data.decode(), re.MULTILINE)]}
accepted_pins = []
for entry in accepted_manifest['authority']:
    data = git('show', candidate + ':' + entry['path'])
    accepted_pins.append({**entry, 'actual_sha256': sha(data), 'matches': sha(data) == entry['sha256']})
git('diff', base + '..' + candidate, '--', archive, old_control, *[e['path'] for e in accepted_manifest['authority']])
checks['accepted_19_controls_match'] = len(accepted_pins) == 19 and all(e['matches'] for e in accepted_pins)
unchanged_files = []
for rel in ['execution/TELEM-02-planning/listener-scope.json', 'validation/WVR-004-telem02-lint-scope.json', 'validation/WVR-004-telem02-lint-disposition.md', 'directives/CD-002-approval-record.md']:
    path = 'docs/planning/active/friday-telemetry-rewire/' + rel
    old_data = git('show', base + ':' + path)
    new_data = git('show', candidate + ':' + path)
    unchanged_files.append({'path': path, 'base_sha256': sha(old_data), 'candidate_sha256': sha(new_data), 'unchanged': old_data == new_data})
scope = json.loads(git('show', candidate + ':docs/planning/active/friday-telemetry-rewire/validation/WVR-004-telem02-lint-scope.json'))
covered_hashes = []
for category in ['archived_files', 'lint_configurations']:
    for path, expected in scope[category].items():
        data = git('show', candidate + ':' + path)
        covered_hashes.append({'category': category, 'path': path, 'expected_sha256': expected, 'actual_sha256': sha(data), 'matches': sha(data) == expected})
registry_path = 'packages/friday-cli/src/friday_cli/commands.py'
registry = git('show', candidate + ':' + registry_path)
covered_hashes.append({'category': 'registry_source', 'path': registry_path, 'expected_sha256': scope['command_registry_source_sha256'], 'actual_sha256': sha(registry), 'matches': sha(registry) == scope['command_registry_source_sha256']})
listeners = json.loads(git('show', candidate + ':docs/planning/active/friday-telemetry-rewire/execution/TELEM-02-planning/listener-scope.json'))
listener_hashes = []
for path, expected in listeners['existing_fixture_hashes'].items():
    data = git('show', candidate + ':' + path)
    listener_hashes.append({'path': path, 'expected_sha256': expected, 'actual_sha256': sha(data), 'matches': sha(data) == expected})
proposal = 'db9223e68e11facc74d2b88853ab4c3a2eaeb17b'
git('diff', proposal + '..' + base, '--', 'docs/planning/active/friday-telemetry-rewire/directives/CD-002-A02-native-retry-disable.md')
git('diff', proposal + '..' + candidate, '--', 'docs/planning/active/friday-telemetry-rewire/directives/CD-002-A02-native-retry-disable.md')
checks['unchanged_scope_files'] = all(e['unchanged'] for e in unchanged_files)
checks['covered_object_hashes_match'] = all(e['matches'] for e in covered_hashes)
checks['listener_existing_hashes_match'] = all(e['matches'] for e in listener_hashes)
result = {'reviewer': '/root/telem02_a02_approved_readiness', 'model': 'GPT-6 Codex; exact model build unavailable', 'captured_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'request_sha256': sha(request_bytes), 'candidate': candidate, 'base': base, 'manifest_path': request['manifest_path'], 'manifest_sha256': sha(manifest_bytes), 'prior_manifest_sha256': sha(old_bytes), 'pins': pins, 'pin_delta': pin_delta, 'checks': checks, 'accepted_manifest_path': old_control, 'accepted_manifest_sha256': sha(old_control_data), 'accepted_pins': accepted_pins, 'unchanged_files': unchanged_files, 'covered_hashes': covered_hashes, 'listener_hashes': listener_hashes, 'listener_counts': {'existing': len(listeners['existing_nodes']), 'new': len(listeners['new_nodes'])}, 'wvr_counts': {'diagnostics': len(scope['diagnostics']), 'archive': scope['archive_count'], 'live': scope['live_count'], 'lint_configs': len(scope['lint_configurations'])}, 'wvr_registry_ast_pin': scope['command_registry_class_ast_sha256'], 'wvr_tool_pin': {'ruff': scope['ruff_version'], 'target': scope['target']}, 'receipts': receipts}
(out / 'capture.json').write_text(json.dumps(result, indent=2) + '\n')
(out / 'capture-script.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'checks': checks, 'pin_delta': pin_delta, 'counts': result['wvr_counts'], 'listener_counts': result['listener_counts'], 'receipts': len(receipts)}, indent=2))
