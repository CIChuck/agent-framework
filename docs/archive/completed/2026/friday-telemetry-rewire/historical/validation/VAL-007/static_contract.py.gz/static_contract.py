import ast,json,hashlib,subprocess,yaml
from pathlib import Path
out=Path('/private/tmp/telem-02/product-validation');root=out/'candidate';base=out/'base';sha=lambda b:hashlib.sha256(b).hexdigest();request=json.loads(Path('/private/tmp/telem-02/product-validation-request.json').read_text())
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(root),*args])
def model(path,name):
 c=next(x for x in ast.parse(path.read_text()).body if isinstance(x,ast.ClassDef) and x.name==name);return ast.dump(c,include_attributes=False)
def legacy_api(path,name):
 c=next(x for x in ast.parse(path.read_text()).body if isinstance(x,ast.ClassDef) and x.name==name);return {f.name:ast.dump(f.args,include_attributes=False) for f in c.body if isinstance(f,ast.FunctionDef) and f.name in ['__init__','start_span','end_span','capture_event']}
prefix='packages/friday-telemetry/src/friday_telemetry/'
assert model(root/(prefix+'config.py'),'TelemetryConfig')==model(base/(prefix+'config.py'),'TelemetryConfig')
assert (root/(prefix+'interface.py')).read_bytes()==(base/(prefix+'interface.py')).read_bytes()
assert legacy_api(root/(prefix+'providers/otel.py'),'OpenTelemetryProvider')==legacy_api(base/(prefix+'providers/otel.py'),'OpenTelemetryProvider')
for p in ['packages/friday-chat/src/friday_chat/config.py','packages/friday-telemetry/src/friday_telemetry/providers/composite.py']:
 assert (root/p).read_bytes()==(base/p).read_bytes()
changed=git('diff','--name-only',request['aggregate_diff']).decode().splitlines();python=[p for p in changed if p.endswith('.py') and (root/p).exists()];assert sorted(python)==sorted(request['expanded_targets']['aggregate_python'])
unit=git('diff','--name-only',request['unit_diff']).decode().splitlines();unitpython=[p for p in unit if p.endswith('.py') and (root/p).exists() and not p.startswith('docs/')];assert sorted(unitpython)==sorted(request['expanded_targets']['unit_python'])
product=git('diff','--name-only',request['product_commit_diff']).decode().splitlines();assert len(product)==13;assert sorted([p for p in product if p.endswith('.py')])==sorted(request['expanded_targets']['unit_python'])
syntax={p:sha((root/p).read_bytes()) for p in python};[ast.parse((root/p).read_text(),feature_version=(3,13)) for p in python]
for p in request['expanded_targets']['unit_source']:
 text=(root/p).read_text();assert '# mypy: ignore-errors' not in text;assert '# type: ignore' not in text;assert 'noqa' not in text
accepted=yaml.safe_load((root/request['accepted_manifest']).read_text());accepted_checks={a['path']:sha((root/a['path']).read_bytes())==a['sha256'] for a in accepted['authority']};assert all(accepted_checks.values())
assert (root/'uv.lock').read_bytes()==(base/'uv.lock').read_bytes()
for p in changed:
 if p.startswith('packages/') and ('config.example' in p or p.endswith('pyproject.toml')):assert p in git('diff','--name-only',request['aggregate_base']+'..'+request['unit_base']).decode().splitlines()
(out/'static-contract.json').write_text(json.dumps({'unit_product_paths':product,'aggregate_python_count':len(python),'unit_python_count':len(unitpython),'AST313':syntax,'legacy_API_unchanged':True,'legacyTelemetryConfig_unchanged':True,'acceptedChatConfig_Composite_unchanged':True,'source_suppressions_added':False,'accepted_manifest_hash':sha((root/request['accepted_manifest']).read_bytes()),'accepted_authority_hash_checks':accepted_checks,'additive_public_exports':True},indent=2));print('scope/AST/API/defaults/acceptedauthority verified')
