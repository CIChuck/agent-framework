import json
from packaging.specifiers import SpecifierSet
from pathlib import Path
s=SpecifierSet('>=3.13.4');assert '3.13.3' not in s and '3.13.4' in s and '3.13.10' in s
result={'minimum':'3.13.4','3.13.3':False,'3.13.4':True,'3.13.10':True,'actual_interpreter':'3.13.10','no_exactfloor_runtime_claim':True};print(json.dumps(result));Path('/private/tmp/telem-02/product-validation/floor-specifiers.json').write_text(json.dumps(result,indent=2))
