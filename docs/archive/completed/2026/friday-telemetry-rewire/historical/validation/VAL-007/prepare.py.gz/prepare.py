"""Read-only source/metadata baseline and fake-only probes; never activates SDK."""
from pathlib import Path
import ast
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time

REPO = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT = Path('/private/tmp/telem-02/product-validation')
GUARD = Path('/private/tmp/telem-01/REM-001/network-guard')
REVISIONS = {'preparation-base': 'e8b075a3861e1e3c1bfac050091a71be60b7e165', 'approved-candidate': 'd187ce35074697633108ef1e8ad5b404b0de9fcc'}
PREFIX = 'packages/friday-telemetry/src/friday_telemetry/'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-c', 'core.hooksPath=/dev/null', '-C', str(REPO), *args])

def protected(path):
    return any(path.startswith(p) for p in ['tests/integration/memory/.friday/', 'tests/integration/memory/vector/', 'tests/integration/memory/vector2_bak/', 'tests/integration/memory/vector_bak/', 'tests/integration/memory/.doltcfg/', 'experiments/provider_memory_smoke/memory/']) or '.friday' in Path(path).parts or Path(path).name == '.env'

def prepare(name, revision):
    root = OUT / name
    if root.exists():
        raise RuntimeError('Retain previous receipts: fresh snapshot required')
    names = git('ls-tree', '-r', '--name-only', revision).decode().splitlines()
    omitted = [p for p in names if protected(p)]
    if len(omitted) != 267 or any(p.endswith(('.py', '.toml', '.yaml', '.yml')) for p in omitted):
        raise RuntimeError('Protected path count or source/config intersection drift')
    subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', 'clone', '--shared', '--no-checkout', '--quiet', str(REPO), str(root)], check=True)
    subprocess.run(['git', '-C', str(root), 'config', 'core.sparseCheckout', 'true'], check=True)
    subprocess.run(['git', '-C', str(root), 'config', 'core.sparseCheckoutCone', 'false'], check=True)
    (root / '.git/info/sparse-checkout').write_text('/*\n' + ''.join('!/' + p + '\n' for p in omitted))
    subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', '-C', str(root), 'checkout', '--quiet', '--detach', revision], check=True)
    if any((root / p).exists() for p in omitted) or any((root / p).exists() for p in ['.env', '.friday', 'chroma_db']):
        raise RuntimeError('Protected runtime artifacts materialized')
    hashes = {p: sha((root / p).read_bytes()) for p in names if not protected(p) and (root / p).is_file()}
    receipt = dict(revision=revision, root=str(root), omitted_before_checkout=omitted, omitted_count=len(omitted), tracked_hashes=hashes, original_dirty_overlay=[], guard_sha256=sha((GUARD / 'sitecustomize.py').read_bytes()))
    save(name + '-snapshot.json', receipt)
    return root, receipt

def environment(root, label):
    tmp = OUT / 'tmp' / label
    tmp.mkdir(parents=True, exist_ok=True)
    return dict(PATH=f'{REPO}/.venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', UV_PROJECT_ENVIRONMENT=str(REPO / '.venv'), UV_CACHE_DIR=str(tmp / 'uv'), UV_NO_SYNC='true', UV_OFFLINE='true', UV_PYTHON_DOWNLOADS='never', LITELLM_LOCAL_MODEL_COST_MAP='true', ANONYMIZED_TELEMETRY='False', TERM='xterm-256color', PYTHONPATH=os.pathsep.join([str(GUARD)] + [str(p) for p in sorted((root / 'packages').glob('*/src'))] + [str(root / 'packages/friday-chat/tests_chat'), str(root)]), TMPDIR=str(tmp), PYTHONDONTWRITEBYTECODE='1', RUFF_CACHE_DIR=str(tmp / 'ruff'), MYPY_CACHE_DIR=str(tmp / 'mypy'))

def public_ast(path):
    tree = ast.parse(path.read_text(), feature_version=(3, 13))
    result = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            result[node.name] = {f.name: ast.unparse(f.args) for f in node.body if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef)) and not f.name.startswith('_') or isinstance(f, ast.FunctionDef) and f.name == '__init__'}
    return result

def source_baseline(root):
    selected = [PREFIX + p for p in ['interface.py', 'config.py', '__init__.py', 'providers/__init__.py', 'providers/otel.py', 'providers/debug.py', 'providers/composite.py']] + ['packages/friday-chat/src/friday_chat/config.py', 'packages/friday-telemetry/tests_telemetry/test_providers.py', 'packages/friday-telemetry/tests_telemetry/test_mcp_telemetry.py', 'packages/friday-telemetry/pyproject.toml', 'pyproject.toml', 'uv.lock']
    exports_tree = ast.parse((root / PREFIX / '__init__.py').read_text())
    exports = next(ast.literal_eval(n.value) for n in exports_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == '__all__' for t in n.targets))
    config = {}
    for rel, name in [(PREFIX + 'config.py', 'TelemetryConfig'), ('packages/friday-chat/src/friday_chat/config.py', 'ChatTelemetryConfig')]:
        cls = next(n for n in ast.parse((root / rel).read_text()).body if isinstance(n, ast.ClassDef) and n.name == name)
        config[name] = {n.target.id: dict(annotation=ast.unparse(n.annotation), default_expression=ast.unparse(n.value)) for n in cls.body if isinstance(n, ast.AnnAssign)}
    return dict(hashes={p: sha((root / p).read_bytes()) for p in selected}, public_exports=exports, api={p: public_ast(root / p) for p in [PREFIX + 'interface.py', PREFIX + 'providers/otel.py']}, legacy_default_expressions=config, missing_new_source=[PREFIX + p for p in ['lifecycle.py', 'factory.py', 'providers/_otel_processor.py', 'providers/_otel_exporter.py'] if not (root / PREFIX / p).exists()])

def metadata_baseline():
    packages = ['opentelemetry-api', 'opentelemetry-sdk', 'opentelemetry-exporter-otlp-proto-grpc', 'opentelemetry-exporter-otlp-proto-common', 'opentelemetry-proto', 'grpcio', 'protobuf', 'ruff', 'mypy', 'pydantic']
    versions = {}
    for name in packages:
        dist = importlib.metadata.distribution(name)
        metadata = dist.read_text('METADATA')
        versions[name] = dict(version=dist.version, metadata_sha256=sha(metadata.encode()), location=str(dist.locate_file('')))
    try:
        importlib.metadata.distribution('opentelemetry-exporter-otlp-proto-http')
        http_absent = False
    except importlib.metadata.PackageNotFoundError:
        http_absent = True
    site = Path(importlib.metadata.distribution('opentelemetry-sdk').locate_file(''))
    paths = ['opentelemetry/sdk/trace/__init__.py', 'opentelemetry/sdk/trace/export/__init__.py', 'opentelemetry/sdk/_shared_internal/__init__.py', 'opentelemetry/sdk/resources/__init__.py', 'opentelemetry/sdk/trace/sampling.py', 'opentelemetry/trace/__init__.py', 'opentelemetry/context/__init__.py', 'opentelemetry/exporter/otlp/proto/common/_internal/__init__.py', 'opentelemetry/exporter/otlp/proto/common/trace_encoder.py', 'opentelemetry/exporter/otlp/proto/common/_internal/trace_encoder/__init__.py', 'opentelemetry/exporter/otlp/proto/grpc/exporter.py', 'opentelemetry/exporter/otlp/proto/grpc/trace_exporter/__init__.py', 'opentelemetry/proto/collector/trace/v1/trace_service_pb2_grpc.py', 'grpc/__init__.py', 'grpc/_channel.py']
    return dict(python=sys.version, executable=sys.executable, versions=versions, http_exporter_absent=http_absent, sdk_sources={p: dict(sha256=sha((site / p).read_bytes()), api=public_ast(site / p)) for p in paths}, sdk_loaded_modules=[m for m in sys.modules if m.startswith(('opentelemetry', 'grpc'))])

def original_state():
    return dict(head=git('rev-parse', 'HEAD').decode().strip(), branch=git('branch', '--show-current').decode().strip(), index_sha256=sha((REPO / '.git/index').read_bytes()), status_names_hex=git('status', '--porcelain=v1', '-z').hex())

if __name__ == '__main__':
    save('original-before.json', original_state())
    save('tooling-and-sdk-source.json', metadata_baseline())
    for name, revision in REVISIONS.items():
        root, snapshot = prepare(name, revision)
        save(name + '-source-api.json', source_baseline(root))
        label = name + '-fake-probe'
        command = [str(REPO / '.venv/bin/python'), str(OUT / 'fake_probe.py'), str(root)]
        env = environment(root, label)
        started = time.time()
        result = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        (OUT / (label + '.stdout')).write_bytes(result.stdout)
        (OUT / (label + '.stderr')).write_bytes(result.stderr)
        unchanged = all(sha((root / p).read_bytes()) == h for p, h in snapshot['tracked_hashes'].items())
        save(label + '-receipt.json', dict(command=command, cwd=str(root), revision=revision, environment=env, exit_code=result.returncode, seconds=time.time() - started, stdout_sha256=sha(result.stdout), stderr_sha256=sha(result.stderr), tracked_unchanged=unchanged, probe_source_sha256=sha((OUT / 'fake_probe.py').read_bytes())))
        if result.returncode or not unchanged:
            raise RuntimeError('Probe or preservation failure; inspect private receipts')
    save('original-after.json', original_state())
    if json.loads((OUT / 'original-before.json').read_text()) != json.loads((OUT / 'original-after.json').read_text()):
        raise RuntimeError('Original metadata drift during baseline; controller reconciliation required')
    print('BASELINE COMPLETE: source/metadata and fake-only probes; no SDK activation or pytest')
