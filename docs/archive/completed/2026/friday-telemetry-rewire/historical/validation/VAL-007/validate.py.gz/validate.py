from pathlib import Path
import importlib.util,json,ast,hashlib,subprocess,sys,time
OUT=Path('/private/tmp/telem-02/product-validation');REPO=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
spec=importlib.util.spec_from_file_location('validator_prepare',OUT/'prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
r=json.loads(Path('/private/tmp/telem-02/product-validation-request.json').read_text())
def save(name,value):h.save(name,value)
def verify():
 assert h.sha(Path('/private/tmp/telem-02/product-validation-request.json').read_bytes())=='e5e0dd1c3c0894ad1dfd02008599b952b51375015c354a66743dcc0c81641685'
 assert h.git('rev-parse','HEAD').decode().strip()==r['candidate']
 for a in r['authority']:assert h.sha((REPO/a['path']).read_bytes())==a['sha256'],a
 assert h.sha((REPO/r['manifest_path']).read_bytes())==r['manifest_sha256']
 for p,v in r['frozen_target_hashes'].items():assert h.sha(h.git('show',r['candidate']+':'+p))==v,p
 assert h.sha((h.GUARD/'sitecustomize.py').read_bytes())=='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81'
def prepare():
 verify();save('original-before.json',h.original_state())
 save('authority-verified.json',r)
 root,receipt=h.prepare('candidate',r['candidate']);base,br=h.prepare('base',r['unit_base'])
 for p in [root,base]:
  (p/'pytest_source_audit.py').write_bytes((OUT/'pytest_source_audit.py').read_bytes())
  for lane in ['active','queued','review','blocked','deferred','backlog']:(p/'docs/planning'/lane).mkdir(exist_ok=True)
 freeze={}
 for p in sorted(root.rglob('*.py')):
  if '.git' in p.parts:continue
  rel=str(p.relative_to(root));tree=ast.parse(p.read_text(),feature_version=(3,13))
  freeze[rel]={'sha256':h.sha(p.read_bytes()),'imports':[ast.unparse(n) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))],'fixtures':[n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and any('fixture' in ast.unparse(d) for d in n.decorator_list)]}
 listener=json.loads((root/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-02-planning/listener-scope.json').read_text());assert len(listener['existing_nodes']+listener['new_nodes'])==13
 save('precollection-freeze.json',{'files':freeze,'listener_scope':listener,'helper_hashes':{p.name:h.sha(p.read_bytes()) for p in OUT.glob('*.py')},'all_conftests':[p for p in freeze if p.endswith('conftest.py')],'expected_effects':'Synthetic snapshot/private-temp writes; mock providers and fixture peers/PTY; exactly13 literal-loopback listeners; HTTPS fully mocked; no native guard completeness claim','native_interception':'test_otlp_collector.py collector fixture validates exact127.0.0.1 ephemeral target,4options,NoCompression,channel owner close,server/executor cleanup','environment':h.environment(root,'preflight')})
 for key in ['unit_diff','aggregate_diff','product_commit_diff']:(OUT/(key+'.patch')).write_bytes(h.git('diff',r[key]))
 save('preparation-complete.json',{'candidate':r['candidate'],'snapshot_hash':h.sha((OUT/'candidate-snapshot.json').read_bytes()),'freeze_hash':h.sha((OUT/'precollection-freeze.json').read_bytes())})
def run(label,args,name='candidate',timeout=600):
 verify();root=OUT/name;receipt=json.loads((OUT/(name+'-snapshot.json')).read_text());assert all(h.sha((root/p).read_bytes())==v for p,v in receipt['tracked_hashes'].items())
 env=h.environment(root,label);env['PYTEST_ADDOPTS']='-o cache_dir='+env['TMPDIR']+'/pytest'
 if args[0]=='pytest':args=args+['-p','pytest_source_audit','--source-audit-output='+str(OUT/(label+'-source-audit.json'))]
 cmd=['/opt/homebrew/bin/uv']+args[1:] if args[0]=='uv' else ['/opt/homebrew/bin/uv','run','--no-sync']+args
 assert not (OUT/(label+'.stdout')).exists();start=time.time()
 with (OUT/(label+'.stdout')).open('wb') as o,(OUT/(label+'.stderr')).open('wb') as e:
  res=subprocess.run(cmd,cwd=root,env=env,stdout=o,stderr=e,timeout=timeout)
 unchanged=all(h.sha((root/p).read_bytes())==v for p,v in receipt['tracked_hashes'].items());assert unchanged
 save(label+'-receipt.json',{'command':cmd,'cwd':str(root),'revision':receipt['revision'],'environment':env,'started_epoch':start,'finished_epoch':time.time(),'seconds':time.time()-start,'exit_code':res.returncode,'tracked_unchanged':unchanged,'stdout_sha256':h.sha((OUT/(label+'.stdout')).read_bytes()),'stderr_sha256':h.sha((OUT/(label+'.stderr')).read_bytes())})
 print(label,res.returncode,flush=True);print((OUT/(label+'.stdout')).read_text()[-1300:],flush=True);print((OUT/(label+'.stderr')).read_text()[-400:],flush=True)
 return res.returncode
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='gate':
  i=int(sys.argv[2]);run('gate-%02d'%i,r['mandatory_commands'][i])
 elif sys.argv[1]=='run':run(sys.argv[2],sys.argv[3:])
 elif sys.argv[1]=='baseline-gate':
  i=int(sys.argv[2]);run('baseline-gate-%02d'%i,r['mandatory_commands'][i],'base')
 elif sys.argv[1]=='base-ruff':run('base-ruff',['ruff','check','.','--output-format=json'],'base')
