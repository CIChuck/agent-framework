import sys,json,importlib.util
from pathlib import Path
s=importlib.util.spec_from_file_location('metadata_prepare','/private/tmp/telem-02/product-validation/prepare.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
print(json.dumps(h.metadata_baseline(),indent=2))
