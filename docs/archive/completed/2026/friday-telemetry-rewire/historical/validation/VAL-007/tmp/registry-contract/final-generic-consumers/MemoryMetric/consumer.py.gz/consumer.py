from original import MemoryMetric as Original
from final import MemoryMetric as Final
class Parent: pass
class Child(Parent): pass
def old_parent_child(value: Original[Parent]) -> Original[Child]:
    return value

def old_child_parent(value: Original[Child]) -> Original[Parent]:
    return value

def final_parent_child(value: Final[Parent]) -> Final[Child]:
    return value

def final_child_parent(value: Final[Child]) -> Final[Parent]:
    return value

