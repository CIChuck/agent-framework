from friday_core.interfaces.tools import ToolAdapter
class Parent: pass
class Child(Parent): pass
def parent_to_child(value: ToolAdapter[Parent]) -> ToolAdapter[Child]:
    return value
def child_to_parent(value: ToolAdapter[Child]) -> ToolAdapter[Parent]:
    return value
