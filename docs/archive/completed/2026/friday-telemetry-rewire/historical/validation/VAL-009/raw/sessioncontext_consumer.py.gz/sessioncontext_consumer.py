from friday_cli.session import SessionContext
class Parent: pass
class Child(Parent): pass
def parent_to_child(value: SessionContext[Parent]) -> SessionContext[Child]:
    return value
def child_to_parent(value: SessionContext[Child]) -> SessionContext[Parent]:
    return value
