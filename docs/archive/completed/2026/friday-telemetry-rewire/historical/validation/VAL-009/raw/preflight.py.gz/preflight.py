from pathlib import Path
import importlib.util,json,ast,hashlib,tomllib
P=Path('/private/tmp/telem-04/VAL-009');root=P/'candidate'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-04-planning/listener-scope.json').read_text())
for p,h in manifest['fixture_hashes'].items(): assert sha(root/p)==h,p
files=list(root.glob('packages/*/**/conftest.py'))+list(root.glob('experiments/*/tests/conftest.py'))
for f in files: ast.parse(f.read_text())
new=json.loads((root/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-04.yaml').read_text())['product_manifest']['new_tests']
for p in new:
 text=(root/p).read_text();assert not any(x in text for x in ('HTTPServer(','grpc.server(','PersistentClient(','TracerProvider(','BatchSpanProcessor(','socket.bind(')),p
preflight=dict(fixture_hashes={p:sha(root/p) for p in manifest['fixture_hashes']},existing_nodes=manifest['existing_nodes'],approved_by='CD-004-approval-record.md',nodes=len(manifest['existing_nodes']),conftest_hashes={str(f.relative_to(root)):sha(f) for f in files},new_tests_transport_fake_only=True,guard='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81',review='Native grpc literal127.0.0.1 finite OTLP deadline from bounded settings; channel_options retry0 proxy0; server/channel/executor explicitly owned and cleaned. HTTP listener loopback0 and server thread joined; finite timeouts and clean credential/proxy-free env. Existing source fixture imports inspected before collection.')
(P/'preflight.json').write_text(json.dumps(preflight,indent=2)+'\n');print('PREFLIGHT',len(files),'fixture helpers;13 exact approved nodes;6 fake-only new modules')
