from pathlib import Path
import json,hashlib,importlib.util,gzip,datetime
P=Path('/private/tmp/telem-04/VAL-009');root=P/'candidate'
spec=importlib.util.spec_from_file_location('h','/private/tmp/telem-02/builder-baseline/prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.OUT=P
metadata=json.loads((P/'command-tooling.stdout').read_text());frozen=json.loads((root/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-02-planning/source-inventory.json').read_text())
for p,pinned in frozen['sdk_source_hashes'].items():assert metadata['sdk_sources'][p]['sha256']==pinned,p
# Frozen pre-build evidence bytes verified; no builder conclusions/results used for verdict.
basepath=root/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-04-baseline';man=json.loads((basepath/'artifact-manifest.json').read_text());baseline=[]
for artifact in man['artifacts']:
 data=(basepath/artifact['stored']).read_bytes();assert h.sha(data)==artifact['stored_sha256'];assert h.sha(gzip.decompress(data))==artifact['original_sha256'];baseline.append(dict(path=artifact['stored'],stored_sha256=h.sha(data),original_sha256=artifact['original_sha256']))
# Receipt coverage confirms each approved loopback node actually ran, and only the permitted skip occurred.
command_results=[]
for i in range(1,19):
 r=json.loads((P/f'command-{i:02}-receipt.json').read_text());out=(P/f'command-{i:02}.stdout').read_bytes();err=(P/f'command-{i:02}.stderr').read_bytes();assert h.sha(out)==r['stdout_sha256'] and h.sha(err)==r['stderr_sha256'];assert r['exit_code']==(1 if i==8 else 0)
 text=out.decode();summary=text.splitlines()[-1] if text else ''
 command_results.append(dict(number=i,command=r['command'],cwd=r['cwd'],exit_code=r['exit_code'],summary=summary,seconds=r['seconds'],receipt=f'command-{i:02}-receipt.json'))
listeners=json.loads((root/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-04-planning/listener-scope.json').read_text())
for node in listeners['existing_nodes']:
 assert 'PASSED '+node in (P/'command-04.stdout').read_text(),node
for i in [1,2,4,5]:
 text=(P/f'command-{i:02}.stdout').read_text();skips=[line for line in text.splitlines() if line.startswith('SKIPPED')];assert skips==([] if i in [1,2] else ["SKIPPED [1] packages/friday-memory/tests_memory/test_adapters/test_graph.py:250: could not import 'scipy': No module named 'scipy'"])
preservation={}
for name in ['candidate','unit-base','aggregate-base']:
 receipt=json.loads((P/(name+'-snapshot.json')).read_text());changed=[p for p,v in receipt['tracked_hashes'].items() if h.sha((P/name/p).read_bytes())!=v];assert not changed;assert not any((P/name/p).exists() for p in receipt['omitted_before_checkout']);preservation[name]=dict(tracked_count=len(receipt['tracked_hashes']),tracked_unchanged=True,protected_absent=267)
after=h.original_state();h.save('original-after-r2.json',after);before=json.loads((P/'original-before.json').read_text())
for k in ['head','branch','index_sha256']:assert before[k]==after[k]
a=set(bytes.fromhex(before['status_names_hex']).decode().split('\0'));b=set(bytes.fromhex(after['status_names_hex']).decode().split('\0'))
expected='?? docs/planning/active/friday-telemetry-rewire/execution/TELEM-04-final/'
assert a<=b and b-a=={expected}
preservation['controller_storage_exception']=dict(added_untracked=expected,confirmed_by_controller=True,preexisting_status_entries_unchanged=True,head_index_branch_unchanged=True,private_conclusions_not_read=True)
h.save('final-reconciliation.json',dict(frozen_candidate=json.loads((P/'request.json').read_text())['candidate'],finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),snapshot_preservation=preservation,original_preserved=True,sdk_frozen_sources_matched=frozen['sdk_source_hashes'],prebuild_evidence_hashes=baseline,approved_effect_nodes_ran=13,command_results=command_results))
print('FINAL:18 required receipts valid;13 approved loopback nodes executed;only exact SciPy skip;all3 snapshots and original metadata unchanged;accepted SDK source pins match')
