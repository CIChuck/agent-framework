from pathlib import Path
import importlib.util,json,subprocess,sys,time,datetime,hashlib,ast,importlib.metadata
P=Path('/private/tmp/telem-04/VAL-009'); root=P/'candidate'
spec=importlib.util.spec_from_file_location('h','/private/tmp/telem-02/builder-baseline/prepare.py'); h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.OUT=P
request=json.loads((P/'request.json').read_text())
def run(i,cmd=None,cwd=root):
 args=request['required_commands'][i-1] if cmd is None else cmd
 command=['uv','run','--no-sync',*args] if args[0] not in ('git','uv') else args
 env=h.environment(cwd,'gate-'+str(i)); started=time.time()
 result=subprocess.run(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=900)
 stem='command-'+str(i).zfill(2)
 (P/(stem+'.stdout')).write_bytes(result.stdout);(P/(stem+'.stderr')).write_bytes(result.stderr)
 h.save(stem+'-receipt.json',dict(command=command,cwd=str(cwd),environment=env,exit_code=result.returncode,started_utc=datetime.datetime.fromtimestamp(started,datetime.timezone.utc).isoformat(),seconds=time.time()-started,stdout_sha256=h.sha(result.stdout),stderr_sha256=h.sha(result.stderr)))
 print(stem,'exit',result.returncode,'seconds',round(time.time()-started,2),flush=True)
if __name__=='__main__':
 for i in map(int,sys.argv[1:]): run(i)
