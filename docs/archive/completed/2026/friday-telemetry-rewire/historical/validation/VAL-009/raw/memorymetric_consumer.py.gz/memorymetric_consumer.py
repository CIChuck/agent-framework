from friday_chat.memory_views import MemoryMetric
class Parent: pass
class Child(Parent): pass
def parent_to_child(value: MemoryMetric[Parent]) -> MemoryMetric[Child]:
    return value
def child_to_parent(value: MemoryMetric[Child]) -> MemoryMetric[Parent]:
    return value
