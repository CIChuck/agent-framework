# CDR-019 — Approved CD-004 authority and WVR-006 reconciliation

Directive authority: **READY**.
Separate narrow lint renewal: **READY**.

Date: 2026-10-09. Reviewer: independent agent `/root/telem04_authority_reviewer`, a separate fresh context receiving the frozen review assignment and environment. Exact model/version is not exposed by this session; no more specific model identity is claimed. Mode: read-only authority/readiness reconciliation, not product `VERIFIED`, acceptance, aggregate product certification or delivery authorization. No delegated subagent was used.

## Frozen inputs and scope

Approved candidate: `b8d885f3a7e2665257047c7758fd33c94a3338e4`.
Original proposal: `1c463368a8d4b741111c28f7ee5210e5b7d26a48`.
Preparation/product base: `e6209e3156216afde1655758e280690229f7d3e6`.
Aggregate base: `2155a0fc51f5b20dea4e35c6cfc70f1d52002735`.
Branch: `feature/friday-telemetry-rewire`.
Reviewed authority diff: original proposal through approved candidate, preserved in `proposal-approved.diff`. Mandatory whitespace ranges: preparation base through approved candidate and aggregate base through approved candidate.

Read AGENTS.md and its three delegated repository policies; the approved 40-pin TELEM-04 manifest; CD-004, its approval record/evidence, execution contract, verification profile, WVR-006 disposition/scope and listener/source inventory; build/tactical plans and accepted telemetry/MCP contracts. Git's tracked inventory contains only the root AGENTS.md. `supplemental-inputs.json` records authority, tooling and Python-floor hashes. Pin validation is independent of historical statements in planning reports.

`static-reconciliation.json` demonstrates all 40 approved content pins match candidate Git blobs. All 38 original proposal pins match proposal Git blobs and are preserved exactly in CD-004 approval evidence. Approval keeps the original product manifest unchanged: nine existing plus three new source paths, nine existing plus six new test paths, two documentation paths, total 29. The manifest, original proposal, approval evidence and static source inventory agree. Nine new source/test paths remain absent at this candidate. The nine existing source hashes/public APIs match the inventory.

The proposal-to-approval diff is confined to 11 planning/board paths, with no package/product delta. Four changed authority documents reconcile status/approval wording; two approval records are added. The decision explicitly approves CD-004 and separately WVR-006, preserving scope, acceptance criteria and existing evidence. Frozen lint/listener/source/planning records intentionally retain their proposal-era labels; the current decision record supplies approval without rewriting frozen bytes. The manifest's retained “proposed” external-services text does not enlarge or revoke the precise approved 13-node inventory. No prior waiver/effect authority is inherited.

All 268 selected prior telemetry/MCP archive and earlier authority inputs compared between proposal and approved candidate remain byte-identical. Accepted TELEM-01–03 specifications/evidence are not rewritten. Board validate/next/show/render checks pass; current telemetry is started, granted, local and names the feature branch. Global `next` selects queued memory-v2; the explicit current maintainer/session direction supplies this telemetry slice and does not authorize memory-v2.

## Isolation and reproduced checks

`approved-snapshot-snapshot.json` pins every materialized tracked file and all 267 omitted protected paths. The supplied preparation helper omitted those paths in sparse configuration before checkout. No original dirty payloads, `.env`, `.friday`, Chroma/transcript runtime state or credentials were copied/read. Commands ran against the tracked snapshot under a credential-free allowlisted environment, offline/no-sync/no-download settings, private caches/temp roots, isolated source/helper PYTHONPATH, no inherited HOME/proxy/OTEL/GRPC/certificate variables and the accepted socket guard SHA256 `6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81`.

No source edits, product test collection/construction, SDK/exporter activation, provider calls, channel/listener/database creation, installation/sync/download or delivery action occurred. Pytest was invoked only for its installed version. The later controller message about behavioral probes was excluded from this readiness evidence.

| Check | Raw result | Receipt |
| --- | --- | --- |
| Installed Python/Ruff/Mypy/Pytest versions | Exit 0; 3.13.10 / 0.14.10 / 1.19.1 / 9.0.2 | `tool-*-receipt.json`, `source-resolution-receipt.json` |
| Ruff on exact nine prospective source paths | Exit 0 | `prospective-ruff-receipt.json` |
| Genuine Mypy --python-version 3.13 on same paths | Exit 0; no issues in 9 source files | `prospective-mypy-receipt.json` |
| Root Ruff JSON | **Exit 1; 327 findings** | `root-ruff-receipt.json`, raw stdout |
| Exact root identity and input reconciliation | 327 exact identities; zero new/missing | `lint-final-reconciliation.json` |
| Ruff resolved target | Exit 0; 3.13/py313 | `ruff-target-receipt.json` |
| Native uv offline lock check/no-download/no-build | Exit 0; unchanged lock | `lock-receipt.json` |
| Board validate/next/show/render --check | Each exit 0 | `board-*-receipt.json` |
| Documentation lifecycle | Exit 0 | `docs-receipt.json` |
| Unit/aggregate git diff --check | Each exit 0 | `unit-diff-receipt.json`, `aggregate-diff-receipt.json` |
| Tracked snapshot/protected omissions | Unchanged/absent | `snapshot-preservation.json` |
| Original HEAD/branch/index/status metadata | Before equals after | `original-before.json`, `original-after.json` |

All 18 project Python floors remain `>=3.13.4`. Tool source/distribution and executable hashes are preserved in source-resolution and supplemental input receipts. Raw commands, cwd, approved revision, allowlisted environment, UTC timing, exits and output hashes are retained, including the nonpassing root lint result.

## Separate WVR-006 disposition

The independently produced normalized root findings equal all 327 pinned identities on path/code/start/end/message. Exactly 326 belong to the four immutable archive probe files and one UP046 belongs to `packages/friday-cli/src/friday_cli/commands.py`. All four archive hashes and 17 lint configuration hashes match. The historical CLI CommandRegistry source SHA256 is `15992e7f38fe874f0104a164180679c7e76d7e09413d68152ef5cc77c0f99308`; class AST SHA256 is `34336e7c35b598b215dbb6d08e1150c2ef96e22d08cacc17b5f76e3f5be3f3e7`, both exact matches. Ruff version/target match 0.14.10/py313.

The first static receipt mistakenly selected the Chat registry rather than the historical CLI registry and recorded two mismatches. That raw receipt remains unchanged. `lint-final-reconciliation.json` corrects the inspection by deriving the CLI path from the pinned live lint identity and independently recomputes both hashes. This reviewer inspection error is not candidate drift. No lint failures were hidden or relabeled passing.

WVR-006 is independently READY only for its exact 327 historical identities and pinned inputs. It does not excuse changed-source/aggregate lint, typing, tests, privacy, lifecycle, any new identity or a suppression/config/exclusion. It expires at TELEM-04 acceptance or immediately on any pinned input drift. Root Ruff remains nonpassing.

## Contract feasibility and construction constraints

No unresolved higher-authority or package-scope conflict was found. CD-004 supplies a closed additive schema and typed correlation surface while preserving the three-method TelemetryInterface, accepted LLM/MCP payloads and caller-owned provider lifetime. The approved paths contain the actual turn, dispatch, persistence, background-origin and diagnostic boundaries; no change to shared LLM/MCP/storage/config/dependency APIs is required by the described observations.

The following are implementation obligations, not product evidence or extra authority:

- Use strict immutable/revalidated execution models and task-local owned context with token restoration. Retain accepted random/reference rules and scalar/count/float bounds; no raw content/ID/name/exception may enter exporter or local safe snapshots.
- Completion and streaming methods own the turn lifetime. Existing stream_process buffers through process_streaming before yielding, so the contract's prohibition on ambient spans across public async-generator yields is feasible without stream behavior changes. Exactly-once observations must mean emission attempts; sink delivery failure remains visible, consistent with accepted TELEM-03.
- Selection has its closed execution.selection snapshot. Do not invent an extra operation_kind outside the approved enum; a safe selection scope need not fabricate a dispatched memory/model/tool operation. Blocked selection/circuit calls still receive a terminal turn observation.
- Observe actual ToolLoop dispatch and accepted MCP status/provenance. Accepted coordination already exposes publication/pending/skipped/disabled through its typed observe callback and validated returned facts. Wrap only the existing outer persistence boundaries, retain completed earlier stages, and never infer publication or an unknown cancellation commit. Do not alter memory_mcp coordination or fake rollback behavior.
- Optional final correlation fields on TurnResult/PendingExtractionTurn and optional adapter observation preserve existing defaults/call shapes. PendingExtractionTurn survives requeue; adapters.py already owns the per-item extraction/cancel/committed-under-cancellation branches. Background entry must clear inherited foreground context and retain only explicit safe causal origin metadata.
- The installed accepted OTel provider owns a task-local span stack and validates live explicit parents. Ended foreground spans must remain causal references, not new SDK parents. Do not register globals, close/flush borrowed sinks or create new exporter lifetimes in application observation.
- Keep bounded validated terminal summaries, fixed closed counters/buckets and separate LLM/MCP accounting. Failed-turn inspection may use the observer snapshot without requiring TurnResult. Provider-required reasoning flags must be omitted unless an existing explicit typed policy supplies them.

The listener inventory contains exactly 13 existing nodes, 11 HTTP and two native gRPC, with no new node. All four pinned fixture/module hashes match. Static inspection confirms the native collector uses literal `127.0.0.1:0`, checked channel target/options and owned cleanup; its source and the accepted exporter remain unchanged. This authority review executes no listener and is not the final fixture/helper/import preflight. The controller must perform that preflight before later authorized loopback tests; no additional effect is granted here.

## Next gate and residual evidence

No numbered CHANGES_REQUESTED or BLOCKED finding remains for either readiness decision. The next authorized gate is the true fake-only pre-build baseline, then construction within the exact 29 paths. If the controller has separately completed that baseline, it must retain its own raw failures/reruns and report before editing. Construction must stop on input/scope/effect drift or any actual feasibility conflict rather than silently expand authority.

AC04-01–08 behavioral satisfaction is intentionally unverified here. The builder must freeze a stable product candidate and complete required checks, then obtain fresh-context read-only full unit and complete aggregate independent review. This READY result cannot support product completion, acceptance, push/merge/release/deployment/publication or vendor/live/credential/state access.
