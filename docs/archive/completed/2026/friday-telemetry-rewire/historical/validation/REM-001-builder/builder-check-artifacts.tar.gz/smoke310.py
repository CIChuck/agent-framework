from pathlib import Path
from collections import deque
from dataclasses import dataclass
from hashlib import sha256
from typing import Literal
from uuid import uuid4
from copy import deepcopy
import asyncio
import sys

assert sys.version_info[:2] == (3,10)
assert deque([1],maxlen=256).maxlen == 256
assert len(sha256('synthetic'.encode('utf-8',errors='surrogatepass')).hexdigest()) == 64
assert uuid4().hex
assert deepcopy({'nested': [1]}) == {'nested':[1]}
@dataclass(frozen=True)
class Local:
    outcome: Literal['success'] = 'success'
assert Local().outcome == 'success'
assert issubclass(asyncio.CancelledError, BaseException)
print('Python 3.10 stdlib API smoke passed')
from friday_chat.telemetry import ChatTelemetryObserver
from friday_telemetry import CompositeProvider, DebugTelemetryRecorder
first,second=DebugTelemetryRecorder(),DebugTelemetryRecorder()
composite=CompositeProvider([first,second])
parent=composite.start_span('parent'); child=composite.start_span('child',parent)
composite.end_span(child); composite.end_span(parent)
observer=ChatTelemetryObserver(enabled=True,session_id='synthetic')
observer.emit('runtime_ready')
assert observer.snapshot().events
print('Python 3.10 observer/composite import/lifecycle smoke passed')
