from pathlib import Path
import ast, hashlib, json, os, shutil, subprocess, sys, time

out=Path('/private/tmp/telem-01/REM-001')
role, name=sys.argv[1:3]
root=out/role
logdir=out/'checks'/role
logdir.mkdir(parents=True,exist_ok=True)
changed=subprocess.check_output(['git','diff','--name-only','2155a0fc51f5b20dea4e35c6cfc70f1d52002735..98cc9e74cf40320af08533f4915e394eecf39537','--','packages'],text=True,cwd=root).splitlines()
py=[p for p in changed if p.endswith('.py') and (root/p).exists()]
src=[p for p in py if '/src/' in p]
env={k:os.environ[k] for k in ['PATH','SYSTEMROOT'] if k in os.environ}
env.update(UV_PROJECT_ENVIRONMENT='/Users/chuckrussell/Dev/gendev/agent-framework/.venv',UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_NO_SYNC='true',UV_OFFLINE='true',LITELLM_LOCAL_MODEL_COST_MAP='true',ANONYMIZED_TELEMETRY='False',TERM='xterm-256color',TMPDIR=str(logdir/'tmp'),PYTHONPATH=os.pathsep.join([str(out/'network-guard'), *map(str,sorted(root.glob('packages/*/src')))]),PYTHONPYCACHEPREFIX=str(logdir/'pycache'),MYPY_CACHE_DIR=str(logdir/'mypy-cache'),RUFF_CACHE_DIR=str(logdir/'ruff-cache'))
Path(env['TMPDIR']).mkdir(exist_ok=True)
uv=[shutil.which('uv'),'run','--no-sync']
focused=['packages/friday-chat/tests_chat/test_telemetry.py','packages/friday-chat/tests_chat/test_cli.py','packages/friday-chat/tests_chat/test_runtime.py','packages/friday-chat/tests_chat/test_app_lifecycle.py','packages/friday-chat/tests_chat/compat/test_config_compatibility.py','packages/friday-telemetry/tests_telemetry/test_providers.py']
focused=[p for p in focused if (root/p).exists()]
commands={
 'focused':uv+['pytest','-p','no:cacheprovider',*focused],
 'packages':uv+['pytest','-p','no:cacheprovider','packages/friday-chat/tests_chat','packages/friday-telemetry/tests_telemetry'],
 'root-pytest':uv+['pytest','-p','no:cacheprovider','--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py'],
 'root-ruff':uv+['ruff','check','.'],
 'root-ruff-json':uv+['ruff','check','.','--output-format','json'],
 'loopback':uv+['pytest','-p','no:cacheprovider','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_chat_adapter_controls_reach_final_http_json','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_chat_adapter_typed_stream_reuses_generation_defaults','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_provider_option_target_mismatch_fails_before_http'],
 'root-pytest-importlib':uv+['pytest','-p','no:cacheprovider','--import-mode=importlib','--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py'],
 'collision':uv+['pytest','-p','no:cacheprovider',str(out/'test_collision.py'),'-k','TestCompositeReusedIds'],
 'independent':uv+['pytest','-p','no:cacheprovider','/private/tmp/telem-01/VAL-001/test_independent.py'],
 'ruff':uv+['ruff','check',*py],
 'mypy310':uv+['mypy','--python-version','3.10',*src],
 'mypy313':uv+['mypy','--python-version','3.13',*src],
 'pty':uv+['pytest','-p','no:cacheprovider','packages/friday-chat/tests_chat/test_reorganization_terminal.py::test_provider_free_pty_acknowledges_before_bounded_progress_completes'],
 'syntax310':uv+['python',str(out/'syntax310.py'),*src],
}
cmd=commands[name]
started=time.time()
with (logdir/(name+'.log')).open('w') as f:
    result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
data={'role':role,'name':name,'command':cmd,'cwd':str(root),'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'exit_code':result.returncode,'seconds':time.time()-started,'changed_python':py,'changed_source':src,'input_hashes':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in py},'worktree_status':subprocess.check_output(['git','status','--short'],cwd=root,text=True),'environment':env,'NO_COLOR_present':False,'label':'retrospective preparation-base' if role=='preparation-base' else role}
(logdir/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:data[k] for k in ['role','name','exit_code','seconds']}))
print((logdir/(name+'.log')).read_text()[-3500:])
