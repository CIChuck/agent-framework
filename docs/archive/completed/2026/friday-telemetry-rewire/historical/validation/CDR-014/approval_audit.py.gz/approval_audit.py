from review_runner import *

prev = REQ['previous_candidate']
names = ['telem02-contract.md', 'verification-profile-TELEM-02.md', 'validation/WVR-004-telem02-lint-disposition.md']
expected = {}
for name in names:
    old = blob(prev, PKT + name).decode()
    new = blob(REQ['candidate'], PKT + name).decode()
    adjusted = old.replace('Status: proposal; not approved.', 'Status: approved by Chuck Russell.')
    if name == 'telem02-contract.md':
        adjusted = adjusted.replace('# TELEM-02 proposed adapter', '# TELEM-02 approved adapter').replace('explicitly proposed\nnormal-user', 'explicitly approved\nnormal-user')
    elif name.startswith('verification'):
        adjusted = adjusted.replace('# Proposed TELEM-02', '# Approved TELEM-02').replace('Only proposed normal-user', 'Only approved normal-user')
    else:
        adjusted = adjusted.replace('# WVR-004 proposal:', '# WVR-004 approved disposition:')
    expected[name] = dict(only_approval_labels_changed=adjusted == new, old_sha256=sha(old.encode()), new_sha256=sha(new.encode()))

directive = 'directives/CD-002-otel-adapter-lifecycle.md'
old = blob(prev, PKT + directive).decode().split('## Exact proposed product manifest', 1)[1]
new = blob(REQ['candidate'], PKT + directive).decode().split('## Exact approved product manifest', 1)[1]
adjusted = old.replace('## Security, ownership and proposed execution permissions', '## Security, ownership and approved execution permissions').replace('If approved, permit normal-user', 'Under this approval, permit normal-user').replace('is separately approved. No inherited', 'is separately approved in the linked approval record. No inherited').replace('approved by this proposal.', 'approved by this directive.')
expected[directive] = dict(product_scope_criteria_permissions_gates_stop_unchanged=adjusted == new)

scope = json.loads(blob(REQ['candidate'], REQ['lint_scope']))
listener_path = PKT + 'execution/TELEM-02-planning/listener-scope.json'
listener = json.loads(blob(REQ['candidate'], listener_path))
all_hashes = dict(scope['archived_files'], **scope['lint_configurations'])
all_hashes['packages/friday-cli/src/friday_cli/commands.py'] = scope['command_registry_source_sha256']
baseline_hashes = {p: sha(blob(REQ['base'], p)) == h for p, h in all_hashes.items()}
history = []
for sub in ['validation/CDR-012/', 'validation/CDR-013/']:
    m = json.loads(blob(REQ['candidate'], PKT + sub + 'artifact-manifest.json'))
    for item in m['files']:
        stored = blob(REQ['candidate'], PKT + sub + item['stored'])
        raw = gzip.decompress(stored) if item['stored'].endswith('.gz') else stored
        history.append(dict(path=PKT + sub + item['stored'], stored_matches=sha(stored) == item['stored_sha256'], original_matches=sha(raw) == item['original_sha256']))
previous_paths = git('ls-tree', '-r', '--name-only', prev, '--', PKT + 'validation/CDR-012/').decode().splitlines()
previous_unchanged = {p: blob(prev, p) == blob(REQ['candidate'], p) for p in previous_paths}
scope_unchanged = {p: blob(prev, p) == blob(REQ['candidate'], p) for p in [REQ['lint_scope'], listener_path]}
save('approval-reconciliation.json', dict(comparisons=expected, exact_scope_inventories_unchanged=scope_unchanged, active_statuses={'lint_scope': scope['status'], 'listener_scope': listener['status']}, baseline_covered_hashes=baseline_hashes, original_CDR012_unchanged=previous_unchanged, prior_reviews_storage=history, history_all_hashes_match=all(x['stored_matches'] and x['original_matches'] for x in history)))
(OUT/'approval.delta').write_bytes(git('diff', prev, REQ['candidate']))
for n in ['candidate', 'baseline']:
    root = OUT/n
    record = json.loads((OUT/(n+'-snapshot.json')).read_text())
    save(n+'-snapshot-final.json', dict(unchanged=all(sha((root/p).read_bytes()) == h for p, h in record['tracked'].items()), protected_absent=all(not(root/p).exists() for p in record['omitted'])))
save('original-final.json', original())
print(json.dumps(dict(label_comparisons=expected, scope_statuses={'lint_scope': scope['status'], 'listener_scope': listener['status']}, baseline_hashes_match=all(baseline_hashes.values()), history_entries=len(history), history_matches=all(x['stored_matches'] and x['original_matches'] for x in history), prior_CDR012_unchanged=all(previous_unchanged.values())), indent=2))
