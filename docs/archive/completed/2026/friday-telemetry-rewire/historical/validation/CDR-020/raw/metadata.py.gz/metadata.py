from pathlib import Path
import importlib.util,json
P=Path('/private/tmp/telem-04/REM-005/readiness');s=importlib.util.spec_from_file_location('h',P/'prepare.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
print(json.dumps(h.metadata_baseline(),indent=2))
