"""Read only selected frozen Git/docs inputs; write receipts only beside this file."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT = Path('/private/tmp/telem-02/a02-proposal-review')
BASE = '95949e49df7b55f8da391a47f6df67cc2ff8e5ce'
CANDIDATE = 'db9223e68e11facc74d2b88853ab4c3a2eaeb17b'
PREFIX = 'docs/planning/active/friday-telemetry-rewire/'
PROPOSAL = PREFIX + 'directives/CD-002-A02-native-retry-disable.md'
MANIFEST = PREFIX + 'authority-manifest-TELEM-02.yaml'

def git(*args):
    result = subprocess.run(['git', *args], cwd=ROOT, capture_output=True, check=True)
    return result.stdout

def blob(revision, path):
    return git('show', revision + ':' + path)

def sha(data):
    return hashlib.sha256(data).hexdigest()

OUT.mkdir(parents=True, exist_ok=True)
manifest_bytes = blob(CANDIDATE, MANIFEST)
manifest = json.loads(manifest_bytes)
inputs = []
for entry in manifest['authority']:
    path = entry['path']
    candidate = blob(CANDIDATE, path)
    base = blob(BASE, path)
    current = (ROOT / path).read_bytes()
    inputs.append({
        'path': path, 'expected_sha256': entry['sha256'],
        'candidate_sha256': sha(candidate), 'base_sha256': sha(base),
        'current_control_sha256': sha(current),
        'matches_pin': sha(candidate) == entry['sha256'],
        'base_candidate_current_equal': base == candidate == current,
    })
for path in [MANIFEST, PROPOSAL, 'uv.lock', PREFIX + 'execution/TELEM-02-planning/source-inventory.json']:
    candidate = blob(CANDIDATE, path)
    receipt = {'path': path, 'candidate_sha256': sha(candidate), 'git_blob': git('rev-parse', CANDIDATE + ':' + path).decode().strip()}
    if path in [MANIFEST, PROPOSAL]:
        receipt['current_control_sha256'] = sha((ROOT / path).read_bytes())
        receipt['current_equal_candidate'] = (ROOT / path).read_bytes() == candidate
    inputs.append(receipt)
changed = git('diff', '--name-status', BASE, CANDIDATE).decode()
diff = git('diff', '--binary', BASE, CANDIDATE)
check = subprocess.run(['git', 'diff', '--check', BASE, CANDIDATE], cwd=ROOT, capture_output=True)
(OUT / 'exact.diff').write_bytes(diff)
(OUT / 'proposal.numbered.txt').write_text(''.join(f'{i}: {line}\n' for i, line in enumerate(blob(CANDIDATE, PROPOSAL).decode().splitlines(), 1)))
excerpts = {}
for path, needles in {
    PREFIX + 'telem02-contract.md': ['no implicit retries', 'channel options are', 'limited to grpc.enable_http_proxy', 'Two exact test nodes', 'socket guard', 'Remote HTTPS', 'No real'],
    PREFIX + 'directives/CD-002-otel-adapter-lifecycle.md': ['new nodes', 'Under this approval', 'No install', 'WVR-004', 'readiness review'],
    PREFIX + 'verification-profile-TELEM-02.md': ['Native gRPC', 'All HTTPS', 'Only approved', '327', 'Documentation-only'],
    PREFIX + 'directives/CD-002-approval-record.md': ['approved', 'It does not approve', 'Expiry'],
}.items():
    lines = blob(CANDIDATE, path).decode().splitlines()
    selected = set()
    for index, line in enumerate(lines):
        if any(needle.lower() in line.lower() for needle in needles):
            selected.update(range(max(0, index - 1), min(len(lines), index + 4)))
    excerpts[path] = [{'line': index + 1, 'text': lines[index]} for index in sorted(selected)]
(OUT / 'authority-excerpts.json').write_text(json.dumps(excerpts, indent=2) + '\n')
listener = json.loads(blob(CANDIDATE, PREFIX + 'execution/TELEM-02-planning/listener-scope.json'))
evidence = {
    'reviewer': '/root/telem02_a02_proposal_review',
    'model': 'GPT-6 family; exact runtime model/version not exposed',
    'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'review_mode': 'fresh independent read-only prospective proposal approval readiness; not product verification',
    'base': BASE, 'candidate': CANDIDATE, 'diff_range': BASE + '..' + CANDIDATE,
    'verdict': 'READY', 'findings': [],
    'changed_paths_receipt': changed,
    'diff_sha256': sha(diff),
    'diff_check_exit': check.returncode,
    'diff_check_stdout': check.stdout.decode(), 'diff_check_stderr': check.stderr.decode(),
    'input_hashes': inputs,
    'authority_pin_count': len(manifest['authority']),
    'all_pins_match': all(entry['matches_pin'] for entry in inputs if 'matches_pin' in entry),
    'all_pinned_controls_base_candidate_current_equal': all(entry['base_candidate_current_equal'] for entry in inputs if 'base_candidate_current_equal' in entry),
    'manifest_base_candidate_current_equal': blob(BASE, MANIFEST) == manifest_bytes == (ROOT / MANIFEST).read_bytes(),
    'listener_count': len(listener['existing_nodes']) + len(listener['new_nodes']),
    'native_node_ids': listener['new_nodes'],
    'existing_approvals': 'CD-002 and separately WVR-004 remain valid within their exact current scope. A02 is not approved or controlling.',
    'known_independent_work': 'Controller disclosed builder product edits continuing outside affected OTLP gate. Uncommitted product files and whole-worktree status were deliberately not inspected. Review binds only frozen proposal delta and approved controls.',
    'approval_gate': 'Explicit maintainer approval; reconcile contract/directive/profile and current-unit hashes; fresh approved-amendment readiness; only then implement option or run native OTLP tests.',
    'activation': 'None. No SDK import, test collection/test run, native channel/listener/provider, credentials/runtime state, original writes/staging/commit/environment mutation, install/sync/download/build, or protected snapshot checkout.',
    'source_access': 'Read-only official-source browsing only; no local source download or original environment mutation.',
    'reproduction': ['python3 /private/tmp/telem-02/a02-proposal-review/audit.py', 'git diff --name-status ' + BASE + ' ' + CANDIDATE, 'git diff --check ' + BASE + ' ' + CANDIDATE],
    'primary_source_receipts': [
        {'url': 'https://github.com/grpc/grpc/blob/v1.67.1/include/grpc/impl/channel_arg_names.h', 'raw_url': 'https://raw.githubusercontent.com/grpc/grpc/v1.67.1/include/grpc/impl/channel_arg_names.h', 'web_source_lines_zero_based': '301-310', 'observed': 'Version-pinned header documents default enabled retries, both transparent and service-configured, under GRPC_ARG_ENABLE_RETRIES.', 'quote': 'Enables retry functionality. Defaults to true.', 'symbol': '#define GRPC_ARG_ENABLE_RETRIES "grpc.enable_retries"'},
        {'url': 'https://grpc.io/docs/guides/retry/', 'web_source_lines_zero_based': '137-145', 'observed': 'Official guide says default transparent retries remain without a policy; channel-level disablement prevents transparent and policy retries.', 'quote': 'disables transparent retries and any configured retry policies'},
    ],
    'limits': 'This evidence establishes proposal necessity and required future verification, not runtime behavior of any future implementation. Native retry fault injection is neither executed nor granted; HTTPS remains mocked and Python socket guards do not comprehensively intercept native gRPC. No product VERIFIED/acceptance/live activation claim.',
}
(OUT / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
print(json.dumps({key: evidence[key] for key in ['verdict', 'authority_pin_count', 'all_pins_match', 'all_pinned_controls_base_candidate_current_equal', 'manifest_base_candidate_current_equal', 'listener_count', 'diff_check_exit', 'changed_paths_receipt']}, indent=2))
