from review_runner import *
import review_runner as runner
import sys, tomllib

candidate, previous, base = REQ['candidate'], REQ['previous_candidate'], REQ['base']
assert sys.version_info[:3] == (3, 13, 10)
def current(p): return blob(candidate, p)
def record(name, value): save(name + '.json', value); return value
def same(p, rev=previous): return blob(rev,p)==current(p)
manifest=json.loads(current(REQ['manifest_path']))
record('manifest-consistency',dict(authority_matches=manifest['authority']==REQ['authority'],count=len(manifest['authority']),base_matches=manifest['base']==base,branch=manifest['branch'],status=manifest['status'],approval_record_matches=manifest['approval_record']==REQ['approval_record']))

json_checks=[]
for p in [REQ['lint_scope'], PKT+'execution/TELEM-02-planning/listener-scope.json']:
    old=json.loads(blob(previous,p)); new=json.loads(current(p))
    oldstatus=old.pop('status'); newstatus=new.pop('status')
    json_checks.append(dict(path=p,old_status=oldstatus,new_status=newstatus,non_status_exact=old==new))
record('json-status-equivalence',json_checks)

replacements={
'README.md':[('permissions are proposed explicitly.','permissions are approved explicitly.')],
'directives/CD-002-otel-adapter-lifecycle.md': [('findings are unwaived for this new unit unless [WVR-004](../validation/WVR-004-telem02-lint-disposition.md)\nis separately approved in the linked approval record.', 'findings are covered only by separately approved [WVR-004](../validation/WVR-004-telem02-lint-disposition.md)\nin the linked approval record, with exact identity/hash reproduction required.')],
'telem02-contract.md':[('Intentional corrections requiring CD-002 approval:', 'Intentional corrections approved under CD-002:'), ('allowed by the proposed production','allowed by the approved production')],
'verification-profile-TELEM-02.md':[('The proposal candidate','The candidate'), ('The corrected327 remain unwaived current-unit debt\nuntil WVR-004 receives separate explicit approval. If approved, independently match', 'The corrected327 are separately approved current-unit debt under WVR-004. Independently match')],
'validation/WVR-004-telem02-lint-disposition.md':[('TELEM-02 / proposed CD-002 only.', 'TELEM-02 / approved CD-002 only.'), ('not covered by this proposal.', 'not covered by this disposition.'), ('Only if the maintainer explicitly approves this proposal may raw root Ruff','Under the recorded separate maintainer approval, raw root Ruff may'), ('is waived. Without separate WVR-004 approval, raw root lint remains a blocking\nTELEM-02 acceptance gate. CD-002 approval alone supplies no lint exception.', 'is waived. CD-002 approval alone supplies no lint exception; the recorded separate\nWVR-004 approval supplies only this exact temporary TELEM-02 disposition.')]
}
prose=[]
for name, substitutions in replacements.items():
    p=PKT+name; original=blob(previous,p).decode(); adjusted=original
    for old,new in substitutions:
        assert old in adjusted,(p,old)
        adjusted=adjusted.replace(old,new)
    prose.append(dict(path=p,only_declared_approval_wording_changes=adjusted==current(p).decode(),before_sha256=sha(original.encode()),after_sha256=sha(current(p))))
record('prose-equivalence',prose)

scope=json.loads(current(REQ['lint_scope']))
def normalized(label):
    root=OUT/label
    return [dict(path=str(Path(d['filename']).relative_to(root)),code=d['code'],location=d['location'],end_location=d['end_location'],message=d['message']) for d in json.loads((OUT/(label+'-root-ruff.stdout')).read_text())]
def identities(rows): return collections.Counter(json.dumps(d,sort_keys=True) for d in rows)
actual=identities(normalized('candidate')); expected=identities(scope['diagnostics']); baseline=identities(normalized('baseline'))
registry='packages/friday-cli/src/friday_cli/commands.py'
node=next(n for n in ast.parse(current(registry),feature_version=(3,13)).body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry')
covered=dict(scope['archived_files'],**scope['lint_configurations']);covered[registry]=scope['command_registry_source_sha256']
pack=json.loads(current(REQ['packaging_record']))
removed=baseline-actual
removed_paths=collections.Counter(json.loads(k)['path'] for k,n in removed.items() for _ in range(n))
record('lint-analysis',dict(interpreter=sys.version,counts=dict(candidate=sum(actual.values()),baseline=sum(baseline.values()),approved=sum(expected.values()),removed=sum(removed.values())),exact_multiset=actual==expected,extra=list((actual-expected).elements()),missing=list((expected-actual).elements()),archive_count=len(scope['archived_files']),config_count=len(scope['lint_configurations']),covered_hashes={p:dict(candidate=sha(current(p))==h,base=sha(blob(base,p))==h,previous=sha(blob(previous,p))==h) for p,h in covered.items()},registry_ast_matches=sha(ast.dump(node,include_attributes=False).encode())==scope['command_registry_class_ast_sha256'],removed_only_packaged_scripts=set(removed_paths)==set(pack['files']),packaging_diagnostic_counts_match=all(removed_paths[p]==v['diagnostics_removed_from_discovery'] for p,v in pack['files'].items()),ruff_version=scope['ruff_version'],target=scope['target']))

listener=json.loads(current(PKT+'execution/TELEM-02-planning/listener-scope.json'))
record('listener-analysis',dict(existing_count=len(listener['existing_nodes']),new_count=len(listener['new_nodes']),unique_count=len(set(listener['existing_nodes']+listener['new_nodes'])),effects=listener['effects'],fixture_hashes={p:sha(current(p))==h for p,h in listener['existing_fixture_hashes'].items()},new_nodes=listener['new_nodes'],final_precollection_freeze_required=True))

accepted=[]
for sub in ['execution/REM-004-final/','validation/VAL-006/']:
    for p in git('ls-tree','-r','--name-only',base,'--',PKT+sub).decode().splitlines():
        old=blob(base,p)
        if p in pack['files']: new=gzip.decompress(current(pack['files'][p]['storage']));kind='gzip preserved'
        elif p==PKT+sub+'artifact-manifest.json':new=current(PKT+sub+'artifact-manifest.pre-packaging.json');kind='original manifest preserved'
        else:new=current(p);kind='unchanged'
        accepted.append(dict(path=p,kind=kind,preserved=old==new,original_sha256=sha(old)))
record('accepted-artifact-preservation',dict(count=len(accepted),all_preserved=all(x['preserved'] for x in accepted),files=accepted))
hashes=[]
for sub in ['execution/REM-004-final/','validation/VAL-006/']:
    m=json.loads(current(PKT+sub+'artifact-manifest.json'))
    for p,d in m.items():
        stored=current(PKT+sub+p);raw=gzip.decompress(stored) if p.endswith('.gz') else stored
        hashes.append(dict(path=PKT+sub+p,stored_matches=sha(stored)==d['sha256'],original_matches=sha(raw)==d.get('original_sha256',sha(raw))))
record('accepted-storage-hashes',dict(count=len(hashes),all_match=all(x['stored_matches'] and x['original_matches'] for x in hashes),files=hashes))
history=[]; histories=[]
for sub in ['validation/CDR-012/','validation/CDR-013/','validation/CDR-014/']:
    for entry in json.loads(current(PKT+sub+'artifact-manifest.json'))['files']:
        stored=current(PKT+sub+entry['stored']); raw=gzip.decompress(stored) if entry['stored'].endswith('.gz') else stored
        history.append(dict(path=PKT+sub+entry['stored'],stored_matches=sha(stored)==entry['stored_sha256'],original_matches=sha(raw)==entry['original_sha256']))
    reportp=PKT+sub+'report.md'
    if sub.endswith('CDR-014/'):
        preserved=current(reportp)==Path('/private/tmp/telem-02/approved-readiness/report.md').read_bytes(); comparison='original prior-review output'
    else:preserved=same(reportp);comparison='previous candidate'
    histories.append(dict(path=reportp,preserved=preserved,comparison=comparison,sha256=sha(current(reportp))))
record('historical-review-preservation',dict(count=len(history),all_storage_match=all(x['stored_matches'] and x['original_matches'] for x in history),reports=histories,files=history,prior_CDR012_CDR013_files_unchanged={p:same(p) for p in git('ls-tree','-r','--name-only',previous,'--',PKT+'validation/CDR-012/',PKT+'validation/CDR-013/').decode().splitlines()}))

inventory=json.loads(current(PKT+'execution/TELEM-02-planning/source-inventory.json'))
sdkroot=REPO/'.venv/lib/python3.13/site-packages'
prior_sdk=json.loads(current(PKT+'validation/CDR-014/installed-source-evidence.json'))
sdkhashes={p:sha((sdkroot/p).read_bytes()) for p in prior_sdk['module_hashes']}
versions={}
for name in prior_sdk['versions']:
    found=list(sdkroot.glob(name+'-*.dist-info/METADATA'));assert len(found)==1,name
    versions[name]=next(line[9:] for line in found[0].read_text().splitlines() if line.startswith('Version: '))
lock=tomllib.loads(current('uv.lock').decode()); pins={d['name']:d['version'] for d in lock['package'] if d['name'].startswith('opentelemetry')}
record('source-sdk-baseline-preservation',dict(sdk_source_hashes=sdkhashes,all_17_sdk_hashes_match_frozen_prior=sdkhashes==prior_sdk['module_hashes'],versions=versions,versions_match_frozen_prior=versions==prior_sdk['versions'],inventory_sdk_hashes={p:sdkhashes[p]==h for p,h in inventory['sdk_source_hashes'].items()},source_hashes={p:sha(current(p))==h for p,h in inventory['source_hashes'].items()},lock_pins={p:pins.get(p)==v for p,v in inventory['lock_otel_pins'].items()},source_inventory_unchanged=same(PKT+'execution/TELEM-02-planning/source-inventory.json'),no_sdk_import_or_activation=True))

changed=git('diff','--name-only',REQ['diff']).decode().splitlines(); files=[]
for p in changed:
    assert p.startswith('docs/planning/'),p
    present=True
    try:raw=current(p)
    except subprocess.CalledProcessError:raw=blob(base,p);present=False
    stored=raw
    if p.endswith('.gz'):raw=gzip.decompress(raw)
    if p.endswith('.json'):json.loads(raw)
    if p.endswith(('.py','.py.gz')):ast.parse(raw,feature_version=(3,13))
    files.append(dict(path=p,present=present,stored_sha256=sha(stored),raw_sha256=sha(raw),bytes=len(stored)))
record('full-diff-inventory',dict(count=len(files),all_paths_planning=True,files=files))
(OUT/'remediation.diff').write_bytes(git('diff',previous,candidate))
for label,revision_range in [('diff-check',REQ['diff']),('remediation-diff-check',previous+'..'+candidate)]:
    cmd=['git','--no-optional-locks','-C',str(REPO),'diff','--check',revision_range]
    r=subprocess.run(cmd,capture_output=True);(OUT/(label+'.stdout')).write_bytes(r.stdout);(OUT/(label+'.stderr')).write_bytes(r.stderr)
    save(label+'.json',dict(command=cmd,exit_code=r.returncode,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr)))
for label,args in [('tool-python',['python','--version']),('tool-ruff',['ruff','--version']),('tool-mypy',['mypy','--version'])]:run(OUT/'candidate',label,args)
for name in ['candidate','baseline']:
    root=OUT/name; rec=json.loads((OUT/(name+'-snapshot.json')).read_text())
    save(name+'-snapshot-final.json',dict(unchanged=all(sha((root/p).read_bytes())==h for p,h in rec['tracked'].items()),protected_absent=all(not(root/p).exists() for p in rec['omitted'])))
before=json.loads((OUT/'original-before.json').read_text());after=runner.original();save('original-final.json',after)
record('original-preservation',dict(head_unchanged=before['head']==after['head'],branch_unchanged=before['branch']==after['branch'],index_unchanged=before['index_sha256']==after['index_sha256'],exact_porcelain_unchanged=before['status_hex']==after['status_hex'],untracked_payloads_uninspected=True))
print(json.dumps(dict(json_non_status_exact=all(x['non_status_exact'] for x in json_checks),prose_exact=all(x['only_declared_approval_wording_changes'] for x in prose),lint_exact=actual==expected,accepted_preserved=all(x['preserved'] for x in accepted),prior_storage_match=all(x['stored_matches'] and x['original_matches'] for x in history),reports_preserved=all(x['preserved'] for x in histories),sdk_match=sdkhashes==prior_sdk['module_hashes'],changed_paths=len(files),original_unchanged=before==after),indent=2))
