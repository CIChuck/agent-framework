from pathlib import Path
import json,ast,hashlib,tomllib,subprocess,re
import prepare_validator as p
root=p.OUT/'candidate';base=p.OUT/'unit-base';aggregate=p.OUT/'aggregate-base'
waiver=json.loads((root/'docs/planning/active/friday-telemetry-rewire/validation/WVR-006-telem04-lint-scope.json').read_text())
raw=json.loads((p.OUT/'command-08-sandbox.stdout').read_text())
fields=('code','location','end_location','message')
actual=[{**{k:d[k] for k in fields},'path':str(Path(d['filename']).relative_to(root))} for d in raw]
key=lambda d:json.dumps(d,sort_keys=True)
assert sorted(map(key,actual))==sorted(map(key,waiver['diagnostics'])) and len(actual)==327
hashes={}
for group in ('archived_files','lint_configurations'):
 hashes[group]={k:p.sha((root/k).read_bytes())==h for k,h in waiver[group].items()};assert all(hashes[group].values())
rel='packages/friday-cli/src/friday_cli/commands.py';tree=ast.parse((root/rel).read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry');a=p.sha(ast.dump(cls,include_attributes=False).encode())
assert p.sha((root/rel).read_bytes())==waiver['command_registry_source_sha256'];assert a==waiver['command_registry_class_ast_sha256'];assert waiver['target']=='py313'
inventory=[]
for rel in p.REQUEST['exact_scopes']['aggregate_python']:
 b=(root/rel).read_bytes();t=ast.parse(b,feature_version=(3,13));prior=ast.parse((aggregate/rel).read_bytes(),feature_version=(3,13)) if (aggregate/rel).exists() else ast.Module(body=[],type_ignores=[])
 def symbols(t):return {n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))}
 now,old=symbols(t),symbols(prior);inventory.append(dict(path=rel,source_sha256=p.sha(b),changed_symbols=[k for k,v in now.items() if old.get(k)!=v],tests=[n.name for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')],imports=[ast.unparse(n) for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom))],ast_sha256=p.sha(ast.dump(t,include_attributes=False).encode())))
scopes={}
for label,key in [('rem','rem_base'),('unit','unit_base'),('aggregate','aggregate_base')]:
 paths=p.git('diff','--name-only',p.REQUEST[key],p.REQUEST['candidate']).decode().splitlines();scopes[label]=paths
 scopes[label+'_python']=[x for x in paths if x.endswith('.py')]
 if label!='rem':
  assert scopes[label+'_python']==p.REQUEST['exact_scopes'][label+'_python']
  assert [x for x in scopes[label+'_python'] if '/src/' in x]==p.REQUEST['exact_scopes'][label+'_source']
 source=[x for x in paths if x.startswith(('packages/','experiments/','scripts/','tests/'))]
 if label=='rem':assert set(source)<=set(sum(p.REQUEST['product_manifest'].values(),[]))
 (p.OUT/(label+'.diff')).write_bytes(p.git('diff',p.REQUEST[key],p.REQUEST['candidate']))
 (p.OUT/(label+'-product.diff')).write_bytes(p.git('diff',p.REQUEST[key],p.REQUEST['candidate'],'--','packages','experiments','scripts','tests','pyproject.toml','uv.lock','main.py'))
# Accepted unit inputs must stay byte exact.
unchanged=['packages/friday-telemetry/src/friday_telemetry/interface.py','packages/friday-telemetry/src/friday_telemetry/models/llm_events.py','packages/friday-telemetry/src/friday_telemetry/models/mcp.py','packages/friday-telemetry/src/friday_telemetry/config.py','packages/friday-llm/src/friday_llm/service.py','packages/friday-llm/src/friday_llm/embeddings.py','packages/friday-chat/src/friday_chat/memory_mcp.py','packages/friday-chat/src/friday_chat/config.py','packages/friday-chat/config.example.yaml','uv.lock']
for rel in unchanged:assert (root/rel).read_bytes()==(base/rel).read_bytes(),rel
for x in root.rglob('pyproject.toml'):
 rel=x.relative_to(root);now=tomllib.loads(x.read_text());before=tomllib.loads((aggregate/rel).read_text()) if (aggregate/rel).exists() else {}
 for field in ('dependencies','optional-dependencies'):assert now.get('project',{}).get(field)==before.get('project',{}).get(field),(str(rel),field)
floors={str(x.relative_to(root)):tomllib.loads(x.read_text()).get('project',{}).get('requires-python') for x in root.rglob('pyproject.toml')}
assert len(floors)==18 and all(v=='>=3.13.4' for v in floors.values())
p.save('scope-waiver-api-final.json',dict(waiver_count=327,waiver_exact=True,waiver_inputs=hashes,command_registry_ast_sha256=a,scopes=scopes,inventory=inventory,unit_unchanged_inputs=unchanged,aggregate_dependencies_unchanged=True,floors=floors))
print('exact327 WVR-006 identities/four archives/17 configs/source+AST matched;133 ASTs;12/81 scope;18 metadata floors;unit accepted inputs unchanged')
