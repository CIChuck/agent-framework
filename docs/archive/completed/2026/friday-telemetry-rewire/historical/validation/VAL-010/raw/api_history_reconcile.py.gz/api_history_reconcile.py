from pathlib import Path
import ast,json,gzip,tomllib,sys
import prepare_validator as p
root=p.OUT/'candidate';unit=p.OUT/'unit-base';agg=p.OUT/'aggregate-base'
def astclass(rel,name,at):return next(n for n in ast.parse((at/rel).read_text(),feature_version=(3,13)).body if isinstance(n,ast.ClassDef) and n.name==name)
def methods(c):return {n.name:ast.unparse(n.args) for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and (not n.name.startswith('_') or n.name=='__init__')}
def fields(c):return [(n.target.id,ast.unparse(n.annotation),ast.unparse(n.value) if n.value else None) for n in c.body if isinstance(n,ast.AnnAssign)]
interfaces={}
for base in (unit,agg):
 rel='packages/friday-telemetry/src/friday_telemetry/interface.py';assert (root/rel).read_bytes()==(base/rel).read_bytes();interfaces[base.name]=methods(astclass(rel,'TelemetryInterface',base))
for name,rel in [('PendingExtractionTurn','packages/friday-chat/src/friday_chat/runtime.py'),('TurnResult','packages/friday-chat/src/friday_chat/turns/processor.py')]:
 a,b=fields(astclass(rel,name,unit)),fields(astclass(rel,name,root));assert a==b[:-1] and b[-1][0]=='correlation_context' and b[-1][-1]=='None'
for name,rel in [('TelemetryConfig','packages/friday-telemetry/src/friday_telemetry/config.py'),('ChatTelemetryConfig','packages/friday-chat/src/friday_chat/config.py')]:
 assert fields(astclass(rel,name,unit))==fields(astclass(rel,name,root))
 if name=='TelemetryConfig':assert fields(astclass(rel,name,agg))==fields(astclass(rel,name,root))
old=methods(astclass('packages/friday-telemetry/src/friday_telemetry/providers/otel.py','OpenTelemetryProvider',agg));new=methods(astclass('packages/friday-telemetry/src/friday_telemetry/providers/otel.py','OpenTelemetryProvider',root));assert all(new[k]==v for k,v in old.items())
def exports(at):
 t=ast.parse((at/'packages/friday-telemetry/src/friday_telemetry/__init__.py').read_text());return set(next(ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='__all__' for x in n.targets)))
added=exports(root)-exports(unit);assert added=={'ExecutionEvent','ExecutionContext','CorrelationScope'} and exports(unit)<=exports(root)
# Every accepted decision pin is checked directly at frozen commit, including nested evidence.
pins=[]
for rel in ['docs/archive/completed/2026/friday-telemetry-rewire-telem-02/acceptance-evidence.json','docs/archive/completed/2026/friday-telemetry-rewire-telem-03/acceptance-evidence.json']:
 v=json.loads((root/rel).read_text())
 def walk(x):
  if isinstance(x,dict):
   if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str) and (root/x['path']).is_file():
    current=p.sha((root/x['path']).read_bytes());pins.append(dict(path=x['path'],expected=x['sha256'],actual=current,matched=current==x['sha256']))
   for k,w in x.items():
    if isinstance(w,str) and len(w)==64 and (root/k).is_file():pins.append(dict(path=k,expected=w,actual=p.sha((root/k).read_bytes()),matched=p.sha((root/k).read_bytes())==w))
    else:walk(w)
  elif isinstance(x,list):
   for w in x:walk(w)
 walk(v)
assert all(x['matched'] for x in pins),[x for x in pins if not x['matched']]
rel='docs/planning/active/friday-telemetry-rewire/validation/CDR-020/raw/historical-recovery/receipt.json.gz';receipt=json.loads(gzip.decompress((root/rel).read_bytes()));historical=[]
for item in receipt['paths']:
 b=p.git('show',receipt['revision']+':'+item['path']);live=Path(receipt['root'])/item['path'];historical.append(dict(path=str(live),revision=receipt['revision'],exists=live.is_file(),actual_sha256=p.sha(live.read_bytes()),expected=item['sha256'],git_sha256=p.sha(b)))
assert all(x['exists'] and x['actual_sha256']==x['expected']==x['git_sha256'] for x in historical)
helpers={str(path):p.sha(path.read_bytes()) for path in [Path('/private/tmp/telem-04/REM-005/readiness/prepare.py'),Path('/private/tmp/telem-03/approved-readiness/reused-prepare.py'),p.OUT/'prepare_validator.py',p.OUT/'network-guard/sitecustomize.py']}
assert helpers['/private/tmp/telem-03/approved-readiness/reused-prepare.py']=='cd3963d50f55b5c2c18f2cf83f38a1ac4e13cb9bfc8ae3b3e31522d8492a9586'
bins={str(p.REPO/'.venv/bin'/name):p.sha((p.REPO/'.venv/bin'/name).read_bytes()) for name in ('python','ruff','mypy','pytest')}
p.save('api-history-preservation.json',dict(interfaces=interfaces,legacy_otel_methods_stable=True,legacy_defaults_unchanged=True,additive_final_dataclass_None_fields=True,exports_added=sorted(added),accepted_pins=pins,historical_links=historical,historical_limitation='Five recovered source/control files keep six historical absolute tmp links live; not self-contained or portable evidence and no historical text rewrite.',helpers=helpers,tool_binary_sha256=bins))
print('API/defaults/3exports/positional fields/accepted pins/history five files and exact archive helper hash matched')
