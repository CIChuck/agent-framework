import json,math
from uuid import uuid4
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.turns.telemetry import turn_scope,operation_scope
from friday_telemetry import DebugTelemetryRecorder
from friday_telemetry.models.execution import OperationFinish,ExecutionEvent
from friday_telemetry.models.llm_events import RequestStart
sink=DebugTelemetryRecorder();o=ChatTelemetryObserver(enabled=True,session_id='PRIVATE_RAW_SESSION')
with operation_scope(o,'native_tool'):
 data={**o.correlation.current().context.identity().model_dump(),'operation_kind':'native_tool','outcome':'succeeded','duration_ms':0.0}
 cases=[('count',True),('count',-1),('count',2**63),('duration_ms',True),('duration_ms',float('nan')),('duration_ms',float('inf')),('duration_ms',-1.0),('reason','PRIVATE_EXCEPTION'),('operation_ref','PRIVATE_CALL_ID'),('extra','PRIVATE_PROMPT'),('count',{'PRIVATE_CONTENT':'PRIVATE'})]+[('schema_version',v) for v in (True,False,1.0,'1',0,2)]
 for key,value in cases:
  before=o.execution_snapshot();n=len(o.snapshot().events);o.capture_event('execution.operation_finish',{**data,key:value});assert o.execution_snapshot()==before and not o.correlation.current().terminal
  assert len(o.snapshot().events)==n+1
 forged=OperationFinish.model_construct(**{**data,'schema_version':True});o.execution(forged);o.execution(ExecutionEvent.model_construct(root=forged));assert not o.execution_snapshot().counters
assert 'PRIVATE' not in repr(o.snapshot())
# Accepted payload and sequence equality, valid links only inside active scope.
o=ChatTelemetryObserver(enabled=True,session_id='PRIVATE_SESSION',provider=sink)
llm=RequestStart(request_id=uuid4().hex,model_ref=uuid4().hex,operation='chat',api='typed_completion',service_role='primary')
llmdata=llm.model_dump(exclude={'name'},exclude_none=True);mcpdata={'server_ref':'a'*16,'tool_ref':'b'*16,'reason':'success'}
o.capture_event(llm.name,llmdata);o.capture_event('mcp.tool_call_start',mcpdata)
assert not any(e.name.startswith('execution.') for e in o.snapshot().events)
with turn_scope(o,'completion'),operation_scope(o,'mcp_tool'):
 o.capture_event(llm.name,llmdata);o.capture_event('mcp.tool_call_start',mcpdata)
 before_links=len([e for e in o.snapshot().events if e.name=='execution.mcp_link']);o.capture_event('mcp.tool_call_start',{**mcpdata,'tool_ref':'PRIVATE_TOOL'});assert len([e for e in o.snapshot().events if e.name=='execution.mcp_link'])==before_links
 events=list(o.snapshot().events);original=next(e for e in reversed(events) if e.name=='mcp.tool_call_start');link=next(e for e in reversed(events) if e.name=='execution.mcp_link');assert dict(original.attributes)==mcpdata and dict(link.attributes)['source_sequence']==original.sequence
assert len([e for e in o.snapshot().events if e.name=='execution.llm_link'])==1
class FailureSink(DebugTelemetryRecorder):
 def capture_event(self,*a):raise RuntimeError('PRIVATE_EVENT')
 def start_span(self,*a):raise RuntimeError('PRIVATE_START')
 def end_span(self,*a):raise RuntimeError('PRIVATE_END')
o=ChatTelemetryObserver(enabled=True,session_id='PRIVATE_SESSION',provider=FailureSink())
for i in range(400):
 with turn_scope(o,'completion'),operation_scope(o,'native_tool'):
  frame=o.correlation.current();event=OperationFinish(**frame.context.identity().model_dump(),operation_kind='native_tool',outcome='succeeded',duration_ms=0.0);o.execution(event);o.execution(event)
metrics=o.execution_snapshot();snapshot=o.snapshot()
assert len(snapshot.events)==256 and snapshot.dropped_count>0 and snapshot.failure_count>0
assert len(metrics.turns)==32 and ('native_tool','succeeded',400) in metrics.counters and ('turn','succeeded',400) in metrics.counters
assert sum(n for k,out,b,n in metrics.histograms if k=='native_tool')==400
assert all(k in {'turn','native_tool'} and out=='succeeded' for k,out,n in metrics.counters)
assert not o._spans and 'PRIVATE' not in repr(snapshot) and 'PRIVATE' not in repr(metrics)
for _ in range(129):o.start_span('chat.operation')
assert len(o._spans)==128
for key in tuple(o._spans):o.end_span(key)
o._counters[('native_tool','succeeded')]=2**63-1
with operation_scope(o,'native_tool'):pass
assert ('native_tool','succeeded',2**63-1) in o.execution_snapshot().counters
print(json.dumps(dict(strict_negatives=len(cases)+2,invalid_zero_metrics=True,accepted_mcp_payload_equal=True,links_only_with_scope=True,privacy_sentinel_absent=True,retained_records=len(snapshot.events),retained_turns=len(metrics.turns),terminal_turns=400,terminal_operations=400,saturation=True,fixed_labels=True,open_span_capacity=128,all_spans_closed=not o._spans),indent=2))
