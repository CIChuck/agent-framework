"""Owned installed SDK plus Debug Composite, full span/event lineage assertions."""
import asyncio,json,threading
from contextvars import ContextVar
from unittest.mock import patch
from friday_telemetry import CompositeProvider,DebugTelemetryRecorder,OTelConfig,TelemetryFactoryConfig,create_telemetry
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.turns.telemetry import turn_scope,operation_scope
from friday_chat.adapters import FrameworkMaintenanceAdapter
from friday_chat.runtime import PendingExtractionTurn
from friday_chat.config import FridayChatConfig
from opentelemetry import trace
from opentelemetry.sdk.trace.export import SpanExporter,SpanExportResult
spans=[];exporters=[];before_threads=set(threading.enumerate());before_global=trace.get_tracer_provider();marker=ContextVar('application_marker',default=None);marker.set('PRIVATE_CALLER')
class Exporter(SpanExporter):
 def __init__(self,stream):self.closed=False;exporters.append(self)
 def export(self,batch):spans.extend(batch);return SpanExportResult.SUCCESS
 def shutdown(self):self.closed=True
async def exercise(handle,debug):
 composite=CompositeProvider([debug,handle.telemetry]);o=ChatTelemetryObserver(enabled=True,session_id='PRIVATE_SESSION',provider=composite)
 external=composite.start_span('synthetic.caller')
 origins=[o.correlation.context(turn=True),None,o.correlation.context(turn=True)];seen=[]
 class Extractor:
  async def extract(self,turn):seen.append(o.correlation.current().context.turn_ref);return {}
 cfg=FridayChatConfig.model_validate({'llm':{'model':'fake/test'},'tools':{'enabled':False}})
 adapter=FrameworkMaintenanceAdapter(cfg,'PRIVATE_SESSION',None,None,None,{}, {},extractor=Extractor(),observer=o)
 with turn_scope(o,'completion') as outer:
  outerframe=o.correlation.current()
  with operation_scope(o,'model_call'):
   parent=o.correlation.current()
   async def sibling():
    with operation_scope(o,'native_tool'):
     await asyncio.sleep(0)
     with operation_scope(o,'memory_retrieve'):await asyncio.sleep(0)
   await asyncio.gather(sibling(),sibling())
   assert o.correlation.current() is parent
   with turn_scope(o,'completion'),operation_scope(o,'model_call'):pass
  adapter.pending_extraction=[PendingExtractionTurn(str(i),'PRIVATE_USER','PRIVATE_ASSISTANT',origin) for i,origin in enumerate(origins)]
  assert await adapter.flush_pending_extraction()==3
  assert seen==[origins[0].turn_ref,None,origins[2].turn_ref]
  assert o.correlation.current() is outerframe
  assert outerframe.accounting.persistence=='not_started'
 assert marker.get()=='PRIVATE_CALLER'
 assert not o._spans and o.correlation.current() is None
 composite.capture_event('synthetic.restored',{'count':1})
 composite.end_span(external)
 assert not composite._spans and all(s.end_time is not None for s in debug.spans.values())
 assert handle.flush().status=='success' and not handle.snapshot().active_spans and not handle.snapshot().closed
 rows=[dict(name=s.name,id=s.context.span_id,parent=s.parent.span_id if s.parent else None,attributes=dict(s.attributes),events=[dict(name=e.name,data=dict(e.attributes)) for e in s.events]) for s in spans]
 byid={s['id']:s for s in rows};checked=0
 for s in rows:
  start=next((e for e in s['events'] if e['name'] in ('execution.turn_start','execution.operation_start')),None)
  if start is None:continue
  data=start['data'];parent=byid.get(s['parent']);checked+=1
  assert s['name']==('chat.turn' if start['name']=='execution.turn_start' else 'chat.operation')
  if data.get('operation_kind')=='memory_extract':assert parent is None
  elif data.get('parent_operation_ref') is not None:
   assert parent is not None
   pe=next(e['data'] for e in parent['events'] if e['name']=='execution.operation_start')
   assert pe['operation_ref']==data['parent_operation_ref'] and pe.get('turn_ref')==data.get('turn_ref')
  elif s['name']=='chat.operation':
   assert parent is not None and parent['name']=='chat.turn'
   pe=next(e['data'] for e in parent['events'] if e['name']=='execution.turn_start');assert pe['turn_ref']==data['turn_ref']
  elif parent is not None:assert parent['name']=='chat.operation'
  for e in s['events']:
   if e['name'] in ('execution.operation_start','execution.operation_finish'):
    assert e['data']['operation_ref']==data.get('operation_ref')
 assert checked>=10
 caller=next(s for s in rows if s['name']=='synthetic.caller');assert caller['parent'] is None and any(e['name']=='synthetic.restored' for e in caller['events'])
 assert 'PRIVATE' not in json.dumps(rows) and 'PRIVATE' not in repr(o.snapshot()) and 'PRIVATE' not in repr(debug.events)
 assert len([s for s in debug.spans.values() if s.name=='chat.operation'])==len([s for s in rows if s['name']=='chat.operation'])
 return dict(checked_spans=checked,mixed_origins=seen,span_rows=rows,debug_spans=[dict(name=s.name,parent_id=s.parent_id,closed=s.end_time is not None) for s in debug.spans.values()],caller_context_restored=True,borrowed_sink_kept_open=True)
with patch('friday_telemetry.providers._otel_exporter.SafeConsoleExporter',Exporter),patch.object(trace,'set_tracer_provider',side_effect=AssertionError('global forbidden')):
 handle=create_telemetry(TelemetryFactoryConfig(provider='otel',otel=OTelConfig(exporter='console')));debug=DebugTelemetryRecorder()
 try:results=asyncio.run(exercise(handle,debug))
 finally:shutdown=handle.shutdown()
assert shutdown.status=='success' and not handle.snapshot().worker_alive and all(x.closed for x in exporters)
assert trace.get_tracer_provider() is before_global and not [t for t in threading.enumerate() if t not in before_threads]
results.update(owned_cleanup=True,global_unchanged=True,worker_leaks=0)
print(json.dumps(results,indent=2))
