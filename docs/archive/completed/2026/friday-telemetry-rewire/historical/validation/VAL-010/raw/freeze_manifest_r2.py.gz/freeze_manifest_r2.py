from pathlib import Path
import json,hashlib,datetime,os
root=Path('/private/tmp/telem-04/REM-005/VAL-010')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
excluded=['candidate','rem-base','unit-base','aggregate-base']
files=[]
for current,dirs,names in os.walk(root):
 if Path(current)==root:dirs[:]=[d for d in dirs if d not in excluded]
 for n in names+[d for d in dirs if (Path(current)/d).is_symlink()]:
  p=Path(current)/n
  if p==root/'artifact-manifest.json':continue
  if p.is_symlink():
   target=os.readlink(p);files.append(dict(path=str(p.relative_to(root)),type='symlink',target=target,bytes=len(os.fsencode(target)),sha256=hashlib.sha256(os.fsencode(target)).hexdigest()));continue
  files.append(dict(path=str(p.relative_to(root)),type='file',bytes=p.stat().st_size,sha256=sha(p)))
provenance={label:dict(receipt=label+'-snapshot.json',receipt_sha256=sha(root/(label+'-snapshot.json')),revision=json.loads((root/(label+'-snapshot.json')).read_text())['revision'],exclusion='Sanitized read-only detached snapshot; complete tracked hashes and 267 pre-checkout protected exclusions in receipt. All tracked bytes reconciled in preservation-final2.json.') for label in excluded}
obj=dict(schema_version=1,review_id='VAL-010',reviewer='/root/rem005_product_validator',date_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),verdict='VERIFIED',candidate='5c3a0e6dc8ba995bad9e7dfb8c574f5dfd335bc8',mode='fresh-context independent read-only',report_sha256=sha(root/'report.md'),inputs='request.json and authority-receipt.json',files=sorted(files,key=lambda x:x['path']),snapshot_exclusions=provenance,self_exclusion='artifact-manifest.json omitted to prevent recursive hash; no other non-snapshot exclusions.',artifact_count=len(files))
(root/'artifact-manifest.json').write_text(json.dumps(obj,indent=2)+'\n')
for f in files:
 if f['type']=='file':(root/f['path']).chmod(0o444)
(root/'artifact-manifest.json').chmod(0o444)
