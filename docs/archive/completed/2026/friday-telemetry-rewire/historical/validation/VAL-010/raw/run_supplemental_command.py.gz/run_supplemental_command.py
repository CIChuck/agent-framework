import prepare_validator as p
import subprocess,sys,os,time,datetime,json
from pathlib import Path
label,snapshot,commands=sys.argv[1:];root=p.OUT/snapshot;raw=json.loads(Path(commands).read_text());env=p.environment(root,label)
env['MYPYPATH']=os.pathsep.join(str(x) for x in sorted((root/'packages').glob('*/src')))
cmd=raw if raw[0] in ('git','uv') else ['uv','run','--no-sync',*raw];stem='supplemental-'+label
if (p.OUT/(stem+'-receipt.json')).exists():raise RuntimeError('new label required')
t=time.monotonic();r=subprocess.run(cmd,cwd=root,env=env,capture_output=True,timeout=300)
for name,data in [('stdout',r.stdout),('stderr',r.stderr)]:(p.OUT/(stem+'.'+name)).write_bytes(data)
p.save(stem+'-receipt.json',dict(command=cmd,cwd=str(root),environment=env,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-t,exit_code=r.returncode,stdout_sha256=p.sha(r.stdout),stderr_sha256=p.sha(r.stderr),script_sha256=p.sha(Path(__file__).read_bytes())))
print(label,r.returncode,r.stdout.decode()[-300:],r.stderr.decode()[-120:])
