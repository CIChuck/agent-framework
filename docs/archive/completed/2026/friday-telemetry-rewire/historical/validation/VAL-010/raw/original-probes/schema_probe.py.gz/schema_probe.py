import json
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.turns.telemetry import operation_scope
rows=[]
for value in [True,1.0]:
 o=ChatTelemetryObserver(enabled=True,session_id='safe')
 with operation_scope(o,'native_tool'):
  context=o.correlation.current().context
  o.capture_event('execution.operation_finish',{**context.identity().model_dump(),'schema_version':value,'operation_kind':'native_tool','outcome':'succeeded','duration_ms':0.0})
  rows.append(dict(input_schema_version=repr(value),counter_after_invalid_input=o.execution_snapshot().counters,rejected_after_invalid_input=o.snapshot().rejected_count,delivered_finish=[dict(e.attributes) for e in o.snapshot().events if e.name=='execution.operation_finish']))
print(json.dumps(rows,indent=2))
