from pathlib import Path
import subprocess,time,json,datetime,sys,os
import prepare_validator as p
root=p.OUT/'candidate'
args=sys.argv[1:];indices=[int(i) for i in args if i.isdigit()] or list(range(1,20));tag='-sandbox' if '--sandbox' in args else ''
for i in indices:
 label=f'command-{i:02d}{tag}'
 if (p.OUT/(label+'-receipt.json')).exists():raise RuntimeError('Retain receipts; unique rerun label required')
 raw=p.REQUEST['required_commands'][i-1];cmd=raw if raw[0] in ('git','uv') else ['uv','run','--no-sync',*raw]
 env=p.environment(root,label)
 if raw[0]=='mypy':env['MYPYPATH']=os.pathsep.join(str(x) for x in sorted((root/'packages').glob('*/src')))
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 try:r=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=900);code=r.returncode;stdout=r.stdout;stderr=r.stderr
 except subprocess.TimeoutExpired as e:code=124;stdout=e.stdout or b'';stderr=e.stderr or b''
 (p.OUT/(label+'.stdout')).write_bytes(stdout);(p.OUT/(label+'.stderr')).write_bytes(stderr)
 p.save(label+'-receipt.json',dict(command=cmd,raw_command=raw,cwd=str(root),environment=env,started=start,duration_seconds=time.monotonic()-t,exit_code=code,stdout_sha256=p.sha(stdout),stderr_sha256=p.sha(stderr),script_sha256=p.sha(Path(__file__).read_bytes())))
 print(label,code,stdout.decode(errors='replace')[-250:],stderr.decode(errors='replace')[-100:],flush=True)
