"""Independent fake-only behavioral matrix and uncovered-context probes."""
import asyncio,json,math
from types import SimpleNamespace
from friday_chat.runtime import build_runtime,PendingExtractionTurn,FakeChatModel
from friday_chat.config import FridayChatConfig
from friday_chat.turns.processor import TurnProcessor
from friday_chat.turns.telemetry import turn_scope,operation_scope
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.adapters import FrameworkMaintenanceAdapter,FrameworkMemoryAdapter
from friday_chat.turns.models import ChatModelResponse,ToolCallRequest
from friday_telemetry import DebugTelemetryRecorder
from friday_telemetry.models.execution import OperationFinish,ExecutionEvent
from pydantic import ValidationError

results=[];issues=[]
def runtime():return build_runtime(FridayChatConfig.model_validate({'llm':{'model':'fake/test','timeout_seconds':.02},'tools':{'enabled':False},'telemetry':{'enabled':True},'transcript':{'capture_raw_prompts':True}}))
def events(o,name):return [dict(e.attributes) for e in o.snapshot().events if e.name=='execution.'+name]
class Unprintable(RuntimeError):
 def __str__(self):raise AssertionError('exception serialization forbidden')
async def boundaries():
 for streaming in (False,True):
  for stage in ('retrieve','model','store_turn','record_turn','record_context_log','record_interaction','speech'):
   for cancel in (False,True):
    r=runtime();error=asyncio.CancelledError() if cancel else Unprintable()
    async def fail(*args,**kw):raise error
    if stage=='retrieve':r.memory.retrieve=fail
    elif stage=='model':
     if streaming:
      async def stream(*args,**kw):
       raise error
       yield 'unreachable'
      r.chat_llm.stream_complete=stream
     else:r.chat_llm.complete=fail
    elif stage=='store_turn':r.memory.store_turn=fail
    elif stage=='speech':r.speech.speak=fail
    else:setattr(r.transcript,stage,fail)
    async def chunk(c):pass
    try:
     if streaming:await TurnProcessor(r).process_streaming('PRIVATE_PROMPT',on_chunk=chunk)
     else:await TurnProcessor(r).process('PRIVATE_PROMPT')
     raise AssertionError('missing primary exception')
    except BaseException as caught:
     assert caught is error or caught.__cause__ is error,(streaming,stage,cancel,type(caught))
    finishes=events(r.telemetry,'turn_finish');assert len(finishes)==1 and finishes[0]['outcome']==('cancelled' if cancel else 'failed')
    assert r.telemetry.correlation.current() is None and not r.telemetry._spans
    assert 'PRIVATE' not in repr(r.telemetry.snapshot())
    results.append(dict(streaming=streaming,stage=stage,cancel=cancel,terminal=finishes[0]))
 # Old work with explicit None context must never borrow a foreground turn.
 o=ChatTelemetryObserver(enabled=True,session_id='PRIVATE_SESSION');seen=[]
 class Extractor:
  async def extract(self,turn):seen.append(o.correlation.current().context.turn_ref);return {}
 a=FrameworkMaintenanceAdapter(runtime().config,'PRIVATE_SESSION',None,None,None,{}, {},extractor=Extractor(),observer=o)
 with turn_scope(o,'completion') as foreground:
  a.pending_extraction=[PendingExtractionTurn('RAW_TURN','PRIVATE_U','PRIVATE_A',None)]
  await a.flush_pending_extraction()
  f=events(o,'operation_finish')[-1]
  if f.get('turn_ref') is not None:issues.append(dict(issue='legacy_none_context_borrows_foreground',foreground=foreground.turn_ref,observed=f))
 # Outgoing stream is kept strongly referenced to expose prompt callback cleanup.
 r=runtime();closed=[]
 class Model:
  def __init__(self):self.iterator=None
  def stream_complete(self,*args,**kw):
   async def gen():
    try:
     yield 'first';yield 'second'
    finally:closed.append(True)
   self.iterator=gen();return self.iterator
 m=Model();r.chat_llm=m;primary=Unprintable()
 async def callback(c):raise primary
 try:await TurnProcessor(r).process_streaming('PRIVATE_PROMPT',on_chunk=callback)
 except Unprintable as caught:assert caught is primary
 await asyncio.sleep(0)
 results.append(dict(probe='callback_iterator_close',closed_before_consumer_cleanup=bool(closed),all_observer_spans_closed=not r.telemetry._spans))
 if not closed:issues.append(dict(issue='callback_does_not_explicitly_close_model_iterator'))
 await m.iterator.aclose()
 # Direct ingestion actual count and failure/empty cases.
 for mode in ('success','empty','failure','cancel'):
  o=ChatTelemetryObserver(enabled=True,session_id='PRIVATE_SESSION')
  class Controller:
   async def store_document(self,*args,**kw):
    if mode=='failure':raise Unprintable()
    if mode=='cancel':raise asyncio.CancelledError()
  adapter=FrameworkMemoryAdapter(Controller(),None,runtime().config,'PRIVATE_SESSION',None,None,observer=o)
  try:count=await adapter.ingest_document(source_path='PRIVATE_PATH',description='PRIVATE_DESC',content='' if mode=='empty' else 'PRIVATE_DOCUMENT')
  except (Unprintable,asyncio.CancelledError):count=None
  finish=events(o,'operation_finish')[-1];assert 'PRIVATE' not in repr(o.snapshot())
  results.append(dict(probe='ingest',mode=mode,count=count,finish=finish))
 # Both sessions and nested scopes retain independent identities and restore parents.
 one=ChatTelemetryObserver(enabled=True,session_id='one');two=ChatTelemetryObserver(enabled=True,session_id='two')
 async def nested(o):
  with turn_scope(o,'completion') as origin:
   parent=o.correlation.current()
   with operation_scope(o,'model_call'):
    f=o.correlation.current()
    with operation_scope(o,'native_tool'):
     c=o.correlation.current();assert c.context.parent_operation_ref==f.context.operation_ref;await asyncio.sleep(0)
    assert o.correlation.current() is f
   assert o.correlation.current() is parent
  assert o.correlation.current() is None and not o._spans;return origin.turn_ref
 refs=await asyncio.gather(nested(one),nested(two));assert refs[0]!=refs[1];results.append(dict(probe='sessions_nested',refs=refs))
 # Strict content, overflow, forged/RootModel and scalar negatives.
 o=ChatTelemetryObserver(enabled=True,session_id='PRIVATE_SESSION');rejected=0;accepted=[]
 with operation_scope(o,'native_tool'):
  frame=o.correlation.current();identity=frame.context.identity().model_dump()
  data={**identity,'operation_kind':'native_tool','outcome':'succeeded','duration_ms':0.0}
  for field,val in [('count',True),('count',2**63),('duration_ms',float('nan')),('duration_ms',float('inf')),('duration_ms',True),('operation_ref','PRIVATE_ID'),('reason','PRIVATE_EXCEPTION'),('count',{'PRIVATE':'PRIVATE'}),('schema_version',True),('schema_version',1.0)]:
   try:OperationFinish.model_validate({**data,field:val});accepted.append([field,repr(val)])
   except ValidationError:rejected+=1
  forged=OperationFinish.model_construct(**{**data,'duration_ms':float('nan')});o.execution(forged)
  forged_root=ExecutionEvent.model_construct(root=forged);o.capture_event('execution.operation_finish',{**data,'duration_ms':float('nan')})
  assert not o.execution_snapshot().counters
 results.append(dict(probe='strict_schema',rejected=rejected,unexpected_accepted=accepted))
 for field,val in accepted:issues.append(dict(issue='schema_literal_accepts_noninteger',field=field,value=val))
 print(json.dumps(dict(results=results,issues=issues),indent=2))
asyncio.run(boundaries())
