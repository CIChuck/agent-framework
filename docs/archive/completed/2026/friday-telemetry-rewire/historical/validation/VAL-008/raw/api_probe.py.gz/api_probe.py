from run_gate import *
from dataclasses import asdict
root=ROOT
checks={}
# Compare exact previously valid positional/keyword slots, defaults and public methods.
for rel in ['packages/friday-llm/src/friday_llm/service.py','packages/friday-llm/src/friday_llm/embeddings.py','packages/friday-chat/src/friday_chat/adapters.py','packages/friday-chat/src/friday_chat/reorganization/mutation.py']:
 before=ast.parse((OUT/'unit-base'/rel).read_text());after=ast.parse((root/rel).read_text())
 def funcs(tree):
  return {n.name:n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and not n.name.startswith('_') or isinstance(n,ast.FunctionDef) and n.name=='__init__'}
 b=funcs(before);a=funcs(after);detail={}
 for name,node in b.items():
  if name not in a:raise RuntimeError('public method removed')
  nb=node.args;na=a[name].args
  if [n.arg for n in nb.posonlyargs+nb.args]!=[n.arg for n in na.posonlyargs+na.args]:raise RuntimeError('positional API changed '+name)
  if [ast.dump(n) for n in nb.defaults]!=[ast.dump(n) for n in na.defaults]:raise RuntimeError('positional defaults changed '+name)
  old_kw={n.arg:None if v is None else ast.dump(v) for n,v in zip(nb.kwonlyargs,nb.kw_defaults)};new_kw={n.arg:None if v is None else ast.dump(v) for n,v in zip(na.kwonlyargs,na.kw_defaults)}
  if not all(new_kw.get(k)==v for k,v in old_kw.items()):raise RuntimeError('keyword default changed '+name)
  additions={k:v for k,v in new_kw.items() if k not in old_kw}
  if any(k not in ('telemetry','service_role','tracker','batch') for k in additions):raise RuntimeError('unexpected optional keyword')
  detail[name]=dict(existing_call_slots_preserved=True,additive_keywords=list(additions))
 checks[rel]=detail
# Public aliases, runtime generic serialization/subscriptability consumer.
from friday_cli.session import SessionContext,SessionManager,SessionConfig
from friday_core.interfaces.tools import ToolAdapter
from friday_moltbook.responses import MoltbookResponse
from friday_memory.llm_completion import MemoryLLMClient
from friday_cli.commands import CommandRegistry
class Parent:pass
class Child(Parent):pass
ctx=SessionContext[Child](session=Child(),config=SessionConfig());assert isinstance(ctx.session,Child)
model=MoltbookResponse[int](success=True,data=1);assert model.model_dump()['data']==1
assert MoltbookResponse[int].model_json_schema()['properties']['data']
assert ToolAdapter[int] and SessionManager[int] and CommandRegistry[int] and MemoryLLMClient
save('api-probe-results.json',dict(call_signatures=checks,runtime_generics_and_pydantic='passed',memory_alias=repr(MemoryLLMClient)))
print('PUBLIC_CALL_AND_RUNTIME_API_PASS')
