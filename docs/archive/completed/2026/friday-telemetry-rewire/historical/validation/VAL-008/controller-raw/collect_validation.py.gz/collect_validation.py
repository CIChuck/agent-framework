from pathlib import Path
import gzip
import hashlib
import json

source=Path('/private/tmp/telem-03/VAL-008')
dest=Path('/Users/chuckrussell/Dev/gendev/agent-framework/docs/planning/active/friday-telemetry-rewire/validation/VAL-008')
m=json.loads((source/'original-raw-artifact-manifest-final.json').read_text())
if m['verdict']!='VERIFIED' or m['candidate']!='dd543fd6a6819ec0c4fb2529fa384fea886f5509':
 raise RuntimeError('Unexpected review verdict/candidate')
expected_report='602796deea2fffa681820bd0ed68ff67a2fa2f60b9c722d96361b39b51676654'
sha=lambda b:hashlib.sha256(b).hexdigest()
if sha((source/'report.md').read_bytes())!=expected_report:raise RuntimeError('Reviewer report drift')
records=[]
for name,expected in m['artifacts'].items():
 path=Path(name)
 if path.is_absolute() or '..' in path.parts:raise RuntimeError('Unexpected artifact path')
 data=(source/path).read_bytes()
 if sha(data)!=expected['sha256'] or len(data)!=expected['size']:raise RuntimeError('Original reviewer artifact drift '+name)
 target=dest/'raw'/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);compressed=gzip.compress(data,mtime=0);target.write_bytes(compressed)
 records.append(dict(original=str(source/path),stored=str(target.relative_to(dest)),original_sha256=sha(data),stored_sha256=sha(compressed),bytes=len(data)))
(dest/'original-report.md').write_bytes((source/'report.md').read_bytes())
(dest/'original-raw-artifact-manifest-final.json').write_bytes((source/'original-raw-artifact-manifest-final.json').read_bytes())
(dest/'stored-artifact-manifest.json').write_text(json.dumps(dict(candidate=m['candidate'],reviewer=m['reviewer'],verdict=m['verdict'],original_manifest_sha256=sha((source/'original-raw-artifact-manifest-final.json').read_bytes()),original_report_sha256=expected_report,gzip_mtime=0,artifacts=records),indent=2)+'\n')
for item in records:
 data=(dest/item['stored']).read_bytes()
 if sha(data)!=item['stored_sha256'] or sha(gzip.decompress(data))!=item['original_sha256']:raise RuntimeError('Stored reviewer artifact drift')
print('Verified and preserved all',len(records),'original and stored reviewer artifacts, including exact report')
