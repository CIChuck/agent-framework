from snapshot import *
ROOT=OUT/'candidate'
PATHS=json.loads((OUT/'expanded-paths.json').read_text())
IGNORE=['--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py']
NEW=['packages/friday-telemetry/tests_telemetry/test_llm_events.py','packages/friday-telemetry/tests_telemetry/test_safe_llm.py','packages/friday-llm/tests_llm/test_safe_telemetry.py','packages/friday-chat/tests_chat/test_llm_telemetry_injection.py']
COMMANDS={
'new-tests':['pytest',*NEW,'-rA'],
'unit-owning':['pytest',*PATHS['unit']['owning_tests'],*IGNORE,'-rA'],
'root-collect':['pytest','--import-mode=importlib',*IGNORE,'--collect-only'],
'root-tests':['pytest','--import-mode=importlib',*IGNORE,'-rA'],
'aggregate-owning':['pytest','--import-mode=importlib',*PATHS['aggregate']['owning_tests'],*IGNORE,'-rA'],
'unit-ruff':['ruff','check',*PATHS['unit']['python']],
'aggregate-ruff':['ruff','check',*PATHS['aggregate']['python']],
'root-ruff':['ruff','check','.','--output-format','json'],
'base-root-ruff':['ruff','check','.','--output-format','json'],
'unit-mypy':['mypy','--python-version','3.13',*PATHS['unit']['source']],
'aggregate-mypy':['mypy','--python-version','3.13',*PATHS['aggregate']['source']],
'lock':['uv','lock','--offline','--check','--no-python-downloads','--no-build'],
'board':['python','scripts/friday-dev-board.py','validate'],
'next':['python','scripts/friday-dev-board.py','next'],
'show':['python','scripts/friday-dev-board.py','show','friday-telemetry-rewire'],
'render':['python','scripts/friday-dev-board.py','render','--check'],
'docs':['python','scripts/check-documentation-lifecycle.py'],
'versions':['python','-c','import sys,importlib.metadata as m;print(sys.version);print({p:m.version(p) for p in ["ruff","mypy","pytest","opentelemetry-sdk","grpcio"]})'],
'unit-diff':['git','--no-optional-locks','diff','--check',PATHS['unit']['base'],'HEAD'],
'aggregate-diff':['git','--no-optional-locks','diff','--check',PATHS['aggregate']['base'],'HEAD'],
}
def run(label,key):
 root=OUT/'unit-base' if key=='base-root-ruff' else ROOT
 env=environment(root,label)
 env['PYTHONPATH']=str(OUT)+os.pathsep+env['PYTHONPATH']
 cmd=COMMANDS[key].copy()
 if cmd[0]=='pytest':cmd+=['-p','pytest_source_audit','--source-audit-output',str(OUT/(label+'-source-audit.json')),'--basetemp',str(OUT/'tmp'/label/'pytest')]
 if cmd[0] not in ('git','uv'):cmd=['uv','run','--no-sync','--offline','--no-python-downloads',*cmd]
 freeze=dict(label=label,key=key,command=cmd,cwd=str(root),environment=env,revision=git('rev-parse',root.name if False else 'HEAD').decode().strip(),candidate=git('-C',str(root),'rev-parse','HEAD').decode().strip(),script_sha256=sha(Path(__file__).read_bytes()),helper_sha256=sha((OUT/'snapshot.py').read_bytes()),audit_sha256=sha((OUT/'pytest_source_audit.py').read_bytes()),guard_sha256=sha((GUARD/'sitecustomize.py').read_bytes()),started=time.time())
 save(label+'-freeze.json',freeze)
 with (OUT/(label+'.stdout')).open('wb') as stdout,(OUT/(label+'.stderr')).open('wb') as stderr:
  p=subprocess.run(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr)
 receipt=json.loads((OUT/(root.name+'-snapshot.json')).read_text())
 changed=[p for p,h in receipt['tracked_hashes'].items() if not (root/p).exists() or sha((root/p).read_bytes())!=h]
 save(label+'-receipt.json',dict(**freeze,exit=p.returncode,seconds=time.time()-freeze['started'],stdout_sha256=sha((OUT/(label+'.stdout')).read_bytes()),stderr_sha256=sha((OUT/(label+'.stderr')).read_bytes()),changed_tracked_paths=changed))
 print(label,p.returncode,'seconds',round(time.time()-freeze['started'],2),'tracked_changed',len(changed),flush=True)
if __name__=='__main__':
 for key in sys.argv[1:]:run(key+'-r1',key)
