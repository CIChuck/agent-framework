from run_gate import *
probe=OUT/'sdk_consumer_probe.py'
save('sdk-consumer-r1-probe-freeze.json',dict(script_sha256=sha(probe.read_bytes()),runner_sha256=sha(Path(__file__).read_bytes()),preflight='Owned in-memory exporter patches public console exporter factory;all gRPC/TLS/credential constructors reject;fake acompletions;owned SDK/thread cleanup;no channels/listeners.'))
COMMANDS['sdk-consumer']=['python',str(probe)]
run('sdk-consumer-r1','sdk-consumer')
