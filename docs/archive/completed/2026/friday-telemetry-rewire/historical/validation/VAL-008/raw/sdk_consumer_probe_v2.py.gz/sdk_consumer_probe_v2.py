"""Separate actual SDK evidence: owned in-memory exporter, no channel or listener."""
import asyncio,json,sys,threading,hashlib
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import grpc
import litellm
from opentelemetry import trace
from opentelemetry.sdk.trace.export import SpanExporter,SpanExportResult
from friday_telemetry import create_telemetry,TelemetryFactoryConfig,OTelConfig,DebugTelemetryRecorder,CompositeProvider
from friday_telemetry.providers import _otel_exporter
from friday_chat.telemetry import ChatTelemetryObserver
from friday_llm import LiteLLMService,ChatCompletionRequest,ResilienceConfig
SENTINEL='INDEPENDENT_VAL008_PRIVATE_SENTINEL'
spans=[];instances=[]
class OwnedMemoryExporter(SpanExporter):
 def __init__(self,stream):self.closed=False;instances.append(self)
 def export(self,batch):spans.extend(batch);return SpanExportResult.SUCCESS
 def shutdown(self):self.closed=True
 def force_flush(self,timeout_millis=30000):return not self.closed

def forbidden(*a,**k):raise AssertionError('probe permits no channel, TLS or credentials')
async def probe():
 global_before=trace.get_tracer_provider();initial=set(threading.enumerate())
 with patch.object(_otel_exporter,'SafeConsoleExporter',OwnedMemoryExporter),patch.object(grpc,'insecure_channel',forbidden),patch.object(grpc,'secure_channel',forbidden),patch.object(grpc,'ssl_channel_credentials',forbidden):
  with create_telemetry(TelemetryFactoryConfig(provider='otel',otel=OTelConfig(exporter='console'))) as handle:
   debug=DebugTelemetryRecorder();composite=CompositeProvider([debug,handle.telemetry]);observer=ChatTelemetryObserver(enabled=True,session_id=SENTINEL,provider=composite)
   service=LiteLLMService(model_name=SENTINEL,telemetry=observer,resilience=ResilienceConfig(max_retries=0))
   raw=NS(choices=[NS(message=NS(content=SENTINEL,reasoning_content=SENTINEL,tool_calls=[]),finish_reason='stop')],usage=NS(prompt_tokens=0,completion_tokens=0,total_tokens=0),id=SENTINEL,model=SENTINEL)
   async def fake(**kwargs):return raw
   with patch.object(litellm,'acompletion',fake):
    request=ChatCompletionRequest(messages=({'role':'user','content':SENTINEL},))
    assert (await service.chat_completion_request(request)).content==SENTINEL
    parent=observer.start_span('chat.application')
    assert (await service.chat_completion_request(request)).content==SENTINEL
    observer.end_span(parent)
   assert handle.flush().status=='success'
   assert len(debug.events)==6
   for span in spans:
    for event in span.events:
     assert event.name.startswith('llm.')
     assert all(type(v) in (str,int,float,bool) for v in event.attributes.values())
     assert SENTINEL not in json.dumps(dict(event.attributes))
   actual=[(event.name,dict(event.attributes)) for span in spans for event in span.events]
   assert sorted(actual,key=lambda v:v[1]['request_id']+v[0])==sorted([(event.name,event.data) for event in debug.events],key=lambda v:v[1]['request_id']+v[0])
   assert len(spans)==4 and len([s for s in spans if s.name=='chat.application'])==1
   current=next(s for s in spans if s.name=='chat.application');assert len(current.events)==3
   assert all(s.parent is None for s in spans)
  assert all(x.closed for x in instances)
  assert not handle.snapshot().worker_alive
 assert trace.get_tracer_provider() is global_before
 assert not [t for t in threading.enumerate() if t not in initial and (t.name=='FridayTelemetryExporter' or t.name.startswith('SyntheticOTLP'))]
 leaks={name:str(Path(m.__file__).resolve()) for name,m in tuple(sys.modules.items()) if isinstance(getattr(m,'__file__',None),str) and Path(m.__file__).resolve().is_relative_to('/Users/chuckrussell/Dev/gendev/agent-framework') and not Path(m.__file__).resolve().is_relative_to('/Users/chuckrussell/Dev/gendev/agent-framework/.venv')}
 assert not leaks
 imports={name:{'path':m.__file__,'sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} for name,m in tuple(sys.modules.items()) if name.startswith(('friday_','opentelemetry','grpc')) and isinstance(getattr(m,'__file__',None),str) and Path(m.__file__).is_file()}
 print(json.dumps(dict(events=actual,spans=len(spans),exporters_closed=True,owned_workers_remaining=[],original_product_import_leaks=leaks,imports=imports),indent=2))
asyncio.run(probe())
