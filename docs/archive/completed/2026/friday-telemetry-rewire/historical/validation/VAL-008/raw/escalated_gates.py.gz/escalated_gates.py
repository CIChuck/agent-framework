from run_gate import run
for gate in ('unit-owning','root-tests','aggregate-owning'):
 run(gate+'-r2-normal-user',gate)
