from run_gate import *
# Use actual classes extracted verbatim to avoid broader legacy source debt.
classes=[('packages/friday-chat/src/friday_chat/memory_views.py','MemoryMetric'),('packages/friday-cli/src/friday_cli/commands.py','CommandRegistry'),('packages/friday-cli/src/friday_cli/session.py','SessionContext'),('packages/friday-cli/src/friday_cli/session.py','SessionManager'),('packages/friday-core/src/friday_core/interfaces/tools.py','ToolAdapter'),('packages/friday-moltbook/src/friday_moltbook/responses.py','MoltbookResponse')]
results={}
for rel,name in classes[:1]:
 result={}
 for label,revision in [('original','2155a0fc51f5b20dea4e35c6cfc70f1d52002735'),('candidate','dd543fd6a6819ec0c4fb2529fa384fea886f5509')]:
  content=git('show',f'{revision}:{rel}').decode();tree=ast.parse(content);cl=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)
  # Keep real imports and supporting classes so class typing gets actual contracts.
  folder=OUT/'generic-consumers-v2'/name/label;folder.mkdir(parents=True,exist_ok=False)
  (folder/'boundary.py').write_text(content)
  (folder/'consumer.py').write_text(f'from boundary import {name}\nclass Parent:pass\nclass Child(Parent):pass\ndef assignments(parent: {name}[Parent], child: {name}[Child]) -> None:\n parent = child\n child = parent\n')
  env=environment(ROOT,f'generic-v2-{name}-{label}')
  cmd=['uv','run','--no-sync','--offline','--no-python-downloads','mypy','--python-version','3.13','--follow-imports=silent','consumer.py']
  save(f'generic-v2-{name}-{label}-freeze.json',dict(command=cmd,cwd=str(folder),environment=env,source_sha256=sha(content.encode()),class_ast_sha256=sha(ast.dump(cl,include_attributes=False).encode()),consumer_sha256=sha((folder/'consumer.py').read_bytes()),reviewer_script_sha256=sha(Path(__file__).read_bytes())))
  p=subprocess.run(cmd,cwd=folder,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (OUT/f'generic-v2-{name}-{label}.stdout').write_bytes(p.stdout);(OUT/f'generic-v2-{name}-{label}.stderr').write_bytes(p.stderr)
  # Preserve all raw diagnostics; compare type assignment error positions/messages only.
  diagnostics=[l for l in p.stdout.decode().splitlines() if 'consumer.py:' in l]
  result[label]=dict(exit=p.returncode,diagnostics=diagnostics,stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr))
 result['consumer_diagnostics_equal']=result['original']['diagnostics']==result['candidate']['diagnostics']
 results[name]=result
save('generic-memorymetric-results.json',results)
print(json.dumps(results,indent=2))
