from snapshot import *
ROOT=OUT/'candidate'
effects=json.loads((ROOT/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-03-planning/listener-scope.json').read_text())
checks={p:dict(expected=h,actual=sha((ROOT/p).read_bytes())) for p,h in effects['fixture_hashes'].items()}
assert all(v['expected']==v['actual'] for v in checks.values())
assert len(effects['existing_nodes'])==13 and effects['new_nodes']==[]
paths=sorted(p for glob in ['packages/*/src/**/*.py','packages/*/tests_*/**/*.py','experiments/*/tests/**/*.py','experiments/*/*.py'] for p in ROOT.glob(glob) if p.is_file())
config=json.loads((OUT/'candidate-snapshot.json').read_text())
save('precollection-freeze.json',dict(fixtures=checks,nodes=effects['existing_nodes'],source_fixture_helpers={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},guard=sha((GUARD/'sitecustomize.py').read_bytes()),review='Fixture/import/helper sources inspected. HTTP127.0.0.1 ephemeral only. gRPC literal127.0.0.1:0; intercepted owned channels; retries0/proxy0; bounded deadlines, owned exporter/channel/server/executor cleanup. New tests only fake dispatch and sinks; existing SDK tests synthetic exporters and patched channels. All regression fakes/temp stores in owned snapshot/temp dirs; no original runtime data.'))
print('PREFLIGHT',len(paths),'hashes;13authorizedexistingnodes;267omissions')
