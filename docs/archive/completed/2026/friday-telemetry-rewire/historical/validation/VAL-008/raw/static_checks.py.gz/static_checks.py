from snapshot import *
import tomllib
ROOT=OUT/'candidate';BASE=OUT/'unit-base'
paths=json.loads((OUT/'expanded-paths.json').read_text());scope=json.loads((ROOT/'docs/planning/active/friday-telemetry-rewire/validation/WVR-005-telem03-lint-scope.json').read_text())
results={}
for label in ('base-root-ruff','root-ruff'):
 root=BASE if label.startswith('base') else ROOT
 actual=json.loads((OUT/(label+'-r1.stdout')).read_text())
 identities=[dict(path=str(Path(d['filename']).relative_to(root)),code=d['code'],location=d['location'],end_location=d['end_location'],message=d['message']) for d in actual]
 canonical=lambda ds: sorted(ds,key=lambda d:json.dumps(d,sort_keys=True))
 results[label]=dict(count=len(actual),identities_equal=canonical(identities)==canonical(scope['diagnostics']))
 results[label]['hash_checks']={p:sha((root/p).read_bytes())==h for group in ('archived_files','lint_configurations') for p,h in scope[group].items()}
 reg=root/'packages/friday-cli/src/friday_cli/commands.py';tree=ast.parse(reg.read_text());cl=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry')
 results[label]['registry_source_equal']=sha(reg.read_bytes())==scope['command_registry_source_sha256']
 results[label]['registry_ast_equal']=sha(ast.dump(cl,include_attributes=False).encode())==scope['command_registry_class_ast_sha256']
results['ast']={p:'parsed3.13' for p in paths['aggregate']['python'] if ast.parse((ROOT/p).read_text(),feature_version=(3,13)) is not None}
configs=[ROOT/'pyproject.toml',*sorted((ROOT/'packages').glob('*/pyproject.toml')),ROOT/'tests/lab/pyproject.toml']
results['floors']={str(p.relative_to(ROOT)):tomllib.loads(p.read_text())['project']['requires-python'] for p in configs}
results['unit_metadata_unchanged']={p:sha((ROOT/p).read_bytes())==sha((BASE/p).read_bytes()) for p in ['pyproject.toml','uv.lock',*scope['lint_configurations'].keys()]}
unchanged=['packages/friday-telemetry/src/friday_telemetry/interface.py','packages/friday-telemetry/src/friday_telemetry/helpers/llm.py','packages/friday-llm/src/friday_llm/telemetry_models.py','packages/friday-llm/src/friday_llm/interfaces.py']
# Entire public request/stream/model boundary and legacy facade bytes, rather than signature alone.
unchanged += [str(p.relative_to(ROOT)) for p in (ROOT/'packages/friday-llm/src/friday_llm').glob('*.py') if p.name not in ('service.py','embeddings.py','pricing.py','telemetry.py')]
unchanged=[p for p in sorted(set(unchanged)) if (ROOT/p).is_file()]
results['unit_public_legacy_unchanged']={p:sha((ROOT/p).read_bytes())==sha((BASE/p).read_bytes()) for p in unchanged}
results['added_source_suppressions']=[];results['added_asserts']=[]
for p in paths['aggregate']['source']:
 diff=git('diff',paths['aggregate']['base'],'dd543fd6a6819ec0c4fb2529fa384fea886f5509','--',p).decode()
 for line in diff.splitlines():
  if line.startswith('+') and not line.startswith('+++'):
   if any(s in line for s in ('mypy:','type: ignore','noqa')):results['added_source_suppressions'].append(dict(path=p,line=line))
   if line.lstrip('+ ').startswith('assert '):results['added_asserts'].append(dict(path=p,line=line))
results['accepted_immutable_in_unit']=not any(p.startswith('docs/archive/completed/2026/friday-telemetry-rewire-telem-') for p in paths['unit']['names'])
results['unit_scope_extra']=json.loads((OUT/'unit-scope.json').read_text())['extra']
save('static-checks.json',results)
print(json.dumps({k:v for k,v in results.items() if k!='ast'},indent=2))
