from run_gate import *
for key,source in [('static-contract','static_checks.py'),('final-contract','final_checks.py')]:
 probe=OUT/source
 save(key+'-r2-probe-freeze.json',dict(script_sha256=sha(probe.read_bytes()),runner_sha256=sha(Path(__file__).read_bytes()),effects='Standard-library source/hash/AST checks;final also reads installed metadata and YAML;no runtime/provider activation.'))
 COMMANDS[key]=['python',str(probe)]
 run(key+'-r2',key)
