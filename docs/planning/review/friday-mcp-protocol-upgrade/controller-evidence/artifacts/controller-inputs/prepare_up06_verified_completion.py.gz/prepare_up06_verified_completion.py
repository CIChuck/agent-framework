"""Controller metadata transaction; run only after the independent review seals."""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import re
import subprocess
import sys

b = Path('/private/tmp/friday-mcp-upgrade')
w = b / 'work'
p = w / 'docs/planning/active/friday-mcp-protocol-upgrade'
r = b / 'independent-review-UP06-002'
d = p / 'validation/VAL-UP06-02'
review = w / 'docs/planning/review/friday-mcp-protocol-upgrade'
candidate = 'c9a8c210eedd85ed9f9418b13c53ac079ebec000'
expected_report, expected_manifest = sys.argv[1:]

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip() == candidate, 'Candidate HEAD drift')
require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=w, text=True).strip(), 'Candidate dirty')
require(digest(r / 'report.md') == expected_report, 'Report seal differs')
require(digest(r / 'evidence-manifest.json') == expected_manifest, 'Manifest seal differs')
report = (r / 'report.md').read_text()
require('**VERIFIED**' in report.splitlines()[:5], 'Independent verdict is not VERIFIED')
mf = json.loads((r / 'evidence-manifest.json').read_text())
authority = json.loads((p / 'authority-UP-06-amendment-002.json').read_text())
request = json.loads((p / 'validation-request-UP-06-amendment-002.json').read_text())
comparison = json.loads((p / 'execution/up06-amend2/verification-comparison.json').read_text())
frozen = comparison['source_hashes']
for name, sha in frozen.items():
    require(digest(w / name) == sha, 'Source drift: ' + name)
for row in request['controls']:
    require(digest(w / row['path']) == row['sha256'], 'Control drift: ' + row['path'])
for name, sha in authority['metadata_hashes'].items():
    require(digest(w / name) == sha, 'Metadata drift: ' + name)
require(not d.exists() and not review.exists(), 'Existing closeout requires reconciliation')
safe = {}
for row in mf['entries']:
    name = row['path']
    path = r / name
    require(not Path(name).is_absolute() and '..' not in Path(name).parts and path.resolve().is_relative_to(r.resolve()), 'Unsafe entry')
    require(path.is_file() and digest(path) == row['sha256'], 'Safe entry seal drift: ' + name)
    if 'bytes' in row:
        require(path.stat().st_size == row['bytes'], 'Entry size drift')
    safe[name] = row
d.mkdir(parents=True)
items = []
for name in sorted(set(safe) | {'report.md', 'evidence-manifest.json'}):
    raw = (r / name).read_bytes()
    destination = d / 'artifacts' / (name + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(gzip.compress(raw, mtime=0))
    items.append({'original_path': name, 'path': str(destination.relative_to(d)), 'encoding': 'gzip', 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'stored_sha256': digest(destination)})
for name in ['report.md', 'evidence-manifest.json']:
    (d / name).write_bytes((r / name).read_bytes())
# Preserve the original report. Only explicitly safe report links get views.
links = re.findall(r'\]\(([^)]+)\)', report)
gzip_aliases = []
for target in links:
    if target.startswith(('https://', 'http://', '#')):
        continue
    name = target.split('#')[0]
    if name in {'report.md', 'evidence-manifest.json'}:
        continue
    if name.endswith('/'):
        rows = [x for x in items if x['original_path'].startswith(name)]
        require(bool(rows), 'Unknown linked directory: ' + name)
        folder = d / name
        folder.mkdir(parents=True, exist_ok=True)
        write_json(folder / 'index.json', {'original_safe_entries': rows, 'archive_root': str(d.relative_to(w))})
        continue
    require(name in safe, 'Unlisted report link: ' + name)
    raw = (r / name).read_bytes()
    destination = d / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    lines = raw.splitlines()
    has_whitespace = any(line.endswith((b' ', b'\t')) for line in lines) or raw.endswith(b'\n\n')
    if ('diff' in Path(name).name and Path(name).suffix == '.txt') or has_whitespace:
        relative_archive = Path('artifacts') / (name + '.gz')
        import os
        destination.symlink_to(os.path.relpath(d / relative_archive, destination.parent))
        gzip_aliases.append(name)
    else:
        require(Path(name).suffix not in {'.py', '.md'}, 'Executable/Markdown link needs explicit safe data view: ' + name)
        destination.write_bytes(raw)
write_json(d / 'stored-manifest.json', {'reviewed_candidate': candidate, 'independent_report_sha256': expected_report, 'independent_manifest_sha256': expected_manifest, 'safe_entries': len(safe), 'artifacts': items, 'gzip_aliases': gzip_aliases, 'storage_note': 'Original report/manifest and safe entries unchanged. Lossless gzip contains original bytes. Listed linked diff/whitespace-bearing text names are gzip aliases, disclosed in navigation. Scripts and captures are data, never executable authority.'})
(d / 'navigation.md').write_text('# Independent aggregate evidence\n\n'
    '[Original sealed report](report.md), [original sealed manifest](evidence-manifest.json), '
    'and [lossless stored hashes](stored-manifest.json).\n\n'
    'Linked diff filenames and whitespace-bearing text entries listed in the '
    'stored manifest are aliases to their gzip archives. Decompress the '
    'archive to read the exact original diff. Original report and evidence bytes '
    'remain unchanged. This is verification, with maintainer acceptance pending.\n')
for item in items:
    require(hashlib.sha256(gzip.decompress((d / item['path']).read_bytes())).hexdigest() == item['sha256'], 'Archive mismatch')
state_path = p / 'execution/current-process-state.json'
state = json.loads(state_path.read_text())
state.update(execution_phase='closeout', validation_state='verified', unit_completion='proposed; whole initiative maintainer acceptance pending', work_state='completed', unit_implementation_authority='closed', next_gate='Maintainer acceptance of the whole MCP upgrade; then delivery planning and separately queued Langfuse', reviewed_candidate=candidate, independent_report=str((d / 'report.md').relative_to(w)), independent_report_sha256=expected_report, independent_manifest_sha256=expected_manifest, current_packet='docs/planning/review/friday-mcp-protocol-upgrade/', note='Whole-feature fresh independent FULL review VERIFIED; controller completion proposal only; acceptance and publication remain separate')
state['builder_finding_dispositions'] = {'BUILD-UP06-001': 'Resolved; independently verified', 'BUILD-UP06-002': 'Resolved; independently verified with real full-current-board rehearsal'}
if state.get('builder_finding'):
    state['builder_finding']['independent_assessment'] = 'verified'
write_json(state_path, state)
log = p / 'execution-log.md'
log.write_text(log.read_text() + '\n\n## Whole-feature independent verification and completion proposal\n\n'
    'VAL-UP06-02 independently VERIFIED candidate ' + candidate + '. All27 checks '
    'and full declared MCP roles/criteria were assessed. The controller proposes '
    'completed/local with a canonical review index and immutable SHA-pinned '
    'historical active backing. All MCP/governance source and controlling bytes '
    'remain unchanged. Whole maintainer acceptance and publication remain separate.\n')
review.mkdir(parents=True)
write_json(review / 'current-process-state.json', state)
(review / 'README.md').write_text('# Friday MCP protocol upgrade — completion proposal\n\n'
    'Work state: **completed**. Validation: **VERIFIED**. Delivery: **local**. '
    'Whole initiative maintainer acceptance is pending.\n\n'
    'The declared client/server profiles target the pinned MCP 2026-07-28 '
    'specification, retain the approved compatibility profiles, and work through '
    'Runtime and Chat configuration. Real subprocess and verified TLS JSON/SSE '
    'cross-peer checks are included in the fresh full review.\n\n'
    '[Closeout and functional evidence](closeout.md). '
    '[Current process state](current-process-state.json). '
    '[Immutable historical authority manifest](historical-authority.json).\n\n'
    'Next gate: maintainer acceptance of the whole upgrade. Langfuse remains '
    'separately queued.\n')
(review / 'closeout.md').write_text('# MCP upgrade closeout\n\n'
    'Fresh independent whole-feature verdict: **VERIFIED** for `' + candidate + '`.\n\n'
    '[Original sealed report](../../active/friday-mcp-protocol-upgrade/validation/VAL-UP06-02/report.md), '
    '[evidence navigation](../../active/friday-mcp-protocol-upgrade/validation/VAL-UP06-02/navigation.md), '
    '[current migration guide](../../../guides/19-mcp-migration.md).\n\n'
    'All27 required checks meet their contracts. Focused MCP cross-peer tests '
    'exercise real stdio and verified TLS Streamable HTTP JSON/SSE, cancellation, '
    'errors and shutdown. Runtime/Chat loaders execute documented configurations. '
    'The governance reconciliation preserves immutable approvals while allowing '
    'a single canonical completed review packet. Full baseline comparisons and '
    'known inherited diagnostics are disclosed in the sealed report.\n\n'
    'Implementation authority is closed. Whole maintainer acceptance, push/PR/merge, '
    'release and optional Langfuse implementation are separate later steps.\n')
rows = {}
controls = authority['controls'] + authority['prior_frozen_manifests'] + [authority['approval'], {'path': str((p / 'authority-UP-06-amendment-002.json').relative_to(w)), 'sha256': digest(p / 'authority-UP-06-amendment-002.json')}]
controls += [{'path': str(path.relative_to(w)), 'sha256': digest(path)} for path in [d / 'report.md', d / 'evidence-manifest.json', d / 'stored-manifest.json', p / 'validation-request-UP-06-amendment-002.json', state_path, log]]
packet = str(p.relative_to(w)) + '/'
for row in controls:
    name = row['path']
    if not name.startswith(packet):
        continue
    require(digest(w / name) == row['sha256'], 'Backing authority drift')
    base = Path(name).name
    kind = 'index' if name == packet + 'README.md' else 'authority' if base.startswith('authority') else 'approval' if base.startswith('approval') or '/acceptance/' in name else 'directive' if '/directives/' in name else 'report' if '/validation/' in name and 'report' in base else 'evidence'
    rows[name] = {'path': name, 'sha256': row['sha256'], 'kind': kind}
manifest_path = review / 'historical-authority.json'
write_json(manifest_path, {'version': 1, 'owner': authority['initiative'], 'packet': packet, 'files': list(rows.values())})
spec = importlib.util.spec_from_file_location('up06_closeout_board', w / 'scripts/friday-dev-board.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
board = module.load_board(w)
task = next(t for t in board['tasks'] if t['id'] == authority['initiative'])
require(task['work_state'] == 'started' and task['delivery_state'] == 'local', 'Unexpected current board state')
task.update(work_state='completed', implementation_authority='closed', packet=str(review.relative_to(w)) + '/', next_gate=state['next_gate'], authority_backing_packets=[{'packet': packet, 'manifest': str(manifest_path.relative_to(w)), 'manifest_sha256': digest(manifest_path)}])
task['validation'].append(str((d / 'report.md').relative_to(w)) + ': VERIFIED fresh whole-feature27-check review; acceptance pending')
module._append_event(board, task_id=authority['initiative'], actor='Codex', actor_role='agent', action='transitioned started -> completed', note='Fresh independent FULL whole-feature VERIFIED; completed/local proposal with immutable authority backing; maintainer acceptance pending', evidence=str((d / 'report.md').relative_to(w)))
module._save_board_and_dashboard(board, w)
require(module.validate_board(module.load_board(w), w) == [], 'Closeout board validation failed')
for name, sha in frozen.items():
    require(digest(w / name) == sha, 'Closeout changed source')
for row in request['controls']:
    require(digest(w / row['path']) == row['sha256'], 'Closeout changed control')
print(json.dumps({'verdict': 'VERIFIED', 'reviewed_candidate': candidate, 'report_sha256': expected_report, 'manifest_sha256': expected_manifest, 'safe_entries': len(safe), 'backing_records': len(rows), 'work_state': 'completed', 'delivery_state': 'local', 'acceptance': 'pending', 'source_changes': 0}, indent=2))
