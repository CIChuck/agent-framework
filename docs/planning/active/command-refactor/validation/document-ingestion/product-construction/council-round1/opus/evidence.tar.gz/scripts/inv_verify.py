import ast, gzip, hashlib, json, os, subprocess, sys, collections
repo, base = sys.argv[1], sys.argv[2]
P = repo + "/docs/planning/active/command-refactor/validation/document-ingestion/product-construction/"
inv = json.loads(gzip.decompress(open(P + "baseline-test-inventory.json.gz", "rb").read()))
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
def git(*a): return subprocess.check_output(["git", *a], cwd=repo, env=env)
mods = inv["modules"]
print("module_keys", sorted(mods[0].keys()))
print("node_keys", sorted(mods[0]["static_base_nodes"][0].keys()))
print("extra module fields sample", {k: v for k, v in mods[0].items() if k not in ("static_base_nodes",)})
roots = collections.Counter(m["path"].split("/")[0] + "/" + (m["path"].split("/")[1] if m["path"].startswith("packages") else "") for m in mods)
print("roots", dict(roots))
print("any root tests/ modules:", [m["path"] for m in mods if m["path"].startswith("tests/")][:5])
# list all base test files in tree
files = git("ls-tree", "-r", "--name-only", base).decode().splitlines()
cand = [f for f in files if f.endswith(".py") and os.path.basename(f).startswith("test_")]
pk = [f for f in cand if f.startswith("packages/")]
rootint = [f for f in cand if f.startswith("tests/")]
print("base package test_*.py files:", len(pk), " root tests/ test_*.py files:", len(rootint))
invpaths = {m["path"] for m in mods}
missing = sorted(set(pk) - invpaths)
print("package test files not in inventory:", len(missing), missing[:15])
print("inventory paths not package test files:", sorted(invpaths - set(pk))[:10])
# verify blob hashes and node names
bad_hash = 0; node_mismatch = []; total_nodes = 0
for m in mods:
    b = git("show", f"{base}:{m['path']}")
    if hashlib.sha256(b).hexdigest() != m["sha256"]: bad_hash += 1
    tree = ast.parse(b)
    names = []
    def visit(body, prefix):
        for n in body:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith("test"):
                names.append(prefix + n.name)
            elif isinstance(n, ast.ClassDef) and n.name.startswith("Test"):
                visit(n.body, prefix + n.name + "::")
    visit(tree.body, "")
    inv_names = [x["node"] for x in m["static_base_nodes"]]
    total_nodes += len(inv_names)
    if sorted(names) != sorted(inv_names): node_mismatch.append((m["path"], len(names), len(inv_names)))
print("module hash mismatches:", bad_hash, " total nodes:", total_nodes, " node-name mismatches:", len(node_mismatch), node_mismatch[:5])
fx = inv["fixtures_and_conftests"]; badfx = 0
for f in fx:
    if hashlib.sha256(git("show", f"{base}:{f['path']}")).hexdigest() != f["sha256"]: badfx += 1
print("fixtures:", len(fx), "hash mismatches:", badfx)
# seed checks
seed = json.load(open(P + "test-migration-seed.json"))
bymod = {m["path"]: m for m in mods}
for e in seed["entries"]:
    m = bymod.get(e["old_path"])
    nodes = {x["node"]: x for x in m["static_base_nodes"]} if m else {}
    n = nodes.get(e["old_node"])
    print(e["id"], "path_in_inv", bool(m), "file_sha_ok", m and m["sha256"] == e["old_file_sha256"], "node_found", bool(n), "def_sha_ok", bool(n) and n.get("definition_sha256") == e["old_definition_sha256"])
