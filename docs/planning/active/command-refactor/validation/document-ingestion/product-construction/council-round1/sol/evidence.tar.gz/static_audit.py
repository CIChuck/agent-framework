import ast,gzip,hashlib,json,os,subprocess,tomllib
from pathlib import Path
R=Path('/Users/chuckrussell/Dev/gendev/agent-framework'); S=Path('/private/tmp/ingest-sol-review-jDcr1r'); P=R/'docs/planning/active/command-refactor/validation/document-ingestion/product-construction'
sha=lambda b:hashlib.sha256(b).hexdigest()
x=json.loads(gzip.decompress((P/'baseline-test-inventory.json.gz').read_bytes()))
errors=[]
for rec in x['modules']+x['fixtures_and_conftests']:
 if sha((R/rec['path']).read_bytes())!=rec['sha256']:errors.append(rec['path'])
seed=json.loads((P/'test-migration-seed.json').read_bytes())
for e in seed['entries']:
 m=next(m for m in x['modules'] if m['path']==e['old_path']); n=next(n for n in m['static_base_nodes'] if n['node']==e['old_node'])
 if m['sha256']!=e['old_file_sha256'] or n['definition_sha256']!=e['old_definition_sha256']:errors.append(e['id'])
paths={
'packages/friday-chat/src/friday_chat/commands/registry.py':['execute','_parse_command_input','_handle_read','_handle_ingest'],
'packages/friday-chat/src/friday_chat/adapters.py':['ingest_document','build_framework_embedding_service','_chunk_text'],
'packages/friday-llm/src/friday_llm/embeddings.py':['embed_documents','embed_query','_embed_batch'],
'packages/friday-memory/src/friday_memory/adapters/vector.py':['__init__','query','_get_embeddings'],
'packages/friday-memory/src/friday_memory/context/assembler.py':['extract_context'],
'packages/friday-tools/src/friday_tools/filesystem/smart_read.py':['run','_store_in_memory'],
'packages/friday-tools/src/friday_tools/filesystem/readers/factory.py':['get_reader_for_path','get_reader'],
'packages/friday-core/src/friday_core/profiles.py':['create_vector_store'],
'packages/friday-memory/src/friday_memory/maintenance/recovery_models.py':[],
'packages/friday-chat/src/friday_chat/reorganization/contracts.py':[],
}
records=[]; excerpts=[]
for f,names in paths.items():
 b=(R/f).read_bytes(); t=ast.parse(b); records.append({'path':f,'sha256':sha(b),'classes':[n.name for n in ast.walk(t) if isinstance(n,ast.ClassDef)]})
 for n in ast.walk(t):
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names:
   excerpts.append(f'\n{f}:{n.lineno}-{n.end_lineno}\n'+ast.get_source_segment(b.decode(),n))
(S/'source-excerpts.txt').write_text('\n'.join(excerpts))
out={'errors':errors,'modules':len(x['modules']),'static_base_nodes':sum(len(m['static_base_nodes']) for m in x['modules']),'fixture_files':len(x['fixtures_and_conftests']),'uncompressed_sha256':sha(gzip.decompress((P/'baseline-test-inventory.json.gz').read_bytes())),'seeds_verified':len(seed['entries']),'source':records}
(S/'static-evidence.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
