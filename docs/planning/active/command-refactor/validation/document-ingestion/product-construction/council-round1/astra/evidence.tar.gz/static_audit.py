import ast,gzip,hashlib,json,os,pathlib,subprocess,tomllib
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); S=pathlib.Path('/private/tmp/ingest-astra-r1-Xhb9MQAm'); P=R/'docs/planning/active/command-refactor/validation/document-ingestion/product-construction'
sha=lambda b:hashlib.sha256(b).hexdigest()
env=os.environ|{'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1','XDG_CACHE_HOME':str(S/'xdg-cache'),'XDG_CONFIG_HOME':str(S/'xdg-config'),'TMPDIR':str(S/'tmp')}
commands=[]
def git(*args):
 p=subprocess.run(['git',*args],cwd=R,env=env,capture_output=True); commands.append({'argv':['git',*args],'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}); return p.stdout
names=git('diff','--name-only','8c36d8e26c618032c1ff536004a582c07ec56a5b..fb587e7a12f48ef0d6937e008045de1de2dd8cd2').decode().splitlines()
raw=gzip.decompress((P/'baseline-test-inventory.json.gz').read_bytes()); inv=json.loads(raw); errors=[]; counts=0
for m in inv['modules']:
 b=(R/m['path']).read_bytes()
 if sha(b)!=m['sha256']:errors.append(m['path'])
 t=ast.parse(b); nodes={}
 def walk(n,prefix=''):
  for x in n.body:
   if isinstance(x,ast.ClassDef):walk(x,prefix+x.name+'::')
   elif isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) and x.name.startswith('test_'):nodes[prefix+x.name]=x
 walk(t)
 if set(nodes)!={n['node'] for n in m['static_base_nodes']}:errors.append('nodes:'+m['path'])
 counts+=len(nodes)
for f in inv['fixtures_and_conftests']:
 if sha((R/f['path']).read_bytes())!=f['sha256']:errors.append(f['path'])
seed=json.loads((P/'test-migration-seed.json').read_bytes())
for e in seed['entries']:
 m=next(m for m in inv['modules'] if m['path']==e['old_path']); n=next(n for n in m['static_base_nodes'] if n['node']==e['old_node'])
 if e['old_file_sha256']!=m['sha256'] or e['old_definition_sha256']!=n['definition_sha256']: errors.append(e['id'])
paths=['friday-core/src/friday_core/profiles.py','friday-core/src/friday_core/interfaces/memory.py','friday-llm/src/friday_llm/embeddings.py','friday-llm/src/friday_llm/model_library.py','friday-chat/src/friday_chat/commands/files.py','friday-chat/src/friday_chat/commands/registry.py','friday-chat/src/friday_chat/adapters.py','friday-chat/src/friday_chat/memory_mcp.py','friday-chat/src/friday_chat/reorganization/contracts.py','friday-chat/src/friday_chat/reorganization/coordinator.py','friday-tools/src/friday_tools/filesystem/smart_read.py','friday-tools/src/friday_tools/filesystem/readers/factory.py','friday-memory/src/friday_memory/adapters/vector.py','friday-memory/src/friday_memory/maintenance/backup.py','friday-memory/src/friday_memory/maintenance/recovery_models.py','friday-memory/src/friday_memory/context/assembler.py','friday-memory/src/friday_memory/retrieval/graph_scorer.py','friday-runtime/src/friday_runtime/di.py','friday-runtime/src/friday_runtime/config.py','friday-runtime/src/friday_runtime/tool_loading.py','friday-cli/src/friday_cli/container.py']
sources=[]
for rel in paths:
 p=R/'packages'/rel; b=p.read_bytes(); t=ast.parse(b)
 sources.append({'path':str(p.relative_to(R)),'sha256':sha(b),'lines':len(b.splitlines()),'definitions':[{'name':n.name,'line':n.lineno,'end':n.end_lineno} for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))],'imports':[ast.unparse(n) for n in ast.walk(t) if isinstance(n,(ast.Import,ast.ImportFrom))]})
metadata=[]
for p in sorted((R/'packages').glob('*/pyproject.toml')):
 b=p.read_bytes(); x=tomllib.loads(b.decode());metadata.append({'path':str(p.relative_to(R)),'sha256':sha(b),'project':x['project']['name'],'dependencies':x['project'].get('dependencies',[]),'extras':list(x['project'].get('optional-dependencies',{}))})
result={'inventory':{'modules':len(inv['modules']),'static_tests':counts,'fixtures':len(inv['fixtures_and_conftests']),'raw_sha256':sha(raw),'errors':errors,'seed_entries':len(seed['entries']),'definition_hashes':'seed matches supplied inventory; all node names independently AST checked; bodies not dynamically run'},'candidate_changed_filenames':names,'selected_sources':sources,'package_metadata':metadata}
(S/'static-evidence.json').write_text(json.dumps(result,indent=2)+'\n');(S/'static-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({'inventory':result['inventory'],'selected_sources':len(sources),'metadata':len(metadata),'candidate_changes':names},indent=2))
