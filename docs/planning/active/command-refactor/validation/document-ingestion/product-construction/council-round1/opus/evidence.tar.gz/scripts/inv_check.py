import ast, gzip, hashlib, json, os, subprocess, sys
repo, base = sys.argv[1], sys.argv[2]
P = repo + "/docs/planning/active/command-refactor/validation/document-ingestion/product-construction/"
raw = open(P + "baseline-test-inventory.json.gz", "rb").read()
print("gz_sha", hashlib.sha256(raw).hexdigest())
un = gzip.decompress(raw)
print("json_sha", hashlib.sha256(un).hexdigest())
inv = json.loads(un)
print("top_keys", sorted(inv.keys()) if isinstance(inv, dict) else type(inv))
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
def blob(path):
    return subprocess.check_output(["git", "show", f"{base}:{path}"], cwd=repo, env=env)
# summarise structure
for k, v in inv.items():
    if isinstance(v, list):
        print(k, "list", len(v), (json.dumps(v[0])[:300] if v else ""))
    elif isinstance(v, dict):
        print(k, "dict", len(v), list(v)[:5])
    else:
        print(k, "=", repr(v)[:200])
