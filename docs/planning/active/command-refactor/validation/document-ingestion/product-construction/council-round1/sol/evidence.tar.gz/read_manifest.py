import hashlib,json
from pathlib import Path
R=Path('/Users/chuckrussell/Dev/gendev/agent-framework'); S=Path('/private/tmp/ingest-sol-review-jDcr1r')
q=json.loads(Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-product-council-r1-3346ng5a/request.json').read_bytes())
records=[]
for e in q['pins']:
 p=Path(e['path']); p=p if p.is_absolute() else R/p
 hash_only= e['path'].endswith('roster.json') or '/.agents/' in str(p) or p.name=='boundary.json'
 b=p.read_bytes(); records.append({'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'mode':'hash only' if hash_only else 'governing context read; JSON parsed or text inspected'})
for r in json.loads((S/'static-evidence.json').read_text())['source']:
 p=R/r['path']; records.append({'path':str(p),'sha256':r['sha256'],'mode':'targeted AST and selected complete function source; no import'})
(S/'read-manifest.json').write_text(json.dumps(records,indent=2)+'\n');print('Recorded',len(records),'bounded input/source records; no excluded payload interpretation')
