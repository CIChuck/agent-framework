"""Read exact hash-bound source chunks without imports, execution or writes."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

p = argparse.ArgumentParser()
p.add_argument("--manifest", required=True, type=Path)
p.add_argument("--path", required=True)
p.add_argument("--chunk", type=int)
p.add_argument("--index", action="store_true")
a = p.parse_args()
m = json.loads(a.manifest.read_bytes())
records = {r["path"]: r for r in m["files"]}
if a.path not in records:
    raise ValueError("Path is not in the allowed reading manifest")
r = records[a.path]
root = Path(m["repo"]).resolve(strict=True)
source = (root / a.path).resolve(strict=True)
if root not in source.parents or not source.is_file():
    raise ValueError("Reading path escaped the recorded repository")
body = source.read_bytes()
if hashlib.sha256(body).hexdigest() != r["sha256"]:
    raise ValueError("Source bytes differ from the frozen manifest")
if a.index:
    print(json.dumps({"path": r["path"], "sha256": r["sha256"],
                      "chunk_count": len(r["chunks"]),
                      "chunks": [{"index": i, "first": x["first_line"],
                                  "last": x["last_line"]}
                                 for i, x in enumerate(r["chunks"])]}))
else:
    if a.chunk is None or a.chunk < 0 or a.chunk >= len(r["chunks"]):
        raise ValueError("Choose a valid recorded chunk index")
    ch = r["chunks"][a.chunk]
    lines = body.decode("utf-8").splitlines(keepends=True)
    text = "".join(lines[ch["first_line"] - 1:ch["last_line"]])
    if hashlib.sha256(text.encode()).hexdigest() != ch["sha256"]:
        raise ValueError("Chunk bytes differ from the frozen manifest")
    print(f"{a.path}: lines {ch['first_line']}-{ch['last_line']}; chunk {a.chunk}")
    sys.stdout.write(text)
