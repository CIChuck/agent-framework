"""Read-only document-review boundaries and fixed offline administration."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def environment(scratch: Path) -> dict[str, str]:
    return os.environ | {
        "GIT_OPTIONAL_LOCKS": "0",
        "PYTHONDONTWRITEBYTECODE": "1",
        "UV_CACHE_DIR": str(scratch / "uv-cache"),
        "UV_NO_CONFIG": "true",
        "UV_PYTHON_DOWNLOADS": "never",
        "XDG_CACHE_HOME": str(scratch / "xdg-cache"),
        "XDG_CONFIG_HOME": str(scratch / "xdg-config"),
        "TMPDIR": str(scratch / "tmp"),
    }


def metadata(path: Path) -> dict[str, object]:
    if not path.exists() and not path.is_symlink():
        return {"absent": True}
    info = path.lstat()
    result: dict[str, object] = {
        "mode": info.st_mode,
        "size": info.st_size,
        "mtime_ns": info.st_mtime_ns,
        "ctime_ns": info.st_ctime_ns,
        "birthtime": info.st_birthtime,
    }
    if stat.S_ISREG(info.st_mode):
        result["sha256"] = sha(path)
    return result


def boundary(request: dict[str, object], scratch: Path, label: str) -> int:
    repo = Path(str(request["repo"]))
    expected = json.loads(Path(str(request["boundary"])).read_bytes())
    env = environment(scratch)

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=repo, env=env)

    # Measure logical index before any status query.
    logical = hashlib.sha256(git("ls-files", "-s", "-z")).hexdigest()
    head = git("rev-parse", "HEAD").decode().strip()
    branch = git("branch", "--show-current").decode().strip()
    staged = git("diff", "--cached", "--name-only").decode()
    status = git("status", "--short", "--untracked-files=normal").decode()
    errors: list[str] = []
    for name, actual in [
        ("logical_index_before_status", logical),
        ("head", head),
        ("branch", branch),
        ("staged", staged),
        ("status", status),
    ]:
        if actual != expected[name]:
            errors.append(name)
    for name, digest in expected["tracked_files"].items():
        path = repo / name
        if not path.is_file() or sha(path) != digest:
            errors.append("tracked:" + name)
    for name, target in expected["symlinks"].items():
        path = repo / name
        if not path.is_symlink() or os.readlink(path) != target:
            errors.append("symlink:" + name)
    for name, record in expected["preserved"].items():
        if metadata(repo / name) != record:
            errors.append("preserved:" + name)
    for item in request["pins"]:
        path = Path(item["path"])
        if not path.is_absolute():
            path = repo / path
        if not path.is_file() or sha(path) != item["sha256"]:
            errors.append("pin:" + item["path"])
    result = {
        "passed": not errors,
        "errors": errors,
        "head": head,
        "branch": branch,
        "logical_index_before_status": logical,
        "status": status,
        "staged": staged,
        "tracked_files_checked": len(expected["tracked_files"]),
        "symlinks_checked": len(expected["symlinks"]),
        "preserved_entries_checked": len(expected["preserved"]),
        "pins_checked": len(request["pins"]),
    }
    (scratch / (label + "-integrity.json")).write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(json.dumps(result, indent=2))
    return int(bool(errors))


def admin(request: dict[str, object], scratch: Path) -> int:
    repo = Path(str(request["repo"]))
    env = environment(scratch)
    uv = [
        "uv", "run", "--offline", "--frozen", "--no-sync",
        "--no-python-downloads", "python", "-B",
    ]
    commands = [
        ("board", uv + ["scripts/friday-dev-board.py", "validate"]),
        ("dashboard", uv + ["scripts/friday-dev-board.py", "render", "--check"]),
        ("docs", uv + ["scripts/check-documentation-lifecycle.py"]),
        ("metadata", uv + ["scripts/check-package-metadata.py"]),
        ("range-whitespace", [
            "git", "diff", "--check", str(request["base"]) + ".." +
            str(request["candidate"]), "--", "docs/planning",
        ]),
        ("owned-whitespace", ["git", "diff", "--check", "--", "docs/planning"]),
        ("staged-whitespace", ["git", "diff", "--cached", "--check"]),
    ]
    results: list[dict[str, object]] = []
    for name, argv in commands:
        process = subprocess.run(
            argv, cwd=repo, env=env, capture_output=True, text=True, timeout=120
        )
        result = {
            "name": name, "argv": argv, "cwd": str(repo),
            "exit": process.returncode, "stdout": process.stdout,
            "stderr": process.stderr,
        }
        results.append(result)
        print(name, process.returncode, process.stdout.strip(), process.stderr.strip())
    (scratch / "admin-commands.json").write_text(json.dumps(results, indent=2) + "\n")
    return int(any(item["exit"] for item in results))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["boundary", "admin"])
    parser.add_argument("--request", required=True, type=Path)
    parser.add_argument("--scratch", required=True, type=Path)
    parser.add_argument("--label", choices=["opening", "closing"], default="opening")
    args = parser.parse_args()
    request = json.loads(args.request.read_bytes())
    scratch = args.scratch.resolve()
    repo = Path(request["repo"]).resolve()
    supplied = Path(request["controller_scratch"]).resolve()
    if (
        not args.scratch.is_absolute() or scratch != args.scratch
        or scratch == repo or repo in scratch.parents
        or scratch == supplied or supplied in scratch.parents
    ):
        raise ValueError("Use physical reviewer-owned external scratch")
    scratch.mkdir(parents=True, exist_ok=True)
    (scratch / "tmp").mkdir(exist_ok=True)
    if args.action == "boundary":
        return boundary(request, scratch, args.label)
    return admin(request, scratch)


if __name__ == "__main__":
    raise SystemExit(main())
