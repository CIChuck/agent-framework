import sys
import pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from review import *
import tarfile
import re

B=REPO/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/large-documents'
idx=json.loads((B/'evidence-index.json').read_text())
assert sha(B/'evidence.tar.gz')==idx['archive_sha256']
expected={x['path']:x for x in idx['members']}
result={'archive_sha256':idx['archive_sha256'],'members':[],'typing_source_matches':[],'generation_source_matches':[]}
with tarfile.open(B/'evidence.tar.gz') as t:
    members=t.getmembers()
    assert len(members)==len(expected)==191
    assert len({m.name for m in members})==191
    for m in members:
        p=pathlib.PurePosixPath(m.name)
        assert m.isfile() and not p.is_absolute() and '..' not in p.parts and str(p)==m.name and '\\' not in m.name
        assert m.size==expected[m.name]['size'] and m.size<=16*1024**2
        raw=t.extractfile(m).read()
        h=hashlib.sha256(raw).hexdigest()
        assert h==expected[m.name]['sha256']
        result['members'].append({'path':m.name,'size':len(raw),'sha256':h})
        if m.name.startswith('typing-source/'):
            rel=m.name.removeprefix('typing-source/')
            current=REPO/('pyproject.toml' if rel=='pyproject.toml' else 'tests/readiness/ingest/'+rel)
            assert h==sha(current)
            if rel=='pyproject.toml': assert h==sha(pathlib.Path(R['private_tools'])/'pyproject.toml')
            result['typing_source_matches'].append(rel)
        if m.name.startswith('normal/source/ingest/'):
            rel=m.name.removeprefix('normal/source/ingest/')
            original=subprocess.check_output(['git','cat-file','blob',R['actual_generation_source']+':tests/readiness/ingest/'+rel])
            assert original==raw
            result['generation_source_matches'].append(rel)
        if m.name.endswith('.png'):
            dest=S/'saved-layout'/p.name
            dest.parent.mkdir(exist_ok=True)
            dest.write_bytes(raw)
    assert len(result['typing_source_matches'])==32
    assert len(result['generation_source_matches'])==35
receipt=json.loads((pathlib.Path(R['review_boundary']).parent/'mypy-last.json').read_text())
assert receipt['exit']==0 and receipt['stdout']=='Success: no issues found in 31 source files\n'
assert len([x for x in result['typing_source_matches'] if x.endswith('.py')])==31
result['typing_evidence']='Inspected pinned receipt; archive retained 31 exact current source bytes and exact root/private config. Not rerun.'
for mode in ['normal','optimized']:
    root=S/'.friday_test/runs'/('large-documents-review-'+mode)
    supplied=pathlib.Path(next(x['root'] for x in R['corpus_runs'] if x['mode']==mode))
    generated={p.name:sha(p) for p in (root/'inputs/corpus').iterdir()}
    original={p.name:sha(p) for p in (supplied/'inputs/corpus').iterdir()}
    assert generated==original
    result[mode+'_reproduced_corpus']=generated
    for rel in ['large_documents.py','fixtures.py']:
        prior=subprocess.check_output(['git','cat-file','blob',R['actual_generation_source']+':tests/readiness/ingest/'+rel])
        assert prior==(root/'source/ingest'/rel).read_bytes()
    result[mode+'_native_validation']=json.loads((root/'reports/native-validation.json').read_text())
(S/'archive-and-attribution.json').write_text(json.dumps(result,indent=2))
print('ARCHIVE PASS 191 regular unique members; all indexed sizes/hashes exact; generation-source35 exact actual source; typing31 + config exact current')
print('BOTH FRESH CORPORA MATCH ORIGINALS',len(result['normal_reproduced_corpus']),'members each')
print('TYPING INSPECTED',receipt['stdout'].strip())
ruff=str(pathlib.Path(R['private_tools'])/'ruff')
root=S/'.friday_test/runs/large-documents-review-normal/source/ingest'
run('ruff-version',[ruff,'--version'])
run('ruff-check',[ruff,'check','--no-cache','--config',str(pathlib.Path(R['private_tools'])/'pyproject.toml'),str(root)])
run('ruff-format',[ruff,'format','--check','--no-cache','--config',str(pathlib.Path(R['private_tools'])/'pyproject.toml'),str(root)])
