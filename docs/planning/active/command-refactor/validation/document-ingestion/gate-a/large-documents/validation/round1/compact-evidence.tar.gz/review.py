import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

S = pathlib.Path(__file__).resolve().parent
R = json.loads((S / 'request.json').read_text())
REPO = pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
PY = '/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while raw := f.read(1024*1024): h.update(raw)
    return h.hexdigest()

def tree(path):
    result={}
    for p in [path,*sorted(path.rglob('*'))]:
        st=p.lstat()
        v={'mode':st.st_mode,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'nlink':st.st_nlink}
        if p.is_symlink():v['symlink']=os.readlink(p)
        elif p.is_file():v['sha256']=sha(p)
        result[str(p.relative_to(path))]=v
    return result

def run(name,args,cwd=REPO):
    env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1','UV_CACHE_DIR':str(S/'cache/uv'),'UV_NO_CONFIG':'true','UV_PYTHON_DOWNLOADS':'never','TMPDIR':str(S/'tmp'),'XDG_CACHE_HOME':str(S/'cache/xdg'),'XDG_CONFIG_HOME':str(S/'config/xdg')}
    start=time.time()
    p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
    record={'name':name,'argv':args,'cwd':str(cwd),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':round(time.time()-start,3)}
    (S/(name+'.json')).write_text(json.dumps(record,indent=2))
    print(name,'exit',p.returncode,p.stdout[-500:].strip(),p.stderr[-180:].strip(),flush=True)
    return record

def prepare():
    for name in ['tmp','cache','config','selftest-normal','selftest-optimized']:(S/name).mkdir(exist_ok=True)
    paths={'harness':R['frozen_harness'],'tools':R['private_tools'],'target':R['private_native_target'],**{v['mode']:v['root'] for v in R['corpus_runs']}}
    data={k:tree(pathlib.Path(v)) for k,v in paths.items()}
    (S/'opening-input-trees.json').write_text(json.dumps(data,indent=2))
    print('IMMUTABLE TREES',[(k,len(v)) for k,v in data.items()],flush=True)
    for mode in ['normal','optimized']:
        root=S/'.friday_test/runs'/('large-documents-review-'+mode)
        root.mkdir(parents=True)
        for name in ['source','inputs','reports','config','cache','tmp']:(root/name).mkdir()
        shutil.copytree(R['frozen_harness'],root/'source/ingest')
    manifest=json.loads(pathlib.Path(R['frozen_manifest']).read_text())
    for row in manifest['files']:
        if sha(pathlib.Path(R['frozen_harness'])/row['path'])!=row['sha256']:raise ValueError('Harness mismatch')
    print('FROZEN HARNESS',len(manifest['files']),'members exact',flush=True)

def selftest(mode):
    args=[PY,'-I','-S','-B']+(['-O'] if mode=='optimized' else [])+[R['frozen_harness']+'/bootstrap.py','selftest','--harness-manifest',R['frozen_manifest'],'--harness-manifest-sha256',R['frozen_manifest_sha256'],'--scratch',str(S/('selftest-'+mode))]
    run('selftest-'+mode,args)

def corpus(mode):
    root=S/'.friday_test/runs'/('large-documents-review-'+mode)
    prefix=[PY,'-I','-S','-B']+(['-O'] if mode=='optimized' else [])+[str(root/'source/ingest/large_documents.py')]
    for command in ['generate','verify','validate']:
        args=prefix+[command,'--run-root',str(root)]+(['--target',R['private_native_target']] if command=='validate' else [])
        if run(command+'-'+mode,args)['exit']:return

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='selftest':selftest(sys.argv[2])
    elif action=='corpus':corpus(sys.argv[2])
