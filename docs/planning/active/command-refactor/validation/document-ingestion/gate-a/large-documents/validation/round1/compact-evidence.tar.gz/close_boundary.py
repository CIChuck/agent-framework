import sys
import pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from review import *

def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1'})
b=json.loads(pathlib.Path(R['review_boundary']).read_text())
logical=hashlib.sha256(git('ls-files','-s','-z')).hexdigest()
status=git('status','--porcelain=v1','--untracked-files=normal').decode()
def meta(p,include):
    st=p.lstat();v={k:getattr(st,'st_'+k) for k in ['mode','size','mtime_ns','ctime_ns','birthtime']}
    if include:v['sha256']=sha(p)
    return v
actual={'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'logical_before_status':logical,'status':status,'tracked_sha256':{n:sha(REPO/n) for n in b['tracked_sha256']},'symlinks':{n:os.readlink(REPO/n) for n in b['symlinks']},'preserved':{n:meta(REPO/n,'sha256' in v) for n,v in b['preserved'].items()},'staging':git('diff','--cached','--name-status').decode()}
opening=json.loads((S/'opening-boundary.json').read_text())
checks={k:actual[k]==opening[k] for k in opening}
(S/'closing-boundary.json').write_text(json.dumps(actual,indent=2))
for k,v in checks.items():print('CLOSING',k,'MATCH' if v else 'MISMATCH')
if not all(checks.values()):raise ValueError('Repository boundary changed')
for name,expected in R['inputs'].items():
    p=pathlib.Path(name);p=p if p.is_absolute() else REPO/p
    if sha(p)!=expected:raise ValueError('Request input pin changed '+name)
paths={'harness':R['frozen_harness'],'tools':R['private_tools'],'target':R['private_native_target'],**{v['mode']:v['root'] for v in R['corpus_runs']}}
current={k:tree(pathlib.Path(v)) for k,v in paths.items()}
before=json.loads((S/'opening-input-trees.json').read_text())
treechecks={k:current[k]==before[k] for k in current}
(S/'closing-input-trees.json').write_text(json.dumps(current,indent=2))
for k,v in treechecks.items():print('INPUT',k,len(current[k]),'UNCHANGED' if v else 'CHANGED')
if not all(treechecks.values()):raise ValueError('Supplied input tree changed')
summary={'repo_boundary':checks,'supplied_trees':treechecks,'request_input_pins':'ALL MATCH','authority':'HASH ONLY MATCH','logical_index':logical,'staging_empty':not actual['staging'],'tracked_files':len(b['tracked_sha256']),'symlinks':len(b['symlinks']),'preserved_entries':len(b['preserved'])}
(S/'integrity-summary.json').write_text(json.dumps(summary,indent=2))
print('FINAL INTEGRITY PASS')
