import pathlib,json,hashlib,subprocess,os
S=pathlib.Path('/private/tmp/large-document-independent-review-HLnkri'); R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); P=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n'); request=json.loads((P/'large-review-request.json').read_bytes()); before=json.loads((S/'opening-boundary.json').read_text()); supplied=json.loads((P/'large-review-boundary.json').read_text()); env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def git(*a): return subprocess.run(['git',*a],cwd=R,env=env,capture_output=True,check=True).stdout
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
normal=S/'.friday_test/runs/large-documents-review-normal/inputs/corpus'; optimized=S/'.friday_test/runs/large-documents-review-optimized/inputs/corpus'; rows=[]
for p in sorted(normal.iterdir()):
 raw=p.read_bytes(); equal=p.name in [x.name for x in optimized.iterdir()] and raw==(optimized/p.name).read_bytes()
 matches={mode:raw==(S/'archive'/mode/'inputs/corpus'/p.name).read_bytes()==(pathlib.Path(root['root'])/'inputs/corpus'/p.name).read_bytes() for mode,root in zip(('normal','optimized'),request['corpus_runs'])}
 rows.append({'path':p.name,'sha256':sha(p),'fresh_modes_equal':equal,'fresh_archive_supplied_equal':matches}); assert equal and all(matches.values())
check={};
for name in ('large_documents.py','fixtures.py','behavior.py','e2e.py'):
 current=(S/'harness'/name).read_bytes(); check[name]={'actual_generator_commit_equal':current==git('show',request['actual_generation_source']+':tests/readiness/ingest/'+name)}
 if name!='large_documents.py': check[name]['base_equal']=current==git('show',request['base']+':tests/readiness/ingest/'+name)
 assert all(check[name].values())
typed=json.loads((S/'typing-inspection.json').read_text()); assert not typed['different_sources'] and typed['config_equals_private'] and typed['config_equals_current'] and typed['receipt']['exit']==0
tracked_diffs=[p for p,h in supplied['tracked_sha256'].items() if before['tracked'][p].get('sha256')!=h]; symlink_diffs=[p for p,v in supplied['symlinks'].items() if before['tracked'][p].get('symlink')!=v]; preserved_diffs=[p for p,v in supplied['preserved'].items() if before['preserved'][p]!=v]
assert not tracked_diffs and not symlink_diffs and not preserved_diffs
visual=[{'path':f'archive/normal/reports/pdf-384-page-{n}.png','sha256':sha(S/f'archive/normal/reports/pdf-384-page-{n}.png'),'inspection':'Legible native text inside physical page margins; no visible overlap or clipped glyphs. Text can continue across page boundary.'} for n in (1,24,46)]
report={'status':'PASS','corpus_files':rows,'document_count':25,'corpus_entries_including_oracle_manifest':len(rows),'source_bytes_without_manifest_or_oracles':sum(x.stat().st_size for x in normal.iterdir() if x.suffix in ('.pdf','.docx','.xlsx','.pptx','.txt')),'all_corpus_bytes':sum(x.stat().st_size for x in normal.iterdir()),'source_commit_equality':check,'supplied_opening_boundary_comparison':{'tracked_difference_count':len(tracked_diffs),'symlink_difference_count':len(symlink_diffs),'preserved_difference_count':len(preserved_diffs),'head_branch_index_equal':before['head']==supplied['head'] and before['branch']==supplied['branch'] and before['logical_index_sha256']==supplied['logical_before_status'],'status_comparison':git('status','--porcelain=v1').decode()==supplied['status']},'typing_receipt_source_config_exact':True,'visual_inspection':visual}
(S/'equivalence.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps({k:v for k,v in report.items() if k not in ('corpus_files','visual_inspection')},indent=2))
