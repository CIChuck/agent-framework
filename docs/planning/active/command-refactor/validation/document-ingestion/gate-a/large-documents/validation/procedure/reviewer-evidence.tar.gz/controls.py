import pathlib,sys,json,os,shutil,hashlib
from unittest.mock import patch
S=pathlib.Path('/private/tmp/large-document-independent-review-HLnkri'); mode=sys.argv[1]; sys.path.insert(0,str(S/'.friday_test/runs/large-documents-review-normal/source')); from ingest import large_documents as c
B=S/('controls-'+mode); B.mkdir(); results=[]; original=c.__file__
def check(v,m):
 if not v: raise RuntimeError(m)
def setup(name,publish=True):
 root=B/name; (root/'inputs').mkdir(parents=True); (root/'source').mkdir()
 for n in ('large_documents.py','fixtures.py'): (root/'source'/n).write_bytes((pathlib.Path(original).parent/n).read_bytes())
 c.__file__=str(root/'source/large_documents.py')
 if publish: c.publish(root,(16,)); check(c.verify(root)['schema']==1,'control positive setup')
 return root

def reject(name,root,expected,action):
 try: action()
 except ValueError as e:
  check(expected in str(e),'wrong refusal path '+name+': '+str(e)); results.append({'case':name,'status':'PASS','origin':'canonical '+action.__name__ if hasattr(action,'__name__') else 'canonical API','expected':expected,'observed':str(e)})
 else: raise RuntimeError('missed refusal '+name)

root=setup('existing-publish'); folder=root/'inputs/corpus'; before={p.name:p.read_bytes() for p in folder.iterdir()}; reject('existing-publish',root,'Fresh physical corpus',lambda:c.publish(root,(16,))); check(before=={p.name:p.read_bytes() for p in folder.iterdir()},'overwrite')
for case,expected in [('tamper','Corpus bytes changed'),('missing-input','Corpus file inventory changed'),('extra-input','Corpus file inventory changed'),('oracle','Corpus oracle changed'),('input-symlink','Corpus file missing/aliased'),('input-hardlink','Corpus file missing/aliased'),('source-changed','Corpus source binding changed'),('source-missing','Corpus source alias/missing'),('source-symlink','Corpus source alias/missing'),('source-hardlink','Corpus source alias/missing'),('folder-symlink','Corpus file missing/aliased')]:
 root=setup(case); folder=root/'inputs/corpus'; path=folder/'orion-016.pdf'
 if case=='tamper': path.write_bytes(path.read_bytes()+b'bad')
 elif case=='missing-input': path.unlink()
 elif case=='extra-input': (folder/'extra').write_text('unexpected')
 elif case=='oracle': (folder/'oracles.json').write_text('{}')
 elif case.startswith('input-'):
  renamed=root/'physical.pdf'; path.rename(renamed)
  if case.endswith('symlink'): path.symlink_to(renamed)
  else: os.link(renamed,path)
 elif case=='source-changed':
  p=root/'source/fixtures.py'; p.write_bytes(p.read_bytes()+b'\n# control\n')
 elif case=='source-missing': (root/'source/fixtures.py').unlink()
 elif case.startswith('source-'):
  p=root/'source/fixtures.py'; renamed=root/'physical-fixtures.py'; p.rename(renamed)
  if case.endswith('symlink'): p.symlink_to(renamed)
  else: os.link(renamed,p)
 else:
  renamed=root/'physical-corpus'; folder.rename(renamed); folder.symlink_to(renamed,target_is_directory=True)
 reject(case,root,expected,lambda:c.verify(root))
for field,value in [('qwen_serving_qualified',True),('word_counts_are_not_model_tokens',False),('chunking_or_inference_performed',True),('qwen_tokens',32768),('missing-format',None)]:
 root=setup('claim-'+field); folder=root/'inputs/corpus'; p=folder/'manifest.json'; manifest=json.loads(p.read_bytes())
 if field=='qwen_tokens': manifest['documents'][0]['qwen_tokens']=value; expected='Corpus document identity/claim changed'
 elif field=='missing-format':
  manifest['documents']=[x for x in manifest['documents'] if x['format']!='pptx']; (folder/'orion-016.pptx').unlink(); expected='Corpus format coverage changed'
 else: manifest[field]=value; expected='Corpus qualification claims changed'
 p.write_bytes(c.encode(manifest)); reject('claim-'+field,root,expected,lambda:c.verify(root))
root=setup('interrupted-publish',False); original_open=pathlib.Path.open; writes=[]
def fail(self,*args,**kwargs):
 mode=args[0] if args else kwargs.get('mode','r')
 if 'x' in mode:
  writes.append(self.name)
  if self.name.endswith('.xlsx'): raise OSError('reviewer injected output failure')
 return original_open(self,*args,**kwargs)
with patch.object(pathlib.Path,'open',fail):
 try: c.publish(root,(16,))
 except OSError as e: check(str(e)=='reviewer injected output failure','wrong interruption')
 else: raise RuntimeError('interruption ignored')
check(not (root/'inputs/corpus/manifest.json').exists(),'failed preparation published success manifest'); results.append({'case':'interrupted-publish','status':'PASS','observed':'injected output failure after two assets; no success manifest','writes':writes})
root=setup('manifest-last',False); writes=[]
def track(self,*args,**kwargs):
 mode=args[0] if args else kwargs.get('mode','r')
 if 'x' in mode: writes.append(self.name)
 return original_open(self,*args,**kwargs)
with patch.object(pathlib.Path,'open',track): c.publish(root,(16,))
check(writes[-1]=='manifest.json' and len(writes)==7,'manifest not last'); results.append({'case':'manifest-last','status':'PASS','observed':writes})
root=setup('publish-parent-alias',False); inputs=root/'inputs'; inputs.rename(root/'physical-inputs'); inputs.symlink_to(root/'physical-inputs',target_is_directory=True); reject('publish-parent-alias',root,'Fresh physical corpus',lambda:c.publish(root,(16,)))
c.__file__=original; (S/('controls-'+mode+'.json')).write_text(json.dumps({'status':'PASS','mode':mode,'cases':results},indent=2)+'\n'); print(json.dumps({'status':'PASS','mode':mode,'independent_call_phase_controls':len(results)}))
