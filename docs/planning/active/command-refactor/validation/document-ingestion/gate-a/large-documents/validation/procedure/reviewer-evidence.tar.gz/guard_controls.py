import pathlib,sys,json,socket,subprocess
S=pathlib.Path('/private/tmp/large-document-independent-review-HLnkri'); mode=sys.argv[1]; root=S/'.friday_test/runs'/('large-documents-review-'+mode); target=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/docling-behavior-e2e-20261112/target'); outside=S/('outside-canary-'+mode); outside.write_text('untouched')
sys.path.insert(0,str(root/'source')); from ingest import large_documents as c
c.guard(root,target); result=[]
for name,fn,witness in [('socket',lambda:socket.socket(),'Corpus preparation forbids network/children'),('child',lambda:subprocess.run(['/usr/bin/true'],check=True),'Corpus preparation forbids network/children'),('outside-read',lambda:outside.read_text(),'Corpus filesystem escape'),('outside-write',lambda:outside.write_text('must not write'),'Corpus filesystem escape'),('target-write',lambda:(target/('review-denied-'+mode)).write_text('must not write'),'Corpus filesystem escape')]:
 try: fn()
 except ValueError as e:
  if witness not in str(e): raise RuntimeError('unexpected control origin '+name+str(e))
  result.append({'case':name,'status':'PASS','observed':str(e)})
 else: raise RuntimeError('missed guard '+name)
(root/'reports/guard-controls.json').write_text(json.dumps({'status':'PASS','mode':mode,'cases':result},indent=2)+'\n'); print(json.dumps({'status':'PASS','mode':mode,'guard_controls':len(result)}))
