from pathlib import Path
import sys,json,re
S=Path(__file__).parent;root=S/'.friday_test/runs/large-documents-generated-normal';target=Path('/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/docling-behavior-e2e-20261112/target');sys.path.insert(0,str(root/'source'))
from ingest.large_documents import guard
guard(root,target)
import pypdfium2 as pdfium
from docx import Document
from openpyxl import load_workbook
from pptx import Presentation
rows=[]
for p in sorted((root/'inputs/corpus').glob('orion-*')):
 size=int(p.stem.split('-')[1]);units=None
 if p.suffix=='.pdf':
  doc=pdfium.PdfDocument(str(p));units=len(doc);texts=[]
  for page in doc:
   tp=page.get_textpage();texts.append(tp.get_text_range());tp.close();page.close()
  doc.close();value='\n'.join(texts)
 elif p.suffix=='.docx':value='\n'.join(x.text for x in Document(str(p)).paragraphs)
 elif p.suffix=='.xlsx':
  book=load_workbook(str(p),read_only=True,data_only=True);units=len(book.sheetnames);value='\n'.join(str(v) for sheet in book for row in sheet.iter_rows(values_only=True) for v in row if v is not None);book.close()
 elif p.suffix=='.pptx':
  deck=Presentation(str(p));units=len(deck.slides);value='\n'.join(shape.text for slide in deck.slides for shape in slide.shapes if shape.has_text_frame)
 else:value=p.read_text()
 normalized=' '.join(value.split());matches=list(re.finditer(r'SECTION-(\d{4})\b',normalized));assert [int(m[1]) for m in matches]==list(range(1,size+1))
 sections=[normalized[m.start():(matches[i+1].start() if i+1<len(matches) else len(normalized))] for i,m in enumerate(matches)]
 key=f'COMPASS-{size}';release=f'RELEASE-{size+17}';kp=[i+1 for i,b in enumerate(sections) if key in b];rp=[i+1 for i,b in enumerate(sections) if release in b];assert kp==[size//2] and rp==[size];assert all(not(key in b and release in b) for b in sections)
 reference=(root/f'inputs/corpus/orion-{size:03d}.txt').read_text();canonical_words=len(reference.split());canonical_chars=len(reference)
 rows.append({'path':p.name,'units':units,'section_ids_in_order':size,'key_sections':kp,'release_sections':rp,'joint_evidence':True,'canonical_words':canonical_words,'canonical_characters':canonical_chars})
assert len(rows)==25
out=root/'reports/independent-native-distribution.json';out.write_text(json.dumps(rows,indent=2)+'\n')
doc=pdfium.PdfDocument(str(root/'inputs/corpus/orion-384.pdf'));images=[]
for i in [0,len(doc)//2,len(doc)-1]:
 page=doc[i];bitmap=page.render(scale=1.5);im=bitmap.to_pil();path=root/f'reports/independent-pdf-384-page-{i+1}.png';im.save(path);images.append({'path':str(path),'width':im.width,'height':im.height});bitmap.close();page.close()
doc.close();(root/'reports/independent-layout-images.json').write_text(json.dumps(images,indent=2)+'\n');print(json.dumps({'status':'PASS','native_distribution_files':len(rows),'layout_images':images}))
