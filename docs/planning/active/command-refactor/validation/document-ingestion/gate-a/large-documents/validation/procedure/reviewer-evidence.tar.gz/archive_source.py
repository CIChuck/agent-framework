import pathlib,json,subprocess,os,hashlib
S=pathlib.Path('/private/tmp/large-document-independent-review-HLnkri'); R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'); m=json.loads((S/'manifest.json').read_text()); rows=[]
for row in m['files']:
 rel=row['path']; original=subprocess.run(['git','show','3bf25f4ebac0497f43862783c0652312cebd998c:tests/readiness/ingest/'+rel],cwd=R,env=env,capture_output=True,check=True).stdout
 for mode in ('normal','optimized'):
  p=S/'archive'/mode/'source/ingest'/rel; raw=p.read_bytes(); good=raw==original; rows.append({'mode':mode,'path':rel,'actual_generation_source_equal':good,'sha256':hashlib.sha256(raw).hexdigest()}); assert good
(S/'archive-source-equality.json').write_text(json.dumps({'status':'PASS','files':rows},indent=2)+'\n'); print(json.dumps({'status':'PASS','generation_source_files_equal':len(rows)}))
