import sys
import pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from review import *
from unittest.mock import patch
import zipfile
import io

MODE='optimized' if sys.flags.optimize else 'normal'
SOURCE=S/'.friday_test/runs/large-documents-review-normal/source'
sys.path.insert(0,str(SOURCE))
from ingest import large_documents as c
BASE=S/'.friday_test/runs'/('large-documents-review-'+MODE)
OUT=S/('controls-'+MODE)
OUT.mkdir()
RESULT=[]

def clone(name):
    root=OUT/'.friday_test/runs'/('large-documents-'+name)
    root.mkdir(parents=True)
    for n in ['inputs','reports','config','cache','tmp']:(root/n).mkdir()
    shutil.copytree(BASE/'source',root/'source')
    shutil.copytree(BASE/'inputs/corpus',root/'inputs/corpus')
    return root

def refused(name,change,needle):
    root=clone(name)
    change(root)
    with patch.object(c,'__file__',str(root/'source/ingest/large_documents.py')):
        try:c.verify(root)
        except ValueError as e:
            if needle not in str(e):raise AssertionError((name,needle,str(e)))
            RESULT.append({'case':name,'status':'PASS','mechanism':str(e)})
        else:raise AssertionError(name+' accepted')

def manifest(root,mutator):
    p=root/'inputs/corpus/manifest.json';m=json.loads(p.read_text());mutator(m);p.write_bytes(c.encode(m))

def alias(root,relative,hard=False):
    path=root/relative;dest=root/('retained-'+path.name);path.rename(dest)
    if hard:os.link(dest,path)
    else:path.symlink_to(dest)

root=clone('existing')
before={p.name:sha(p) for p in (root/'inputs/corpus').iterdir()}
with patch.object(c,'__file__',str(root/'source/ingest/large_documents.py')):
    try:c.publish(root)
    except ValueError as e:assert 'Fresh physical corpus' in str(e)
    else:raise AssertionError('existing output accepted')
assert before=={p.name:sha(p) for p in (root/'inputs/corpus').iterdir()}
RESULT.append({'case':'existing-output','status':'PASS','mechanism':'Fresh physical corpus refusal; all 27 prior hashes unchanged'})
refused('bytes',lambda r:(r/'inputs/corpus/orion-016.pdf').write_bytes(b'tamper'),'Corpus bytes changed')
refused('missing',lambda r:(r/'inputs/corpus/orion-016.pdf').unlink(),'inventory changed')
refused('extra',lambda r:(r/'inputs/corpus/extra').write_text('extra'),'inventory changed')
refused('oracle',lambda r:(r/'inputs/corpus/oracles.json').write_text('{}'),'oracle changed')
for hard in [False,True]:
    refused('file-'+str(hard),lambda r:alias(r,'inputs/corpus/orion-016.pdf',hard),'file missing/aliased')
    refused('source-'+str(hard),lambda r:alias(r,'source/ingest/fixtures.py',hard),'source alias/missing')
refused('source-missing',lambda r:(r/'source/ingest/fixtures.py').unlink(),'source alias/missing')
refused('source-changed',lambda r:(r/'source/ingest/fixtures.py').write_bytes((r/'source/ingest/fixtures.py').read_bytes()+b'\n# independent change\n'),'source binding changed')
for key,val in [('qwen_serving_qualified',True),('chunking_or_inference_performed',True),('word_counts_are_not_model_tokens',False)]:
    refused(key,lambda r:manifest(r,lambda m:m.update({key:val})),'qualification claims changed')
refused('token-claim',lambda r:manifest(r,lambda m:m['documents'][0].update(qwen_tokens=8192)),'identity/claim changed')
def remove_format(r):
    manifest(r,lambda m:m.update(documents=[x for x in m['documents'] if x['format']!='pptx']))
    for p in (r/'inputs/corpus').glob('*.pptx'):p.unlink()
refused('format-removed',remove_format,'format coverage changed')

partial=OUT/'partial';(partial/'inputs').mkdir(parents=True)
original=pathlib.Path.open
def fail_asset(path,*a,**kw):
    if path.name=='orion-016.docx' and a and a[0]=='xb':raise OSError('independent publication fault')
    return original(path,*a,**kw)
with patch.object(pathlib.Path,'open',fail_asset):
    try:c.publish(partial,(16,))
    except OSError as e:assert str(e)=='independent publication fault'
    else:raise AssertionError('injected failure not reached')
assert not (partial/'inputs/corpus/manifest.json').exists()
assert (partial/'inputs/corpus/orion-016.pdf').exists()
RESULT.append({'case':'manifest-last-failure','status':'PASS','mechanism':'Injected second-asset write fault reached after first write; no success manifest exists'})

for name,old,new,needle in [('native-body',b'Operators compare the observed readings',b'Operators discard the observed readings','lost full section body'),('native-section',b'SECTION-0002',b'SECTION-9999','lost/duplicated section'),('native-fact',b'NORTH QUAY',b'SOUTH BAYX','lost anchor/fact')]:
    root=clone(name);p=root/'inputs/corpus/orion-016.docx'
    buf=io.BytesIO()
    with zipfile.ZipFile(p) as z,zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_DEFLATED) as w:
        for info in z.infolist():
            raw=z.read(info.filename)
            if info.filename=='word/document.xml':assert old in raw;raw=raw.replace(old,new)
            w.writestr(info,raw)
    p.write_bytes(buf.getvalue())
    manifest(root,lambda m:next(x for x in m['documents'] if x['path']==p.name).update(sha256=sha(p),bytes=p.stat().st_size))
    with patch.object(c,'__file__',str(root/'source/ingest/large_documents.py')):c.verify(root)
    args=[PY,'-I','-S','-B']+(['-O'] if MODE=='optimized' else [])+[str(root/'source/ingest/large_documents.py'),'validate','--run-root',str(root),'--target',R['private_native_target']]
    r=run(name+'-'+MODE,args)
    assert r['exit']!=0 and needle in r['stderr'] and not (root/'reports/native-validation.json').exists()
    RESULT.append({'case':name,'status':'PASS','mechanism':needle,'pre_native_verify':'PASS','exit':r['exit']})

root=clone('native-count');manifest(root,lambda m:m['documents'][0]['native_units'].update(pdf_pages=3))
args=[PY,'-I','-S','-B']+(['-O'] if MODE=='optimized' else [])+[str(root/'source/ingest/large_documents.py'),'validate','--run-root',str(root),'--target',R['private_native_target']]
r=run('native-count-'+MODE,args)
assert r['exit']!=0 and 'Actual PDF page count' in r['stderr']
RESULT.append({'case':'native-count','status':'PASS','mechanism':'Actual PDF page count','exit':r['exit']})

report=BASE/'reports/native-validation.json';before=sha(report)
args=[PY,'-I','-S','-B']+(['-O'] if MODE=='optimized' else [])+[str(BASE/'source/ingest/large_documents.py'),'validate','--run-root',str(BASE),'--target',R['private_native_target']]
r=run('report-exclusive-'+MODE,args)
assert r['exit']!=0 and 'FileExistsError' in r['stderr'] and before==sha(report)
RESULT.append({'case':'native-report-exclusive','status':'PASS','mechanism':'FileExistsError; prior report hash unchanged','exit':r['exit']})
(S/('independent-controls-'+MODE+'.json')).write_text(json.dumps(RESULT,indent=2))
print('INDEPENDENT CONTROLS',MODE,len(RESULT),'PASS')
