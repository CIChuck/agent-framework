import os, pathlib, subprocess, hashlib, json, stat, sys
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
S=pathlib.Path('/tmp/large-document-independent-review-HLnkri')
P=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n')
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def git(*args):
 p=subprocess.run(['git',*args],cwd=R,env=env,capture_output=True,check=True); return p.stdout
def sha(p): return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def meta(p,content=True):
 try: s=p.lstat()
 except FileNotFoundError: return {'missing':True}
 d={'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'birthtime':s.st_birthtime}
 if stat.S_ISLNK(s.st_mode): d['symlink']=os.readlink(p)
 elif content and stat.S_ISREG(s.st_mode): d['sha256']=sha(p)
 return d
label=sys.argv[1]
index=git('ls-files','-s','-z')
(S/(label+'-index.bin')).write_bytes(index)
request=json.loads((P/'large-review-request.json').read_text())
supplied=json.loads((P/'large-review-boundary.json').read_text())
paths=[x.split(b'\t',1)[1].decode() for x in index.split(b'\0') if x]
result={'logical_index_sha256':hashlib.sha256(index).hexdigest(),'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'status':git('status','--porcelain=v1','--untracked-files=all').decode(),'staging':git('diff','--cached','--name-status').decode(),'pins':{v:git('rev-parse',v).decode().strip() for v in [request['base'],request['candidate'],request['actual_generation_source']]},'tracked':{p:meta(R/p) for p in paths},'preserved':{p:meta(R/p) for p in supplied['preserved']},'inputs':{p:sha(pathlib.Path(p) if p.startswith('/') else R/p) for p in request['inputs']}}
result['supplied']={}
for root in [P/'frozen-large-final',P/'validation-tools',pathlib.Path(request['private_native_target']),*[pathlib.Path(x['root']) for x in request['corpus_runs']]]:
 result['supplied'][str(root)]={str(p.relative_to(root)):meta(p) for p in sorted(root.rglob('*')) if not p.is_dir() or p.is_symlink()}
(S/(label+'-boundary.json')).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
checks={'all_pinned_inputs_match':all(result['inputs'][p]==v for p,v in request['inputs'].items()),'head_matches':result['head']==request['candidate'],'branch_matches':result['branch']==request['branch'],'tracked_count':len(paths),'supplied_boundary_keys':list(supplied),'supplied_file_counts':{p:len(v) for p,v in result['supplied'].items()},'logical_index_sha256':result['logical_index_sha256'],'status':result['status'],'staging':result['staging']}
if label=='closing':
 opening=json.loads((S/'opening-boundary.json').read_text()); checks['unchanged']=result==opening; checks['different_sections']=[k for k in result if result[k]!=opening[k]]
(S/(label+'-summary.json')).write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({k:v for k,v in checks.items() if k not in ("status","staging")},indent=2))
