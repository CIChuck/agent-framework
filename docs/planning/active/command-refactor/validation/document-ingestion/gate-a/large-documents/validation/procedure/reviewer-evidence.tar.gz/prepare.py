import pathlib,json,hashlib,tarfile,shutil,subprocess,os
S=pathlib.Path('/private/tmp/large-document-independent-review-HLnkri'); R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); P=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n')
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*a): return subprocess.run(['git',*a],cwd=R,env=env,capture_output=True,check=True).stdout
manifest=json.loads((P/'frozen-large-final/manifest.json').read_text()); checks=[]
for row in manifest['files']:
 rel=row['path']; raw=(P/'frozen-large-final/harness'/rel).read_bytes(); current=(R/'tests/readiness/ingest'/rel).read_bytes(); blob=git('show',manifest['commit']+':tests/readiness/ingest/'+rel)
 checks.append({'path':rel,'frozen_current_candidate_equal':raw==current==blob,'sha256':sha(raw),'pinned_sha256_equal':sha(raw)==row['sha256']})
 assert checks[-1]['frozen_current_candidate_equal'] and checks[-1]['pinned_sha256_equal']
 for dest in [S/'harness'/rel,S/'static-source/tests/readiness/ingest'/rel,*[S/'.friday_test/runs'/('large-documents-review-'+mode)/'source/ingest'/rel for mode in ('normal','optimized')]]:
  dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(raw)
for mode in ('normal','optimized'):
 root=S/'.friday_test/runs'/('large-documents-review-'+mode)
 for name in ('inputs','reports','config','cache','tmp'): (root/name).mkdir()
 (S/('selftest-'+mode)).mkdir()
(S/'manifest.json').write_bytes((P/'frozen-large-final/manifest.json').read_bytes()); (S/'pyproject.toml').write_bytes((R/'pyproject.toml').read_bytes())
D=R/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/large-documents'; idx=json.loads((D/'evidence-index.json').read_text()); raw=(D/'evidence.tar.gz').read_bytes(); assert sha(raw)==idx['archive_sha256']
expected={x['path']:x for x in idx['members']}; archive=S/'archive'; archive.mkdir(); members=[]
with tarfile.open(D/'evidence.tar.gz','r:gz') as tar:
 ts=tar.getmembers(); assert len(ts)==len(expected)==191; assert sum(x.size for x in ts)<64*1024**2
 assert len({x.name for x in ts})==len(ts)
 for m in ts:
  assert m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts
  b=tar.extractfile(m).read(); assert m.name in expected and len(b)==expected[m.name]['size'] and sha(b)==expected[m.name]['sha256']; dest=archive/m.name; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b); members.append(m.name)
changes=git('diff','--name-only','641ad015a30ea0db1ef3d4a8c5ba6263c86cf7a3',manifest['commit']).decode().splitlines(); (S/'changed-paths.txt').write_text('\n'.join(changes)+'\n')
bounded=['tests/readiness/ingest/large_documents.py','tests/readiness/ingest/tests/test_large_documents.py','tests/readiness/ingest/stages.py','tests/readiness/ingest/README.md']; (S/'bounded-source.diff').write_bytes(git('diff','641ad015a30ea0db1ef3d4a8c5ba6263c86cf7a3',manifest['commit'],'--',*bounded))
summary={'source_equality':checks,'archive_members':members,'archive_sha256':sha(raw),'changed_paths':changes,'python_sources':len(list((S/'static-source').rglob('*.py')))}
(S/'preparation.json').write_text(json.dumps(summary,indent=2)+'\n'); print(json.dumps({'all35_source_files_equal':all(x['frozen_current_candidate_equal'] for x in checks),'archive_member_count':len(members),'python_sources':summary['python_sources'],'changed_paths':changes,'pdf_pngs':[x for x in members if x.endswith('.png')],'typing_source':[x for x in members if x.startswith('typing-source/')]}))
