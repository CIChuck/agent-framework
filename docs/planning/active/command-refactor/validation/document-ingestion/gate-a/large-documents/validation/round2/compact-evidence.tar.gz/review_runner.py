from pathlib import Path
import json,os,sys,subprocess,shutil,hashlib,zipfile,tarfile,stat,time
S=Path(__file__).parent;R=Path('/Users/chuckrussell/Dev/gendev/agent-framework');C=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n');REQ=json.loads((C/'large-v2-review-request.json').read_text());PY='/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13';TARGET=Path(REQ['private_native_target']);H=S/'harness';M=S/'manifest.json';MH=REQ['frozen_manifest_sha256']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v): (S/n).write_text(json.dumps(v,indent=2)+'\n')
def run(name,argv,cwd=None,expect=0,needle=None,timeout=120):
 env={'HOME':str(S/'home'),'PATH':'/usr/bin:/bin:/opt/homebrew/bin','LANG':'en_US.UTF-8','PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0','UV_CACHE_DIR':str(S/'uv-cache'),'XDG_CACHE_HOME':str(S/'xdg-cache'),'TMPDIR':str(S/'tmp')}
 for k in ['HOME','UV_CACHE_DIR','XDG_CACHE_HOME','TMPDIR']:Path(env[k]).mkdir(exist_ok=True)
 t=time.time();q=subprocess.run(argv,cwd=cwd or S,env=env,capture_output=True,text=True,timeout=timeout); row={'name':name,'argv':list(map(str,argv)),'cwd':str(cwd or S),'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'seconds':time.time()-t,'expected':expect,'needle':needle};ledger=S/'command-ledger.json';rows=json.loads(ledger.read_text()) if ledger.exists() else [];rows.append(row);write('command-ledger.json',rows)
 ok=(q.returncode==expect if expect is not None else q.returncode!=0) and (needle is None or needle in q.stderr+q.stdout)
 print(json.dumps({'name':name,'exit':q.returncode,'expected_met':ok,'stdout':q.stdout[-250:],'stderr_tail':q.stderr[-200:]}),flush=True)
 if not ok:raise RuntimeError('unexpected '+name)
 return row

def make(name,original=None):
 root=S/'.friday_test/runs'/('large-documents-'+name);root.mkdir(parents=True)
 if original:
  for n in ['source','inputs']:shutil.copytree(original/n,root/n)
 else:
  (root/'source').mkdir();shutil.copytree(H,root/'source/ingest');(root/'inputs').mkdir()
 for n in ['reports','config','cache','tmp']:(root/n).mkdir()
 return root

def cli(root,command,opt=False):
 a=[PY,'-I','-S','-B']+(['-O'] if opt else [])+[str(root/'source/ingest/large_documents.py'),command,'--run-root',str(root)]
 if command=='validate':a+=['--target',str(TARGET)]
 return a

def snapshot():
 paths=[TARGET,C/'validation-tools',Path(REQ['frozen_harness'])]+[Path(row['root']) for row in REQ['corpus_runs']]
 paths+=sorted(R.glob('.friday_test/runs/large-documents-*'))
 out={}
 for root in dict.fromkeys(paths):
  tree={}
  for p in [root,*sorted(root.rglob('*'))]:
   st=p.lstat();v={'mode':st.st_mode,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'birthtime':st.st_birthtime,'nlink':st.st_nlink}
   if stat.S_ISREG(st.st_mode):v['sha256']=sha(p)
   elif p.is_symlink():v['link']=os.readlink(p)
   tree[str(p.relative_to(root))]=v
  out[str(root)]=tree
 return out

if __name__=='__main__':
 stage=sys.argv[1]
 if stage=='prepare':
  snap=snapshot();write('supplied-opening.json',snap);print('snapshotted supplied entries',sum(len(v) for v in snap.values()),flush=True)
  shutil.copytree(REQ['frozen_harness'],H);shutil.copyfile(REQ['frozen_manifest'],M)
  manifest=json.loads(M.read_text());assert sha(M)==MH
  for row in manifest['files']:
   assert sha(H/row['path'])==row['sha256']==sha(R/'tests/readiness/ingest'/row['path'])
  print('frozen/current source equality',len(manifest['files']))
  # LD-CORPUS-001 delta first, against an integrity-valid native DOCX copied from supplied run.
  original=Path(REQ['corpus_runs'][0]['root']);root=make('delta-tail-mutant',original)
  p=root/'inputs/corpus/orion-016.docx'
  with zipfile.ZipFile(p) as z:members={n:z.read(n) for n in z.namelist()}
  needle=b'paired with RELEASE-33.';assert members['word/document.xml'].count(needle)==1
  members['word/document.xml']=members['word/document.xml'].replace(needle,needle+b' COMPASS-16')
  with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
   for n,raw in members.items():z.writestr(n,raw)
  m=root/'inputs/corpus/manifest.json';v=json.loads(m.read_text())
  for row in v['documents']:
   if row['path']==p.name:row.update(bytes=p.stat().st_size,sha256=sha(p))
  m.write_text(json.dumps(v,indent=2)+'\n')
  for opt in [False,True]:
   mode='optimized' if opt else 'normal';run('delta-integrity-'+mode,cli(root,'verify',opt));run('delta-native-refusal-'+mode,cli(root,'validate',opt),expect=None,needle='Cross-section answers supplied by one section')
  assert not (root/'reports/native-validation.json').exists()
  write('delta-result.json',{'finding':'LD-CORPUS-001','status':'closed','integrity_valid_native_docx_refused_both_modes':True,'mutant_sha256':sha(p),'manifest_sha256':sha(m),'success_report_absent':True})
 elif stage=='full':
  for opt in [False,True]:
   mode='optimized' if opt else 'normal';scratch=S/('selftest-'+mode);scratch.mkdir()
   run('selftest-'+mode,[PY,'-I','-S','-B']+(['-O'] if opt else [])+[str(H/'bootstrap.py'),'selftest','--harness-manifest',str(M),'--harness-manifest-sha256',MH,'--scratch',str(scratch)])
   # Native replay on independent physical copies of supplied frozen source/corpus.
   original=Path(REQ['corpus_runs'][1 if opt else 0]['root']); copied=make('copied-'+mode,original)
   run('copy-verify-'+mode,cli(copied,'verify',opt));run('copy-native-'+mode,cli(copied,'validate',opt))
   fresh=make('generated-'+mode)
   run('generate-'+mode,cli(fresh,'generate',opt));run('fresh-verify-'+mode,cli(fresh,'verify',opt));run('fresh-native-'+mode,cli(fresh,'validate',opt))
  roots=[S/'.friday_test/runs'/('large-documents-generated-'+m) for m in ['normal','optimized']];a,b=[{p.name:sha(p) for p in (r/'inputs/corpus').iterdir()} for r in roots];assert a==b
  supplied={p.name:sha(p) for p in (Path(REQ['corpus_runs'][0]['root'])/'inputs/corpus').iterdir()};assert a==supplied
  native=[json.loads((r/'reports/native-validation.json').read_text()) for r in roots];assert all(len(n['results'])==25 for n in native)
  write('fresh-result.json',{'determinism_equal':True,'fresh_equals_supplied':True,'corpus_hashes':a,'native_files_per_mode':25,'total_complete_section_bodies_per_mode':sum(x['exact_section_bodies_verified'] for x in native[0]['results']),'models':False})
 elif stage=='close':
  end=snapshot();write('supplied-closing.json',end);opening=json.loads((S/'supplied-opening.json').read_text());assert opening==end;print('supplied preservation entries match',sum(len(v) for v in end.values()))
