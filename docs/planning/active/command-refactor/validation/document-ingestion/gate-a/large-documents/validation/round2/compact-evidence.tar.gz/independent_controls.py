from pathlib import Path
import sys,json,os,shutil,io,zipfile,re,hashlib,socket
from unittest.mock import patch
S=Path(__file__).parent;sys.path.insert(0,str(S));import review_runner as rr
sys.path.insert(0,str(S/'harness').rsplit('/',1)[0]);sys.path.insert(0,str(S/'.friday_test/runs/large-documents-generated-normal/source'))
from ingest import large_documents as c
checks=[]
def require(ok,msg):
 if not ok:raise RuntimeError(msg)
def refusal(name,fn,needle):
 try:fn()
 except ValueError as e:
  require(needle in str(e),name+' wrong mechanism: '+str(e));checks.append({'name':name,'refusal':str(e)})
 else:raise RuntimeError(name+' erroneously accepted')
base=S/'.friday_test/runs/large-documents-generated-normal'
def copied(name):return rr.make('control-r2-'+name,base)
# Fresh-only publication and fail-before-manifest witness.
root=copied('existing');before={p.name:rr.sha(p) for p in (root/'inputs/corpus').iterdir()};refusal('existing publication',lambda:c.publish(root),'Fresh physical');require(before=={p.name:rr.sha(p) for p in (root/'inputs/corpus').iterdir()},'overwritten')
root=rr.make('control-r2-partial-publish');original=Path.open
def fail_docx(self,*a,**kw):
 if self.name=='orion-016.docx' and 'x' in str(a[0] if a else kw.get('mode')):raise OSError('independent simulated write interruption')
 return original(self,*a,**kw)
try:
 with patch.object(Path,'open',fail_docx):c.publish(root,(16,))
except OSError as e:require('independent simulated' in str(e),'wrong failure')
else:raise RuntimeError('failure injection missing')
require((root/'inputs/corpus/orion-016.pdf').is_file() and not (root/'inputs/corpus/manifest.json').exists(),'partial acquired success');checks.append({'name':'manifest last','partial_pdf_present':True,'success_manifest_absent':True})
for name,needle in [('bytes','Corpus bytes changed'),('missing','inventory changed'),('extra','inventory changed'),('oracle','oracle changed'),('serving','qualification claims changed'),('tokens','identity/claim changed'),('inference','qualification claims changed'),('source-change','source binding changed'),('source-missing','source alias/missing'),('source-symlink','source alias/missing'),('source-hardlink','source alias/missing'),('data-symlink','missing/aliased'),('data-hardlink','missing/aliased')]:
 root=copied(name);p=root/'inputs/corpus/orion-016.docx';m=root/'inputs/corpus/manifest.json';v=json.loads(m.read_text());source=root/'source/ingest/fixtures.py'
 if name=='bytes':p.write_bytes(p.read_bytes()+b'changed')
 elif name=='missing':p.unlink()
 elif name=='extra':p.with_name('extra').write_text('unlisted')
 elif name=='oracle':p.with_name('oracles.json').write_text('{}')
 elif name in ['serving','tokens','inference']:
  if name=='serving':v['qwen_serving_qualified']=True
  elif name=='tokens':v['documents'][0]['qwen_tokens']=8192
  else:v['chunking_or_inference_performed']=True
  m.write_bytes(c.encode(v))
 elif name=='source-change':source.write_bytes(source.read_bytes()+b'\n# independent change\n')
 elif name=='source-missing':source.unlink()
 elif name.startswith('source-'):
  q=root/'source/physical-fixtures.py';source.rename(q)
  if name.endswith('symlink'):source.symlink_to(q)
  else:os.link(q,source)
 else:
  q=root/'physical.docx';p.rename(q)
  if name.endswith('symlink'):p.symlink_to(q)
  else:os.link(q,p)
 rr.run('independent-'+name,rr.cli(root,'verify'),expect=None,needle=needle)
 checks.append({'name':name,'expected':needle})
# Integrity-valid actual native body, duplicate and order mutants.
for name,needle in [('body','lost full section body'),('duplicate','lost/duplicated section'),('order','section order changed')]:
 root=copied('native-'+name);p=root/'inputs/corpus/orion-016.docx'
 with zipfile.ZipFile(p) as z:members={n:z.read(n) for n in z.namelist()}
 raw=members['word/document.xml'].decode()
 if name=='body':raw=raw.replace('A delayed delivery requires a separate exception record, rather than an invented completion date.','A delayed delivery requires a different independent control sentence.',1)
 elif name=='duplicate':raw=raw.replace('</w:body>','<w:p><w:r><w:t>SECTION-0001</w:t></w:r></w:p></w:body>')
 else:
  paras=re.findall(r'<w:p>.*?</w:p>',raw);require(len(paras)==33,'paragraph witness');old=''.join(paras[1:5]);new=''.join(paras[3:5]+paras[1:3]);require(old in raw,'swap witness');raw=raw.replace(old,new)
 members['word/document.xml']=raw.encode()
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
  for n,r in members.items():z.writestr(n,r)
 m=root/'inputs/corpus/manifest.json';v=json.loads(m.read_text())
 for row in v['documents']:
  if row['path']==p.name:row.update(bytes=p.stat().st_size,sha256=rr.sha(p))
 m.write_bytes(c.encode(v));rr.run('native-'+name+'-integrity',rr.cli(root,'verify'));rr.run('native-'+name+'-refusal',rr.cli(root,'validate'),expect=None,needle=needle);require(not (root/'reports/native-validation.json').exists(),'failed semantic publication');checks.append({'name':'native '+name,'verify':True,'semantic_refusal':needle})
rr.write('independent-controls.json',{'status':'PASS','checks':checks})
# Actual Python audit refusals happen before effects; no network/child operation occurs.
root=rr.make('control-r2-guard');c.guard(root,None)
refusal('socket before network',lambda:socket.socket(),'forbids network/children')
refusal('child before launch',lambda:os.system('/usr/bin/true'),'forbids network/children')
refusal('outside scratch read',lambda:(S/'manifest.json').read_bytes(),'filesystem escape')
(root/'reports/guard-controls.json').write_text(json.dumps(checks[-3:],indent=2)+'\n')
print(json.dumps({'status':'PASS','independent_control_count':len(checks)}))
