import pathlib,sys,json,re,hashlib,importlib
S=pathlib.Path('/private/tmp/large-document-independent-review-HLnkri'); mode=sys.argv[1]; root=S/'.friday_test/runs'/('large-documents-review-'+mode); target=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/docling-behavior-e2e-20261112/target')
sys.path.insert(0,str(root/'source')); from ingest import large_documents as corpus
corpus.guard(root,target)
pdf=importlib.import_module('pypdfium2'); docx=importlib.import_module('docx'); xlsx=importlib.import_module('openpyxl'); pptx=importlib.import_module('pptx')
folder=root/'inputs/corpus'; manifest=json.loads((folder/'manifest.json').read_bytes()); oracles=json.loads((folder/'oracles.json').read_bytes()); rows={x['path']:x for x in manifest['documents']}; result=[]; facts=[]
def check(c,m):
 if not c: raise ValueError(m)
def norm(s): return ' '.join(s.split())
check(len(rows)==25 and len(list(folder.iterdir()))==27,'full inventory'); check(sum(x.stat().st_size for x in folder.iterdir())<=16*1024**2,'total bound')
for size in (16,64,128,256,384):
 reference=(folder/f'orion-{size:03}.txt').read_text(); paras=reference.strip().split('\n\n'); check(paras[0]==f'ORION OPERATIONS MANUAL - {size} SECTIONS','reference title'); sections=[]
 for i,p in enumerate(paras[1:],1):
  h,b=p.split('\n',1); check(h.startswith(f'SECTION-{i:04} '),'reference section order'); check(f'fictional station Orion {i:04}.' in b and f'B{size:03}-{i:04}.' in b,'unique per-section facts'); sections.append((h,b))
 check(len(sections)==size,'body count')
 expected=[f'SOURCE_START_{size}: The pilot zone is NORTH QUAY. The earlier route AMBER is provisional.',f'SOURCE_MIDDLE_{size}: The calibration key is COMPASS-{size}. Retain it for the final authorization.',f'SOURCE_TAIL_{size}: The final authorized route is COBALT. AMBER is revoked. Authorization requires COMPASS-{size} and RELEASE-{size+17}.']
 for p,n in zip(expected,(1,size//2,size)): check(p in sections[n-1][1],'independent anchor/fact location')
 q=oracles[str(size)]['queries']; check(q[2]['answers']==['COBALT'] and q[2]['evidence_sections']==[size],'supersession oracle'); check(q[3]['answers']==[f'COMPASS-{size}',f'RELEASE-{size+17}'] and q[3]['evidence_sections']==[size//2,size],'cross-section oracle')
 units={}
 for kind in ('pdf','docx','xlsx','pptx','txt'):
  path=folder/f'orion-{size:03}.{kind}'; row=rows[path.name]; raw=path.read_bytes(); check(len(raw)<=32*1024**2,'file bound'); check(hashlib.sha256(raw).hexdigest()==row['sha256'],'independent asset hash'); check(row['canonical_words']==len(reference.split()) and row['canonical_characters']==len(reference),'independent measurements'); check(row['qwen_tokens'] is None,'tokens unset')
  if kind=='pdf':
   d=pdf.PdfDocument(str(path)); units['pdf_pages']=len(d); text=[]
   for page in d:
    tp=page.get_textpage(); text.append(tp.get_text_range()); tp.close(); page.close()
   d.close(); value='\n'.join(text); check(units['pdf_pages']<=50,'actual page bound')
  elif kind=='docx': value='\n'.join(x.text for x in docx.Document(str(path)).paragraphs)
  elif kind=='xlsx':
   d=xlsx.load_workbook(str(path),read_only=True,data_only=True); units['xlsx_sheets']=len(d.sheetnames); check(units['xlsx_sheets']<=32,'actual sheet bound'); check(all(s.sheet_state=='visible' for s in d),'visible sheets'); value='\n'.join(str(c) for s in d for r in s.iter_rows(values_only=True) for c in r if c is not None); d.close()
  elif kind=='pptx':
   d=pptx.Presentation(str(path)); units['pptx_slides']=len(d.slides); check(units['pptx_slides']<=100,'actual slide bound'); value='\n'.join(s.text for p in d.slides for s in p.shapes if s.has_text_frame)
  else: value=reference
  v=norm(value); last=-1
  for i,(h,b) in enumerate(sections,1):
   check(v.count(f'SECTION-{i:04}')==1,'unique native ID'); check(v.count(norm(b))==1,'complete unique native body'); pos=v.index(norm(b)); check(pos>last,'native body order'); last=pos
  for p in expected: check(p in v,'native exact anchor facts')
  result.append({'path':path.name,'bodies_in_order':size,'known_fact_checks':3,'native_words':len(value.split()),'characters':len(value),'sha256':hashlib.sha256(raw).hexdigest()})
 check(all(row['native_units']==units for row in rows.values() if row['sections']==size),'actual units versus every manifest row')
 facts.append({'sections':size,'canonical_words':len(reference.split()),'canonical_characters':len(reference),**units})
check(manifest['qwen_serving_qualified'] is False and manifest['chunking_or_inference_performed'] is False and manifest['word_counts_are_not_model_tokens'] is True,'qualification flags')
output={'status':'PASS','mode':mode,'native_files':len(result),'all_bodies_verified':sum(x['bodies_in_order'] for x in result),'rows':result,'facts':facts,'reader_origins':{x.__name__:x.__file__ for x in (pdf,docx,xlsx,pptx)},'limits':'Python-visible audit guard only; native I/O not OS contained; no model or Docling execution'}
(root/'reports/independent-native.json').write_text(json.dumps(output,indent=2)+'\n'); print(json.dumps({'status':'PASS','mode':mode,'files':25,'bodies_in_order':output['all_bodies_verified'],'facts':facts}))
