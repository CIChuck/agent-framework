import sys
import pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from review import *
import re
import importlib.util
from urllib.parse import unquote

prefix=['uv','run','--offline','--frozen','--no-sync','--no-python-downloads','python','-B']
for name,args in [('board-validate',['scripts/friday-dev-board.py','validate']),('board-dashboard',['scripts/friday-dev-board.py','render','--check']),('board-next',['scripts/friday-dev-board.py','next']),('package-metadata',['scripts/check-package-metadata.py'])]:
    run(name,prefix+args)

spec=importlib.util.spec_from_file_location('board_review',REPO/'scripts/friday-dev-board.py')
board=importlib.util.module_from_spec(spec);sys.modules[spec.name]=board;spec.loader.exec_module(board)
task=next(x for x in board.load_board(REPO)['tasks'] if x['id']=='friday-command-refactor')
selected={k:task[k] for k in ['id','work_state','condition','implementation_authority','branch','delivery_state','next_gate']}
(S/'selected-board-fields.json').write_text(json.dumps(selected,indent=2))
print('SELECTED BOARD',json.dumps(selected))
controls=json.loads(pathlib.Path(R['safe_current_controls']).read_text())
if selected['branch']!=R['branch'] or selected['work_state']!='started' or selected['delivery_state']!='local' or selected['implementation_authority']!='granted':raise ValueError('Board mismatch')
p=REPO/'docs/planning/active/command-refactor/authority.json'
if sha(p)!=controls['authority_sha256']:raise ValueError('Authority hash mismatch')
print('AUTHORITY HASH ONLY MATCH')

B=REPO/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a'
docs=[B/'large-documents-scope.md',B/'large-documents/criteria.md',B/'large-documents/results.md',REPO/'tests/readiness/ingest/README.md']
report=[]
for p in docs:
    raw=p.read_text()
    if p.name=='README.md':raw=raw.split('\n## Complete isolated ingestion evaluation',1)[0]
    fenced=False
    for i,line in enumerate(raw.splitlines(),1):
        if line.lstrip().startswith(('```','~~~')):fenced=not fenced;continue
        if fenced:continue
        for m in re.finditer(r'(?<!!)\[[^\]]+\]\(([^)]+)\)',line):
            target=unquote(m.group(1).split('#')[0].split('?')[0].strip('<>'))
            if not target or '://' in target:continue
            resolved=(p.parent/target).resolve()
            if not resolved.exists():raise ValueError('Broken bounded doc link '+str(p)+':'+str(i))
            report.append({'source':str(p.relative_to(REPO)),'line':i,'target':target,'exists':True})
(S/'bounded-docs-links.json').write_text(json.dumps({'checks':report,'limit':'Full historical documentation scanner intentionally not run because it reads excluded histories.'},indent=2))
print('BOUNDED DOCS LINKS',len(report),'PASS')
selected_paths=['tests/readiness/ingest/large_documents.py','tests/readiness/ingest/tests/test_large_documents.py','tests/readiness/ingest/stages.py','tests/readiness/ingest/README.md','docs/planning/active/command-refactor/validation/document-ingestion/gate-a/large-documents-scope.md','docs/planning/active/command-refactor/validation/document-ingestion/gate-a/large-documents']
run('selected-whitespace',['git','diff','--check',R['base'],R['candidate'],'--',*selected_paths])
