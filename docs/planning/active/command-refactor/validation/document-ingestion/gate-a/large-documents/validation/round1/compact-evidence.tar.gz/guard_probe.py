import sys
import pathlib
import socket
import subprocess
import os
root=pathlib.Path(sys.argv[1]); action=sys.argv[2]
sys.path.insert(0,str(root/'source'))
from ingest.large_documents import guard
guard(root,None)
try:
    if action=='network':socket.socket()
    elif action=='child':subprocess.Popen(['/usr/bin/true'])
    elif action=='write':(root.parent/'outside-own-write').write_text('forbidden')
    elif action=='rename':os.rename(root/'inside-sentinel',root.parent/'outside-own-rename')
    else:raise RuntimeError('Unknown probe')
except ValueError as e:
    expected='network/children' if action in ['network','child'] else ('filesystem escape' if action=='write' else 'mutation escape')
    if expected not in str(e):raise RuntimeError('Wrong failure mechanism') from e
    print('PASS',action,str(e))
else:raise RuntimeError('Guard probe effect was accepted')
