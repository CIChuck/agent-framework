import pathlib,subprocess,os,json,sys,hashlib
S=pathlib.Path('/private/tmp/large-document-independent-review-HLnkri'); R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); P=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n'); PY='/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13'
env={k:v for k,v in os.environ.items() if k in ('HOME','PATH','LANG','LC_ALL')}; env.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',UV_CACHE_DIR=str(S/'admin-uv-cache'),UV_PYTHON_DOWNLOADS='never',UV_NO_CONFIG='true')
kind=sys.argv[1]; out=[]
def run(name,argv,cwd=S):
 p=subprocess.run([str(x) for x in argv],cwd=cwd,env=env,capture_output=True,text=True); d={'name':name,'argv':[str(x) for x in argv],'cwd':str(cwd),'env':{k:env[k] for k in ('GIT_OPTIONAL_LOCKS','PYTHONDONTWRITEBYTECODE','UV_CACHE_DIR')},'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}; (S/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n'); out.append({'name':name,'exit':p.returncode,'stdout_tail':p.stdout[-500:],'stderr_tail':p.stderr[-800:]}); return p
if kind in ('normal','optimized'):
 flags=[PY,'-I','-S','-B']+(['-O'] if kind=='optimized' else [])
 run('selftest-'+kind,flags+[S/'harness/bootstrap.py','selftest','--harness-manifest',S/'manifest.json','--harness-manifest-sha256','2496a5e2be8035fa814a6153e33ba75bcb54c775f621ad64e3f59d9f3ce3d0a5','--scratch',S/('selftest-'+kind)])
 root=S/'.friday_test/runs'/('large-documents-review-'+kind)
 for command in ('generate','verify','validate'):
  args=flags+[root/'source/ingest/large_documents.py',command,'--run-root',root]
  if command=='validate': args+=['--target','/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/docling-behavior-e2e-20261112/target']
  run('corpus-'+command+'-'+kind,args)
elif kind=='static':
 ruff=P/'validation-tools/ruff'; sources=sorted((S/'static-source/tests/readiness/ingest').rglob('*.py')); assert len(sources)==31
 run('ruff-check',[ruff,'check','--config',S/'pyproject.toml','--cache-dir',S/'ruff-cache',*sources]); run('ruff-format',[ruff,'format','--check','--config',S/'pyproject.toml','--cache-dir',S/'ruff-cache',*sources])
 diffs=[]
 for p in (S/'archive/typing-source').rglob('*.py'):
  rel=p.relative_to(S/'archive/typing-source'); current=S/'harness'/rel
  if p.read_bytes()!=current.read_bytes(): diffs.append(str(rel))
 config=S/'archive/typing-source/pyproject.toml'; ref=P/'validation-tools/pyproject.toml'; assert len(list((S/'archive/typing-source').rglob('*.py')))==31
 d={'mode':'inspected source-equal receipt','source_count':31,'different_sources':diffs,'config_equals_private':config.read_bytes()==ref.read_bytes(),'config_equals_current':config.read_bytes()==(R/'pyproject.toml').read_bytes(),'receipt':json.loads((S/'archive/checks/mypy-last.json').read_text())}; (S/'typing-inspection.json').write_text(json.dumps(d,indent=2)+'\n'); out.append({k:v for k,v in d.items() if k!='receipt'})
elif kind=='admin':
 pre=['uv','run','--offline','--frozen','--no-sync','--no-python-downloads','python','-B']
 for name,args in [('board',['scripts/friday-dev-board.py','validate']),('dashboard',['scripts/friday-dev-board.py','render','--check']),('docs',['scripts/check-documentation-lifecycle.py']),('metadata',['scripts/check-package-metadata.py'])]: run('admin-'+name,pre+args,R)
 for name,args in [('owned-whitespace',['diff','--check','--','.gitignore','docs/planning','tests/readiness/ingest']),('cached-whitespace',['diff','--cached','--check']),('candidate-whitespace',['diff','--check','641ad015a30ea0db1ef3d4a8c5ba6263c86cf7a3','b341a3c9f6c326b8f891b058fec642dd31d5efc4','--','docs/planning','tests/readiness/ingest'])]: run(name,['git',*args],R)
print(json.dumps(out,indent=2))
