import pathlib,hashlib,json,tarfile,io
S=pathlib.Path('/private/tmp/large-document-independent-review-HLnkri')
files=[]
for p in S.iterdir():
 if p.is_file() and (p.suffix in ('.json','.py','.diff') or p.name in ('review-report.md','changed-paths.txt')) and p.name not in ('delivery-manifest.json','reviewer-evidence-members.json'): files.append(p)
files += [p for p in (S/'harness').rglob('*') if p.is_file()]
for mode in ('normal','optimized'):
 root=S/'.friday_test/runs'/('large-documents-review-'+mode)
 files += [p for sub in ('inputs/corpus','reports') for p in (root/sub).rglob('*') if p.is_file()]
files += [S/'archive/checks/mypy-last.json']
files=sorted(set(files),key=lambda p:str(p.relative_to(S)))
def digest(p): return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
rows=[{'path':str(p.relative_to(S)),'size':p.stat().st_size,'sha256':digest(p)} for p in files]
index=S/'reviewer-evidence-members.json'; index.write_text(json.dumps({'schema':1,'members':rows},indent=2)+'\n'); files.append(index)
archive=S/'reviewer-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:
  name=str(p.relative_to(S)); raw=p.read_bytes(); info=tarfile.TarInfo(name); info.size=len(raw); info.mode=0o644; info.mtime=0; tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
 ms=tar.getmembers(); assert len(ms)==len(files)
 for m in ms:
  raw=tar.extractfile(m).read(); p=S/m.name; assert raw==p.read_bytes()
manifest={'outcome':'BLOCKED','reason':'LD-PROC-001 reviewer-procedure exclusion exposure; no mandatory candidate finding','archive_members':len(files),'artifacts':{p.name:{'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)} for p in [S/'review-report.md',S/'command-ledger.json',archive,index,S/'opening-boundary.json',S/'closing-boundary.json']}}
(S/'delivery-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n'); print(json.dumps(manifest,indent=2))
