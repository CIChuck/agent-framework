import sys
import pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from review import *
import re

results=[]
for mode in ['normal','optimized']:
    root=S/'.friday_test/runs'/('large-documents-review-'+mode)
    sentinel=root/'inside-sentinel';sentinel.write_text('reviewer sentinel')
    for action in ['network','child','write','rename']:
        args=[PY,'-I','-S','-B']+(['-O'] if mode=='optimized' else [])+[str(S/'guard_probe.py'),str(root),action]
        rec=run('guard-'+action+'-'+mode,args)
        if rec['exit']!=0 or 'PASS' not in rec['stdout']:raise ValueError('guard failed')
        results.append({'mode':mode,'action':action,'exit':rec['exit'],'result':rec['stdout'].strip()})
    if sentinel.read_text()!='reviewer sentinel':raise ValueError('Guard sentinel changed')
    sentinel.unlink()
    if (root.parent/'outside-own-write').exists() or (root.parent/'outside-own-rename').exists():raise ValueError('Guard wrote outside own run')

native=json.loads((S/'.friday_test/runs/large-documents-review-normal/reports/native-validation.json').read_text())
fact=json.loads((REPO/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/large-documents/facts.json').read_text())
if len(native['results'])!=25 or native['inference_requests']!=0 or native['docling_conversion_performed'] is not False:raise ValueError('Native evidence invalid')
root=S/'.friday_test/runs/large-documents-review-normal/inputs/corpus'
m=json.loads((root/'manifest.json').read_text());oracle=json.loads((root/'oracles.json').read_text())
inventory=[]
for size,words,chars,pages,sheets,slides in [(16,1358,9572,2,1,4),(64,5294,37259,8,1,16),(128,10542,74181,16,2,32),(256,21038,148020,31,4,64),(384,31534,221852,46,6,96)]:
    raw=(root/f'orion-{size:03d}.txt').read_text()
    ids=re.findall(r'SECTION-([0-9]{4})',raw)
    if ids!=[f'{i:04d}' for i in range(1,size+1)]:raise ValueError('Section ID inventory/order mismatch')
    if len(raw.split())!=words or len(raw)!=chars:raise ValueError('Measurement mismatch')
    sections={int(i):v for i,v in re.findall(r'SECTION-([0-9]{4}) ([\s\S]*?)(?=\n\nSECTION-|\Z)',raw)}
    if not all(x in sections[1] for x in ['NORTH QUAY','AMBER is provisional']):raise ValueError('Opening fact mismatch')
    if f'COMPASS-{size}' not in sections[size//2]:raise ValueError('Middle fact mismatch')
    if not all(x in sections[size] for x in ['COBALT. AMBER is revoked',f'COMPASS-{size}',f'RELEASE-{size+17}']):raise ValueError('Final fact mismatch')
    queries=oracle[str(size)]['queries']
    if queries[2]['answers']!=['COBALT'] or queries[2]['evidence_sections']!=[size]:raise ValueError('Supersession query mismatch')
    if queries[3]['answers']!=[f'COMPASS-{size}',f'RELEASE-{size+17}'] or queries[3]['evidence_sections']!=[size//2,size]:raise ValueError('Cross-section query mismatch')
    rows=[x for x in m['documents'] if x['sections']==size]
    if len(rows)!=5 or {x['format'] for x in rows}!={'pdf','docx','xlsx','pptx','txt'}:raise ValueError('Format inventory')
    if not all(x['qwen_tokens'] is None and x['canonical_words']==words and x['canonical_characters']==chars and x['native_units']=={'pdf_pages':pages,'xlsx_sheets':sheets,'pptx_slides':slides} and x['bytes']<32*1024**2 for x in rows):raise ValueError('Manifest fields mismatch')
    inventory.append({'sections':size,'words':words,'characters':chars,'pdf_pages':pages,'xlsx_sheets':sheets,'pptx_slides':slides,'ordered_unique_ids':len(ids),'query_checks':'PASS'})
total=sum(x['bytes'] for x in m['documents'])
if total!=1361146 or sum(p.stat().st_size for p in root.iterdir())>16*1024**2:raise ValueError('Corpus ceiling')
if any(m[k] is not v for k,v in [('word_counts_are_not_model_tokens',True),('qwen_serving_qualified',False),('chunking_or_inference_performed',False)]):raise ValueError('Model qualification drift')
(S/'independent-guard-and-facts.json').write_text(json.dumps({'guard_results':results,'inventory':inventory,'document_source_bytes':total,'total_retained_corpus_bytes':sum(p.stat().st_size for p in root.iterdir()),'native_packages':native['packages'],'section_bodies_per_mode':sum(x['exact_section_bodies_verified'] for x in native['results']),'limits':fact['limits']},indent=2))
print('INDEPENDENT FACTS/QUERIES/COUNTS PASS',len(inventory),'lengths; native',sum(x['exact_section_bodies_verified'] for x in native['results']),'complete section bodies per mode')

os.environ.update(UV_OFFLINE='true',UV_FROZEN='true',UV_NO_SYNC='true',UV_PYTHON_DOWNLOADS='never',UV_NO_ENV_FILE='true')
run('documentation-lifecycle',['uv','run','--offline','--frozen','--no-sync','--no-python-downloads','python','-B','scripts/check-documentation-lifecycle.py'])
