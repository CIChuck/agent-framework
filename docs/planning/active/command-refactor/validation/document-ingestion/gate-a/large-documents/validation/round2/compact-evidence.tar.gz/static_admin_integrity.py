from pathlib import Path,PurePosixPath
import sys,json,hashlib,tarfile,subprocess,os
S=Path(__file__).parent;sys.path.insert(0,str(S));import review_runner as rr
R=rr.R;D=R/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/large-documents';tools=rr.C/'validation-tools'
# Use identical project rules and current frozen31 Python source files; private outputs only.
config=S/'pyproject.toml';config.write_bytes((tools/'pyproject.toml').read_bytes());assert rr.sha(config)==rr.sha(R/'pyproject.toml')
source=S/'static-source/tests/readiness/ingest';source.parent.mkdir(parents=True);__import__('shutil').copytree(rr.H,source)
files=sorted(source.rglob('*.py'));assert len(files)==31
rr.run('focused-ruff',[str(tools/'ruff'),'check','--config',str(config),'--cache-dir',str(S/'ruff-cache'),str(source)])
rr.run('focused-format',[str(tools/'ruff'),'format','--check','--config',str(config),'--cache-dir',str(S/'ruff-cache'),str(source)])
# Archive member hashes, exact inventory and source/corpus equivalence, no extraction or historical report interpretation.
index=json.loads((D/'evidence-index-v2.json').read_text());assert rr.sha(D/'evidence-v2.tar.gz')==index['archive_sha256'];decl={x['path']:x for x in index['members']};equal_sources=[];typing=[]
with tarfile.open(D/'evidence-v2.tar.gz') as t:
 members=t.getmembers();assert len(members)==len(decl)==len({m.name for m in members})
 for m in members:
  p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts and m.isfile();raw=t.extractfile(m).read();assert len(raw)==decl[m.name]['size'] and hashlib.sha256(raw).hexdigest()==decl[m.name]['sha256']
  for mode in ['normal','optimized']:
   prefix=mode+'/source/ingest/'
   if m.name.startswith(prefix):
    rel=m.name[len(prefix):];assert raw==(rr.H/rel).read_bytes();equal_sources.append(m.name)
   prefix=mode+'/inputs/corpus/'
   if m.name.startswith(prefix):assert raw==(Path(rr.REQ['corpus_runs'][0 if mode=='normal' else 1]['root'])/'inputs/corpus'/m.name[len(prefix):]).read_bytes()
  if m.name.startswith('typing-source/'):
   rel=m.name.removeprefix('typing-source/');expected=config if rel=='pyproject.toml' else rr.H/rel;assert raw==expected.read_bytes();typing.append(m.name)
 # Receipt's actual source path remains byte-equal too.
 receipt=json.loads((rr.C/'mypy-last.json').read_text());assert receipt['exit']==0 and '31 source files' in receipt['stdout'];typed=Path(receipt['argv'][-1]);hashes={}
 for p in files:
  rel=p.relative_to(source);assert p.read_bytes()==(typed/rel).read_bytes();hashes[str(rel)]=rr.sha(p)
 assert len(typing)==32 and len(equal_sources)==70
rr.write('integrity-and-inspected-typing.json',{'status':'PASS','archive_members':len(members),'archive_sha256':index['archive_sha256'],'archive_source_files_equal':len(equal_sources),'archived_typing_source_and_config_equal':len(typing),'typing_receipt_sha256':rr.sha(rr.C/'mypy-last.json'),'typing_source_equality_count':len(files),'typing_mode':'inspected existing success with direct current-source and archived-source equality; not freshly rerun','typing_argv_inspected':receipt['argv'],'source_hashes':hashes,'config_sha256':rr.sha(config)})
# Required read-only administrative checkers. Deliberately omit mutating render.
uv=['uv','run','--offline','--frozen','--no-sync','--no-python-downloads','python','-B']
for name,argv in [('board',uv+['scripts/friday-dev-board.py','validate']),('dashboard',uv+['scripts/friday-dev-board.py','render','--check']),('documentation',uv+['scripts/check-documentation-lifecycle.py']),('package-metadata',uv+['scripts/check-package-metadata.py']),('candidate-whitespace',['git','diff','--check',rr.REQ['full_unit_base'],rr.REQ['candidate'],'--','tests/readiness/ingest','docs/planning']),('cached-whitespace',['git','diff','--cached','--check'])]:rr.run(name,argv,cwd=R)
# Confirm diff scope without viewing excluded authority/history payloads.
a=subprocess.check_output(['git','diff','--name-only',rr.REQ['full_unit_base'],rr.REQ['candidate']],cwd=R).decode().splitlines();expected={'tests/readiness/ingest/README.md','tests/readiness/ingest/large_documents.py','tests/readiness/ingest/stages.py','tests/readiness/ingest/tests/test_large_documents.py'};assert {x for x in a if not x.startswith('docs/planning/')}==expected
frozen={}
for n in ['behavior.py','e2e.py','fixtures.py']:
 raw=subprocess.check_output(['git','show',rr.REQ['full_unit_base']+':tests/readiness/ingest/'+n],cwd=R);assert raw==(rr.H/n).read_bytes();frozen[n]=rr.sha(rr.H/n)
control=json.loads(Path(rr.REQ['safe_current_controls']).read_text());assert control['authority_sha256']==rr.sha(R/'docs/planning/active/command-refactor/authority.json');assert control['board_work_state']=='started' and control['delivery_state']=='local' and control['process']['execution_phase']=='validation' and control['process']['validation_state']=='in_review'
rr.write('scope-and-current-controls.json',{'status':'PASS','scope_files':a,'unchanged_baseline_sources':frozen,'safe_current_controls_sha256':rr.sha(Path(rr.REQ['safe_current_controls'])),'authority_hash_matches':True,'work_state':'started','delivery_state':'local','phase':'validation','validation_state':'in_review'})
print(json.dumps({'status':'PASS','archive_members':len(members),'typing_sources':len(files),'administration':True}))
