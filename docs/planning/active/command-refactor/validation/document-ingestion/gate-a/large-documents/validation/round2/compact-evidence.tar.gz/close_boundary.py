from pathlib import Path
import json,hashlib,os,subprocess,sys
S=Path(__file__).parent;sys.path.insert(0,str(S));import review_runner as rr
R=rr.R;req=rr.REQ;b=json.loads(Path(req['review_boundary']).read_text());env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
logical=subprocess.check_output(['git','ls-files','-s','-z'],cwd=R,env=env);(S/'closing-logical-index.bin').write_bytes(logical);bad=[]
for k,h in b['tracked_sha256'].items():
 if rr.sha(R/k)!=h:bad.append(k)
for k,v in b['symlinks'].items():
 if os.readlink(R/k)!=v:bad.append(k)
for k,v in b['preserved'].items():
 p=R/k;st=p.lstat();got={'mode':st.st_mode,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'birthtime':st.st_birthtime}
 if p.is_file():got['sha256']=rr.sha(p)
 if got!=v:bad.append(k)
for name,h in req['inputs'].items():
 p=Path(name);p=p if p.is_absolute() else R/p
 if rr.sha(p)!=h:bad.append(name)
status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=R,env=env).decode();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();branch=subprocess.check_output(['git','branch','--show-current'],cwd=R).decode().strip();staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).decode();digest=hashlib.sha256(logical).hexdigest();ok=not bad and digest==b['logical_before_status'] and status==b['status'] and head==b['head'] and branch==b['branch'] and not staged
manifest=json.loads(rr.M.read_text());assert manifest['commit']==req['actual_generation_source'];tree=subprocess.check_output(['git','rev-parse',req['actual_generation_source']+':tests/readiness/ingest'],cwd=R).decode().strip();assert tree==manifest['tree']
for row in manifest['files']:
 raw=subprocess.check_output(['git','show',req['actual_generation_source']+':tests/readiness/ingest/'+row['path']],cwd=R);assert raw==(rr.H/row['path']).read_bytes()
rr.write('closing-boundary.json',{'status':'PASS' if ok else 'FAIL','logical_index_sha256':digest,'logical_before_status':True,'head':head,'branch':branch,'status_porcelain':status,'staged':staged,'tracked_hashes_checked':len(b['tracked_sha256']),'symlinks_checked':len(b['symlinks']),'preserved_metadata_checked':len(b['preserved']),'input_pins_checked':len(req['inputs']),'source_commit_files_checked':len(manifest['files']),'source_commit_tree':tree,'mismatches':bad,'pinned_boundary_equal':ok})
assert ok
print(json.dumps({'status':'PASS','logical_index_sha256':digest,'tracked':len(b['tracked_sha256']),'pins':len(req['inputs']),'source_commit_files':len(manifest['files'])}))
