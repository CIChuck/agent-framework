from pathlib import Path
import shutil,json,hashlib,zipfile,io,subprocess,os
s=Path(__file__).parent;actual=Path('/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/large-documents-20261112-v2-normal');root=s/'large-cross-negative/.friday_test/runs/large-documents-tail-mutant';root.mkdir(parents=True)
for name in ['source','inputs']:shutil.copytree(actual/name,root/name)
for name in ['reports','config','cache','tmp']:(root/name).mkdir()
p=root/'inputs/corpus/orion-016.docx'
with zipfile.ZipFile(p) as z:members={n:z.read(n) for n in z.namelist()}
needle=b'paired with RELEASE-33.'
if members['word/document.xml'].count(needle)!=1:raise RuntimeError('Mutant target')
members['word/document.xml']=members['word/document.xml'].replace(needle,needle+b' COMPASS-16')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for name,raw in members.items():z.writestr(name,raw)
m=root/'inputs/corpus/manifest.json';v=json.loads(m.read_bytes())
for row in v['documents']:
 if row['path']==p.name:row.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
m.write_text(json.dumps(v,indent=2)+'\n');receipts=[]
for command in ['verify','validate']:
 argv=['/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13','-I','-S','-B',str(root/'source/ingest/large_documents.py'),command,'--run-root',str(root)]
 if command=='validate':argv+=['--target','/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/docling-behavior-e2e-20261112/target']
 r=subprocess.run(argv,env={'PATH':'/usr/bin:/bin','HOME':os.environ['HOME']},cwd=root,capture_output=True,text=True,timeout=60);receipts.append({'argv':argv,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
if receipts[0]['exit']!=0 or receipts[1]['exit']==0 or 'Cross-section answers supplied by one section' not in receipts[1]['stderr']:raise RuntimeError('Negative witness wrong mechanism')
(s/'large-native-cross-section-negative.json').write_text(json.dumps({'status':'PASS','mechanism':'integrity-valid native DOCX appends the middle key to tail; native semantic checker refuses','source_original_unchanged':True,'receipts':receipts},indent=2)+'\n');print(json.dumps({'verify_exit':receipts[0]['exit'],'native_validation_exit':receipts[1]['exit'],'cross_section_refusal':True}))
