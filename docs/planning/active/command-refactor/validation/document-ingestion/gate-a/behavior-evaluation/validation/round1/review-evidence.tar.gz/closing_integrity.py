import pathlib,os,json,subprocess,hashlib,stat
s=pathlib.Path(__file__).resolve().parent;req=json.loads((s/'review-request.json').read_bytes());repo=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');b=json.loads(pathlib.Path(req['review_boundary']).read_bytes())
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');git=lambda *a:subprocess.check_output(['git','-c','core.fsmonitor=false',*a],cwd=repo,env=env)
def require(value,msg):
 if not value:raise RuntimeError(msg)
logical=git('ls-files','-s','-z');digest=hashlib.sha256(logical).hexdigest();require(digest==b['logical_before_status'],'logical index')
require(git('rev-parse','HEAD').decode().strip()==req['candidate'],'candidate');require(git('branch','--show-current').decode().strip()==req['branch'],'branch')
status_bytes=git('status','--porcelain=v1','-z');require(status_bytes==(s/'opening-status.bin').read_bytes(),'status drift')
for name,h in b['tracked_sha256'].items():
 p=repo/name
 if p.is_symlink():continue
 require(hashlib.sha256(p.read_bytes()).hexdigest()==h,'tracked bytes '+name)
for name,target in b['symlinks'].items():require(os.readlink(repo/name)==target,'symlink '+name)
for name,want in b['preserved'].items():
 p=repo/name;st=p.lstat();got={'mode':st.st_mode,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'birthtime':st.st_birthtime}
 if 'sha256' in want:got['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 require(got==want,'protected metadata '+name)
for name,want in req['inputs'].items():
 p=pathlib.Path(name);p=p if p.is_absolute() else repo/p
 require(hashlib.sha256(p.read_bytes()).hexdigest()==want,'request pin '+name)
manifest=json.loads(pathlib.Path(req['frozen_harness_manifest']).read_bytes());run=s/'.friday_test/runs/docling-behavior-review-20261112'
for row in manifest['files']:
 require(hashlib.sha256((run/'source/ingest'/row['path']).read_bytes()).hexdigest()==row['sha256'],'private source drift '+row['path'])
assets=json.loads((s/'inspected-evidence/run/reports/assets.json').read_bytes())
for row in assets:
 require(row['status']=='verified','unverified supplied asset')
 require(hashlib.sha256((run/row['path']).read_bytes()).hexdigest()==row['sha256'],'private asset '+row['path'])
# Own private fixture copies still exactly match the indexed evidence originals.
idx=json.loads((s/'evidence-members.json').read_bytes()); fixtures=[r for r in idx if r['path'].startswith('run/inputs/')]
for row in fixtures:require(hashlib.sha256((run/pathlib.Path(row['path']).relative_to('run')).read_bytes()).hexdigest()==row['sha256'],'private fixture '+row['path'])
# Read-only supplied copies were never targets of any execution. Verify their declared source/assets/input payloads too.
parent=pathlib.Path(req['runtime_root'])
for row in assets:require(hashlib.sha256((parent/row['path']).read_bytes()).hexdigest()==row['sha256'],'supplied asset '+row['path'])
for row in fixtures:require(hashlib.sha256((parent/pathlib.Path(row['path']).relative_to('run')).read_bytes()).hexdigest()==row['sha256'],'supplied fixture '+row['path'])
records=[json.loads(p.read_bytes()) for p in (run/'reports/commands').glob('*.json')]
rss=max(v['peak_rss_bytes'] for v in records);active=sum(v['seconds'] for v in records);disk=sum((pathlib.Path(d)/n).lstat().st_size for d,_,files in os.walk(run) for n in files)
result={'head':req['candidate'],'branch':req['branch'],'logical_index_before_status_sha256':digest,'status_unchanged':True,'tracked_sha256_count':len(b['tracked_sha256']),'symlinks_unchanged':len(b['symlinks']),'protected_payload_and_metadata_unchanged':b['preserved'],'request_input_pins_match':True,'private_source_files_unchanged':len(manifest['files']),'private_and_supplied_asset_hashes_verified':len(assets),'private_and_supplied_fixture_hashes_verified':len(fixtures),'shared_source_or_input_writes':False,'production_effects':False,'private_runtime_peak_sampled_rss_bytes':rss,'private_runtime_supervised_active_seconds':active,'private_runtime_logical_disk_bytes':disk,'native_os_containment_claim':False}
(s/'closing-integrity.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
