import json,pathlib,hashlib,tarfile,gzip,subprocess,os,stat
s=pathlib.Path(__file__).resolve().parent
req=json.loads((s/'review-request.json').read_bytes());p=pathlib.Path(req['frozen_harness_manifest']).parent
packet=pathlib.Path(req['inputs'].keys().__iter__().__next__()).parent if False else pathlib.Path(req['runtime_root']).parents[2]/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/behavior-evaluation'
packet=pathlib.Path(req['review_boundary']).parent if False else pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework/docs/planning/active/command-refactor/validation/document-ingestion/gate-a/behavior-evaluation')
idx=json.loads((s/'evidence-members.json').read_bytes()); expected={x['path']:x for x in idx}; assert len(expected)==len(idx)
out=s/'inspected-evidence';out.mkdir()
with tarfile.open(packet/'behavior-evidence.tar.gz','r:gz') as t:
 members=t.getmembers(); assert len(members)==len(expected)
 for x in members:
  assert x.isfile() and x.name in expected and not pathlib.PurePosixPath(x.name).is_absolute() and '..' not in pathlib.PurePosixPath(x.name).parts
  raw=t.extractfile(x).read(); item=expected[x.name];assert len(raw)==item['size'] and hashlib.sha256(raw).hexdigest()==item['sha256'],x.name
  dest=out/x.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
assert hashlib.sha256(gzip.decompress((packet/'evidence-members.json.gz').read_bytes())).hexdigest()==json.loads((packet/'evidence-index.json').read_text())['index']['raw_sha256']
manifest=json.loads((p/'manifest.json').read_bytes()); source=s/'frozen/harness';source.mkdir(parents=True)
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');git=lambda *a:subprocess.check_output(['git','-c','core.fsmonitor=false',*a],env=env)
for item in manifest['files']:
 name=item['path'];raw=git('show',req['candidate']+':tests/readiness/ingest/'+name);assert hashlib.sha256(raw).hexdigest()==item['sha256'];assert git('rev-parse',req['candidate']+':tests/readiness/ingest/'+name).decode().strip()==item['blob']
 dest=source/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
(s/'frozen/manifest.json').write_bytes((p/'manifest.json').read_bytes())
assert git('diff',req['source_candidate']+'..'+req['candidate'],'--','tests/readiness/ingest')==b''
for k,v in json.loads(pathlib.Path(req['review_boundary']).read_bytes())['symlinks'].items(): assert os.readlink(k)==v,k
pres=json.loads(pathlib.Path(req['review_boundary']).read_bytes())['preserved']
for name,want in pres.items():
 st=pathlib.Path(name).lstat();got={'mode':st.st_mode,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'birthtime':st.st_birthtime}
 if 'sha256' in want:got['sha256']=hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()
 assert got==want,(name,got,want)
(s/'opening-integrity.json').write_text(json.dumps({'archive_members':len(idx),'bytes':sum(x['size'] for x in idx),'source_manifest_files':len(manifest['files']),'symlinks':26,'preserved':pres,'all_pins_match':True},indent=2))
for name in ('normal','optimized'):(s/('selftest-'+name)).mkdir()
# APFS clone private copies; reject aliases/hardlinks in source before copying.
run=s/'.friday_test/runs/docling-behavior-review-20261112'; run.mkdir(parents=True)
for name in ('config','logs','reports','target','cache','tmp','assets','inputs','source'):(run/name).mkdir()
parent=pathlib.Path(req['runtime_root'])
for name in ('config','inputs','target','assets'):
 for d,dirs,files in os.walk(parent/name,followlinks=False):
  for n in dirs+files:
   path=pathlib.Path(d)/n;st=path.lstat();assert not stat.S_ISLNK(st.st_mode),str(path)
   if stat.S_ISREG(st.st_mode):assert st.st_nlink==1,str(path)
 # directory contents clone to existing own physical dir
 subprocess.run(['/bin/cp','-cR',str(parent/name)+ '/.',str(run/name)],check=True)
(run/'source/ingest').mkdir()
subprocess.run(['/bin/cp','-cR',str(source)+'/.',str(run/'source/ingest')],check=True)
tools=s/'validation-tools'; tools.mkdir();orig=pathlib.Path(req['private_validation_tools'])
for name in ('ruff','pyproject.toml'):subprocess.run(['/bin/cp','-c',str(orig/name),str(tools/name)],check=True)
# Supply private static source paths and root config without traversing production dependencies.
static=s/'static-source/tests/readiness/ingest';static.parent.mkdir(parents=True);subprocess.run(['/bin/cp','-cR',str(source),str(static)],check=True)
print(json.dumps({'scratch':str(s),'run':str(run),'archive_verified_members':len(idx),'source_files':len(manifest['files'])}))
