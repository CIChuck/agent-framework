| WORD MERGED   | WORD MERGED   |
|---------------|---------------|
| WORD LEFT     | WORD RIGHT    |