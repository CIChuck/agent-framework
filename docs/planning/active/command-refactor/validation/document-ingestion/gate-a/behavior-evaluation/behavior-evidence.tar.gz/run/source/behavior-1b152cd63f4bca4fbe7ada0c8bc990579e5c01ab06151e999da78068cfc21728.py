"""Direct Docling behavior evaluation in an explicitly owned disposable run."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def environment(root: Path) -> dict[str, str]:
    """Explicit private caches/config; no inherited provider/proxy credentials."""
    result = {
        "PATH": "/usr/bin:/bin",
        "HOME": os.environ.get("HOME", ""),
        "PYTHONDONTWRITEBYTECODE": "1",
        "UV_CACHE_DIR": str(root / "cache/uv"),
        "UV_NO_CONFIG": "true",
        "UV_PYTHON_DOWNLOADS": "never",
        "UV_HTTP_RETRIES": "0",
        "UV_HTTP_TIMEOUT": "60",
        "UV_KEYRING_PROVIDER": "disabled",
        "UV_LINK_MODE": "copy",
        "NETRC": str(root / "config/empty-netrc"),
        "XDG_CACHE_HOME": str(root / "cache/xdg"),
        "XDG_CONFIG_HOME": str(root / "config/xdg"),
        "TMPDIR": str(root / "tmp"),
        "HF_HOME": str(root / "cache/huggingface"),
        "HF_HUB_CACHE": str(root / "cache/huggingface/hub"),
        "HUGGINGFACE_HUB_CACHE": str(root / "cache/huggingface/hub"),
        "HF_HUB_DISABLE_TELEMETRY": "1",
        "DO_NOT_TRACK": "1",
        "TORCH_HOME": str(root / "cache/torch"),
        "DOCLING_ARTIFACTS_PATH": str(root / "assets"),
        "LITELLM_MODE": "PRODUCTION",
        "LITELLM_LOCAL_MODEL_COST_MAP": "True",
        "OMP_NUM_THREADS": "4",
        "MKL_NUM_THREADS": "4",
        "OPENBLAS_NUM_THREADS": "4",
        "TOKENIZERS_PARALLELISM": "false",
    }
    (root / "config/empty-netrc").touch(exist_ok=True)
    return result


def supervise(root: Path, name: str, argv: list[str], seconds: int) -> int:
    """Only terminate this command's own process group; keep logs on failure."""
    started = time.monotonic()
    reason: str | None = None
    peak_rss = 0
    if (root / "logs" / (name + ".stdout")).exists():
        name += "-" + str(time.time_ns())
    source = Path(__file__).read_bytes()
    source_sha = hashlib.sha256(source).hexdigest()
    (root / "source" / ("behavior-" + source_sha + ".py")).write_bytes(source)
    with (root / "logs" / (name + ".stdout")).open("wb") as stdout, (
        root / "logs" / (name + ".stderr")
    ).open("wb") as stderr:
        child = subprocess.Popen(
            argv,
            cwd=root,
            env=environment(root),
            stdout=stdout,
            stderr=stderr,
            start_new_session=True,
        )
        try:
            while child.poll() is None:
                if time.monotonic() - started > seconds:
                    reason = "time_limit"
                    break
                raw = subprocess.check_output(
                    ["/bin/ps", "-axo", "pid=,ppid=,rss="],
                    env={"PATH": "/usr/bin:/bin"},
                    text=True,
                )
                rows = [tuple(map(int, line.split())) for line in raw.splitlines()]
                owned = {child.pid}
                for _ in range(32):
                    expanded = owned | {pid for pid, parent, _ in rows if parent in owned}
                    if expanded == owned:
                        break
                    owned = expanded
                rss = sum(size * 1024 for pid, _, size in rows if pid in owned)
                peak_rss = max(peak_rss, rss)
                if rss > 8 * 1024**3:
                    reason = "rss_limit"
                    break
                time.sleep(0.25)
        finally:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
            child.wait()
    record = {
        "argv": argv,
        "exit": child.returncode,
        "reason": reason,
        "seconds": time.monotonic() - started,
        "peak_rss_bytes": peak_rss,
        "scope": "private process tree; sampled RSS, no OS sandbox claim",
        "runner_sha256": source_sha,
    }
    write_json(root / "reports" / (name + ".json"), record)
    print(json.dumps(record), flush=True)
    return child.returncode if reason is None else 124


def setup(root: Path, uv: Path) -> int:
    require(not any((root / "target").iterdir()), "Private target must be empty")
    compile_args = [
        str(uv), "--no-config", "pip", "compile",
        str(root / "config/requirements.in"),
        "--python", sys.executable, "--no-python-downloads",
        "--only-binary", ":all:", "--no-sources",
        "--default-index", "https://pypi.org/simple", "--generate-hashes",
        "--output-file", str(root / "config/requirements.lock"),
    ]
    code = supervise(root, "resolve", compile_args, 900)
    if code:
        return code
    return supervise(
        root, "install",
        [str(uv), "--no-config", "pip", "sync",
         str(root / "config/requirements.lock"), "--python", sys.executable,
         "--no-python-downloads", "--target", str(root / "target"),
         "--require-hashes", "--only-binary", ":all:",
         "--default-index", "https://pypi.org/simple", "--link-mode", "copy", "--strict"],
        1200,
    )


def offline(root: Path) -> None:
    """Conversion may read local dependencies/assets and write only this run.

    Python-visible network/process/writes are intercepted. Native libraries are
    not an OS sandbox; production preservation is checked separately.
    """
    os.environ.update(environment(root))
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    sys.path.insert(0, str(root / "target"))

    def audit(event: str, args: tuple[object, ...]) -> None:
        if event in {"socket.connect", "socket.getaddrinfo", "subprocess.Popen", "os.system"}:
            raise PermissionError("Offline evaluation forbids network/child processes")
        if event == "open" and isinstance(args[0], (str, bytes, os.PathLike)):
            mode, flags = args[1], args[2]
            writing = isinstance(mode, str) and any(letter in mode for letter in "wax+")
            writing = writing or isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC))
            if writing:
                path = Path(os.fsdecode(args[0])).resolve()
                require(path == root or root in path.parents, "Write outside private run refused")

    sys.addaudithook(audit)


def probe(root: Path) -> int:
    offline(root)
    import importlib.metadata

    import certifi
    from packaging.version import Version

    require(Version(importlib.metadata.version("certifi")) >= Version("2026.10.19"), "Certifi security floor")
    require(root / "target" in Path(certifi.where()).resolve().parents, "Wrong Certifi origin")
    versions = {dist.metadata["Name"]: dist.version for dist in importlib.metadata.distributions(path=[str(root / "target")])}
    write_json(root / "reports/packages.json", {"versions": versions, "certifi_bundle": certifi.where(), "certifi_floor_pass": True})
    print(json.dumps({"distributions": len(versions), "certifi": importlib.metadata.version("certifi"), "docling": importlib.metadata.version("docling")}))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["setup", "probe"])
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--uv", type=Path)
    args = parser.parse_args()
    root = args.run_root.resolve(strict=True)
    require(root == args.run_root and root.name.startswith("docling-behavior-") and root.parent.name == "runs" and root.parent.parent.name == ".friday_test", "Explicit private behavior run required")
    require(sys.flags.isolated == 1 and sys.flags.no_site == 1 and sys.flags.dont_write_bytecode == 1, "Use base Python -I -S -B")
    if args.command == "setup":
        require(args.uv is not None and args.uv.is_file(), "Explicit existing uv required")
        return setup(root, args.uv)
    return probe(root)


if __name__ == "__main__":
    raise SystemExit(main())
