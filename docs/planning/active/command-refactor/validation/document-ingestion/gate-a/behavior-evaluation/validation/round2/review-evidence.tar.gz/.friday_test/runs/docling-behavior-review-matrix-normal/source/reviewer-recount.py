import collections,hashlib,importlib.util,json,pathlib,sys,unicodedata
P=pathlib.Path;root=P(sys.argv[1]);runner=root/'source/ingest/behavior.py';spec=importlib.util.spec_from_file_location('review_behavior',runner);b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.offline(root)
from tokenizers import Tokenizer
from docling_core.types.doc import DoclingDocument,ContentLayer
import certifi,rapidocr,docling.document_converter
from importlib import metadata
T=Tokenizer.from_file(str(root/'assets/nomic/tokenizer.json'));prefix='search_document: ';oracles={r['file']:r for r in json.loads((root/'config/oracles.json').read_bytes())['cases']};details=[];failures=[];total_chunks=0;ordered={'pdf-native.pdf','pdf-pages.pdf','docx-body.docx','docx-long.docx','xlsx-order.xlsx','pptx-order.pptx','pptx-unicode-long.pptx'}
def norm(s):return ' '.join(unicodedata.normalize('NFC',s).split())
for f in sorted((root/'reports/chunks').glob('*.json')):
 name,strategy,limit,_=f.name.rsplit('.',3);limit=int(limit);d=json.loads(f.read_bytes());chunks=d['chunks'];total_chunks+=len(chunks);counts=[];without=[];errors=[]
 for i,c in enumerate(chunks):
  prepared=c['prepared'];count=len(T.encode(prepared,add_special_tokens=True).ids);plain=len(T.encode(prepared,add_special_tokens=False).ids);counts.append(count);without.append(plain)
  if prepared!=prefix+c['text'] or count!=c['tokens_with_specials'] or count>limit or count-plain!=2:errors.append({'chunk':i,'count':count,'claimed':c['tokens_with_specials'],'no_specials':plain})
 joined=('\n' if strategy=='document' else '').join(c['text'] for c in chunks)
 if name.startswith('supplemental-'):
  kind=name.removeprefix('supplemental-');expected={'contains':[kind+' ROW 0:',kind+' ROW 119:'],'excludes':[]};source=''.join(f'{kind} ROW {i}: café 東京 Ω distinctive content for bounded embedding input.\n' for i in range(120))
 else:
  filename=name.removesuffix('.json');expected=oracles[filename];raw=(root/'reports/admitted/documents'/name).read_bytes();doc=DoclingDocument.model_validate_json(raw);record=b.admitted_document(root,filename,raw);layers={ContentLayer.BODY,ContentLayer.FURNITURE}
  if filename.endswith('.pptx') and record.get('structural_audit',{}).get('comment_parts',0)==0:layers.add(ContentLayer.NOTES)
  source=doc.export_to_markdown(included_content_layers=layers)
 normalized=norm(joined);missing=[s for s in expected['contains'] if s not in normalized];leaked=[s for s in expected['excludes'] if s in normalized];positions=[normalized.find(s) for s in expected['contains']];order_ok=name.removesuffix('.json') not in ordered or positions==sorted(positions)
 exact=strategy=='document' or joined==source
 if errors or missing or leaked or not exact or not order_ok:failures.append({'file':f.name,'tokens':errors,'missing':missing,'leaked':leaked,'exact':exact,'order_ok':order_ok})
 details.append({'file':f.name,'chunks':len(chunks),'max_actual':max(counts),'special_tokens':2,'prepared_sha256':hashlib.sha256(''.join(c['prepared'] for c in chunks).encode()).hexdigest(),'source_exact_for_prototype':exact,'oracle_pass':not missing and not leaked and order_ok})
records=[json.loads(f.read_bytes()) for f in (root/'reports/admitted').glob('*.result.json')];states=collections.Counter(r['status'] for r in records);native_negative=[r['file'] for r in records if r.get('native_docling_called') and (r.get('conversion_status')!='success' or not r.get('comparison',{}).get('meaningful'))];admitted_sources=json.loads((root/'reports/chunking.json').read_bytes())['actual_document_sources']
for module in (certifi,rapidocr,docling.document_converter):
 if root/'target' not in P(module.__file__).resolve().parents:raise RuntimeError('Wrong runtime module origin')
result={'mode':'optimized' if sys.flags.optimize else 'normal','cases':len(details),'chunks':total_chunks,'failure_count':len(failures),'failures':failures,'details':details,'prefix':prefix,'prefix_with_special_tokens':len(T.encode(prefix,add_special_tokens=True).ids),'special_tokens_per_input':2,'conversion_records':len(records),'statuses':dict(states),'phase_counts':dict(collections.Counter(r['phase'] for r in records)),'native_calls':sum(r.get('native_docling_called') is True for r in records),'native_empty_or_failure':sorted(native_negative),'structural_admission_refusals':sorted(r['file'] for r in records if r['status']=='admission_refused'),'setup_errors':[r['file'] for r in records if r.get('phase')=='setup' and r['status']=='error'],'actual_document_sources':admitted_sources,'versions':{n:metadata.version(n) for n in ('docling','rapidocr','certifi')},'origins':{m.__name__:m.__file__ for m in (certifi,rapidocr,docling.document_converter)},'counter_agrees_with_LM_Studio':'not qualified'}
(root/'reports/reviewer-recount.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('details','actual_document_sources','origins')}));
if len(details)!=324 or failures or len(records)!=37:raise RuntimeError('Independent recount failed')
