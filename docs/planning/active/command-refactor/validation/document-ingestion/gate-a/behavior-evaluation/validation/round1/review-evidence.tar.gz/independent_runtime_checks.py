import sys,pathlib,json,types,hashlib
s=pathlib.Path(__file__).resolve().parent;r=s/'.friday_test/runs/docling-behavior-review-20261112';p=r/'source/ingest/behavior.py'
data={}
for mode in ('normal','optimized'):
 d=s/('runtime-'+mode)
 matrix=json.loads((d/'chunking.json').read_bytes())
 data[mode]=[(row,json.loads((d/'chunks'/(row['source']+f".{row['strategy']}.{row['limit']}.json")).read_bytes())['chunks']) for row in matrix['results']]
raw=p.read_bytes();m=types.ModuleType('behavior');m.__file__=str(p);exec(compile(raw,str(p),'exec'),m.__dict__);m.offline(r)
from transformers import AutoTokenizer
import certifi,docling.document_converter,rapidocr,importlib.metadata
from packaging.version import Version
origins={name:str(sys.modules[name].__file__) for name in ('rapidocr','docling.document_converter','certifi')}
assert all(r/'target' in pathlib.Path(v).resolve().parents for v in origins.values())
assert Version(importlib.metadata.version('certifi'))>=Version('2026.10.19')
tokenizer=AutoTokenizer.from_pretrained(str(r/'assets/nomic'),tokenizer_type='bert',use_fast=True,local_files_only=True,trust_remote_code=False)
result={'origins':origins,'versions':{name:importlib.metadata.version(name) for name in ('docling','rapidocr','certifi')},'modes':{}}
for mode,rows in data.items():
 checked=0;maximum=0
 for row,chunks in rows:
  assert row['status']=='pass' and chunks
  for chunk in chunks:
   prepared='search_document: '+chunk['text'];actual=len(tokenizer.encode(prepared,add_special_tokens=True,truncation=False))
   assert chunk['prepared']==prepared and chunk['tokens_with_specials']==actual and actual<=row['limit'],(mode,row,actual)
   checked+=1;maximum=max(maximum,actual)
 result['modes'][mode]={'cases':len(rows),'chunks_retokenized':checked,'maximum_tokens':maximum,'all_limits_pass':True}
(r/'reports/reviewer-independent-tokens.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
