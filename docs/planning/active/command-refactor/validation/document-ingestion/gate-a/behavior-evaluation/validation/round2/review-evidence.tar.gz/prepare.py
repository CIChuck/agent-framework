import gzip,hashlib,json,os,pathlib,shutil,subprocess,tarfile,time
P=pathlib.Path; own=P('/private/tmp/docling-corrected-review-cFoB1YcS'); repo=P('/Users/chuckrussell/Dev/gendev/agent-framework'); req=json.loads(P('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n/review-request.json').read_bytes()); supplied=P(req['runtime_root']); control=P(req['review_boundary']).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def inventory(root):
 result={}
 for folder,dirs,files in os.walk(root,followlinks=False):
  for n in sorted(dirs+files):
   p=P(folder)/n;s=p.lstat();r={'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'ino':s.st_ino,'nlink':s.st_nlink}
   if p.is_symlink():r['link']=os.readlink(p)
   elif p.is_file():r['sha256']=sha(p.read_bytes())
   result[str(p.relative_to(root))]=r
 return result
for name,root in [('supplied-runtime',supplied),('supplied-control',control)]:
 x=inventory(root); (own/(name+'-opening.json')).write_text(json.dumps(x,sort_keys=True)+'\n'); print(name,len(x),'inventory complete')
p=repo/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/behavior-evaluation'; idx=json.loads(gzip.decompress((p/'evidence-members.json.gz').read_bytes())); expected={x['path']:x for x in idx}; failures=[];seen=set();total=0
with tarfile.open(p/'behavior-evidence.tar.gz','r:gz') as t:
 for member in t:
  if not member.isfile(): raise RuntimeError('non-regular archive member')
  if member.name in seen: raise RuntimeError('duplicate member')
  seen.add(member.name);raw=t.extractfile(member).read();total+=len(raw);e=expected.get(member.name)
  if e is None or e['sha256']!=sha(raw) or e['size']!=len(raw):failures.append(member.name)
if seen!=set(expected):failures.append('member-set')
report={'indexed':len(idx),'members':len(seen),'raw_bytes':total,'failures':failures,'index_raw_sha256':sha(gzip.decompress((p/'evidence-members.json.gz').read_bytes()))};(own/'archive-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
if failures:raise RuntimeError('archive failed')
manifest=json.loads(P(req['frozen_harness_manifest']).read_bytes()); frozen=own/'frozen/ingest';frozen.mkdir(parents=True)
for f in manifest['files']:
 raw=subprocess.check_output(['git','-c','core.fsmonitor=false','show',req['candidate']+':tests/readiness/ingest/'+f['path']],cwd=repo,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
 if sha(raw)!=f['sha256']:raise RuntimeError('Git blob mismatch')
 dest=frozen/f['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
shutil.copyfile(req['frozen_harness_manifest'],own/'frozen/manifest.json')
for mode in ['delta-normal','delta-optimized','matrix-normal','matrix-optimized']:
 run=own/'.friday_test/runs'/('docling-behavior-review-'+mode);run.mkdir(parents=True)
 for d in ('config','logs','reports','target','cache','tmp','assets','inputs','source'):(run/d).mkdir()
 for d in ('target','assets','config','inputs'):
  for folder,dirs,files in os.walk(supplied/d,followlinks=False):
   for n in dirs+files:
    f=P(folder)/n
    if f.is_symlink() or f.is_file() and f.stat().st_nlink!=1:raise RuntimeError('copy input alias '+str(f))
  subprocess.run(['/bin/cp','-cR',str(supplied/d)+'/.',str(run/d)],check=True)
 subprocess.run(['/bin/cp','-cR',str(frozen),str(run/'source/ingest')],check=True)
 print('prepared',run)
for mode in ('normal','optimized'):(own/('selftest-'+mode)).mkdir()
(own/'tools').mkdir();shutil.copy2(control/'validation-tools/ruff',own/'tools/ruff');shutil.copy2(control/'validation-tools/pyproject.toml',own/'tools/pyproject.toml')
print('complete')
