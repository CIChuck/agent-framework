import pathlib,json,collections,hashlib
s=pathlib.Path(__file__).resolve().parent;a=s/'inspected-evidence/run';source_sha='32a1f3ee4e030a176a642573bf334425a1e93f79fe1c2a8be3d0117da0d47a60';result={'modes':{}}
for mode in ('normal','optimized'):
 d=a/'history'/('qualified-'+mode);records=[json.loads(p.read_bytes()) for p in (d/'admitted').glob('*.result.json')];assert len(records)==37 and all(x['runner_sha256']==source_sha for x in records)
 chunk=json.loads((d/'chunking.json').read_bytes());cov=json.loads((d/'chunk-content-coverage.json').read_bytes());assert len(chunk['results'])==324 and all(x['status']=='pass' for x in chunk['results']);assert cov['cases']==cov['passed']==324
 result['modes'][mode]={'source_sha256':source_sha,'converted_or_admission_records':len(records),'statuses':dict(collections.Counter(r['status'] for r in records)),'native_docling_called':sum(r['native_docling_called'] for r in records),'admitted_meaningful_documents':len(chunk['actual_document_sources']),'chunk_cases':len(chunk['results']),'content_coverage_passed':cov['passed'],'evidence_directory':str(d.relative_to(s))}
fc=json.loads((s/'inspected-evidence/controller/frozen-checks.json').read_bytes());result['retained_selectors']=[{'kind':r['kind'],'mode':r['mode'],'exit':r['exit'],'stdout':r['stdout']} for r in fc['results'] if r['kind']!='minimal'];assert all(r['exit']==0 for r in result['retained_selectors'])
result['private_mypy']={'exit':0,'stdout':json.loads((s/'inspected-evidence/controller/mypy-last.json').read_bytes())['stdout'],'source_hashes_verified':True}
result['standard_setup']={name:json.loads((a/'reports'/name).read_bytes()) for name in ('resolve-1794510268120569000.json','install.json')}
result['setup_seconds']=sum(r['seconds'] for r in result['standard_setup'].values());result['installed_distribution_count']=len(json.loads((a/'reports/packages.json').read_bytes())['versions'])
result['asset_count']=len(json.loads((a/'reports/assets.json').read_bytes()));result['source_candidate_unchanged_since']='24d15ab5a82c662bcbf3a49d0603184d5fba748b'
result['base_python_sha256']=hashlib.sha256(pathlib.Path('/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13').read_bytes()).hexdigest()
for name in ('ruff','pyproject.toml'):result['private_'+name+'_sha256']=hashlib.sha256((s/'validation-tools'/name).read_bytes()).hexdigest()
(s/'inspected-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
