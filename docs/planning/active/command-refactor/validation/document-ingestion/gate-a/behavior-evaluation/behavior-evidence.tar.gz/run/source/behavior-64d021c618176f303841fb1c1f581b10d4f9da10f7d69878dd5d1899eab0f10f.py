"""Direct Docling behavior evaluation in an explicitly owned disposable run."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import signal
import ssl
import subprocess
import sys
import time
import unicodedata
import urllib.request
from collections.abc import Callable
from pathlib import Path
from urllib.parse import urlsplit


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def environment(root: Path) -> dict[str, str]:
    """Explicit private caches/config; no inherited provider/proxy credentials."""
    result = {
        "PATH": "/usr/bin:/bin",
        "HOME": os.environ.get("HOME", ""),
        "PYTHONDONTWRITEBYTECODE": "1",
        "UV_CACHE_DIR": str(root / "cache/uv"),
        "UV_NO_CONFIG": "true",
        "UV_PYTHON_DOWNLOADS": "never",
        "UV_HTTP_RETRIES": "0",
        "UV_HTTP_TIMEOUT": "60",
        "UV_KEYRING_PROVIDER": "disabled",
        "UV_LINK_MODE": "copy",
        "NETRC": str(root / "config/empty-netrc"),
        "XDG_CACHE_HOME": str(root / "cache/xdg"),
        "XDG_CONFIG_HOME": str(root / "config/xdg"),
        "TMPDIR": str(root / "tmp"),
        "HF_HOME": str(root / "cache/huggingface"),
        "HF_HUB_CACHE": str(root / "cache/huggingface/hub"),
        "HUGGINGFACE_HUB_CACHE": str(root / "cache/huggingface/hub"),
        "HF_HUB_DISABLE_TELEMETRY": "1",
        "DO_NOT_TRACK": "1",
        "TORCH_HOME": str(root / "cache/torch"),
        "MPLCONFIGDIR": str(root / "cache/matplotlib"),
        "TORCHINDUCTOR_CACHE_DIR": str(root / "cache/torchinductor"),
        "DOCLING_ARTIFACTS_PATH": str(root / "assets"),
        "LITELLM_MODE": "PRODUCTION",
        "LITELLM_LOCAL_MODEL_COST_MAP": "True",
        "OMP_NUM_THREADS": "4",
        "MKL_NUM_THREADS": "4",
        "OPENBLAS_NUM_THREADS": "4",
        "TOKENIZERS_PARALLELISM": "false",
    }
    (root / "config/empty-netrc").touch(exist_ok=True)
    return result


def supervise(root: Path, name: str, argv: list[str], seconds: int) -> int:
    """Only terminate this command's own process group; keep logs on failure."""
    started = time.monotonic()
    reason: str | None = None
    peak_rss = 0
    if (root / "logs" / (name + ".stdout")).exists():
        name += "-" + str(time.time_ns())
    source = Path(__file__).read_bytes()
    source_sha = hashlib.sha256(source).hexdigest()
    (root / "source" / ("behavior-" + source_sha + ".py")).write_bytes(source)
    with (root / "logs" / (name + ".stdout")).open("wb") as stdout, (
        root / "logs" / (name + ".stderr")
    ).open("wb") as stderr:
        child = subprocess.Popen(
            argv,
            cwd=root,
            env=environment(root),
            stdout=stdout,
            stderr=stderr,
            start_new_session=True,
        )
        try:
            while child.poll() is None:
                if time.monotonic() - started > seconds:
                    reason = "time_limit"
                    break
                raw = subprocess.check_output(
                    ["/bin/ps", "-axo", "pid=,ppid=,rss="],
                    env={"PATH": "/usr/bin:/bin"},
                    text=True,
                )
                rows = [tuple(map(int, line.split())) for line in raw.splitlines()]
                owned = {child.pid}
                for _ in range(32):
                    expanded = owned | {pid for pid, parent, _ in rows if parent in owned}
                    if expanded == owned:
                        break
                    owned = expanded
                rss = sum(size * 1024 for pid, _, size in rows if pid in owned)
                peak_rss = max(peak_rss, rss)
                if rss > 8 * 1024**3:
                    reason = "rss_limit"
                    break
                time.sleep(0.25)
        finally:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
            child.wait()
    record = {
        "argv": argv,
        "exit": child.returncode,
        "reason": reason,
        "seconds": time.monotonic() - started,
        "peak_rss_bytes": peak_rss,
        "scope": "private process tree; sampled RSS, no OS sandbox claim",
        "runner_sha256": source_sha,
    }
    write_json(root / "reports" / (name + ".json"), record)
    print(json.dumps(record), flush=True)
    return child.returncode if reason is None else 124


def setup(root: Path, uv: Path) -> int:
    require(not any((root / "target").iterdir()), "Private target must be empty")
    compile_args = [
        str(uv), "--no-config", "pip", "compile",
        str(root / "config/requirements.in"),
        "--python", sys.executable, "--no-python-downloads",
        "--only-binary", ":all:", "--no-sources",
        "--default-index", "https://pypi.org/simple", "--generate-hashes",
        "--output-file", str(root / "config/requirements.lock"),
    ]
    code = supervise(root, "resolve", compile_args, 900)
    if code:
        return code
    return supervise(
        root, "install",
        [str(uv), "--no-config", "pip", "sync",
         str(root / "config/requirements.lock"), "--python", sys.executable,
         "--no-python-downloads", "--target", str(root / "target"),
         "--require-hashes", "--only-binary", ":all:",
         "--default-index", "https://pypi.org/simple", "--link-mode", "copy", "--strict"],
        1200,
    )


def offline(root: Path) -> None:
    """Conversion may read local dependencies/assets and write only this run.

    Python-visible network/process/writes are intercepted. Native libraries are
    not an OS sandbox; production preservation is checked separately.
    """
    os.environ.update(environment(root))
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    sys.path.insert(0, str(root / "target"))
    import mimetypes

    mimetypes.knownfiles = []
    mimetypes.init(files=[])  # Built-in mappings, no host/server configuration.

    def audit(event: str, args: tuple[object, ...]) -> None:
        if event in {"socket.connect", "socket.getaddrinfo", "socket.sendto", "subprocess.Popen", "os.system"}:
            raise PermissionError("Offline evaluation forbids network/child processes")
        if event == "open" and isinstance(args[0], (str, bytes, os.PathLike)):
            if Path(os.fsdecode(args[0])).resolve() == Path("/dev/null"):
                return  # Standard sink/type probes; never a user file.
            mode, flags = args[1], args[2]
            writing = isinstance(mode, str) and any(letter in mode for letter in "wax+")
            writing = writing or isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC))
            if writing:
                path = Path(os.fsdecode(args[0])).resolve()
                require(path == root or root in path.parents, "Write outside private run refused")
            else:
                path = Path(os.fsdecode(args[0])).resolve()
                allowed = (root, Path(sys.base_prefix).resolve(), Path(__file__).resolve())
                require(any(path == item or item in path.parents for item in allowed) or path == Path("/System/Library/CoreServices/SystemVersion.plist"), "Read outside evaluation/stdlib roots refused: " + str(path))
        elif event in {"os.mkdir", "os.remove", "os.rmdir", "os.chmod", "os.utime", "os.truncate", "os.rename", "os.link", "os.symlink"}:
            for value in args[:2] if event in {"os.rename", "os.link", "os.symlink"} else args[:1]:
                if isinstance(value, (str, bytes, os.PathLike)):
                    path = Path(os.fsdecode(value)).resolve()
                    require(path == root or root in path.parents, "Mutation outside private run refused")

    sys.addaudithook(audit)


def probe(root: Path) -> int:
    offline(root)
    import importlib.metadata

    import certifi
    from packaging.version import Version

    require(Version(importlib.metadata.version("certifi")) >= Version("2026.10.19"), "Certifi security floor")
    require(root / "target" in Path(certifi.where()).resolve().parents, "Wrong Certifi origin")
    versions = {dist.metadata["Name"]: dist.version for dist in importlib.metadata.distributions(path=[str(root / "target")])}
    write_json(root / "reports/packages.json", {"versions": versions, "certifi_bundle": certifi.where(), "certifi_floor_pass": True})
    print(json.dumps({"distributions": len(versions), "certifi": importlib.metadata.version("certifi"), "docling": importlib.metadata.version("docling")}))
    return 0


def prepare_inputs(root: Path) -> int:
    sys.path.insert(0, str(root / "source"))
    from ingest.fixtures import publish_matrix

    expected = json.loads((root / "source/ingest/fixtures/expectations.json").read_bytes())["A2"]["fixture_oracles"]
    published = publish_matrix(root / "inputs/generated", expected, lambda: None)
    write_json(root / "config/oracles.json", expected)
    write_json(root / "reports/fixtures.json", published)
    print(json.dumps({"genuine_inputs": len(expected["cases"]), "formats": ["pdf", "docx", "xlsx", "pptx"]}))
    return 0


def fetch_assets(root: Path, manifest: Path) -> int:
    os.environ.update(environment(root))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.load_verify_locations(cafile=str(root / "target/certifi/cacert.pem"))

    class PublicRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req: urllib.request.Request, fp: object, code: int, msg: str, headers: object, newurl: str) -> urllib.request.Request | None:
            parsed = urlsplit(newurl)
            host = parsed.hostname or ""
            require(parsed.scheme == "https" and (host == "huggingface.co" or host.endswith(".hf.co") or host.endswith(".huggingface.co")) and not parsed.username and not parsed.password, "Non-public asset redirect refused")
            return super().redirect_request(req, fp, code, msg, headers, newurl)

    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context), PublicRedirect())
    records: list[dict[str, object]] = []
    total = 0
    for item in json.loads(manifest.read_bytes())["asset_candidates"]:
        role = item["role"]
        folder = {"layout": "docling-project--docling-layout-heron", "tableformer": "docling-project--docling-models", "ocr": "ocr", "tokenizer": "nomic"}[role]
        destination = root / "assets" / folder / item["path"]
        destination.parent.mkdir(parents=True, exist_ok=True)
        expected_size = item["size_bytes"]
        total += expected_size
        require(total <= 1024**3, "Asset budget exceeded")
        entry: dict[str, object] = {"role": role, "source": item["url"], "path": str(destination.relative_to(root))}
        try:
            if not destination.exists():
                temporary = destination.with_name(destination.name + ".part")
                with opener.open(item["url"], timeout=60) as response, temporary.open("xb") as output:
                    count = 0
                    while chunk := response.read(1024**2):
                        count += len(chunk)
                        require(count <= expected_size, "Asset exceeds declared size")
                        output.write(chunk)
                require(count == expected_size, "Incomplete asset")
                temporary.rename(destination)
            raw = destination.read_bytes()
            require(len(raw) == expected_size, "Asset size mismatch")
            actual = hashlib.sha256(raw).hexdigest()
            if item["expected_lfs_sha256"]:
                require(actual == item["expected_lfs_sha256"], "Asset SHA256 mismatch")
            else:
                blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
                require(blob == item["expected_git_blob_sha1"], "Asset Git-blob mismatch")
            destination.chmod(0o444)
            entry.update(status="verified", sha256=actual, size=len(raw))
        except Exception as exc:
            entry.update(status="failed", error=type(exc).__name__ + ": " + str(exc))
        records.append(entry)
        write_json(root / "reports/assets.json", records)
        print(json.dumps({"asset": str(destination.relative_to(root)), "status": entry["status"]}), flush=True)
    return 0 if all(row["status"] == "verified" for row in records) else 1


def compare_text(content: str, expected: dict[str, object], ordered: bool) -> dict[str, object]:
    normalized = " ".join(unicodedata.normalize("NFC", content).split())
    included = expected["contains"]
    excluded = expected["excludes"]
    require(isinstance(included, list) and isinstance(excluded, list), "Invalid independent oracle")
    missing = [item for item in included if item not in normalized]
    leaked = [item for item in excluded if item in normalized]
    positions = [normalized.find(item) for item in included]
    order_ok = not ordered or not missing and positions == sorted(positions)
    meaningful = re.sub(r"<!--.*?-->|!\[[^\]]*\]\([^)]*\)", "", normalized)
    return {"missing": missing, "leaked": leaked, "order_ok": order_ok, "meaningful": any(character.isalnum() for character in meaningful)}


def convert_case(root: Path, filename: str, include_furniture: bool = False) -> int:
    offline(root)
    sys.path.insert(0, str(root / "source"))
    from ingest.fixtures import audit_office

    from docling.datamodel.accelerator_options import AcceleratorDevice, AcceleratorOptions
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import PdfPipelineOptions, RapidOcrOptions
    from docling.document_converter import DocumentConverter, PdfFormatOption
    from docling_core.types.doc import ContentLayer

    expected = next(row for row in json.loads((root / "config/oracles.json").read_bytes())["cases"] if row["file"] == filename)
    path = root / "inputs/generated" / filename
    require(path.parent == root / "inputs/generated" and path.is_file(), "Unknown input")
    record: dict[str, object] = {"file": filename, "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "expected": expected, "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    started = time.monotonic()
    try:
        if expected["format"] != "pdf":
            record["structural_audit"] = audit_office(path.read_bytes(), expected["format"])
        options = PdfPipelineOptions(
            artifacts_path=root / "assets", enable_remote_services=False,
            accelerator_options=AcceleratorOptions(device=AcceleratorDevice.CPU, num_threads=4),
            document_timeout=300,
        )
        options.ocr_options = RapidOcrOptions(
            backend="onnxruntime", lang=["en"],
            det_model_path=str(root / "assets/ocr/PP-OCRv4/en_PP-OCRv3_det_infer.onnx"),
            rec_model_path=str(root / "assets/ocr/PP-OCRv3/en_PP-OCRv3_rec_infer.onnx"),
            cls_model_path=str(root / "assets/ocr/PP-OCRv1/ch_ppocr_mobile_v2.0_cls_infer.onnx"),
        )
        converter = DocumentConverter(
            allowed_formats=[InputFormat.PDF, InputFormat.DOCX, InputFormat.XLSX, InputFormat.PPTX],
            format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=options)},
        )
        converted = converter.convert(path, raises_on_error=False, max_num_pages=50, max_file_size=32 * 1024**2)
        content = converted.document.export_to_markdown(
            included_content_layers={ContentLayer.BODY, ContentLayer.FURNITURE}
            if include_furniture else {ContentLayer.BODY}
        )
        notes = converted.document.export_to_markdown(included_content_layers={ContentLayer.NOTES})
        destination = root / "reports" / ("body-furniture/documents" if include_furniture else "documents")
        destination.mkdir(parents=True, exist_ok=True)
        (destination / (filename + ".md")).write_text(content)
        (destination / (filename + ".notes.md")).write_text(notes)
        converted.document.save_as_json(destination / (filename + ".json"))
        ordered = filename in {"pdf-native.pdf", "pdf-pages.pdf", "docx-body.docx", "docx-long.docx", "xlsx-order.xlsx", "pptx-order.pptx", "pptx-unicode-long.pptx"}
        comparison_text = content
        audit = record.get("structural_audit", {})
        if notes.strip() and isinstance(audit, dict) and audit.get("comment_parts", 0) == 0:
            comparison_text += "\n\n## Speaker notes\n\n" + notes
        comparison = compare_text(comparison_text, expected, ordered)
        record.update(conversion_status=converted.status.value, errors=[str(error) for error in converted.errors], characters=len(content), notes_characters=len(notes), docling_pages=len(converted.document.pages), tables=len(converted.document.tables), comparison=comparison)
        refused = not comparison["meaningful"] or converted.status.value != "success"
        matches = bool(refused) if expected["outcome"] == "refuse" else not refused and not comparison["missing"] and not comparison["leaked"] and comparison["order_ok"]
        record.update(status="characterized" if expected["outcome"] == "characterize" else "pass" if matches else "fail", raw_output_retained=True)
    except Exception as exc:
        # Setup/import/model failures do not prove document rejection.
        record.update(status="error", exception=type(exc).__name__, error=str(exc))
    record["seconds"] = time.monotonic() - started
    result_root = root / "reports" / ("body-furniture" if include_furniture else ".")
    result_root.mkdir(exist_ok=True)
    write_json(result_root / (filename + ".result.json"), record)
    print(json.dumps({"file": filename, "status": record["status"], "seconds": record["seconds"]}), flush=True)
    return 0 if record["status"] in {"pass", "characterized"} else 1


def fixed_chunks(
    content: str,
    limit: int,
    count: Callable[[str], int],
    offsets: Callable[[str], list[int]],
) -> list[str]:
    """Token-boundary slices, retaining every character and final-input limits."""
    require(type(limit) is int and 16 <= limit <= 8192, "Chunk-token limit")
    require(count("") < limit, "Prepared prefix exhausts token budget")
    chunks: list[str] = []
    start = 0
    while start < len(content):
        remaining = content[start:]
        if count(remaining) <= limit:
            chunks.append(remaining)
            break
        ends = offsets(remaining)
        require(bool(ends) and all(type(end) is int and 0 < end <= len(remaining) for end in ends), "Tokenizer offsets invalid")
        index = min(limit, len(ends)) - 1
        while index >= 0 and count(remaining[:ends[index]]) > limit:
            index -= 1
        require(index >= 0, "Cannot split input within prepared token budget")
        end = ends[index]
        require(end > 0, "Chunker made no progress")
        chunks.append(remaining[:end])
        start += end
    require("".join(chunks) == content and all(count(chunk) <= limit for chunk in chunks), "Chunk coverage/overflow failure")
    return chunks


def recursive_chunks(
    content: str,
    limit: int,
    count: Callable[[str], int],
    offsets: Callable[[str], list[int]],
) -> list[str]:
    def divide(value: str, separators: tuple[str, ...]) -> list[str]:
        if count(value) <= limit:
            return [value]
        if not separators:
            return fixed_chunks(value, limit, count, offsets)
        separator, *rest = separators
        if separator not in value:
            return divide(value, tuple(rest))
        pieces = value.split(separator)
        return [part for index, piece in enumerate(pieces) for part in divide(piece + (separator if index < len(pieces) - 1 else ""), tuple(rest))]

    require(type(limit) is int and 16 <= limit <= 8192, "Chunk-token limit")
    packed: list[str] = []
    current = ""
    for piece in divide(content, ("\n\n", "\n", ". ", " ")):
        if current and count(current + piece) > limit:
            packed.append(current)
            current = ""
        current += piece
    if current:
        packed.append(current)
    require("".join(packed) == content and all(count(chunk) <= limit for chunk in packed), "Recursive coverage/overflow failure")
    return packed


def chunk_cases(root: Path, limits: list[int]) -> int:
    offline(root)
    from docling_core.transforms.chunker.hybrid_chunker import HybridChunker
    from docling_core.transforms.chunker.tokenizer.huggingface import HuggingFaceTokenizer
    from docling_core.types.doc import DocItemLabel, DoclingDocument
    from transformers import BertTokenizerFast

    tokenizer = BertTokenizerFast.from_pretrained(str(root / "assets/nomic"), local_files_only=True)
    prefix = "search_document: "

    def count(value: str) -> int:
        return len(tokenizer.encode(prefix + value, add_special_tokens=True, truncation=False))

    def offsets(value: str) -> list[int]:
        return [end for start, end in tokenizer(value, add_special_tokens=False, return_offsets_mapping=True, truncation=False)["offset_mapping"] if end > start]

    sources: list[tuple[str, DoclingDocument]] = []
    for path in sorted((root / "reports/documents").glob("*.json")):
        document = DoclingDocument.model_validate_json(path.read_bytes())
        if any(item.text.strip() for item in document.texts) or document.tables:
            sources.append((path.name, document))
    for kind in ("text", "markdown", "code-json", "csv", "tsv", "web-tool-payload"):
        document = DoclingDocument(name=kind)
        for index in range(120):
            document.add_text(label=DocItemLabel.PARAGRAPH, text=f"{kind} ROW {index}: café 東京 Ω distinctive content for bounded embedding input.\n")
        sources.append(("supplemental-" + kind, document))
    results: list[dict[str, object]] = []
    destination = root / "reports/chunks"
    destination.mkdir(exist_ok=True)
    for name, document in sources:
        content = document.export_to_markdown()
        for limit in limits:
            require(type(limit) is int and 16 <= limit <= 8192, "Chunk-token limit")
            for strategy in ("document", "recursive", "fixed"):
                row: dict[str, object] = {"source": name, "strategy": strategy, "limit": limit}
                started = time.monotonic()
                try:
                    if strategy == "document":
                        chunker = HybridChunker(tokenizer=HuggingFaceTokenizer(tokenizer=tokenizer, max_tokens=limit - count("")), merge_peers=True)
                        fragments = [chunker.contextualize(chunk) for chunk in chunker.chunk(dl_doc=document)]
                    elif strategy == "recursive":
                        fragments = recursive_chunks(content, limit, count, offsets)
                    else:
                        fragments = fixed_chunks(content, limit, count, offsets)
                    counts = [count(fragment) for fragment in fragments]
                    require(bool(fragments) and all(size <= limit for size in counts), "Final prepared chunk overflow/empty output")
                    row.update(status="pass", chunks=len(fragments), max_prepared_tokens=max(counts), source_reconstruction="exact" if strategy != "document" else "Docling contextualized representation; coverage assessed separately")
                    write_json(destination / (name + f".{strategy}.{limit}.json"), {"chunks": [{"text": fragment, "prepared": prefix + fragment, "tokens_with_specials": size} for fragment, size in zip(fragments, counts, strict=True)]})
                except Exception as exc:
                    row.update(status="fail", error=type(exc).__name__ + ": " + str(exc))
                row["seconds"] = time.monotonic() - started
                results.append(row)
    write_json(root / "reports/chunking.json", {"tokenizer": "nomic-ai/nomic-embed-text-v1.5, pinned local tokenizer", "prefix": prefix, "special_tokens_counted": True, "model_calls": 0, "counter_matches_LM_Studio": "not yet qualified", "recursive_fixed": "test-only policy prototypes, not production implementations", "results": results})
    print(json.dumps({"cases": len(results), "passed": sum(row["status"] == "pass" for row in results), "failed": sum(row["status"] != "pass" for row in results), "sources": len(sources), "limits": limits}), flush=True)
    return 0 if all(row["status"] == "pass" for row in results) else 1


def check_isolation(root: Path) -> int:
    offline(root)
    import socket

    checks: dict[str, bool] = {}
    try:
        with socket.socket() as connection:
            connection.connect(("127.0.0.1", 9))
    except PermissionError as exc:
        checks["network_denied_before_connect"] = "Offline evaluation" in str(exc)
    for operation, mode in (("write", "xb"), ("read", "rb")):
        try:
            with (root.parent / "forbidden-evaluation-canary").open(mode):
                pass
        except ValueError as exc:
            checks[operation + "_outside_run_denied"] = "outside" in str(exc)
    allowed = root / "reports/allowed-isolation-canary"
    allowed.write_text("private-only")
    checks["private_write_and_read_allowed"] = allowed.read_text() == "private-only"
    require(len(checks) == 4 and all(checks.values()), "Isolation canary failed")
    write_json(root / "reports/isolation.json", {"checks": checks, "scope": "Python-visible prevention; native/OS behavior not sandboxed", "production_changes": False})
    print(json.dumps(checks))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["setup", "probe", "fixtures", "assets", "convert", "chunks", "check-isolation"])
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--uv", type=Path)
    parser.add_argument("--asset-manifest", type=Path)
    parser.add_argument("--case")
    parser.add_argument("--include-furniture", action="store_true")
    parser.add_argument("--chunk-tokens", type=int, nargs="+", default=[512])
    args = parser.parse_args()
    root = args.run_root.resolve(strict=True)
    require(root == args.run_root and root.name.startswith("docling-behavior-") and root.parent.name == "runs" and root.parent.parent.name == ".friday_test", "Explicit private behavior run required")
    require(sys.flags.isolated == 1 and sys.flags.no_site == 1 and sys.flags.dont_write_bytecode == 1, "Use base Python -I -S -B")
    if args.command == "setup":
        require(args.uv is not None and args.uv.is_file(), "Explicit existing uv required")
        return setup(root, args.uv)
    if args.command == "fixtures":
        return prepare_inputs(root)
    if args.command == "assets":
        require(args.asset_manifest is not None, "Explicit asset manifest required")
        return fetch_assets(root, args.asset_manifest)
    if args.command == "convert":
        require(args.case is not None, "Explicit generated case required")
        return convert_case(root, args.case, args.include_furniture)
    if args.command == "chunks":
        return chunk_cases(root, args.chunk_tokens)
    if args.command == "check-isolation":
        return check_isolation(root)
    return probe(root)


if __name__ == "__main__":
    raise SystemExit(main())
