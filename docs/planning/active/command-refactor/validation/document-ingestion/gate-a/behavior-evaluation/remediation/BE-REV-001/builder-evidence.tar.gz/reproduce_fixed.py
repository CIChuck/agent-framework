"""Builder proof only: real conversion, owned timeout, refusal, genuine retry."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

scratch = Path(__file__).parent.resolve()
mode = "optimized" if sys.flags.optimize else "normal"
root = scratch / ".friday_test/runs" / ("docling-behavior-remediation-final4-" + mode)
root.mkdir(parents=True)
supplied = Path("/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/docling-behavior-20261112")
source = Path("/Users/chuckrussell/Dev/gendev/agent-framework/tests/readiness/ingest")
for name in ("target", "assets", "config", "inputs"):
    subprocess.run(["/bin/cp", "-cR", str(supplied / name), str(root / name)], check=True)
for name in ("logs", "reports", "cache", "tmp", "source"):
    (root / name).mkdir()
shutil.copytree(source, root / "source/ingest", ignore=shutil.ignore_patterns("__pycache__"))
sys.path.insert(0, str(root / "source"))
from ingest import behavior

runner = root / "source/ingest/behavior.py"
base = Path("/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13")
flags = ["-I", "-S", "-B"] + (["-O"] if sys.flags.optimize else [])
common = [str(base), *flags, str(runner)]
convert = common + ["convert", "--run-root", str(root), "--case", "pdf-native.pdf", "--include-furniture", "--enforce-admission"]
chunks = common + ["chunks", "--run-root", str(root), "--document-profile", "admitted", "--chunk-tokens", "64", "128", "512", "1024"]
report = common + ["report", "--run-root", str(root)]
proof = {"mode": mode, "run_root": str(root), "runner_sha256": hashlib.sha256(runner.read_bytes()).hexdigest(), "source_pdf_sha256": hashlib.sha256((root / "inputs/generated/pdf-native.pdf").read_bytes()).hexdigest(), "commands": []}

def require(value, message):
    if not value:
        raise RuntimeError(message)

def command(name, argv, limit=300, direct=False):
    started = time.monotonic()
    if direct:
        result = subprocess.run(argv, cwd=root, env=behavior.environment(root), capture_output=True, timeout=limit)
        (root / "logs" / (name + ".stdout")).write_bytes(result.stdout)
        (root / "logs" / (name + ".stderr")).write_bytes(result.stderr)
        code = result.returncode
    else:
        code = behavior.supervise(root, name, argv, limit)
    proof["commands"].append({"name": name, "argv": argv, "limit": limit, "direct": direct, "exit": code, "seconds": time.monotonic() - started})
    (scratch / ("proof-final4-" + mode + ".json")).write_text(json.dumps(proof, indent=2) + "\n")
    return code

result_path = root / "reports/admitted/pdf-native.pdf.result.json"
doc_path = root / "reports/admitted/documents/pdf-native.pdf.json"
require(command("fresh-success", convert) == 0, "Real initial conversion failed")
old_record = result_path.read_bytes()
old_json = doc_path.read_bytes()
positive = behavior.admitted_document(root, "pdf-native.pdf", old_json)
require(positive["status"] == "pass" and positive["native_docling_called"] is True, "Initial conversion lacks genuine positive admission")
require(command("fresh-chunks", chunks) == 0, "Fresh positive chunking failed")
fresh_chunks = json.loads((root / "reports/chunking.json").read_bytes())
require(fresh_chunks["actual_document_sources"] == ["pdf-native.pdf.json"], "Positive source missing")
require(command("owned-timeout", convert, 1) == 124, "Owned actual conversion did not time out")
require(result_path.read_bytes() == old_record and doc_path.read_bytes() == old_json, "Controlled timeout changed old published bytes")
try:
    behavior.admitted_document(root, "pdf-native.pdf", old_json)
except (ValueError, OSError) as exc:
    proof["stale_refusal"] = type(exc).__name__ + ": " + str(exc)
else:
    raise RuntimeError("Old PDF retained admission after the timeout")
require(command("stale-report-refused", report) != 0, "Old chunk report remained green")
require(command("stale-chunks-refused", chunks) != 0, "Only stale document earned chunks success")
refused_chunks = json.loads((root / "reports/chunking.json").read_bytes())
require(refused_chunks["actual_document_sources"] == [] and refused_chunks["results"] == [], "Stale PDF or supplemental sources entered chunk matrix")
require(any(row["file"] == "pdf-native.pdf.json" and "Latest admission refused" in row["reason"] for row in refused_chunks["skipped"]), "No explicit skip reason")
require(command("fresh-direct-retry", convert, direct=True) == 0, "Real direct CLI retry failed")
fresh = behavior.admitted_document(root, "pdf-native.pdf", doc_path.read_bytes())
require(fresh["attempt"] != positive["attempt"], "Retry reused the initial identity")
require(command("retry-chunks", chunks) == 0, "Fresh retry did not restore chunkability")
require(command("retry-report", report) == 0, "Fresh retry coverage failed")
proof.update(status="builder-regression-passed", initial_attempt=positive["attempt"], retry_attempt=fresh["attempt"], old_result_sha256=hashlib.sha256(old_record).hexdigest(), refused_chunk_report=refused_chunks, positive_chunk_cases=len(fresh_chunks["results"]), final_chunk_report=json.loads((root / "reports/chunking.json").read_bytes()))
(scratch / ("proof-final4-" + mode + ".json")).write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps({"mode": mode, "status": proof["status"], "proof": str(scratch / ("proof-final4-" + mode + ".json"))}), flush=True)
