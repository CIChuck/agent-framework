import hashlib,json,os,pathlib
P=pathlib.Path;own=P('/private/tmp/docling-corrected-review-cFoB1YcS');roots={'supplied-runtime':P('/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/docling-behavior-20261112'),'supplied-control':P('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n')};result={}
for name,root in roots.items():
 entries={}
 for folder,dirs,files in os.walk(root,followlinks=False):
  for n in sorted(dirs+files):
   p=P(folder)/n;s=p.lstat();r={'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'ino':s.st_ino,'nlink':s.st_nlink}
   if p.is_symlink():r['link']=os.readlink(p)
   elif p.is_file():r['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
   entries[str(p.relative_to(root))]=r
 before=json.loads((own/(name+'-opening.json')).read_bytes());differences=[n for n in set(entries)|set(before) if entries.get(n)!=before.get(n)];result[name]={'entries':len(entries),'differences':differences};print(name,len(entries),'differences',differences,flush=True)
(own/'supplied-closing.json').write_text(json.dumps(result,indent=2)+'\n')
if any(r['differences'] for r in result.values()):raise RuntimeError('Supplied boundary changed')
