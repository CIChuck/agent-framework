|   READINESS HEADER |
|--------------------|
|                  5 |