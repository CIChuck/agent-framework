| READINESS HEADER   |
|--------------------|
| VISIBLE SHEET      |