| READINESS HEADER    |
|---------------------|
| EXCLUDED HIDDEN ROW |