import pathlib,sys,types,hashlib
s=pathlib.Path(__file__).resolve().parent
root=s/'.friday_test/runs/docling-behavior-review-20261112'
path=root/'source/ingest/behavior.py';raw=path.read_bytes()
if hashlib.sha256(raw).hexdigest()!='32a1f3ee4e030a176a642573bf334425a1e93f79fe1c2a8be3d0117da0d47a60':raise SystemExit('wrong runner')
m=types.ModuleType('review_behavior');m.__file__=str(path);exec(compile(raw,str(path),'exec'),m.__dict__)
name=sys.argv[1];argv=sys.argv[2:]
raise SystemExit(m.supervise(root,name,argv,300))
