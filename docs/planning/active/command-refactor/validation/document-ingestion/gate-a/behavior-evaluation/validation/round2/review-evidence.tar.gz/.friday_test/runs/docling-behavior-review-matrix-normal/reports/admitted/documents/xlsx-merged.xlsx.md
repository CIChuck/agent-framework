| READINESS HEADER   |                  |
|--------------------|------------------|
| MERGED ONE VALUE   | MERGED ONE VALUE |