import pathlib,json,hashlib,tarfile,stat
s=pathlib.Path(__file__).resolve().parent;r=s/'.friday_test/runs/docling-behavior-review-20261112';stale=s/'.friday_test/runs/docling-behavior-stale-review'
files=set()
def add(p):
 if p.is_dir():
  for q in p.rglob('*'):
   if q.is_file():files.add(q)
 else:files.add(p)
for name in ('report.md','command-ledger.jsonl','command-ledger.md','review-request.json','opening-integrity.json','closing-integrity.json','opening-index.bin','opening-status.bin','inspected-summary.json','stale-reproduction-normal.json','stale-reproduction-optimized.json','reproduce_stale.py','execute_checks.py','supervise_runtime.py','prepare_review.py','closing_integrity.py','inspection_summary.py','independent_runtime_checks.py','write_report.py','package_evidence.py','command-logs','runtime-normal','runtime-optimized','frozen'):
 add(s/name)
for name in ('reports','logs'):add(r/name)
add(r/'source/reviewer_independent_checks.py')
for name in ('reports','logs'):add(stale/name)
add(stale/'inputs/generated/pdf-native.pdf')
records=[]
for p in sorted(files):
 assert p.is_relative_to(s) and p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
 records.append({'path':str(p.relative_to(s)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size})
(s/'review-evidence-index.json').write_text(json.dumps({'schema':1,'excluded':'No copied third-party target, model assets, production payloads or private controller directories; selected reviewer evidence only','files':records},indent=2)+'\n')
archive=s/'review-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for row in records:t.add(s/row['path'],arcname=row['path'],recursive=False)
 t.add(s/'review-evidence-index.json',arcname='review-evidence-index.json',recursive=False)
expected={x['path']:x for x in records}
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(expected)+1 and len(set(m.name for m in members))==len(members)
 for m in members:
  assert m.isfile()
  b=t.extractfile(m).read()
  if m.name=='review-evidence-index.json':assert b==(s/m.name).read_bytes()
  else:assert len(b)==expected[m.name]['size'] and hashlib.sha256(b).hexdigest()==expected[m.name]['sha256']
main=('report.md','command-ledger.jsonl','command-ledger.md','review-evidence.tar.gz','review-evidence-index.json','closing-integrity.json','reproduce_stale.py')
hashes={name:{'sha256':hashlib.sha256((s/name).read_bytes()).hexdigest(),'size':(s/name).stat().st_size} for name in main}
(s/'artifact-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps({'scratch':str(s),'members':len(records)+1,'hashes':hashes},indent=2))
