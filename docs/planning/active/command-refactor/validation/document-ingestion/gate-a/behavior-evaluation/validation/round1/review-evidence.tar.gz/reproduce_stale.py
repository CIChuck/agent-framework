import pathlib,sys,types,hashlib,json,subprocess
def require(value,message):
 if not value:raise RuntimeError(message)
s=pathlib.Path(__file__).resolve().parent;r=s/'.friday_test/runs/docling-behavior-stale-review'
p=r/'source/ingest/behavior.py';raw=p.read_bytes();require(hashlib.sha256(raw).hexdigest()=='32a1f3ee4e030a176a642573bf334425a1e93f79fe1c2a8be3d0117da0d47a60','source hash')
m=types.ModuleType('behavior');m.__file__=str(p);exec(compile(raw,str(p),'exec'),m.__dict__)
flags=['-I','-S','-B']+(['-O'] if sys.flags.optimize else [])
argv=[sys.executable,*flags,str(p),'convert','--run-root',str(r),'--case','pdf-native.pdf','--include-furniture','--enforce-admission']
positive=m.supervise(r,'fresh-positive-'+str(sys.flags.optimize),argv,300)
require(positive==0,'genuine fresh successful conversion in same run and mode')
result=r/'reports/admitted/pdf-native.pdf.result.json';before=result.read_bytes();record=json.loads(before)
require(record['status']=='pass' and record['conversion_status']=='success','prior real success')
flags=['-I','-S','-B']+(['-O'] if sys.flags.optimize else [])
argv=[sys.executable,*flags,str(p),'convert','--run-root',str(r),'--case','pdf-native.pdf','--include-furniture','--enforce-admission']
code=m.supervise(r,'fresh-native-rerun-'+str(sys.flags.optimize),argv,1)
require(code==124,'fresh timeout')
require(result.read_bytes()==before,'old result unchanged')
oldraw=(r/'reports/admitted/documents/pdf-native.pdf.json').read_bytes();ready=m.document_ready(json.loads(result.read_bytes()),oldraw)
chunks=m.supervise(r,'after-timeout-chunks-'+str(sys.flags.optimize),[sys.executable,*flags,str(p),'chunks','--run-root',str(r),'--chunk-tokens','64','128','512','1024'],300)
data=json.loads((r/'reports/chunking.json').read_bytes())
out={'mode':'optimized' if sys.flags.optimize else 'normal','positive_conversion_exit':positive,'conversion_supervisor_exit':code,'result_record_unchanged':True,'document_ready_after_failed_latest_attempt':ready,'chunk_exit':chunks,'stale_source_in_admitted_matrix':'pdf-native.pdf.json' in data['actual_document_sources'],'chunk_cases':len(data['results']),'chunk_failures':sum(x['status']!='pass' for x in data['results']),'skipped':data['skipped']}
(s/('stale-reproduction-'+out['mode']+'.json')).write_text(json.dumps(out,indent=2));print(json.dumps(out))
require(ready and chunks==0 and out['stale_source_in_admitted_matrix'],'stale source actually admitted')
