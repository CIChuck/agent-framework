import json,os,pathlib,subprocess,time
P=pathlib.Path;own=P('/private/tmp/docling-corrected-review-cFoB1YcS');repo=P('/Users/chuckrussell/Dev/gendev/agent-framework');py='/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13';manifest=own/'frozen/manifest.json';digest='be8ca22f16b9acdc9b2279ca72db33747adbb59f17be361b1256857927df98b8';log=own/'checks-logs';log.mkdir();ledger=[]
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1','UV_CACHE_DIR':str(own/'uv-admin-cache'),'UV_NO_CONFIG':'1','UV_PYTHON_DOWNLOADS':'never','RUFF_CACHE_DIR':str(own/'ruff-cache')}
def run(name,argv,cwd=repo):
 t=time.monotonic()
 with (log/(name+'.stdout')).open('xb') as out,(log/(name+'.stderr')).open('xb') as err:r=subprocess.run(argv,cwd=cwd,env=env,stdout=out,stderr=err)
 row={'name':name,'argv':argv,'cwd':str(cwd),'exit':r.returncode,'seconds':time.monotonic()-t};ledger.append(row);(own/'checks-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');print(name,r.returncode,flush=True)
for mode,extra in [('normal',[]),('optimized',['-O'])]:run('selftest-'+mode,[py,'-I','-S','-B',*extra,str(own/'frozen/ingest/run.py'),'selftest','--harness-manifest',str(manifest),'--harness-manifest-sha256',digest,'--scratch',str(own/('selftest-'+mode))],own)
for name,args in [('ruff',['check','--no-cache']),('format',['format','--check','--no-cache'])]:run(name,[str(own/'tools/ruff'),*args,'--config',str(own/'tools/pyproject.toml'),str(own/'frozen/ingest')],own)
for name,args in [('board-validate',['scripts/friday-dev-board.py','validate']),('board-render',['scripts/friday-dev-board.py','render','--check']),('documentation-lifecycle',['scripts/check-documentation-lifecycle.py']),('package-metadata',['scripts/check-package-metadata.py'])]:run(name,['uv','run','--offline','--frozen','--no-sync','--no-python-downloads','python','-B',*args])
git=['git','-c','core.fsmonitor=false']
for name,args in [('owned-whitespace',['diff','--check','--','tests/readiness/ingest']),('range-whitespace',['diff','--check','11e8fccc23981b5449a51f2ef3f7d3ea565a062c','96f752d64ead1c98bd900891aaa94edfe4ebe5d3']),('cached-whitespace',['diff','--cached','--check']),('dirty-whitespace-baseline',['diff','--check'])]:run(name,git+args)
