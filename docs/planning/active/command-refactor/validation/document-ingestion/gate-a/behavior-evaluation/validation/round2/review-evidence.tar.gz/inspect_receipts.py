import collections,gzip,hashlib,json,pathlib,tarfile
P=pathlib.Path;own=P('/private/tmp/docling-corrected-review-cFoB1YcS');packet=P('/Users/chuckrussell/Dev/gendev/agent-framework/docs/planning/active/command-refactor/validation/document-ingestion/gate-a/behavior-evaluation');out={}
with tarfile.open(packet/'behavior-evidence.tar.gz','r:gz') as t:
 def read(n):return json.loads(t.extractfile(n).read())
 for n in ['run/reports/resolve.json','run/reports/install.json','run/reports/packages.json','run/reports/isolation.json']:
  out[n]=read(n)
 assets=read('run/reports/assets.json');out['assets_summary']={'count':len(assets),'status':dict(collections.Counter(r['status'] for r in assets)),'bytes':sum(r.get('size',0) for r in assets),'digests':[{k:r[k] for k in ('path','sha256','size') if k in r} for r in assets]}
 for mode in ('normal','optimized'):
  prefix='run/history/corrected-'+mode+'/'
  evaluation=read(prefix+'evaluation-'+mode+'-configured.json');coverage=read(prefix+'chunk-content-coverage.json');out[prefix+'summary']={'evaluation':evaluation,'coverage':{k:v for k,v in coverage.items() if k!='results'}}
 # Historical raw conversion outcomes are execution measurements, never reviewer verdicts.
 raw=[]
 for m in t.getmembers():
  if m.name.startswith('run/reports/') and m.name.count('/')==2 and m.name.endswith('.result.json'):
   d=read(m.name);raw.append({k:d[k] for k in ('file','status','phase','native_docling_called','conversion_status','comparison','error') if k in d})
 out['historical_raw_conversion_results']=raw
 rawchunks=read('run/reports/chunking-default.json');out['historical_default_chunk_summary']={'cases':len(rawchunks['results']),'pass':sum(x['status']=='pass' for x in rawchunks['results']),'failures':[x for x in rawchunks['results'] if x['status']!='pass'],'sources':rawchunks.get('actual_document_sources','not recorded by historical version')}
control=P('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n');out['frozen_checks']=json.loads((control/'frozen-checks.json').read_bytes());out['mypy_receipt']=json.loads((control/'mypy-last.json').read_bytes());(own/'inspected-receipts.json').write_text(json.dumps(out,indent=2)+'\n')
for k,v in out.items():
 if k=='frozen_checks':print(k,'type',type(v).__name__,'keys',list(v) if isinstance(v,dict) else 'list '+str(len(v)))
 elif k in ('historical_raw_conversion_results','historical_default_chunk_summary'):print(k,json.dumps(v))
 elif k=='assets_summary':print(k,{a:b for a,b in v.items() if a!='digests'})
 else:print(k,json.dumps(v)[:3500])
