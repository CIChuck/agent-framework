| READINESS HEADER   |
|--------------------|