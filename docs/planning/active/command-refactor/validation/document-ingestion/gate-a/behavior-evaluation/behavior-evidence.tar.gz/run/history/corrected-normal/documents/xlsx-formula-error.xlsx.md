| READINESS HEADER   |
|--------------------|
| #DIV/0!            |