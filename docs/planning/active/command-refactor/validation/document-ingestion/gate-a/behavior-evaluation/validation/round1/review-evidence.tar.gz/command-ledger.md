**Exact fresh command ledger**

Run root: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`. All entries retain exact argv/cwd in command-ledger.jsonl.

**minimal-normal** — exit 0, 1.884s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/frozen/harness/bootstrap.py selftest --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/frozen/manifest.json --harness-manifest-sha256 49cd2cdedcf2c2999505d623f0e92010cc6b7edc9997ad39c0bfd67ebac7ccfc --scratch /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/selftest-normal
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `9a9a5930adc706611d20d819e539b914a9d359296a62d55496da900f9c6e891d`; stderr SHA256 `da6aa7d23ba47419053ea416c0e715b4a286c22a82e4796136d096d02705afa4`.

**minimal-optimized** — exit 0, 1.866s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/frozen/harness/bootstrap.py selftest --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/frozen/manifest.json --harness-manifest-sha256 49cd2cdedcf2c2999505d623f0e92010cc6b7edc9997ad39c0bfd67ebac7ccfc --scratch /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/selftest-optimized
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `b14a976391974cab77976bfbcdb703297398e7fd5d1fc1e55765ea1610391d0d`; stderr SHA256 `b22701cd9c63e42d21e92418f8f5d3fb74975e2b8872ec79acfa1e37d41327c0`.

**ruff-check** — exit 0, 0.487s

```sh
/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/validation-tools/ruff check --no-cache --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/validation-tools/pyproject.toml /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/static-source/tests/readiness/ingest
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/static-source`; stdout SHA256 `82b3e6a6c090a57601d22943bd23fca9218d1031dbe5a7b754092f9a156b4f18`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**ruff-format** — exit 0, 0.016s

```sh
/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/validation-tools/ruff format --check --no-cache --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/validation-tools/pyproject.toml /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/static-source/tests/readiness/ingest
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/static-source`; stdout SHA256 `edc30689f9fd3dc494be14b82b3b560778897cff7435d2cc81d54f1829d5038d`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**board** — exit 0, 0.241s

```sh
uv run --offline --frozen --no-sync --no-python-downloads python -B scripts/friday-dev-board.py validate
```
cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; stdout SHA256 `c4d2aec671b8fd5d5a978b1c191b186f6d151f7ace4785fbd74b06c3c5f3fdae`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**dashboard** — exit 0, 0.142s

```sh
uv run --offline --frozen --no-sync --no-python-downloads python -B scripts/friday-dev-board.py render --check
```
cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; stdout SHA256 `a28df31135633728c76b88ed1a836e90f2c8046e1d72663c8881937c7693ba33`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**docs** — exit 0, 0.723s

```sh
uv run --offline --frozen --no-sync --no-python-downloads python -B scripts/check-documentation-lifecycle.py
```
cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; stdout SHA256 `4c224fcc7658bd6663078daba6094aef56ba2b7461b20305ab9c5544d1d688a6`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**metadata** — exit 0, 0.041s

```sh
uv run --offline --frozen --no-sync --no-python-downloads python -B scripts/check-package-metadata.py
```
cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; stdout SHA256 `b755228d64e991cad2a40d1ea238ea00e97d8d2fd420a5141fffa00476ed690f`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**owned-whitespace** — exit 0, 0.012s

```sh
git -c core.fsmonitor=false diff --check -- .gitignore docs/planning tests/readiness/ingest
```
cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; stdout SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**range-whitespace** — exit 0, 0.024s

```sh
git -c core.fsmonitor=false diff --check 11e8fccc23981b5449a51f2ef3f7d3ea565a062c..4fd5f8252cd5d89924e0e01527dadca3ea1ee3b3 -- .gitignore docs/planning tests/readiness/ingest
```
cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; stdout SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**index-whitespace** — exit 0, 0.009s

```sh
git -c core.fsmonitor=false diff --cached --check
```
cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; stdout SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-pdf-native.pdf** — exit 0, 34.447s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-pdf-native.pdf /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pdf-native.pdf --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `20a6e82e69ff0e0abb4d4100d36b7b89f43643dc23a09cdcfd46a7601af3c6da`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-pdf-pages.pdf** — exit 0, 9.669s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-pdf-pages.pdf /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pdf-pages.pdf --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `db68db9a1ca687e0357454ef8ad4437c48201f03ec4d7a026b9a47bfaf9dbdc6`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-pdf-scanned.pdf** — exit 0, 10.257s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-pdf-scanned.pdf /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pdf-scanned.pdf --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `91148bf2c9695da858ed2aa580798f5f5c01c8dd7c38411649880e1a7e3a879c`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-docx-body.docx** — exit 0, 4.290s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-docx-body.docx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case docx-body.docx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `cb752f220f2037f48ee1c0cd26c85d47c391de9d1fb7169002af3c4ad24571d4`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-docx-merged.docx** — exit 0, 4.286s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-docx-merged.docx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case docx-merged.docx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `aea47f11e16875b018cd8090ee32ff3c0e7ffe0a278e2d6aa39307e2a8e3ebeb`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-xlsx-formula-valid.xlsx** — exit 0, 4.260s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-xlsx-formula-valid.xlsx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case xlsx-formula-valid.xlsx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `5b17ad3fee25e8f53c6ac17cedf2e7ee2650220deffa128b00fa846729c1aa84`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-xlsx-formula-missing.xlsx** — exit 0, 1.272s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-xlsx-formula-missing.xlsx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case xlsx-formula-missing.xlsx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `338094412e39b13a7f020a6792a9a70301734cbbae5ee2df80e5db0fd570c93c`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-xlsx-hidden-row.xlsx** — exit 0, 1.203s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-xlsx-hidden-row.xlsx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case xlsx-hidden-row.xlsx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `4f20cf5c3a41b2ef036411ef5c81cd1f01af427d2d0c42211f7b27298a5221e1`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-pptx-notes.pptx** — exit 0, 4.214s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-pptx-notes.pptx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pptx-notes.pptx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `62947f7380275a4b17953ccbe480ddb490400048548fa68fa9e0a623b949ef7e`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-pptx-comments.pptx** — exit 0, 4.248s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-pptx-comments.pptx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pptx-comments.pptx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `83faa81407baffca7d63277395e976bf22ae775381e48b57d48bbc0ae279bf27`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-corrupt.pdf** — exit 0, 4.176s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-corrupt.pdf /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case corrupt.pdf --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `81cf1b2ac6ef89c2ac9f35174b6805a74ca46eddddb0cd5d63051f6a64ae0185`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-corrupt.docx** — exit 0, 1.307s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-corrupt.docx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case corrupt.docx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `928688c59d7302f63e04caeb11399495ed525479a4e1e16f2915465befdc0779`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-probe** — exit 0, 1.250s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-probe /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py probe --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `d2ae818f7f0a722e70f5be3bd8694776f38121346dd8c6a004994c3e3ae5bf96`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-isolation** — exit 0, 1.337s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-isolation /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py check-isolation --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `28bd303ac18d7643fa29279519f516247567d0f7c73f61b2768bb50c24a680a4`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-chunks** — exit 0, 6.664s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-chunks /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py chunks --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --chunk-tokens 64 128 512 1024
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `87c10f5ebb2c3ecf662de305c5f56f8be24c791a50d1f8d8e0064aea206470cd`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**normal-report** — exit 0, 1.236s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py normal-report /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py report --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `83f39c44cb0da0fdd9488565d5865569aeaec99ef9786e3f35fc6ebc057f5c46`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-pdf-native.pdf** — exit 0, 9.662s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-pdf-native.pdf /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pdf-native.pdf --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `5c4735f3867e0cb43c172b75b463bf5ef9575e42606327d8240acf497b1636db`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-pdf-pages.pdf** — exit 0, 9.986s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-pdf-pages.pdf /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pdf-pages.pdf --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `cc5336ba77072bcf9463db3cdd03ad3f38b6a549da590b946dedc378411ec33b`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-pdf-scanned.pdf** — exit 0, 10.249s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-pdf-scanned.pdf /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pdf-scanned.pdf --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `aee3f908b802c9d8b9d9b785bacdb588e1e88f4724bd54e2ac69d97d769491dd`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**stale-reproduction-normal** — exit 0, 20.807s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/reproduce_stale.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `607a7fa898033949551e66a2075f7d468f96c4574f121dc6591ca2cf868133d9`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-docx-body.docx** — exit 0, 4.553s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-docx-body.docx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case docx-body.docx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `8c6587839b0cecc2abec21fbcdddf519c2d73fd9fc73e696e7c8394c6e8bf4eb`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**stale-reproduction-optimized** — exit 0, 8.215s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/reproduce_stale.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `0db0acdaceffd75618d26c503de42d6e8c1f6f11ddca217910e300b48300cfd2`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-docx-merged.docx** — exit 0, 4.523s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-docx-merged.docx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case docx-merged.docx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `5945033e555fad97990785c5a41a215987c3e5753f97ef32ffb7dd981fe54294`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-xlsx-formula-valid.xlsx** — exit 0, 4.553s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-xlsx-formula-valid.xlsx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case xlsx-formula-valid.xlsx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `e29759599bb772314a3b098caa4cd56f272f667dca308faeba819c0b9613d51a`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-xlsx-formula-missing.xlsx** — exit 0, 1.262s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-xlsx-formula-missing.xlsx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case xlsx-formula-missing.xlsx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `6bd9607fdc82735c9e83147acaacc8a824ca75d4d60bf77f0e835141553f1949`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-xlsx-hidden-row.xlsx** — exit 0, 1.268s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-xlsx-hidden-row.xlsx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case xlsx-hidden-row.xlsx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `5d4968970cc49fd73946493270275a0676c1adb488ce232667d9fc6ad744e250`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-pptx-notes.pptx** — exit 0, 4.240s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-pptx-notes.pptx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pptx-notes.pptx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `77901576ecd064acf4de529067221435e35b9466b847f5a0b8253f777aa112a1`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-pptx-comments.pptx** — exit 0, 4.504s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-pptx-comments.pptx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case pptx-comments.pptx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `2064a69ec34efefcf0fd69c4562384046de8132705a1c8d7dea71370dcf4b4c2`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-corrupt.pdf** — exit 0, 4.569s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-corrupt.pdf /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case corrupt.pdf --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `fd23832637d8ae834976a558c16eedb6be19c68a13809124a1a64effb211abd4`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-corrupt.docx** — exit 0, 1.295s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-corrupt.docx /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py convert --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --case corrupt.docx --include-furniture --enforce-admission
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `95d6858a8814bbafc75ec4b793cf5188627fb2b8adfc09b068e3a2740228961e`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-probe** — exit 0, 1.272s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-probe /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py probe --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `ddcd5ad701109b314ac29a72c787f15c950360c9339fe1abcb6956ebb7d4b43c`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-isolation** — exit 0, 1.253s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-isolation /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py check-isolation --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `1961088ec251940b01124fdfe738f7fa8945e7386cc982b38d01f9fd849f3081`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-chunks** — exit 0, 6.675s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-chunks /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py chunks --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112 --chunk-tokens 64 128 512 1024
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `228e56e4d92732056d7f7576b499ee50c0bcedbd131850cc5032a9add6e8d738`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**optimized-report** — exit 0, 1.244s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py optimized-report /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py report --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `e59ac2f5347d5572a47c86bbbe74f74761062d46c0d31bfc94dde3ec23c57d9c`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**independent-origin-token-check** — exit 1, 1.552s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/independent_runtime_checks.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`; stderr SHA256 `206619367df2bd61d3baeaeba6e75ab3cbdb222e2772ca4bee93490853e2404d`.

**default512-normal** — exit 0, 4.479s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/supervise_runtime.py default512-normal /Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/ingest/behavior.py chunks --run-root /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `af7bd9d868fa55fa56adf71c8e6a65db5be95813fe6a0b4660722ee570000298`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**stale-reproduction-proof-normal** — exit 0, 7.221s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/reproduce_stale.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `c30b205a25bde8faab3020b262a635c9bdaca6c9c251827e3c7fb164cbb4ef13`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**stale-reproduction-proof-optimized** — exit 0, 7.500s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/reproduce_stale.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `1cb76a5e0387ffd3c5fd3c0d35198542f1bb0765e1598d6c987606b5184981f4`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**independent-origin-token-check-corrected** — exit 0, 5.133s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/.friday_test/runs/docling-behavior-review-20261112/source/reviewer_independent_checks.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `beb4df40d37ed7592b59846c3f52e9b3e5fb11cec105bc7dbf6f89582ce0238f`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**closing-integrity** — exit 0, 2.456s

```sh
python3 -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/closing_integrity.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `dbfe52577a3ae8d0625dd5c91e20f4278c5d83d28cde46775b360c2dc61b295e`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**stale-reproduction-final-normal** — exit 0, 25.448s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/reproduce_stale.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `18483c8f6aea7fbeecbf6d08c8f54b14d27bc8b85f3d93d81b9759792397c27d`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**stale-reproduction-final-optimized** — exit 0, 16.475s

```sh
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/reproduce_stale.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `bdc31c69785ca305c449be559fc20b5dc454adcb60e555e1abaf24283b3c26b8`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

**closing-integrity-final** — exit 0, 1.563s

```sh
python3 -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2/closing_integrity.py
```
cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/docling-independent-review-pznws3a2`; stdout SHA256 `dbfe52577a3ae8d0625dd5c91e20f4278c5d83d28cde46775b360c2dc61b295e`; stderr SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
