import hashlib,json,os,pathlib,subprocess,sys,time
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OWN=pathlib.Path('/private/tmp/docling-corrected-review-cFoB1YcS')
REQ=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n/review-request.json')
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git','-c','core.fsmonitor=false',*args],cwd=ROOT,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def verify():
 req=json.loads(REQ.read_text()); b=json.loads(pathlib.Path(req['review_boundary']).read_text()); errors=[]
 logical=hashlib.sha256(git('ls-files','-s','-z')).hexdigest()
 for key,val in [('head',git('rev-parse','HEAD').decode().strip()),('branch',git('branch','--show-current').decode().strip()),('logical_before_status',logical),('status',git('status','--porcelain=v1').decode())]:
  if b[key]!=val: errors.append([key,b[key],val])
 for p,h in req['inputs'].items():
  actual=sha(ROOT/p if not p.startswith('/') else p)
  if actual!=h: errors.append(['pin',p,h,actual])
 for p,h in b['tracked_sha256'].items():
  if sha(ROOT/p)!=h: errors.append(['tracked',p])
 for p,t in b['symlinks'].items():
  if not (ROOT/p).is_symlink() or os.readlink(ROOT/p)!=t: errors.append(['symlink',p])
 for p,expected in b['preserved'].items():
  x=ROOT/p; s=x.lstat(); actual={'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'birthtime':s.st_birthtime}
  if 'sha256' in expected: actual['sha256']=sha(x)
  if actual!=expected: errors.append(['preserved',p,expected,actual])
 result={'time':time.time(),'head':b['head'],'logical':logical,'tracked':len(b['tracked_sha256']),'symlinks':len(b['symlinks']),'protected':len(b['preserved']),'pins':len(req['inputs']),'errors':errors}
 (OWN/(sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result)); return bool(errors)
sys.exit(verify())
