| READINESS HEADER   |                        |
|--------------------|------------------------|
| VISIBLE CELL       | EXCLUDED HIDDEN COLUMN |