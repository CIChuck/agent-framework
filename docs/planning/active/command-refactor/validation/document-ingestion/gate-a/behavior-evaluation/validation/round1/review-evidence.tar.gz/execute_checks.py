import os,json,pathlib,subprocess,time,hashlib,sys
s=pathlib.Path(__file__).resolve().parent
base='/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13'
run=s/'.friday_test/runs/docling-behavior-review-20261112'
runner=run/'source/ingest/behavior.py'
env={k:v for k,v in os.environ.items() if k in ('HOME','PATH','LANG','TERM')};env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',UV_CACHE_DIR=str(s/'uv-cache'),RUFF_CACHE_DIR=str(s/'ruff-cache'),TMPDIR=str(s/'tmp'))
(s/'tmp').mkdir(exist_ok=True); (s/'command-logs').mkdir(exist_ok=True)
def execute(name,argv,cwd=s,timeout=600):
 if name.startswith(('normal-','optimized-')):
  argv=[base,'-I','-S','-B',s/'supervise_runtime.py',name,*argv]
 start=time.monotonic()
 try:
  p=subprocess.run([str(x) for x in argv],cwd=cwd,env=env,capture_output=True,timeout=timeout)
  code=p.returncode;stdout=p.stdout;stderr=p.stderr
 except subprocess.TimeoutExpired as exc:code=124;stdout=exc.stdout or b'';stderr=exc.stderr or b''
 log=s/'command-logs'/name;log.with_suffix('.stdout').write_bytes(stdout);log.with_suffix('.stderr').write_bytes(stderr)
 row={'name':name,'argv':[str(x) for x in argv],'cwd':str(cwd),'exit':code,'seconds':time.monotonic()-start,'stdout_path':str(log.with_suffix('.stdout')),'stderr_path':str(log.with_suffix('.stderr')),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest()}
 with (s/'command-ledger.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
 return code
if __name__=='__main__':
 phase=sys.argv[1]
 if phase=='baseline':
  for mode in ('normal','optimized'):
   execute('minimal-'+mode,[base,'-I','-S','-B',*(['-O'] if mode=='optimized' else []),s/'frozen/harness/bootstrap.py','selftest','--harness-manifest',s/'frozen/manifest.json','--harness-manifest-sha256','49cd2cdedcf2c2999505d623f0e92010cc6b7edc9997ad39c0bfd67ebac7ccfc','--scratch',s/('selftest-'+mode)])
  execute('ruff-check',[s/'validation-tools/ruff','check','--no-cache','--config',s/'validation-tools/pyproject.toml',s/'static-source/tests/readiness/ingest'],cwd=s/'static-source')
  execute('ruff-format',[s/'validation-tools/ruff','format','--check','--no-cache','--config',s/'validation-tools/pyproject.toml',s/'static-source/tests/readiness/ingest'],cwd=s/'static-source')
  for name,args in [('board',['scripts/friday-dev-board.py','validate']),('dashboard',['scripts/friday-dev-board.py','render','--check']),('docs',['scripts/check-documentation-lifecycle.py']),('metadata',['scripts/check-package-metadata.py'])]:
   execute(name,['uv','run','--offline','--frozen','--no-sync','--no-python-downloads','python','-B',*args],cwd='/Users/chuckrussell/Dev/gendev/agent-framework')
  for name,args in [('owned-whitespace',['diff','--check','--','.gitignore','docs/planning','tests/readiness/ingest']),('range-whitespace',['diff','--check','11e8fccc23981b5449a51f2ef3f7d3ea565a062c..4fd5f8252cd5d89924e0e01527dadca3ea1ee3b3','--','.gitignore','docs/planning','tests/readiness/ingest']),('index-whitespace',['diff','--cached','--check'])]:
   execute(name,['git','-c','core.fsmonitor=false',*args],cwd='/Users/chuckrussell/Dev/gendev/agent-framework')
 elif phase=='runtime':
  for mode in ('normal','optimized'):
   flags=[base,'-I','-S','-B']+(['-O'] if mode=='optimized' else [])
   cases=['pdf-native.pdf','pdf-pages.pdf','pdf-scanned.pdf','docx-body.docx','docx-merged.docx','xlsx-formula-valid.xlsx','xlsx-formula-missing.xlsx','xlsx-hidden-row.xlsx','pptx-notes.pptx','pptx-comments.pptx','corrupt.pdf','corrupt.docx']
   for case in cases:
    execute(mode+'-'+case,[*flags,runner,'convert','--run-root',run,'--case',case,'--include-furniture','--enforce-admission'])
   execute(mode+'-probe',[*flags,runner,'probe','--run-root',run])
   execute(mode+'-isolation',[*flags,runner,'check-isolation','--run-root',run])
   execute(mode+'-chunks',[*flags,runner,'chunks','--run-root',run,'--chunk-tokens','64','128','512','1024'])
   execute(mode+'-report',[*flags,runner,'report','--run-root',run])
   dest=s/('runtime-'+mode);dest.mkdir();subprocess.run(['/bin/cp','-cR',str(run/'reports')+'/.',str(dest)],check=True)
