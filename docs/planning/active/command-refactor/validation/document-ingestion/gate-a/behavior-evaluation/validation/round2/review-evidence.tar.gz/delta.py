import hashlib,importlib.util,json,os,pathlib,signal,subprocess,sys,time
P=pathlib.Path;OWN=P('/private/tmp/docling-corrected-review-cFoB1YcS');PYTHON='/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13';mode='optimized' if sys.flags.optimize else 'normal';root=OWN/'.friday_test/runs'/('docling-behavior-review-delta-'+mode);runner=root/'source/ingest/behavior.py'
spec=importlib.util.spec_from_file_location('review_behavior',runner);b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
flags=['-I','-S','-B']+(['-O'] if sys.flags.optimize else [])
def must(c,m):
 if not c:raise RuntimeError(m)
def argv(operation,case=None):
 a=[PYTHON,*flags,str(runner),operation,'--run-root',str(root)]
 if case:a+=['--case',case,'--include-furniture','--enforce-admission']
 return a
if len(sys.argv)>1 and sys.argv[1]=='--parent-death':
 original=P.open
 def interrupt_receipt(self,*a,**kw):
  if self.name.endswith('.supervision.json') and a and a[0]=='x':os._exit(17)
  return original(self,*a,**kw)
 P.open=interrupt_receipt
 b.supervise(root,'owned-parent-death',argv('convert','pdf-native.pdf'),300)
 raise RuntimeError('Parent death witness failed')
ledger=[];checks=[];logdir=OWN/('delta-logs-'+mode);logdir.mkdir()
def command(name,a,expected):
 start=time.monotonic()
 with (logdir/(name+'.stdout')).open('xb') as out,(logdir/(name+'.stderr')).open('xb') as err:
  child=subprocess.Popen(a,cwd=root,env=b.environment(root),stdout=out,stderr=err,start_new_session=True)
  try:code=child.wait(timeout=330)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGTERM);child.wait();raise
 r={'name':name,'argv':a,'cwd':str(root),'exit':code,'seconds':time.monotonic()-start,'expected':expected};ledger.append(r);(OWN/('delta-ledger-'+mode+'.json')).write_text(json.dumps(ledger,indent=2)+'\n');must(code==expected,name+' unexpected exit '+str(code));print(name,code,flush=True);return r
def raw(name):return (root/'reports/admitted/documents'/(name+'.json')).read_bytes()
def admitted(name):return b.admitted_document(root,name,raw(name))
def refusal(name,label):
 try:admitted(name)
 except (OSError,ValueError,KeyError,TypeError,StopIteration) as exc:checks.append({'check':label,'refused':True,'error':type(exc).__name__+': '+str(exc)});return
 raise RuntimeError(label+' improperly admitted')
def positive(name,label):
 r=admitted(name);checks.append({'check':label,'eligible':True,'attempt':r['attempt']['attempt_id']});return r
command('seed-direct',argv('convert','pdf-native.pdf'),0);command('sibling-direct',argv('convert','pdf-pages.pdf'),0)
seed=positive('pdf-native.pdf','genuine direct seed');positive('pdf-pages.pdf','genuine sibling')
command('seed-default512-chunks',argv('chunks'),0);command('seed-report',argv('report'),0)
# Actual own input/settings/runner mutations, each followed by semantic refusal.
inp=root/'inputs/generated/pdf-native.pdf';saved=inp.read_bytes();inp.chmod(0o644);inp.write_bytes(saved+b'\n% own changed input\n');refusal('pdf-native.pdf','changed input');positive('pdf-pages.pdf','sibling after input change');inp.write_bytes(saved)
oracles=root/'config/oracles.json';saved=oracles.read_bytes();d=json.loads(saved);next(r for r in d['cases'] if r['file']=='pdf-native.pdf')['contains'].append('OWN CHANGED SETTING');oracles.write_text(json.dumps(d));refusal('pdf-native.pdf','changed oracle/settings');oracles.write_bytes(saved)
saved=runner.read_bytes();runner.write_bytes(saved+b'\n# own identity-only semantic negative\n');refusal('pdf-native.pdf','changed runner bytes');runner.write_bytes(saved);positive('pdf-native.pdf','restored genuine identities')
old_result=(root/'reports/admitted/pdf-native.pdf.result.json').read_bytes();old_chunk=(root/'reports/chunking.json').read_bytes()
start=time.monotonic();code=b.supervise(root,'owned-timeout-before-completion',argv('convert','pdf-native.pdf'),1);ledger.append({'name':'candidate-supervisor-timeout','argv':argv('convert','pdf-native.pdf'),'seconds_limit':1,'exit':code,'seconds':time.monotonic()-start});must(code==124,'expected actual supervisor timeout');must((root/'reports/admitted/pdf-native.pdf.result.json').read_bytes()==old_result,'timeout unexpectedly replaced old result');refusal('pdf-native.pdf','actual timeout supersedes old genuine success');positive('pdf-pages.pdf','sibling after timeout')
command('stale-report',argv('report'),1)
command('sibling-only-chunks',argv('chunks'),0);data=json.loads((root/'reports/chunking.json').read_bytes());must(data['actual_document_sources']==['pdf-pages.pdf.json'],'stale document leaked');must(any(r['file']=='pdf-native.pdf.json' for r in data['skipped']),'stale skip missing');checks.append({'check':'stale excluded with sibling','sources':data['actual_document_sources'],'skipped':data['skipped']})
sibling=root/'reports/admitted/documents/pdf-pages.pdf.json';held=root/'reports/sibling-held.json';sibling.rename(held)
command('only-stale-chunks',argv('chunks'),1);data=json.loads((root/'reports/chunking.json').read_bytes());must(data['actual_document_sources']==[] and data['results']==[],'generic payloads earned stale success');checks.append({'check':'only stale refused before generic payloads','report':data});command('only-stale-report',argv('report'),1);held.rename(sibling)
command('fresh-retry-direct',argv('convert','pdf-native.pdf'),0);retry=positive('pdf-native.pdf','fresh direct retry restored');must(retry['attempt']['attempt_id']!=seed['attempt']['attempt_id'],'attempt reused');command('retry-chunks',argv('chunks'),0);command('retry-report',argv('report'),0)
# Never-started supervisor: invalidate first, then fail Popen without a child.
original=b.subprocess.Popen
def absent(*a,**k):raise FileNotFoundError('owned never-started semantic control')
b.subprocess.Popen=absent
try:
 try:b.supervise(root,'owned-never-started',argv('convert','pdf-native.pdf'),1)
 except FileNotFoundError:checks.append({'check':'never-started Popen witness','expected_exception':True})
 else:raise RuntimeError('Never started control did not execute')
finally:b.subprocess.Popen=original
refusal('pdf-native.pdf','never-started supersedes success');positive('pdf-pages.pdf','sibling after never started')
command('parent-dies-after-worker-success',[PYTHON,*flags,str(OWN/'delta.py'),'--parent-death'],17)
current=json.loads((root/'reports/admitted/pdf-native.pdf.result.json').read_bytes());attempt=current['attempt'];must(current['native_docling_called'] and current['conversion_status']=='success' and attempt['supervised'] is True,'parent-death child lacks actual success');aroot=root/'reports/admitted/attempts';receipt=aroot/(attempt['attempt_id']+'.supervision.json');must(not receipt.exists(),'dead parent wrote receipt');refusal('pdf-native.pdf','successful worker missing parent receipt');positive('pdf-pages.pdf','sibling after parent death')
# Changing just the immutable supervision bit cannot relabel that worker as direct.
path=aroot/(attempt['attempt_id']+'.json');saved=path.read_bytes();bad=json.loads(saved);bad['supervised']=False;path.write_text(json.dumps(bad));refusal('pdf-native.pdf','supervised flag cannot bypass absent receipt');path.write_bytes(saved)
for index,(exit_code,reason) in enumerate([(-15,'time_limit'),(0,'time_limit'),(17,None)]):
 receipt.write_text(json.dumps({'attempt_id':attempt['attempt_id'],'exit':exit_code,'reason':reason}));refusal('pdf-native.pdf','abnormal parent receipt '+str(index))
command('final-fresh-direct',argv('convert','pdf-native.pdf'),0);positive('pdf-native.pdf','final direct success restored');command('final-default512-chunks',argv('chunks'),0);command('final-report',argv('report'),0)
(OWN/('delta-ledger-'+mode+'.json')).write_text(json.dumps(ledger,indent=2)+'\n');(OWN/('delta-proof-'+mode+'.json')).write_text(json.dumps({'mode':mode,'checks':checks,'passed':True,'runner_sha256':hashlib.sha256(runner.read_bytes()).hexdigest()},indent=2)+'\n');print('DELTA PASS',mode,flush=True)
