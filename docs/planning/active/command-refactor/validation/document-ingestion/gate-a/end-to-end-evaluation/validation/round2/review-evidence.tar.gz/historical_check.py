from pathlib import Path
import hashlib,json,os,subprocess,unicodedata,zipfile
s=Path(__file__).parent;a=s/'actual-archive/run';repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');req=json.loads((s/'request.json').read_bytes());env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,env=env)
result={'harness':{},'wheel_payloads':[],'modes':[],'conversion_oracles':[]}
for name in ['e2e.py','behavior.py']:
 raw=(a/'source/ingest'/name).read_bytes()
 if raw!=git('show',req['actual_live_source']+':tests/readiness/ingest/'+name):raise RuntimeError('historical source')
 result['harness'][name]=sha(raw)
for wheel in (a/'wheels').glob('*.whl'):
 key=wheel.name.split('_')[2].split('-')[0];package='friday-'+key;count=0
 with zipfile.ZipFile(wheel) as archive:
  for name in archive.namelist():
   if '.dist-info/' in name or name.endswith('/'):continue
   raw=archive.read(name);path='packages/'+package+'/src/'+name
   if raw!=git('show','96f752d64ead1c98bd900891aaa94edfe4ebe5d3:'+path) or raw!=git('show',req['candidate']+':'+path) or raw!=(Path(req['run_root'])/'target'/name).read_bytes():raise RuntimeError('wheel origin')
   count+=1
 result['wheel_payloads'].append({'wheel':wheel.name,'committed_current_installed_equal_members':count})
oracles={x['file']:x for x in json.loads((a/'config/oracles.json').read_bytes())['cases']};fingerprint=json.loads((a/'config/loaded-model-status.json').read_bytes())['all_loaded_instances_digest']
for mode in ['normal','optimized']:
 folder=a/'reports/e2e';pointer=json.loads((folder/(mode+'.latest.json')).read_bytes());rid=pointer['run_id']
 def read(kind):return json.loads((folder/(rid+'.'+kind+'.json')).read_bytes())
 outcome=read('result');corpus=read('corpus');stored=read('stored');http=read('http');reopened=read('reopened')
 if pointer['source_sha256']!=result['harness']['e2e.py'] or outcome['source_sha256']!=pointer['source_sha256']:raise RuntimeError('live source binding')
 for name,digest in outcome['evidence'].items():
  if sha((folder/(rid+'.'+name+'.json')).read_bytes())!=digest:raise RuntimeError('artifact hash')
 if stored['corpus_sha256']!=sha((folder/(rid+'.corpus.json')).read_bytes()):raise RuntimeError('corpus binding')
 rows=corpus['entries'];byid={x['id']:x for x in rows}
 if byid!={x['id']:x for c in stored['collections'] for x in c['rows']}:raise RuntimeError('stored row mapping')
 if any(not x['text'].strip() or sha(x['text'].encode())!=x['text_sha256'] or x['source'] in ['corrupt.pdf.json','xlsx-formula-missing.xlsx.json'] for x in rows):raise RuntimeError('corpus content')
 expected_posts=[]
 for c in stored['collections']:
  documents=['search_document: '+x['text'] for x in c['rows']];expected_posts.extend([documents[n:n+32] for n in range(0,len(documents),32)]);expected_posts.extend([['search_query: '+q['query']] for q in c['queries']])
 posts=[x for x in http if x['method']=='POST'];gets=[x for x in http if x['method']=='GET']
 if len(http)!=27 or len(posts)!=9 or len(gets)!=18:raise RuntimeError('transport counts')
 for post,values in zip(posts,expected_posts,strict=True):
  n=http.index(post)
  if post['input_sha256']!=[sha(x.encode()) for x in values] or post['inputs']!=len(values) or post['dimensions']!=768 or post['status']!=200 or http[n-1]['method']!='GET' or http[n+1]['method']!='GET':raise RuntimeError('transport body or bracketing')
 if any(x['state']!={'model':'text-embedding-nomic-embed-text-v1.5','context':2048,'loaded_digest':fingerprint} or x['status']!=200 for x in gets):raise RuntimeError('model-state')
 expected_numbers=list(range(4,31)) if mode=='normal' else list(range(31,58))
 if [x['request'] for x in http]!=expected_numbers or any(x['exit']!=0 for x in outcome['commands']):raise RuntimeError('budget sequence or failed command')
 for name,attempt in corpus['conversion_attempts'].items():
  f=a/'reports/admitted/attempts';ident=attempt['attempt_id'];record=json.loads((f/(ident+'.json')).read_bytes());conversion=json.loads((f/(ident+'.result.json')).read_bytes());doc=(f/(ident+'.result.document.json')).read_bytes();source=(a/'inputs/generated'/attempt['file']).read_bytes()
  if record!=attempt or conversion['attempt']!=attempt or sha(source)!=attempt['source_sha256'] or attempt['runner_sha256']!=result['harness']['behavior.py'] or sha(doc)!=conversion['output_json_sha256'] or not conversion['native_docling_called'] or conversion['conversion_status']!='success' or conversion['status']!='pass':raise RuntimeError('conversion binding')
  expected=oracles[attempt['file']]
  for budget in [512]+([128] if name=='docx-long.docx.json' else []):
   text=' '.join(unicodedata.normalize('NFC',' '.join(x['text'] for x in rows if x['source']==name and x['budget']==budget)).split())
   if any(x not in text for x in expected['contains']) or any(x in text for x in expected['excludes']):raise RuntimeError('literal oracle')
  result['conversion_oracles'].append({'mode':mode,'source':name,'attempt_id':ident,'immutable_source_output_and_literals_verified':True})
 result['modes'].append({'mode':mode,'run_id':rid,'rows':len(rows),'POSTs':len(posts),'GETs':len(gets),'vectors':sum(x['inputs'] for x in posts),'local_prepared_tokens':sum(x['local_tokens'] for x in posts),'saved_reopen':reopened,'actual_execution_attribution':'c977 historical inspected receipts; no new inference'})
(s/'historical-reproduction.json').write_text(json.dumps(result,indent=2));print('PASS: 149 wheel payloads,10 genuine immutable conversion/oracle bindings,54 transport records and every prepared POST input hash')
