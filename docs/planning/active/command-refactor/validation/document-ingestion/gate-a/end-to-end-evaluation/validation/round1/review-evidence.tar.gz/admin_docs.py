import os, pathlib, runpy, subprocess
ROOT=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
original=subprocess.run

def controlled(args,*pos,**kw):
 if args==['uv','run','python','scripts/friday-dev-board.py','validate']:
  args=['uv','run','--offline','--frozen','--no-sync','--no-python-downloads','python','-B','scripts/friday-dev-board.py','validate']
 return original(args,*pos,**kw)
subprocess.run=controlled
runpy.run_path(str(ROOT/'scripts/check-documentation-lifecycle.py'),run_name='__main__')
