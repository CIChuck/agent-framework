import os,json,pathlib,subprocess,hashlib
s=pathlib.Path(__file__).parent;req=json.loads((s/'request.json').read_text());b=json.loads((s/'boundary-reference.json').read_text());repo=pathlib.Path(b['repo']);env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def git(*a):return subprocess.check_output(['git',*a],cwd=repo,env=env)
idx=git('ls-files','-s','-z');(s/'closing-index.bin').write_bytes(idx)
o={'logical_before_status':hashlib.sha256(idx).hexdigest(),'status':git('status','--porcelain').decode(),'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'tracked_sha256':{},'symlinks':{},'preserved':{},'pins':{}}
for p,h in b['tracked_sha256'].items():o['tracked_sha256'][p]=hashlib.sha256((repo/p).read_bytes()).hexdigest()
for p in b['symlinks']:o['symlinks'][p]=os.readlink(repo/p)
for p,item in b['preserved'].items():
 st=(repo/p).lstat();val={k:getattr(st,'st_'+k) for k in ['mode','size','mtime_ns','ctime_ns','birthtime']}
 if 'sha256' in item:val['sha256']=hashlib.sha256((repo/p).read_bytes()).hexdigest()
 o['preserved'][p]=val
for p,h in req['inputs'].items():o['pins'][p]=hashlib.sha256(pathlib.Path(repo/p if not pathlib.Path(p).is_absolute() else p).read_bytes()).hexdigest()
o['frozen_manifest']=hashlib.sha256(pathlib.Path(req['frozen_manifest']).read_bytes()).hexdigest()
(s/'closing.json').write_text(json.dumps(o,indent=2));opening=json.loads((s/'opening.json').read_text());result={'frozen_boundary_equal':{k:o[k]==b[k] for k in ['logical_before_status','status','head','branch','tracked_sha256','symlinks','preserved']},'opening_equal':o==opening,'pins_equal':all(o['pins'][p]==h for p,h in req['inputs'].items()),'frozen_manifest_equal':o['frozen_manifest']==req['frozen_manifest_sha256'],'tracked_count':len(o['tracked_sha256']),'symlink_count':len(o['symlinks']),'preserved_count':len(o['preserved']),'pins_count':len(o['pins']),'logical_index':o['logical_before_status'],'head':o['head'],'branch':o['branch'],'status':o['status']}
(s/'closing-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if not all(result['frozen_boundary_equal'].values()) or not result['opening_equal'] or not result['pins_equal'] or not result['frozen_manifest_equal']:raise RuntimeError('Frozen review boundary changed')
