import ast,hashlib,importlib,json,os,subprocess,sys
from pathlib import Path
scratch=Path(__file__).parent
repo=Path("/Users/chuckrussell/Dev/gendev/agent-framework")
base="/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13"
ruff="/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n/validation-tools/ruff"
config="/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n/validation-tools/pyproject.toml"
env={"PATH":"/usr/bin:/bin","LANG":"en_US.UTF-8","GIT_OPTIONAL_LOCKS":"0","PYTHONDONTWRITEBYTECODE":"1"}
ledger=[]
def command(label,argv,cwd=repo):
    result=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,text=True,timeout=60)
    stdout=scratch/(label+".stdout");stderr=scratch/(label+".stderr")
    stdout.write_text(result.stdout);stderr.write_text(result.stderr)
    row={"label":label,"argv":argv,"cwd":str(cwd),"exit":result.returncode,"stdout":str(stdout),"stderr":str(stderr)}
    ledger.append(row)
    return result
for mode,flags in [("normal",[]),("optimized",["-O"])]:
    result=command("focused-"+mode,[base,"-I","-S","-B",*flags,str(scratch/"focused-tests.py"),str(scratch/(mode+"-final"))])
    if result.returncode: raise RuntimeError(result.stderr)
for name,verbs in [("ruff-check",["check"]),("ruff-format",["format","--check"])]:
    result=command(name,[ruff,*verbs,"--no-cache","--config",config,"tests/readiness/ingest/e2e.py","tests/readiness/ingest/tests/test_e2e.py"])
    if result.returncode: raise RuntimeError(result.stdout+result.stderr)
sys.path.insert(0,str(repo/"tests/readiness"))
package=importlib.import_module("ingest.tests")
package.SCRATCH=scratch/"canonical-cli-fixtures";package.SCRATCH.mkdir()
fixtures=importlib.import_module("ingest.tests.test_e2e")
e2e=importlib.import_module("ingest.e2e")
for mode,flags in [("normal",[]),("optimized",["-O"])]:
    root=fixtures.report_fixture();script=root/"source/ingest/e2e.py"
    argv=[base,"-I","-S","-B",*flags,str(script),"report","--run-root",str(root)]
    result=command("canonical-positive-"+mode,argv,root)
    if result.returncode or json.loads(result.stdout)["status"]!="PASS": raise RuntimeError("positive failed")
    corpus_path=root/"reports/e2e"/("a"*32+".corpus.json")
    corpus=e2e.read(corpus_path);missing=dict(corpus);del missing["conversion_attempts"]
    fixtures.replace_report_corpus(root,missing)
    result=command("canonical-missing-binding-"+mode,argv,root)
    if result.returncode==0 or "Report conversion source binding missing" not in result.stderr or result.stdout: raise RuntimeError("missing binding control failed")
    mismatch={**corpus,"conversion_attempts":{"fixture":{"runner_sha256":"0"*64}}}
    fixtures.replace_report_corpus(root,mismatch)
    result=command("canonical-mismatched-binding-"+mode,argv,root)
    if result.returncode==0 or "Report conversion source changed" not in result.stderr or result.stdout: raise RuntimeError("mismatch control failed")
    fixtures.replace_report_corpus(root,corpus)
    behavior=script.with_name("behavior.py");original=behavior.read_bytes()
    behavior.write_bytes(original+b"\nraise RuntimeError('synthetic source tamper')\n")
    result=command("canonical-changed-behavior-"+mode,argv,root)
    if result.returncode==0 or "Report conversion source changed" not in result.stderr or result.stdout: raise RuntimeError("source tamper control failed")
    behavior.write_bytes(original)
    script.write_bytes(script.read_bytes()+b"\n# synthetic e2e tamper\n")
    result=command("canonical-changed-e2e-"+mode,argv,root)
    if result.returncode==0 or "Report runner changed" not in result.stderr or result.stdout: raise RuntimeError("e2e tamper control failed")
def functions(raw):
    return {node.name:ast.dump(node,include_attributes=False) for node in ast.parse(raw).body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
source="tests/readiness/ingest/e2e.py"
old=subprocess.check_output(["git","show","c97777366671006f56866aa92898aaffcec524d6:"+source],cwd=repo,env=env)
current=(repo/source).read_bytes();old_funcs=functions(old);new_funcs=functions(current)
changed=[name for name in old_funcs if old_funcs[name]!=new_funcs.get(name)]
added=sorted(set(new_funcs)-set(old_funcs))
if changed!=["report"] or added!=["report_conversion_source"]: raise RuntimeError(str((changed,added)))
behavior_source="tests/readiness/ingest/behavior.py"
old_behavior=subprocess.check_output(["git","show","c97777366671006f56866aa92898aaffcec524d6:"+behavior_source],cwd=repo,env=env)
if old_behavior!=(repo/behavior_source).read_bytes(): raise RuntimeError("behavior source changed")
ast_record={"baseline":"c97777366671006f56866aa92898aaffcec524d6","unchanged_e2e_definitions":sorted(set(old_funcs)-set(changed)),"unchanged_definition_count":len(old_funcs)-len(changed),"changed_definitions":changed,"added_definitions":added,"behavior_byte_equal":True,"behavior_sha256":hashlib.sha256(old_behavior).hexdigest()}
(scratch/"ast-scope.json").write_text(json.dumps(ast_record,indent=2)+"\n")
opening=json.loads((scratch/"opening.json").read_text());closing={"hashes":{p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in opening["hashes"]}}
closing["index_sha256"]=hashlib.sha256(subprocess.check_output(["git","ls-files","-s","-z"],cwd=repo,env=env)).hexdigest()
closing["index_unchanged"]=opening["index_sha256"]==closing["index_sha256"]
closing["protected_unchanged"]={p:opening["hashes"][p]==closing["hashes"][p] for p in opening["hashes"] if p.startswith("packages/") or p.endswith("behavior.py")}
(scratch/"closing.json").write_text(json.dumps(closing,indent=2)+"\n")
(scratch/"command-ledger.json").write_text(json.dumps(ledger,indent=2)+"\n")
summary={"status":"PASS","focused_tests_per_lane":11,"canonical_cli_cases_per_lane":5,"live_execution":False,"scratch":str(scratch),"ast":ast_record,"preservation":closing}
(scratch/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary))
