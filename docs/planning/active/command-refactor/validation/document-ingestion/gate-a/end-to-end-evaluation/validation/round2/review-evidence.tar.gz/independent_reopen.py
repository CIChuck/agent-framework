import asyncio, pathlib, os, sys, json, hashlib, mimetypes, math
s=pathlib.Path(__file__).parent
archive=s/'actual-archive/run'
target=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/docling-behavior-e2e-20261112/target')
stdlib=pathlib.Path(sys.base_prefix)
mode=sys.argv[1];rid={'normal':'b30fc98907624550ae98706e847de03d','optimized':'287706eaf2ab44469dccc2eb2961a511'}[mode]
# All native persistence paths belong to this extracted copy, never the supplied store.
store=archive/'stores'/rid
logs=[];network=[]
for x in ['reopen-cache-'+mode,'reopen-tmp-'+mode]:(s/x).mkdir(exist_ok=True)
os.environ.clear();os.environ.update(HOME='/Users/chuckrussell',PATH='/usr/bin:/bin',LANG='en_US.UTF-8',XDG_CACHE_HOME=str(s/('reopen-cache-'+mode)),TMPDIR=str(s/('reopen-tmp-'+mode)),ANONYMIZED_TELEMETRY='False',OTEL_SDK_DISABLED='true',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
mimetypes.knownfiles=[];mimetypes.init(files=[])
def allowed(p,writing):
 roots=[s] if writing else [s,target,stdlib,pathlib.Path('/System/Library/CoreServices/SystemVersion.plist')]
 return any(p==r or r in p.parents for r in roots) or str(p)=='/dev/null'
def pth(x):return pathlib.Path(os.path.abspath(os.fsdecode(x)))
def audit(event,args):
 if event in ['socket.connect','socket.getaddrinfo','socket.sendto','subprocess.Popen','os.system','os.posix_spawn','os.exec']:
  network.append({'event':event,'prevented':True});raise PermissionError('Independent network/child guard')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=pth(args[0]);mode,flags=args[1:3];writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)))
  if not allowed(p,writing):logs.append({'event':event,'path':str(p),'write':writing,'prevented':True});raise PermissionError('Independent outside-file guard')
 if event in ['os.mkdir','os.remove','os.rmdir','os.chmod','os.utime','os.truncate','os.rename','os.link','os.symlink']:
  for item in args[:2] if event in ['os.rename','os.link','os.symlink'] else args[:1]:
   if isinstance(item,(str,bytes,os.PathLike)) and not allowed(pth(item),True):logs.append({'event':event,'path':str(pth(item)),'write':True,'prevented':True});raise PermissionError('Independent outside-mutation guard')
sys.addaudithook(audit)
# Block actual home-cache metadata before Chroma's best-effort user-id branch.
orig_stat=os.stat;orig_lstat=os.lstat
homecache=pathlib.Path('/Users/chuckrussell/.cache')
def protected_stat(fn):
 def wrapper(path,*args,**kwargs):
  if isinstance(path,(str,bytes,os.PathLike)):
   p=pth(path)
   if p==homecache or homecache in p.parents:logs.append({'event':'stat','path':str(p),'prevented':True});raise PermissionError('Independent home-cache metadata guard')
  return fn(path,*args,**kwargs)
 return wrapper
os.stat=protected_stat(orig_stat);os.lstat=protected_stat(orig_lstat)
sys.path.insert(0,str(target))
from friday_memory.adapters.vector import ChromaVectorStore
from tokenizers import Tokenizer
tokenizer=Tokenizer.from_file(str(s/'tokenizer.json'))
class NoEmbedding:
 async def embed_documents(self,values):raise RuntimeError('Independent reopen forbids embedding')
 async def embed_query(self,value):raise RuntimeError('Independent reopen forbids embedding')
async def run():
 data=json.loads((archive/'reports/e2e'/(rid+'.stored.json')).read_bytes());checked=0;count=0;details=[]
 for col in data['collections']:
  adapter=ChromaVectorStore(collection_name=col['name'],embedding_function=NoEmbedding(),persist_directory=str(store))
  if adapter._client.get_settings().anonymized_telemetry is not False:raise RuntimeError('telemetry setting')
  vectors=adapter._collection.get(include=['embeddings'])['embeddings']
  if vectors is None or any(len(v)!=768 or not all(math.isfinite(float(x)) for x in v) or not any(float(x)!=0 for x in v) for v in vectors):raise RuntimeError('persisted vectors')
  rows=await adapter.get_all(limit=None);expected={r['id']:r for r in col['rows']}
  if len(rows)!=len(expected):raise RuntimeError('row count')
  for row in rows:
   exp=expected[row['id']];meta=row['metadata']
   if row['text']!=exp['text'] or hashlib.sha256(row['text'].encode()).hexdigest()!=exp['text_sha256'] or meta['content_sha256']!=exp['text_sha256'] or meta['source']!=exp['source'] or meta['chunk']!=exp['chunk'] or meta['chunk_tokens']!=col['budget'] or meta.get('protected') is not True or 'description' in meta:raise RuntimeError('text/provenance')
  token_counts=[len(tokenizer.encode('search_document: '+r['text'],add_special_tokens=True).ids) for r in col['rows']]
  if any(n>col['budget'] or n<=0 for n in token_counts):raise RuntimeError('prepared token budget')
  count+=len(rows)
  for q in col['queries']:
   hits=await adapter.query(q['query'],n_results=min(5,len(rows)),query_embedding=q['vector'])
   if [h['id'] for h in hits]!=q['ids']:raise RuntimeError('retrieval ids')
   checked+=1
  details.append({'collection':col['name'],'rows':len(rows),'queries':len(col['queries']),'prepared_token_max':max(token_counts),'finite_nonzero_vectors':len(vectors)})
 return {'status':'PASS','mode':mode,'historical_run_id':rid,'rows':count,'queries':checked,'details':details,'network_attempts':network,'prevented_outside':logs,'actual_outside_payload_accesses':0,'native_limit':'Python audit and targeted home-cache metadata guard; not OS sandbox'}
try:
 result=asyncio.run(run())
finally:
 (s/('reopen-'+mode+'-guard.json')).write_text(json.dumps({'prevented':logs,'network':network},indent=2))
(s/('reopen-'+mode+'.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result))
