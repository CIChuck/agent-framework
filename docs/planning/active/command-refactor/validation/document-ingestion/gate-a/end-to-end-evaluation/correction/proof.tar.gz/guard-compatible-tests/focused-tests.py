import importlib,json,sys,unittest
from pathlib import Path
sys.path.insert(0, "/Users/chuckrussell/Dev/gendev/agent-framework/tests/readiness")
package=importlib.import_module("ingest.tests")
scratch=Path(sys.argv[1])
scratch.mkdir()
package.SCRATCH=scratch
suite=unittest.defaultTestLoader.loadTestsFromName("ingest.tests.test_e2e")
result=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({"tests_run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"success":result.wasSuccessful(),"scope":"synthetic offline reporting controls; no live execution"}))
raise SystemExit(0 if result.wasSuccessful() else 1)
