import hashlib,json,os,pathlib,subprocess
S=pathlib.Path(__file__).resolve().parent; B=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-behavior-focus-5ns8oj8n/e2e-review-boundary.json'); b=json.loads(B.read_text())
# Compute the logical index before invoking status, as required.
index=subprocess.check_output(['git','ls-files','-s','-z']); (S/'closing-index.bin').write_bytes(index)
status=subprocess.check_output(['git','status','--porcelain=v1'],text=True)
bad=[]
for name,digest in b['tracked_sha256'].items():
 p=pathlib.Path(name)
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest: bad.append(name)
symlink_bad=[name for name,target in b['symlinks'].items() if not pathlib.Path(name).is_symlink() or os.readlink(name)!=target]
preserved_bad=[]
for name,expected in b['preserved'].items():
 p=pathlib.Path(name); st=p.lstat(); actual={'mode':st.st_mode,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'birthtime':st.st_birthtime}
 if 'sha256' in expected: actual['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 if actual!=expected: preserved_bad.append({'path':name,'actual':actual,'expected':expected})
request=json.loads((S/'request.json').read_text()); input_bad=[name for name,digest in request['inputs'].items() if hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()!=digest]
result={'tracked_count':len(b['tracked_sha256']),'tracked_mismatches':bad,'symlink_count':len(b['symlinks']),'symlink_mismatches':symlink_bad,'preserved_count':len(b['preserved']),'preserved_mismatches':preserved_bad,'input_hash_mismatches':input_bad,'logical_index_sha256':hashlib.sha256(index).hexdigest(),'index_matches':hashlib.sha256(index).hexdigest()==b['logical_before_status'],'status':status,'status_matches':status==b['status'],'head_matches':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==b['head'],'branch_matches':subprocess.check_output(['git','branch','--show-current'],text=True).strip()==b['branch'],'scratch_owner_uid':S.stat().st_uid,'scratch_physical':S==S.resolve(),'all_our_writes':str(S)}
(S/'closing-integrity.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
if bad or symlink_bad or preserved_bad or input_bad or not all(result[k] for k in ['index_matches','status_matches','head_matches','branch_matches','scratch_physical']): raise SystemExit(1)
