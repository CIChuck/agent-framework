from pathlib import Path
import json, hashlib, subprocess, sys, os, importlib.util, copy
s=Path(__file__).parent
repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
code=(repo/'tests/readiness/ingest/e2e.py').read_bytes()
behavior=(repo/'tests/readiness/ingest/behavior.py').read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
runner=sha(code); binding=sha(behavior)
CASES=['pdf-native.pdf','pdf-scanned.pdf','docx-long.docx','xlsx-values.xlsx','pptx-notes.pptx','corrupt.pdf','xlsx-formula-missing.xlsx']
def write(p,d):p.write_text(json.dumps(d))
def fixture(name):
 root=s/'report-controls'/name/'.friday_test/runs/docling-behavior-e2e-independent'
 for n in ['config','logs','reports/e2e','target','cache','tmp','assets','inputs','source/ingest']:(root/n).mkdir(parents=True)
 (root/'source/ingest/e2e.py').write_bytes(code);(root/'source/ingest/behavior.py').write_bytes(behavior)
 for mode,rid in [('normal','1'*32),('optimized','2'*32)]:
  f=root/'reports/e2e';write(f/(mode+'.latest.json'),{'run_id':rid,'source_sha256':runner});ev={}
  for kind in ['corpus','stored','reopened','http']:
   d={'kind':'synthetic reporting only'}
   if kind=='corpus':d.update(run_id=rid,e2e_sha256=runner,conversion_attempts={'one':{'runner_sha256':binding,'attempt_id':rid},'two':{'runner_sha256':binding,'attempt_id':rid}})
   p=f/(rid+'.'+kind+'.json');write(p,d);ev[kind]=sha(p.read_bytes())
  write(f/(rid+'.result.json'),{'status':'PASS','run_id':rid,'mode':mode,'source_sha256':runner,'commands':[{'operation':x,'exit':0} for x in [*CASES,'chunks','embed','reopen']],'evidence':ev})
 write(root/'reports/live-budget.json',{'requests':0,'vectors':0,'tokens':0});return root
def edit_corpus(root,fn):
 f=root/'reports/e2e';p=f/('1'*32+'.corpus.json');d=json.loads(p.read_bytes());fn(d);write(p,d);p2=f/('1'*32+'.result.json');v=json.loads(p2.read_bytes());v['evidence']['corpus']=sha(p.read_bytes());write(p2,v)
rows=[]
for lane,flags in [('normal',[]),('optimized',['-O'])]:
 for case in ['valid','advanced-pointer','missing-binding','malformed-digest','conflicting-digest','changed-behavior','missing-behavior','symlink-behavior','hardlink-behavior','parent-symlink','aliased-corpus','changed-e2e','failed-result','changed-http','missing-evidence']:
  root=fixture(lane+'-'+case);b=root/'source/ingest/behavior.py';f=root/'reports/e2e'
  if case=='advanced-pointer':
   (root/'reports/admitted').mkdir();write(root/'reports/admitted/one.attempt.json',{'attempt_id':'9'*32})
  elif case=='missing-binding':edit_corpus(root,lambda d:d.pop('conversion_attempts'))
  elif case=='malformed-digest':edit_corpus(root,lambda d:d.update(conversion_attempts={'x':{'runner_sha256':True}}))
  elif case=='conflicting-digest':edit_corpus(root,lambda d:d['conversion_attempts'].update(x={'runner_sha256':'f'*64}))
  elif case=='changed-behavior':b.write_bytes(behavior+b'\n# changed conversion source\n')
  elif case=='missing-behavior':b.unlink()
  elif case in ['symlink-behavior','hardlink-behavior']:
   other=b.with_name('physical.py');b.rename(other)
   if case=='symlink-behavior':b.symlink_to(other)
   else:os.link(other,b)
  elif case=='parent-symlink':
   folder=b.parent;other=folder.with_name('physical');folder.rename(other);folder.symlink_to(other,target_is_directory=True)
  elif case=='aliased-corpus':
   p=f/('1'*32+'.corpus.json');other=p.with_suffix('.physical');p.rename(other);os.link(other,p)
  elif case=='changed-e2e':(root/'source/ingest/e2e.py').write_bytes(code+b'\n# changed runner\n')
  elif case=='failed-result':
   p=f/('1'*32+'.result.json');v=json.loads(p.read_bytes());v['status']='FAIL';write(p,v)
  elif case=='changed-http':(f/('1'*32+'.http.json')).write_text('{}')
  elif case=='missing-evidence':(f/('1'*32+'.stored.json')).unlink()
  cmd=[sys.executable,'-I','-S','-B',*flags,str(root/'source/ingest/e2e.py'),'report','--run-root',str(root)]
  out=subprocess.run(cmd,capture_output=True,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'))
  (s/('cli-'+lane+'-'+case+'.stdout')).write_bytes(out.stdout);(s/('cli-'+lane+'-'+case+'.stderr')).write_bytes(out.stderr)
  expected=case in ['valid','advanced-pointer'];passed=(out.returncode==0 and json.loads(out.stdout)['status']=='PASS') if expected else out.returncode!=0 and out.stdout==b''
  rows.append({'name':'canonical-'+lane+'-'+case,'argv':cmd,'exit':out.returncode,'expected_pass':expected,'verified':passed,'stderr_tail':out.stderr.decode()[-400:]})
  if not passed:raise RuntimeError(rows[-1])
(s/'independent-cli.json').write_text(json.dumps(rows,indent=2))
spec=importlib.util.spec_from_file_location('e2e_independent',repo/'tests/readiness/ingest/e2e.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
def refused(name,fn):
 try:fn()
 except (ValueError,TypeError,KeyError):checks.append({'name':name,'refused':True});return
 raise RuntimeError(name+' did not refuse')
def payload():return {'model':m.MODEL,'data':[{'index':0,'embedding':[0.25]*768}]}
for name,fn in [('wrong-model',lambda d:d.update(model='other')),('boolean-index',lambda d:d['data'][0].update(index=True)),('nonfinite',lambda d:d['data'][0]['embedding'].__setitem__(3,float('nan'))),('bool-component',lambda d:d['data'][0]['embedding'].__setitem__(3,True)),('zero-vector',lambda d:d['data'][0].update(embedding=[0]*768)),('wrong-dimensions',lambda d:d['data'][0].update(embedding=[1]*767)),('count',lambda d:d.update(data=[]))]:
 d=payload();fn(d);refused(name,lambda:m.validated_vectors(d,1))
if len(m.validated_vectors(payload(),1)[0])!=768:raise RuntimeError('positive vector failure')
root=s/'independent-budget';(root/'reports').mkdir(parents=True);p=root/'reports/live-budget.json';write(p,{'requests':63,'vectors':255,'tokens':131071});m.Budget(root).charge(1,1);before=p.read_bytes();refused('budget-next-request',lambda:m.Budget(root).charge());
if p.read_bytes()!=before:raise RuntimeError('budget changed after refusal')
refused('negative-budget',lambda:m.Budget(root).charge(-1,0));refused('boolean-budget',lambda:m.Budget(root).charge(True,0))
(s/'independent-response-budget.json').write_text(json.dumps({'checks':checks,'positive_vector':True,'last_boundary_reservation':json.loads(before),'exhausted_reservation_unchanged':True},indent=2))
ledger=json.loads((s/'command-ledger.json').read_text());ledger.extend(rows);(s/'command-ledger.json').write_text(json.dumps(ledger,indent=2));print('canonical CLI:',len(rows),'verified; response/budget:',len(checks),'refusals and positive boundary verified')
