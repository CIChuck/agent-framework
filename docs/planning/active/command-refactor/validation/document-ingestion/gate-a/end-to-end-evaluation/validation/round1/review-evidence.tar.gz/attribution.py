import collections, hashlib, json, pathlib
S=pathlib.Path(__file__).resolve().parent; A=S/'archive/run'
def read(name): return json.loads((A/name).read_text())
def sha(raw): return hashlib.sha256(raw).hexdigest()
all_modes=[]; number=4; total_tokens=0; total_vectors=0
for mode in ['normal','optimized']:
 folder='reports/e2e/'; p=read(folder+mode+'.latest.json'); rid=p['run_id']; result=read(folder+rid+'.result.json'); corpus=read(folder+rid+'.corpus.json'); stored=read(folder+rid+'.stored.json'); http=read(folder+rid+'.http.json'); reopened=read(folder+rid+'.reopened.json')
 assert result['run_id']==corpus['run_id']==stored['run_id']==reopened['run_id']==rid
 for suffix,digest in result['evidence'].items(): assert sha((A/(folder+rid+'.'+suffix+'.json')).read_bytes())==digest
 assert stored['corpus_sha256']==result['evidence']['corpus']
 assert p['source_sha256']==result['source_sha256']==corpus['e2e_sha256']==stored['e2e_sha256']==sha((A/'source/ingest/e2e.py').read_bytes())
 expected={r['id']:r for r in corpus['entries']}; assert len(expected)==81
 token_map={}; document_sources=set()
 for row in expected.values():
  assert row['source'] not in {'corrupt.pdf.json','xlsx-formula-missing.xlsx.json'}
  chunks=read('reports/chunks/'+row['source']+'.document.'+str(row['budget'])+'.json')['chunks']; chunk=chunks[row['chunk']]
  assert row['text']==chunk['text'] and row['text_sha256']==sha(row['text'].encode())
  assert chunk['prepared']=='search_document: '+row['text'] and 0<chunk['tokens_with_specials']<=row['budget']
  token_map[row['id']]=chunk['tokens_with_specials']; document_sources.add(row['source'])
 post_expected=[]; collections_summary=[]
 for collection in stored['collections']:
  rows=collection['rows']; assert all(r==expected[r['id']] for r in rows)
  for i in range(0,len(rows),32):
   batch=rows[i:i+32]; post_expected.append(([sha(('search_document: '+r['text']).encode()) for r in batch],sum(token_map[r['id']] for r in batch)))
  for query in collection['queries']:
   assert any(r['text']==query['query'] and r['source']==query['source'] for r in rows)
   assert len(query['vector'])==768 and len(query['ids'])==5 and query['source_rank']==1
   # Token count differs only by equal-length Nomic task word; exact count is checked in live hook.
   post_expected.append(([sha(('search_query: '+query['query']).encode())],None))
  collections_summary.append({'budget':collection['budget'],'rows':len(rows),'sources':sorted({r['source'] for r in rows}),'queries':len(collection['queries'])})
 posts=[r for r in http if r['method']=='POST']; assert len(posts)==len(post_expected)==9
 for row,(hashes,tokens) in zip(posts,post_expected,strict=True):
  assert row['input_sha256']==hashes and row['inputs']==len(hashes) and row['dimensions']==768 and row['status']==200
  if tokens is not None: assert row['local_tokens']==tokens
 assert [r['method'] for r in http]==['GET','POST','GET']*9
 for row in http:
  assert row['request']==number and row['status']==200; number+=1
  if row['method']=='GET': assert row['state']=={'model':'text-embedding-nomic-embed-text-v1.5','context':2048,'loaded_digest':'333235a9b7afaefe3550f879c4f8bafcfbf853dcc56197f2d47becea60f6c3c8'}
  else: total_tokens+=row['local_tokens']; total_vectors+=row['inputs']
 assert reopened=={'status':'PASS','run_id':rid,'queries':5,'network_requests':0}
 assert stored['broker_calls']=={'embed_documents':4,'embed_query':5}
 # Each corpus binds immutable conversion attempts, including normal attempts superseded by optimized.
 for source,identity in corpus['conversion_attempts'].items():
  attempt=A/'reports/admitted/attempts'; aid=identity['attempt_id']; saved=json.loads((attempt/(aid+'.json')).read_text()); record=json.loads((attempt/(aid+'.result.json')).read_text()); supervision=json.loads((attempt/(aid+'.supervision.json')).read_text()); document=(attempt/(aid+'.result.document.json')).read_bytes()
  assert saved==identity and record['attempt']==identity and record['status']=='pass' and record['native_docling_called'] is True
  assert record['output_json_sha256']==sha(document)
 all_modes.append({'mode':mode,'run_id':rid,'collections':collections_summary,'transport_requests':len(http),'embedding_requests':len(posts),'vectors':sum(r['inputs'] for r in posts),'prepared_tokens':sum(r['local_tokens'] for r in posts)})
budget=read('reports/live-budget.json'); assert budget=={'requests':57,'vectors':total_vectors,'tokens':total_tokens}
assert total_vectors==172 and total_tokens==41556
refusals=[]
for source in ['corrupt.pdf','xlsx-formula-missing.xlsx']:
 row=read('reports/admitted/'+source+'.result.json'); assert row['characters']==0 if 'characters' in row else row['status']=='admission_refused'
 refusals.append({'file':source,'phase':row['phase'],'native_docling_called':row['native_docling_called'],'status':row['status'],'reason':row.get('error',row.get('conversion_status'))})
res={'status':'PASS','modes':all_modes,'shared_budget':budget,'refusals':refusals,'raw_response_bodies_retained':False,'attribution_limit':'HTTP hook records contain response hashes, checked dimensions and usage; raw response replay is unavailable. Stored vectors and saved query vectors remain independently inspectable.'}
(S/'attribution.json').write_text(json.dumps(res,indent=2)+'\n'); print(json.dumps(res,indent=2))
