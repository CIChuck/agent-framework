from pathlib import Path
import ast, hashlib, json, os, subprocess, tarfile
s=Path(__file__).parent; repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');r=json.loads((s/'request.json').read_text());env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*argv):return subprocess.check_output(['git',*argv],cwd=repo,env=env)
def definitions(raw):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
p='tests/readiness/ingest/e2e.py';old=git('show',r['actual_live_source']+':'+p);new=(repo/p).read_bytes();a,b=definitions(old),definitions(new);scope={'unchanged':sorted(n for n in a if a[n]==b.get(n)),'changed':sorted(n for n in a if n in b and a[n]!=b[n]),'added':sorted(set(b)-set(a)),'removed':sorted(set(a)-set(b)),'behavior_byte_equal':git('show',r['actual_live_source']+':tests/readiness/ingest/behavior.py')==(repo/'tests/readiness/ingest/behavior.py').read_bytes()}
if len(scope['unchanged'])!=20 or scope['changed']!=['report'] or scope['added']!=['report_conversion_source'] or scope['removed'] or not scope['behavior_byte_equal']:raise RuntimeError('scope drift')
manifest=json.loads(Path(r['frozen_manifest']).read_bytes());harness=Path(r['frozen_harness']);checked=[]
for f in manifest['files']:
 raw=(harness/f['path']).read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 if sha(raw)!=f['sha256'] or blob!=f['blob'] or raw!=(repo/'tests/readiness/ingest'/f['path']).read_bytes():raise RuntimeError('frozen member drift')
 checked.append(f['path'])
p=repo/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/end-to-end-evaluation';archives=[];store_files=[]
for archive,index in [('evidence.tar.gz','evidence-index.json'),('correction/proof.tar.gz','correction/proof-index.json')]:
 expected={x['path']:x for x in json.loads((p/index).read_bytes())['members']};seen=set()
 with tarfile.open(p/archive) as t:
  for m in t:
   n=Path(m.name)
   if m.name in seen or n.is_absolute() or '..' in n.parts or not m.isfile():raise RuntimeError('unsafe archive')
   seen.add(m.name);raw=t.extractfile(m).read()
   if sha(raw)!=expected[m.name]['sha256'] or len(raw)!=expected[m.name]['size']:raise RuntimeError('archive member drift')
   if archive=='evidence.tar.gz' and m.name.startswith('run/stores/'):
    physical=Path(r['run_root'])/Path(m.name).relative_to('run');ok=physical.read_bytes()==raw
    if not ok:raise RuntimeError('supplied original physical store drift')
    store_files.append({'path':str(physical),'sha256':sha(raw),'equals_original_archive':ok})
 if seen!=set(expected):raise RuntimeError('archive inventory drift')
 archives.append({'path':archive,'sha256':sha((p/archive).read_bytes()),'members':len(seen),'all_verified':True})
sup=Path(r['private_tools']).parent;static=sup/'static-source/tests/readiness/ingest';files=sorted(static.rglob('*.py'));typing=[]
for file in files:
 current=repo/'tests/readiness/ingest'/file.relative_to(static)
 if file.read_bytes()!=current.read_bytes():raise RuntimeError('typing source drift')
 typing.append({'path':str(current),'sha256':sha(current.read_bytes())})
if len(files)!=29 or (sup/'validation-tools/pyproject.toml').read_bytes()!=(repo/'pyproject.toml').read_bytes():raise RuntimeError('typing config drift')
result={'scope':scope,'frozen_manifest_commit':manifest['commit'],'frozen_members_equal_current':checked,'archives':archives,'original_supplied_store_files_equal_archive':store_files,'typing_receipt_source_files_equal':typing,'typing_receipt_exit':json.loads((sup/'mypy-last.json').read_text())['exit']}
(s/'static-integrity.json').write_text(json.dumps(result,indent=2));print('PASS: 20 unchanged AST definitions; '+str(len(checked))+' frozen members; 367 + 411 archive members; '+str(len(store_files))+' original physical store files unchanged; 29 typing source files')
