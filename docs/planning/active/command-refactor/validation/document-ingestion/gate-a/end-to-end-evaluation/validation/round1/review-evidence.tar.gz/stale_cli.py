import hashlib,json,os,pathlib,shutil,subprocess,sys
S=pathlib.Path(__file__).resolve().parent; mode='optimized' if sys.flags.optimize else 'normal'; root=S/('canonical-'+mode)/'.friday_test/runs/docling-behavior-e2e-review'
shutil.copytree(S/'archive/run/source',root/'source'); shutil.copytree(S/'archive/run/reports/e2e',root/'reports/e2e'); shutil.copyfile(S/'archive/run/reports/live-budget.json',root/'reports/live-budget.json')
for name in ['config','logs','target','cache','tmp','assets','inputs']: (root/name).mkdir()
argv=[sys.executable,'-I','-S','-B']+(['-O'] if sys.flags.optimize else [])+[str(root/'source/ingest/e2e.py'),'report','--run-root',str(root)]
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(root/'tmp'))
results=[]
for phase in ['positive','changed-behavior-source']:
 if phase=='changed-behavior-source':
  p=root/'source/ingest/behavior.py'; original=p.read_bytes(); p.write_bytes(original+b'\nraise RuntimeError("Independent disposable-source tamper")\n')
 result=subprocess.run(argv,cwd=root,env=env,capture_output=True,text=True)
 (S/(mode+'-cli-'+phase+'.stdout')).write_text(result.stdout); (S/(mode+'-cli-'+phase+'.stderr')).write_text(result.stderr)
 results.append({'phase':phase,'argv':argv,'exit':result.returncode,'status':json.loads(result.stdout)['status'],'behavior_sha256':hashlib.sha256((root/'source/ingest/behavior.py').read_bytes()).hexdigest()})
witness={'mode':mode,'results':results,'source_origin':'exact source copy from verified archive; e2e.py unchanged','outside_writes':False,'live_calls':False}
(S/('canonical-stale-source-'+mode+'.json')).write_text(json.dumps(witness,indent=2)+'\n'); print(json.dumps(witness,indent=2))
