import base64, contextlib, copy, fcntl, hashlib, importlib.util, io, json, pathlib, shutil, struct
S=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('review_e2e',S/'archive/run/source/ingest/e2e.py'); e=importlib.util.module_from_spec(spec); spec.loader.exec_module(e)
results=[]
def check(name, fn, refusal=False):
 try:
  value=fn()
 except (ValueError, OSError, KeyError, TypeError) as exc:
  if not refusal: raise
  results.append({'check':name,'status':'PASS','refusal':type(exc).__name__+': '+str(exc)})
 else:
  if refusal: raise RuntimeError('Accepted invalid input: '+name)
  results.append({'check':name,'status':'PASS','result':value})
v=[0.125]*768
valid={'model':e.MODEL,'data':[{'index':0,'embedding':v},{'index':1,'embedding':v}]}
check('two ordered responses accepted',lambda:len(e.validated_vectors(valid,2)))
for label,payload in [('wrong-model',dict(valid,model='other')),('missing-vector',dict(valid,data=valid['data'][:1])),('duplicate-index',dict(valid,data=[valid['data'][0]]*2)),('boolean-index',dict(valid,data=[{'index':True,'embedding':v},valid['data'][1]])),('string-vector',dict(valid,data=[{'index':0,'embedding':['0.1']*768},valid['data'][1]])),('infinity',dict(valid,data=[{'index':0,'embedding':[float('inf')]+v[1:]},valid['data'][1]])),('nan',dict(valid,data=[{'index':0,'embedding':[float('nan')]+v[1:]},valid['data'][1]])),('zero',dict(valid,data=[{'index':0,'embedding':[0.0]*768},valid['data'][1]])),('dimensions',dict(valid,data=[{'index':0,'embedding':v[:-1]},valid['data'][1]])),('invalid-base64',dict(valid,data=[{'index':0,'embedding':'!!!!'},valid['data'][1]])),('short-base64',dict(valid,data=[{'index':0,'embedding':'AA=='},valid['data'][1]]))]:
 check('transport-'+label,lambda payload=payload:e.validated_vectors(payload,2),True)
for key,initial,charge in [('requests',{'requests':64,'vectors':0,'tokens':0},(0,0)),('vectors',{'requests':0,'vectors':256,'tokens':0},(1,0)),('tokens',{'requests':0,'vectors':0,'tokens':131072},(0,1)),('negative',{'requests':-1,'vectors':0,'tokens':0},(0,0))]:
 root=S/('budget-'+key); (root/'reports').mkdir(parents=True); path=root/'reports/live-budget.json'; path.write_text(json.dumps(initial)); before=path.read_bytes(); check('budget-'+key,lambda root=root,charge=charge:e.Budget(root).charge(*charge),True)
 if before!=path.read_bytes(): raise RuntimeError('Refusal changed reservation')
root=S/'budget-positive'; (root/'reports').mkdir(parents=True); path=root/'reports/live-budget.json'; path.write_text(json.dumps({'requests':0,'vectors':0,'tokens':0})); check('budget-reserve-before-transport',lambda:e.Budget(root).charge(2,44)); check('budget-reservation-persists',lambda:e.read(path)=={'requests':1,'vectors':2,'tokens':44})
with path.with_suffix('.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); check('budget-concurrent-writer',lambda:e.Budget(root).charge(),True)
root=S/'report-controls'; shutil.copytree(S/'archive/run/reports/e2e',root/'reports/e2e'); shutil.copyfile(S/'archive/run/reports/live-budget.json',root/'reports/live-budget.json')
def report():
 with contextlib.redirect_stdout(io.StringIO()): return e.report(root)
check('report-actual-positive',report)
folder=root/'reports/e2e'; pointer=json.loads((folder/'normal.latest.json').read_text()); run_id=pointer['run_id']; receipt=folder/(run_id+'.result.json'); original=receipt.read_bytes()
for key,value in [('status','FAIL'),('commands',[]),('evidence',{}),('source_sha256','0'*64),('run_id','0'*32)]:
 data=json.loads(original); data[key]=value; receipt.write_text(json.dumps(data)); check('report-'+key,report,True); receipt.write_bytes(original)
http=folder/(run_id+'.http.json'); raw=http.read_bytes(); http.write_bytes(raw+b'\n'); check('report-modified-http',report,True); http.write_bytes(raw); http.unlink(); check('report-missing-http',report,True); http.write_bytes(raw)
old_file=e.__file__; changed=S/'changed-source.py'; changed.write_bytes(pathlib.Path(old_file).read_bytes()+b'\n'); e.__file__=str(changed); check('report-changed-runner-source',report,True); e.__file__=old_file
check('report-restored-positive',report)
(S/'independent-controls.json').write_text(json.dumps({'checks':results,'count':len(results),'fake_vectors_live_credit':False},indent=2)+'\n'); print(json.dumps({'status':'PASS','checks':len(results)}))
