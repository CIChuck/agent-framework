import asyncio, hashlib, importlib.metadata, json, math, mimetypes, os, pathlib, socket, sys
S=pathlib.Path(__file__).resolve().parent
TARGET=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework/.friday_test/runs/docling-behavior-e2e-20261112/target')
BASE=pathlib.Path(sys.base_prefix).resolve()
for p in ['reopen-cache','reopen-tmp','reopen-config']: (S/p).mkdir(exist_ok=True)
(S/'reopen-config/empty-netrc').write_bytes(b'')
env={'HOME':os.environ.get('HOME',''),'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0','LITELLM_MODE':'PRODUCTION','LITELLM_LOCAL_MODEL_COST_MAP':'True','DISABLE_AIOHTTP_TRANSPORT':'True','DISABLE_AIOHTTP_TRUST_ENV':'True','ANONYMIZED_TELEMETRY':'False','OTEL_SDK_DISABLED':'true','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','DO_NOT_TRACK':'1','OMP_NUM_THREADS':'4','MKL_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4','TOKENIZERS_PARALLELISM':'false','NETRC':str(S/'reopen-config/empty-netrc'),'TMPDIR':str(S/'reopen-tmp'),'XDG_CACHE_HOME':str(S/'reopen-cache'),'XDG_CONFIG_HOME':str(S/'reopen-config'),'MPLCONFIGDIR':str(S/'reopen-cache/mpl'),'HF_HOME':str(S/'reopen-cache/hf'),'SSL_CERT_FILE':str(TARGET/'certifi/cacert.pem'),'REQUESTS_CA_BUNDLE':str(TARGET/'certifi/cacert.pem')}
os.environ.clear(); os.environ.update(env); sys.path.insert(0,str(TARGET)); mimetypes.knownfiles=[]; mimetypes.init(files=[])
network=[]; denied=[]
def audit(event,args):
 if event in {'socket.connect','socket.getaddrinfo','socket.sendto','subprocess.Popen','os.system','os.posix_spawn','os.exec'}:
  network.append(event); raise PermissionError('Independent reopen forbids network/process effects')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=pathlib.Path(os.fsdecode(args[0])).resolve(); mode,flags=args[1:3]; writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)))
  allowed=(S,) if writing else (S,TARGET,BASE,pathlib.Path('/System/Library/CoreServices/SystemVersion.plist'),pathlib.Path('/dev/null'))
  if not any(path==p or p in path.parents for p in allowed): denied.append(str(path)); raise PermissionError('Outside reviewer read/write: '+str(path))
 if event in {'os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink'}:
  for raw in args[:2] if event in {'os.rename','os.link','os.symlink'} else args[:1]:
   if isinstance(raw,(str,bytes,os.PathLike)):
    path=pathlib.Path(os.fsdecode(raw)).resolve()
    if path!=S and S not in path.parents: denied.append(str(path)); raise PermissionError('Outside reviewer mutation')
sys.addaudithook(audit)
from friday_memory.adapters.vector import ChromaVectorStore
from tokenizers import Tokenizer
class NoEmbedding:
 async def embed_documents(self,values): raise RuntimeError('Embedding forbidden')
 async def embed_query(self,value): raise RuntimeError('Embedding forbidden')
async def main():
 modes=[]
 for mode in ['normal','optimized']:
  folder=S/'archive/run/reports/e2e'; pointer=json.loads((folder/(mode+'.latest.json')).read_text()); rid=pointer['run_id']; stored=json.loads((folder/(rid+'.stored.json')).read_text()); collections=[]
  for collection in stored['collections']:
   store=ChromaVectorStore(collection_name=collection['name'],embedding_function=NoEmbedding(),persist_directory=str(S/'archive/run/stores'/rid)); actual=await store.get_all(limit=None); expected={r['id']:r for r in collection['rows']}
   if len(actual)!=len(expected): raise RuntimeError('Row mismatch')
   for row in actual:
    expected_row=expected[row['id']]; md=row['metadata']
    if row['text']!=expected_row['text'] or md['content_sha256']!=hashlib.sha256(row['text'].encode()).hexdigest() or md['source']!=expected_row['source'] or md['chunk']!=expected_row['chunk'] or md['chunk_tokens']!=collection['budget'] or md['protected'] is not True or 'description' in md: raise RuntimeError('Text/provenance mismatch')
   vectors=store._collection.get(include=['embeddings'])['embeddings']
   if len(vectors)!=len(expected) or any(len(v)!=768 or not all(math.isfinite(float(x)) for x in v) or not any(x!=0 for x in v) for v in vectors): raise RuntimeError('Stored vector mismatch')
   queries=[]
   for query in collection['queries']:
    hits=await store.query(query['query'],n_results=min(5,len(expected)),query_embedding=query['vector'])
    if [h['id'] for h in hits]!=query['ids']: raise RuntimeError('Retrieval changed')
    queries.append({'source':query['source'],'ids_identical':True,'rank':query['source_rank']})
   collections.append({'budget':collection['budget'],'rows':len(actual),'queries':queries})
  modes.append({'mode':mode,'run_id':rid,'collections':collections})
 if network or any(p!='/Users/chuckrussell/.cache/chroma/telemetry_user_id' for p in denied): raise RuntimeError('Unexpected network/read attempts '+repr((network,denied)))
 result={'status':'PASS','modes':modes,'network_attempts_during_reopen':0,'outside_attempts_prevented':denied,'successful_outside_effects':0,'embedding_calls':0,'versions':{name:importlib.metadata.version(name) for name in ['chromadb','friday-framework-memory','certifi']},'guard':'Python-visible; native residual limits remain'}
 (S/'fresh-reopen.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result))
asyncio.run(main())
try: socket.create_connection(('127.0.0.1',1234),timeout=1)
except PermissionError: pass
else: raise RuntimeError('Network canary accepted')
(S/'network-denial-canary.json').write_text(json.dumps({'status':'PASS','refused_events':network})+'\n')
