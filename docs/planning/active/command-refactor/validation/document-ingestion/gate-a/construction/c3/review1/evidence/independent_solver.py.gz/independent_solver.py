from pathlib import Path
import hashlib,json,sys,types
S=Path(__file__).parent.resolve();Q=json.loads((S/'request.json').read_bytes());H=S/'formal/source/tests/readiness/ingest';M=S/'formal/harness-manifest.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def require(ok,m):
 if not ok:raise RuntimeError(m)
require(sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode,'Required flags')
roots=[]
for key in ['parser','engine']:
 spec=Q['tool_inputs'][key];t=S/'validation-tools'/Path(spec['root']).name;require({str(p.relative_to(t)):sha(p.read_bytes()) for p in t.rglob('*') if p.is_file()}==spec['files'],'Opening inventory');require(all(not p.is_symlink() for p in t.rglob('*')),'Symlink target');roots.append(t)
raw=(H/'bootstrap.py').read_bytes();require(sha(raw)==Q['bootstrap_sha256'],'Bootstrap pin');ns={'__name__':'review_bootstrap','__file__':str(H/'bootstrap.py')};exec(compile(raw,str(H/'bootstrap.py'),'exec',dont_inherit=True),ns);buffers=ns['verified_buffers'](H,M,Q['source_manifest_sha256']);pkg=types.ModuleType('ingest');pkg.__path__=[];pkg.__dict__.update(ROOT=H,BUFFERS=buffers);sys.modules['ingest']=pkg;sys.meta_path.insert(0,ns['Buffers'](H,buffers))
from ingest.startup import Guard,guarded
sys.path[:0]=[str(t) for t in roots]
records=[]
with guarded(Guard((S,Path(sys.base_prefix).resolve()/'lib',Path(sys.executable).resolve()),())):
 from ingest.manifests import resolve_catalog,dependency_selection,Refusal,canonical,digest
 from unittest.mock import patch
 def wheel(name,version='1',deps=(),extras=(),**kw):
  filename=name.replace('-','_')+'-'+version+'-py3-none-any.whl';return {'name':name,'version':version,'filename':filename,'url':'https://files.pythonhosted.org/reviewer/'+filename,'sha256':'b'*64,'size':100,'license':'MIT','requires_python':'>=3.10,<3.14','requires_dist':list(deps),'provides_extra':list(extras),'yanked':False}|kw
 env={'implementation_name':'cpython','implementation_version':'3.13.10','os_name':'posix','platform_machine':'arm64','platform_release':'synthetic','platform_system':'Darwin','platform_version':'synthetic','python_full_version':'3.13.10','platform_python_implementation':'CPython','python_version':'3.13','sys_platform':'darwin'}
 def cat(rows,roots=('app','bridge')):return {'schema':1,'roots':list(roots),'environment':dict(env),'tags':['py3-none-any'],'candidates':rows}
 def base():return cat([wheel('app','2',['lib>=2']),wheel('app','1',['lib>=1']),wheel('bridge',deps=['lib<2']),wheel('lib','2'),wheel('lib','1')])
 def chosen(r):return {w['name']:w['version'] for w in r['selection']['wheels']}
 def success(label,value,**kw):
  r=resolve_catalog(value,**kw)
  for f in ['artifact_bytes_verified','licenses_qualified','installed_profile_qualified','execution_permitted','actual_index_resolution']:require(r[f] is False,label+' qualification '+f)
  for f in ['artifact_bytes_verified','licenses_qualified','installed_profile_qualified','execution_permitted']:require(r['consistency'][f] is False,label+' consistency '+f)
  records.append({'label':label,'phase':'function_call','outcome':'success','chosen':chosen(r),'rounds':r['rounds'],'rejections':r['rejected_candidates']});return r
 def refuse(label,value,contains='',**kw):
  try:resolve_catalog(value,**kw)
  except Refusal as exc:
   require(contains in str(exc),label+' wrong refusal '+str(exc));records.append({'label':label,'phase':'function_call','outcome':'refusal','reason':str(exc)})
  else:raise RuntimeError(label+' accepted')
 # Malformed outer controls before any optional library import in this fresh worker.
 before=set(sys.modules)
 refuse('outer shape before optional import',{},'control fields')
 require(not any(n=='packaging' or n.startswith('packaging.') or n=='resolvelib' or n.startswith('resolvelib.') for n in set(sys.modules)-before),'Unexpected optional import')
 r=success('genuine backtracking',base());require(chosen(r)=={'app':'1','bridge':'1','lib':'1'} and r['rejected_candidates']>=1,'Backtracking witness')
 refuse('impossible graph',cat(base()['candidates'],['app==2','bridge']),'no compatible solution')
 value=cat([wheel('alpha-file',deps=['base','plus; extra == "fast"','Ghost; sys_platform == "win32"'],extras=['fast']),wheel('base',deps=['Alpha.File']),wheel('plus'),wheel('zlate',deps=['Alpha.File[fast]'])],['Alpha.File','zlate'])
 r=success('base late extra marker cycle',value);require(set(chosen(r))=={'alpha-file','base','plus','zlate'} and r['consistency']['requested_extras']['alpha-file']==['fast'],'Late extra closure')
 reversed_value=base();reversed_value['candidates'].reverse();reversed_value['roots'].reverse();require(chosen(success('deterministic reversed catalog',reversed_value))==chosen(success('deterministic repeat',base())),'Order altered choice')
 frozen=base();expected=digest(canonical(frozen));calls=0
 def mutate():
  global calls
  calls+=1
  if calls==1:frozen.update(candidates=[],roots=['mutated'])
 r=success('input snapshotted before callback',frozen,before_step=mutate);require(r['catalog_sha256']==expected and chosen(r)=={'app':'1','bridge':'1','lib':'1'} and calls>1,'Snapshot witness')
 rows=base()['candidates']+[wheel('app','3',requires_python='>=3.14'),wheel('app','4',yanked=True),wheel('app','5',size=4294967297)]
 f='app-6-cp313-cp313-win_amd64.whl';rows.append(wheel('app','6',filename=f,url='https://files.pythonhosted.org/reviewer/'+f))
 r=success('known ineligible exclusions',cat(rows));require({x['version']:x['reasons'] for x in r['excluded_candidates']}=={'3':['python'],'4':['yanked'],'5':['bytes'],'6':['platform']},'Exclusion facts')
 for label,kw in [('unknown yanked',{'yanked':'unknown'}),('malformed excluded license',{'yanked':True,'license':''}),('malformed excluded requirement',{'yanked':True,'requires_dist':['bad @ https://x.invalid/a.whl']}),('malformed excluded python',{'yanked':True,'requires_python':'???'})]:refuse(label,cat(base()['candidates']+[wheel('app','9',**kw)]))
 refuse('unknown extra',cat(base()['candidates'],['app[missing]']),'no compatible solution')
 refuse('round ceiling actual call',base(),max_rounds=1)
 refuse('invalid round parameter',base(),max_rounds=501)
 refuse('invalid time parameter',base(),timeout_seconds=0)
 refuse('candidate count limit',cat([wheel('app',str(i)) for i in range(513)],['app']),'Selection count')
 refuse('edge count limit',cat([wheel('app',str(i),['dep']*256) for i in range(33)],['app']),'Declared dependency graph limit')
 refuse('selected aggregate bytes',cat([wheel('app',deps=['lib'],size=2200000000),wheel('lib',size=2200000000)],['app']),'Selected package byte ceiling')
 for label,clocks in [('wall deadline before work',[0.0,301.0]),('deadline after callback',[0.0,0.0,301.0]),('backward clock',[2.0,1.0]),('nonfinite clock',[float('nan')])]:
  with patch('ingest.manifests.monotonic',side_effect=clocks):refuse(label,base())
 calls=0
 def stop():
  global calls
  calls+=1
  if calls==9:raise Refusal('reviewer stop witness')
 refuse('caller stop without retry',base(),'reviewer stop witness',before_step=stop);require(calls==9,'Stop retried')
 refuse('bounded JSON snapshot',cat([wheel('app',license='X'*(1024*1024))],['app']),'Control record exceeds')
 # Independent write/socket canaries ensure the worker guard is armed.
 try:(S/'forbidden-profile-write').write_text('must not exist')
 except Refusal:records.append({'label':'guard rejects all writes','phase':'function_call','outcome':'refusal'})
 else:raise RuntimeError('Profile write escaped')
 import socket
 try:socket.socket()
 except Refusal:records.append({'label':'guard rejects socket creation','phase':'function_call','outcome':'refusal'})
 else:raise RuntimeError('Network guard escaped')
 origins={n:m.__file__ for n,m in sys.modules.items() if n=='packaging' or n.startswith('packaging.') or n=='resolvelib' or n.startswith('resolvelib.')};require(all((roots[0] if n.startswith('packaging') else roots[1]) in Path(p).resolve().parents for n,p in origins.items()),'Unexpected optional origin')
 for key in ['parser','engine']:
  spec=Q['tool_inputs'][key];t=S/'validation-tools'/Path(spec['root']).name;require({str(p.relative_to(t)):sha(p.read_bytes()) for p in t.rglob('*') if p.is_file()}==spec['files'],'Closing tool inventory')
print(json.dumps({'optimized':bool(sys.flags.optimize),'checks':len(records),'positive':sum(x['outcome']=='success' for x in records),'refusals':sum(x['outcome']=='refusal' for x in records),'records':records,'origins':origins,'all_inventory_checks':True,'all_plan_qualification_flags_false':True},indent=2))
