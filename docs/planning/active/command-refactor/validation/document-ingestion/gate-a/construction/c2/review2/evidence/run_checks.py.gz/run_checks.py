from commands import *
import shutil
M=S/'candidate-manifest.json';MH=hashlib.sha256(M.read_bytes()).hexdigest();H=S/'candidate'
checks={}
for opt in [False,True]:
 mode='optimized' if opt else 'normal';flags=[PY,'-I','-S','-B',*(['-O'] if opt else [])]
 for profile in ['independent','selector']:run(profile+'-'+mode,flags+[str(S/'selection_worker.py'),'candidate',profile])
 scratch=S/('selftest-'+mode);scratch.mkdir()
 p=run('minimal-'+mode,flags+[str(H/'bootstrap.py'),'selftest','--harness-manifest',str(M),'--harness-manifest-sha256',MH,'--scratch',str(scratch),'--profile','minimal']);output=json.loads(p.stdout);assert output['cases']==56 and output['status']=='PASS'
 # Public manual flow executes only frozen committed harness in a fresh fake project.
 project=S/('manual-'+mode);project.mkdir();control=S/('control-'+mode+'.json')
 config={'schema':1,'project':str(project),'run_id':'review','harness_sha256':MH,'envelope_sha256':'4b6273c2a629affd02e388574a0b1715334456c921611e55e069122f7b0b4315','interpreter_sha256':'e2adf1814122d8b26166917ef7d294d7426963e0f59e28d0d5aef773f67c4bb0','activation':'C0'};control.write_text(json.dumps(config,sort_keys=True,separators=(',',':')));CH=hashlib.sha256(control.read_bytes()).hexdigest()
 initial=['--harness-manifest',str(M),'--harness-manifest-sha256',MH,'--config',str(control),'--config-sha256',CH]
 before={str(p.relative_to(project)) for p in project.rglob('*')};run('preflight-'+mode,flags+[str(H/'bootstrap.py'),'preflight',*initial]);assert {str(p.relative_to(project)) for p in project.rglob('*')}==before
 init=json.loads(run('init-'+mode,flags+[str(H/'bootstrap.py'),'init',*initial]).stdout);entry=project/'.friday_test/runs/review/harness/run.py';frozen=['--harness-manifest',init['harness_manifest'],'--harness-manifest-sha256',MH,'--config',init['config'],'--config-sha256',init['config_sha256']]
 prepare=json.loads(run('prepare-fixtures-'+mode,flags+[str(entry),'prepare-fixtures',*frozen]).stdout);assert prepare['fixture_count']==30 and prepare['converter_qualified'] is False and prepare['full_readiness'] is False
 fixture_manifest=Path(prepare['manifest']);fm=json.loads(fixture_manifest.read_bytes());checks[mode]={'fixture_manifest':str(fixture_manifest),'sha256':hashlib.sha256(fixture_manifest.read_bytes()).hexdigest(),'prepared':prepare}
 for stage in ['all','A0','A1','A2','A3','A4']:
  p=run('blocked-'+stage+'-'+mode,flags+[str(entry),'run','--stage',stage,*frozen],3);o=json.loads(p.stdout);assert o['effects_performed'] is False and o['full_readiness'] is False
 run('prepare-model-blocked-'+mode,flags+[str(entry),'prepare-model',*frozen],3)
 p=run('report-'+mode,flags+[str(entry),'report',*frozen],3);assert json.loads(p.stdout)['full_readiness'] is False
 run('stop-'+mode,flags+[str(entry),'stop',*frozen]);run('run-after-stop-'+mode,flags+[str(entry),'run',*frozen],2)
 p=run('report-after-stop-'+mode,flags+[str(entry),'report',*frozen],3);assert json.loads(p.stdout)['stopped'] is True
checks['modes_equal_fixture_hashes']=checks['normal']['sha256']==checks['optimized']['sha256'];assert checks['modes_equal_fixture_hashes'];(S/'manual-summary.json').write_text(json.dumps(checks,indent=2))
# Private static-source export, all rules remain exact root bytes.
static=S/'static-source/ingest';shutil.copytree(H,static);files=sorted(str(p) for p in static.rglob('*.py'));assert len(files)==25
ruff=S/'validation-tools/ruff';conf=S/'validation-tools/pyproject.toml'
run('ruff-check',[str(ruff),'check','--isolated','--config',str(conf),'--no-cache',str(static)])
run('ruff-format',[str(ruff),'format','--isolated','--config',str(conf),'--no-cache','--check',str(static)])
raw=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6/run_private_mypy.py').read_text();(S/'run_private_mypy.py').write_text(raw)
ENV['MYPYPATH']=str(S/'static-source')
run('mypy',[PY,'-I','-S','-B',str(S/'run_private_mypy.py'),str(S/'validation-tools/mypy-target'),str(H),str(M),MH,'70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c','--config-file',str(conf),'--no-site-packages','--namespace-packages','--explicit-package-bases','--cache-dir',str(S/'validation-tools/mypy-cache'),*files])
