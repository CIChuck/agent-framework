import pathlib,json,hashlib,shutil
S=pathlib.Path(__file__).parent; R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); B=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-build-sqewgfmf')
q=json.loads((B/'review-request.json').read_text()); t=q['tool_inputs']; dest=S/'validation-tools';dest.mkdir()
def verify(p,expected):
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected: raise RuntimeError('hash '+str(p))
    return raw
for key, filename in [('ruff','ruff'),('root_config','pyproject.toml'),('mypy_inventory','mypy-target-manifest.json'),('mypy_launcher','supplied-launcher-inspected.py.txt')]:
    (dest/filename).write_bytes(verify(pathlib.Path(t[key]),t[key+'_sha256']))
(dest/'ruff').chmod(0o755)
inv=json.loads((dest/'mypy-target-manifest.json').read_text()); src=pathlib.Path(t['mypy_target']); target=dest/'mypy-target'; target.mkdir()
if set(inv['files'])!={p.relative_to(src).as_posix() for p in src.rglob('*') if p.is_file()}: raise RuntimeError('tool file selection')
for rel,sha in inv['files'].items():
    p=src/rel
    if p.is_symlink(): raise RuntimeError('tool alias')
    out=target/rel;out.parent.mkdir(exist_ok=True,parents=True);out.write_bytes(verify(p,sha))
if hashlib.sha256((R/'pyproject.toml').read_bytes()).hexdigest()!=t['root_config_sha256']: raise RuntimeError('root config mismatch')
for name in ['mypy-cache','ruff-cache']: (dest/name).mkdir()
for name in ['static-tmp','home-cache','config','selftest-normal','selftest-optimized','manual-project','independent-normal','independent-optimized']: (S/name).mkdir()
# Operational launcher adapted only after inspection; builder cache paths are replaced with reviewer-owned paths.
launcher=(dest/'supplied-launcher-inspected.py.txt').read_text()
(S/'private-mypy.py').write_text(launcher)
print(json.dumps({'copied_files':len(inv['files']),'profile':inv['profile_sha256'],'static_root_config_verified':True,'source_target':str(src),'own_target':str(target)}))
