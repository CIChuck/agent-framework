import copy,unittest
from ingest.manifests import dependency_selection,Refusal

def run_independent():
 c=unittest.TestCase(); records=[]
 env={'implementation_name':'cpython','implementation_version':'3.13.10','os_name':'posix','platform_machine':'arm64','platform_release':'declared','platform_system':'Darwin','platform_version':'declared','python_full_version':'3.13.10','platform_python_implementation':'CPython','python_version':'3.13','sys_platform':'darwin'}
 def wheel(name,version='1.0',deps=None,extras=None):
  filename=name.replace('-','_')+'-'+version+'-py3-none-any.whl'
  return dict(name=name,version=version,filename=filename,url='https://files.pythonhosted.org/declared/'+filename,sha256='f'*64,size=70,license='DECLARED ONLY',requires_python='>=3.13,<3.14',requires_dist=deps or [],provides_extra=extras or [],yanked=False)
 def selection(rows,roots=None):return dict(schema=1,roots=roots or ['a'],environment=dict(env),tags=['py3-none-any'],wheels=rows)
 def test(name,fn):
  try:fn();records.append(dict(name=name,result='PASS'))
  except AssertionError as e:records.append(dict(name=name,result='FAIL',error=str(e)))
 def yes(data,count,extras=None):
  out=dependency_selection(data);c.assertEqual(out['distribution_count'],count);c.assertEqual(out['selected_bytes'],sum(x['size'] for x in data['wheels']))
  for key in ['artifact_bytes_verified','licenses_qualified','installed_profile_qualified','execution_permitted']:c.assertIs(out[key],False)
  if extras is not None:c.assertEqual(out['requested_extras'],extras)
 def no(data):
  with c.assertRaises(Refusal):dependency_selection(data)
 test('cycle closure plus additive base-extra',lambda:yes(selection([wheel('a',deps=['b>=1','c; extra == "fast"'],extras=['fast']),wheel('b',deps=['a>=1']),wheel('c')],['a[fast]']),3,{'a':['fast'],'b':[],'c':[]}))
 test('late extra on previously visited cycle',lambda:yes(selection([wheel('a',deps=['b'],extras=['fast']),wheel('b',deps=['a[fast]','c; extra == "fast"'],extras=['fast']),wheel('c')],['b[fast]','a']),3,{'a':['fast'],'b':['fast'],'c':[]}))
 test('base requirement remains with requested extra',lambda:no(selection([wheel('a',deps=['missing; extra == ""'],extras=['fast'])],['a[fast]'])))
 test('constraints from repeated reachable roots',lambda:no(selection([wheel('a')],['a>=1','a>=2'])))
 test('transitive conflicting version',lambda:no(selection([wheel('a',deps=['b<1']),wheel('b') ])))
 test('missing transitive closure',lambda:no(selection([wheel('a',deps=['b'])])))
 test('unreachable wheel closure',lambda:no(selection([wheel('a'),wheel('b')])))
 test('inactive dependency marker',lambda:yes(selection([wheel('a',deps=['not-present; sys_platform == "win32"'])]),1))
 test('canonicalized names and extras',lambda:yes(selection([wheel('alpha-beta',extras=['fast-mode'])],['Alpha.Beta[Fast_Mode]']),1,{'alpha-beta':['fast-mode']}))
 test('unknown transitive extra',lambda:no(selection([wheel('a',deps=['b[missing]']),wheel('b')])))
 test('explicit python constraint conflict',lambda:no(selection([wheel('a')|{'requires_python':'<3.13'}])))
 test('single wheel exceeds byte ceiling',lambda:no(selection([wheel('a')|{'size':4*1024**3+1}])))
 test('exact total byte ceiling remains declaration only',lambda:yes(selection([wheel('a')|{'size':4*1024**3}]),1))
 test('unknown license string earns no qualification',lambda:yes(selection([wheel('a')|{'license':'UNKNOWN UNQUALIFIED'}]),1))
 test('root direct reference refused',lambda:no(selection([wheel('a')],['a @ https://files.pythonhosted.org/a.whl'])))
 test('malformed empty ABI tag refused',lambda:no(selection([wheel('a')|{'filename':'a-1.0-py3--any.whl','url':'https://files.pythonhosted.org/a-1.0-py3--any.whl'}])|{'tags':['py3--any']}))
 test('malformed empty platform tag refused',lambda:no(selection([wheel('a')|{'filename':'a-1.0-py3-none-.whl','url':'https://files.pythonhosted.org/a-1.0-py3-none-.whl'}])|{'tags':['py3-none-']}))
 return records
