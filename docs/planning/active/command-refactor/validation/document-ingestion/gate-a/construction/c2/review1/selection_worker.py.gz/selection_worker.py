from pathlib import Path
import hashlib,json,sys,types
s=Path(__file__).parent.resolve();setup=json.loads((s/'setup.json').read_bytes());h=Path(setup['export']);m=Path(setup['manifest']);target=s/'validation-tools/parser-target'
def check(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(raw):return hashlib.sha256(raw).hexdigest()
check(sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode,'Use -I -S -B')
profile=json.loads((s/'parser_inspection.json').read_bytes());check({str(p.relative_to(target)):sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}==profile['files'],'Private tool inventory')
raw=(h/'bootstrap.py').read_bytes();check(sha(raw)=='70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c','bootstrap');ns={'__name__':'private_bootstrap','__file__':str(h/'bootstrap.py')};exec(compile(raw,str(h/'bootstrap.py'),'exec',dont_inherit=True),ns);buffers=ns['verified_buffers'](h,m,setup['manifest_sha256']);pkg=types.ModuleType('ingest');pkg.__path__=[];pkg.__dict__.update(ROOT=h,BUFFERS=buffers);sys.modules['ingest']=pkg;tests=types.ModuleType('ingest.tests');tests.__path__=[];sys.modules['ingest.tests']=tests;sys.meta_path.insert(0,ns['Buffers'](h,buffers));from ingest.startup import Guard,guarded
sys.path.insert(0,str(target));policy=Guard((s,h,target,Path(sys.base_prefix).resolve()/'lib',Path(sys.executable).resolve()),(s,))
with guarded(policy):
 from ingest.tests.test_manifests import dependency_cases
 result=dependency_cases()
 import packaging
 check(Path(packaging.__file__).resolve()==target/'packaging/__init__.py','wrong parser origin')
 custom={'__name__':'independent_selection','__file__':str(s/'independent_selection.py')};exec(compile((s/'independent_selection.py').read_bytes(),str(s/'independent_selection.py'),'exec'),custom);independent=custom['run_independent']()
result.update(optimized=bool(sys.flags.optimize),source_manifest_sha256=setup['manifest_sha256'],parser_origin=str(packaging.__file__),parser_version=packaging.__version__,independent=independent)
print(json.dumps(result))
raise SystemExit(1 if any(x['result']=='FAIL' for x in independent) else 0)
