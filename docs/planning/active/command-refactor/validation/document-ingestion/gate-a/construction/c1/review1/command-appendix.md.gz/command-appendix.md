# Exact executed validation commands

All generated outputs, configuration, temporary paths and caches are reviewer-owned. The administration lane reads the existing checkout and working interpreter under the controller clarification, without sync/install or product imports.

## selftest-normal

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/export-harness/run.py selftest --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/candidate-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --scratch /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/selftest-normal-final
```

## selftest-optimized

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/export-harness/run.py selftest --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/candidate-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --scratch /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/selftest-optimized-final
```

## ruff-check

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/validation-tools/ruff check --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/validation-tools/pyproject.toml --cache-dir /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/validation-tools/ruff-cache /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/bootstrap.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/config.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/environment.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/export.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/fixtures.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/ledger.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/manifests.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/paths.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/protection.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/reports.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/run.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/stages.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/startup.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_cli.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_environment.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_export.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_fixtures.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_ledger.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_manifests.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_paths.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_protection.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_reports.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_startup.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_window.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/window.py
```

## ruff-format

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/validation-tools/ruff format --check --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/validation-tools/pyproject.toml --cache-dir /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/validation-tools/ruff-cache /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/bootstrap.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/config.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/environment.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/export.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/fixtures.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/ledger.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/manifests.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/paths.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/protection.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/reports.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/run.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/stages.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/startup.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_cli.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_environment.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_export.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_fixtures.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_ledger.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_manifests.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_paths.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_protection.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_reports.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_startup.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_window.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/window.py
```

## mypy

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/private-mypy.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/validation-tools/mypy-target /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/candidate-manifest.json 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d 70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c --config-file /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/validation-tools/pyproject.toml --no-site-packages --explicit-package-bases --cache-dir /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/validation-tools/mypy-cache /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/bootstrap.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/config.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/environment.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/export.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/fixtures.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/ledger.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/manifests.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/paths.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/protection.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/reports.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/run.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/stages.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/startup.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_cli.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_environment.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_export.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_fixtures.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_ledger.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_manifests.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_paths.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_protection.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_reports.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_startup.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/tests/test_window.py /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/typing-source-final/ingest/window.py
```

## manual-blocked-A0

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py run --stage A0 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-blocked-A1

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py run --stage A1 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-blocked-A2

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py run --stage A2 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-blocked-A3

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py run --stage A3 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-blocked-A4

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py run --stage A4 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-blocked-all

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py run --stage all --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-blocked-model

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py prepare-model --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-init

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/export-harness/bootstrap.py init --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/candidate-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-control.json --config-sha256 50222fc4ebf3bdbbd5547718e4b82027c7da1e551ae6e1e087979774a534acf8
```

## manual-preflight

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/export-harness/bootstrap.py preflight --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/candidate-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-control.json --config-sha256 50222fc4ebf3bdbbd5547718e4b82027c7da1e551ae6e1e087979774a534acf8
```

## manual-prepare-repeat

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 2 (expected 2).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py prepare-fixtures --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-prepare

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py prepare-fixtures --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-report

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py report --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-stop

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py stop --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-stopped-prepare

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 2 (expected 2).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py prepare-fixtures --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## manual-stopped-report

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/harness/run.py report --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/manual-project-final/.friday_test/runs/independent-c1/config/control.json --config-sha256 64c51884f7f8af6a0c02548edc76237800e2149efbd39ca5cd390f8d100719fd
```

## optimized-manual-blocked-A0

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py run --stage A0 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-blocked-A1

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py run --stage A1 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-blocked-A2

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py run --stage A2 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-blocked-A3

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py run --stage A3 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-blocked-A4

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py run --stage A4 --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-blocked-all

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py run --stage all --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-blocked-model

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py prepare-model --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-init

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/export-harness/bootstrap.py init --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/candidate-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-control.json --config-sha256 6605281a973e93ecb39e39272e2837921f3bc24d80e4858689873af00504ecf6
```

## optimized-manual-preflight

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/export-harness/bootstrap.py preflight --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/candidate-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-control.json --config-sha256 6605281a973e93ecb39e39272e2837921f3bc24d80e4858689873af00504ecf6
```

## optimized-manual-prepare-repeat

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 2 (expected 2).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py prepare-fixtures --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-prepare

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py prepare-fixtures --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-report

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py report --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-stop

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 0 (expected 0).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py stop --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-stopped-prepare

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 2 (expected 2).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py prepare-fixtures --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## optimized-manual-stopped-report

cwd: `/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi`; exit 3 (expected 3).

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/harness/run.py report --harness-manifest /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/harness-manifest.json --harness-manifest-sha256 1fa29eeb336b637c590adb105582e19aea67c07e516c8db7c49a3d1846da6e1d --config /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/optimized-manual-project-optimized/.friday_test/runs/independent-c1/config/control.json --config-sha256 7fa580bd1ef771bb1b52b8fd330cee0197a2a9db4dd9dee6f57e83f9660c5a1f
```

## board-validate

cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; exit 0 (expected 0).

```text
/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/admin-bin/uv run python -B scripts/friday-dev-board.py validate
```

## board-render-check

cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; exit 0 (expected 0).

```text
/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/admin-bin/uv run python -B scripts/friday-dev-board.py render --check
```

## documentation-lifecycle

cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; exit 0 (expected 0).

```text
/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/admin-bin/uv run python -B scripts/check-documentation-lifecycle.py
```

## package-metadata

cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; exit 0 (expected 0).

```text
/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/admin-bin/uv run python -B scripts/check-package-metadata.py
```

## owned-whitespace

cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; exit 0 (expected 0).

```text
git diff --check -- .gitignore docs/planning tests/readiness/ingest
```

## cached-whitespace

cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; exit 0 (expected 0).

```text
git diff --cached --check
```

## range-whitespace

cwd: `/Users/chuckrussell/Dev/gendev/agent-framework`; exit 0 (expected 0).

```text
git diff --check 2920d0dd295e9ecb1b35acc1d646cba18149c60d 48bc7c973a8de00ec79117ece4792455e7164ccd --
```

## Independent assertions normal

cwd: repository; exit 0. stdout/stderr retained as `independent-normal-final.stdout` and `.stderr`.

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/independent-final.py
```

## Independent assertions optimized

cwd: repository; exit 0. stdout/stderr retained as `independent-optimized-final.stdout` and `.stderr`.

```text
/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13 -I -S -B -O /private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-validator-P2CzAi/independent-final.py
```
