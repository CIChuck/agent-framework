import hashlib,json,os,pathlib,stat,subprocess,sys
S=pathlib.Path(__file__).parent.resolve(); R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); Q=json.loads((S/'request.json').read_bytes()); B=json.loads(pathlib.Path(Q['boundary']).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['/usr/bin/git',*a],cwd=R,env={'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0'})
def inventory(t):return {str(p.relative_to(t)):sha(p.read_bytes()) for p in t.rglob('*') if p.is_file()}
def run(label):
 out={'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'logical_before_status':sha(git('ls-files','-s','-z'))};out['status_full']=git('status','--short').decode();out['staged_diff']=git('diff','--cached','--binary').decode();out['protected']={p:sha((R/p).read_bytes()) for p in B['protected']};out['symlinks']={p:os.readlink(R/p) for p in B['symlinks']};out['preserved']={}
 for p,expected in B['preserved'].items():
  q=R/p
  if not q.exists() and not q.is_symlink():row={'absent':True}
  else:
   z=q.lstat();row={'mode':z.st_mode,'size':z.st_size,'mtime_ns':z.st_mtime_ns,'ctime_ns':z.st_ctime_ns,'birthtime':z.st_birthtime}
   if stat.S_ISREG(z.st_mode):row['sha256']=sha(q.read_bytes())
  out['preserved'][p]=row
 mismatch={k:([p for p in B[k] if out[k].get(p)!=B[k][p]] if isinstance(B[k],dict) else {'expected':B[k],'actual':out[k]}) for k in out if out[k]!=B[k]}
 checks={'pins':{p:sha((R/p).read_bytes())==h for p,h in Q['pins'].items()},'inputs':{p:sha(pathlib.Path(p).read_bytes())==h for p,h in Q['input_files'].items()},'tool_targets':{k:inventory(pathlib.Path(v['root']))==v['files'] and all(not p.is_symlink() for p in pathlib.Path(v['root']).rglob('*')) for k,v in Q['tool_inputs'].items()},'request':sha(pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-resolver-engine-fsiunmow/review-request.json').read_bytes())=='e48e102babda06d8e1c374bc1ed9db3db0b230d8631fabd6de0501e0bc3a36c2','boundary':sha(pathlib.Path(Q['boundary']).read_bytes())==Q['boundary_sha256'],'interpreter':sha(pathlib.Path(Q['interpreter']).read_bytes())==Q['interpreter_sha256']}
 (S/(label+'-state.json')).write_text(json.dumps(out,indent=2)+'\n');(S/(label+'-checks.json')).write_text(json.dumps({'mismatch':mismatch,'checks':checks},indent=2)+'\n');print(json.dumps({'label':label,'protected':len(out['protected']),'symlinks':len(out['symlinks']),'preserved':len(out['preserved']),'mismatch':mismatch,'failed_checks':{k:[x for x,y in v.items() if not y] if isinstance(v,dict) else v for k,v in checks.items() if not (all(v.values()) if isinstance(v,dict) else v)}}))
 if mismatch or not all(all(v.values()) if isinstance(v,dict) else v for v in checks.values()):raise SystemExit(1)
if __name__=='__main__':run(sys.argv[1])
