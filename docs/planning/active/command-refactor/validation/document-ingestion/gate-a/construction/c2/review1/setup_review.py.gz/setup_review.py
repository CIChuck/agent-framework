import pathlib,json,hashlib,subprocess,os,ast
s=pathlib.Path(__file__).parent.resolve();req=json.loads((s/'request.json').read_bytes());repo=pathlib.Path(req['repo']); supplied=pathlib.Path(req['boundary']).parent;env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
def sha(b):return hashlib.sha256(b).hexdigest()
def check(ok,msg):
 if not ok:raise RuntimeError(msg)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,env=env)
tools=s/'validation-tools';tools.mkdir(); inputs={}
for key in ['ruff','root_config','mypy_inventory','mypy_launcher','parser_inspection','selection_driver']:
 p=pathlib.Path(req['tool_inputs'][key]);raw=p.read_bytes();check(sha(raw)==req['tool_inputs'][key+'_sha256'],key+' identity');inputs[str(p)]=sha(raw)
check(sha(pathlib.Path(req['interpreter']).read_bytes())==req['interpreter_sha256'],'interpreter');inputs[req['interpreter']]=req['interpreter_sha256']
for key,inventory,dest in [('mypy_target','mypy_inventory','mypy-target'),('parser_target','parser_inspection','parser-target')]:
 origin=pathlib.Path(req['tool_inputs'][key]);inv=json.loads(pathlib.Path(req['tool_inputs'][inventory]).read_bytes());files=inv['files'];check(len(files)==(1177 if key=='mypy_target' else 23),'tool count');check({str(p.relative_to(origin)) for p in origin.rglob('*') if p.is_file()}==set(files),'exact tool inventory')
 for name,digest in files.items():
  p=origin/name;check(not p.is_symlink(),'tool symlink');raw=p.read_bytes();check(sha(raw)==digest,'tool digest '+name);q=tools/dest/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw);q.chmod(0o444);inputs[str(p)]=digest
 (s/(inventory+'.json')).write_text(json.dumps(inv,sort_keys=True,indent=2)+'\n')
for key,dest in [('ruff','ruff'),('root_config','pyproject.toml')]:
 p=pathlib.Path(req['tool_inputs'][key]);q=tools/dest;q.write_bytes(p.read_bytes());q.chmod(0o555 if key=='ruff' else 0o444)
check((tools/'pyproject.toml').read_bytes()==(repo/'pyproject.toml').read_bytes(),'root config equality')
h=s/'export/tests/readiness/ingest';h.mkdir(parents=True);rows=[]
for item in git('ls-tree','-r','-z',req['candidate'],'--','tests/readiness/ingest').split(b'\0'):
 if not item:continue
 meta,path=item.split(b'\t');mode,kind,blob=meta.decode().split();check(mode=='100644' and kind=='blob','nonregular source');name=str(pathlib.Path(path.decode()).relative_to('tests/readiness/ingest'));raw=git('cat-file','blob',blob);q=h/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw);q.chmod(0o444);rows.append(dict(path=name,blob=blob,sha256=sha(raw),mode=mode))
man=dict(schema=1,commit=req['candidate'],tree=git('rev-parse',req['candidate']+'^{tree}').decode().strip(),files=rows);mp=s/'harness-manifest.json';mp.write_text(json.dumps(man,sort_keys=True,separators=(',',':')))
reference=json.loads((repo/pathlib.Path(req['source_manifest']).relative_to(repo)).read_bytes());check(rows==reference['files'],'source manifest file equality');check(sha((h/'bootstrap.py').read_bytes())==req['bootstrap_sha256'],'bootstrap')
retained=[];new=[]
for row in rows:
 if not row['path'].startswith('tests/') or not row['path'].endswith('.py'):continue
 path='tests/readiness/ingest/'+row['path'];old=ast.parse(git('show',req['base']+':'+path));current=ast.parse((h/row['path']).read_bytes())
 def bodies(tree):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')}
 before=bodies(old);after=bodies(current)
 for k,v in before.items():check(after.get(k)==v,'changed prior test '+k);retained.append(k)
 new += [k for k in after if k not in before]
check(len(retained)==54 and len(new)==1,'test retention count')
changed=git('diff','--name-only',req['base'],req['candidate']).decode().splitlines();check(changed==req['changed_paths'],'changed path list')
(s/'inputs-opening.json').write_text(json.dumps(inputs,sort_keys=True,indent=2)+'\n');(s/'setup.json').write_text(json.dumps(dict(export=str(h),manifest=str(mp),manifest_sha256=sha(mp.read_bytes()),files=len(rows),source_delta=[p for p in changed if p.startswith('tests/')],retained=len(retained),new=new,tools={'typing':1177,'parser':23},root_rules_identical=True),indent=2)+'\n');print((s/'setup.json').read_text())
