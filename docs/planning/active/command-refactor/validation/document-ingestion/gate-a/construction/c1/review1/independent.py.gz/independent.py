import pathlib,sys,json,hashlib,types,unittest,io,zipfile,re,zlib,os,socket,_thread,threading
S=pathlib.Path(__file__).parent;E=S/'export-harness';M=S/'export-manifest.json';W=S/('independent-optimized-v2' if sys.flags.optimize else 'independent-normal-v2');W.mkdir();O=S/('outside-optimized-v2' if sys.flags.optimize else 'outside-normal-v2');O.mkdir();(O/'secret').write_bytes(b'owned fake outside content')
raw=(E/'bootstrap.py').read_bytes()
if hashlib.sha256(raw).hexdigest()!='70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c':raise RuntimeError('bootstrap mismatch')
ns={'__name__':'verified_independent_loader','__file__':str(E/'bootstrap.py')};exec(compile(raw,str(E/'bootstrap.py'),'exec',dont_inherit=True),ns)
buffers=ns['verified_buffers'](E,M,hashlib.sha256(M.read_bytes()).hexdigest());pkg=types.ModuleType('ingest');pkg.__path__=[];pkg.__dict__.update(ROOT=E,BUFFERS=buffers);sys.modules['ingest']=pkg;sys.meta_path.insert(0,ns['Buffers'](E,buffers))
from ingest.startup import Guard,guarded
from ingest.manifests import Refusal,canonical,digest
from ingest.fixtures import matrix_bytes,publish_matrix,verify_matrix,audit_office,archive
from ingest.ledger import Ledger,ZERO
from ingest.reports import report
from ingest.window import Window,FakeTransportGate
saved_thread=_thread.start_new_thread
oracle=json.loads(buffers['fixtures/expectations.json'])['A2']['fixture_oracles']; witness=[]
class Independent(unittest.TestCase):
    def root(self,name):p=W/name;p.mkdir();return p
    def refused(self,callback,pattern):
        with self.assertRaisesRegex(Refusal,pattern):callback()
        witness.append(pattern)
    def parts(self,raw):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:return {n:z.read(n).decode() for n in z.namelist()}
    def ledger(self,name):
        log=Ledger(self.root(name));log.append('init',{'run_id':'independent','config_sha256':'a'*64,'harness_sha256':'b'*64},ZERO);return log
    def test_01_complete_literal_oracles_and_independent_content(self):
        a=matrix_bytes();b=matrix_bytes();self.assertEqual(a,b);self.assertEqual(len(a),30);self.assertEqual(len({digest(x) for x in a.values()}),30)
        self.assertEqual({k:sum(n.endswith('.'+k) for n in a) for k in ['pdf','docx','xlsx','pptx']},{'pdf':6,'docx':6,'xlsx':10,'pptx':8})
        self.assertEqual(set(a),{c['file'] for c in oracle['cases']})
        for c in oracle['cases']:
            data=a[c['file']]
            if c['format']=='pdf':
                if c['file']!='pdf-scanned.pdf':
                    for marker in c['contains']:self.assertIn(marker.encode(),data)
            else:
                payload=''.join(self.parts(data).values())
                for marker in c['contains']:self.assertIn(marker,payload)
                for marker in c['excludes']:self.assertIn(marker,payload) # excluded source content is present to exercise future policy
        self.assertEqual([c['outcome'] for c in oracle['cases']].count('refuse'),6)
    def test_02_pdf_xref_lengths_pages_image_and_standard_encryption(self):
        a=matrix_bytes()
        for name,data in a.items():
            if not name.endswith('.pdf'):continue
            start=int(re.search(rb'startxref\n(\d+)\n%%EOF',data)[1]);self.assertEqual(data[start:start+4],b'xref')
            rows=data[start:].splitlines();count=int(rows[1].split()[1]);self.assertEqual(count,len(re.findall(rb'(?m)^\d+ 0 obj$',data))+1)
            for i,line in enumerate(rows[3:2+count],1):self.assertTrue(data[int(line[:10]):].startswith(f'{i} 0 obj\n'.encode()))
            self.assertEqual(int(re.search(rb'/Type /Pages /Count (\d+)',data)[1]),3 if name=='pdf-pages.pdf' else 1)
            for found in re.finditer(rb'/Length (\d+) >>\nstream\n',data):
                end=found.end()+int(found[1]);self.assertEqual(data[end:end+10],b'\nendstream')
        scan=a['pdf-scanned.pdf'];m=re.search(rb'/Subtype /Image /Width (\d+) /Height (\d+).*?/Length (\d+) >>\nstream\n',scan);pixels=zlib.decompress(scan[m.end():m.end()+int(m[3])]);self.assertEqual(len(pixels),int(m[1])*int(m[2]));self.assertEqual(set(pixels),{0,255});self.assertNotIn(b'SCANNED PAGE VERIFIED',scan)
        # Independently implement the public PDF revision-2 password algorithm to decrypt the fixture stream.
        def rc4(key,data):
            box=list(range(256));j=0
            for i in range(256):j=(j+box[i]+key[i%len(key)])%256;box[i],box[j]=box[j],box[i]
            i=j=0;out=[]
            for c in data:i=(i+1)%256;j=(j+box[i])%256;box[i],box[j]=box[j],box[i];out.append(c^box[(box[i]+box[j])%256])
            return bytes(out)
        data=a['pdf-encrypted.pdf'];padding=bytes.fromhex('28bf4e5e4e758a4164004e56fffa01082e2e00b6d0683e802f0ca9fe6453697a');user=(b'fixture-password'+padding)[:32];owner=bytes.fromhex(re.search(rb'/O <([0-9a-f]+)>',data)[1].decode());fileid=bytes.fromhex(re.search(rb'/ID \[<([0-9a-f]+)>',data)[1].decode());key=hashlib.md5(user+owner+b'\xfc\xff\xff\xff'+fileid).digest()[:5];u=bytes.fromhex(re.search(rb'/U <([0-9a-f]+)>',data)[1].decode());self.assertEqual(rc4(key,padding),u)
        obj=re.search(rb'(\d+) 0 obj\n<< /Length (\d+) >>\nstream\n',data);objkey=hashlib.md5(key+int(obj[1]).to_bytes(3,'little')+b'\0\0').digest()[:10];self.assertIn(b'ENCRYPTED PRIVATE FIXTURE',rc4(objkey,data[obj.end():obj.end()+int(obj[2])]))
    def test_03_office_order_visibility_notes_and_bounds(self):
        a=matrix_bytes();self.assertEqual(audit_office(a['docx-body.docx'],'docx')['body_order'],['p','p','tbl','p','sectPr']);self.assertEqual(len(audit_office(a['docx-parts.docx'],'docx')['omitted_parts']),3)
        p=self.parts(a['docx-body.docx'])['word/document.xml'];self.assertLess(p.index('WORD BEFORE'),p.index('WORD TABLE HEADER'));self.assertLess(p.index('WORD TABLE VALUE'),p.index('WORD AFTER'))
        facts=audit_office(a['xlsx-order.xlsx'],'xlsx');self.assertEqual([x['name'] for x in facts['units']],['SecondByName','FirstByName'])
        self.assertEqual(audit_office(a['xlsx-hidden-sheet.xlsx'],'xlsx')['units'][1]['hidden'],True);self.assertEqual(audit_office(a['xlsx-hidden-row.xlsx'],'xlsx')['units'][0]['hidden_rows'],[2]);self.assertEqual(audit_office(a['xlsx-hidden-column.xlsx'],'xlsx')['units'][0]['hidden_columns'],['2:2'])
        self.assertEqual(audit_office(a['pptx-notes.pptx'],'pptx')['note_parts'],1);self.assertEqual(audit_office(a['pptx-comments.pptx'],'pptx')['comment_parts'],1);hidden=audit_office(a['pptx-hidden.pptx'],'pptx')['units'];self.assertEqual([x['hidden'] for x in hidden],[False,True]);self.assertEqual(hidden[0]['hidden_shapes'],['3']);self.assertEqual(audit_office(a['pptx-external.pptx'],'pptx')['refusal_codes'],['external_relationship_requires_no_fetch'])
        for name,data in a.items():
            kind=name.rsplit('.',1)[1]
            if kind!='pdf':self.assertIs(audit_office(data,kind)['text_extracted'],False)
        parts=self.parts(a['xlsx-values.xlsx']);key='xl/worksheets/sheet1.xml'
        for mutation,pattern in [(parts[key].replace('r="A2"','r="XFE2"'),'coordinate'),('<!DOCTYPE worksheet [<!ENTITY x "bad">]>'+parts[key],'declarations'),(parts[key].replace('</worksheet>','<mergeCells><mergeCell ref="A1:XFD20000"/></mergeCells></worksheet>'),'expansion')]:
            bad=parts.copy();bad[key]=mutation;self.refused(lambda:audit_office(archive(bad),'xlsx'),pattern)
        self.refused(lambda:audit_office(archive({'../outside':'payload'}),'xlsx'),'escape')
    def test_04_formula_cache_selection(self):
        a=matrix_bytes();missing=self.parts(a['xlsx-formula-missing.xlsx']);key='xl/worksheets/sheet1.xml'
        self.assertEqual(audit_office(a['xlsx-formula-missing.xlsx'],'xlsx')['refusal_codes'],['included_formula_cache_missing']);self.assertEqual(audit_office(a['xlsx-formula-error.xlsx'],'xlsx')['refusal_codes'],['included_formula_cache_error']);self.assertEqual(audit_office(a['xlsx-formula-valid.xlsx'],'xlsx')['refusal_codes'],[])
        missing[key]=missing[key].replace('<row r="2">','<row r="2" hidden="true">');self.assertEqual(audit_office(archive(missing),'xlsx')['refusal_codes'],[])
    def test_05_publication_extra_alias_and_content_refuse(self):
        root=self.root('publication');dest=root/'new';manifest=publish_matrix(dest,oracle);sha=digest(canonical(manifest));self.assertEqual(len(verify_matrix(dest,sha)),30);self.assertFalse(any(p.stat().st_mode&0o222 for p in dest.iterdir()))
        extra=dest/'unexpected';extra.write_bytes(b'extra');self.refused(lambda:verify_matrix(dest,sha),'Extra');extra.unlink()
        p=dest/'xlsx-values.xlsx';raw=p.read_bytes();p.chmod(0o644);p.write_bytes(raw[:-1]+bytes([raw[-1]^1]));self.refused(lambda:verify_matrix(dest,sha),'bytes changed');p.write_bytes(raw);p.unlink();p.symlink_to(dest/'xlsx-order.xlsx');self.refused(lambda:verify_matrix(dest,sha),'[Ss]ymlink')
        self.refused(lambda:publish_matrix(dest,oracle),'New physical');bad={'schema':1,'cases':[]};missing=root/'still-absent';self.refused(lambda:publish_matrix(missing,bad),'oracle count');self.assertFalse(missing.exists())
    def test_06_partial_stop_and_lease_ownership(self):
        root=self.root('partial');calls=[]
        def check():
            calls.append(1)
            if len(calls)==5:raise Refusal('independent sticky stop')
        self.refused(lambda:publish_matrix(root/'inputs',oracle,check),'sticky stop');self.assertEqual(len(list((root/'inputs').iterdir())),3);self.assertFalse((root/'inputs/manifest.json').exists())
        log=self.ledger('lease');tip=log.tip();self.refused(lambda:log.append_held('finish',{},tip,object()),'not owned')
        with log.lease() as token:
            self.refused(lambda:Ledger(log.state).append_held('finish',{},tip,token),'not owned')
            with self.assertRaises(FileExistsError):Ledger(log.state).append('finish',{},tip)
            log.append_held('finish',{'operation':'independent'},tip,token);self.refused(lambda:log.append_held('finish',{},tip,token),'Stale')
            pid=log._lease_pid;log._lease_pid=-1;self.refused(lambda:log.append_held('finish',{},log.tip(),token),'not owned');log._lease_pid=pid
        self.refused(lambda:log.append_held('finish',{},log.tip(),token),'not owned');self.assertFalse((log.state/'writer.lock').exists())
    def test_07_retained_guard_refusals_with_positive_owned_io(self):
        p=W/'positive';p.write_bytes(b'ok');self.assertEqual(p.read_bytes(),b'ok')
        for callback,pattern in [(lambda:(O/'secret').read_bytes(),'Undeclared'),(lambda:os.stat(O/'absent'),'Undeclared'),(lambda:os.listdir(O),'Undeclared'),(lambda:(O/'must-not-exist').write_bytes(b'bad'),'Undeclared'),(lambda:socket.socket(),'Network'),(lambda:saved_thread(lambda:None,()),'thread'),(lambda:threading.Thread(target=lambda:None).start(),'thread')]:self.refused(callback,pattern)
        fd=os.open(p,os.O_RDONLY)
        try:self.refused(lambda:os.fstat(fd),'descriptor');self.refused(lambda:os.stat(p,dir_fd=fd),'dir_fd')
        finally:os.close(fd)
        with self.assertRaises(Refusal):
            with guarded(Guard((O,),())):pass
    def test_08_retained_budget_transport_and_report_truth(self):
        log=self.ledger('budget');log.reserve('requests',64,64);self.refused(lambda:Ledger(log.state).reserve('requests',1,64),'resource ceiling')
        stop=[False];calls=[];reservations=[];w=Window('independent','http://127.0.0.1:1234','loaded','LMS_NATIVE_V1',1000,'scope',{'x':'a'*64})
        gate=FakeTransportGate(w,lambda:10,lambda:stop[0],lambda *args:reservations.append(args),lambda *args:calls.append(args) or {},len,20)
        gate.send('POST','/v1/embeddings',{'model':'loaded','input':['one']});self.assertEqual(gate.attempts,1);self.assertEqual(len(calls),1)
        self.refused(lambda:gate.send('POST','/v1/embeddings',{'model':'wrong','input':['one']}),'identity');self.assertEqual(gate.attempts,1)
        def reserve(*args):stop[0]=True
        gate.reserve=reserve;self.refused(lambda:gate.send('POST','/v1/embeddings',{'model':'loaded','input':['one']}),'before transport');self.assertEqual(gate.attempts,1)
        rlog=self.ledger('report');rlog.append('finish',{'operation':'prepare_fixtures','manifest_sha256':'c'*64,'fixture_count':30,'converter_qualified':False},rlog.tip());r=report(rlog);self.assertIs(r['full_readiness'],False);self.assertIs(r['prepared_inputs'][0]['current_bytes_revalidated'],False);self.assertEqual(r['status'],'INCOMPLETE')
        rlog.append('finish',{'operation':'prepare_fixtures','manifest_sha256':'c'*64,'fixture_count':30,'converter_qualified':True},rlog.tip());self.refused(lambda:report(rlog),'claim')
policy=Guard((E,pathlib.Path(sys.base_prefix).resolve()/'lib',pathlib.Path(sys.executable).resolve()),(W,))
with guarded(policy):result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Independent))
print(json.dumps({'tests':result.testsRun,'success':result.wasSuccessful(),'optimized':bool(sys.flags.optimize),'independent_refusal_witnesses':witness,'application_modules':[n for n in sys.modules if n.startswith(('friday_','docling','litellm'))]}))
raise SystemExit(0 if result.wasSuccessful() else 1)
