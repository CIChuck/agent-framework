import hashlib,json,os,pathlib,subprocess,sys
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); S=pathlib.Path(__file__).parent
Q=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-build-sqewgfmf/review-request.json')
req=json.loads(Q.read_text()); boundary=json.loads(pathlib.Path(req['boundary']).read_text())
def h(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=R,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def snap():
    index=h(git('ls-files','-s','-z'))
    status=git('status','--porcelain=v1','--untracked-files=all').decode()
    result={'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'logical_index':index,'status':status,'tracked':{},'symlinks':{},'preserved':{}}
    for rel in boundary['tracked']:
        p=R/rel
        result['tracked'][rel]=h(p.read_bytes())
    for rel in boundary['symlinks']: result['symlinks'][rel]=os.readlink(R/rel)
    for rel,record in boundary['preserved'].items():
        p=R/rel
        if record.get('absent'): result['preserved'][rel]={'absent':not os.path.lexists(p)}; continue
        st=p.lstat(); d={k:getattr(st,'st_'+k) for k in ('mode','size','mtime_ns','ctime_ns','birthtime')}
        if 'sha256' in record: d['sha256']=h(p.read_bytes())
        result['preserved'][rel]=d
    return result
if sys.argv[1]=='open':
    a=snap(); (S/'opening.json').write_text(json.dumps(a,indent=2))
    mismatches={k:[p for p,v in boundary[k].items() if a[k].get(p)!=v] for k in ('tracked','symlinks','preserved')}
    pins={p:h((R/p).read_bytes())==v and h(git('show',req['candidate']+':'+p))==v for p,v in req['pins'].items()}
    manifest=json.loads((R/req['criteria']).read_text()) if False else json.loads(pathlib.Path(req['source_manifest']).read_text())
    exp=S/'export-harness'; exp.mkdir()
    exported=[]
    for f in manifest['files']:
        rel='tests/readiness/ingest/'+f['path']; data=git('show',req['candidate']+':'+rel)
        blob=git('rev-parse',req['candidate']+':'+rel).decode().strip()
        if h(data)!=f['sha256'] or blob!=f['blob']: raise SystemExit('bad manifest '+rel)
        p=exp/f['path']; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
        exported.append({'path':f['path'],'sha256':h(data),'blob':blob,'mode':f['mode']})
    exact=git('ls-tree','-r','-z',req['candidate'],'tests/readiness/ingest')
    observed=[x.split(b'\t',1)[1].decode().removeprefix('tests/readiness/ingest/') for x in exact.split(b'\0') if x]
    if sorted(observed)!=sorted(f['path'] for f in exported): raise SystemExit('manifest selection mismatch')
    ownmanifest={**manifest,'commit':req['candidate'],'files':exported,'export_origin':'reviewer git-show from candidate; no worktree source'}
    (S/'export-manifest.json').write_text(json.dumps(ownmanifest,sort_keys=True,separators=(',',':')))
    print(json.dumps({'boundary_keys':list(boundary),'boundary_identity':{k:v for k,v in boundary.items() if k not in ('tracked','symlinks','preserved','status')},'opening_identity':{k:v for k,v in a.items() if k not in ('tracked','symlinks','preserved','status')},'counts':{k:len(a[k]) for k in ('tracked','symlinks','preserved')},'mismatches':mismatches,'pins':pins,'exported':len(exported),'manifest_sha256':h((S/'export-manifest.json').read_bytes())},indent=2))
else:
    a=snap(); (S/'closing.json').write_text(json.dumps(a,indent=2)); old=json.loads((S/'opening.json').read_text()); print(json.dumps({'unchanged':a==old,'changed_keys':[k for k in a if a[k]!=old[k]]}));
