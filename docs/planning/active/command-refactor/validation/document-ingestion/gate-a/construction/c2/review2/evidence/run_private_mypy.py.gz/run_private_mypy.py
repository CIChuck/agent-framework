"""Operational private-tool launcher; source/target/digests are explicit inputs."""
import sys, pathlib, types, hashlib, importlib
if not (sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode):
    raise RuntimeError('Use -I -S -B')
target, harness, manifest, expected, expected_bootstrap = sys.argv[1:6]
root = pathlib.Path(harness)
raw = (root/'bootstrap.py').read_bytes()
if hashlib.sha256(raw).hexdigest()!=expected_bootstrap:
    raise RuntimeError('Private tool bootstrap identity mismatch')
namespace={'__name__':'private_tool_bootstrap','__file__':str(root/'bootstrap.py')}
exec(compile(raw,str(root/'bootstrap.py'),'exec',dont_inherit=True),namespace)
buffers=namespace['verified_buffers'](root,pathlib.Path(manifest),expected)
package=types.ModuleType('ingest');package.__path__=[];package.__dict__.update(ROOT=root,BUFFERS=buffers);sys.modules['ingest']=package
sys.meta_path.insert(0,namespace['Buffers'](root,buffers))
from ingest.startup import Guard,guarded
private=pathlib.Path(__file__).parent.resolve()
stdlib=pathlib.Path(sys.base_prefix).resolve()/'lib'
class ObservedGuard(Guard):
    def path(self,value,write=False,probe=False):
        try:
            super().path(value,write,probe)
        except Exception:
            sys.stderr.write('PRIVATE TOOL REFUSAL: '+repr(value)+' write='+str(write)+' probe='+str(probe)+'\n')
            raise
policy=ObservedGuard((private,stdlib,pathlib.Path(sys.executable).resolve(),pathlib.Path("/System/Library/CoreServices/SystemVersion.plist")),(private/'validation-tools/mypy-cache',private/'static-tmp'))
sys.path.insert(0,target)
with guarded(policy):
    import mypy.modulefinder as finder
    original_paths=finder.default_lib_path
    def private_typeshed(data_dir,pyversion,custom_typeshed_dir):
        result=[path for path in original_paths(data_dir,pyversion,custom_typeshed_dir) if path != "/usr/local/lib/mypy"]
        for path in result:
            policy.path(path)
        return result
    finder.default_lib_path=private_typeshed
    # Declare only the hash-verified private parser as an installed PEP561 package.
    # This preserves root checks on selected sources without treating third-party
    # library internals as repository source or discovering ambient site packages.
    import mypy.build as build
    original_search=build.compute_search_paths
    def explicit_search(*args,**kwargs):
        result=original_search(*args,**kwargs)
        explicit=finder.SearchPaths(result.python_path,result.mypy_path,(str(private/"validation-tools/parser-target"),),result.typeshed_path)
        sys.stderr.write("PRIVATE PEP561 PATHS: "+repr(explicit.package_path)+"\n")
        return explicit
    build.compute_search_paths=explicit_search
    from mypy.api import run
    out,err,code=run(sys.argv[6:])
sys.stdout.write(out);sys.stderr.write(err)
raise SystemExit(code)
