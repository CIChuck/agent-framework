"""Private engine import and actual synthetic solving only; no index/Docling calls."""
from pathlib import Path
import hashlib,json,sys,types,time
s=Path(__file__).parent.resolve();h=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6/formal-correction1/source/tests/readiness/ingest');m=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6/formal-correction1/harness-manifest.json')
def require(ok,message):
 if not ok:raise AssertionError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
require(sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode,'Use -I -S -B')
engine=s/'validation-tools/resolver-target';parser=s/'validation-tools/packaging-target';expected_engine=json.loads((s/'inspection.json').read_bytes());expected_parser=json.loads((s/'parser-inspection.json').read_bytes())
for target,inventory in [(engine,expected_engine),(parser,expected_parser)]:
 require({str(p.relative_to(target)):sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}==inventory['files'] and all(not p.is_symlink() for p in target.rglob('*')),'Private inventory changed')
raw=(h/'bootstrap.py').read_bytes();require(sha(raw)=='70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c','Bootstrap changed');ns={'__name__':'private_bootstrap','__file__':str(h/'bootstrap.py')};exec(compile(raw,str(h/'bootstrap.py'),'exec',dont_inherit=True),ns);buffers=ns['verified_buffers'](h,m,'f4d0e22c089d839780e60cd2ab543257db2e300ccfb1bebfdd6b065c53687843');pkg=types.ModuleType('ingest');pkg.__path__=[];pkg.__dict__.update(ROOT=h,BUFFERS=buffers);sys.modules['ingest']=pkg;sys.meta_path.insert(0,ns['Buffers'](h,buffers));from ingest.startup import Guard,guarded
sys.path[:0]=[str(engine),str(parser)];policy=Guard((s,h,Path(sys.base_prefix).resolve()/'lib',Path(sys.executable).resolve()),(s,));started=time.monotonic();checks=[]
with guarded(policy):
 import resolvelib,packaging
 from packaging.requirements import Requirement
 from packaging.version import Version
 from packaging.utils import canonicalize_name
 from resolvelib import AbstractProvider,BaseReporter,Resolver,ResolutionImpossible,ResolutionTooDeep
 require(resolvelib.__version__=='1.2.1' and packaging.__version__=='24.2','Tool versions')
 class Provider(AbstractProvider):
  def __init__(self,catalog):self.catalog=catalog
  def identify(self,requirement_or_candidate):return canonicalize_name(requirement_or_candidate.name) if isinstance(requirement_or_candidate,Requirement) else requirement_or_candidate[0]
  def get_preference(self,identifier,**kwargs):return identifier
  def find_matches(self,identifier,requirements,incompatibilities):
   requirements=list(requirements[identifier]);excluded=set(incompatibilities[identifier]);return [(identifier,Version(version)) for version in sorted(self.catalog.get(identifier,{}),key=Version,reverse=True) if (identifier,Version(version)) not in excluded and all(Version(version) in req.specifier for req in requirements)]
  def is_satisfied_by(self,requirement,candidate):return self.identify(requirement)==candidate[0] and candidate[1] in requirement.specifier
  def get_dependencies(self,candidate):return [Requirement(raw) for raw in self.catalog[candidate[0]][str(candidate[1])]]
 class Reporter(BaseReporter):
  def __init__(self):self.rounds=0;self.rejections=0
  def starting_round(self,index):
   self.rounds+=1;require(time.monotonic()-started<300,'Qualification time bound')
  def rejecting_candidate(self,criterion,candidate):self.rejections+=1
 catalog={'alpha':{'2':['beta>=2'],'1':['beta>=1']},'beta':{'2':[],'1':[]}}
 reporter=Reporter();result=Resolver(Provider(catalog),reporter).resolve([Requirement('alpha>=1'),Requirement('beta<2')],max_rounds=500);mapping={name:str(candidate[1]) for name,candidate in result.mapping.items()};require(mapping=={'alpha':'1','beta':'1'} and reporter.rejections>=1,'Actual backtracking result');checks.append('newest_conflict_backtracks_to_compatible_version')
 try:Resolver(Provider(catalog),Reporter()).resolve([Requirement('alpha==2'),Requirement('beta<2')],max_rounds=500)
 except ResolutionImpossible:checks.append('unsatisfiable_constraints_refuse')
 else:raise AssertionError('Unsatisfiable graph accepted')
 cycle={'alpha':{'1':['beta==1']},'beta':{'1':['alpha==1']}};cycle_result=Resolver(Provider(cycle),Reporter()).resolve([Requirement('alpha')],max_rounds=500);require(set(cycle_result.mapping)=={'alpha','beta'},'Cycle resolution');checks.append('finite_cycle_resolves')
 try:Resolver(Provider(catalog),Reporter()).resolve([Requirement('alpha')],max_rounds=1)
 except ResolutionTooDeep:checks.append('round_ceiling_refuses')
 else:raise AssertionError('Round ceiling not enforced')
 origins={name:module.__file__ for name,module in sys.modules.items() if name=='resolvelib' or name.startswith('resolvelib.') or name=='packaging' or name.startswith('packaging.')};require(all((engine in Path(path).resolve().parents if name.startswith('resolvelib') else parser in Path(path).resolve().parents) for name,path in origins.items()),'Tool import origin');checks.append('all_tool_module_origins_private')
 for target,inventory in [(engine,expected_engine),(parser,expected_parser)]:require({str(p.relative_to(target)):sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}==inventory['files'],'Tool target modified')
 checks.append('exact_targets_unchanged')
record={'status':'PASS','profile_sha256':expected_engine['profile_sha256'],'optimized':bool(sys.flags.optimize),'checks':checks,'count':len(checks),'chosen':mapping,'backtracking_rejections':reporter.rejections,'solver_rounds':reporter.rounds,'origins':origins,'synthetic_resolution':True,'actual_A0_A4':False,'network_requests':0,'docling_or_model_imports':False};(s/('qualified-optimized.json' if sys.flags.optimize else 'qualified-normal.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({key:value for key,value in record.items() if key!='origins'}))
