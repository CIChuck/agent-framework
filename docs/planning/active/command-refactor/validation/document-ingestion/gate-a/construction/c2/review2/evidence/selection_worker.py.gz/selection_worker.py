"""Reviewer-authored actual-call assertions over verified committed buffers."""
import sys,json,hashlib,types,unittest,copy
from pathlib import Path
S=Path(__file__).parent.resolve();label,mode=sys.argv[1:3];H=S/label;M=S/(label+'-manifest.json')
def check(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
check(sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode,'-I -S -B required')
profile=json.loads((S/'validation-tools/parser-inspection.json').read_bytes());target=S/'validation-tools/parser-target'
check({str(p.relative_to(target)):sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}==profile['files'],'parser exact inventory')
raw=(H/'bootstrap.py').read_bytes();check(sha(raw)=='70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c','bootstrap')
ns={'__name__':'review_bootstrap','__file__':str(H/'bootstrap.py')};exec(compile(raw,str(H/'bootstrap.py'),'exec',dont_inherit=True),ns);buffers=ns['verified_buffers'](H,M,sha(M.read_bytes()))
pkg=types.ModuleType('ingest');pkg.__path__=[];pkg.__dict__.update(ROOT=H,BUFFERS=buffers);sys.modules['ingest']=pkg;tests=types.ModuleType('ingest.tests');tests.__path__=[];sys.modules['ingest.tests']=tests;sys.meta_path.insert(0,ns['Buffers'](H,buffers))
from ingest.startup import Guard,guarded
sys.path.insert(0,str(target));policy=Guard((S,H,target,Path(sys.base_prefix).resolve()/'lib',Path(sys.executable).resolve()),(S,))
result={'source':label,'mode':mode,'optimized':bool(sys.flags.optimize),'manifest_sha256':sha(M.read_bytes()),'setup_succeeded':False}
with guarded(policy):
 from ingest.manifests import dependency_selection,Refusal
 import packaging
 check(Path(packaging.__file__).resolve().is_relative_to(target),'parser origin')
 check(packaging.__version__=='24.2','parser version')
 result.update(setup_succeeded=True,parser_origin=str(packaging.__file__),parser_sha256=sha(Path(packaging.__file__).read_bytes()))
 env={'implementation_name':'cpython','implementation_version':'3.13.10','os_name':'posix','platform_machine':'arm64','platform_release':'review','platform_system':'Darwin','platform_version':'review','python_full_version':'3.13.10','platform_python_implementation':'CPython','python_version':'3.13','sys_platform':'darwin'}
 def wheel(name='orbit',version='1.0',tag='py3-none-any',requires=(),extras=()):
  fn=name.replace('-','_')+'-'+version+'-'+tag+'.whl'
  return {'name':name,'version':version,'filename':fn,'url':'https://files.pythonhosted.org/reviewer/'+fn,'sha256':'b'*64,'size':7,'license':'BSD-2-Clause','requires_python':'>=3.13,<3.14','requires_dist':list(requires),'provides_extra':list(extras),'yanked':False}
 def selection(tag='py3-none-any',target_tag=None):return {'schema':1,'roots':['orbit==1.0'],'environment':dict(env),'tags':[target_tag or tag],'wheels':[wheel(tag=tag)]}
 case=unittest.TestCase()
 if mode=='witness':
  rows=[]
  for tag in ['py3--any','py3-none-']:
   v=selection(tag);row={'tag':tag,'call_reached':True}
   try:
    with case.assertRaises(Refusal):
     row['returned']=dependency_selection(v)
   except AssertionError as e:row.update(assertion_failure=str(e),refused=False)
   else:row['refused']=True
   rows.append(row)
  result.update(results=rows,call_assertion_failures=sum(not x['refused'] for x in rows))
 elif mode=='selector':
  from ingest.tests.test_manifests import dependency_cases
  result.update(dependency_cases())
  case.assertEqual(result['positive_cases'],6);case.assertEqual(result['refusal_cases'],39)
 elif mode=='independent':
  successes=[];refusals=[]
  def positive(name,v,count):
   output=dependency_selection(v);case.assertEqual(output['distribution_count'],count)
   for flag in ['artifact_bytes_verified','licenses_qualified','installed_profile_qualified','execution_permitted']:case.assertIs(output[flag],False)
   successes.append({'name':name,'result':output})
  def negative(name,v):
   with case.assertRaises(Refusal) as caught:dependency_selection(v)
   refusals.append({'name':name,'reason':str(caught.exception)})
  for tag,target_tag in [('py3-none-any',None),('cp313-cp313-macosx_11_0_arm64',None),('py2.py3-none-any','py3-none-any'),('py3-none.abi3-any','py3-none-any'),('py3-none-any.macosx_11_0_arm64','py3-none-any'),('py3-none-any','py2.py3-none-any')]:positive('valid-tag:'+tag+':'+str(target_tag),selection(tag,target_tag),1)
  malformed=['-none-any','py3--any','py3-none-','.py3-none-any','py3.-none-any','py3..py2-none-any','py3-.none-any','py3-none.-any','py3-none..abi3-any','py3-none-.any','py3-none-any.','py3-none-any..other']
  for tag in malformed:
   negative('matching-malformed:'+tag,selection(tag))
   negative('malformed-wheel-only:'+tag,selection(tag,'py3-none-any'))
  v=selection();v['roots']=['orbit[turbo]>=1'];v['wheels']=[wheel(requires=['base>=2','extra; extra == "turbo"','windows; sys_platform == "win32"'],extras=['turbo']),wheel('base','2.5',requires=['orbit>=1']),wheel('extra')];positive('base+extras+cycle+inactive-marker',v,3)
  x=copy.deepcopy(v);x['roots']=['orbit>=1'];x['wheels']=x['wheels'][:2];positive('base-without-extra',x,2)
  x=copy.deepcopy(v);x['roots']=['base[late]','orbit'];x['wheels'][1]=wheel('base','2.5',requires=['orbit[turbo]; extra == "late"'],extras=['late']);positive('late-extra-expansion',x,3)
  for name,alter in [('missing',lambda x:x['wheels'].pop()),('conflict',lambda x:x['wheels'][1].update(requires_dist=['orbit<1'])),('unknown-extra',lambda x:x.update(roots=['orbit[absent]'])),('unreachable',lambda x:x['wheels'].append(wheel('orphan'))),('direct-reference',lambda x:x['wheels'][0].update(requires_dist=['base @ https://files.pythonhosted.org/a.whl'])),('python',lambda x:x['wheels'][0].update(requires_python='<3.13')),('wrong-platform',lambda x:x.update(tags=['cp313-cp313-win_amd64'])),('count-roots',lambda x:x.update(roots=['orbit']*65)),('count-wheels',lambda x:x.update(wheels=[wheel()]*513)),('root-length',lambda x:x.update(roots=['orbit'+' '*4097])),('byte-cap',lambda x:x['wheels'][0].update(size=4*1024**3+1)),('bool-size',lambda x:x['wheels'][0].update(size=True)),('host',lambda x:x['wheels'][0].update(url='https://other.invalid/x.whl')),('yanked',lambda x:x['wheels'][0].update(yanked=True)),('metadata-unknown',lambda x:x['wheels'][0].update(unexpected=True)),('field-missing',lambda x:x['environment'].pop('sys_platform')),('dependency-count',lambda x:x['wheels'][0].update(requires_dist=['base']*257)),('extra-count',lambda x:x['wheels'][0].update(provides_extra=['x'+str(n) for n in range(65)])),('tag-count',lambda x:x.update(tags=['py3-none-any']*2049))]:
   x=copy.deepcopy(v);alter(x);negative(name,x)
  result.update(positive_cases=len(successes),refusal_cases=len(refusals),positives=successes,refusals=refusals)
 else:raise ValueError(mode)
 result['loaded_parser_modules']={k:str(getattr(v,'__file__','')) for k,v in sys.modules.items() if k=='packaging' or k.startswith('packaging.')}
 check(all(Path(p).is_relative_to(target) for p in result['loaded_parser_modules'].values()),'all parser origins')
print(json.dumps(result,sort_keys=True))
if mode=='witness' and result['call_assertion_failures']:raise AssertionError('Actual call assertion witness: expected Refusal was not raised')
