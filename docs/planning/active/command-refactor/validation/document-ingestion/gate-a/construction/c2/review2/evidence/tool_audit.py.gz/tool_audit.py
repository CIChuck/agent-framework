import json,csv,io,hashlib,base64,email
from pathlib import Path
S=Path(__file__).parent;results={}
for label,count in [('mypy-target',1177),('parser-target',23)]:
 root=S/'validation-tools'/label;files=[p for p in root.rglob('*') if p.is_file()];assert len(files)==count;assert not any(p.is_symlink() for p in root.rglob('*'))
 hooks=[str(p.relative_to(root)) for p in files if p.suffix in {'.pth','.egg-link'} or p.name.startswith(('sitecustomize.','usercustomize.'))];assert not hooks
 records=[]
 for info in sorted(root.glob('*.dist-info')):
  metadata=email.message_from_bytes((info/'METADATA').read_bytes());verified=0;blank=[]
  for name,digest,size in csv.reader(io.StringIO((info/'RECORD').read_text())):
   path=root/name;assert path.is_file() and path.resolve().is_relative_to(root)
   raw=path.read_bytes()
   if digest:
    kind,encoded=digest.split('=',1);assert kind=='sha256';assert base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip('=')==encoded;assert int(size)==len(raw);verified+=1
   else:blank.append(name)
  records.append({'distribution':metadata['Name'],'version':metadata['Version'],'record_members_hashed':verified,'unhashed_record_self':blank,'license_files':[str(p.relative_to(root)) for p in info.rglob('*') if p.is_file() and p.name.startswith(('LICENSE','COPYING'))]})
 results[label]={'files':len(files),'startup_hooks':hooks,'record_verification':records,'py_typed':str(root/'packaging/py.typed') if label=='parser-target' else None}
(S/'tool-origin-record-audit.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
