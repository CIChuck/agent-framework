"""Private exact-current-byte development receipts, not committed proof."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

S = Path(__file__).parent.resolve()
R = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
P = '/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13'
BASE = 'ecfa38bb71854bb3174ceb9ee82cbb87ef110e69'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=R, env={'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0'})


def run(label, argv, cwd):
    env = {'HOME':os.environ.get('HOME',''), 'PATH':'/usr/bin:/bin', 'LANG':'en_US.UTF-8', 'PYTHONDONTWRITEBYTECODE':'1', 'MYPYPATH':str(S/'snapshot'/sys.argv[1]/'tests/readiness'), 'TMPDIR':str(S/'static-tmp')}
    completed = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, timeout=90)
    record = {'argv':argv, 'cwd':str(cwd), 'exit_code':completed.returncode, 'stdout':completed.stdout, 'stderr':completed.stderr, 'claim':'development exact-byte snapshot only'}
    (S/(label+'.json')).write_text(json.dumps(record, indent=2))
    print(json.dumps({'label':label,'exit_code':completed.returncode,'stdout':completed.stdout[-3000:],'stderr':completed.stderr[-7000:]}),flush=True)


def main():
    version = sys.argv[1]
    h = S/'snapshot'/version/'tests/readiness/ingest'
    h.mkdir(parents=True)
    files = git('ls-tree','-r','--name-only',BASE,'--','tests/readiness/ingest').decode().splitlines()
    records=[]
    for name in files:
        relative = Path(name).relative_to('tests/readiness/ingest').as_posix()
        src = R/name
        if src.is_symlink():raise RuntimeError('source alias')
        raw=src.read_bytes()
        dst=h/relative;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
        records.append({'path':relative,'blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'sha256':hashlib.sha256(raw).hexdigest(),'mode':'100644'})
    manifest={'schema':1,'commit':BASE,'tree':git('rev-parse',BASE+'^{tree}').decode().strip(),'files':records}
    raw=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()
    mp=S/('development-manifest-'+version+'.json');mp.write_bytes(raw)
    digest=hashlib.sha256(raw).hexdigest()
    (S/('snapshot-'+version+'.json')).write_text(json.dumps({'warning':'Uncommitted exact-current-byte development snapshot. Commit/tree fields name the selection base only, not formal committed identity.','harness':str(h),'manifest':str(mp),'manifest_sha256':digest,'files':records},indent=2))
    for flag,label in [([], 'normal'),(['-O'],'optimized')]:
        out=S/('selftest-'+version+'-'+label);out.mkdir()
        run(version+'-'+label,[P,'-I','-S','-B',*flag,str(h/'run.py'),'selftest','--harness-manifest',str(mp),'--harness-manifest-sha256',digest,'--scratch',str(out)],S)
    run(version+'-ruff',[str(S/'tools/ruff'),'check','--no-cache','--no-respect-gitignore','--config',str(S/'tools/pyproject.toml'),str(h)],S)
    run(version+'-format',[str(S/'tools/ruff'),'format','--check','--no-cache','--config',str(S/'tools/pyproject.toml'),str(h)],S)
    cache=S/('mypy-cache-'+version);cache.mkdir()
    (S/'static-tmp').mkdir(exist_ok=True)
    run(version+'-mypy',[P,'-I','-S','-B',str(S/'private_mypy.py'),str(S/'tools/mypy-target'),str(h),str(mp),digest,hashlib.sha256((h/'bootstrap.py').read_bytes()).hexdigest(),'--config-file',str(S/'tools/pyproject.toml'),'--no-site-packages','--explicit-package-bases','--cache-dir',str(cache),str(h)],S)


if __name__=='__main__':main()
