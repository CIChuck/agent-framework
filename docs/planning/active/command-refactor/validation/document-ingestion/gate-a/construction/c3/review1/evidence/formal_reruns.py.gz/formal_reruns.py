from pathlib import Path
import os,json,hashlib,subprocess,sys
s=Path(__file__).parent.resolve();repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');f=s/'formal';f.mkdir();h=f/'source/tests/readiness/ingest';h.mkdir(parents=True);base=Path('/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13');env={'PATH':'/usr/bin:/bin','HOME':os.environ.get('HOME',''),'GIT_OPTIONAL_LOCKS':'0'}
def git(*args):return subprocess.check_output(['/usr/bin/git',*args],cwd=repo,env=env)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(value,message):
 if not value:raise RuntimeError(message)
commit=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip();rows=[]
for item in git('ls-tree','-r','-z',commit,'--','tests/readiness/ingest').split(b'\0'):
 if not item:continue
 meta,path=item.split(b'\t',1);mode,kind,blob=meta.decode().split();path=path.decode();name=str(Path(path).relative_to('tests/readiness/ingest'));raw=git('cat-file','blob',blob);q=h/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw);q.chmod(0o444);rows.append({'path':name,'blob':blob,'sha256':sha(raw),'mode':mode})
m=f/'harness-manifest.json';require(commit=='5c37bf0382699cda2234e73407065f1a6455e2a6','Candidate moved'); approved=Path('/Users/chuckrussell/Dev/gendev/agent-framework/docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction/c3/harness-manifest.json'); require(sha(approved.read_bytes())=='688c258e9772403fde49bd646dc43f52613dc820ff4e70602ef2b02c0491c80e','Manifest changed'); require(rows==json.loads(approved.read_bytes())['files'],'Current committed selection differs'); m.write_bytes(approved.read_bytes());mh=sha(m.read_bytes());records=[]
def run(name,args,expected=0):
 argv=[str(base),'-I','-S','-B',*args];r=subprocess.run(argv,cwd=f,env=env,capture_output=True,text=True,timeout=120);records.append({'name':name,'argv':argv,'expected_exit':expected,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(f/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,r.stdout[-320:]);require(r.returncode==expected,'Unexpected result: '+name);return r
controls=['--harness-manifest',str(m),'--harness-manifest-sha256',mh]
for name,flags in [('normal',[]),('optimized',['-O'])]:
 scratch=f/('selftest-'+name);scratch.mkdir();r=run('selftest-'+name,[*flags,str(h/'bootstrap.py'),'selftest',*controls,'--scratch',str(scratch)]);require(json.loads(r.stdout)['cases']==57,'Unexpected selected test count')
 project=f/('unit-project-'+name);project.mkdir();control=f/('control-'+name+'.json');config={'schema':1,'project':str(project),'run_id':'manual-c1','harness_sha256':mh,'envelope_sha256':'4b6273c2a629affd02e388574a0b1715334456c921611e55e069122f7b0b4315','interpreter_sha256':sha(base.read_bytes()),'activation':'C0'};control.write_text(json.dumps(config,indent=2)+'\n');ch=sha(control.read_bytes());args=[*controls,'--config',str(control),'--config-sha256',ch];before=list(project.rglob('*'));run(name+'-preflight',[*flags,str(h/'bootstrap.py'),'preflight',*args]);require(before==list(project.rglob('*')),'Preflight wrote files')
 r=run(name+'-init',[*flags,str(h/'bootstrap.py'),'init',*args]);init=json.loads(r.stdout);frozen=Path(init['config']).parent.parent/'harness/run.py';args=['--harness-manifest',init['harness_manifest'],'--harness-manifest-sha256',mh,'--config',init['config'],'--config-sha256',init['config_sha256']]
 r=run(name+'-prepare-fixtures',[*flags,str(frozen),'prepare-fixtures',*args]);prepared=json.loads(r.stdout);manifest=Path(prepared['manifest']);require(prepared['fixture_count']==30 and prepared['converter_qualified'] is False and prepared['full_readiness'] is False,'Invalid preparation claim');require(sha(manifest.read_bytes())==prepared['manifest_sha256'],'Published manifest changed');inventory=json.loads(manifest.read_bytes());require(len(inventory['files'])==30,'Inventory incomplete')
 for row in inventory['files']:
  target=manifest.parent/row['file'];require(sha(target.read_bytes())==row['sha256'] and target.stat().st_size==row['bytes'] and target.stat().st_mode&0o222==0,'Published input mismatch')
 require(sha((manifest.parent/'oracles.json').read_bytes())==inventory['oracles_sha256'],'Oracle mismatch')
 run(name+'-repeat-refused',[*flags,str(frozen),'prepare-fixtures',*args],2)
 run(name+'-all-blocked',[*flags,str(frozen),'run','--stage','all',*args],3)
 r=run(name+'-report-incomplete',[*flags,str(frozen),'report',*args],3);require(json.loads(r.stdout)['prepared_inputs'][0]['current_bytes_revalidated'] is False,'Report overclaim')
 run(name+'-prepare-model-blocked',[*flags,str(frozen),'prepare-model',*args],3)
 run(name+'-stop',[*flags,str(frozen),'stop',*args]);run(name+'-stopped-effects-refuse',[*flags,str(frozen),'prepare-fixtures',*args],2);run(name+'-report-after-stop',[*flags,str(frozen),'report',*args],3)
summary={'source_commit':commit,'source_tree':tree,'manifest_sha256':mh,'bootstrap_sha256':sha((h/'bootstrap.py').read_bytes()),'interpreter':str(base),'interpreter_sha256':sha(base.read_bytes()),'selected_files':len(rows),'commands':len(records),'selftests':2,'cases_per_selftest':57,'manual_modes':2,'fixture_count_each':30,'actual_A0_A4':False,'actual_model_calls':0,'repo_friday_test_created':False};(f/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
