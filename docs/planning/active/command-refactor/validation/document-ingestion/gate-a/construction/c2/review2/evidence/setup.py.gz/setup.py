import json,os,hashlib,subprocess,ast,shutil
from pathlib import Path
S=Path(__file__).parent;R=Path('/Users/chuckrussell/Dev/gendev/agent-framework');P=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6');q=json.loads((P/'corrected-review-request.json').read_bytes());t=q['tool_inputs']
def sha(b):return hashlib.sha256(b).hexdigest()
def require(c,m):
 if not c:raise RuntimeError(m)
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
require(sha(Path(q['interpreter']).read_bytes())==q['interpreter_sha256'],'interpreter')
for k,v in t.items():
 if k.endswith('_sha256'):continue
 if k+'_sha256' in t:require(sha(Path(v).read_bytes())==t[k+'_sha256'],k)
for name,source in [('pyproject.toml','root_config'),('ruff','ruff'),('mypy-target-manifest.json','mypy_inventory'),('parser-inspection.json','parser_inspection')]:
 out=S/'validation-tools'/name;out.parent.mkdir(exist_ok=True);out.write_bytes(Path(t[source]).read_bytes())
(S/'validation-tools/ruff').chmod(0o755)
for key,invkey,count in [('mypy_target','mypy_inventory',1177),('parser_target','parser_inspection',23)]:
 source=Path(t[key]);inv=json.loads(Path(t[invkey]).read_bytes())['files'];require(len(inv)==count,'inventory count')
 actual={str(p.relative_to(source)):sha(p.read_bytes()) for p in source.rglob('*') if p.is_file()};require(actual==inv,'source '+key+' inventory');require(not any(p.is_symlink() for p in source.rglob('*')),'symlinks')
 dest=S/'validation-tools'/key.replace('_','-');dest.mkdir(exist_ok=True)
 for n,h in inv.items():
  require(not Path(n).is_absolute() and '..' not in Path(n).parts,'unsafe inventory path');f=dest/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((source/n).read_bytes());require(sha(f.read_bytes())==h,'copied hash')
for label,commit in [('candidate',q['candidate']),('unfixed',q['remediation']['unfixed_commit'])]:
 root=S/label;root.mkdir(exist_ok=True);records=[]
 for raw in git('ls-tree','-r','-z',commit,'--','tests/readiness/ingest').split(b'\0'):
  if not raw:continue
  spec,name=raw.split(b'\t',1);mode,kind,oid=spec.decode().split();require(mode=='100644' and kind=='blob','export regular-only');rel=name.decode().removeprefix('tests/readiness/ingest/');data=git('cat-file','blob',oid);f=root/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data);records.append({'path':rel,'mode':mode,'blob':oid,'sha256':sha(data)})
 selection_commit=q['source_commit'] if label=='candidate' else commit
 manifest={'schema':1,'commit':selection_commit,'tree':git('rev-parse',selection_commit+'^{tree}').decode().strip(),'files':records};out=S/(label+'-manifest.json');out.write_text(json.dumps(manifest,sort_keys=True,separators=(',',':')))
 require(sha((root/'bootstrap.py').read_bytes())==q['bootstrap_sha256'],'bootstrap')
 if label=='candidate':
  approved=json.loads(Path(q['source_manifest']).read_bytes());require(records==approved['files'] and manifest['tree']==approved['tree'],'approved candidate selection')
# Structural scope, frozen C1 receipt retention and exact test bodies: no historical report content.
paths=git('diff','--name-only',q['diff']).decode().splitlines();require(paths==sorted(q['changed_paths']),'exact changed paths')
(S/'candidate-paths.json').write_text(json.dumps(paths,indent=2))
for label,range_ in [('aggregate-source',q['diff']),('correction-source',q['remediation']['delta'])]:
 (S/(label+'.diff')).write_bytes(git('diff',range_,'--','tests/readiness/ingest'))
def tests(commit):
 result={}
 for row in git('ls-tree','-r','--name-only',commit,'--','tests/readiness/ingest/tests').decode().splitlines():
  text=git('show',commit+':'+row).decode();tree=ast.parse(text)
  for node in ast.walk(tree):
   if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name.startswith('test_'):result[row+':'+node.name]=ast.dump(node,include_attributes=False)
 return result
prior=tests(q['remediation']['unfixed_commit']);base=tests(q['base']);now=tests(q['candidate']);require(all(now.get(k)==v for k,v in prior.items()),'55 retained tests');require(all(now.get(k)==v for k,v in base.items()),'54 baseline tests')
c1=git('diff','--name-only',q['diff'],'--','docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction/c1').decode();require(not c1,'C1 immutable evidence')
result={'tool_files':{'typing':1177,'parser':23},'test_bodies':{'base':len(base),'prior':len(prior),'candidate':len(now),'unchanged':True},'exact_changed_paths':len(paths),'c1_evidence_unchanged':True,'exports':{label:{'manifest_sha256':sha((S/(label+'-manifest.json')).read_bytes()),'files':len(json.loads((S/(label+'-manifest.json')).read_bytes())['files'])} for label in ['candidate','unfixed']}}
(S/'setup.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
