"""Exact one-wheel transfer only, disabled until the frozen review has ended."""
from pathlib import Path
import base64,csv,datetime,email.parser,gzip,hashlib,http.client,io,json,os,ssl,stat,urllib.parse,zipfile
s=Path(__file__).parent.resolve();repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');profile=repo/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction/c1/private-resolver-tool-profile.json';expected='f81bc1edc54635a51dcb720fe6cc82e990affd85b73fc75c5b69be91698bffe6'
def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
require((s/'frozen-review-ended.json').is_file(),'Frozen review still active; do not activate')
raw=profile.read_bytes();require(sha(raw)==expected,'Approved profile changed');p=json.loads(raw);approval=json.loads((s/'approval.json').read_bytes());require(approval['profile_sha256']==expected and approval['verbatim_instruction']=='Approve private resolver-tool profile','Approval mismatch');target=Path(p['target']);cache=Path(p['cache']);require(not target.exists() and not cache.exists(),'Private target/cache already exists');require(target.parent.is_dir() and target.parent.resolve()==target.parent,'Private target ancestor mismatch')
prior=json.loads((repo/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction/c0/private-typecheck-approval.json').read_bytes());ca=Path(prior['bootstrap_ca']);ca_raw=ca.read_bytes();require(sha(ca_raw)==prior['bootstrap_ca_sha256'],'Previously qualified bootstrap CA changed')
artifact=p['artifacts'][0];url=urllib.parse.urlsplit(artifact['url']);require(len(p['artifacts'])==1 and p['requests']==1 and p['retries']==0 and artifact['bytes']==65451 and url.scheme=='https' and url.hostname=='files.pythonhosted.org' and url.port is None and not url.query and not url.fragment and not url.username,'Unexpected transfer profile')
attempt=s/'attempt.json';receipt={'profile_sha256':expected,'request_count':1,'retries':0,'payload_limit':65451,'effect_outcome':'unknown_or_in_progress','bootstrap_ca':str(ca),'bootstrap_ca_sha256':sha(ca_raw),'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with attempt.open('x') as stream:json.dump(receipt,stream,indent=2)
context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);context.load_verify_locations(cadata=ca_raw.decode());connection=http.client.HTTPSConnection(url.hostname,443,context=context,timeout=30)
try:
 connection.request('GET',url.path,headers={'Accept-Encoding':'identity','User-Agent':'Friday-private-resolver-tool/1'})
 response=connection.getresponse();require(response.status==200,'Status/redirect refused');require(response.getheader('Content-Encoding','identity')=='identity','Compressed transfer refused');data=response.read(65452)
finally:connection.close()
require(len(data)==65451 and sha(data)==artifact['sha256'],'Artifact byte/hash mismatch');cache.mkdir(mode=0o700);wheel_path=cache/Path(url.path).name
with wheel_path.open('xb') as stream:stream.write(data)
wheel_path.chmod(0o444)
with zipfile.ZipFile(io.BytesIO(data)) as wheel:
 names=wheel.namelist();infos=wheel.infolist();require(len(names)==len(set(names)) and len(names)<1000 and sum(x.file_size for x in infos)<4*1024*1024,'Wheel inventory limit');require(all(not x.is_dir() and not stat.S_ISLNK(x.external_attr>>16) and not Path(x.filename).is_absolute() and '..' not in Path(x.filename).parts and '\\' not in x.filename for x in infos),'Wheel member type/path refused');require(all(not x.endswith(('.pth','.egg-link','.pyc','.pyo','.so','.dylib')) and not Path(x).name.startswith(('sitecustomize.','usercustomize.')) and x.startswith(('packaging/','packaging-24.2.dist-info/')) for x in names),'Unqualified member/startup hook');metadata_name='packaging-24.2.dist-info/METADATA';record_name='packaging-24.2.dist-info/RECORD';require(metadata_name in names and record_name in names,'Missing wheel metadata');metadata=email.parser.BytesParser().parsebytes(wheel.read(metadata_name));require(metadata['Name']=='packaging' and metadata['Version']=='24.2' and not metadata.get_all('Requires-Dist',[]),'Distribution identity/dependencies mismatch');record={}
 for row in csv.reader(io.StringIO(wheel.read(record_name).decode())):
  require(len(row)==3 and row[0] not in record,'Invalid/duplicate RECORD');record[row[0]]=row[1:]
 require(set(record)==set(names),'RECORD inventory mismatch')
 inventory={}
 for name in names:
  contents=wheel.read(name);inventory[name]=sha(contents);encoded,size=record[name]
  if name==record_name:require(encoded=='' and size=='','RECORD self-entry must be blank')
  else:require(encoded=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(contents).digest()).rstrip(b'=').decode() and size==str(len(contents)),'RECORD hash/length mismatch')
 licenses=[name for name in names if '.dist-info/' in name and 'license' in Path(name).name.lower()];require(len(licenses)>=3,'Missing dual-license materials');license_text='\n'.join(wheel.read(name).decode() for name in licenses);require('Apache License' in license_text and 'Redistribution and use in source and binary forms' in license_text,'Unknown license materials')
 inspection={'profile_sha256':expected,'wheel_sha256':sha(data),'name':metadata['Name'],'version':metadata['Version'],'requires_python':metadata.get('Requires-Python'),'license':metadata.get('License'),'license_expression':metadata.get('License-Expression'),'license_files':{name:inventory[name] for name in licenses},'member_count':len(names),'record_verified':True,'startup_hooks':[],'files':inventory,'claim':'Inspected exact wheel, no Docling or actual stage activation'};(s/'inspection.json').write_text(json.dumps(inspection,indent=2)+'\n')
 target.mkdir(mode=0o700)
 for name in names:
  q=target/name;q.parent.mkdir(parents=True,exist_ok=True)
  with q.open('xb') as stream:stream.write(wheel.read(name))
  q.chmod(0o444)
receipt.update(effect_outcome='downloaded_inspected_extracted_not_executed',payload_bytes=len(data),wheel_sha256=sha(data),completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(s/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['effect_outcome'],'requests':1,'bytes':len(data),'target':str(target),'members':len(names),'inspection':str(s/'inspection.json')}))
