import pathlib,json,subprocess,os,hashlib,gzip,ast,shutil
S=pathlib.Path(__file__).parent;R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');uv='/opt/homebrew/bin/uv';P='/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13'
B=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-build-sqewgfmf');q=json.loads((B/'review-request.json').read_text())
# A private wrapper carries all required uv limits into the documentation check's nested board selector.
bin=S/'admin-bin';bin.mkdir();wrapper=bin/'uv';wrapper.write_text('#!/bin/sh\nif [ "$1" = run ]; then\n shift\n exec /opt/homebrew/bin/uv run --offline --frozen --no-sync --no-python-downloads --no-env-file "$@"\nfi\nexit 2\n');wrapper.chmod(0o700)
for n in ['admin-uv-cache','admin-config','admin-tmp','admin-data']:(S/n).mkdir()
env={'HOME':os.environ.get('HOME',''),'PATH':str(bin)+':/opt/homebrew/bin:/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_CACHE_DIR':str(S/'admin-uv-cache'),'UV_CONFIG_DIR':str(S/'admin-config'),'UV_CREDENTIALS_DIR':str(S/'admin-config/credentials'),'XDG_CACHE_HOME':str(S/'admin-uv-cache'),'XDG_CONFIG_HOME':str(S/'admin-config'),'XDG_DATA_HOME':str(S/'admin-data'),'TMPDIR':str(S/'admin-tmp'),'UV_OFFLINE':'1','UV_FROZEN':'1','UV_NO_SYNC':'1','UV_NO_PYTHON_DOWNLOADS':'1','UV_NO_ENV_FILE':'1'}
records=[]
def run(name,argv,expected=0):
 p=subprocess.run(argv,cwd=R,env=env,capture_output=True,text=True,timeout=120);row={'name':name,'argv':argv,'cwd':str(R),'exit':p.returncode,'expected_exit':expected,'stdout':p.stdout,'stderr':p.stderr};records.append(row);(S/'admin-commands.json').write_text(json.dumps(records,indent=2));print(json.dumps({'name':name,'exit':p.returncode,'stdout':p.stdout[-700:],'stderr':p.stderr[-200:]}),flush=True)
 if p.returncode!=expected:raise RuntimeError('admin failure '+name)
 return p
base=[str(wrapper),'run','python','-B']
run('board-validate',base+['scripts/friday-dev-board.py','validate'])
run('board-render-check',base+['scripts/friday-dev-board.py','render','--check'])
run('documentation-lifecycle',base+['scripts/check-documentation-lifecycle.py'])
run('package-metadata',base+['scripts/check-package-metadata.py'])
for name,args in [('owned-whitespace',['diff','--check','--','.gitignore','docs/planning','tests/readiness/ingest']),('cached-whitespace',['diff','--cached','--check']),('range-whitespace',['diff','--check',q['base'],q['candidate'],'--'])]:run(name,['git',*args])
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=env)
changed=git('diff','--name-only',q['base'],q['candidate']).decode().splitlines()
if changed!=sorted(q['changed_paths']):raise RuntimeError('changed path mismatch')
# Compare each original unittest body exactly as source text, independent of supplied retention receipt.
retained=[]
for p in sorted((S/'export-harness/tests').glob('test_*.py')):
 rel='tests/readiness/ingest/tests/'+p.name;old=git('show',q['base']+':'+rel).decode();new=p.read_text()
 def tests(src):
  return {n.name:ast.get_source_segment(src,n) for n in ast.walk(ast.parse(src)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')}
 before=tests(old);after=tests(new)
 for name,body in before.items():
  if after.get(name)!=body:raise RuntimeError('old test changed '+rel+':'+name)
 retained += [rel+':'+n for n in before]
if len(retained)!=43:raise RuntimeError('43 retained required')
# Hash pairs only; do not read builder conclusions as correctness evidence.
C=R/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction/c1';pairs=[]
for item in json.loads((C/'evidence/index.json').read_text()):
 raw=(C/item['path']).read_bytes();expanded=gzip.decompress(raw)
 if hashlib.sha256(raw).hexdigest()!=item['gzip_sha256'] or hashlib.sha256(expanded).hexdigest()!=item['raw_sha256']:raise RuntimeError('evidence hash mismatch')
 pairs.append({'path':item['path'],'raw_bytes':len(expanded),'raw_sha256':item['raw_sha256'],'gzip_sha256':item['gzip_sha256']})
# Assert source commit and candidate select identical harness bytes; no executable C0 guard changes.
unchanged=[]
for f in json.loads((S/'candidate-manifest.json').read_text())['files']:
 rel='tests/readiness/ingest/'+f['path']
 if git('show',q['source_commit']+':'+rel)!=git('show',q['candidate']+':'+rel):raise RuntimeError('source/candidate harness drift')
 if f['path'] not in ['README.md','fixtures.py','fixtures/expectations.json','ledger.py','stages.py','reports.py','tests/test_cli.py','tests/test_fixtures.py','tests/test_ledger.py','tests/test_reports.py']:
  if git('show',q['base']+':'+rel)!=git('show',q['candidate']+':'+rel):raise RuntimeError('unpermitted runtime delta')
  unchanged.append(rel)
(S/'administration-audit.json').write_text(json.dumps({'changed_paths':changed,'retained_test_bodies':retained,'retained_count':len(retained),'evidence_pairs':pairs,'unchanged_runtime_paths':unchanged,'source_commit_equals_candidate_harness':True},indent=2))
print(json.dumps({'changed_paths':len(changed),'retained_test_bodies':len(retained),'evidence_pairs':len(pairs),'unchanged_runtime_paths':len(unchanged)}))
