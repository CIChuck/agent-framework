import pathlib,json,hashlib,shlex,datetime
S=pathlib.Path(__file__).parent;B=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-build-sqewgfmf');q=json.loads((B/'review-request.json').read_text());t=q['tool_inputs'];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
closing=json.loads((S/'closing-summary.json').read_text())
if not closing['unchanged']:raise RuntimeError('closing drift')
for key in ['ruff','root_config','mypy_inventory','mypy_launcher']:
 if h(pathlib.Path(t[key]))!=t[key+'_sha256']:raise RuntimeError('supplied tool changed')
inv=json.loads(pathlib.Path(t['mypy_inventory']).read_text())
for root in [pathlib.Path(t['mypy_target']),S/'validation-tools/mypy-target']:
 if set(inv['files'])!={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}:raise RuntimeError('tool target file set changed')
 for rel,sha in inv['files'].items():
  if h(root/rel)!=sha:raise RuntimeError('tool target changed')
if h(B/'review-request.json')!='8bc06f8b0bd755ae2394102330f645daf132ed9fc42759d0823634814cbc3b56' or h(B/'review-boundary.json')!=q['boundary_sha256']:raise RuntimeError('input changed')
m=json.loads((S/'candidate-manifest.json').read_text())
for f in m['files']:
 p=S/'export-harness'/f['path']
 if h(p)!=f['sha256'] or p.stat().st_mode&0o222:raise RuntimeError('private export changed/writable')
normal=json.loads((S/'independent-normal-final.stdout').read_text());optimized=json.loads((S/'independent-optimized-final.stdout').read_text())
for x in [normal,optimized]:
 if not x['success'] or x['tests']!=8 or x['application_modules']:raise RuntimeError('independent lane failure')
summary={'reviewer':'fresh native validator /root/ingest_c1_independent_validation','model':'GPT-6 agent; precise serving model identifier not exposed','date_utc':datetime.datetime.now(datetime.UTC).isoformat(),'verdict':'VERIFIED','advisory_score':9.2,'candidate':q['candidate'],'base':q['base'],'source_commit':q['source_commit'],'candidate_tree':m['tree'],'harness_manifest_sha256':h(S/'candidate-manifest.json'),'exported_files':len(m['files']),'selftest_cases_each':54,'independent_cases_each':8,'independent_refusal_witnesses_each':len(normal['independent_refusal_witnesses']),'all_shared_boundaries_unchanged':True,'supplied_tool_target_files_unchanged':len(inv['files']),'private_tool_target_files_unchanged':len(inv['files']),'manual_matrix_sha256':json.loads((S/'manual-summary.json').read_text())['manifest']['manifest_sha256'],'optimized_manual_matrix_sha256':json.loads((S/'optimized-manual-summary.json').read_text())['manifest']['manifest_sha256'],'report_scope':'C1 synthetic input preparation delta first; full bounded retained offline-controls/input-preparation aggregate; no full A0-A4 readiness'}
(S/'final-audit.json').write_text(json.dumps(summary,indent=2))
records=[]
for name in ['selftest-normal','selftest-optimized','ruff-check','ruff-format','mypy']:
 records.append(json.loads((S/(name+'.json')).read_text()))
for p in sorted(S.glob('manual-*.json'))+sorted(S.glob('optimized-manual-*.json')):
 x=json.loads(p.read_text())
 if isinstance(x,dict) and 'argv' in x:records.append(x)
records.extend(json.loads((S/'admin-commands.json').read_text()))
for rec in records:
 if rec['exit']!=rec['expected_exit']:raise RuntimeError('unexpected command exit')
 if any(str(B) in a for a in rec['argv']):raise RuntimeError('supplied scratch in execution argv')
lines=['# Exact executed validation commands','','All generated outputs, configuration, temporary paths and caches are reviewer-owned. The administration lane reads the existing checkout and working interpreter under the controller clarification, without sync/install or product imports.','']
for r in records:
 lines += ['## '+r['name'],'','cwd: `'+r['cwd']+'`; exit '+str(r['exit'])+' (expected '+str(r['expected_exit'])+').','','```text',shlex.join(r['argv']),'```','']
for opt,lane in [(False,'normal'),(True,'optimized')]:
 lines += ['## Independent assertions '+lane,'','cwd: repository; exit 0. stdout/stderr retained as `independent-'+lane+'-final.stdout` and `.stderr`.','','```text',shlex.join([q['interpreter'],'-I','-S','-B']+(['-O'] if opt else [])+[str(S/'independent-final.py')]),'```','']
(S/'command-appendix.md').write_text('\n'.join(lines))
print(json.dumps(summary,indent=2))
