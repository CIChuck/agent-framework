import pathlib,json,hashlib,subprocess,os,sys,shutil
S=pathlib.Path(__file__).parent;R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');P='/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13'; E=S/'export-harness';M=S/'candidate-manifest.json';MH=hashlib.sha256(M.read_bytes()).hexdigest();T=S/'validation-tools'
env={'HOME':os.environ.get('HOME',''),'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0','TMPDIR':str(S/'static-tmp'),'XDG_CACHE_HOME':str(S/'home-cache'),'XDG_CONFIG_HOME':str(S/'config'),'MYPY_CACHE_DIR':str(T/'mypy-cache'),'MYPYPATH':str(S/'typing-source-final')}
def run(name,args,expected=0,cwd=S):
    p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True,timeout=120)
    row={'name':name,'argv':args,'cwd':str(cwd),'exit':p.returncode,'expected_exit':expected,'stdout':p.stdout,'stderr':p.stderr}
    (S/(name+'.json')).write_text(json.dumps(row,indent=2));print(json.dumps({'name':name,'exit':p.returncode,'expected':expected,'stdout':p.stdout[-800:],'stderr':p.stderr[-300:]}),flush=True)
    if p.returncode!=expected: raise RuntimeError('unexpected exit '+name)
    return p
if sys.argv[1]=='tests':
    for opt,which in [(False,'normal'),(True,'optimized')]:
        run('selftest-'+which,[P,'-I','-S','-B','-O']+(['-O'] if opt else [])+[str(E/'run.py'),'selftest','--harness-manifest',str(M),'--harness-manifest-sha256',MH,'--scratch',str(S/('selftest-'+which+'-final'))])
elif sys.argv[1]=='manual':
    config={'schema':1,'project':str(S/'optimized-manual-project-optimized'),'run_id':'independent-c1','harness_sha256':MH,'envelope_sha256':'4b6273c2a629affd02e388574a0b1715334456c921611e55e069122f7b0b4315','interpreter_sha256':'e2adf1814122d8b26166917ef7d294d7426963e0f59e28d0d5aef773f67c4bb0','activation':'C0'}
    c=S/'optimized-manual-control.json';c.write_text(json.dumps(config));ch=hashlib.sha256(c.read_bytes()).hexdigest()
    args=['--harness-manifest',str(M),'--harness-manifest-sha256',MH,'--config',str(c),'--config-sha256',ch]
    before=sorted(str(p.relative_to(S/'optimized-manual-project-optimized')) for p in (S/'optimized-manual-project-optimized').rglob('*'))
    run('optimized-manual-preflight',[P,'-I','-S','-B','-O',str(E/'bootstrap.py'),'preflight',*args])
    if before!=sorted(str(p.relative_to(S/'optimized-manual-project-optimized')) for p in (S/'optimized-manual-project-optimized').rglob('*')): raise RuntimeError('preflight created state')
    init=json.loads(run('optimized-manual-init',[P,'-I','-S','-B','-O',str(E/'bootstrap.py'),'init',*args]).stdout)
    root=pathlib.Path(init['config']).parents[1];args=['--harness-manifest',init['harness_manifest'],'--harness-manifest-sha256',MH,'--config',init['config'],'--config-sha256',init['config_sha256']]
    entry=[P,'-I','-S','-B','-O',str(root/'harness/run.py')]
    out=json.loads(run('optimized-manual-prepare',entry+['prepare-fixtures',*args]).stdout)
    dest=pathlib.Path(out['manifest']).parent
    if hashlib.sha256((dest/'manifest.json').read_bytes()).hexdigest()!=out['manifest_sha256']:raise RuntimeError('manual digest')
    man=json.loads((dest/'manifest.json').read_text())
    for row in man['files']:
        path=dest/row['file'];data=path.read_bytes()
        if hashlib.sha256(data).hexdigest()!=row['sha256'] or len(data)!=row['bytes'] or path.stat().st_mode&0o222: raise RuntimeError('manual input')
    run('optimized-manual-prepare-repeat',entry+['prepare-fixtures',*args],2)
    run('optimized-manual-report',entry+['report',*args],3)
    for stage in ['all','A0','A1','A2','A3','A4']: run('optimized-manual-blocked-'+stage,entry+['run','--stage',stage,*args],3)
    run('optimized-manual-blocked-model',entry+['prepare-model',*args],3)
    run('optimized-manual-stop',entry+['stop',*args])
    run('optimized-manual-stopped-prepare',entry+['prepare-fixtures',*args],2)
    run('optimized-manual-stopped-report',entry+['report',*args],3)
    (S/'optimized-manual-summary.json').write_text(json.dumps({'frozen_root':str(root),'manifest':out,'no_preflight_state':True,'verified_input_hashes':30,'events':[json.loads(x)['event'] for x in (root/'state/bindings.jsonl').read_text().splitlines()]},indent=2))
elif sys.argv[1]=='static':
    copy=S/'typing-source-final/ingest';shutil.copytree(E,copy)
    paths=sorted(str(p) for p in copy.rglob('*.py'))
    if len(paths)!=25:raise RuntimeError('wrong static selection')
    (S/'static-selection.json').write_text(json.dumps(paths,indent=2))
    run('ruff-check',[str(T/'ruff'),'check','--config',str(T/'pyproject.toml'),'--cache-dir',str(T/'ruff-cache'),*paths])
    run('ruff-format',[str(T/'ruff'),'format','--check','--config',str(T/'pyproject.toml'),'--cache-dir',str(T/'ruff-cache'),*paths])
    run('mypy',[P,'-I','-S','-B','-O',str(S/'private-mypy.py'),str(T/'mypy-target'),str(copy),str(M),MH,'70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c','--config-file',str(T/'pyproject.toml'),'--no-site-packages','--explicit-package-bases','--cache-dir',str(T/'mypy-cache'),*paths])
