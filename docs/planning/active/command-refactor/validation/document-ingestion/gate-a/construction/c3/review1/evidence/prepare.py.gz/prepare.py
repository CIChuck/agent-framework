import ast,gzip,hashlib,json,pathlib,shutil,subprocess
S=pathlib.Path(__file__).parent.resolve();Q=json.loads((S/'request.json').read_bytes());R=pathlib.Path(Q['repo']);P=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-resolver-engine-fsiunmow')
def sha(b):return hashlib.sha256(b).hexdigest()
def require(x,m):
 if not x:raise RuntimeError(m)
def git(*a):return subprocess.check_output(['/usr/bin/git',*a],cwd=R,env={'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0'})
checks={}
for k,v in Q['tool_inputs'].items():
 t=S/'validation-tools'/pathlib.Path(v['root']).name;shutil.copytree(v['root'],t);got={str(p.relative_to(t)):sha(p.read_bytes()) for p in t.rglob('*') if p.is_file()};require(got==v['files'],k+' copy inventory');checks[k]={'files':len(got),'matched':True}
for name in ['ruff','pyproject.toml']:
 shutil.copy2(P/'validation-tools'/name,S/'validation-tools'/name)
for name in ['parser-inspection.json','inspection.json','run_private_mypy.py','profile_worker.py','formal_static.py']:
 shutil.copy2(P/name,S/name)
raw=(P/'formal_reruns.py').read_text();raw=raw.replace("m.write_text(json.dumps({'schema':1,'commit':commit,'tree':tree,'files':rows},sort_keys=True,separators=(',',':')))","require(commit=='5c37bf0382699cda2234e73407065f1a6455e2a6','Candidate moved'); approved=Path("+repr(Q['source_manifest'])+"); require(sha(approved.read_bytes())=='"+Q['source_manifest_sha256']+"','Manifest changed'); require(rows==json.loads(approved.read_bytes())['files'],'Current committed selection differs'); m.write_bytes(approved.read_bytes())")
require(raw!=(P/'formal_reruns.py').read_text(),'Adaptation missing');(S/'formal_reruns.py').write_text(raw)
# Verify all retained unittest bodies at the exact base without executing the baseline.
old={};new={}
for item in git('ls-tree','-r','--name-only',Q['base'],'--','tests/readiness/ingest/tests').decode().splitlines():
 if not item.endswith('.py'):continue
 for target,commit in [(old,Q['base']),(new,Q['candidate'])]:
  source=git('show',commit+':'+item).decode();tree=ast.parse(source)
  for cls in tree.body:
   if isinstance(cls,ast.ClassDef):
    for f in cls.body:
     if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'):
      body='\n'.join(source.splitlines()[f.body[0].lineno-1:f.body[-1].end_lineno]); target[(item,cls.name,f.name)]=sha(body.encode())
require(len(old)==56,'Prior count');require(all(new.get(k)==v for k,v in old.items()),'Changed prior test bodies');checks['retained_tests']={'prior':len(old),'current':len(new),'all_bodies_identical':True}
# Hash audit current gzip evidence only; never load builder result conclusions.
C=R/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction/c3';pairs=[]
for folder in ['evidence','tool-evidence']:
 for row in json.loads((C/folder/'index.json').read_bytes()):
  q=C/row['path'] if folder=='evidence' else C/folder/row['path'];packed=q.read_bytes();unpacked=gzip.decompress(packed);require(sha(packed)==row['gzip_sha256'] and sha(unpacked)==row['raw_sha256'],'Gzip pair mismatch '+str(q));pairs.append({'path':str(q.relative_to(R)),'gzip_sha256':sha(packed),'raw_sha256':sha(unpacked)})
checks['current_gzip_pairs']=pairs
checks['source_changed_paths']=git('diff','--name-only',Q['base'],Q['candidate']).decode().splitlines();require(checks['source_changed_paths']==Q['changed_paths'],'Changed path mismatch')
(S/'preparation.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({'private_targets':{k:v for k,v in checks.items() if k in ['mypy','parser','engine']},'retained_tests':checks['retained_tests'],'gzip_pairs':len(pairs),'changed_paths':len(checks['source_changed_paths'])}))
