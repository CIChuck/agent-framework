import os,sys,json,hashlib,subprocess,stat
from pathlib import Path
ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework'); SCR=Path(__file__).parent
REQUEST=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6/corrected-review-request.json')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
def meta(p):
 try:s=p.lstat()
 except FileNotFoundError:return {'absent':True}
 d={'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'birthtime':s.st_birthtime}
 if stat.S_ISREG(s.st_mode):d['sha256']=sha(p.read_bytes())
 elif stat.S_ISLNK(s.st_mode):d['symlink']=os.readlink(p)
 return d
r=json.loads(REQUEST.read_bytes());b=json.loads(Path(r['boundary']).read_bytes())
idx=sha(git('ls-files','-s','-z'))
tracked={};links={}
for raw in git('ls-files','-z').split(b'\0'):
 if not raw:continue
 s=os.fsdecode(raw);p=ROOT/s
 if p.is_symlink():links[s]=os.readlink(p)
 elif p.is_file():tracked[s]=sha(p.read_bytes())
 else:pass  # gitlink excluded from regular-file boundary; logical index binds it
d={'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'logical_before_status':idx,'status':git('status','--short','--untracked-files=normal').decode(),'tracked':tracked,'symlinks':links,'preserved':{p:meta(ROOT/p) for p in b['preserved']},'pins':{p:sha((ROOT/p).read_bytes()) for p in r['pins']}}
inputs={str(REQUEST):meta(REQUEST),r['boundary']:meta(Path(r['boundary'])),r['interpreter']:meta(Path(r['interpreter']))}
t=r['tool_inputs']
for k,v in t.items():
 if k.endswith('_sha256'):continue
 p=Path(v)
 if p.is_file():inputs[v]=meta(p)
 elif p.is_dir():
  for f in sorted(p.rglob('*')):
   if f.is_file() or f.is_symlink():inputs[str(f)]=meta(f)
d['supplied_inputs']=inputs
out=SCR/(sys.argv[1]+'.json');out.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
print(json.dumps({'snapshot':str(out),'sha256':sha(out.read_bytes()),'tracked':len(tracked),'symlinks':len(links),'metadata':len(d['preserved']),'boundary_matches':{k:d[k]==b[k] for k in ['head','branch','logical_before_status','status','tracked','symlinks','preserved']},'pins_match':d['pins']==r['pins'],'supplied_files':len(inputs)}))
