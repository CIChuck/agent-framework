"""One approved transfer, exact inventory inspection, no library execution."""
from pathlib import Path
import base64,csv,datetime,email.parser,hashlib,http.client,io,json,ssl,stat,urllib.parse,zipfile
s=Path(__file__).parent.resolve();repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');profile=repo/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction/c3/private-resolver-engine-profile.json';expected='a9c64ca1ccc63ebe54c26108bc58c033792905394736fe048f29e84d74103a0f'
def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
p_raw=profile.read_bytes();require(sha(p_raw)==expected,'Approved profile changed');p=json.loads(p_raw);approval=json.loads((s/'approval.json').read_bytes());require(approval['profile_sha256']==expected and approval['verbatim_instruction']=='Approve private resolver-engine profile','Approval mismatch');target=Path(p['target']);cache=Path(p['cache']);require(not target.exists() and not cache.exists(),'Private target/cache already exists');target.parent.mkdir(mode=0o700,exist_ok=True);require(target.parent.resolve()==target.parent,'Private target alias')
prior=json.loads((repo/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction/c0/private-typecheck-approval.json').read_bytes());ca=Path(prior['bootstrap_ca']);ca_raw=ca.read_bytes();require(sha(ca_raw)==prior['bootstrap_ca_sha256'],'Qualified bootstrap CA changed')
artifact=p['artifacts'][0];url=urllib.parse.urlsplit(artifact['url']);require(len(p['artifacts'])==1 and p['requests']==1 and p['retries']==0 and artifact['bytes']==18737 and url.scheme=='https' and url.hostname=='files.pythonhosted.org' and url.port is None and not url.username and not url.query and not url.fragment,'Unexpected transfer profile')
receipt={'profile_sha256':expected,'requests':1,'retries':0,'payload_limit_bytes':18737,'effect_outcome':'unknown_or_in_progress','bootstrap_ca':str(ca),'bootstrap_ca_sha256':sha(ca_raw),'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (s/'attempt.json').open('x') as stream:json.dump(receipt,stream,indent=2)
context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);context.load_verify_locations(cadata=ca_raw.decode());connection=http.client.HTTPSConnection(url.hostname,443,context=context,timeout=30)
try:
 connection.request('GET',url.path,headers={'Accept-Encoding':'identity','User-Agent':'Friday-private-resolver-engine/1'});response=connection.getresponse();require(response.status==200,'Status/redirect refused');require(response.getheader('Content-Encoding','identity')=='identity','Compressed transfer refused');data=response.read(18738)
finally:connection.close()
require(len(data)==18737 and sha(data)==artifact['sha256'],'Wheel size/hash mismatch');cache.mkdir(mode=0o700);wheel_path=cache/Path(url.path).name
with wheel_path.open('xb') as stream:stream.write(data)
wheel_path.chmod(0o444)
with zipfile.ZipFile(io.BytesIO(data)) as wheel:
 names=wheel.namelist();infos=wheel.infolist();require(len(names)==len(set(names)) and len(names)<1000 and sum(x.file_size for x in infos)<4*1024*1024,'Wheel inventory bound');require(all(not x.is_dir() and not stat.S_ISLNK(x.external_attr>>16) and not Path(x.filename).is_absolute() and '..' not in Path(x.filename).parts and '\\' not in x.filename for x in infos),'Wheel type/path refused');require(all(not x.endswith(('.pth','.egg-link','.pyc','.pyo','.so','.dylib')) and not Path(x).name.startswith(('sitecustomize.','usercustomize.')) and x.startswith(('resolvelib/','resolvelib-1.2.1.dist-info/')) for x in names),'Unqualified member/startup hook');metadata_name='resolvelib-1.2.1.dist-info/METADATA';record_name='resolvelib-1.2.1.dist-info/RECORD';require(metadata_name in names and record_name in names,'Missing wheel metadata');metadata=email.parser.BytesParser().parsebytes(wheel.read(metadata_name));require(metadata['Name']=='resolvelib' and metadata['Version']=='1.2.1','Distribution identity mismatch');record={}
 for row in csv.reader(io.StringIO(wheel.read(record_name).decode())):
  require(len(row)==3 and row[0] not in record,'Invalid/duplicate RECORD');record[row[0]]=row[1:]
 require(set(record)==set(names),'RECORD inventory mismatch');inventory={}
 for name in names:
  contents=wheel.read(name);inventory[name]=sha(contents);encoded,size=record[name]
  if name==record_name:require(encoded=='' and size=='','RECORD self entry')
  else:require(encoded=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(contents).digest()).rstrip(b'=').decode() and size==str(len(contents)),'RECORD byte/hash mismatch')
 licenses=[name for name in names if '.dist-info/' in name and 'license' in Path(name).name.lower()];require(bool(licenses),'Missing license materials');license_text='\n'.join(wheel.read(name).decode() for name in licenses);require('Permission to use, copy, modify' in license_text and 'THE SOFTWARE IS PROVIDED' in license_text,'Unresolved ISC license materials')
 inspection={'profile_sha256':expected,'wheel':str(wheel_path),'wheel_sha256':sha(data),'name':metadata['Name'],'version':metadata['Version'],'requires_python':metadata.get('Requires-Python'),'requires_dist':metadata.get_all('Requires-Dist',[]),'license':metadata.get('License'),'license_expression':metadata.get('License-Expression'),'license_files':{name:inventory[name] for name in licenses},'member_count':len(names),'record_verified':True,'startup_hooks':[],'files':inventory,'status':'DOWNLOADED_INSPECTED_NOT_EXTRACTED_NOT_EXECUTED'};(s/'inspection.json').write_text(json.dumps(inspection,indent=2)+'\n')
receipt.update(effect_outcome=inspection['status'],payload_bytes=len(data),completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(s/'download.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:inspection[k] for k in ['status','name','version','member_count','requires_python','requires_dist','license','license_expression','license_files']}))
