from pathlib import Path
import hashlib,json,sys,types
s=Path(__file__).parent.resolve();h=Path(sys.argv[1]);m=Path(sys.argv[2]);expected=sys.argv[3];selector=sys.argv[4]
def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
require(sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode,'Use -I -S -B')
roots=[]
for dirname,inventory_name in [('packaging-target','parser-inspection.json'),('resolver-target','inspection.json')]:
 target=s/'validation-tools'/dirname;inventory=json.loads((s/inventory_name).read_bytes());require({str(p.relative_to(target)):sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}==inventory['files'] and all(not p.is_symlink() for p in target.rglob('*')),'Private tool inventory mismatch');roots.append(target)
raw=(h/'bootstrap.py').read_bytes();require(sha(raw)=='70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c','Unapproved bootstrap');ns={'__name__':'private_bootstrap','__file__':str(h/'bootstrap.py')};exec(compile(raw,str(h/'bootstrap.py'),'exec',dont_inherit=True),ns);buffers=ns['verified_buffers'](h,m,expected);pkg=types.ModuleType('ingest');pkg.__path__=[];pkg.__dict__.update(ROOT=h,BUFFERS=buffers);sys.modules['ingest']=pkg;tests=types.ModuleType('ingest.tests');tests.__path__=[];sys.modules['ingest.tests']=tests;sys.meta_path.insert(0,ns['Buffers'](h,buffers));from ingest.startup import Guard,guarded
sys.path[:0]=[str(p) for p in roots];policy=Guard((s,h,Path(sys.base_prefix).resolve()/'lib',Path(sys.executable).resolve()),())
with guarded(policy):
 from ingest.tests.test_manifests import dependency_cases,catalog_cases
 require(selector in {'parser','engine'},'Unknown private selector');result=dependency_cases() if selector=='parser' else catalog_cases()
 for dirname,inventory_name in [('packaging-target','parser-inspection.json'),('resolver-target','inspection.json')]:
  target=s/'validation-tools'/dirname;inventory=json.loads((s/inventory_name).read_bytes());require({str(p.relative_to(target)):sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}==inventory['files'] and all(not p.is_symlink() for p in target.rglob('*')),'Private target changed during execution')
 origins={name:module.__file__ for name,module in sys.modules.items() if name=='packaging' or name.startswith('packaging.') or name=='resolvelib' or name.startswith('resolvelib.')};require(all((roots[0] if name.startswith('packaging') else roots[1]) in Path(path).resolve().parents for name,path in origins.items()),'Private import origin mismatch')
result.update(selector=selector,optimized=bool(sys.flags.optimize),source_manifest_sha256=expected,engine_profile_sha256='a9c64ca1ccc63ebe54c26108bc58c033792905394736fe048f29e84d74103a0f',origins=origins,network_requests=0,artifact_transfers=0);print(json.dumps(result))
