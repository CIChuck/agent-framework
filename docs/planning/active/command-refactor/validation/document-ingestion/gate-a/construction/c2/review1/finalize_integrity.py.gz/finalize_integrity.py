from pathlib import Path
import json,hashlib,gzip,subprocess,sys,datetime
s=Path(__file__).parent.resolve();req=json.loads((s/'request.json').read_bytes());root=Path(req['repo'])/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(ok,msg):
 if not ok:raise RuntimeError(msg)
audited=[]
for index,relative_root in [(root/'c0/evidence-index.json',root/'c0'),(root/'c0/closeout-evidence/index.json',root/'c0/closeout-evidence'),(root/'c1/evidence/index.json',root/'c1'),(root/'c2/evidence/index.json',root/'c2')]:
 for row in json.loads(index.read_bytes()):
  path=relative_root/row['path'];compressed=path.read_bytes();payload=gzip.decompress(compressed);expected_compressed=row.get('gzip_sha256',row.get('compressed_sha256'));expected_raw=row.get('raw_sha256',row.get('uncompressed_sha256',row.get('sha256')));require(sha(compressed)==expected_compressed and sha(payload)==expected_raw,'raw/gzip pair mismatch '+str(path));audited.append(dict(path=str(path),gzip_sha256=expected_compressed,raw_sha256=expected_raw))
require(len(audited)==41,'evidence pair count');(s/'aggregate-evidence-audit.json').write_text(json.dumps({'mode':'hash-only inspection; no historical report or conclusion adopted','pairs':audited},indent=2)+'\n')
inputs=json.loads((s/'inputs-opening.json').read_bytes());changed=[p for p,digest in inputs.items() if sha(Path(p).read_bytes())!=digest]
for name,expected in [('review-request.json','06787f8adda6242076fbd0175287f22f3124e8aaa9be6c7ad6e58f904837252b'),('review-boundary.json',req['boundary_sha256'])]:require(sha((Path(req['boundary']).parent/name).read_bytes())==expected,'request/boundary changed')
setup=json.loads((s/'setup.json').read_bytes());h=Path(setup['export']);manifest=json.loads(Path(setup['manifest']).read_bytes())
for row in manifest['files']:require(sha((h/row['path']).read_bytes())==row['sha256'],'export changed '+row['path'])
for name,copydir in [('mypy_inventory','mypy-target'),('parser_inspection','parser-target')]:
 inv=json.loads((s/(name+'.json')).read_bytes());target=s/'validation-tools'/copydir;require({str(p.relative_to(target)) for p in target.rglob('*') if p.is_file()}==set(inv['files']),'private tool extras')
 for path,expected in inv['files'].items():require(sha((target/path).read_bytes())==expected,'private tool changed '+path)
require(not changed,'supplied input changed');(s/'input-closing.json').write_text(json.dumps(dict(checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),supplied_tool_files=len(inputs),copied_typingfiles=1177,copied_parserfiles=23,exported_files=29,changed=changed),indent=2)+'\n')
argv=[sys.executable,'-I','-S','-B',str(s/'snapshot.py'),'closing'];r=subprocess.run(argv,capture_output=True,text=True);result=dict(argv=argv,exit=r.returncode,stdout=r.stdout,stderr=r.stderr,evidence_pairs=len(audited),supplied_paths=len(inputs));(s/'final-integrity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));require(r.returncode==0,'closing repo check failed');require(json.loads((s/'opening.json').read_bytes())==json.loads((s/'closing.json').read_bytes()),'opening/closing differ')
