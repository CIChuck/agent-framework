from ingest.manifests import dependency_selection

def witnesses():
 environment={'implementation_name':'cpython','implementation_version':'3.13.10','os_name':'posix','platform_machine':'arm64','platform_release':'declared','platform_system':'Darwin','platform_version':'declared','python_full_version':'3.13.10','platform_python_implementation':'CPython','python_version':'3.13','sys_platform':'darwin'}
 results=[]
 for tag in ['py3--any','py3-none-']:
  filename='a-1.0-'+tag+'.whl'
  wheel=dict(name='a',version='1.0',filename=filename,url='https://files.pythonhosted.org/'+filename,sha256='f'*64,size=70,license='DECLARED ONLY',requires_python='>=3.13,<3.14',requires_dist=[],provides_extra=[],yanked=False)
  value=dict(schema=1,roots=['a'],environment=environment,tags=[tag],wheels=[wheel]);results.append(dict(input=value,observed=dependency_selection(value),required='Refusal'))
 return results
