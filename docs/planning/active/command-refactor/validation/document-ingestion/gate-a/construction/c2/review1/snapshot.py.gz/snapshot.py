import pathlib,json,subprocess,os,hashlib,sys,stat
repo=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); scratch=pathlib.Path(__file__).parent; req=json.loads((scratch/'request.json').read_bytes()); ref=json.loads((scratch/'boundary-reference.json').read_bytes()); env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
def git(*args): return subprocess.check_output(['git',*args],cwd=repo,env=env)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
logical=hashlib.sha256(git('ls-files','-s','-z')).hexdigest()
head=git('rev-parse','HEAD').decode().strip(); branch=git('branch','--show-current').decode().strip(); status=git('status','--short','--untracked-files=normal').decode()
tracked={}; symlinks={}
for name in git('ls-files','-z').decode().split('\0'):
 if not name: continue
 p=repo/name
 if p.is_symlink(): symlinks[name]=os.readlink(p)
 elif p.is_file(): tracked[name]=sha(p)
preserved={}
for name in ref['preserved']:
 p=repo/name
 if not p.exists() and not p.is_symlink():
  preserved[name]={'absent': True}; continue
 s=p.lstat(); v=dict(mode=s.st_mode,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,birthtime=s.st_birthtime)
 if stat.S_ISREG(s.st_mode): v['sha256']=sha(p)
 if stat.S_ISLNK(s.st_mode): v['target']=os.readlink(p)
 preserved[name]=v
pins={name:sha(repo/name) for name in req['pins']}
snapshot=dict(head=head,branch=branch,logical_before_status=logical,status=status,tracked=tracked,symlinks=symlinks,preserved=preserved,pins=pins)
label=sys.argv[1]; (scratch/(label+'.json')).write_text(json.dumps(snapshot,sort_keys=True,indent=2)+'\n')
errors=[k for k in ('head','branch','logical_before_status','status','tracked','symlinks','preserved') if snapshot[k]!=ref[k]]
errors += ['pin:'+k for k,v in pins.items() if v!=req['pins'][k]]
print(json.dumps(dict(label=label,head=head,branch=branch,logical_before_status=logical,status=status,tracked=len(tracked),symlinks=len(symlinks),preserved=list(preserved),errors=errors)))
if errors: raise SystemExit(1)
