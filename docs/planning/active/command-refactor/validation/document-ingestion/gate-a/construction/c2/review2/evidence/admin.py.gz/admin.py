from commands import *
for p in ['uv-config','uv-credentials','xdg-data']:(S/p).mkdir(exist_ok=True)
ENV.update(UV_CONFIG_DIR=str(S/'uv-config'),UV_CREDENTIALS_DIR=str(S/'uv-credentials'),UV_KEYRING_PROVIDER='disabled',UV_NO_ENV_FILE='1',XDG_DATA_HOME=str(S/'xdg-data'))
base=['uv','run','--offline','--frozen','--no-sync','--no-python-downloads','--no-env-file','python','-B']
for name,script,args in [('board-validate','friday-dev-board.py',['validate']),('board-render-check','friday-dev-board.py',['render','--check']),('board-show','friday-dev-board.py',['show','friday-command-refactor']),('docs-lifecycle','check-documentation-lifecycle.py',[]),('package-metadata','check-package-metadata.py',[])]:run(name,base+['scripts/'+script,*args],cwd=R)
for name,args,expected in [('whitespace-owned',['diff','--check','--','tests/readiness/ingest','docs/planning'],0),('whitespace-cached',['diff','--cached','--check'],0),('whitespace-range',['diff','--check','73fbda9b7f4e90da9912be442e1eb05b494a13b5..3985edc21474a86fce0bb29794ff52315c12ad5c'],0),('whitespace-working-baseline',['diff','--check'],2)]:run(name,['git',*args],expected,cwd=R)
