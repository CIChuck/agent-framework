"""Bounded private parser qualification; does not run a package resolver."""
import sys,pathlib,json,hashlib,types
s=pathlib.Path(__file__).parent.resolve();repository=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');h=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-build-sqewgfmf/formal/source/tests/readiness/ingest');m=h.parents[3]/'harness-manifest.json'
# The formal manifest is beside formal/source, not inside the source export.
m=pathlib.Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c1-build-sqewgfmf/formal/harness-manifest.json')
def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
require(sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode,'Use qualified -I -S -B with optional -O')
inspection=json.loads((s/'inspection.json').read_bytes());profile=json.loads((repository/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction/c1/private-resolver-tool-profile.json').read_bytes());target=pathlib.Path(profile['target']);expected=inspection['files'];actual={str(p.relative_to(target)):sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()};require(actual==expected and all(not p.is_symlink() for p in target.rglob('*')),'Private parser inventory mismatch')
raw=(h/'bootstrap.py').read_bytes();require(sha(raw)=='70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c','Bootstrap changed');ns={'__name__':'tool_bootstrap','__file__':str(h/'bootstrap.py')};exec(compile(raw,str(h/'bootstrap.py'),'exec',dont_inherit=True),ns);buffers=ns['verified_buffers'](h,m,'5c545b931a6b5fb66e21d9ccf479b0ca7e719fada2d4eb8d6492845ea48aecae');package=types.ModuleType('ingest');package.__path__=[];package.__dict__.update(ROOT=h,BUFFERS=buffers);sys.modules['ingest']=package;sys.meta_path.insert(0,ns['Buffers'](h,buffers));from ingest.startup import Guard,guarded
policy=Guard((s,target,h,pathlib.Path(sys.base_prefix).resolve()/'lib',pathlib.Path(sys.executable).resolve()),(s,));sys.path.insert(0,str(target));checks=[]
def check(name,ok):require(ok,name);checks.append(name)
with guarded(policy):
 import packaging
 from packaging.requirements import InvalidRequirement,Requirement
 from packaging.specifiers import SpecifierSet
 from packaging.version import InvalidVersion,Version
 from packaging.utils import canonicalize_name,parse_wheel_filename
 from packaging.tags import parse_tag
 check('exact_package',packaging.__version__=='24.2')
 check('canonical_names',canonicalize_name('My.Package_Name')=='my-package-name')
 check('ordered_versions',Version('1.0rc1')<Version('1.0')<Version('1.0.post1'))
 check('compatible_release',Version('2.4.9') in SpecifierSet('~=2.4.1') and Version('2.5') not in SpecifierSet('~=2.4.1'))
 check('intersection',Version('2.2') in SpecifierSet('>=2,<3,!=2.1') and Version('2.1') not in SpecifierSet('>=2,<3,!=2.1'))
 check('prerelease_policy',not SpecifierSet('>=2').contains('2.1rc1') and SpecifierSet('>=2').contains('2.1rc1',prereleases=True))
 env={'implementation_name':'cpython','implementation_version':'3.13.10','os_name':'posix','platform_machine':'arm64','platform_release':'test','platform_system':'Darwin','platform_version':'test','python_full_version':'3.13.10','platform_python_implementation':'CPython','python_version':'3.13','sys_platform':'darwin','extra':'rapidocr'}
 req=Requirement("Demo[rapidocr]>=2,<3; python_version >= '3.12' and extra == 'rapidocr'");check('extras_and_markers',req.extras=={'rapidocr'} and req.marker is not None and req.marker.evaluate(env));check('excluded_marker',not Requirement("Demo; sys_platform == 'win32'").marker.evaluate(env))
 check('requires_python',Version(env['python_full_version']) in SpecifierSet('>=3.10,<3.14') and Version(env['python_full_version']) not in SpecifierSet('<3.13'))
 name,version,build,tags=parse_wheel_filename('demo-2.4-py3-none-any.whl');check('wheel_identity',name=='demo' and str(version)=='2.4' and not build);check('wheel_tags',bool(tags&parse_tag('py3-none-any')) and not bool(tags&parse_tag('cp313-cp313-win_amd64')))
 check('direct_url_is_detectable',Requirement('demo @ https://unapproved.invalid/demo.whl').url is not None)
 try:Requirement('demo [broken')
 except InvalidRequirement:check('malformed_requirement_refuses',True)
 else:raise RuntimeError('Malformed requirement accepted')
 try:Version('not-a-version')
 except InvalidVersion:check('malformed_version_refuses',True)
 else:raise RuntimeError('Malformed version accepted')
 origin=pathlib.Path(packaging.__file__).resolve();check('origin',target in origin.parents)
 require({str(p.relative_to(target)):sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}==expected,'Parser target changed during execution')
result={'status':'PASS','scope':'Private packaging parser only; no actual dependency resolver/Docling/model qualification','checks':checks,'count':len(checks),'optimized':bool(sys.flags.optimize),'profile_sha256':inspection['profile_sha256'],'origin':str(origin),'target_unchanged':True,'network_requests_during_qualification':0};q=s/('qualified-optimized.json' if sys.flags.optimize else 'qualified-normal.json');q.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
