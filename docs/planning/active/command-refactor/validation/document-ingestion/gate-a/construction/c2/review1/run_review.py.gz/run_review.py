import pathlib,os,json,subprocess,hashlib
s=pathlib.Path(__file__).parent.resolve();setup=json.loads((s/'setup.json').read_bytes());req=json.loads((s/'request.json').read_bytes());h=pathlib.Path(setup['export']);m=pathlib.Path(setup['manifest']);base=req['interpreter'];records=[]
env={'PATH':'/usr/bin:/bin','HOME':os.environ.get('HOME',''),'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(s/'runtime-tmp')};pathlib.Path(env['TMPDIR']).mkdir(exist_ok=True)
def check(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def run(name,argv,cwd=s,expected=0,environment=None):
 r=subprocess.run(argv,cwd=cwd,env=environment or env,capture_output=True,text=True,timeout=150);records.append(dict(name=name,argv=argv,cwd=str(cwd),environment=environment or env,expected_exit=expected,exit=r.returncode,stdout=r.stdout,stderr=r.stderr));(s/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,r.stdout[-180:],r.stderr[-180:],flush=True);check(r.returncode==expected,'Unexpected exit '+name);return r
# Delta first, before retained aggregate execution.
for name,flags in [('normal',[]),('optimized',['-O'])]:
 r=run('selection-'+name,[base,'-I','-S','-B',*flags,str(s/'selection_worker.py')],expected=1);v=json.loads(r.stdout);check(v['positive_cases']==5 and v['refusal_cases']==31,'selector count');check(len(v['independent'])==17 and sum(x['result']=='FAIL' for x in v['independent'])==2,'independent findings differed')
controls=['--harness-manifest',str(m),'--harness-manifest-sha256',setup['manifest_sha256']]
for name,flags in [('normal',[]),('optimized',['-O'])]:
 prefix=[base,'-I','-S','-B',*flags];scratch=s/('selftest-'+name);scratch.mkdir();r=run('selftest-'+name,prefix+[str(h/'bootstrap.py'),'selftest',*controls,'--scratch',str(scratch)]);check(json.loads(r.stdout)['cases']==55,'minimal test count')
 project=s/('unit-project-'+name);project.mkdir();control=s/('control-'+name+'.json');cfg=dict(schema=1,project=str(project),run_id='review-c2-'+name,harness_sha256=setup['manifest_sha256'],envelope_sha256=req['pins']['docs/planning/active/command-refactor/validation/document-ingestion/gate-a/effects-envelope.json'],interpreter_sha256=req['interpreter_sha256'],activation='C0');control.write_text(json.dumps(cfg,indent=2)+'\n');args=[*controls,'--config',str(control),'--config-sha256',sha(control.read_bytes())]
 before=list(project.rglob('*'));run(name+'-preflight',prefix+[str(h/'bootstrap.py'),'preflight',*args]);check(before==list(project.rglob('*')),'preflight effects')
 r=run(name+'-init',prefix+[str(h/'bootstrap.py'),'init',*args]);init=json.loads(r.stdout);entry=pathlib.Path(init['config']).parent.parent/'harness/run.py';args=['--harness-manifest',init['harness_manifest'],'--harness-manifest-sha256',setup['manifest_sha256'],'--config',init['config'],'--config-sha256',init['config_sha256']]
 r=run(name+'-prepare-fixtures',prefix+[str(entry),'prepare-fixtures',*args]);prepared=json.loads(r.stdout);manifest=pathlib.Path(prepared['manifest']);check(prepared['fixture_count']==30 and prepared['converter_qualified'] is False and prepared['full_readiness'] is False,'preparation overclaim');check(sha(manifest.read_bytes())==prepared['manifest_sha256'],'manifest identity');inv=json.loads(manifest.read_bytes());check(len(inv['files'])==30,'fixture count')
 for row in inv['files']:
  p=manifest.parent/row['file'];check(sha(p.read_bytes())==row['sha256'] and p.stat().st_size==row['bytes'] and p.stat().st_mode&0o222==0,'fixture identity/mode')
 check(sha((manifest.parent/'oracles.json').read_bytes())==inv['oracles_sha256'],'oracle digest')
 run(name+'-repeat-refused',prefix+[str(entry),'prepare-fixtures',*args],expected=2)
 for stage in ['all','A0','A1','A2','A3','A4']:run(name+'-stage-'+stage,prefix+[str(entry),'run','--stage',stage,*args],expected=3)
 r=run(name+'-report-incomplete',prefix+[str(entry),'report',*args],expected=3);check(json.loads(r.stdout)['prepared_inputs'][0]['current_bytes_revalidated'] is False,'report overclaim')
 run(name+'-prepare-model-blocked',prefix+[str(entry),'prepare-model',*args],expected=3)
 run(name+'-stop',prefix+[str(entry),'stop',*args]);run(name+'-stopped-effects-refused',prefix+[str(entry),'prepare-fixtures',*args],expected=2);run(name+'-report-after-stop',prefix+[str(entry),'report',*args],expected=3)
print(json.dumps(dict(commands=len(records),minimal_per_mode=55,selection_each=dict(positive=5,refusal=31,independent_pass=15,independent_fail=2),manual_fixture_each=30,actual_stages_activated=False)))
