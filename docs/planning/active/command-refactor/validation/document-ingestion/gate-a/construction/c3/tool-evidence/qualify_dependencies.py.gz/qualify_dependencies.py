"""Guarded exact private parser, dependency gate, then exclusive extraction."""
from pathlib import Path
import hashlib,json,sys,types,zipfile
s=Path(__file__).parent.resolve();h=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6/formal-correction1/source/tests/readiness/ingest');m=h.parents[3]/'harness-manifest.json';m=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6/formal-correction1/harness-manifest.json')
def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
require(sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode,'Use -I -S -B')
source=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6/validation-tools/parser-target');old=json.loads(Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6/parser-inspection.json').read_bytes());target=s/'validation-tools/packaging-target';require(not target.exists(),'Reused parser target must be absent')
for name,expected in old['files'].items():
 raw=(source/name).read_bytes();require(sha(raw)==expected,'Approved parser input changed');q=target/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw);q.chmod(0o444)
(s/'parser-inspection.json').write_text(json.dumps(old,indent=2)+'\n');raw=(h/'bootstrap.py').read_bytes();require(sha(raw)=='70e03f2215282e2d4aa6fd0a58161ce0b9858981a114caba49f4826f5833599c','Bootstrap changed');ns={'__name__':'private_bootstrap','__file__':str(h/'bootstrap.py')};exec(compile(raw,str(h/'bootstrap.py'),'exec',dont_inherit=True),ns);buffers=ns['verified_buffers'](h,m,'f4d0e22c089d839780e60cd2ab543257db2e300ccfb1bebfdd6b065c53687843');package=types.ModuleType('ingest');package.__path__=[];package.__dict__.update(ROOT=h,BUFFERS=buffers);sys.modules['ingest']=package;sys.meta_path.insert(0,ns['Buffers'](h,buffers));from ingest.startup import Guard,guarded
sys.path.insert(0,str(target));policy=Guard((s,h,Path(sys.base_prefix).resolve()/'lib',Path(sys.executable).resolve()),(s,));inspection=json.loads((s/'inspection.json').read_bytes());checks=[]
with guarded(policy):
 import packaging
 from packaging.requirements import Requirement
 from packaging.specifiers import SpecifierSet
 from packaging.version import Version
 require(packaging.__version__=='24.2' and target in Path(packaging.__file__).resolve().parents,'Parser origin/version mismatch')
 require(Version('3.13.10') in SpecifierSet(inspection['requires_python']),'Engine Python requirement refused')
 environment={'implementation_name':'cpython','implementation_version':'3.13.10','os_name':'posix','platform_machine':'arm64','platform_release':'test','platform_system':'Darwin','platform_version':'test','python_full_version':'3.13.10','platform_python_implementation':'CPython','python_version':'3.13','sys_platform':'darwin','extra':''}
 for raw in inspection['requires_dist']:
  requirement=Requirement(raw);require(requirement.url is None and requirement.marker is not None and not requirement.marker.evaluate(environment),'Unapproved active engine dependency');checks.append({'requirement':raw,'selected_extra':'','active':False})
 wheel_path=Path(inspection['wheel']);require(sha(wheel_path.read_bytes())==inspection['wheel_sha256'],'Engine wheel changed');engine=s/'validation-tools/resolver-target';require(not engine.exists(),'Engine extraction target exists');engine.mkdir(mode=0o700)
 with zipfile.ZipFile(wheel_path) as wheel:
  require(set(wheel.namelist())==set(inspection['files']),'Inspected wheel inventory changed')
  for name,expected in inspection['files'].items():
   raw=wheel.read(name);require(sha(raw)==expected,'Engine member changed');q=engine/name;q.parent.mkdir(parents=True,exist_ok=True)
   with q.open('xb') as stream:stream.write(raw)
   q.chmod(0o444)
result={'status':'DEPENDENCY_AND_EXTRACTION_GATE_PASS','engine_profile_sha256':inspection['profile_sha256'],'engine_requires_python':inspection['requires_python'],'engine_member_count':len(inspection['files']),'engine_target':str(engine),'parser_member_count':len(old['files']),'optional_dependency_checks':checks,'active_engine_dependencies':[],'engine_imported':False,'network_requests':0};(s/'extraction.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
