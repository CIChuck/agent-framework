import subprocess,os,json,time,hashlib
from pathlib import Path
S=Path(__file__).parent;R=Path('/Users/chuckrussell/Dev/gendev/agent-framework');PY='/Users/chuckrussell/.local/share/uv/python/cpython-3.13.10-macos-aarch64-none/bin/python3.13'
for p in ['tmp','uv-cache','xdg-cache','xdg-config','static-tmp','validation-tools/mypy-cache']: (S/p).mkdir(parents=True,exist_ok=True)
ENV={'HOME':os.environ['HOME'],'PATH':os.environ['PATH'],'LANG':'en_US.UTF-8','GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(S/'tmp'),'TMP':str(S/'tmp'),'TEMP':str(S/'tmp'),'UV_CACHE_DIR':str(S/'uv-cache'),'UV_NO_PROGRESS':'1','UV_PYTHON_DOWNLOADS':'never','XDG_CACHE_HOME':str(S/'xdg-cache'),'XDG_CONFIG_HOME':str(S/'xdg-config'),'MYPYPATH':str(S/'candidate')}
def run(name,argv,expected=0,cwd=None):
 started=time.time();p=subprocess.run(argv,cwd=cwd or S,env=ENV,capture_output=True);out=S/(name+'.stdout');err=S/(name+'.stderr');out.write_bytes(p.stdout);err.write_bytes(p.stderr)
 row={'name':name,'argv':list(map(str,argv)),'cwd':str(cwd or S),'env':{k:v for k,v in ENV.items() if k!='HOME'},'exit':p.returncode,'expected_exit':expected,'elapsed':time.time()-started,'stdout':str(out),'stderr':str(err),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
 with (S/'commands.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 print(json.dumps({k:row[k] for k in ['name','exit','expected_exit','elapsed']}),flush=True)
 if p.returncode!=expected:raise RuntimeError(name+' unexpected exit: '+p.stderr.decode()[-4000:])
 return p
if __name__=='__main__':
 for label,expected in [('unfixed',1),('candidate',0)]:
  for opt in [False,True]:run('delta-'+label+('-optimized' if opt else '-normal'),[PY,'-I','-S','-B',*(['-O'] if opt else []),str(S/'selection_worker.py'),label,'witness'],expected)
