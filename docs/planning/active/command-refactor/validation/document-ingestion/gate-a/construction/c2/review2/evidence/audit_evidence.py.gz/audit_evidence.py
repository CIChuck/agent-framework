import json,gzip,hashlib
from pathlib import Path
R=Path('/Users/chuckrussell/Dev/gendev/agent-framework');S=Path(__file__).parent;C=R/'docs/planning/active/command-refactor/validation/document-ingestion/gate-a/construction'
def sha(b):return hashlib.sha256(b).hexdigest()
results=[]
for f in sorted(C.rglob('*.json')):
 if f.name not in ['index.json','evidence-index.json']:continue
 data=json.loads(f.read_bytes())
 if not isinstance(data,list):continue
 for row in data:
  if not isinstance(row,dict) or not isinstance(row.get('path'),str) or not row['path'].endswith('.gz'):continue
  choices=[f.parent/row['path'],f.parent.parent/row['path']];p=next((p for p in choices if p.is_file()),None)
  if p is None:raise RuntimeError('Missing '+row['path'])
  p=p.resolve();assert p.is_relative_to(C)
  compressed=p.read_bytes();raw=gzip.decompress(compressed)
  gh=row.get('gzip_sha256',row.get('compressed_sha256'));rh=row.get('raw_sha256',row.get('uncompressed_sha256',row.get('sha256')))
  assert gh and rh and sha(compressed)==gh and sha(raw)==rh,(p,gh,rh)
  sibling=p.with_suffix('');pair_present=sibling.is_file()
  pair_equal=not pair_present or sha(sibling.read_bytes())==rh
  results.append({'index':str(f.relative_to(R)),'path':str(p.relative_to(R)),'gzip_sha256':gh,'raw_sha256':rh,'sibling_present':pair_present,'sibling_present_and_equal':pair_present and pair_equal,'sibling_equal':pair_equal,'class':'integrity_only_no_correctness_credit'})
(S/'embedded-evidence-audit.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'indexed_gzip_rows':len(results),'raw_siblings_present_equal':sum(r['sibling_present_and_equal'] for r in results),'all_indexed_gzip_and_raw_hashes_match':True,'sibling_mismatches':[r['path'] for r in results if not r['sibling_equal']],'by_index':{f:sum(r['index']==f for r in results) for f in sorted(set(r['index'] for r in results))}}))
