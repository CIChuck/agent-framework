import json,hashlib,shlex,datetime,subprocess,os
from pathlib import Path
S=Path(__file__).parent;R=Path('/Users/chuckrussell/Dev/gendev/agent-framework');P=Path('/private/var/folders/dh/wfnmsgpn1yl83xlbmc109sf40000gn/T/ingest-c2-build-uk9g_iz6');q=json.loads((P/'corrected-review-request.json').read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
a=json.loads((S/'opening.json').read_bytes());b=json.loads((S/'closing.json').read_bytes());assert a==b
for label in ['candidate','unfixed']:
 m=json.loads((S/(label+'-manifest.json')).read_bytes())
 assert {str(p.relative_to(S/label)):sha(p.read_bytes()) for p in (S/label).rglob('*') if p.is_file()}=={r['path']:r['sha256'] for r in m['files']}
for key,invkey in [('mypy_target','mypy_inventory'),('parser_target','parser_inspection')]:
 root=S/'validation-tools'/key.replace('_','-');expected=json.loads(Path(q['tool_inputs'][invkey]).read_bytes())['files'];assert {str(p.relative_to(root)):sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()}==expected
assert sha((S/'validation-tools/pyproject.toml').read_bytes())==q['tool_inputs']['root_config_sha256']
integrity={'opening_sha256':sha((S/'opening.json').read_bytes()),'closing_sha256':sha((S/'closing.json').read_bytes()),'identical':True,'tracked_files':18391,'symlinks':26,'metadata_roots':9,'pins':len(q['pins']),'supplied_files':len(a['supplied_inputs']),'head':a['head'],'branch':a['branch'],'logical_index_before_status':a['logical_before_status'],'status':a['status'],'own_exports_and_tools_match':True,'repository_writes':False,'supplied_input_writes':False}
(S/'integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
cmds=[json.loads(x) for x in (S/'commands.jsonl').read_text().splitlines()];assert all(c['exit']==c['expected_exit'] for c in cmds if c['name']!='ruff-check');assert len([c for c in cmds if c['name']=='ruff-check' and c['exit']==2])==1
setup=json.loads((S/'setup.json').read_bytes());ind=json.loads((S/'independent-normal.stdout').read_bytes());aud=json.loads((S/'embedded-evidence-audit.json').read_bytes())
cd=[
('CD-01','PASS','setup.json; candidate-paths.json; correction-source.diff; aggregate-source.diff; opening.json/closing.json. All20 authority pins match. Exact82 changed paths match request; executable delta is only manifests.py and its existing test module, plus README. C1 evidence unchanged; all55 prior and54 base test bodies identical.'),
('CD-02','PASS','manifests.py:139-181; minimal-normal/optimized and independent-normal/optimized. Exact schema/environment fields, count/type checks and nonempty tag component/member grammar. The minimal test_empty_target_tag_components_refuse_before_parser_import executes with no optional parser import.'),
('CD-03','PASS','selector-normal/optimized:6 positives each; independent-normal/optimized:9 positives each. Verified packaging24.2 origins only; versions, specifiers, normalized identities, base+extras, inactive platform marker, cycles, late extras, universal/native/compressed tags and prerelease behavior.'),
('CD-04','PASS','selector-normal/optimized:39 actual Refusal cases each. Independent43 actual Refusal cases each, including24 malformed target/wheel variants; all12 malformed-wheel-only cases reach Malformed selected wheel tag. Missing/conflicting/unreachable dependencies, unknown extras, bad Python/platform/host/direct-reference/yanked/size controls also exercised.'),
('CD-05','PASS','manifests.py:147-170,209-213,277-304,319-339; independent count/byte/requirement limits and retained selector. Explicit64 roots/512 wheels/2048 tags/256 requires-dist per wheel/8192 declarations and expansion/32 requested extras/64 provided extras/4GiB selected bytes. Checker performs declaration checks only; all qualification/execution flags false. No actual resolver/download/install adapter is called.'),
('CD-06','PASS','setup.json AST retention54base/55prior/56current; minimal-normal/optimized stdout+stderr:56 executed,0 failures,0 skipped; selector-normal/optimized:6positive39refusal with exact parser inventory and all imported packaging origins private.'),
('CD-07','PASS','ruff-check-corrected-command exit0; ruff-format exit0; mypy exit0 with Success: no issues found in25 source files. Exact root config hash; no suppression/cast matches in harness; private copied typing1177/parser23 files and RECORD audit. Packaging exposed only as private PEP561 package_path; fresh cache, no ambient site or upstream/root-rule/source edits.'),
('CD-08','PASS','Stable candidate3985edc2; correction delta completed before aggregate execution. Manual two-mode frozen flow, required repository administration and whitespace checks;292 indexed gzip/raw digest pairs pass. opening/closing identical; no candidate/supplied writes. All actual A0-A4, full HR,9.5 advancement, acceptance and delivery remain open.')]
cc=[
('CC-01','PASS','All20pins and full boundary preserved; test-only82-path exact range; setup.json and integrity.json.'),
('CC-02','PASS','Pinned base CPython3.13.10 bootstrap identity and mandatory -I/-S/-B flags;56 tests per mode include dirty/extra/pyc/swap and private armed site-canary controls. test_startup.py.'),
('CC-03','PASS','Strict JSON/config/path tests, empty owned selftest scratch, no-write preflight and new-only init; test_manifests.py,test_paths.py,test_cli.py and two manual flows.'),
('CC-04','PASS','Current test_ledger.py exercises immutable identities, canonical chain/order/tamper/stale tips, candidate/promotion ordering, concurrent writer, cumulative reservations and terminal stop; both modes pass.'),
('CC-05','PASS','test_export.py actual private fixture repository commit/blob export excludes poisoned dirty/untracked input and retains private source index. Both modes pass. Reviewer export independently verifies every selected candidate/unfixed blob.'),
('CC-06','PASS','test_protection.py and test_startup.py execute guarded discovery, owned positive and read/probe/write/descriptor/dir-fd/thread/socket refusals, separate fake native metadata-detection failure, missing/truncated coverage. Both modes pass; OS containment is not claimed.'),
('CC-07','PASS','test_environment.py and child positive/negative in test_startup.py: explicit allowlisted settings, fake credentials/proxies/Python discovery dropped, startup inventory. No real SDK/profile is qualified.'),
('CC-08','PASS','test_window.py fake loaded-state/route/expiry/revocation/model/input/vector/token/request controls; callbacks changing stop/expiry before handoff refuse with conservative charges; accepted fake in-flight boundary remains documented. Both modes pass; no HTTP transport.'),
('CC-09','PASS','Two public manual flows and retained CLI/report/fixture cases. PREPARED_INPUTS is input preparation only; all/allA0-A4/prepare-model exit3, reports INCOMPLETE exit3, terminal stop prevents resumed effects. Structural seeds/ZIP controls pass.'),
('CC-10','PASS','Focused private root-rule lint/format/type checks pass;56 current control tests normal/-O. Fresh current-source aggregate assessed independently, with the context exception disclosed below.')]
ci=[
('CI-01','PASS','Exact directive/continuation pins, no C1 evidence changes and complete opening/closing boundary. All candidate inputs frozen.'),
('CI-02','PASS','test_fixtures.py checks deterministic unique6PDF/6DOCX/10XLSX/8PPTX containers; PDF offsets/pages/image/encryption and Office structures. Independently hashed manual30files in each mode;50583bytes,0444 inputs, identical manifest/oracles.'),
('CI-03','PASS','Current fixtures/expectations.json contains30 literal marker/exclusion/unit/outcome oracles. publish_matrix binds that file; no converter output or real extraction is used to derive it. Independent oracle hash85f6bffd0b2f9d79c2c62b60e6b3a150c7d0fde7cec3adfa8a842e220a367a23.'),
('CI-04','PASS','Current audit_office and test_fixtures.py: hidden units/rows/columns/shapes, formula cache and external relation distinctions; ZIP/XML/coordinate/merged bounds and UTF16 entity refusal. Output remains structural facts, text_extracted false.'),
('CI-05','PASS','Current publish_matrix/verify_matrix and retained actual-call tests: new physical destination, complete oracle before writes, exclusive/read-only publication, wrong hashes/extra or alias refusal and stopped partial publication without ready manifest.'),
('CI-06','PASS','test_operation_append_requires_live_same_instance_writer_lease executes same-instance/process token, stale/foreign/released token and competing writer checks; current append_held validates token and PID.'),
('CI-07','PASS','Public frozen entry preflight/init/prepare-fixtures/report/stop exercised in normal/-O; independent hashes and read-only mode checked. Reports label receipts ledger witnesses, not current-byte/conversion proof; no promotion or upstream execution.'),
('CI-08','PASS','All54base and55prior test bodies unchanged, including original controls;56 current cases execute per mode without skips under verified-buffer loader.'),
('CI-09','PASS','Ruff/format/25-source mypy and board/dashboard/docs/metadata/owned whitespace pass using required private tools/admin exception. Existing working-tree YAML whitespace failure remains unwaived.'),
('CI-10','PASS','Stable candidate, exact29-blob source export and fresh read-only aggregate. This report distinguishes fresh execution, source inspection and integrity-only supplied receipts; no old review result is adopted.')]
lines=[]
def add(t=''):lines.append(t)
add('VERIFIED')
add()
add('Fresh read-only corrected implementation validation — INGEST-C2-VAL-001 delta FIRST, followed by FULL bounded C0/C1/C2 aggregate, CD-01–08.')
add()
add('Reviewer: OpenAI Codex fresh task-only subagent /root/ingest_c2_corrected_validation. Exact model/version is not exposed in this agent context. Review date UTC: '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'. Repository: '+str(R)+'. Private evidence root: '+str(S)+'. No nested agents, repairs, repository writes, staging, commits, delivery or new profile activation.')
add()
add('Candidate3985edc21474a86fce0bb29794ff52315c12ad5c; base73fbda9b7f4e90da9912be442e1eb05b494a13b5; exact range '+q['diff']+'. Correction range '+q['remediation']['delta']+'. Actual unfixed source120def192117d6ed53fe10fa2ec3728c0e56ea7b. Approved selected source8cb32e314860825f6d521e97306e7c8e1a100f70, tree0bd4734795a12c375ab1646f131f305cb713cb40. Every29 selected candidate blob/hash equals that source manifest; own manifest SHA256f4d0e22c089d839780e60cd2ab543257db2e300ccfb1bebfdd6b065c53687843. Actual-unfixed export manifest SHA256c9197333b7b124b73fe086a759a9e25d909d6814e4b85cb1b16287a8975a305a.')
add()
add('The external request was SHA256-verified before its first read:077a99965833e7225077fbb46090a946fd9a576d8e996087086bfce8f56e3ac2. Boundary SHA256112fa2bebc354dc22ffec7a2e50b2f427d44701004143a9c37affe14367d160d verified before its read. AGENTS.md and all three policies, the exact directive, current C0/C1/C2 scopes, continuation, private-tool approvals/profiles and named remediation were inspected. Current authority is validation/in_review on feature/cmd-ingest-001; board remains started/normal, implementation_authority granted, delivery local. The pinned C1 continuation supplies offline test-only construction authority despite older unactivated wording retained in the parent draft directive; actual stage effects remain unactivated.')
add()
add('**Numbered findings and named correction**')
add()
add('No new mandatory or advisory finding. INGEST-C2-VAL-001 is closed for this candidate: both reported malformed declarations (py3--any and py3-none-) return CONSISTENT_CANDIDATE_DECLARATIONS from actual unfixed source, producing two genuine unittest.assertRaises call-assertion failures per mode. The four delta commands run first: unfixed normal/-O each exit1 with setup_succeeded=true and2 Refusal-not-raised witnesses; corrected normal/-O each exit0 with2 actual Refusals. The corrected source validates target syntax before optional imports and checks every expanded wheel tag. Independent wheel-only cases retain a valid target and refuse all12 malformed wheel tags at Malformed selected wheel tag. Valid universal/native and compressed interpreter/ABI/platform groups still succeed. No setup/import/collection error is counted as a negative witness.')
add()
add('**CD-01–08 matrix**')
add()
add('| Criterion | Outcome | Current evidence |');add('| --- | --- | --- |')
for row in cd:add('| '+' | '.join(row)+' |')
add()
add('**Full bounded retained C0 matrix**')
add();add('| Criterion | Outcome | Current evidence |');add('| --- | --- | --- |')
for row in cc:add('| '+' | '.join(row)+' |')
add();add('**Full bounded retained C1 matrix**');add();add('| Criterion | Outcome | Current evidence |');add('| --- | --- | --- |')
for row in ci:add('| '+' | '.join(row)+' |')
add()
add('**Executed evidence, tools and administration**')
add()
add('Fresh execution:56 minimal cases per normal/-O lane (no failures/skips); explicit current selector6 positives/39 Refusals per lane; reviewer-authored9 positives/43 Refusals per lane. The latter independently covers additive base/extras, an inactive marker, a cycle, late extra expansion, version conflicts, missing/unreachable closure, unknown extras, direct references, Python/platform constraints, count/requirement/size/host/yanked/schema controls and no qualification overclaim. The source-inspected8192 graph limits and remaining parser semantics are assessed with the current retained selector; this review does not claim exhaustive parsing or resource-stress proof.')
add()
add('Every typing1177 and parser23 file was copied by verified inventory into this review root and rehashed, with no symlinks or startup hooks. Fresh RECORD verification covers all1172 hashed typing members plus each of5 RECORD self entries, and22 hashed parser members plus its RECORD self entry; license files and packaging/py.typed are present. Ruff executable SHA2563844f53974c6e6d52dcfccdc02e9b34188c5003f0060ad2f3a96b9d550eea6f5, exact root config SHA256d1e8ff05afbe8f1a06d3ddaa07db520ff0a1378f6fae23baf3ee525b9619e9d7, interpreter SHA256e2adf1814122d8b26166917ef7d294d7426963e0f59e28d0d5aef773f67c4bb0. Source/static/runtime lanes use only the pinned base interpreter with -I -S -B, plus -O where stated; all imported packaging modules originate in the private copied parser target.')
add()
add('The inspected supplied mypy launcher was copied into private scratch; its private paths derive from __file__. It leaves upstream source/root rules unchanged, removes ambient mypy library search and explicitly binds the private parser as a PEP561 package_path. MYPYPATH names the private static-source root. All25 exact Python source files are checked using a newly created private cache. Mypy logged denied optional CPython setup/locale probes and the one private PEP561 path; these are disclosed guarded refusals, not semantic rejection credit or a fallback. Final mypy exit0: Success: no issues found in25 source files. No source/library suppression, root-rule alteration or ambient site is used.')
add()
add('Separate administration uses only existing uv selectors with --offline --frozen --no-sync --no-python-downloads --no-env-file python -B, unchanged HOME, bytecode off, GIT_OPTIONAL_LOCKS=0 and owned UV/XDG/TMP/config/credentials paths. This is the explicit request exception for repository maintenance, including its yaml dependency; it is not a harness/static .venv fallback. Source inspection of the three maintenance scripts shows no Friday application imports. Board validate passes36 tasks; render --check is current; documentation lifecycle passes1097 Markdown files; package metadata passes18 pyproject.toml files. Owned/cached/range whitespace checks exit0. Full working-tree diff --check retains exit2 solely from the preserved dirty chat YAML whitespace; no waiver or whole-repository-green claim follows.')
add()
add('Reviewer command-setup mistakes were corrected only in owned scratch: snapshot enumeration initially met a Gitlink directory (IsADirectoryError, exit1), then excluded that Gitlink from the regular-file boundary as the supplied boundary does; the logical index binds it. The first export setup compared the subtree ID against a manifest containing the approved source commit root-tree ID (exit1), then verified the correct source-root tree and identical candidate blobs. Initial Ruff argv combined --isolated and --config and was refused by Ruff (exit2); the corrected explicit --config/no-cache invocation passes without changing root rules. The first evidence audit also assumed readable historical siblings must equal their gzip originals (exit1); the final audit separates exact indexed raw/gzip identity from distinct readable wrappers and verifies the current C2 trailing-blank normalization. None of these infrastructure failures supplies product rejection credit. All runtime/assertion/static/admin invocations and any unexpected initial exit are retained in commands.jsonl with exact argv, cwd, allowlisted environment (HOME preserved without its value), stdout/stderr paths, digests and exits.')
add()
add('**Inspected receipts and integrity**')
add()
add('Supplied approval/profile/inventory documents and operational launchers were inspected as inputs; previous build/review success claims were not reused. Embedded receipts are integrity-only:292 indexed compressed/raw SHA256 pairs all match across C0/C1/C2, including historical evidence. The three readable historical report siblings are distinct representations; no report content/verdict was read for correctness. The current C2 readable normalization hashes match its normalization receipt and differ from original gzip raw bytes only by trailing blank lines. The two C0 readable wrappers already differ in the unchanged baseline; their archived gzip originals match their declared raw hashes. This is not a claim that every readable sibling equals its raw archive.')
add()
add('opening.json and closing.json are byte-identical, SHA256'+integrity['opening_sha256']+'. HEAD, branch, logical index before status, exact dirty status,18391 regular tracked-file hashes,26 symlink targets, all20 pins,9 protected metadata records and1210 supplied file hash/metadata records are unchanged. Logical index SHA256902349b6d0628c9ad97cf54fbf3d2cfc2758d6bf0904b5491d5c5d9f50c0ac5c. Protected .friday/.friday-old/.venv metadata was checked without traversal; dirty YAMLs were hashed without payload inspection; live .friday_test remains absent. Candidate/unfixed exports, private tool copies and root config rehash correctly. The terminal integrity check runs again after this report is written, producing terminal-integrity.json with this report SHA256.')
add()
add('**Independence and shared-context disclosure**')
add()
add('No memory files, C2 review1 report/verdict, peer test logic or private builder reasoning were read or used. One attempted shallow current-authority extraction inadvertently printed unrelated historical pilot/foundation authority fields, including unrelated historical result labels, before truncation. The controller was notified immediately. Those labels supplied no correctness evidence; remaining authority extraction used explicit current INGEST fields only. Historical report bytes were processed only mechanically for hashes/normalization and never displayed or semantically relied upon. The exposure does not supply a prior verdict for this candidate and does not compromise the task-only implementation independence under the governing policy. This exception is explicit so the controller/maintainer can assess it.')
add()
add('**Limits and advisory score**')
add()
add('Advisory score:9.3/10 for this bounded offline component, not a full-readiness score. The named defect is reproduced and corrected under both modes, retained controls execute, and independent call assertions support the declaration checker. Remaining real profiles/adapters, native containment and broader source/runtime qualification keep full HR-01–18, A0–A4 and any9.5 advancement open. This result supplies no actual dependency resolution, metadata collection, download/install, artifact-byte/license/installed-profile provenance qualification, Docling/OCR/extraction/chunk/model/tokenizer acceptance, target-machine fact verification, production/store/provider/network effect, UAT, maintainer acceptance or delivery authority. Python-visible guard evidence has declared native/child/detective limits and is not OS containment. Full repository debt and preserved YAML whitespace remain unwaived. No new profile has been activated.')
add()
add('**Reproducible command ledger**')
add()
add('Initial external verification command, exit0:');add('```sh');add('shasum -a 256 '+str(P/'corrected-review-request.json'));add('```')
add('Boundary verification and initial logical-index command both exit0:');add('```sh');add('shasum -a 256 '+q['boundary']);add('GIT_OPTIONAL_LOCKS=0 git ls-files -s -z | shasum -a 256');add('```')
add('Owned setup/integrity helper invocations (run_checks.py exits1 as disclosed below; final other helper invocations exit0):');add('```sh')
for name in ['snapshot.py opening','setup.py','commands.py','run_checks.py','static_checks.py','admin.py','audit_evidence.py','tool_audit.py','snapshot.py closing']:
 add('/usr/bin/python3 -B '+str(S)+'/'+name)
add('```')
add('run_checks.py completed all semantic/manual lanes, then exited1 on the initial invalid Ruff argv; static_checks.py completed the corrected static lane. Commands below are recorded individually and authoritative for result/exit:')
for c in cmds:
 add();add(c['name']+' — exit'+str(c['exit'])+'; expected'+str(c['expected_exit'])+'; cwd '+c['cwd']+'.');add('```sh');add(shlex.join(c['argv']));add('```');add('stdout SHA256'+c['stdout_sha256']+'; stderr SHA256'+c['stderr_sha256']+'.')
add();add('**Evidence artifacts**');add()
for f in ['setup.json','candidate-manifest.json','unfixed-manifest.json','candidate-paths.json','correction-source.diff','aggregate-source.diff','selection_worker.py','commands.jsonl','current-authority.json','manual-summary.json','independent-manual-matrix.json','tool-origin-record-audit.json','embedded-evidence-audit.json','readable-normalization-audit.json','opening.json','closing.json','integrity.json']:
 add('- ['+f+']('+str(S/f)+'), SHA256'+sha((S/f).read_bytes())+'.')
report=S/'report.md';report.write_text('\n'.join(lines)+'\n');print(json.dumps({'report':str(report),'sha256':sha(report.read_bytes()),'outcome':'VERIFIED','advisory_score':9.3,'commands':len(cmds),'pins':len(q['pins']),'all_closing_equal':True}))
