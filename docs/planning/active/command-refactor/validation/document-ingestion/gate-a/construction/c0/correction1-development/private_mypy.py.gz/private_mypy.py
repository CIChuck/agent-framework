"""Private copied-tool launcher; caller binds current development snapshot."""
import sys, pathlib, types, hashlib, json
if not (sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode):
    raise RuntimeError('Use -I -S -B')
target, harness, manifest, expected, expected_bootstrap = sys.argv[1:6]
root = pathlib.Path(harness)
raw = (root/'bootstrap.py').read_bytes()
if hashlib.sha256(raw).hexdigest()!=expected_bootstrap:
    raise RuntimeError('Private tool bootstrap identity mismatch')
private=pathlib.Path(__file__).parent.resolve()
tool_manifest=json.loads((private/'tools/mypy-target-manifest.json').read_bytes())
for name,digest in tool_manifest['files'].items():
    if hashlib.sha256((pathlib.Path(target)/name).read_bytes()).hexdigest()!=digest:
        raise RuntimeError('Private mypy tool identity mismatch')
system_input=pathlib.Path('/System/Library/CoreServices/SystemVersion.plist')
if hashlib.sha256(system_input.read_bytes()).hexdigest()!='bd61e19dd67dd97ce9a27c79a2148d42cc9685a71c6f17ff27d62b819f39f983':
    raise RuntimeError('Public system input changed')
namespace={'__name__':'private_tool_bootstrap','__file__':str(root/'bootstrap.py')}
exec(compile(raw,str(root/'bootstrap.py'),'exec',dont_inherit=True),namespace)
buffers=namespace['verified_buffers'](root,pathlib.Path(manifest),expected)
package=types.ModuleType('ingest');package.__path__=[];package.__dict__.update(ROOT=root,BUFFERS=buffers);sys.modules['ingest']=package
sys.meta_path.insert(0,namespace['Buffers'](root,buffers))
from ingest.startup import Guard,guarded
stdlib=pathlib.Path(sys.base_prefix).resolve()/'lib'
class ObservedGuard(Guard):
    def path(self,value,write=False,probe=False):
        try:
            super().path(value,write,probe)
        except Exception:
            sys.stderr.write('PRIVATE TOOL REFUSAL: '+repr(value)+' write='+str(write)+' probe='+str(probe)+'\n')
            raise
cache=pathlib.Path(sys.argv[sys.argv.index('--cache-dir')+1])
policy=ObservedGuard((private,stdlib,pathlib.Path(sys.executable).resolve(),system_input),(cache,private/'static-tmp'))
sys.path.insert(0,target)
with guarded(policy):
    import mypy.modulefinder as finder
    original_paths=finder.default_lib_path
    def private_typeshed(data_dir,pyversion,custom_typeshed_dir):
        result=[path for path in original_paths(data_dir,pyversion,custom_typeshed_dir) if path != '/usr/local/lib/mypy']
        for path in result:policy.path(path)
        return result
    finder.default_lib_path=private_typeshed
    from mypy.api import run
    out,err,code=run(sys.argv[6:])
sys.stdout.write(out);sys.stderr.write(err)
raise SystemExit(code)
