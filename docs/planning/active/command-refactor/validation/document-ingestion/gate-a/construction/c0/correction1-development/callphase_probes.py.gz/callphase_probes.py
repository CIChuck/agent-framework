"""Remediator-owned call-phase development witnesses; no formal review claim."""
import _thread
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import threading
import types

# Capture actual aliases before loading startup.py or installing any guard.
saved_new = _thread.start_new_thread
saved_short = _thread.start_new
saved_joinable = _thread.start_joinable_thread
saved_standard = threading.Thread
saved_threading_joinable = threading._start_joinable_thread
saved_chmod = os.chmod
saved_utime = os.utime
S = Path(__file__).parent.resolve()
selection = json.loads((S/'snapshot-development2.json').read_bytes())
H = Path(selection['harness'])
bootstrap = (H/'bootstrap.py').read_bytes()
namespace = {'__name__':'private_bootstrap','__file__':str(H/'bootstrap.py')}
exec(compile(bootstrap,str(H/'bootstrap.py'),'exec',dont_inherit=True),namespace)
buffers = namespace['verified_buffers'](H,Path(selection['manifest']),selection['manifest_sha256'])
package = types.ModuleType('ingest');package.__path__=[];package.__dict__.update(ROOT=H,BUFFERS=buffers);sys.modules['ingest']=package
sys.meta_path.insert(0,namespace['Buffers'](H,buffers))
from ingest.startup import Guard,guarded
from ingest.manifests import Refusal
from ingest.ledger import Ledger,ZERO
from ingest.window import Window,FakeTransportGate

lane='optimized' if sys.flags.optimize else 'normal'
root=S/('callphase-'+lane);root.mkdir()
owned=root/'owned';outside=root/'outside';owned.mkdir();outside.mkdir()
for base in (owned,outside):
    (base/'sentinel').write_bytes(b'private unchanged target')
    os.chmod(base/'sentinel',0o644)
    os.utime(base/'sentinel',ns=(1_000_000_000,2_000_000_000))
    (base/'directory').mkdir()
target=outside/'sentinel';before=target.stat()
directory_fd=os.open(outside,os.O_RDONLY)
events=[]
def observe(event,args):
    if event.startswith('_thread.') or event in {'os.chmod','os.utime','os.chown','os.rename','os.link','os.symlink','os.mkdir','os.remove','os.rmdir'}:
        events.append({'event':event,'argument_types':[type(a).__name__ for a in args],'arguments':[str(a) if isinstance(a,os.PathLike) else a if isinstance(a,(str,int,type(None),tuple)) else type(a).__name__ for a in args]})
sys.addaudithook(observe)
rows=[]
def refuses(name,call):
    try:
        call()
    except Refusal as exc:
        rows.append({'name':name,'result':'REFUSED','reason':str(exc),'call_phase':True})
    else:
        rows.append({'name':name,'result':'FAILED_NO_REFUSAL','call_phase':True})

marker=outside/'thread-effect';finished=threading.Event()
def worker():
    try:marker.write_text('unexpected outside worker')
    finally:finished.set()
def standard():
    t=saved_standard(target=worker);t.start();t.join(2)
os.chdir(owned)
with guarded(Guard((owned,),(owned,))):
    for name,call in [
        ('saved_standard_Thread',standard),
        ('saved_start_new_thread',lambda:saved_new(worker,())),
        ('saved_start_new',lambda:saved_short(worker,())),
        ('saved_start_joinable_thread',lambda:saved_joinable(worker)),
        ('saved_threading_joinable_alias',lambda:saved_threading_joinable(worker)),
        ('module_start_new_thread',lambda:_thread.start_new_thread(worker,())),
    ]:refuses(name,call)
    for name,call in [
        ('relative_saved_chmod_dirfd',lambda:saved_chmod('sentinel',0o600,dir_fd=directory_fd)),
        ('relative_saved_utime_dirfd',lambda:saved_utime('sentinel',ns=(3,4),dir_fd=directory_fd)),
        ('relative_chown_dirfd',lambda:os.chown('sentinel',-1,-1,dir_fd=directory_fd)),
        ('relative_mkdir_dirfd',lambda:os.mkdir('created',dir_fd=directory_fd)),
        ('relative_unlink_dirfd',lambda:os.unlink('sentinel',dir_fd=directory_fd)),
        ('relative_rmdir_dirfd',lambda:os.rmdir('directory',dir_fd=directory_fd)),
        ('relative_open_dirfd',lambda:os.open('created',os.O_WRONLY|os.O_CREAT,dir_fd=directory_fd)),
        ('relative_rename_source_dirfd',lambda:os.rename('sentinel','created',src_dir_fd=directory_fd)),
        ('relative_rename_destination_dirfd',lambda:os.rename('sentinel','created',dst_dir_fd=directory_fd)),
        ('relative_replace_dirfd',lambda:os.replace('sentinel','created',src_dir_fd=directory_fd,dst_dir_fd=directory_fd)),
        ('relative_link_source_dirfd',lambda:os.link('sentinel','created',src_dir_fd=directory_fd)),
        ('relative_link_destination_dirfd',lambda:os.link('sentinel','created',dst_dir_fd=directory_fd)),
        ('relative_symlink_dirfd',lambda:os.symlink('sentinel','created',dir_fd=directory_fd)),
        ('relative_mkfifo_dirfd',lambda:os.mkfifo('created',dir_fd=directory_fd)),
        ('relative_mknod_dirfd',lambda:os.mknod('created',stat.S_IFIFO|0o600,dir_fd=directory_fd)),
    ]:refuses(name,call)
    for name,path in [('present',target),('absent',outside/'absent'),('ancestor',owned.parent)]:
        refuses('access_'+name,lambda:os.access(path,os.F_OK))
    refuses('access_dirfd_present',lambda:os.access('sentinel',os.F_OK,dir_fd=directory_fd))
    refuses('access_dirfd_absent',lambda:os.access('absent',os.F_OK,dir_fd=directory_fd))
    os.chmod(owned/'sentinel',0o640);os.utime(owned/'sentinel',ns=(5,6))
    positive=os.access(owned/'sentinel',os.F_OK) and (owned/'sentinel').stat().st_mtime_ns==6
os.chdir(S);os.close(directory_fd)
after=target.stat()
preserved=(before.st_mode,before.st_atime_ns,before.st_mtime_ns,before.st_size)==(after.st_mode,after.st_atime_ns,after.st_mtime_ns,after.st_size) and target.read_bytes()==b'private unchanged target'

for control in ('expiry','stop'):
    state=root/('ledger-'+control);state.mkdir();log=Ledger(state)
    log.append('init',{'run_id':'unit','config_sha256':'a'*64,'harness_sha256':'b'*64},ZERO)
    now=[2];sent=[]
    def reserve(resource,amount,ceiling):
        log.reserve(resource,amount,ceiling)
        if control=='expiry':now[0]=20
        else:(state/'stop.json').write_text('{"schema":1}')
    def fake(method,path,payload):sent.append(path);return {}
    w=Window('unit','http://127.0.0.1:1234','fake-loaded','LMS_NATIVE_V0',20,'a'*64,{'batch':'b'*64})
    gate=FakeTransportGate(w,lambda:now[0],log.stopped,reserve,fake)
    refuses(control+'_during_real_ledger_reservation',lambda:gate.send('GET',w.status_path,{}))
    rows.append({'name':control+'_actual_attempts','attempts':gate.attempts,'calls':len(sent),'charged_records':len(log.records())-1})

result={'lane':lane,'development_only':True,'rows':rows,'thread_marker_exists':marker.exists(),'target_mode_times_content_preserved':preserved,'owned_metadata_access_positive':positive,'events':events}
(S/('callphase-'+lane+'.json')).write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
if any(row.get('result')=='FAILED_NO_REFUSAL' or row.get('attempts',0)!=0 or row.get('calls',0)!=0 for row in rows) or marker.exists() or not preserved or not positive:raise SystemExit(1)
