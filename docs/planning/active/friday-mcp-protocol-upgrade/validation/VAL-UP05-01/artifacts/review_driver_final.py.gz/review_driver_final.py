from pathlib import Path
import json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');e=b/'independent-review-UP05-001';r=json.loads((b/'work/docs/planning/active/friday-mcp-protocol-upgrade/validation-request-UP05.json').read_text())
for c in r['required_checks']:
 subprocess.run([str(b/'venv/bin/python'),str(e/'review_runner_final.py'),c['id'],c['snapshot'],*c['argv']],check=True)
for c in r['required_checks']:
 if c['id'] in ['full-mypy','baseline-full-mypy']:
  subprocess.run([str(b/'venv/bin/python'),str(e/'review_runner_final.py'),c['id']+'-columns',c['snapshot'],*c['argv'],'--show-column-numbers','--no-pretty'],check=True)
