import asyncio, importlib.util, json, logging, io
from pathlib import Path
from friday_mcp.client.protocol import META_PREFIX, ProtocolLimits, ToolResult
path=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/client/test_modern_protocol.py')
spec=importlib.util.spec_from_file_location('probe_helpers',path)
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
async def main():
    opaque={'traceparent':'OPAQUE_TRACE_SENTINEL','tracestate':{'unknown':[]},'baggage':None}
    sink=io.StringIO();handler=logging.StreamHandler(sink);root=logging.getLogger();root.addHandler(handler)
    client=h.Client()
    def respond(message):
        if message['method']=='server/discover':return {'result':h.discover(_meta=opaque)}
        if message['method']=='tools/call':return {'result':h.complete(_meta=opaque,content=[{'type':'text','text':'safe','_meta':opaque}])}
        return client.transport.default(message)
    client.transport.handler=respond
    try:
        await client.connect()
        await client.list_tools()
        value=await client.call_tool('echo',{'application':{'_meta':opaque}})
        notifications={'jsonrpc':'2.0','method':'notifications/unknown','params':{'_meta':opaque}}
        await client._handle_message(notifications)
        requests=[m for m in client.transport.sent if 'id' in m]
        emitted=[sorted(m['params']['_meta']) for m in requests]
        assert value=='safe'
        assert all(not set(opaque)&set(keys) for keys in emitted)
        assert 'OPAQUE_TRACE_SENTINEL' not in sink.getvalue()
        assert 'OPAQUE_TRACE_SENTINEL' not in repr(client._discovery)
        print(json.dumps({'passive_opaque_reception':True,'no_reserved_trace_emission':True,'fixed_text_preserved':True,'no_trace_payload_logs_or_discovery_repr':True,'request_metadata_keys':emitted},indent=2))
    finally:
        await client.disconnect();root.removeHandler(handler)
asyncio.run(main())
