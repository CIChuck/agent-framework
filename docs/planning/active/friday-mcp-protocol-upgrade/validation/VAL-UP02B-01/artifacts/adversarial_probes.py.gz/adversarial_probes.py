import asyncio,importlib.util,json,sys
from pathlib import Path
from friday_mcp.client.http_protocol import header_bindings,HTTP_COMPAT_VERSION
from friday_mcp.client.protocol import ToolDefinition,ProtocolLimits
path=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/client/test_http_lifecycle.py')
spec=importlib.util.spec_from_file_location('review_peer',path);helpers=importlib.util.module_from_spec(spec);sys.modules[spec.name]=helpers;spec.loader.exec_module(helpers)
async def probe_headers():
 schema={'type':'object','properties':{'payload':{'type':'string','contentMediaType':'application/json','contentSchema':{'type':'object','properties':{'v':{'type':'string','x-mcp-header':'Hidden'}}}}}}
 ToolDefinition.parse({'name':'invalid-content-schema','inputSchema':schema},ProtocolLimits(),modern=True)
 print('contentSchema binding accepted:',header_bindings(schema))
 peer=helpers.Peer();peer.tools.append({'name':'invalid-content-schema','inputSchema':schema})
 client,_,_=await helpers.ready_client(peer=peer)
 try:print('published catalog:',[t['name'] for t in await client.list_tools()],'rejected:',client.rejected_http_tools)
 finally:await client.disconnect()
async def probe_sessions():
 late_release=asyncio.Event()
 class DelayedStream(helpers.WireStream):
  async def read(self,max_bytes,timeout=None):
   await self.ready.wait()
   if b'"text":"late"' in self.outgoing: await late_release.wait()
   return await super().read(max_bytes,timeout)
 class DelayedPeer(helpers.Peer):
  async def connect_tcp(self,host,port,timeout=None,local_address=None,socket_options=None):
   self.connections.append((host,port));stream=DelayedStream(self);self.streams.append(stream);return stream
 peer=DelayedPeer(HTTP_COMPAT_VERSION);client,_,_=await helpers.ready_client(peer=peer)
 def hook(verb,headers,request):
  if request.get('method')=='tools/call':
   return helpers.Reply(status=404)
 peer.hook=hook
 late=asyncio.create_task(client.call_tool('echo',{'text':'late'}))
 while peer.methods().count('tools/call')<1:await asyncio.sleep(0)
 fast=asyncio.create_task(client.call_tool('echo',{'text':'fast'}))
 fast_result=await asyncio.gather(fast,return_exceptions=True)
 print('after fast 404: connected',client.is_connected,'session',client._session_id,'generation',client._generation,'initialize count',peer.methods().count('initialize'))
 late_release.set();late_result=await asyncio.gather(late,return_exceptions=True)
 print('after late 404: connected',client.is_connected,'session',client._session_id,'generation',client._generation,'initialize count',peer.methods().count('initialize'),'call count',peer.methods().count('tools/call'))
 peer.hook=None
 try:
  print('next explicit result:',await client.call_tool('echo',{'text':'next'}))
 except Exception as e:print('next explicit exception:',type(e).__name__,str(e))
 await client.disconnect()
async def main():await probe_headers();await probe_sessions()
asyncio.run(main())
