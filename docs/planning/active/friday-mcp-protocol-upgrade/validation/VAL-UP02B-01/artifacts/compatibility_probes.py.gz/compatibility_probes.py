import asyncio,importlib.util,json,sys
from pathlib import Path
from friday_mcp.client.http_protocol import HTTP_COMPAT_VERSION
path=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/client/test_http_lifecycle.py')
spec=importlib.util.spec_from_file_location('review_peer',path);h=importlib.util.module_from_spec(spec);sys.modules[spec.name]=h;spec.loader.exec_module(h)
async def dialect():
 peer=h.Peer(HTTP_COMPAT_VERSION);peer.tools[0]['inputSchema']['$schema']='https://unsupported.example/unknown-schema'
 client,_,_=await h.ready_client(peer=peer)
 try:print('unsupported 2025 input dialect published:',(await client.list_tools())[0]['inputSchema']['$schema'])
 finally:await client.disconnect()
async def metadata():
 peer=h.Peer(HTTP_COMPAT_VERSION);peer.tools[0]['_meta']={'bad/name/key':1}
 client,_,_=await h.ready_client(peer=peer)
 try:
  print('malformed 2025 Tool metadata published:',(await client.list_tools())[0]['_meta'])
  peer.hook=lambda verb,headers,request: peer.rpc(request,{'content':[{'type':'text','text':'ok','_meta':{'bad/name/key':1}}],'_meta':{'bad/name/key':1}}) if request.get('method')=='tools/call' else None
  print('malformed 2025 result/TextContent metadata returned success:',await client.call_tool('echo',{'text':'x'}))
 finally:await client.disconnect()
async def main():await dialect();await metadata()
asyncio.run(main())
