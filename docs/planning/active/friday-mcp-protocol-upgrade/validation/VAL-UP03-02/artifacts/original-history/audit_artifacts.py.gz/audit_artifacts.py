from pathlib import Path
import json,gzip,hashlib,subprocess,re,collections
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';r=b/'independent-review-UP03';p=w/'docs/planning/active/friday-mcp-protocol-upgrade'
h=lambda x:hashlib.sha256(x).hexdigest();out={}
for rel in ['execution/up03','execution/up03-planning']:
 root=p/rel;d=json.loads((root/'stored-manifest.json').read_text());items=[]
 for a in d['artifacts']:
  data=(root/a['path']).read_bytes();plain=gzip.decompress(data) if a['encoding']=='gzip' else data
  items.append({'path':str((root/a['path']).relative_to(w)),'stored_match':h(data)==a['stored_sha256'],'content_match':h(plain)==a['sha256'],'bytes_match':len(plain)==a['bytes']})
 out[rel]={'count':len(items),'all_match':all(all(a[k] for k in ['stored_match','content_match','bytes_match']) for a in items),'items':items}
libs=[]
for name,key in [('reused-library-manifest.json.gz','copied'),('additional-validation-libraries.json.gz','added')]:
 d=json.loads(gzip.decompress((p/'execution/up03/artifacts/environment'/name).read_bytes()))
 for dist in d[key]:
  failures=[]
  for f in dist.get('files',[]):
   file=b/'venv/lib/python3.13/site-packages'/f['path']
   if not file.exists() or h(file.read_bytes())!=f['sha256']:failures.append(f['path'])
  libs.append({'distribution':dist.get('distribution',dist.get('name')),'version':dist['version'],'files_checked':len(dist.get('files',[])),'failures':failures})
out['library_audit']=libs
snapshot=json.loads((b/'up03-baseline-snapshot.json').read_text());out['snapshot_manifest_sha256']=h((b/'up03-baseline-snapshot.json').read_bytes());out['baseline_revision']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=b/'up03-baseline',text=True).strip();out['baseline_status']=subprocess.check_output(['git','status','--porcelain'],cwd=b/'up03-baseline',text=True)
ledger=json.loads(gzip.decompress((p/'execution/up03/artifacts/normative-clause-ledger.json.gz').read_bytes()));audit=json.loads((r/'input-audit.json').read_text());reconc=[]
for s in audit['sources']:
 text=gzip.decompress((w/s['path']).read_bytes()).decode();actual=[(text.count('\n',0,m.start())+1,m.group()) for m in re.finditer(r'\b(?:MUST|SHALL|REQUIRED)\b',text)];mapped=[]
 for c in ledger['clauses']:
  if c['source']==s['url']:
   start=text.find(c['paragraph']);mapped.extend((text.count('\n',0,start+m.start())+1,m.group()) for m in re.finditer(r'\b(?:MUST|SHALL|REQUIRED)\b',c['paragraph']))
 reconc.append({'source':s['url'],'actual':len(actual),'mapped':len(mapped),'exact_occurrence_multiset':collections.Counter(actual)==collections.Counter(mapped)})
out['complete_source_occurrences']=reconc
schema_issues=[]
for interface in ledger['selected_schema_interfaces']:
 s=next(s for s in audit['sources'] if s['url']==interface['source']);text=gzip.decompress((w/s['path']).read_bytes()).decode();lines=text.splitlines()
 if interface['definition'] not in text:schema_issues.append([interface['type'],'definition'])
 for field in interface['fields']:
  if field['declaration'].strip()!=lines[field['line']-1].strip():schema_issues.append([interface['type'],field])
out['schema_interfaces']=len(ledger['selected_schema_interfaces']);out['schema_fields']=sum(len(i['fields']) for i in ledger['selected_schema_interfaces']);out['schema_issues']=schema_issues
out['new_source_suppressions_or_casts']=[line for line in (r/'selected.diff').read_text().splitlines() if line.startswith('+') and not line.startswith('+++') and re.search(r'type:\s*ignore|mypy:\s*ignore|\bcast\(|\bassert\b',line) and 'assert' not in line]
(r/'artifact-audit.json').write_text(json.dumps(out,indent=2)+'\n');print({k:{'count':v['count'],'all_match':v['all_match']} for k,v in out.items() if isinstance(v,dict) and 'all_match' in v});print('libraries',len(libs),'files',sum(x['files_checked'] for x in libs),'failures',sum(len(x['failures']) for x in libs));print('occurrences',sum(x['actual'] for x in reconc),'exact',all(x['exact_occurrence_multiset'] for x in reconc),'schema',out['schema_interfaces'],out['schema_fields'],'issues',schema_issues)
