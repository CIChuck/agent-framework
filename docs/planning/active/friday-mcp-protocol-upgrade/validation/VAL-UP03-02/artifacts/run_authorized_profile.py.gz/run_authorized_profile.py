import hashlib,json,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade');r=b/'independent-review-UP03-003';w=b/'work';req=json.loads((w/'docs/planning/active/friday-mcp-protocol-upgrade/validation-request-REM-MCP-UP-003.json').read_text())
def run(label,snapshot,argv):
 check=r/'checks'/label;check.mkdir(parents=True,exist_ok=True)
 freeze={'utc':datetime.now(timezone.utc).isoformat(),'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True),'argv':argv,'snapshot':str(b/snapshot),'product_hashes':{p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in req['product_hashes']},'metadata_hashes':{p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in req['metadata_hashes']},'guard_sha256':hashlib.sha256((b/'guard/sitecustomize.py').read_bytes()).hexdigest(),'pinned_runner_sha256':hashlib.sha256((b/'run_check.py').read_bytes()).hexdigest(),'review_runner_sha256':hashlib.sha256((r/'review_run_check.py').read_bytes()).hexdigest(),'profile_runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'effects':req['permitted_effects']}
 assert freeze['candidate']=='3473cad1ab9ad35577d809281c87ce242f545b2c' and not freeze['status']
 assert freeze['product_hashes']==req['product_hashes'] and freeze['metadata_hashes']==req['metadata_hashes']
 (check/'before-execution.json').write_text(json.dumps(freeze,indent=2)+'\n')
 result=subprocess.run([sys.executable,str(r/'review_run_check.py'),label,snapshot,*argv],capture_output=True,text=True)
 (check/'orchestrator.stdout').write_text(result.stdout);(check/'orchestrator.stderr').write_text(result.stderr)
 if result.returncode: raise RuntimeError('Runner failure')
 receipt=json.loads((check/'receipt.json').read_text());assert receipt['argv']==argv
 print(result.stdout.strip(),flush=True)
 return receipt
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='extra':
  run('address-semantics','work',[str(b/'venv/bin/python'),str(r/'probe_address_semantics.py')])
  for c in req['required_checks']:
   if c['id'] in ['full-mypy','baseline-full-mypy']:run('columns-'+c['id'],c['snapshot'],c['argv']+['--show-column-numbers'])
  run('range-whitespace','work',['git','diff','--check',req['base_commit']+'..HEAD'])
 else:
  for c in req['required_checks']:run('authorized-final-'+c['id'],c['snapshot'],c['argv'])
