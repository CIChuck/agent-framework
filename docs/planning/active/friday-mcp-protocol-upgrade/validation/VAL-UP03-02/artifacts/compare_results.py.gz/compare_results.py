from pathlib import Path
import json,re,hashlib
r=Path('/private/tmp/friday-mcp-upgrade/independent-review-UP03-003');b=Path('/private/tmp/friday-mcp-upgrade');prefix='authorized-final-'
def read(label):return (r/'checks'/(prefix+label)/'stdout').read_text()
def normalize(x):
 if isinstance(x,str):return x.replace(str(b/'work')+'/', '<snapshot>/').replace(str(b/'up03-baseline')+'/', '<snapshot>/')
 if isinstance(x,list):return [normalize(a) for a in x]
 if isinstance(x,dict):return {k:normalize(v) for k,v in x.items()}
 return x
if not (r/'checks/authorized-final-baseline-full-mypy/receipt.json').exists():prefix=''
ruff=[normalize(json.loads(read(k))) for k in ['root-ruff','baseline-root-ruff']]
for name,obj in zip(['candidate-ruff-normalized.json','baseline-ruff-normalized.json'],ruff):(r/name).write_text(json.dumps(obj,indent=2)+'\n')
roots=[normalize(read(k)) for k in ['root','baseline-root']]
def warnings(text):return text.split('warnings summary ===============================\n',1)[1].split('-- Docs:',1)[0]
def skips(text):return [line for line in text.splitlines() if line.startswith('SKIPPED ')]
def diagnostics(text):
 return [dict(path=m[0],line=int(m[1]),column=int(m[2]) if m[2] else None,message=m[3],code=m[4]) for m in re.findall(r'^(.+?):(\d+)(?::(\d+))?: error: (.+?)  \[([^]]+)\]$',normalize(text),re.M)]
mypy=[diagnostics(read(k)) for k in ['full-mypy','baseline-full-mypy']]
checks=[]
for p in sorted((r/'checks').glob(prefix+'*/receipt.json')):
 d=json.loads(p.read_text());checks.append({'id':p.parent.name,'exit_code':d['exit_code'],'stdout_sha256':d['stdout_sha256'],'stderr_sha256':d['stderr_sha256']})
out={'prefix':prefix,'ruff_counts':[len(x) for x in ruff],'complete_ruff_objects_equal':ruff[0]==ruff[1],'mypy_objects':mypy,'mypy_objects_equal':mypy[0]==mypy[1],'root_summaries':[re.findall(r'^\d+ passed,.*$',t,re.M)[-1] for t in roots],'skip_lines':skips(roots[0]),'skip_lines_equal':skips(roots[0])==skips(roots[1]),'full_warning_sections_equal':warnings(roots[0])==warnings(roots[1]),'checks':checks}
(r/'candidate-warning-section.txt').write_text(warnings(roots[0]));(r/'baseline-warning-section.txt').write_text(warnings(roots[1]));(r/'comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['checks','skip_lines','mypy_objects']},indent=2))
