import gzip
import hashlib
import json
import re
import subprocess
from collections import Counter
from pathlib import Path

work = Path('/private/tmp/friday-mcp-upgrade/work')
review = Path('/private/tmp/friday-mcp-upgrade/independent-review')
packet = work / 'docs/planning/active/friday-mcp-protocol-upgrade'
def sha(data): return hashlib.sha256(data).hexdigest()

# The inventory is derived directly from complete frozen source bytes, not from
# the implementation agent's clause ledger. One row covers each mandatory-keyword
# source line; neighboring lines retain wrapped requirements and role context.
rows=[]
for path in sorted((review/'normative').iterdir()):
    lines=path.read_text().splitlines()
    for i,line in enumerate(lines,1):
        if not re.search(r'\b(MUST|REQUIRED|SHALL)\b',line): continue
        status='NOT_APPLICABLE'; reason='Outside the tools-only stdio client role or optional feature is not implemented/advertised.'; evidence='protocol-contract.md supported profiles; exact twelve-path product diff in inventory.json'
        if '--authorization.md' in path.name or '--streamable-http.md' in path.name:
            reason='HTTP/OAuth binding belongs to separately unapproved UP-02B/03/05; existing legacy SSE source is unchanged.'
        elif path.name=='specification--2026-07-28--index.md':
            reason='BCP14 keyword definition, not a behavioral clause; lowercase host/UI guidance is not a capitalized normative clause.'
        elif path.name=='specification--2026-07-28--basic--index.md':
            if i in {19,29,48,49,50,72,73,75,85,86,87,105,106,107,120,123,127,128,140,162,174,259,293,294,299,303,307,330,370}:
                status='PASS';reason='Applicable client envelope, result/version, metadata emission, local/wire error separation or bounded JSON-Schema profile is implemented.';evidence='client/base.py:_request/_handle_message/_handle_server_message; client/protocol.py:validate_message/complete_result/ToolDefinition/validate_output_schema; checks/focused, checks/package, checks/adversarial-probes'
            if i in {336,337,345}:
                status='FAIL';reason='VAL-UP02A-002: incoming protocol metadata keys are not validated; invalid prefix/name accepted.';evidence='checks/adversarial-probes/stdout; client/protocol.py:200-237,259-274,329-349'
            if i==29:
                status='PARTIAL';reason='Envelope checks pass; applicable protocol/schema metadata validation is incomplete (VAL-UP02A-002).'
            if i in {203,426}:
                status='NOT_APPLICABLE';reason='No stateful continuation/handle handling or trace context emission/propagation. Peer trace data is ignored, never interpreted/exported.'
            if i in {466,478,481}:
                reason='No icon fetching, rendering or use; bounded opaque catalog metadata does not invoke an icon consumer.'
        elif '--basic--versioning.md' in path.name:
            if i==124:
                status='PASS';reason='No optional extensions advertised; unknown result tags fail instead of enabling a handler.';evidence='base.py:_request; protocol.py:complete_result; checks/focused'
            elif i==88:
                status='FAIL';reason='VAL-UP02A-002: supported extension names/settings are retained from server capabilities without declared-schema validation.';evidence='protocol.py:324-328; checks/adversarial-probes demonstrates analogous known-capability validation gap; schema ServerCapabilities'
        elif '--server--discover.md' in path.name:
            reason='Server implementation requirement; modern Friday server remains UP-05. Client discovery is tested independently in checks/focused and checks/package.'
        elif '--basic--transports--stdio.md' in path.name:
            if i in {15,22,38,83,146}:
                status='PASS';reason='Newline framing and valid outgoing requests/notifications, no modern client responses, bounded issued-request cancellation, and varied nonmodern-error fallback are tested.';evidence='stdio.py:send/receive; base.py:_handle_server_message/_cancel_request; checks/focused; checks/package'
            if i==52: reason='No subscriptions/listen requests opened or optional subscription handler enabled; unsolicited notifications do not cause effects.'
        elif '--server--tools.md' in path.name:
            if i in {18,293,305}:
                status='PASS';reason='Every request has required metadata; inputSchema is object/2020-12 validated; annotations are untrusted and never confer authorization.';evidence='base.py:_request; protocol.py:ToolDefinition.parse; unchanged accepted runtime/Chat trust paths; checks/focused/checks/cross-package-loopback'
            if i==234:reason='No MRTR retry; independent tools/call is never automatically replayed.'
            if 346<=i<=361:reason='x-mcp-header validation is HTTP-specific; stdio is explicitly permitted to ignore annotations.'
        elif '--basic--patterns--mrtr.md' in path.name:
            if i in {22,132,262,264}:
                status='PASS';reason='Required request metadata is present; input-required state is opaque, not retried or transferred to another request.';evidence='base.py:_request; protocol.py:complete_result; checks/focused; checks/package'
            if i in {258,261,263}:reason='Conditional on retrying; this approved profile explicitly refuses interactive continuation and performs no retry.'
        elif path.suffix=='.ts':
            if i in {37,229,232,624,1104}:
                status='PASS';reason='Unknown metadata not trusted; modern tag/legacy absence handled; cancellation references issued ID; no result caching.';evidence='protocol.py:complete_result; base.py:_request/_cancel_request; stdio.py:_issued_requests; checks/focused/checks/package'
            if i in {42,43,48,876}:
                status='FAIL';reason='VAL-UP02A-002: applicable incoming protocol metadata/extension naming and shapes are not validated.';evidence='protocol.py:Discovery.parse/ToolDefinition.parse/ToolResult.parse; checks/adversarial-probes'
            if i==575:
                status='PASS';reason='Input-required result must contain state or inputRequests; otherwise it fails; no handlers or replay.';evidence='protocol.py:complete_result; checks/focused'
            if i==938:reason='Icon rendering is not implemented.'
            if i in {2143,2148,2451,2512}:reason='Sampling/tool-use/model-selection capabilities not advertised or implemented; unsupported input request disposition is fixed.'
        rows.append({'id':f'N-{len(rows)+1:03d}','source':path.name,'line':i,'keyword_occurrences':len(re.findall(r'\b(MUST|REQUIRED|SHALL)\b',line)),'source_context':'\n'.join(lines[max(0,i-3):min(len(lines),i+3)]),'status':status,'reason':reason,'evidence':evidence})

# Required schema members with no uppercase keyword are separately evaluated.
structures=[
 ('RequestMetaObject/RequestParams','PASS','Required revision and clientCapabilities, optional package identity; base.py:_request, focused modern metadata wire test.'),
 ('JSONRPCRequest/Notification/Response/Error','PASS','Envelope and type-sensitive ID checks; fixed peer error handling; focused malformed/late/duplicate/concurrent cases.'),
 ('Result/ResultMetaObject/MetaObject','FAIL','VAL-UP02A-002; outer object check does not validate key grammar or known Implementation fields outside discovery.'),
 ('DiscoverResult/ServerCapabilities','FAIL','VAL-UP02A-002; listChanged accepts a string; extension keys/settings are not fully validated.'),
 ('CacheableResult','PASS','ttlMs and public/private types checked; no cache opened; focused discovery/catalog failure cases.'),
 ('PaginatedResult/ListToolsResult/Tool/BaseMetadata/Icons/ToolAnnotations','FAIL','VAL-UP02A-002; tools retain nonobject _meta and known optional fields without checking their schema types; no icons rendered/fetched.'),
 ('CallToolRequestParams','PASS','Tool name/arguments emitted from typed public signature and validated JSON boundary; unchanged routing tested.'),
 ('CallToolResult/TextContent/Annotations','FAIL','VAL-UP02A-002; TextContent _meta=[] and priority string accepted; text/structured values otherwise preserved and bounded.'),
 ('InputRequiredResult/InputRequests','PASS_WITH_LIMITATION','At least one state/request map required; unsupported outcome with no capability handlers, raw repr, continuation or replay. Input request internals are not executed.'),
 ('CancelledNotificationParams','PASS','No id on notification; requestId is issued string request; bounded send; initialize excluded.'),
 ('ImageContent/AudioContent/ResourceLink/EmbeddedResource','UNSUPPORTED_SAFE','Modern nontext returns fixed unsupported_content; no fetch/render occurs. Valid legacy mixed text compatibility retained.'),
 ('Other schema structures','NOT_APPLICABLE','Resources/prompts/sampling/elicitation/roots/subscriptions/completion/server-specific features and HTTP binding are not declared in this first tools-only client slice.'),
]
ledger={'origin':'Independent extraction from ten complete hash-verified frozen sources, not builder ledger. One row per source line containing MUST/REQUIRED/SHALL, including wrapped context. Typed applicable schema structures separately covered. Noncapitalized binding fallback prose is additionally evaluated as VAL-UP02A-001 under approved contract.','counts':dict(Counter(r['status'] for r in rows)),'rows':rows,'schema_structures':[{'structure':s,'status':st,'evaluation':ev} for s,st,ev in structures]}
(review/'normative-clause-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')

integrity=[]
for item in json.loads((packet/'execution/client-core/artifact-manifest.json').read_text())['artifacts']:
    raw=(packet/item['path']).read_bytes()
    decoded=gzip.decompress(raw) if item['encoding']=='gzip' else raw
    integrity.append({'path':item['path'],'stored_match':len(raw)==item['stored_bytes'] and sha(raw)==item['stored_sha256'],'content_match':len(decoded)==item['bytes'] and sha(decoded)==item['sha256']})
(review/'candidate-evidence-integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
skip_lists={name:[line for line in (review/'checks'/name/'stdout').read_text().splitlines() if line.startswith('SKIPPED')] for name in ('root-pytest-loopback','baseline-pytest-loopback')}
(review/'skip-comparison.json').write_text(json.dumps({'identical':skip_lists['root-pytest-loopback']==skip_lists['baseline-pytest-loopback'],'inventories':skip_lists},indent=2)+'\n')
checks=[json.loads(p.read_text())|{'label':p.parent.name} for p in sorted((review/'checks').glob('*/receipt.json'))]
(review/'command-ledger.json').write_text(json.dumps(checks,indent=2)+'\n')
final={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True),'product_hashes':{p:sha((work/p).read_bytes()) for p in json.loads((review/'inventory.json').read_text())['candidate_products']},'authority_sha256':sha((packet/'authority-manifest.json').read_bytes())}
initial=json.loads((review/'inventory.json').read_text())
final['preserved']=final['head']==initial['head'] and final['status']==initial['status'] and final['product_hashes']==initial['candidate_products'] and final['authority_sha256']==initial['authority_sha256']
(review/'freeze-closeout.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps({'normative_counts':ledger['counts'],'candidate_evidence_count':len(integrity),'candidate_evidence_mismatches':[r for r in integrity if not(r['stored_match'] and r['content_match'])],'skip_inventories_identical':skip_lists['root-pytest-loopback']==skip_lists['baseline-pytest-loopback'],'freeze_preserved':final['preserved']}))
