import hashlib, json, subprocess, sys, gzip
from pathlib import Path
from datetime import datetime, timezone
B=Path('/private/tmp/friday-mcp-upgrade'); R=B/'independent-review-UP05-002'; W=R/'runtime/candidate'; P=W/'docs/planning/active/friday-mcp-protocol-upgrade'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def capture(label):
    request=json.loads((P/'validation-request-REM-MCP-UP-006.json').read_text())
    inventories={}; files={}; distributions=[]; file_entries=[]
    for name,key in [('reused-library-manifest.json','copied'),('additional-validation-libraries.json','added')]:
        src=B/name; inventories[name]=sha(src)
        if not (R/'inputs'/name).exists():
            (R/'inputs').mkdir(exist_ok=True); (R/'inputs'/name).write_bytes(src.read_bytes())
        for d in json.loads(src.read_text())[key]:
            distributions.append({'name':d.get('distribution',d.get('name')),'version':d['version']})
            for f in d['files']:
                a=sha(B/'venv/lib/python3.13/site-packages'/f['path'])
                if a!=f['sha256']: raise RuntimeError('library mismatch '+f['path'])
                file_entries.append({'path':f['path'],'sha256':a}); files[f['path']]={'sha256':a,'bytes':(B/'venv/lib/python3.13/site-packages'/f['path']).stat().st_size}
    hashes={}; mismatches=[]
    for group in ['product_hashes','metadata_hashes','preserved_product_hashes']:
        hashes[group]={}
        for p,h in request[group].items():
            actual=sha(W/p); hashes[group][p]=actual
            if actual!=h: mismatches.append(p)
    controls=list(request['controls'])+[request['authority_manifest'],request['original_authority'],request['verification_profile']]
    hashes['controls']={}
    for e in controls:
        actual=sha(W/e['path']); hashes['controls'][e['path']]=actual
        if actual!=e['sha256']: mismatches.append(e['path'])
    histories={}
    for name in ['validation/VAL-UP05-01/stored-manifest.json','execution/rem006/stored-manifest.json']:
        m=P/name; entries=json.loads(m.read_text())['artifacts']; bad=[]
        for e in entries:
            p=m.parent/e['path']; raw=p.read_bytes()
            if hashlib.sha256(raw).hexdigest()!=e['stored_sha256']: bad.append(e['path'])
            raw=gzip.decompress(raw) if e.get('encoding')=='gzip' else raw
            if hashlib.sha256(raw).hexdigest()!=e['sha256'] or len(raw)!=e['bytes']: bad.append(e['path'])
        histories[name]={'entries':len(entries),'bad':bad,'sha256':sha(m)}
        if bad: raise RuntimeError('history mismatch')
    source_files={path:sha(W/path) for path in subprocess.check_output(['git','ls-files'],cwd=W,text=True).splitlines() if (W/path).is_file()}
    baseline=B/'independent-review-UP05-002/runtime/baseline'
    baseline_source_files={path:sha(baseline/path) for path in subprocess.check_output(['git','ls-files'],cwd=baseline,text=True).splitlines() if (baseline/path).is_file()}
    fixed={str(p):sha(p) for p in [B/'run_check.py',B/'run_check_UP05.py',B/'guard/sitecustomize.py',R/'run_check_UP05.py']}
    state={'time':datetime.now(timezone.utc).isoformat(),'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=W,text=True),'inventory_hashes':inventories,'library_files':files,'library_entries':file_entries,'library_count':len(file_entries),'unique_library_count':len(files),'distributions':distributions,'distribution_count':len(distributions),'fixed':fixed,'hashes':hashes,'mismatches':mismatches,'history':histories,'source_files':source_files,'baseline_source_files':baseline_source_files}
    (R/(label+'.json')).write_text(json.dumps(state,indent=2)+'\n')
    print(json.dumps({k:state[k] for k in ['time','commit','status','library_count','distribution_count','mismatches','history']}))
    if mismatches or len(file_entries)!=22009 or len(distributions)!=192 or state['status'] or state['commit']!='2b536516068f9e946572d165636211a24a93638d': raise RuntimeError('freeze mismatch')
if __name__=='__main__': capture(sys.argv[1])
