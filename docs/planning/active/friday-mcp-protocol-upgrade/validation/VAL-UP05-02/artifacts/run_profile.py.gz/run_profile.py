import json,subprocess,sys
from pathlib import Path
B=Path('/private/tmp/friday-mcp-upgrade'); R=B/'independent-review-UP05-002'
request=json.loads((B/'work/docs/planning/active/friday-mcp-protocol-upgrade/validation-request-REM-MCP-UP-006.json').read_text())
for check in request['required_checks']:
    label='full-001-'+check['id']
    if (R/'checks'/label).exists(): raise RuntimeError('label already exists')
    subprocess.run([str(B/'venv/bin/python'),str(R/'run_check_UP05.py'),label,check['snapshot'],*check['argv']],check=True)
    receipt=json.loads((R/'checks'/label/'receipt.json').read_text())
    print('CHILD',check['id'],receipt['exit_code'],flush=True)
for check in [c for c in request['required_checks'] if c['id'] in ['full-mypy','baseline-full-mypy']]:
    label='columns-001-'+check['id']
    subprocess.run([str(B/'venv/bin/python'),str(R/'run_check_UP05.py'),label,check['snapshot'],*check['argv'],'--show-column-numbers','--no-pretty'],check=True)
    receipt=json.loads((R/'checks'/label/'receipt.json').read_text())
    print('CHILD',label,receipt['exit_code'],flush=True)
