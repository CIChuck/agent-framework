from pathlib import Path
import hashlib,json
R=Path('/private/tmp/friday-mcp-upgrade/independent-review-UP05-002')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
metadata=json.loads((R/'manifest-metadata.json').read_text())
norm=json.loads((R/'source-capture-integrity.json').read_text())
modern_http=next(x for x in norm['captures'] if '/2026-07-28/basic/transports/streamable-http.md' in x['source'])
metadata['findings'][0]['normative_source']['sha256']=modern_http['sha256']
(R/'findings.json').write_text(json.dumps(metadata['findings'],indent=2)+'\n')
(R/'manifest-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
excluded={'evidence-manifest.json','evidence-manifest.sha256','seal-verification.json'}
entries=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 relative=p.relative_to(R)
 if relative.parts[0]=='runtime' or any(x in relative.parts for x in ['.git','__pycache__']) or relative.name in excluded:continue
 if relative.suffix=='.pyc' or relative.name in ['fixture-key.pem']:continue
 entries.append({'path':str(relative),'bytes':p.stat().st_size,'sha256':digest(p)})
metadata['entries']=entries
manifest=R/'evidence-manifest.json';manifest.write_text(json.dumps(metadata,indent=2)+'\n')
for e in json.loads(manifest.read_text())['entries']:
 p=R/e['path'];assert p.stat().st_size==e['bytes'] and digest(p)==e['sha256']
result={'outcome':metadata['outcome'],'candidate_commit':metadata['candidate_commit'],'entries':len(entries),'all_entry_bytes_hashes_verified':True,'manifest_sha256':digest(manifest),'report_sha256':digest(R/'report.md'),'archive_exclusions':'All runtime clone/HOME/TMP/cache/stores/generated cert privatekeys, .git and bytecode excluded.'}
(R/'evidence-manifest.sha256').write_text(result['manifest_sha256']+'  evidence-manifest.json\n')
(R/'seal-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
