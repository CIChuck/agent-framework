# VERIFIED

Fresh-context, READ-ONLY independent finding-delta review for approved REM-MCP-UP-002, followed by FULL original CD-MCP-UP-002 / MCP-UP-02B work-unit review. Reviewer: separate Codex agent `/root/mcp_up02b_remediation_validator`, GPT-6 family; exact serving model/version unavailable. Date: 2026-10-12. Frozen candidate: `14dba178feff8789111db88d981f1d0e85e6a748`, branch `feature/friday-mcp-protocol-upgrade`, clean at initial and final inventories. Product baseline: `256d09d2f6a89846b5b77c4ae6436750d9bdbd95`; reproducible pre-CD2 baseline: `9e00288b4b36632bb82b98955a88dec0545efb47` in `http-baseline`. Failed original HTTP candidate: `2a3cec520f20442515d3d9a5a1a33eb500bd8846`; approved remediation execution baseline: `05118298b10a396d5aff5de61f074a4ff251b695`.

All four original mandatory findings are resolved, and no additional violated requirement was identified in the full authorized work unit. This verdict covers this committed HTTP unit only. It is not maintainer acceptance, whole-MCP completion, remote Runtime/Chat admission, merge, release, publication, or live-provider validation.

## Authority, independence and preservation

Read AGENTS.md and its engineering/lifecycle/independent-validation policies, the frozen original and remediation request/manifests, both separate approval receipts, immutable proposed directives/proposal manifests, prior controls and approved build/protocol/tactical/conformance contracts. The proposed labels remain intentionally frozen; Chuck Russell's separate receipts authorize those exact bytes. The archived original CHANGES_REQUESTED report was read and its decompressed SHA256 independently matched `e97e199a556be162ff99a46d6d3ec6db75de3ef61cff5985447b47fbd73487c3`.

`inventory.json` and `initial-inventory.json` verify 93 pinned hashes with no mismatch, all 18 complete normative captures including both dated schemas, exact fourteen overall product paths, exact six remediation paths, prior frozen controls, archived original builder and validator artifacts, approved dependency boundaries, candidate SHA/branch/clean state, and guard SHA. `full-product.diff` and `remediation-product.diff` retain the complete selected product changes; `full.diff` and `remediation.diff` also retain process changes. No original control/artifact was replaced. The three immutable original private probes match their archived source hashes in `original-probe-integrity.json`; copies are retained in `original_probes/`.

The remediation directive SHA256 is `bab8e478d5d2e73d3d79818c9984474e5a0ab136ae9230179718487f17197240`; approved proposal manifest `45a40aa7d241b44b68021ab1d7a0e1dae461bec8350bb3c05627123b706c7873`; remediation authority `da46b64374f63ddb937d1073baae241d6832264de5fa34e4f07ef47ad758a785`; remediation approval `6ff881f654dc2a4894f57c1393700fa481349b938bd16ea1d48c57ef82390cf9`. Original CD2 authority, approval, proposal and directive pins remain unchanged and are recorded in the inventories.

No builder private reasoning/conclusion was inherited or used as a verdict. The task envelope, shared filesystem/tools and controlled wire-peer helper infrastructure are the context exceptions. Builder archived argv/effects records supplied reproducibility inputs only. Assertions in `test_fresh_probes.py` were authored independently; the candidate and shared checkout were not edited. Reviewer writes consist solely of private evidence and originally allowed HOME/cache/TMP/check scratch. No commits, board/process mutations, package synchronization, credentials, live services, public DNS/TCP, providers, publication or arbitrary external peers were used.

## Original finding resolution matrix

| Finding | Independent resolution evidence | Result |
| --- | --- | --- |
| VAL-UP02B-001 | `http_protocol.py:16-36,115-160` now visits contentSchema and the full 2020-12 schema-bearing vocabulary as unreachable outside properties paths. Fresh probes cover 21 keywords, direct/nested contentSchema and six valid/malformed annotation shapes, exact six rejected-tool counts, no invalid-tool call issuance, opaque schema-looking application JSON, and exact matching Unicode/sentinel wire encoding. The HTTP suite additionally inspects zero partial publication while a later page is held. Original reproducer passes. | RESOLVED |
| VAL-UP02B-002 | `http.py:153-156,211-215,653-685,706-795` scopes recovery/publication to generations and serializes lifecycle ownership. Fresh controlled concurrent calls cover delayed old404 after successful recovery, failed recovery followed by explicit connect, recovery deadline failure, disconnect during recovery, and stale waiter's shorter deadline during active recovery. Healthy session/catalog/generation are retained; exact counters show one recovery for the expired generation and no mutation replay; initialize never carries old session ID; subsequent explicit call succeeds; all streams/jobs/pool owners clean up. Original reproducer passes. | RESOLVED |
| VAL-UP02B-003 | `protocol.py:363-372`, compatibility response validation, and atomic local catalog construction reject malformed/unsupported declared2025 dialects with fixed unsupported_schema. Fresh probes reject five additional declaration shapes on later pages after a previous good catalog, retain no partial/stale catalog/bindings, issue no calls during catalog validation, and perform only controlled endpoint resolution. Required regressions prove absent/supported2020-12 success and modern/2024 preservation. Original reproducer passes. | RESOLVED |
| VAL-UP02B-004 | `protocol.py:239-257,288-309,335-406,409-459` enforces grammar at selected dated received metadata boundaries without modern reserved-value interpretation. Fresh assertions separately cover 13 malformed forms across Tool, Result, TextContent, initialize/list results and received request/notification params; valid empty/prefixed/unprefixed keys retain opaque values, application JSON remains data, legacy2024 stays permissive and modern reserved metadata stays strict. Wire-level original and required regressions reject invalid metadata with fixed payload-free outcomes. Original Tool/Result/TextContent reproducers all pass. | RESOLVED |

Fresh final suite: **130 passed**. Original independent regression suite: **6 passed**. Both remain outside the candidate.

The immutable exploratory scripts `adversarial_probes.py` and `compatibility_probes.py` were also rerun exactly. Their child exits are 1 because their old success-oriented print probes now encounter the required corrected rejection, respectively invalid contentSchema annotation and unsupported2025 dialect, before reaching later prints. Those nonzero outputs are retained and explicitly classified as expected rejection demonstrations, not passing suites or hidden product failures. The six independent regression assertions and fresh probes supply complete finding verification.

An initial reviewer-added assertion assumed the2025 low-level API must disable all later explicit uncatalogued calls after a failed catalog. That exceeds the approved requirement: catalog validation must fail atomically and issue no tool call, while the existing2025 explicit uncatalogued-call API is preserved; only modern HTTP requires successful catalog bindings before calls. Five initial probe failures reflect that invalid reviewer assumption. `test_fresh_probes.initial.py` and `checks/fresh-probes/` retain the exact initial source/output; the corrected final assertions test the actual authority. No product change was made to satisfy reviewer tests.

## Full original work-unit review

`normative-clause-schema-review.json` reconciles all **218 frozen clause paragraphs**, every selected **98 schema interfaces /231 fields**, complete sources, candidate modules, criterion families and independently executed evidence. An independent scan of all18 captures finds no omitted paragraph containing mandatory terms; each frozen source paragraph/definition/field is checked against its captured bytes. Both schemas are pinned to upstream commit `271ecc9accafdd9b83a3c869fa67c22953b2af80`. The frozen ledger's347 occurrences omit two SHALL tokens solely within its BCP14 terminology definition; the independent count349 includes them. These are terminology definitions, not missing implementation obligations.

The independent ledger distinguishes client obligations and adverse-peer validation from server-only duties, preserves stdio obligations, and separately classifies optional/capability-dependent exclusions. In particular2025 POST/Accept rules and issued cancellation remain applicable despite mixed optional GET/task paragraphs. SDK interoperability supplements the dated source review and does not establish conformance by itself.

| Criterion | Source, required positive/negative and independent proof | Disposition |
| --- | --- | --- |
| HTTP-AC-01 | Explicit2026/2025 constructors; modern metadata/discovery vs2025 initialization; honest empty capabilities; dated envelope/metadata/schema/result validation; required297 HTTP and228 original client tests, six original reproducers and fresh dated/legacy/modern probes. | PASS |
| HTTP-AC-02 | `SSEDecoder`, `_decode`, `_exchange`: JSON/SSE, UTF-8 splits, CR/LF/comments/priming/multiline/truncation, malformed status/content-type/envelope/IDs, duplicate results, unsupported messages and concurrent isolated streams; real SDK JSON/SSE. | PASS |
| HTTP-AC-03 | Header/body revision/method/name agreement, property-only extraction, safe token/collision/scalar/integer rules, exact UTF-8 Base64 including sentinel-shaped ASCII, absent/null omission and bad arguments before I/O; vocabulary/contentSchema/opaque JSON fresh probes. | PASS |
| HTTP-AC-04 | Pre-retention raw HTTP wire/header and SSE line/event/count limits; URL/session/generated headers; bounded JSON/catalog/result and owner capacity; one monotonic send/DNS/catalog/recovery deadline. Required boundary/stall/resistant-owner tests plus fresh recovery waiter/deadline probes. | PASS |
| HTTP-AC-05 | `retries=0`, no automatic tools/call replay, request stream scoped modern cancellation, bounded issued non-initialize compatibility cancellation. Synthetic execution counters under status/drop/disconnect/timeout/session/shutdown failures; fresh exact concurrent counters. | PASS |
| HTTP-AC-06 | Exact2025 initialize/version/initialized/session/DELETE and unsupported server request handling; literal-loopback2025 counterpart; one generation-owned404 reinitialize without old ID/replay; healthy subsequent explicit calls after stale responses. | PASS |
| HTTP-AC-07 | Endpoint rejection before I/O, public typed httpcore backend; every DNS candidate checked at actual connection; controlled changed/mixed addresses and exact numeric connector/port inspection; original hostname retained for verified TLS/SNI; real loopback TLS success/wrong-host failure; no redirect/proxy/cookie/ambient credential use or token forwarding. | PASS |
| HTTP-AC-08 | Tasks/streams/pool/partial TLS startup owned; retained cleanup-resistant owners observable/capacity-bounded/retryable; borrowed resolver/connector open; primary failures preserved; fresh generation/shutdown/deadline ownership and zero final owners. | PASS |
| HTTP-AC-09 | Required suite runs two named real literal127.0.0.1 synthetic peers: official SDK2.3.0 modern JSON/SSE and independent exact2025 session peer, plus generated private TLS, ambiguous-drop and cancel counters. Complete dated clause/schema ledger reviewed independently. | PASS |
| HTTP-AC-10 | Exact14 overall/six delta paths, immutable controls/artifacts, useful public explicit API/limits/security/profile docs, no new suppressions, only approved direct httpcore edge, complete raw commands and baseline comparison; Runtime/Chat/Telemetry and root regressions. | PASS |

The accepted base/protocol/export/dependency boundaries and all new HTTP source, tests and fixture files were reviewed in the full product diff. `base.py` now permits request-scoped subclasses while still enforcing the shared transport invariant explicitly, and snapshots the call's output schema across concurrent catalog refresh. The public export is additive; old constructors/defaults, stdio/SSE, manager/config, Runtime/Chat/Core/Telemetry/server/YAML source are preserved. Whole-lock TOML equality holds after removing only the two approved direct httpcore dependency/declaration edges; remediation changes no metadata/dependency bytes. No runtime SDK import, private httpcore API dependency, new cast workaround, source-ignore expansion or global lint/type weakening was found.

## Independently executed profile and baseline

`command-ledger.json` and each `checks/<label>/receipt.json`, `stdout`, `stderr` retain full argv, cwd, allowlisted environment, UTC timestamps, child exit, stream SHA256 and guard SHA256. `pre-execution-check-freeze.json` freezes the exact original profile argv and the immutable runner hash that defines its complete per-label allowlisted environment, before execution; raw receipts confirm those environments. All pytest/Mypy executions use the private Python with `-m`, and Ruff uses the private binary. The runner exits0 regardless of child failure; every child receipt was inspected.

| Check | Actual child exit / result |
| --- | --- |
| Three HTTP files |0;297 passed |
| Four original focused client files |0;228 passed |
| Full MCP package |0;561 passed |
| Runtime/Chat/Telemetry |0;1211 passed,5 skipped,1 warning |
| Root configured pytest |0;3628 passed,14 skipped,15 warnings |
| Preserved baseline root pytest |0;3331 passed,14 skipped,15 warnings |
| Changed/new11 Python path Ruff |0;clean |
| Root / baseline Ruff JSON |1 /1;exact327 inherited full diagnostic/fix objects, no additions/removals |
| Six module Mypy / full MCP Mypy |0 /0;6 /21 source files |
| Board validate/next/show |0;26 tasks, initiative started/granted/local, correct branch and independent-review gate |
| Documentation lifecycle/render |0;checks passed |
| Whitespace (working tree and full/delta ranges) |0;clean |
| Original six regressions |0;6 passed |
| Final fresh adversarial suite |0;130 passed |
| Candidate/baseline repeat with -rs |0 /0;exact same skip locations/reasons and full normalized warning sections |

`ruff-comparison.json` retains both complete normalized arrays, including fixes, locations and all diagnostic fields; no diagnostic is added or removed. This nonzero historical gate is reported as unchanged approved baseline debt, not a newly waived success. `baseline-comparison.json` retains exact warnings and skips. Thirteen unchanged skips require explicit live LM Studio authority, and one graph test cannot import optional scipy; they supply no live/provider proof. Warning classes are exactly `DeprecationWarning` and `PydanticDeprecatedSince211`, with identical normalized full sections. Candidate's297 additional passes are the new HTTP suite; no missing accepted baseline tests were inferred from counts alone.

`checks/environment` confirms Python3.13.10, mcp/mcp-types2.3.0, httpcore1.0.9, IDNA3.20, jsonschema4.25.1 and referencing0.37.0. Runner environments have no ambient OTEL fields or provider credentials; TOKENIZERS_PARALLELISM is only an execution toggle. Guard SHA256 is `38f6a7483d66a066336d63c14980f1acfe307ec38848f0761c6928a66989a7a8`. The guards/effects remain the original offline profile; no actual public-looking address in controlled resolver probes is contacted.

## Limits and next gate

Inherited `# mypy: ignore-errors` remain unchanged in client/__init__.py and sse.py, root __init__.py, protocols.py, config.py, both utils modules and existing server modules. The new HTTP and changed base/protocol modules preserve meaningful typing without new suppressions. Full MCP Mypy does not erase inherited ignored debt; root Ruff, skipped optional/live checks and deterministic wire proof are separate evidence classes.

Unsupported dialect/content/input-required outcomes are safe explicit limits, not full optional-feature conformance.2025 explicit low-level uncatalogued calls remain possible by existing contract; modern calls require successful catalog/header bindings. OAuth acquisition/login/discovery/refresh, subscriptions/GET/resumption/tasks/MRTR fulfillment, resources/prompts, Runtime/Chat remote YAML admission, modern Friday-server publication, aggregate initiative acceptance and Langfuse remain separately gated. No real credentials, model/exporter or external service was used. Root validation covers configured discovery, not every unselected top-level lab suite or clean-install distribution proof.

No numbered actionable product finding remains. The controller may record this independent unit verdict and prepare the next authorized gate. Maintainer acceptance and any later construction/delivery authority remain separate. Candidate, governing authority and clean private work were rechecked unchanged at closeout; any later governed change invalidates this result.
