import json,subprocess,shutil,hashlib
from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade');d=b/'independent-review-UP02B-002';w=b/'work';r=json.loads((w/'docs/planning/active/friday-mcp-protocol-upgrade/validation-request-UP-02B.json').read_text());checks=[(n,'work',a) for n,a in r['required_checks'].items()]+[(n,'http-baseline',r['required_checks'][a]) for n,a in [('baseline-root','root'),('baseline-ruff','root-ruff')]]
(d/'pre-execution-check-freeze.json').write_text(json.dumps({'checks':checks,'runner_sha256':hashlib.sha256((b/'run_check.py').read_bytes()).hexdigest(),'guard_sha256':hashlib.sha256((b/'guard/sitecustomize.py').read_bytes()).hexdigest()},indent=2)+'\n')
ledger=[]
for n,s,a in checks:
 p=subprocess.run([str(b/'venv/bin/python'),str(b/'run_check.py'),'review-rem002-'+n,s,*a],capture_output=True,text=True);print(p.stdout.strip(),flush=True)
 if p.stderr:print(p.stderr,flush=True)
 src=b/'checks'/('review-rem002-'+n);target=d/'checks'/n;shutil.copytree(src,target,dirs_exist_ok=True);ledger.append(json.loads((target/'receipt.json').read_text()));(d/'command-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
