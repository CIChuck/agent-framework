import sys,json,importlib.metadata,os
print(json.dumps({'python':sys.version,'packages':{k:importlib.metadata.version(k) for k in ['mcp','mcp-types','httpcore','jsonschema','referencing','idna']},'ambient_otel_keys':[k for k in os.environ if k.startswith('OTEL_')],'credential_variable_names':[k for k in os.environ if any(s in k for s in ['API_KEY','TOKEN','SECRET'])]},indent=2))
