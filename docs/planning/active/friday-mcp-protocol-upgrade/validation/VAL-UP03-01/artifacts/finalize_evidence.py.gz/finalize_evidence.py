from pathlib import Path
import hashlib,json,re,subprocess
from datetime import datetime,timezone
r=Path('/private/tmp/friday-mcp-upgrade/independent-review-UP03');w=Path('/private/tmp/friday-mcp-upgrade/work');p=w/'docs/planning/active/friday-mcp-protocol-upgrade';req=json.loads((p/'validation-request-UP-03.json').read_text());h=lambda data:hashlib.sha256(data).hexdigest()
objects=[]
for name in ['columns-full-mypy','columns-baseline-full-mypy']:
 data=(r/'checks'/name/'stdout').read_text();items=[]
 for m in re.finditer(r'^(.+?):(\d+):(\d+): error: (.+?)\s+\[([^]]+)\]$',data,re.M):
  items.append(dict(path=m[1],line=int(m[2]),column=int(m[3]),message=m[4],code=m[5]))
 objects.append(items)
(r/'mypy-column-comparison.json').write_text(json.dumps({'candidate':objects[0],'baseline':objects[1],'equal':objects[0]==objects[1],'count':len(objects[0]),'argv_delta':['--show-column-numbers'],'source':'checks/columns-{full-mypy,baseline-full-mypy}/receipt.json'},indent=2)+'\n')
check=subprocess.run(['git','diff','--check',req['base_commit']+'..HEAD'],cwd=w,capture_output=True,text=True)
inputs=['validation-request-UP-03.json','authority-UP-03.json','approval-UP-03.json','directives/CD-MCP-UP-003-runtime-yaml-chat.md','up03-integration-contract.md','verification-profile-UP-03.json']
freeze={'utc':datetime.now(timezone.utc).isoformat(),'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True),'aggregate_whitespace':{'argv':check.args,'exit_code':check.returncode,'stdout':check.stdout,'stderr':check.stderr},'product_hashes':{k:h((w/k).read_bytes()) for k in req['product_hashes']},'metadata_hashes':{k:h((w/k).read_bytes()) for k in req['metadata_hashes']},'authority_hashes':{k:h((p/k).read_bytes()) for k in inputs},'pinned_runner_sha256':h(Path('/private/tmp/friday-mcp-upgrade/run_check.py').read_bytes()),'guard_sha256':h(Path('/private/tmp/friday-mcp-upgrade/guard/sitecustomize.py').read_bytes())}
freeze['product_hashes_unchanged']=freeze['product_hashes']==req['product_hashes'];freeze['metadata_hashes_unchanged']=freeze['metadata_hashes']==req['metadata_hashes'];(r/'closing-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
assert objects[0]==objects[1] and len(objects[0])==4
assert freeze['candidate']=='a897b3deaa9e007223c8ecbe7cfbfb4750ef10b7' and not freeze['status'] and freeze['product_hashes_unchanged'] and freeze['metadata_hashes_unchanged'] and check.returncode==0
print('Column comparison exact; closing freeze clean and unchanged',freeze['utc'])
