from pathlib import Path
import gzip,hashlib,json,re,subprocess,collections
b=Path('/private/tmp/friday-mcp-upgrade'); w=b/'work'; r=b/'independent-review-UP03'; p='docs/planning/active/friday-mcp-protocol-upgrade/'
h=lambda x:hashlib.sha256(x).hexdigest(); records=[]; visited=set()
def scan(value,owner):
 if isinstance(value,dict):
  if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
   path=value['path']; file=w/path if not path.startswith('/') else Path(path)
   if file.exists(): records.append({'owner':owner,'path':path,'expected':value['sha256'],'actual':h(file.read_bytes()),'match':h(file.read_bytes())==value['sha256']})
   else: records.append({'owner':owner,'path':path,'missing':True})
  for child in value.values():scan(child,owner)
 elif isinstance(value,list):
  for child in value:scan(child,owner)
for name in ['authority-UP-03.json','approval-UP-03.json','authority-manifest.json','authority-UP-02B.json','authority-REM-MCP-UP-002.json','proposals/UP-03-authority-manifest.json']:
 data=json.loads((w/p/name).read_text());scan(data,p+name)
req=json.loads((w/p/'validation-request-UP-03.json').read_text());scan(req,p+'validation-request-UP-03.json')
products=[]
for path,expected in req['product_hashes'].items(): products.append({'path':path,'sha256':h((w/path).read_bytes()),'match':h((w/path).read_bytes())==expected})
metadata=[]
for path,expected in req['metadata_hashes'].items():
 cur=(w/path).read_bytes(); old=subprocess.check_output(['git','show',req['base_commit']+':'+path],cwd=w)
 metadata.append({'path':path,'sha256':h(cur),'request_match':h(cur)==expected,'baseline_identical':cur==old})
changed=subprocess.check_output(['git','diff','--name-only',req['base_commit']+'..HEAD'],cwd=w,text=True).splitlines();extra=[x for x in changed if x not in req['product_hashes'] and x not in ['docs/planning/README.md','docs/planning/board.yaml'] and not x.startswith('docs/planning/active/friday-mcp-protocol-upgrade/') and not x.startswith('docs/archive/completed/2026/friday-mcp-protocol-upgrade-up-02b/')]
sources=[]
for folder in ['research-sources','research-sources/up02b']:
 m=json.loads((w/p/folder/'manifest.json').read_text())
 for s in m['sources']:
  file=w/p/folder/s['artifact'];raw=file.read_bytes();content=gzip.decompress(raw).decode();sources.append({**s,'path':str(file.relative_to(w)),'compressed_match':h(raw)==s['artifact_sha256'],'content_match':h(content.encode())==s['sha256'],'bytes_match':len(content.encode())==s['bytes'],'mandatory_count':len(re.findall(r'\b(?:MUST|SHALL|REQUIRED)\b',content))}); (r/'sources').mkdir(exist_ok=True); (r/'sources'/file.name.removesuffix('.gz')).write_text(content)
ledger=json.loads(gzip.decompress((w/p/'execution/up03/artifacts/normative-clause-ledger.json.gz').read_bytes()));plan=json.loads(gzip.decompress((w/p/'execution/up03/artifacts/normative-clause-plan.json.gz').read_bytes())); issues=[]
for c in ledger['clauses']:
 s=next((s for s in sources if s['url']==c['source']),None)
 if s is None:issues.append(['unknown-source',c['source']]);continue
 content=gzip.decompress((w/s['path']).read_bytes()).decode();text=c['paragraph']
 if text not in content:issues.append(['paragraph-not-found',c['source'],c['line']])
 if c['source_sha256']!=s['sha256']:issues.append(['source-hash',c['source']])
 for kind in ['assembly_positive','assembly_negative']:
  for test in c[kind]:
   path,_,func=test.partition('::');data=(w/path).read_text() if (w/path).exists() else ''
   if not data or func and not re.search(r'\bdef '+re.escape(func)+r'\(',data):issues.append(['missing-test',test])
keys={'source','source_sha256','line','section','paragraph','mandatory_occurrences','applicability','reason','group','accepted_transport_evidence','integration_criteria'}
lossless=len(plan['clauses'])==len(ledger['clauses']) and all({k:a[k] for k in keys}=={k:z[k] for k in keys} for a,z in zip(plan['clauses'],ledger['clauses']))
report={'authority_refs':records,'authority_failures':[x for x in records if not x.get('match',False)],'products':products,'metadata':metadata,'changed_product_paths':[x for x in changed if x in req['product_hashes']],'unexpected_paths':extra,'sources':sources,'ledger_keys':list(ledger),'ledger_clauses':len(ledger['clauses']),'ledger_occurrences':sum(c['mandatory_occurrences'] for c in ledger['clauses']),'ledger_plan_lossless_controls':lossless,'ledger_issues':issues,'applicability_counts':dict(collections.Counter(c['applicability'] for c in ledger['clauses']))}
(r/'input-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k in ['authority_failures','unexpected_paths','ledger_keys','ledger_clauses','ledger_occurrences','ledger_plan_lossless_controls','ledger_issues','applicability_counts']},indent=2));print('Sources',len(sources),'products',len(products),'all source hashes',all(s['compressed_match'] and s['content_match'] and s['bytes_match'] for s in sources))
