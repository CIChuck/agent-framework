from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
r=Path('/private/tmp/friday-mcp-upgrade/independent-review-UP03');report=r/'report.md'
s=report.read_text().replace('`271ecc9…baf80`','`271ecc9accafdd9b83a3c869fa67c22953b2af80`').replace('test_actual_connect_validates_changing_dns_and_preserves_tls_hostname','test_runtime_actual_connect_policy_rechecks_dns_and_preserves_hostname')
report.write_text(s)
files=[]
for f in sorted(r.rglob('*')):
 rel=f.relative_to(r)
 if not f.is_file() or rel.parts[0]=='runtime' or rel.as_posix() in ['evidence-manifest.json','evidence-manifest.sha256']:continue
 data=f.read_bytes();files.append({'path':rel.as_posix(),'source_path':str(f),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'review_id':'MCP-UP-03-original-independent-review','outcome':'CHANGES_REQUESTED','candidate':'a897b3deaa9e007223c8ecbe7cfbfb4750ef10b7','created_utc':datetime.now(timezone.utc).isoformat(),'archive_rule':'Copy exact original bytes only from listed source paths; preserve relative paths. No runtime material. Manifest excludes itself to avoid recursive hashes.','excluded_paths':[str(r/'runtime')],'exclusion_reason':'Generated private HOME/cache/TLS keys/stores and copied warm cache; not review artifacts.','files':files}
p=r/'evidence-manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n');(r/'evidence-manifest.sha256').write_text(hashlib.sha256(p.read_bytes()).hexdigest()+'  evidence-manifest.json\n')
assert not any('/runtime/' in x['source_path'] for x in files)
assert all(hashlib.sha256(Path(x['source_path']).read_bytes()).hexdigest()==x['sha256'] for x in files)
print(json.dumps({'files':len(files),'bytes':sum(x['bytes'] for x in files),'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'excluded':manifest['excluded_paths']},indent=2))
