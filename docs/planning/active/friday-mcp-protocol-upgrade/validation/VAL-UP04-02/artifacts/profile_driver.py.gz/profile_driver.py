import json,subprocess,sys
from pathlib import Path
from freeze import freeze
base=Path('/private/tmp/friday-mcp-upgrade');e=base/'independent-review-UP04-002'
p=json.loads((base/'work/docs/planning/active/friday-mcp-protocol-upgrade/verification-profile-REM-MCP-UP-004.json').read_text())
for c in p['checks']:
 label=c['id'];freeze(label)
 r=subprocess.run([sys.executable,str(e/'run_check_UP04_review.py'),label,c['snapshot'],*c['argv']])
 receipt=json.loads((e/'checks'/label/'receipt.json').read_text());print(label,receipt['exit_code'],flush=True)
