from pathlib import Path
import json,hashlib,subprocess,shutil,gzip
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';e=b/'independent-review-UP04-002';p=w/'docs/planning/active/friday-mcp-protocol-upgrade'
def sha(x):return hashlib.sha256(x).hexdigest()
request=json.loads((p/'validation-request-REM-MCP-UP-004.json').read_text())
paths=set(request['product_hashes'])|set(request['metadata_hashes'])|{'AGENTS.md','docs/reference/policies/repository-engineering-policy.md','docs/reference/policies/development-task-lifecycle.md','docs/reference/policies/independent-validation-policy.md'}
controls={};issues=[];visited=set()
def visit(x):
 if isinstance(x,list):
  for v in x:visit(v)
 elif isinstance(x,dict):
  if 'path' in x and 'sha256' in x and isinstance(x['path'],str) and x['path'].startswith(('docs/','AGENTS')):
   q=w/x['path']
   if not q.exists():issues.append({'path':x['path'],'issue':'missing'});return
   h=sha(q.read_bytes()); controls[x['path']]=h
   if h!=x['sha256']:issues.append({'path':x['path'],'expected':x['sha256'],'actual':h})
   if q.suffix=='.json' and x['path'] not in visited:
    visited.add(x['path']);visit(json.loads(q.read_text()))
  for k,v in x.items():
   if k not in ('entries','files'):visit(v)
visit(request)
paths|=set(controls)
for q in sorted(paths):
 dest=e/'inputs'/'sources'/q;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/q,dest)
(e/'authority-audit.json').write_text(json.dumps({'controls':controls,'issues':issues},indent=2)+'\n')
(e/'freeze-paths.json').write_text(json.dumps(sorted(paths),indent=2)+'\n')
def freeze(label):
 out=e/'checks'/label;out.mkdir(parents=True,exist_ok=True)
 d={'candidate_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=w,text=True),'hashes':{q:sha((w/q).read_bytes()) for q in paths},'guard_sha256':sha((b/'guard/sitecustomize.py').read_bytes()),'original_runner_sha256':sha((b/'run_check.py').read_bytes()),'UP04_runner_sha256':sha((b/'run_check_UP04.py').read_bytes())}
 assert d['candidate_commit']=='0fac03d69d0fb74eb52429970e5c0910b65922fe' and not d['status']
 (out/'candidate-authority-freeze.json').write_text(json.dumps(d,indent=2)+'\n')
 return d
if __name__=='__main__':
 import sys
 freeze(sys.argv[1] if len(sys.argv)>1 else 'initial')
 print(json.dumps({'controls':len(controls),'issues':issues,'paths':len(paths)}))
