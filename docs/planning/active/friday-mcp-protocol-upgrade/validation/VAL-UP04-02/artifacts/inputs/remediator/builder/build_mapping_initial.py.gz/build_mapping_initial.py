from pathlib import Path
import json,hashlib,re,gzip,sys,inspect
root=Path('/private/tmp/friday-mcp-upgrade/work'); out=Path('/private/tmp/friday-mcp-upgrade/rem004-builder-evidence')
sys.path.insert(0,str(root/'packages/friday-mcp'))
from tests_mcp.client.test_result_refresh import input_variant_cases
from friday_mcp.client import protocol
cases=[{'id':x.id,'input_request':x.values[0],'failure_code':x.values[1],'local_code':-32100 if x.values[1]=='input_required_unsupported' else -32021,'test':'packages/friday-mcp/tests_mcp/client/test_result_refresh.py::test_input_variant_public_disposition_privacy_and_zero_continuation','profiles':['stdio','2026-07-28'],'commands':['matrix-6','focused-final']} for x in input_variant_cases()]
(out/'actual-variant-matrix.json').write_text(json.dumps(cases,indent=2)+'\n')
modern=(out/'modern-schema.ts').read_text(); names=['InputRequest','InputRequests','CreateMessageRequest','CreateMessageRequestParams','SamplingMessage','SamplingMessageContentBlock','ToolUseContent','ToolResultContent','ContentBlock','TextContent','ImageContent','AudioContent','ToolChoice','ModelPreferences','ModelHint','Tool','ListRootsRequest','ElicitRequest','ElicitRequestParams','ElicitRequestFormParams','ElicitRequestURLParams','PrimitiveSchemaDefinition','StringSchema','NumberSchema','BooleanSchema','EnumSchema','SingleSelectEnumSchema','MultiSelectEnumSchema','UntitledSingleSelectEnumSchema','TitledSingleSelectEnumSchema','LegacyTitledEnumSchema','UntitledMultiSelectEnumSchema','TitledMultiSelectEnumSchema']
prefixes={
'InputRequest':['unknown-method','roots','sampling-params','form-params','url-params'],
'InputRequests':['unknown-method','roots','sampling-params','form-params','url-params'],
'CreateMessageRequest':['sampling/createMessage-params'],
'CreateMessageRequestParams':['sampling-params','maxTokens','model-preferences','model-hint','sampling-tool','tool-choice'],
'SamplingMessage':['sampling-message','tool-result-unmatched'],
'SamplingMessageContentBlock':['text','image','audio','tool-use','tool-result','sampling-outer'],
'ToolUseContent':['tool-use'], 'ToolResultContent':['tool-result'],
'ContentBlock':['text','image','audio','sampling-outer','tool-result-nested'],
'TextContent':['text'], 'ImageContent':['image'],'AudioContent':['audio'],
'ToolChoice':['tool-choice'],'ModelPreferences':['model-preferences','model-hint'],'ModelHint':['model-hint','model-preferences-hints'],
'Tool':['sampling-tool'], 'ListRootsRequest':['roots'], 'ElicitRequest':['elicitation/create-params','form-params','url-params'],
'ElicitRequestParams':['form-params','url-params'], 'ElicitRequestFormParams':['form-params','requested-schema','form-malformed-sibling'],
'ElicitRequestURLParams':['url-params'], 'PrimitiveSchemaDefinition':['string','number','integer','boolean','single','multi','legacy','invalid-property'],
'StringSchema':['string'], 'NumberSchema':['number','integer'], 'BooleanSchema':['boolean'],
'EnumSchema':['single','multi','legacy','oneOf','anyOf','array-items'], 'SingleSelectEnumSchema':['single','legacy','oneOf'],
'MultiSelectEnumSchema':['multi','anyOf','array-items'], 'UntitledSingleSelectEnumSchema':['single-enum'],
'TitledSingleSelectEnumSchema':['single-titled','oneOf'], 'LegacyTitledEnumSchema':['legacy-titled'],
'UntitledMultiSelectEnumSchema':['multi-enum','array-items'], 'TitledMultiSelectEnumSchema':['multi-titled','anyOf','array-items']}
rows=[]
for name in names:
 m=re.search(r'^export (?:interface|type) '+name+r'\b',modern,re.M); assert m,name
 n=re.search(r'^export (?:interface|type) ',modern[m.end():],re.M); end=m.end()+n.start() if n else len(modern)
 fragment=modern[m.start():end]; matched=[x for x in cases if any(x['id'].startswith(p) for p in prefixes[name])]
 rows.append({'definition':name,'schema_upstream_commit':'271ecc9accafdd9b83a3c869fa67c22953b2af80','schema_sha256':hashlib.sha256(modern.encode()).hexdigest(),'line':modern[:m.start()].count('\n')+1,'fragment':fragment,'case_ids':[x['id'] for x in matched],'valid_ids':[x['id'] for x in matched if x['failure_code']=='input_required_unsupported'],'invalid_ids':[x['id'] for x in matched if x['failure_code']=='invalid_result'],'semantics':'Both singleton/list sampling content accepted; outer resource excluded, nested ordinary ToolResultContent union accepted. Optional nonnullable fields omitted are covered by minimal cases and explicit-null/wrong-type cases reject. Unknown-JSON structuredContent permits null. Enum omitted on string may match StringSchema, so omitted enum/oneOf is valid alternative; array properties must satisfy one of two declared item grammars.'})
source=[]
for name in ['_validate_input_requests','_validate_input_request_variants','_validate_sampling_params','_validate_sampling_block','_validate_form_property','_validate_content_block','complete_result']:
 f=getattr(protocol,name); lines,start=inspect.getsourcelines(f); source.append({'function':name,'path':'packages/friday-mcp/src/friday_mcp/client/protocol.py','line':start,'sha256':hashlib.sha256(''.join(lines).encode()).hexdigest()})
ledger=root/'docs/planning/active/friday-mcp-protocol-upgrade/execution/up04/artifacts/normative-clause-ledger.json.gz'; raw=ledger.read_bytes(); old=json.loads(gzip.decompress(raw))
report={'status':'Builder actual evidence; independent validation pending','variant_cases':len(cases),'public_matrix_tests':2*len(cases),'definitions':rows,'source_functions':source,'original_ledger':{'path':str(ledger.relative_to(root)),'sha256':hashlib.sha256(raw).hexdigest(),'clauses':len(old['clauses']),'selected_schema_interfaces':len(old['selected_schema_interfaces']),'selected_schema_fields':len(old['selected_schema_fields']),'mandatory_occurrences':old['mandatory_occurrences'],'original_sources_raw_occurrences':349,'unchanged_duties':'Original ledger retained for unmodified transport/result/role requirements; mapping is preserved rather than claiming all old findings were verified.'},'findings':[
{'finding':'VAL-UP04-001','criteria':['RES-AC-01','RES-AC-02','RES-AC-03','RES-AC-08'],'source':'packages/friday-mcp/src/friday_mcp/client/base.py::refresh_tool_catalog','tests':['test_capacity_rejection_retires_before_owned_discovery_schedules','test_cancelled_before_discovery_cannot_reuse_old_adapter_cache','test_partial_refresh_failures_retire_all_admission_and_recover','test_failed_admission_does_not_cancel_already_issued_schema_binding','test_2025_failed_capacity_refresh_retires_recovered_raw_call_catalog','test_serial_refresh_returns_own_generation_after_failure','test_refresh_wait_deadline_and_disconnect_settle_owned_tasks','test_modern_http_headers_and_schema_are_captured_before_scheduling_exchange','test_call_keeps_old_output_schema_across_successful_refresh'],'profiles':'constructor1..4, modern stdio-like/2026HTTP/2025HTTP; original5 SDK stdio/TLS refresh interop tests repeat','command_ids':['matrix-6','focused-final','original-constructor','original-instance','original-supplemental']},
{'finding':'VAL-UP04-002','criteria':['RES-AC-05','RES-AC-10'],'source':'packages/friday-mcp/src/friday_mcp/client/protocol.py::_validate_input_requests and helpers','tests':['test_input_variant_public_disposition_privacy_and_zero_continuation'],'case_matrix':'actual-variant-matrix.json','command_ids':['matrix-6','focused-final','original-supplemental'],'no_effect_proof':'Exact one original tools/call, fixed local integer/text codes, no unknown request params or input state, empty clientCapabilities, safe traceback/logs, subsequent call and cleanup. Guard prohibits actual public network/provider/store reads.'}],
'overlap_semantics':'Public entry retires snapshot and raw-call recovery synchronously. Accepted discoveries retain existing serialized lock and operation-returned generations; immediate constructor-budget1..4 queued successes all return distinct generations. An attempt arriving after an older discovery captures a generation retires that older generation, so its existing catalog_unavailable guard prevents stale publication. The lock ensures no older completion can clear or publish over a newer successful result. No issued tools/call is cancelled or replayed. Existing failed-old/success-new and absolute-deadline tests remain unchanged.',
'cleanup_semantics':'HTTP cancel/deadline may retain bounded cleanup owner when operation settles. The new lower-budget public stop/start tests assert owner<=budget, drain through disconnect to zero, reconnect and explicit rediscovery. No claim of immediate cleanup-free retry is made.',
'unsupported_roles':'No Tasks, interactive input execution, roots callback, sampling/provider, elicitation UI, URL/media retrieval, continuation, automatic refresh/subscription, live external MCP or delivery. Client role unchanged.'}
(out/'final-requirement-test-mapping.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cases':len(cases),'definitions':len(rows),'mapping':str(out/'final-requirement-test-mapping.json')}))
