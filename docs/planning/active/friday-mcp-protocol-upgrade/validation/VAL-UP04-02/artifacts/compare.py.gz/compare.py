from pathlib import Path
import json,re,hashlib
p=Path('/private/tmp/friday-mcp-upgrade/independent-review-UP04-002');a=p/'attempts/sandbox/checks'
def norm(s):return s.replace('/private/tmp/friday-mcp-upgrade/up04-baseline','<SNAPSHOT>').replace('/private/tmp/friday-mcp-upgrade/work','<SNAPSHOT>')
r1=json.loads(norm((a/'root-ruff/stdout').read_text()));r2=json.loads(norm((a/'baseline-root-ruff/stdout').read_text()));assert r1==r2 and len(r1)==327
for n,v in [('ruff-candidate-normalized.json',r1),('ruff-baseline-normalized.json',r2)]: (p/n).write_text(json.dumps(v,indent=2)+'\n')
def mypy(q):
 rows=[]
 for line in q.read_text().splitlines():
  m=re.fullmatch(r'(.+):(\d+):(\d+): (error|note): (.*?)\s+\[([^\]]+)\]',norm(line))
  if m:rows.append({'path':m[1],'line':int(m[2]),'column':int(m[3]),'severity':m[4],'message':m[5],'code':m[6]})
 return rows
m1=mypy(p/'checks/supplemental-mypy/stdout');m2=mypy(p/'checks/supplemental-baseline-mypy/stdout');assert len(m1)==4 and m1==m2
(p/'mypy-candidate-normalized.json').write_text(json.dumps(m1,indent=2)+'\n');(p/'mypy-baseline-normalized.json').write_text(json.dumps(m2,indent=2)+'\n')
root1=norm((a/'root/stdout').read_text());root2=norm((a/'baseline-root/stdout').read_text())
def warns(s):
 m=re.search(r'=+ warnings summary =+\n(.*?)(?=\n-- Docs:)',s,re.S);return m[1] if m else None
skips1=[s for s in root1.splitlines() if s.startswith('SKIPPED ')];skips2=[s for s in root2.splitlines() if s.startswith('SKIPPED ')]
(p/'sandbox-warning-candidate.txt').write_text(warns(root1) or '');(p/'sandbox-warning-baseline.txt').write_text(warns(root2) or '');(p/'sandbox-skips.json').write_text(json.dumps({'candidate':skips1,'baseline':skips2},indent=2)+'\n')
out={'ruff_objects_equal':r1==r2,'ruff_count':len(r1),'mypy_objects_equal':m1==m2,'mypy_count':len(m1),'sandbox_skips_equal':skips1==skips2,'sandbox_warning_sections_equal':warns(root1)==warns(root2),'root_limitation':'Both sandbox root runs failed loopback fixtures; eleven warnings observed. This is not a successful full root/warning-profile proof and does not establish accepted fifteen-warning equality.'}
(p/'comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
