import json,re,hashlib,difflib,subprocess
from pathlib import Path
R=Path('/private/tmp/friday-mcp-upgrade/independent-review-UP04-003');B=R.parent
roots=[str(B/'work'),str(B/'up04-baseline')]
def norm(x):
 if isinstance(x,str):
  for root in roots:x=x.replace(root,'<SNAPSHOT>')
  return x
 if isinstance(x,list):return [norm(v) for v in x]
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items()}
 return x
def read(c):return (R/'checks'/c/'stdout').read_text()
def sha(x):return hashlib.sha256(x.encode()).hexdigest()
ruff=norm(json.loads(read('root-ruff')));base=norm(json.loads(read('baseline-root-ruff')));assert len(ruff)==len(base)==327 and ruff==base
pattern=r'^(.*?):(\d+):(\d+): (error|warning|note): (.*?)\s+\[([^]]+)\]$'
def diagnostics(text):
 return [{'path':m[1],'line':int(m[2]),'column':int(m[3]),'severity':m[4],'message':m[5],'code':m[6]} for l in text.splitlines() if (m:=re.match(pattern,l))]
mypy=diagnostics(read('full-mypy-columns'));mbase=diagnostics(read('baseline-full-mypy-columns'));assert len(mypy)==len(mbase)==4 and mypy==mbase
root=norm(read('root'));baseline=norm(read('baseline-root'))
def warnings(s):return s.split('warnings summary ===============================\n',1)[1].split('\n-- Docs:',1)[0]
warn=warnings(root);bwarn=warnings(baseline);assert warn==bwarn
skip=[l for l in root.splitlines() if l.startswith('SKIPPED')];bskip=[l for l in baseline.splitlines() if l.startswith('SKIPPED')];assert skip==bskip
(R/'normalized-ruff-327.json').write_text(json.dumps(ruff,indent=2)+'\n');(R/'normalized-mypy-4.json').write_text(json.dumps(mypy,indent=2)+'\n');(R/'normalized-root-warnings.txt').write_text(warn+'\n');(R/'normalized-root-skips.txt').write_text('\n'.join(skip)+'\n')
receipts=[]
for p in sorted((R/'checks').glob('*/receipt.json')):
 d=json.loads(p.read_text());assert hashlib.sha256((p.parent/'stdout').read_bytes()).hexdigest()==d['stdout_sha256'];assert hashlib.sha256((p.parent/'stderr').read_bytes()).hexdigest()==d['stderr_sha256'];receipts.append({'id':p.parent.name,'exit_code':d['exit_code'],'started_utc':d['started_utc'],'finished_utc':d['finished_utc'],'last_stdout_line':read(p.parent.name).strip().splitlines()[-1] if read(p.parent.name).strip() else ''})
(R/'comparison.json').write_text(json.dumps({'complete_ruff_count':327,'complete_ruff_objects_equal':True,'complete_mypy_count':4,'complete_mypy_objects_equal':True,'mypy_objects':mypy,'skip_locations_reasons_counts_equal':True,'complete_normalized_warning_section_equal':True,'warning_section_sha256':sha(warn),'skip_lines':skip,'root_summary':root.strip().splitlines()[-1],'baseline_root_summary':baseline.strip().splitlines()[-1],'receipts':receipts},indent=2)+'\n')
initial=(B/'run_check_UP04.py').read_text();redirected=(R/'run_check_UP04.py').read_text();(R/'runner-destination-only.diff').write_text(''.join(difflib.unified_diff(initial.splitlines(True),redirected.splitlines(True),fromfile='immutable-UP04',tofile='review-destinations')))
a=(R/'probes/recovery_overlap_budgets.py').read_text();b=(R/'probes/recovery_overlap_budgets_zero.py').read_text();(R/'budget-assertion-only.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='immutable-budget-probe',tofile='assert-zero')))
stability={}
for name in ['work','up04-baseline']:
 w=B/name;head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();status=subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=w,text=True);assert not status;stability[name]={'head':head,'status':status}
(R/'candidate-final-stability.json').write_text(json.dumps(stability,indent=2)+'\n')
print(json.dumps({'Ruff327':True,'Mypy4':True,'root_skips':True,'root_warnings15':True,'stable':stability,'executed':len(receipts)}))
