"""Independent public failure-cleanup overlap; no catalog/task/lock injection."""
import asyncio,json,importlib.util,sys
from pathlib import Path
from friday_mcp.client.adapter import MCPToolAdapter
from friday_mcp.client.protocol import ProtocolLimits
p=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/client/test_http_lifecycle.py')
spec=importlib.util.spec_from_file_location('independent_http_helpers',p);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
async def case(budget):
 peer=m.Peer(version='2025-11-25');client,_,_=m.make_client(peer,limits=ProtocolLimits(concurrent_requests=budget));gate=asyncio.Event();started=asyncio.Event();facts={'budget':budget}
 await client.connect();adapter=MCPToolAdapter(client);old=(await adapter.get_tools())[0]
 def hook(verb,headers,message):
  if message.get('method')=='initialize':
   started.set();return peer.rpc(message,{'protocolVersion':'invalid','capabilities':{'tools':{}},'serverInfo':{'name':'review','version':'1'}},stall=gate)
  return None
 peer.hook=hook;peer.expire_once=True;running=asyncio.create_task(old.execute());await asyncio.wait_for(started.wait(),1)
 try:await client.refresh_tool_catalog()
 except Exception as ex:facts['newer_refresh_failure']=getattr(ex,'failure_code',type(ex).__name__)
 gate.set()
 try:await running
 except Exception as ex:facts['expired_call_failure']=getattr(ex,'failure_code',type(ex).__name__)
 before=peer.methods().count('tools/call')
 for key,operation in [('raw',lambda:client.call_tool('echo',{})),('wrapper',lambda:old.execute())]:
  try:await operation();facts[key]='UNSAFE_SUCCESS'
  except Exception as ex:facts[key]=getattr(ex,'failure_code',type(ex).__name__)
 facts['stale_mutating_calls']=peer.methods().count('tools/call')-before;facts['snapshot_unavailable']=client.current_catalog_snapshot is None;facts['disconnected']=not client.is_connected
 peer.hook=None;await client.connect();fresh=(await adapter.get_tools(refresh=True))[0];current=client.current_catalog_snapshot;facts['fresh_value']=await fresh.execute()
 try:await old.execute()
 except Exception as ex:facts['old_after_reconnect']=getattr(ex,'failure_code',type(ex).__name__)
 facts['fresh_snapshot_preserved']=current is client.current_catalog_snapshot
 await client.disconnect();facts['remaining_owners']=client.outstanding_http_owners+client.outstanding_catalog_owners;facts['closed']=all(s.closed for s in peer.streams)
 assert facts['raw']==facts['wrapper']==facts['old_after_reconnect']=='catalog_unavailable' and facts['stale_mutating_calls']==facts['remaining_owners']==0 and facts['closed'] and facts['fresh_snapshot_preserved'] and facts['disconnected'] and facts['fresh_value']=='ok'
 return facts
async def main():print(json.dumps([await asyncio.wait_for(case(b),5) for b in range(1,5)],indent=2))
asyncio.run(main())
