import json,hashlib,subprocess,sys,os
from pathlib import Path
from datetime import datetime,timezone
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP04-003';W=B/'work';P=W/'docs/planning/active/friday-mcp-protocol-upgrade'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(w,*args):return subprocess.check_output(['git',*args],cwd=w,text=True).strip()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
request=json.loads((P/'validation-request-REM-MCP-UP-005.json').read_text())
original=B/'run_check_UP04.py';s=original.read_text();assert sha(original)=='5e5c9901bf66117ee11669d32de857ea2087738add9eef3c7ae6aa6f3c8592a6'
s=s.replace("base / 'checks' / label","base / 'independent-review-UP04-003' / 'checks' / label").replace("base / 'homes' / label","base / 'independent-review-UP04-003' / 'homes' / label").replace("base / 'tmp'","base / 'independent-review-UP04-003' / 'tmp'").replace("base / 'cache'","home / 'uv-cache'")
runner=R/'run_check_UP04.py'
if not runner.exists():runner.write_text(s)
assert runner.read_text()==s
controls=['AGENTS.md','docs/reference/policies/repository-engineering-policy.md','docs/reference/policies/development-task-lifecycle.md','docs/reference/policies/independent-validation-policy.md','docs/planning/board.yaml','docs/planning/README.md']+[str(x.relative_to(W)) for x in P.rglob('*') if x.is_file() and not any(y in x.parts for y in ['execution','validation','research-sources'])]
expected='47fcdb76035306c8aa7494ca1e1962049e984a3d'
def freeze(label,argv,snapshot):
 out=R/'checks'/label;out.mkdir(parents=True,exist_ok=True)
 assert git(W,'rev-parse','HEAD')==expected;assert not git(W,'status','--porcelain=v1','-uall')
 assert git(B/'up04-baseline','rev-parse','HEAD')==request['base_commit'];assert not git(B/'up04-baseline','status','--porcelain=v1','-uall')
 sources={p:sha(W/p) for p in request['product_hashes']};meta={p:sha(W/p) for p in request['metadata_hashes']}
 assert sources==request['product_hashes'];assert meta==request['metadata_hashes']
 assert sha(B/'guard/sitecustomize.py')==request['guard']['sha256']
 assert sha(B/'run_check.py')=='ceec1b2316f4be3bce36fb778eb80b5d472561920d6d6fe35b8b30735e1776f0'
 dump(out/'candidate-freeze.json',{'utc':datetime.now(timezone.utc).isoformat(),'candidate_commit':expected,'branch':git(W,'branch','--show-current'),'argv':argv,'snapshot':snapshot,'source_hashes':sources,'metadata_hashes':meta,'control_hashes':{p:sha(W/p) for p in controls},'guard_sha256':sha(B/'guard/sitecustomize.py'),'original_runner_sha256':sha(B/'run_check.py'),'original_UP04_runner_sha256':sha(original),'redirected_runner_sha256':sha(runner)})
 for p in list(sources)+list(meta)+controls:
  dest=R/'inputs'/p;dest.parent.mkdir(parents=True,exist_ok=True)
  if not dest.exists():dest.write_bytes((W/p).read_bytes())
 return out
if __name__=='__main__':
 if sys.argv[1]=='profile':
  start,end=map(int,sys.argv[2:4]);checks=request['required_checks'][start:end]
 elif sys.argv[1]=='extra':
  checks=[{'id':sys.argv[2],'snapshot':sys.argv[3],'argv':sys.argv[4:]}]
 else:raise ValueError()
 for c in checks:
  out=freeze(c['id'],c['argv'],c['snapshot']);assert not (out/'receipt.json').exists()
  proc=subprocess.run([str(B/'venv/bin/python'),str(runner),c['id'],c['snapshot'],*c['argv']],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (out/'wrapper-stdout').write_bytes(proc.stdout);(out/'wrapper-stderr').write_bytes(proc.stderr)
  print(proc.stdout.decode(),flush=True)
  if proc.returncode:raise SystemExit(proc.returncode)
  rec=json.loads((out/'receipt.json').read_text());print('CHILD',c['id'],rec['exit_code'],flush=True)
