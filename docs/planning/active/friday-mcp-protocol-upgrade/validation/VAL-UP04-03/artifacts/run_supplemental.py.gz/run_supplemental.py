import subprocess
from pathlib import Path
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP04-003';py=str(B/'venv/bin/python');driver=str(R/'review_driver.py')
checks=[('recovery-overlap-budgets-zero','work',[py,str(R/'probes/recovery_overlap_budgets_zero.py')]),('recovery-failure-ownership','work',[py,str(R/'probes/recovery_failure_ownership.py')]),('original-constructor-limit','work',[py,str(R/'probes/refresh_limit_constructor_probe.py')]),('original-instance-limit','work',[py,str(R/'probes/refresh_limit_probe.py')]),('original-supplemental-work','work',[py,str(R/'probes/supplemental_probe.py')]),('original-supplemental-baseline','up04-baseline',[py,str(R/'probes/supplemental_probe.py')]),('schema-mapping','work',[py,str(R/'schema_mapping_audit.py')])]
paths=['packages/friday-core/src/friday_core','packages/friday-mcp/src/friday_mcp','packages/friday-runtime/src/friday_runtime','packages/friday-chat/src/friday_chat']
for name,snapshot in [('full-mypy-columns','work'),('baseline-full-mypy-columns','up04-baseline')]:checks.append((name,snapshot,[py,'-m','mypy',*paths,'--show-column-numbers','--no-pretty']))
checks.append(('uncommitted-whitespace','work',['git','diff','--check']))
for name,snapshot,argv in checks:subprocess.run([py,driver,'extra',name,snapshot,*argv],check=True)
