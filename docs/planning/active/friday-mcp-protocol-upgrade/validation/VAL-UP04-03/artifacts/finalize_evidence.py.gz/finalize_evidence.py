import json,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP04-003';W=B/'work';P=W/'docs/planning/active/friday-mcp-protocol-upgrade'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
stability={}
for name,expected in [('work','47fcdb76035306c8aa7494ca1e1962049e984a3d'),('up04-baseline','3fd5437088c5ddf5d68be3a2a097770c294cba6b')]:
 w=B/name;head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();status=subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=w,text=True);assert head==expected and not status;stability[name]={'head':head,'status':status,'branch':subprocess.check_output(['git','branch','--show-current'],cwd=w,text=True).strip()}
req=json.loads((P/'validation-request-REM-MCP-UP-005.json').read_text());assert all(h(W/p)==v for p,v in req['product_hashes'].items());assert all(h(W/p)==v for p,v in req['metadata_hashes'].items())
(R/'candidate-final-stability.json').write_text(json.dumps({'verified_at_utc':datetime.now(timezone.utc).isoformat(),**stability},indent=2)+'\n')
checks=[]
for p in sorted((R/'checks').glob('*/receipt.json')):
 d=json.loads(p.read_text());assert h(p.parent/'stdout')==d['stdout_sha256'] and h(p.parent/'stderr')==d['stderr_sha256'];checks.append({'id':p.parent.name,'exit_code':d['exit_code'],'argv':d['argv'],'cwd':d['cwd'],'started_utc':d['started_utc'],'finished_utc':d['finished_utc']})
(R/'complete-executed-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
entries=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or any(x in p.relative_to(R).parts for x in ['homes','tmp','cache','caches','__pycache__','runtime']):continue
 if p.name=='evidence-manifest.json':continue
 rel=p.relative_to(R);assert not p.is_symlink();assert not any(s in p.name.lower() for s in ['.pem','.key','.p12','.sqlite'])
 entries.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':h(p)})
(R/'evidence-manifest.json').write_text(json.dumps({'outcome':'VERIFIED','candidate_commit':'47fcdb76035306c8aa7494ca1e1962049e984a3d','product_commit':'a9c913e41cdbd5bd824f36fe7b15001e6c126e17','reviewer':'/root/rem005_final_validator','review_mode':'read-only REM005 delta then full original UP04','created_at_utc':datetime.now(timezone.utc).isoformat(),'entries':entries,'excluded':'homes/tmp/caches/runtime/generated TLS keys; no source_path read selectors','boundary':'Independent review only, no acceptance/completion/publication authority'},indent=2)+'\n')
print(json.dumps({'outcome':'VERIFIED','entries':len(entries),'checks':len(checks),'report_sha256':h(R/'report.md'),'manifest_sha256':h(R/'evidence-manifest.json'),'candidate':stability['work']}))
