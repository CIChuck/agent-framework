import json,hashlib,gzip,re,tomllib,subprocess
from pathlib import Path
B=Path('/private/tmp/friday-mcp-upgrade');W=B/'work';R=B/'independent-review-UP04-003';P=W/'docs/planning/active/friday-mcp-protocol-upgrade'
def h(b):return hashlib.sha256(b).hexdigest()
def put(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
def dump(name,obj):put(R/name,(json.dumps(obj,indent=2)+'\n').encode())
def collect(x):
 if isinstance(x,dict):
  if 'path' in x and 'sha256' in x and isinstance(x['path'],str):yield x
  for v in x.values():yield from collect(v)
 elif isinstance(x,list):
  for v in x:yield from collect(v)
# Each read uses explicit bound path. source_path is never a selector.
queue=[P/f for f in ['validation-request-REM-MCP-UP-005.json','authority-REM-MCP-UP-005.json','authority-UP-04.json','authority-REM-MCP-UP-004.json']];seen=set();pins=[]
while queue:
 f=queue.pop(0)
 if f in seen:continue
 seen.add(f);raw=f.read_bytes();put(R/'inputs'/f.relative_to(W),raw)
 try:x=json.loads(raw)
 except ValueError:continue
 for e in collect(x):
  p=Path(e['path']);target=p if p.is_absolute() else W/p
  if not str(target).startswith(str(W)) and target not in [B/'guard/sitecustomize.py',B/'run_check.py',B/'run_check_UP04.py']:continue
  exists=target.is_file();actual=h(target.read_bytes()) if exists else None
  pins.append({'container':str(f.relative_to(W)),'path':e['path'],'expected':e['sha256'],'actual':actual,'matches':actual==e['sha256']})
  if exists and target.suffix=='.json' and str(target).startswith(str(W)) and not any(z in target.parts for z in ['execution','validation']):queue.append(target)
dump('authority-audit.json',{'pins':pins,'mismatches':[e for e in pins if not e['matches']]})
# Original immutable archival objects; verify compressed and lossless bytes, copy safe inputs for inspection.
archives=[]
for unit in ['rem005','rem004']:
 f=P/'execution'/unit/'stored-manifest.json';d=json.loads(f.read_text());records=[]
 for a in d['artifacts']:
  path=f.parent/a['path'];assert path.resolve().is_relative_to(f.parent.resolve());stored=path.read_bytes();data=gzip.decompress(stored) if a.get('encoding')=='gzip' else stored
  assert h(stored)==a['stored_sha256'] and h(data)==a['sha256'] and len(data)==a['bytes']
  records.append({'path':str(path.relative_to(W)),'bytes':len(data),'sha256':h(data),'matches':True})
  if any(s in a['path'] for s in ['preconstruction-plan','authority-binding','planning-freeze','final-requirement-test-mapping','actual-variant-matrix','modern-schema.ts','compat-schema.ts']):put(R/'archive-inputs'/unit/a['original_path'],data)
 archives.append({'unit':unit,'count':len(records),'entries':records})
dump('archive-integrity.json',archives)
# All19 original complete captured inputs; read every byte, preserve text, enumerate normative occurrences.
norm=[];clauses=[]
for rel in ['research-sources','research-sources/up02b','research-sources/up04']:
 root=P/rel;man=json.loads((root/'manifest.json').read_text())
 for a in man['sources']:
  path=root/a['artifact'];stored=path.read_bytes();raw=gzip.decompress(stored);assert h(stored)==a['artifact_sha256'] and h(raw)==a['sha256'] and len(raw)==a['bytes']
  dest=R/'inputs/normative'/a['artifact'].removesuffix('.gz');put(dest,raw)
  text=raw.decode();count=0
  for n,line in enumerate(text.splitlines(),1):
   words=re.findall(r'\b(?:MUST NOT|SHALL NOT|SHOULD NOT|MUST|SHALL|SHOULD|REQUIRED|RECOMMENDED|MAY|OPTIONAL)\b',line);count+=len(words)
   if words:clauses.append({'source':a['artifact'],'line':n,'words':words,'text':line})
  norm.append({'artifact':a['artifact'],'bytes':len(raw),'sha256':h(raw),'keywords':count})
dump('normative-audit.json',{'count':len(norm),'sources':norm,'keyword_total':sum(e['keywords'] for e in norm)});dump('normative-clauses.json',clauses)
# destination ONLY library verification
libraries=[];entries=[]
for file,key in [('reused-library-manifest.json','copied'),('additional-validation-libraries.json','added')]:
 d=json.loads((B/file).read_text());put(R/'inputs/environment'/file,(B/file).read_bytes())
 for dist in d[key]:
  for a in dist['files']:
   path=B/'venv/lib/python3.13/site-packages'/a['path'];raw=path.read_bytes();assert h(raw)==a['sha256'];entries.append({'path':a['path'],'sha256':h(raw),'matches':True})
  libraries.append({'name':dist.get('distribution',dist.get('name')),'version':dist['version'],'files':len(dist['files'])})
dump('library-integrity.json',{'files':len(entries),'distributions':len(libraries),'libraries':libraries,'entries':entries,'source_originals_read':False})
lock=tomllib.loads((W/'uv.lock').read_text());names={'mcp','httpcore2','httpx2','h11','jsonschema','referencing','pydantic','ruff','mypy','pytest','pytest-asyncio','certifi'}
dump('dependency-artifacts-edges.json',{'metadata_unchanged':True,'selected_complete_lock_objects':[p for p in lock['package'] if p['name'] in names]})
req=json.loads((P/'validation-request-REM-MCP-UP-005.json').read_text());base=req['base_commit'];rem=req['remediation_base'];prod=list(req['product_hashes']);metadata=list(req['metadata_hashes'])
def diff(ref,args):return subprocess.check_output(['git','diff','--name-only',ref,'HEAD','--',*args],cwd=W,text=True).splitlines()
dump('product-scope.json',{'delta_paths':diff(rem,prod),'full_paths':diff(base,prod),'metadata_delta':diff(base,metadata),'other18_unchanged':len(diff(rem,prod))==2,'original_control_changes_since_REM004':diff(rem,['docs/planning/active/friday-mcp-protocol-upgrade/authority-UP-04.json','docs/planning/active/friday-mcp-protocol-upgrade/authority-REM-MCP-UP-004.json','docs/planning/active/friday-mcp-protocol-upgrade/validation/VAL-UP04-01','docs/planning/active/friday-mcp-protocol-upgrade/validation/VAL-UP04-02','docs/planning/active/friday-mcp-protocol-upgrade/research-sources','docs/planning/active/friday-mcp-protocol-upgrade/execution/rem004'])})
for label,ref in [('delta',rem),('full',base)]:put(R/f'{label}-product.diff',subprocess.check_output(['git','diff',ref,'HEAD','--',*prod],cwd=W))
print(json.dumps({'pins':len(pins),'pin_mismatches':len([e for e in pins if not e['matches']]),'archives':[{'unit':a['unit'],'count':a['count']} for a in archives],'sources':len(norm),'libraries':len(libraries),'files':len(entries)}))
