import hashlib,json,subprocess,gzip,sys
from pathlib import Path
from datetime import datetime,timezone
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP05-003';W=B/'work';P=W/'docs/planning/active/friday-mcp-protocol-upgrade'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def capture(label):
 request=json.loads((P/'validation-request-REM-MCP-UP-006-R1.json').read_text());entries=[];files={};dist=[]
 for name,key in [('reused-library-manifest.json','copied'),('additional-validation-libraries.json','added')]:
  for d in json.loads((B/name).read_text())[key]:
   dist.append({'name':d.get('distribution',d.get('name')),'version':d['version']})
   for f in d['files']:
    p=B/'venv/lib/python3.13/site-packages'/f['path'];h=sha(p)
    if h!=f['sha256']: raise RuntimeError('library drift '+f['path'])
    entries.append({'path':f['path'],'sha256':h});files[f['path']]={'sha256':h,'bytes':p.stat().st_size}
 hashes={};bad=[]
 for group in ['product_hashes','metadata_hashes','preserved_product_hashes']:
  hashes[group]={p:sha(W/p) for p in request[group]}
  bad.extend(p for p,h in request[group].items() if hashes[group][p]!=h)
 controls=request['controls']+[request['authority_manifest'],request['original_authority'],request['verification_profile']]
 hashes['controls']={e['path']:sha(W/e['path']) for e in controls}
 bad.extend(e['path'] for e in controls if hashes['controls'][e['path']]!=e['sha256'])
 history={}
 for name in ['validation/VAL-UP05-01/stored-manifest.json','validation/VAL-UP05-02/stored-manifest.json','execution/rem006/stored-manifest.json','execution/rem006-r1/stored-manifest.json']:
  m=P/name;es=json.loads(m.read_text())['artifacts'];mismatches=[]
  for e in es:
   raw=(m.parent/e['path']).read_bytes()
   if hashlib.sha256(raw).hexdigest()!=e['stored_sha256']:mismatches.append(e['path'])
   raw=gzip.decompress(raw) if e.get('encoding')=='gzip' else raw
   if hashlib.sha256(raw).hexdigest()!=e['sha256'] or len(raw)!=e['bytes']:mismatches.append(e['path'])
  history[name]={'entries':len(es),'bad':mismatches,'sha256':sha(m)}
  if mismatches:raise RuntimeError('history drift')
 snapshots={}
 for name in ['work','up05-baseline']:
  root=B/name;excluded={x[2:] for x in (root/'.git/info/sparse-checkout').read_text().splitlines() if x.startswith('!/')} 
  source={};absent=[]
  for path in subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines():
   if path in excluded:continue
   if (root/path).is_file():source[path]=sha(root/path)
   else:absent.append(path)
  snapshots[name]={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'source_files':source,'protected_omitted_count':len(excluded),'other_absent':absent,'sparse_sha256':sha(root/'.git/info/sparse-checkout')}
 fixed={str(p):sha(p) for p in [B/'run_check.py',B/'run_check_UP05.py',B/'run_check_UP04.py',B/'guard/sitecustomize.py',R/'run_check_UP05.py']}
 state={'time':datetime.now(timezone.utc).isoformat(),'library_entries':entries,'library_files':files,'library_count':len(entries),'unique_library_count':len(files),'distribution_count':len(dist),'distributions':dist,'inventory_hashes':{n:sha(B/n) for n in ['reused-library-manifest.json','additional-validation-libraries.json']},'hashes':hashes,'mismatches':bad,'history':history,'snapshots':snapshots,'fixed':fixed}
 (R/(label+'.json')).write_text(json.dumps(state,indent=2)+'\n')
 print(json.dumps({'time':state['time'],'library_references':len(entries),'unique_paths':len(files),'distributions':len(dist),'mismatches':bad,'history':history,'snapshots':{n:{k:v for k,v in x.items() if k!='source_files'} for n,x in snapshots.items()}}))
 if bad or len(entries)!=22009 or len(files)!=21992 or len(dist)!=192 or snapshots['work']['head']!='012430089bcd1b60b12c071b8c8220f20d2bac79' or snapshots['work']['status'] or snapshots['up05-baseline']['status']:raise RuntimeError('freeze drift')
if __name__=='__main__':capture(sys.argv[1])
