import hashlib,json,re,subprocess
from pathlib import Path
from datetime import datetime,timezone
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP05-003';W=B/'work';P=W/'docs/planning/active/friday-mcp-protocol-upgrade'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
request=json.loads((P/'validation-request-REM-MCP-UP-006-R1.json').read_text());before=json.loads((R/'before-first-command.json').read_text());after=json.loads((R/'final-after-all-checks.json').read_text());comparison=json.loads((R/'exact-profile-comparison.json').read_text())
equal={k:before[k]==after[k] for k in ['library_entries','library_files','inventory_hashes','hashes','history','snapshots','fixed']};assert all(equal.values())
receipts=[]
for p in sorted((R/'checks').glob('*/receipt.json')):
 c=json.loads(p.read_text());pre=json.loads(p.with_name('preflight.json').read_text());assert pre['source_hashes']==(request['product_hashes'] if c['cwd']==str(W) else pre['source_hashes'])
 assert c['stdout_sha256']==sha(p.with_name('stdout')) and c['stderr_sha256']==sha(p.with_name('stderr'));assert c['environment']==pre['environment'] and c['guard_sha256']==request['guard']['sha256'];receipts.append({'label':p.parent.name,**c})
first=min(x['started_utc'] for x in receipts);last=max(x['finished_utc'] for x in receipts)
assert before['time']<first<last<after['time']
for key in ['HOME','TMPDIR','XDG_CACHE_HOME','MYPY_CACHE_DIR','RUFF_CACHE_DIR','UV_CACHE_DIR']:
 vals=[x['environment'][key] for x in receipts];assert len(vals)==len(set(vals)) and all(str(R/'runtime') in v for v in vals)
assert len(receipts)==27
raw=(R/'checks/original-live-001/stdout').read_text();live=[json.loads(m[1]) for m in re.finditer(r'LIVE_VERIFIED_TLS_INVALID_STANDARD (\{[^\n]+\})',raw)];assert len(live)==2
for row in live:
 assert row['handler_starts']==row['child_exit']==row['active_final']==0
 for x in row['observations']:
  assert x['status']==400
  if x['suffix_hex']=='e4b896e7958c':assert x['body']=={'jsonrpc':'2.0','error':{'code':-32020,'message':'Header mismatch'}}
  else:assert x['body']=={'raw_parser_body':'Invalid HTTP request received.'}
assert json.loads((R/'checks/original-edges-001/receipt.json').read_text())['exit_code']==0
assert json.loads((R/'checks/fresh-application-001/receipt.json').read_text())['exit_code']==0
assert json.loads((R/'checks/original-live-001/receipt.json').read_text())['exit_code']==1
probe_originals={n:{'reviewer_sha256':sha(R/n),'original_sha256':sha(B/'independent-review-UP05-002'/n)} for n in ['test_review_edges.py','test_standard_header_live.py']};assert all(x['reviewer_sha256']==x['original_sha256'] for x in probe_originals.values())
proof={'outcome':'VERIFIED','candidate':after['snapshots']['work']['head'],'before':before['time'],'first_child':first,'last_child':last,'after':after['time'],'strict_chronology':True,'strict_equal_groups':equal,'candidate_governed_file_count':len(after['snapshots']['work']['source_files']),'baseline_governed_file_count':len(after['snapshots']['up05-baseline']['source_files']),'protected_omitted_count':267,'governed_candidate_status':after['snapshots']['work']['status'],'raw_child_exits':{x['label']:x['exit_code'] for x in receipts},'unique_command_destinations':True,'original_probe_byte_equality':probe_originals,'original_live_observations':live,'exclusions':'Runtime HOME/TMP/cache/stores/certs/privatekeys/bytecode/.git/generatedarchives are deliberately excluded; approved ignored synthetic CWD fixture effects retained; governed tracked stability controls.'}
(R/'final-integrity-chronology.json').write_text(json.dumps(proof,indent=2)+'\n')
finding_authority=json.loads((P/'authority-REM-MCP-UP-006.json').read_text())['findings'];findings=[]
evidence={'VAL-UP05-001':'test_review_edges.py::test_independent_cancellation_and_eof; 32 limits1..4 × badframe classes × drain/lock cases; test_modern_stdio backpressured/saturation and serialized-writer product cases',
 'VAL-UP05-002':'test_review_edges.py::test_independent_resistant_owner_retry_and_stale_generation; 16 limits1..4 × resistantdrain/read/close/lock cases; nativepartialstart, stalefinalizer/signal and retryableclose product cases',
 'VAL-UP05-003':'test_review_edges.py::test_independent_idle_fragments_and_output_budget; 4 limits1..4 idle/fragment/output cases; product firstbyte/partialEOF/fragmentassembly cases',
 'VAL-UP05-004':'test_review_edges.py::test_independent_custom_headers_exact_code; 12 JSON/SSE badcustom cases plus equal/conflicting case-insensitive duplicates; preserved access-specific product cases',
 'VAL-UP05-005':'test_review_edges.py six standardheader cases; test_application_header_boundary.py directASGI640 fullinvalid-byte cases plus realverifiedTLS16 layer-specific observations; productvalid/invalidASCII/HTAB/Base64/normalization and rawUTF8 probes'}
for f in finding_authority:
 findings.append({'id':f['id'],'severity':f['severity'],'status':'resolved_in_current_independent_review','original_title':f['title'],'source_and_authority':f.get('requirements',f.get('requirement')),'current_evidence':evidence[f['id']]})
findings.append({'id':'VAL-UP05-005','severity':'medium','status':'resolved_in_current_independent_review','source':'http_policy.py:144-148; http.py:193-227','authority':'REM006-R1 exact correction; contract110/120; capturedHTTP479-484,596-602,623-629; HeaderMismatchError schema468','mitigation':'plainstandard bytegrammar prebody; fixedHeaderMismatch; no normalization/Base64 orcategoryregression','current_evidence':evidence['VAL-UP05-005'],'docs':'guide18 plainMethod/Version bytegrammar and separateName/Param sentinel clarified; defaults unchanged'})
(R/'findings.json').write_text(json.dumps({'outcome':'VERIFIED','unresolved_findings':[],'new_findings':[],'resolved_findings':findings,'original_raw_live_failure_explanation':'Only h11preASGI C0/DEL plaintext violates original probe application-only assertion; actualUTF8 appresponses pass. Original script and exit1 receipts preserved; separate counterpart explicitly provesbothlayers.'},indent=2)+'\n')
rows='\n'.join(f"| `{c['id']}` | {c['exit_code']} | `checks/full-001-{c['id']}/receipt.json` |" for c in comparison['required_checks'])
criteria=[
 ('SRV-AC-01','protocol.py ServerRequest/metadata/ServerWireError; full-unit assessment envelope,metadata,version,notification,unsupported; fresh field and byte probes','Strict per-request2026 envelope/metadata/error variants; optionalclientInfo, exact ID/noID grammar, inactive -32021 refused; supported/requested versiondata.'),
 ('SRV-AC-02','modern.py _stage/_page/dispatch; catalog/tooldefinition bundles and server-focused rawreceipt','Atomic sorted immutable catalog; complete count/byte-aware pages, obsolete/forged/null/oversized cursors denied, nohandler I/O and immediately-stale cache hints.'),
 ('SRV-AC-03','protocol.py RegisteredTool/ToolCallResult; modern.py dispatch/_execute; toolcall bundle, server-focused and fresh-field receipts','Capture schema/handler before await; arguments validated then onceonly invocation; output schema/pinned result/text/metadata/null/mixedorder checked; legitimate toolerrors safe; no replay.'),
 ('SRV-AC-04','modern_stdio.py connection/reject/dispatch/write/stop; stdio/notification bundles; original-edges-001 and server-focused','Responsive cancellation/EOF underblocked rejection; native newline stdio cleanstdout; generation ownership/partialstartup/deadline/pipe/SIGTERM/restart evidence.'),
 ('SRV-AC-05','http.py operation/_send; http_policy.py validate/validate_rpc_headers/decode_header; http/headers/version bundles; original/fresh probes and server-http','One statelessPOST JSON/SSE; precise status/body/header rules, requiredplain metadata grammar versusName/customBase64, nohandler beforevalidation; unknownASCII categories preserved.'),
 ('SRV-AC-06','http_policy.py HTTPServerPolicy; access bundle/server-security cases and fresh-byte/TLS receipts','Typedexplicit exposurepolicy; Host/Origin/bearer/TLS/query/duplicates/bytecaps/privateerrors preserveaccess statuses; staticadministrative gate with explicitlydeferredOAuth.'),
 ('SRV-AC-07','modern.py run_owned/stop; modern_stdio.py _stop_connection and frame_deadline; http.py owner/send; ownership bundle and original-edge probes','Lower-only limits and absolutefirstbyte/POST deadlines, boundedowners/output, cancellation-resistant truthfulretention, explicitretry and restartblocking; noorphan/replay in exercisedbounds.'),
 ('SRV-AC-08','registry.py configure_modern_tools_mode/_handler; registry bundle and server-focused','PublicCore typed contracts plus actualDefaultToolRegistry synthetics; filters/prefix/collision/schema/handler snapshots atomic; independentinstances, noimplicitloading.'),
 ('SRV-AC-09','server/__init__.py; compatibility bundle/legacy tests; current preserved-product and metadata snapshots; original-clients and crosspackage receipts','All60 acceptedproducts/19metadata match; originalnames/constructors/defaults preserved; optionalHTTP dependency imports lazy/fixederror; noacceptedclient/Core/Runtime/Chat/telemetry edits.'),
 ('SRV-AC-10','modern.py _execute observation; metadata/observation bundles, server-security and crosspackage rawreceipts','InjectedpublicTelemetryInterface only; one admittedhandler start/terminal, fixedmethod/outcome/hashlabel, no rawarguments/results/IDs/token/trace; observerfailure no replay and separateinstance/providerstate.'),
 ('SRV-AC-11','test_server_interop.py official_client/exercise_sdk and actual named Fridayfixture; interop bundle; server-focused/server-http, original/fresh live receipts','PinnedSDK2.3.0 Client realstdio and verifiedprivateTLS JSON/SSE, mode2026/cacheNone/nointeractiveextensions; actualwire/counters/version/error/cancel/disconnect/childsettlement; rawnegatives bypassSDKretry.'),
 ('SRV-AC-12','scope-proof.json; 19 SHAselectedcaptured inputs; full-unit-field-clause-assessment.json; exact-profile-comparison.json; strict before/final-after snapshots','All18 products/all12 criteria, originalwrong2025plan preserved and corrected2026plan controlling; accurateguide/README/non-goals; all20 exactcommands pluscolumns/exactdebt/skips/warnings; noinstalls/weakening.'),
]
criteria_rows='\n'.join(f'| {c} | PASS | {why} Evidence: {ev}. |' for c,ev,why in criteria)
text=f'''# VAL-UP05-03 independent review

**VERIFIED**

Frozen candidate `012430089bcd1b60b12c071b8c8220f20d2bac79`, corrected product commit `a8ef5b78054f1d0008706cc09a265c50a58fc0ac`. Reviewed 2026-10-13 by fresh separate read-only Codex validator `/root/rem006_r1_fresh_full_validator` (GPT-6 family as described by agent instructions; exact deployment variant/version unavailable). This validator did not build or remediate the product, received frozen inputs without builder reasoning, and spawned no additional agents. Review mode: bounded REM006-R1 delta followed by the complete original MCP-UP-05 work unit. No unresolved mandatory finding or new drift was found within this declared tools-server profile.

This resolves VAL-UP05-005 and independently preserves the four earlier fixes. It permits a controller completion proposal for this work unit only. Maintainer acceptance, UP-06 aggregate verification, whole-initiative completion, push/merge/release/publication and live deployment remain separate. No governed candidate, board, authority, source/test or metadata bytes were edited; no repair, commit, install/sync, provider/credential/user-store use or publication occurred.

## Frozen authority, scope and read-only boundary

Remediation diff: `2b536516068f9e946572d165636211a24a93638d..012430089bcd1b60b12c071b8c8220f20d2bac79`; full work-unit diff: `f876603c74d8a90639fb5dc90d287d17ab523705..012430089bcd1b60b12c071b8c8220f20d2bac79`. `remediation.diff`, `full-unit.diff` and `scope-proof.json` retain the actual product scopes: exactly three R1 paths and all original18 paths. Other15 originalproducts remain unchanged across the R1 range.

Read AGENTS and engineering/lifecycle/independent-validation policies, initiative index/build/tactical/current-process state, original CD005 contract/profile, separate UP05/AMEND001/002 approval receipts and manifests, parent REM006 approval/directive/authority, REM006-R1 exact directive/request/authority, original reviewer reports and probe inputs. Historical proposed labels and frozen index headings do not replace later exact approval receipts or declared current process state. R1 is a three-of-six-path continuation under existing REM006 approval, not new approval; all12 criteria/all20 commands remain unchanged. Board validate/next/show confirms started/granted, named MCP branch and current R1 full review gate. Formal remediation cycle2 is recorded; no extra remediation was performed.

Authority REM006-R1 SHA256: `4c9ad27e4469ad5c714a59e2883bc77f79ec7902cf65fc98011112781c553555`. Original AMEND002 authority: `0d1ccb9a5a68fa8b3be25c728cb4de7b08d8cd9bf62265a36caee30fb062d13f`. Request: `{sha(P/'validation-request-REM-MCP-UP-006-R1.json')}`. R1 directive: `{sha(P/'directives/REM-MCP-UP-006-R1-standard-header-byte-grammar.md')}`. Parent REM006 authority: `{sha(P/'authority-REM-MCP-UP-006.json')}`; approval receipt: `{sha(P/'approval-REM-MCP-UP-006.json')}`. Original request controls are individually checked in strict snapshots. All19 metadata and60 acceptedproduct hashes match before/after. The original VAL-UP05-02 report SHA remains `7c38b79f1f0438b3fd59cb51efafecf6386cb336b028898a9957ef457918d0d9`, and all374 archived artifacts verify stored/decoded bytes and SHA. Earlier454-entry review and434-entry REM006 archives plus299-entry R1 builder archive also match; these remain inputs, not review conclusions.

All19 complete local primary captures were individually hashed and copied from SHA-selected evidence. Their frozen dated contents control this review; no public-network refresh was substituted. Modern2026 schema SHA `742750af0bb8c716e7030c4977c992b55d1adc4407e9e66997db5846baedc2cd` controls; corrected prospective plan SHA `1ba20b8ca818059b62aaeb1a906d36067ee15c4032ea518ab4c63a9cbd824853` is the approved remaining-construction plan. Original erroneous2025-selected plan remains unchanged historical evidence. `full-unit-field-clause-assessment.json` independently classifies all155 declaration,337 exactfield-reference and316 paragraph inventory entries against actual source, AST/assertion references, errors/privacy/bounds and unsupportedroles. It verifies260 content-hash/AST source/test pointers and retains164 assertion groups in `actual-assertion-extracts.json`. Counts are inventories, not conformance evidence. Field rows preserve exact corrected schema lines; builder mappings were only input indexes. Supported aliases/union branches, omitted optionalfields, conditional/client/intermediary/historical/OAuth duties and documented SHOULD tradeoffs are separated. No blanket optional-role/OAuth/MCP conformance is asserted.

## Numbered mitigation and independent semantic evidence

| Finding | Independent current disposition |
| --- | --- |
| VAL-UP05-001 (high) | RESOLVED. 32 independent limits1..4 × malformed/duplicate/admission/oversize × blockeddrain/lock cases process owner-local cancellation and EOF before output release; bounded separate rejection pool and serializedwriters/saturation product cases preserve count/ownership. |
| VAL-UP05-002 (high) | RESOLVED. 16 resistantdrain/read/close/lock cases retain originalgeneration on incomplete stop, deny start/serve, settle explicitretry, and leave replacement untouched by old teardown. Native partialstart, stale signals/finalizers and retryableclose product cases pass. |
| VAL-UP05-003 (medium) | RESOLVED. Four independent limits1..4 cases distinguish idle time from firstbyte fragments; expired fragments invoke nohandler and output cannot refresh deadline. Product fragmented/oversize/partialEOF/handler/send cases pass. |
| VAL-UP05-004 (medium) | RESOLVED. 12 JSON/SSE malformedcustom cases plus equal/conflicting case-insensitive duplicates return fixed400/-32020 and0handlers; preserved Host/Origin/Bearer/TLS/media access cases retain statuses/privacy. |
| VAL-UP05-005 (medium) | RESOLVED. `http_policy.py:144-148` checks plainMethod/Version visibleASCII/SP/HTAB before bodyreceive and RPCrouting, retaining fixed400/-32020 withoutID/rawvalues. Original six ASGI standardheader cases nowpass; fresh directASGI probes exercise640 invalidbyte field/mode combinations with0bodyreads/handlers/activeowners. Product validbyte sweeps retain unknownmethod404/-32601 and unknownversion400/-32022 supported/requested; exactcomparison rejects normalization/Base64 changes. |

`checks/original-edges-001` reruns the unchanged original70-case reviewer suite: **70 passed**, childexit0. This includes all64 earlier mitigation cases and six standard-header cases. `test_review_edges.py` and `test_standard_header_live.py` are byte-identical to the original private reviewer scripts, verified by SHA in `final-integrity-chronology.json`. Initial symptom assertions are retained unchanged in `inputs/original-symptom-test_independent_probes.py` and immutable original archive; the current correction assertions are separate scripts.

The original raw verifiedTLS script deliberately retains its exact assertion and produces **2 failed**, childexit1 in `checks/original-live-001`. Both JSON/SSE runs record C0/DEL rejected by h11 **before ASGI** as400/plaintext, while rawUTF8 `世界` reaches the application and returns exact400/-32020. All handlerstarts0, finalactive0 and childexit0. Its final all-JSON-RPC assertion is incompatible with middleware-level rejection, so it is disclosed and retained without rewrite. CapturedHTTP631-635 explicitly distinguishes intermediary HTTP status rejection from an application JSON-RPC error; the original finding itself already excluded h11 rejection from its application finding.

Separate `test_application_header_boundary.py` asserts both layers honestly: directASGI invalidbytes receive fixedHeaderMismatch without bodyread; real verifiedTLS control/DEL receive the exact h11plaintext400 and rawUTF8 `世界`/`é` receive the exact applicationHeaderMismatch in both modes. These16 live observations use the named Friday subprocess, verifiedprivateCA, noSDK retry,0handlers, finalactive0 and childexit0. `test_field_variants.py` separately exercises all Implementation strings/icon fields for required/optional omission and40 null/wrongtype variations, plus Tool/Text optional fields/annotations and cancellationdependent grammar through actual APIs. `checks/fresh-application-001`: **8 passed**, childexit0. Thus the original parser failures do not hide applicationerrors or remove mandatory assertions.

Guide18 correctly clarifies plainstandard grammar and separateName/Param sentinel semantics. No new feature/default/role/dependency/path or configuration change is introduced by R1. Complete findings/dispositions are in `findings.json`; no outstanding required mitigation remains.

## Exact required profile and inherited debt

All20 unchanged EXACT argv ran sequentially against frozen privatecandidate/base. Every raw child receipt, stdout/stderr and preflight is retained; wrapperexit0 was never interpreted as childsuccess. Originalguard/environment/source/checker scope remains unchanged, with own27 unique per-command HOME/TMP/cache destinations. All required functional/docs/lifecycle/whitespace checks pass; narrow/touchedRuff and MCP/narrowMypy pass.

| Required command ID | Raw child exit | Receipt |
| --- | ---: | --- |
{rows}

Candidate root: **{comparison['root']}**. Current acceptedbaseline: **{comparison['baseline']}**. Nine groupedskip location/reason rows represent14 skippedtests; all complete rows and full15-warning sections are exactly equal. RootRuff retains rawexit1 with exactly equal327 complete normalized diagnostic/fix objects. Full/baseMypy retain rawexit1 with identicalfour path/line/**column**/severity/code/message objects: `profiles.py:77:9,82:9,110:9,115:9`, no-any-return. Fresh supplemental `--show-column-numbers --no-pretty` outputs are retained, as are paired normalizedobjects and `exact-profile-comparison.json`. This is approved inheritedbaseline debt, not a clean rootchecker claim or new waiver. Full warning/object comparisons are stricter than counts.

Verified tooling: Python3.13.10, SDK/mcp-types2.3.0, Ruff0.14.10, Mypy1.19.1, IDNA3.20, reused without installs/sync. `checks/tooling-versions-001` records actual versions. Extra uncommitted `git diff --check` childexit0 is retained separately.

## All12 acceptance criteria

Every PASS below is supported by current source, actualassertions and fresh receipt groups in `full-unit-field-clause-assessment.json`; supplied ledger labels alone were not acceptance evidence.

| Criterion | Result | Current evidence and assessed behavior |
| --- | --- | --- |
{criteria_rows}

## Strict integrity chronology, context exceptions and residual risk

Before-first actual snapshot `{before['time']}` < first child `{first}` < last child `{last}` < final-after actual snapshot `{after['time']}`. Both rehash every expected librarypath from the ORIGINAL reused/additional manifests: **22,009 inventoryreferences /21,992 unique paths /192 distributions**, with17 identical overlappingreferences. Every expectedactualSHA matches; full actual libraries/distribution/inventory objects equal. Intermediate `after-last-command.json` is retained as well. Governed14,073candidate/11,738base trackedfile hashes, all controls/products/metadata/preservedproducts, historyarchives, originalrunners/guard and HEAD/status are exactly equal before/finalafter. Protected267 trackeduser-store paths remain omitted via the already-present sparsepatterns and their contents were not read. `final-integrity-chronology.json` retains strict equality/receipt/probe proof. Candidate staysclean at exact dispatchedHEAD; acceptedbase staysclean at f876603.

UP05 originalrunner SHA `e302adaef56d824be9ee962ee6c648624330f0d0d6aa1c992f5b0dbeced8e017`; originalgenericrunner SHA `ceec1b2316f4be3bce36fb778eb80b5d472561920d6d6fe35b8b30735e1776f0`; UP04runner SHA `5e5c9901bf66117ee11669d32de857ea2087738add9eef3c7ae6aa6f3c8592a6`; guard SHA `38f6a7483d66a066336d63c14980f1acfe307ec38848f0761c6928a66989a7a8`. `runner-destinations-only.diff` shows only revieweroutput/HOME/TMP/cache redirection, with checkercommands/configuration/source/environment allowlist intact. Approvedguarded loopback escalation was used for knownsandbox bindrestriction; nofailedsandbox rerun or publicnetwork/credential effect was introduced.

Shared context exception: policy/task memory lookup and environmentinstructions originate from the root session, but builder reasoning/conclusions were not inherited or used. Product/controlreview used frozenprivatecandidate; libraryandoriginalprobe files were read-only sharedprivatevalidation inputs. The sharedroot dirtycheckout was not edited or broadly scanned. Existing private sparsecandidate/base were reused under explicitcontrolling fixtureauthorization. Approved ignored synthetic relativeCWD `.friday`/experiment outputs from broad/root fixtures are retained and disclosed; they are not governedtracked drift and were neither cleaned nor included in evidence. No all-runtime equality claim is made. Ownruntime HOME/TMP/cache/cert/privatekey/store/bytecode/.git/generatedarchives are excluded from the explicit safe manifest.

Residual limitations: Pythonasync cancellation requires cooperation; resistantwork remains honestlyowned and blocksrestart in exercisedbounds. h11 may reject malformed wireheaders before applicationdispatch withplaintext400, so ASGIexactgrammar and actualTLSapplication proof are separate. OptionalOAuth/MRTR/subscription/Task/media/agent roles and realdeployment are excluded and unverified as implementedfeatures. Consent/UI remains with explicittoolowner. Fullinitiative/UP06 and maintaineracceptance are not supplied by this result. No unresolved mandatorycriterion remains within this bounded workunit. Safe manifestentries are individually verified before seal; reviewer evidence stops changing after sealing.
'''
(R/'report.md').write_text(text)
print(json.dumps({'outcome':'VERIFIED','report_sha256':sha(R/'report.md'),'checks':len(receipts),'chronology':proof['strict_chronology'],'candidate_stability':equal}))
