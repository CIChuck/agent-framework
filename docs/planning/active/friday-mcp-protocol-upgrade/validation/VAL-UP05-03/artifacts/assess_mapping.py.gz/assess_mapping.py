"""Independent review decisions; supplied ledgers are indexes, never verdicts."""
import ast,hashlib,json,re
from pathlib import Path
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP05-003';W=B/'work'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
index=json.loads((R/'inputs/final-actual-modern-mapping.json').read_text());plan=json.loads((R/'inputs/prospective-modern-schema-replan.json').read_text())
schema=R/'inputs/normative/modelcontextprotocol--modelcontextprotocol--main--schema--2026-07-28--schema.ts';text=schema.read_text();lines=text.splitlines();starts=list(re.finditer(r'^export\s+(?:interface|type)\s+(\w+)',text,re.M))
assert len(starts)==155 and sha(schema)==plan['controlling_server_schema_sha256']
modern=next(x for x in plan['schemas'] if x['sha256']==sha(schema));assert {x['name'] for x in modern['declarations']}=={m[1] for m in starts}
observed={
 'envelope':'decode rejects duplicate members, nonfinite/invalid UTF8, responses and batches; bounded_json limits byte/depth/node work; ServerRequest separates IDs and notifications. safe_error_id echoes only a readable own bounded ID; fixed errors never use local exception text.',
 'metadata':'metadata and implementation validate required version/capabilities plus optional identity/capability/log/progress shapes and reserved trace formats. Per-request values are not adopted for authorization, handler parameters or telemetry. Result serverInfo is fixed and opaque custom metadata remains bounded.',
 'version':'dispatch accepts only2026; UnsupportedProtocolVersion requires supported/requested exactly. HTTP first compares standard bytes; invalid bytes have fixedHeaderMismatch; legitimate unknownASCII version remains -32022. Discovery supportedVersions is a different field.',
 'catalog':'_stage creates sorted immutable definition/handler/page/cursor snapshots atomically. It reserves worst encodedID/cursor/SSE overhead and refuses incompatible lower limits; stale/forged/oversized cursors cannot invoke tools. Discover/list always ttlMs0/private.',
 'tooldefinition':'RegisteredTool validates async handler, frozen definition, dialect/subset, primitive static unique header bindings. Existing public ToolDefinition.parse validates optional Tool fields; no schema-reference network or regex evaluation is possible.',
 'toolcall':'dispatch captures catalog/tool/input/output/handler without pre-execution await, validates arguments before exactlyone async invocation; _execute revalidates direct result constructors, successful captured schema, fixedsafe error and wire sizes. Text/null/scalar/array structured output and ordered mixed text are supported; media/input_required refused.',
 'unsupported':'Only discover/list/call dispatch branches exist. Other RPCs use MethodNotFound; requestState/inputResponses are refused even when null. MissingRequiredClientCapability is unconstructible because no optional client capability is required. No server-to-client RPC, Tasks, prompts/resources/agent/subscription/cache/logging/OAuth role is advertised or activated.',
 'stdio':'Connection generation owns serving/read/dispatch/output/close-wait/signal/streams. Bounded separate rejection pool keeps reader cancellation/EOF responsive, saturation closes without queues. Single lock serializes writes; late/cancelled old writers cannot publish. First byte starts deadline including partial frame/oversize/body/handler/delivery; idle is distinct.',
 'notification':'ServerRequest has separate notification metadata and validates cancellation requestId/reason. Stdio cancels only current connection outstanding dispatcher; unknown/completed/malformed notifications are ignored withoutresponse. HTTP has no accepted core client notification and returns error without fabricatedID.',
 'http':'One exactPOST endpoint with JSON or single request-scopedSSE. Access/media/body/metadata/header gates precede dispatch. GET/DELETE405, otherpath404, method404/-32601, version400/-32022. Incoming response/batch rejected; no session/cookie/redirect/GETstream. Attempted sends are never replayed.',
 'headers':'HTTPServerPolicy.validate bounds headers and checks standard visibleASCII/SP/HTAB grammar before receive. validate_rpc_headers compares exactplain Method/Version bytes; Name/recognizedcustom values canonicalBase64/UTF8, omission/null and Decimal integer rules. All malformed/duplicate mirrored errors are400/-32020 with fixedmessage; valid unknowncustom header unused.',
 'access':'Typed policy validates literal bind/path/Host/Origin/bearer/TLS config, query denial and nonlocal prerequisites. Origin403, host/TLS400, bearer401 preserve fixedprivate errors. token is nonrepr/constant-time. No identity trust, credentials discovery or OAuth claim.',
 'ownership':'run_owned bounds count/deadline, tracks tasks untilactualsettlement and cancels onlyowner. Resistant work survives honestly in task/generation sets; unsafe restart blocked untilretry. HTTP disconnect owns its POST; successful delivery usesoriginaldeadline; onlyfixedterminal error has remaining shutdownwindow.',
 'registry':'configure_modern_tools_mode uses publicCore ToolDefinition/ToolRegistry and captured async execute method; snapshots supplied schemas/filter/prefix/collisions atomically; realDefaultToolRegistry synthetic tests verify no implicitregistry/agent/resource load.',
 'compatibility':'Newexports preserve oldserverclasses and constructor/config/version interfaces; optionalHTTP imports occur atcreate_app/serve, fixed missingdependencyerror. Accepted60product/19metadata hashes and preservedclient/cross-package tests independently match.',
 'observation':'Injected publicTelemetryInterface only; one admittedhandler start/finalend withfixedmethod,hashedregisteredtoolID,outcome. Invalidrequests produce nohandlerevents; observerexception cannotreplay; twoinstances isolateprovider/state and rawpayload/trace/credential/ID absent.',
 'interop':'PinnedSDK2.3Client mode2026/cacheNone/disabledinteractivecallbacks against actualnamedFriday stdiosubprocess/privateverifiedTLSJSON/SSE. Tests inspect actualdiscovery and fixturewire/handler/terminalcounters; rawnegatives bypass SDKHeaderMismatchretry. No self-client shortcut.'}
bundles={};pointer_checks=[];assertion_extracts=[]
for name,b in index['bundles'].items():
 result={'reviewer_assessment':observed[name],'criteria':b['criteria'],'source':[],'assertions':[],'checks':b['check_ids']}
 for kind in ['source','assertions']:
  for e in b[kind]:
   p=W/e['path'];raw=p.read_text();assert sha(p)==e['sha256'];tree=ast.parse(raw)
   nodes=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name==e['symbol']]
   n=min(nodes,key=lambda n:abs(n.lineno-e['line']))
   assert n.lineno==e['line'];refs={'path':e['path'],'symbol':n.name,'line':n.lineno,'end_line':n.end_lineno,'sha256':sha(p)}
   if kind=='assertions':
    asserts=[{'line':x.lineno,'expression':ast.get_source_segment(raw,x)} for x in ast.walk(n) if isinstance(x,ast.Assert)]
    raises=[{'line':x.lineno,'expression':ast.get_source_segment(raw,x)} for x in ast.walk(n) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='raises']
    assert asserts or raises;refs['assertions']=asserts;refs['raises']=raises
    assertion_extracts.append(refs)
   result[kind].append(refs);pointer_checks.append({'path':e['path'],'symbol':n.name,'hash_and_AST_location_match':True})
 bundles[name]=result
fields=[];declarations=[]
for d in index['declarations']:
 m=next(m for m in starts if m[1]==d['name']);line=text[:m.start()].count('\n')+1;assert line==d['schema_line']
 selected=d['bundles'];role='tools_server_boundary' if selected!=['unsupported'] else 'inactive_optional_role'
 if d['name'] in ['ContentBlock','ClientRequest','ClientNotification','ServerResult']:
  role='union_partially_supported';selected=['toolcall'] if d['name']=='ContentBlock' else ['catalog','toolcall','notification']
 declarations.append({'name':d['name'],'schema_line':line,'role':role,'evidence_bundles':selected,'reviewer_decision':'; '.join(observed[x] for x in selected)})
for f in index['fields']:
 assert lines[f['schema_line']-1].strip()==f['field'],(f['declaration'],f['schema_line'],f['field'])
 d=next(d for d in declarations if d['name']==f['declaration']);selected=f['bundles'];role='tools_server_boundary' if f['disposition']=='supported_boundary' else 'inactive_variant_or_role'
 # Optional advertised/emitted fields do not become implemented simply because
 # their enclosing declaration contains some supported fields.
 if f['declaration']=='ServerCapabilities' and not f['field'].startswith('tools?:'):role='omitted_optional_capability';selected=['catalog','unsupported']
 if f['declaration']=='DiscoverResult' and f['field'].startswith('instructions?:'):role='omitted_optional_field';selected=['catalog']
 if f['declaration']=='ResultMetaObject':selected=['metadata','toolcall']
 if f['declaration'] in ['RequestMetaObject','HeaderMismatchError'] and any(s in f['field'] for s in ['protocolVersion','code:']):selected=list(dict.fromkeys(selected+['headers','version']))
 fields.append({'declaration':f['declaration'],'schema_line':f['schema_line'],'field':f['field'],'role':role,'evidence_bundles':selected,'reviewer_decision':'; '.join(observed[x] for x in selected),'variant_boundary':'Mandatory variants enforced; optional fields preserve omission and reject explicit null/wrongtype when present; emitted fixedfields checked in raw response/SDK tests. Inactive variants are omitted/rejected before invocation; no claim of optional-role conformance.'})
assert len(fields)==337
captures=json.loads((R/'source-capture-integrity.json').read_text());byurl={s['url']:s for s in captures};clauses=[]
for c in index['clauses']:
 src=R/byurl[c['source']]['path'];assert sha(src)==c['sha256'];raw=src.read_text();paragraph=' '.join(c['paragraph'].split());assert paragraph in ' '.join(raw.split())
 role=c['disposition'];selected=c['bundles']
 if '2025-' in c['source']:role='historical_client_or_legacy_authority';decision='2025 authority preserved for accepted client/legacy compatibility, not applied as modernserver schema; current tests/hashes verify preservation.'
 elif '/basic/authorization' in c['source'] and c['line']>21:role='inactive_optional_oauth';decision='Optional OAuth conformance explicitly declined by approved static administrative profile; conditionalOAuth MUSTs not claimed implemented; no tokenissuer/discovery/consent/metadata server role.'
 elif c['id'] in ['SRV-CLAUSE-0016','SRV-CLAUSE-0045','SRV-CLAUSE-0111','SRV-CLAUSE-0116','SRV-CLAUSE-0138','SRV-CLAUSE-0282']:role='documented_should_tradeoff';decision='Guide records staticgate/OAuth decline, fixed initializeerrors, Unicode names/sentinel, avoid sensitive mirroredargs, no peerreason logs; applicable approved tradeoff does not waive MUST.'
 elif role=='normative_interpretation':decision='BCP14 interpretation only; no runtime test claimed.'
 elif role=='application_owner_should':decision='Explicittool owner retains consent/UI/humanapproval; this library loads onlyexplicit async tools and introduces no UI authority.'
 elif role=='other_role_or_conditional_client_duty':decision='Client/intermediary/optionalrole duty distinguished from Friday toolsserver; supported subset evaluated through indicated bundles; no claim that serverimplements a client duty.'
 else:decision='; '.join(observed[x] for x in selected)
 # The field-value grammar paragraph has both a client encoding obligation
 # and a direct server validation dependency. Preserve both roles explicitly.
 if c['id']=='SRV-CLAUSE-0081':role='mixed_client_encoding_and_server_grammar';selected=['headers'];decision=observed['headers']+' Client sentinel obligation applies Name/Param; Method/Version stay plain.'
 clauses.append({**{k:c[k] for k in ['id','source','sha256','line','paragraph','tokens']},'reviewer_role':role,'evidence_bundles':selected,'reviewer_decision':decision})
criteria=[{'id':c['id'],'requirement':c['requirement'],'evidence_bundles':c['bundles'],'reviewer_assessment':'; '.join(observed[x] for x in c['bundles'])} for c in index['criteria']]
result={'reviewer':'/root/rem006_r1_fresh_full_validator','candidate':'012430089bcd1b60b12c071b8c8220f20d2bac79','schema_sha256':sha(schema),'controlling_corrected_plan_sha256':sha(R/'inputs/prospective-modern-schema-replan.json'),'inventory_only_counts':{'declarations':len(declarations),'fields':len(fields),'clauses':len(clauses)},'counts_are_not_conformance':True,'independent_review_basis':'Current source inspection, exact schema lines/paragraphs, immutable authority, independently verified AST/hash/assertion locations, new reviewer probes and fresh commands. Builder ledger used only as input index; row classifications below are reviewer decisions. Unadvertised optional/client/historical roles are explicitly separate. Complete role mapping is bounded profile validation, not blanket MCP conformance.','bundles':bundles,'criteria':criteria,'declarations':declarations,'fields':fields,'clauses':clauses,'pointer_integrity':pointer_checks}
(R/'full-unit-field-clause-assessment.json').write_text(json.dumps(result,indent=2)+'\n');(R/'actual-assertion-extracts.json').write_text(json.dumps(assertion_extracts,indent=2)+'\n');print(json.dumps({'inventory':result['inventory_only_counts'],'verified_pointer_refs':len(pointer_checks),'assertion_groups':len(assertion_extracts)}))
