import asyncio,ipaddress,json,os,socket,ssl,sys
from pathlib import Path
from datetime import UTC,datetime,timedelta
import pytest,httpx
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID
def tls_material(tmp_path, *, valid_name=True):
    key = ec.generate_private_key(ec.SECP256R1())
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "synthetic-loopback")])
    now = datetime.now(UTC)
    san = (
        x509.IPAddress(ipaddress.ip_address("127.0.0.1"))
        if valid_name
        else x509.DNSName("wrong.example")
    )
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=1))
        .not_valid_after(now + timedelta(hours=1))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .add_extension(x509.SubjectAlternativeName([san]), critical=False)
        .sign(key, hashes.SHA256())
    )
    cert_path = tmp_path / "fixture-cert.pem"
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    (tmp_path / "fixture-key.pem").write_bytes(
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
    )
    context = ssl.create_default_context(cafile=str(cert_path))
    assert context.check_hostname and context.verify_mode == ssl.CERT_REQUIRED
    return context

@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['json','sse'])
async def test_real_verified_tls_standard_header_boundary(tmp_path,mode):
 context=tls_material(tmp_path)
 with socket.socket() as reservation:
  reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
 counter=tmp_path/'counter.jsonl';ready=tmp_path/'ready';fixture=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/fixtures/friday_modern_tools_server.py')
 process=await asyncio.create_subprocess_exec(sys.executable,str(fixture),mode,str(counter),str(port),str(tmp_path/'fixture-cert.pem'),str(tmp_path/'fixture-key.pem'),str(ready),cwd=tmp_path,env=dict(os.environ),stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
 observations=[]
 try:
  for _ in range(300):
   if ready.exists():break
   if process.returncode is not None:raise RuntimeError('Approved fixture exited')
   await asyncio.sleep(.01)
  assert ready.exists()
  async with httpx.AsyncClient(verify=context,trust_env=False,follow_redirects=False) as client:
   for field in ['mcp-method','mcp-protocol-version']:
    for suffix in ['\x01','\x7f','世界']:
     method='server/discover'+(suffix if field=='mcp-method' else '');version='2026-07-28'+(suffix if field=='mcp-protocol-version' else '')
     body=json.dumps({'jsonrpc':'2.0','id':91,'method':method,'params':{'_meta':{'io.modelcontextprotocol/protocolVersion':version,'io.modelcontextprotocol/clientCapabilities':{}}}}).encode()
     headers=[(b'content-type',b'application/json'),(b'accept',b'application/json,text/event-stream'),(b'mcp-protocol-version',version.encode()),(b'mcp-method',method.encode())]
     q=await client.post(f'https://127.0.0.1:{port}/mcp',headers=headers,content=body)
     try:reply=q.json()
     except ValueError:reply={'raw_parser_body':q.text}
     observations.append({'mode':mode,'header':field,'suffix_hex':suffix.encode().hex(),'status':q.status_code,'body':reply})
 finally:
  if process.returncode is None:process.terminate()
  try:await asyncio.wait_for(process.wait(),2)
  except TimeoutError:process.kill();await process.wait();raise
  stdout,stderr=await process.communicate();assert process.returncode==0 and not stdout
 rows=[json.loads(x) for x in counter.read_text().splitlines()] if counter.exists() else []
 assert sum(x['event']=='handler_start' for x in rows)==0 and rows[-1]=={'event':'server_stopped','active':0}
 print('LIVE_VERIFIED_TLS_INVALID_STANDARD',json.dumps({'observations':observations,'handler_starts':0,'child_exit':process.returncode,'active_final':rows[-1]['active']}))
 assert all(x['status']==400 and x['body'].get('error',{}).get('code')==-32020 for x in observations)
