import json,subprocess
from pathlib import Path
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP05-003';python=str(B/'venv/bin/python')
for label,paths in [('original-edges-001',['test_review_edges.py']),('original-live-001',['test_standard_header_live.py']),('fresh-application-001',['test_application_header_boundary.py','test_field_variants.py'])]:
 subprocess.run([python,str(R/'run_check_UP05.py'),label,'work',python,'-m','pytest',*[str(R/p) for p in paths],'-q','-s'],check=True)
 print('CHILD',label,json.loads((R/'checks'/label/'receipt.json').read_text())['exit_code'],flush=True)
subprocess.run([python,str(R/'run_check_UP05.py'),'worktree-whitespace-001','work','git','diff','--check'],check=True)
