import json,subprocess
from pathlib import Path
B=Path('/private/tmp/friday-mcp-upgrade');R=B/'independent-review-UP05-003'
r=json.loads((B/'work/docs/planning/active/friday-mcp-protocol-upgrade/validation-request-REM-MCP-UP-006-R1.json').read_text())
for c in r['required_checks']:
 label='full-001-'+c['id']
 if (R/'checks'/label).exists():raise RuntimeError('label reused')
 subprocess.run([str(B/'venv/bin/python'),str(R/'run_check_UP05.py'),label,c['snapshot'],*c['argv']],check=True)
 receipt=json.loads((R/'checks'/label/'receipt.json').read_text());print('CHILD',c['id'],receipt['exit_code'],flush=True)
for c in [c for c in r['required_checks'] if c['id'] in ['full-mypy','baseline-full-mypy']]:
 label='columns-001-'+c['id'];subprocess.run([str(B/'venv/bin/python'),str(R/'run_check_UP05.py'),label,c['snapshot'],*c['argv'],'--show-column-numbers','--no-pretty'],check=True)
 print('CHILD',label,json.loads((R/'checks'/label/'receipt.json').read_text())['exit_code'],flush=True)
