"""Fresh independent header assertions; original raw middleware probe is retained."""
import asyncio,json,os,socket,sys,importlib.util
from pathlib import Path
import pytest,httpx
from friday_mcp.server import StreamableHTTPMCPServer,ToolCallResult
_spec=importlib.util.spec_from_file_location('_original_probe_helper',Path(__file__).with_name('test_standard_header_live.py'))
_original=importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_original)
tls_material=_original.tls_material
V='2026-07-28';P='io.modelcontextprotocol/'
def frame(method,version):
 return json.dumps({'jsonrpc':'2.0','id':'synthetic-private-request','method':method,'params':{'_meta':{P+'protocolVersion':version,P+'clientCapabilities':{}},'name':'held'}}).encode()
def headers(method,version):
 return [(b'host',b'127.0.0.1:8000'),(b'content-type',b'application/json'),(b'accept',b'application/json,text/event-stream'),(b'mcp-method',method),(b'mcp-protocol-version',version),(b'mcp-name',b'held')]
@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['json','sse'])
@pytest.mark.parametrize('field',['mcp-method','mcp-protocol-version'])
async def test_direct_asgi_full_byte_grammar_and_privacy(mode,field):
 server=StreamableHTTPMCPServer(response_mode=mode);calls=[]
 async def handler(a):calls.append(1);return ToolCallResult.text('ok')
 server.register_tool({'name':'held','inputSchema':{'type':'object'}},handler)
 invalid=[*range(9),*range(10,32),*range(127,256)];observations=[]
 try:
  for byte in invalid:
   method=b'tools/call';version=V.encode();bad=b'private-'+bytes([byte])+b'-value'
   if field=='mcp-method':method=bad
   else:version=bad
   consumed=[];messages=[]
   async def receive():consumed.append(1);return {'type':'http.request','body':frame(method.decode('latin1'),version.decode('latin1')),'more_body':False}
   async def send(m):messages.append(m)
   await server({'type':'http','path':'/mcp','method':'POST','scheme':'http','headers':headers(method,version),'query_string':b''},receive,send)
   body=json.loads(messages[1]['body'])
   assert messages[0]['status']==400 and body=={'jsonrpc':'2.0','error':{'code':-32020,'message':'Header mismatch'}}
   assert not consumed and not calls and server.active_requests==0
   observations.append(byte)
  print('FRESH_DIRECT_ASGI_BYTE_SWEEP',mode,field,len(observations),'zero_body_reads_handlers_ids_or_raw_values')
 finally:await server.stop()

@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['json','sse'])
async def test_real_tls_parser_vs_application_corrected_expectations(tmp_path,mode):
 context=tls_material(tmp_path)
 with socket.socket() as reservation:reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
 counter=tmp_path/'counter.jsonl';ready=tmp_path/'ready';fixture=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/fixtures/friday_modern_tools_server.py')
 process=await asyncio.create_subprocess_exec(sys.executable,str(fixture),mode,str(counter),str(port),str(tmp_path/'fixture-cert.pem'),str(tmp_path/'fixture-key.pem'),str(ready),cwd=tmp_path,env=dict(os.environ),stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
 observations=[]
 try:
  for _ in range(300):
   if ready.exists():break
   if process.returncode is not None:raise RuntimeError('Approved fixture exited')
   await asyncio.sleep(.01)
  assert ready.exists()
  async with httpx.AsyncClient(verify=context,trust_env=False,follow_redirects=False) as client:
   for field in ['mcp-method','mcp-protocol-version']:
    for suffix in ['\x01','\x7f','世界','é']:
     method='tools/call'+(suffix if field=='mcp-method' else '');version=V+(suffix if field=='mcp-protocol-version' else '')
     hs=[(k,v) for k,v in headers(method.encode(),version.encode()) if k!=b'host']
     q=await client.post(f'https://127.0.0.1:{port}/mcp',headers=hs,content=frame(method,version))
     assert q.status_code==400
     if suffix in ['\x01','\x7f']:
      assert q.text=='Invalid HTTP request received.' and q.headers['content-type'].startswith('text/plain')
      layer='h11_pre_ASGI'
     else:
      assert q.json()=={'jsonrpc':'2.0','error':{'code':-32020,'message':'Header mismatch'}}
      layer='application'
     observations.append({'mode':mode,'field':field,'suffix_hex':suffix.encode().hex(),'layer':layer,'status':q.status_code,'body':q.text})
 finally:
  if process.returncode is None:process.terminate()
  try:await asyncio.wait_for(process.wait(),2)
  except TimeoutError:process.kill();await process.wait();raise
  stdout,stderr=await process.communicate();assert process.returncode==0 and not stdout
 rows=[json.loads(x) for x in counter.read_text().splitlines()] if counter.exists() else []
 assert sum(x['event']=='handler_start' for x in rows)==0 and rows[-1]=={'event':'server_stopped','active':0}
 print('CORRECTED_LIVE_VERIFIED_TLS',json.dumps({'observations':observations,'handler_starts':0,'active_final':0,'child_exit':0}))
