import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

base = Path('/private/tmp/friday-mcp-upgrade')
review = base / 'remediation-01-builder'
label, snapshot, *argv = sys.argv[1:]
work = base / snapshot
output = review / 'checks' / label
output.mkdir(parents=True, exist_ok=True)
private = review / 'runtime' / label
private.mkdir(parents=True, exist_ok=True)
for folder in ('home', 'tmp', 'cache'):
    (private / folder).mkdir(exist_ok=True)
venv = base / ('baseline-venv' if snapshot == 'baseline' else 'venv')
environment = {
    'PATH': str(venv / 'bin') + ':/opt/homebrew/bin:/usr/bin:/bin',
    'HOME': str(private / 'home'), 'TMPDIR': str(private / 'tmp'),
    'PYTHONPATH': ':'.join([str(base / 'guard')] + [str(p) for p in sorted((work / 'packages').glob('*/src'))] + [str(work / 'packages/friday-chat/tests_chat')]),
    'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0',
    'PYTEST_ADDOPTS': '--import-mode=importlib -o cache_dir=' + str(private / 'cache/pytest'),
    'RUFF_CACHE_DIR': str(private / 'cache/ruff'), 'MYPY_CACHE_DIR': str(private / 'cache/mypy'),
    'UV_CACHE_DIR': str(private / 'cache/uv'), 'UV_NO_SYNC': '1', 'UV_OFFLINE': '1',
    'UV_PROJECT_ENVIRONMENT': str(venv), 'VIRTUAL_ENV': str(venv),
    'FRIDAY_TELEMETRY_ENABLED': 'false', 'ANONYMIZED_TELEMETRY': 'false',
    'TOKENIZERS_PARALLELISM': 'false',
    'XDG_CACHE_HOME': str(private / 'cache'), 'MPLCONFIGDIR': str(private / 'cache/mpl'),
}
started = datetime.now(timezone.utc).isoformat()
with (output / 'stdout').open('wb') as stdout, (output / 'stderr').open('wb') as stderr:
    process = subprocess.run(argv, cwd=work, env=environment, stdout=stdout, stderr=stderr)
receipt = {'argv': argv, 'cwd': str(work), 'environment': environment, 'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': process.returncode, 'stdout_sha256': hashlib.sha256((output / 'stdout').read_bytes()).hexdigest(), 'stderr_sha256': hashlib.sha256((output / 'stderr').read_bytes()).hexdigest(), 'guard_sha256': hashlib.sha256((base / 'guard/sitecustomize.py').read_bytes()).hexdigest()}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'check': label, 'exit': process.returncode, 'evidence': str(output)}))
