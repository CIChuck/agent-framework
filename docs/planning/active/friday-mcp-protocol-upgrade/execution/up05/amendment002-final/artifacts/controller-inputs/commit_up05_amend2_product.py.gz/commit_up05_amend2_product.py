from pathlib import Path
import json,hashlib,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=json.loads((p/'authority-UP-05-amendment-002.json').read_text())
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
for x in a['controls']+a['prior_frozen_manifests']+[a['approval'],a['approved_proposal'],a['amendment_approval'],a['approved_amendment'],a['amendment_document'],a['parent_authority'],a['prior_amendment_authority'],a['prior_amendment_approval'],a['prior_approved_amendment'],a['prior_amendment_document'],a['corrected_prospective_plan']]:
 if h(w/x['path'])!=x['sha256']:raise RuntimeError('Authority drift')
for key in ['metadata_hashes','preserved_product_hashes']:
 for f,d in a[key].items():
  if h(w/f)!=d:raise RuntimeError('Preserved hash drift')
paths=[x['path'] for x in a['product_paths']]
if any(not (w/f).is_file() for f in paths):raise RuntimeError('Incomplete product paths')
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=w,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=w,text=True).splitlines())
if not changed or not changed.issubset(set(paths)):raise RuntimeError('Uncommitted scope drift')
if json.loads((b/'checks/up05-amend2-dev-focused-09/receipt.json').read_text())['exit_code'] or json.loads((b/'checks/up05-amend2-dev-ruff-09/receipt.json').read_text())['exit_code']:raise RuntimeError('Development check failed')
subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','commit','-m','Enforce complete modern MCP server schema and owned transport boundaries'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip())
