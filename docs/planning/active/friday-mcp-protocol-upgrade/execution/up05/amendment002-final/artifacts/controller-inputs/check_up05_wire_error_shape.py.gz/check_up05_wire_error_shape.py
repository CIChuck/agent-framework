import asyncio,json
from friday_mcp.server import ModernToolsMCPServer
from friday_mcp.server.protocol import PREFIX,VERSION
async def check():
 server=ModernToolsMCPServer();version='2026-08-01';raw=json.dumps({'jsonrpc':'2.0','id':1,'method':'server/discover','params':{'_meta':{PREFIX+'protocolVersion':version,PREFIX+'clientCapabilities':{}}}}).encode();response=await server.handle(raw);await server.stop();print(json.dumps({'actual':response,'expected_error_data':{'supported':[VERSION],'requested':version},'active_owners':server.active_requests},sort_keys=True))
 error=response.get('error')
 if not isinstance(error,dict) or error.get('data')!={'supported':[VERSION],'requested':version}:raise RuntimeError('Pinned UnsupportedProtocolVersionError data fields do not match')
asyncio.run(check())
