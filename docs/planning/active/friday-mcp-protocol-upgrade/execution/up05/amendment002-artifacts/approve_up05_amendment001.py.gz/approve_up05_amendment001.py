from pathlib import Path
import json,hashlib,subprocess,importlib.util
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';expected='473ec5b13a4e66ac9948c87d10ddb569d3c701de'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def dump(f,j):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(j,indent=2)+'\n')
if subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()!=expected:raise RuntimeError('HEAD drift')
proposal=p/'proposals/UP-05-amendment-001-authority-manifest.json';j=json.loads(proposal.read_text());parent=p/'authority-UP-05.json';a=json.loads(parent.read_text())
for entry in [j['parent_authority'],j['amendment_document'],j['checkpoint']]+a['controls']+a['prior_frozen_manifests']:
 if h(w/entry['path'])!=entry['sha256']:raise RuntimeError('Authority drift')
checkpoint=json.loads((w/j['checkpoint']['path']).read_text())
for entry in checkpoint['product_paths']:
 if h(w/entry['path'])!=entry['current_sha256']:raise RuntimeError('Partial construction drift')
for key in ['metadata_hashes','preserved_product_hashes']:
 for f,d in a[key].items():
  if h(w/f)!=d:raise RuntimeError('Preserved hash drift')
receipt=p/'approval-UP-05-amendment-001.json';dump(receipt,{'amendment':'AMEND-MCP-UP-005-001','work_unit':'MCP-UP-05','status':'approved','approved_by':'Chuck Russell','maintainer_statement':'approved','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'proposal_commit':expected,'proposal_manifest_sha256':h(proposal),'override':j['override'],'scope':'Original18 product paths/12 criteria/20 required commands and private effects unchanged','later_unit_or_remote_delivery_authority':'not granted'})
a.update(status='approved_execution_with_amendment',amendment_approval={'path':str(receipt.relative_to(w)),'sha256':h(receipt)},approved_amendment={'path':str(proposal.relative_to(w)),'sha256':h(proposal)},amendment_document=j['amendment_document'],amendment_override=j['override'],amended_execution_baseline=expected,parent_authority=j['parent_authority']);dump(p/'authority-UP-05-amendment-001.json',a)
sf=p/'execution/current-process-state.json';s=json.loads(sf.read_text());s.update(execution_phase='construction',validation_state='not_ready',unit_completion='not proposed; approved UP-05 construction resumed',note='Exact AMEND-MCP-UP-005-001 approved; parent controls immutable; required immediately stale private discovery/list metadata authorized',next_gate='Complete amended CD-MCP-UP-005, all20 checks and stable candidate for fresh independent full-unit validation',pending_amendment=None,construction_stop=None,amendment_status='approved',current_execution_authority=str((p/'authority-UP-05-amendment-001.json').relative_to(w)));dump(sf,s)
log=p/'execution-log.md';log.write_text(log.read_text()+'\n\n## 2026-10-13 - UP-05 cache-metadata amendment approved\n\nChuck Russell explicitly stated “approved” for AMEND-MCP-UP-005-001. Separate\napproval receipt and amended execution authority pin the exact correction.\nConstruction resumes within the same18 paths/12 criteria/20 checks/private\nfixture effects. Parent controls remain unchanged. No later-unit, acceptance\nor publication authority is inferred.\n')
spec=importlib.util.spec_from_file_location('board',w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);board=m.load_board(w);task=next(t for t in board['tasks'] if t['id']=='friday-mcp-protocol-upgrade');task['next_gate']=s['next_gate'];m._append_event(board,task_id=task['id'],actor='Chuck Russell',actor_role='maintainer',action='approved exact AMEND-MCP-UP-005-001',note='Exact statement: approved. Required immediately stale private discovery/list wire metadata; original construction scope unchanged, local only',evidence=str(receipt.relative_to(w)));m._save_board_and_dashboard(board,w)
for label,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show','friday-mcp-protocol-upgrade'],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 name='up05-amendment001-approved-'+label;subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP05.py'),name,'work',str(b/'venv/bin/python'),*args],check=True)
 if json.loads((b/'checks'/name/'receipt.json').read_text())['exit_code']:raise RuntimeError('Process check failed')
paths=[str(f.relative_to(w)) for f in [receipt,p/'authority-UP-05-amendment-001.json',sf,log]]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','commit','-m','Record exact MCP server stale cache-metadata amendment approval'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip())
