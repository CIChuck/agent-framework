from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp');source=b/'src/friday_mcp/server';p=source/'protocol.py';s=p.read_text();pos=s.index('\n\nclass ServerWireError')
s=s[:pos]+'\n\nDEFAULT_SERVER_LIMITS = ServerLimits()'+s[pos:];s=s.replace('= ServerLimits()', '= DEFAULT_SERVER_LIMITS');s=s.replace('DEFAULT_SERVER_LIMITS = DEFAULT_SERVER_LIMITS','DEFAULT_SERVER_LIMITS = ServerLimits()')
insert='''

def _trace_formats(obj: dict[str, JSONValue], limits: ServerLimits) -> None:
    """Validate reserved W3C field formats; never adopt or propagate peer context."""
    if "traceparent" in obj:
        value = obj["traceparent"]
        if not isinstance(value, str) or len(value) > limits.identity_bytes:
            raise ServerWireError(-32602)
        match = re.fullmatch(r"([0-9a-f]{2})-([0-9a-f]{32})-([0-9a-f]{16})-([0-9a-f]{2})(-[!-~]+)?", value)
        if match is None or match[1] == "ff" or int(match[2], 16) == 0 or int(match[3], 16) == 0 or match[1] == "00" and match[5] is not None:
            raise ServerWireError(-32602)
    if "tracestate" in obj:
        state = obj["tracestate"]
        if not isinstance(state, str) or len(state) > 512:
            raise ServerWireError(-32602)
        members = state.split(",")
        if len(members) > 32:
            raise ServerWireError(-32602)
        seen: set[str] = set()
        for part in members:
            member = part.strip(" \\t")
            if not member:
                continue
            key, separator, value = member.partition("=")
            if not separator or re.fullmatch(r"(?:[a-z][a-z0-9_*/-]{0,255}|[a-z0-9][a-z0-9_*/-]{0,240}@[a-z][a-z0-9_*/-]{0,13})", key) is None or key in seen or not 1 <= len(value) <= 256 or value.endswith(" ") or any(not 0x20 <= ord(c) <= 0x7e or c in ",=" for c in value):
                raise ServerWireError(-32602)
            seen.add(key)
    if "baggage" in obj:
        baggage = obj["baggage"]
        if not isinstance(baggage, str) or len(baggage) > min(8192, limits.request_bytes):
            raise ServerWireError(-32602)
        if not baggage:
            return
        members = baggage.split(",")
        if len(members) > 180:
            raise ServerWireError(-32602)
        token = re.compile(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+")
        for member in members:
            for index, property_text in enumerate(member.split(";")):
                key, separator, value = property_text.strip(" \\t").partition("=")
                if token.fullmatch(key.rstrip(" \\t")) is None or index == 0 and not separator:
                    raise ServerWireError(-32602)
                value = value.strip(" \\t")
                if any(not (ord(c) == 0x21 or 0x23 <= ord(c) <= 0x2b or 0x2d <= ord(c) <= 0x3a or 0x3c <= ord(c) <= 0x5b or 0x5d <= ord(c) <= 0x7e) for c in value) or re.search(r"%(?![0-9A-Fa-f]{2})", value):
                    raise ServerWireError(-32602)
'''
pos=s.index('\n\ndef metadata(');s=s[:pos]+insert+s[pos:];s=s.replace('''    if notification:
        if PREFIX''','''    _trace_formats(obj, limits)
    if notification:
        if PREFIX''')
s += '''

def notification_envelope(raw: bytes, limits: ServerLimits) -> bool:
    try:
        value = decode(raw, limits)
        return isinstance(value, dict) and value.get("jsonrpc") == "2.0" and isinstance(value.get("method"), str) and "id" not in value and "result" not in value and "error" not in value
    except ServerWireError:
        return False
'''
s=s.replace('# A conservative work cap prevents schema x instance expansion from monopolizing the reader.', '# Bound schema x instance work so validation cannot monopolize the reader.').replace('"""Serialized immutable text/structured result; null remains distinct from omission."""','"""Immutable text/structured result, preserving null versus omission."""').replace('# Dated client parser validates every supported text annotation/metadata field.', '# Validate every supported dated text annotation and metadata field.');p.write_text(s)
for name in ['modern.py','modern_stdio.py','http.py']:
 p=source/name;s=p.read_text().replace('limits: ServerLimits = ServerLimits()', 'limits: ServerLimits = DEFAULT_SERVER_LIMITS');s=s.replace('    ServerLimits,','    DEFAULT_SERVER_LIMITS,\n    ServerLimits,');p.write_text(s)
p=source/'modern.py';s=p.read_text().replace('from dataclasses import dataclass','from dataclasses import dataclass\nfrom contextlib import suppress').replace('''        self.limits = limits''','''        if not isinstance(limits, ServerLimits):
            raise ValueError("Invalid MCP server limits")
        self.limits = limits''').replace('# Revalidate public dataclass constructors and lower limits before publishing anything.', '# Revalidate direct constructors and lower limits before publishing.').replace('# Reserve the worst allowed response ID and a full cursor before byte partitioning.', '# Reserve the worst encoded ID and full cursor before byte partitioning.').replace('"""Bound admission and settlement without clearing cancellation-resistant owners."""','"""Bound admission and retain owners that resist cancellation."""').replace('''            try:
                span = observer.start_span("mcp.tools.call")
            except Exception:
                pass''','''            with suppress(Exception):
                span = observer.start_span("mcp.tools.call")''').replace('''                try:
                    observer.end_span(
                        span, {"method": "tools/call", "outcome": outcome}
                    )
                except Exception:
                    pass''','''                with suppress(Exception):
                    observer.end_span(span, {"method": "tools/call", "outcome": outcome})''');p.write_text(s)
p=source/'http.py';s=p.read_text().replace('policy: HTTPServerPolicy = HTTPServerPolicy()', 'policy: HTTPServerPolicy | None = None').replace('''        if not isinstance(policy, HTTPServerPolicy)''','''        if policy is None:
            policy = HTTPServerPolicy()
        if not isinstance(policy, HTTPServerPolicy)''');p.write_text(s)
p=source/'modern_stdio.py';s=p.read_text().replace('    safe_error_id,', '    safe_error_id,\n    notification_envelope,').replace('''                    raise ServerWireError(-32601)
                if request.request_id''','''                    return
                if request.request_id''').replace('''            except ServerWireError as error:
                await write_response(''','''            except ServerWireError as error:
                if notification_envelope(raw, self.limits):
                    return
                await write_response(''').replace('# Let already-admitted operations start while continuing to read cancellation.', '# Start admitted operations while keeping cancellation reads responsive.');p.write_text(s)
p=source/'registry.py';s=p.read_text().replace('"""Replace catalog atomically with a validated explicit snapshot; no auto refresh."""','"""Publish a validated explicit snapshot atomically, without auto refresh."""');p.write_text(s)
p=b/'tests_mcp/server/test_registry.py';s=p.read_text().replace('# The public protocol permits a tool property to change; bridge must still reject collisions.', '# Mutable public tool properties must not bypass collision checks.');p.write_text(s)
p=b/'tests_mcp/server/test_modern_protocol.py';s=p.read_text().replace('test_optional_implementation_full_fields_unknown_extensions_and_per_request_caps','test_optional_implementation_extensions_and_per_request_caps');p.write_text(s)
p=b/'tests_mcp/server/test_streamable_http.py';s=p.read_text().replace('# Parent/null arguments invalid under schema are independently rejected after header validation.', '# Schema-invalid null arguments fail after header validation.').replace('async def handler(args):\n            calls.append(1)','async def handler(args, calls=calls):\n            calls.append(1)');p.write_text(s)
