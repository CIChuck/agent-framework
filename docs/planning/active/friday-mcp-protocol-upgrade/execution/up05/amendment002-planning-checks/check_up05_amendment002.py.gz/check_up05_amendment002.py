from pathlib import Path
import json,subprocess,gzip,hashlib
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';e=p/'execution/up05/amendment002-planning-checks';e.mkdir(exist_ok=True)
checks={'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show','friday-mcp-protocol-upgrade'],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}
entries=[]
for key,args in checks.items():
 label='up05-amendment002-'+key
 subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP05.py'),label,'work',str(b/'venv/bin/python'),*args],check=True)
 receipt=json.loads((b/'checks'/label/'receipt.json').read_text())
 if receipt['exit_code']:raise RuntimeError('Process check failed '+key)
 for name in ['stdout','stderr','receipt.json','preflight.json']:
  raw=(b/'checks'/label/name).read_bytes();out=e/(label+'--'+name+'.gz');out.write_bytes(gzip.compress(raw,mtime=0));entries.append({'path':str(out.relative_to(p)),'raw_sha256':hashlib.sha256(raw).hexdigest(),'artifact_sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
for script in ['prepare_up05_amendment002.py','check_up05_amendment002.py']:
 raw=(b/script).read_bytes();out=e/(script+'.gz');out.write_bytes(gzip.compress(raw,mtime=0));entries.append({'path':str(out.relative_to(p)),'raw_sha256':hashlib.sha256(raw).hexdigest(),'artifact_sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
(e/'manifest.json').write_text(json.dumps({'entries':entries,'result':'All five process checks exit0; no product verification or independent acceptance'},indent=2)+'\n')
paths=[str(x.relative_to(w)) for x in e.iterdir()];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','commit','-m','Retain MCP cache-metadata amendment planning checks'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip())
