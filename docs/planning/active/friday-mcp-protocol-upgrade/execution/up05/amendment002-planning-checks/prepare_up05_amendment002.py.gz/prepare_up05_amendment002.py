from pathlib import Path
import json,gzip,hashlib,subprocess,importlib.util
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';e=p/'execution/up05';a=json.loads((p/'authority-UP-05-amendment-001.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def dump(f,j):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(j,indent=2)+'\n')
if head!='ed8f8cbdc27b469b389487dd931678b4777b13b9':raise RuntimeError('HEAD drift')
for row in a['controls']+a['prior_frozen_manifests']+[a['approval'],a['approved_proposal'],a['amendment_approval'],a['approved_amendment'],a['amendment_document'],a['parent_authority']]:
 if h(w/row['path'])!=row['sha256']:raise RuntimeError('Authority drift')
for key in ['metadata_hashes','preserved_product_hashes']:
 for path,digest in a[key].items():
  if h(w/path)!=digest:raise RuntimeError('Protected source drift')
replan=e/'prospective-modern-schema-replan.json';plan=json.loads(replan.read_text())
if plan['modern_counts']!={'declarations':155,'fields':337} or plan['controlling_server_schema_sha256']!='742750af0bb8c716e7030c4977c992b55d1adc4407e9e66997db5846baedc2cd':raise RuntimeError('Incorrect modern selection')
art=e/'amendment002-artifacts';art.mkdir(exist_ok=True);entries=[]
def retain(f,name):
 raw=f.read_bytes();dest=art/(name+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0));entries.append({'artifact':str(dest.relative_to(p)),'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'artifact_sha256':h(dest),'provenance':str(f)})
labels=sorted(x.name for x in (b/'checks').iterdir() if x.is_dir() and (x.name.startswith('up05-amendment001-approved-') or x.name.startswith('up05-amended-dev-') or x.name.startswith('up05-full-') or x.name in ['up05-baseline-full-mypy-columns','up05-wire-error-schema-audit-01']))
for label in labels:
 for name in ['stdout','stderr','receipt.json','preflight.json']:
  f=b/'checks'/label/name
  if f.is_file():retain(f,label+'--'+name)
for name in ['approve_up05_amendment001.py','refine_up05_boundaries.py','commit_up05_product.py','run_up05_profile.py','up05-profile-freeze.json','check_up05_supplements.py','compare_up05_checks.py','up05-verification-comparison.json','rehash_up05_before.py','rehash_up05_after.py','up05-library-before.json','up05-library-after.json','replan_up05_modern_schema.py','check_up05_wire_error_shape.py']:
 retain(b/name,name)
# Only original safe outputs/controllers; no HOME/TMP/runtime stores or certificate keys.
dump(e/'amendment002-artifacts-manifest.json',{'artifacts':entries,'excluded':'Private TLS keys, fixture runtime/counters/HOME/TMP stores, caches and provider environment are not archived'})
comparison=json.loads((b/'up05-verification-comparison.json').read_text());dump(e/'verification-before-amendment002.json',comparison)
checkpoint={'status':'Unreviewed draft; construction stopped on normative/authority conflict','product_candidate':head,'product_hashes':{x['path']:h(w/x['path']) for x in a['product_paths']},'amended_authority_sha256':h(p/'authority-UP-05-amendment-001.json'),'frozen_profile_sha256':h(b/'up05-profile-freeze.json'),'schema_audit_exit':json.loads((b/'checks/up05-wire-error-schema-audit-01/receipt.json').read_text())['exit_code'],'known_conflict':'UnsupportedProtocolVersionError requires data.supported and data.requested; original contract prescribes only supportedVersions','planning_error':'Historical selected schema was2025 because a variable was overwritten; retain immutable original plan but it cannot establish2026 field coverage','corrected_plan_sha256':h(replan),'no_product_edits_after_conflict_discovery':True,'no_VERIFIED_or_acceptance':True,'formal_remediation_cycles':0,'created_utc':datetime.now(timezone.utc).isoformat()};dump(e/'amendment002-construction-checkpoint.json',checkpoint)
text='''# AMEND-MCP-UP-005-002: correct modern schema plan and version-error data

Status: Proposed; exact maintainer approval is required before construction resumes.
Parent: CD-MCP-UP-005 plus approved AMEND-MCP-UP-005-001.
Current unreviewed product: `ed8f8cbdc27b469b389487dd931678b4777b13b9`.

## Confirmed conflict and cause

The approved up05-server-contract.md line57 prescribes
“UnsupportedProtocolVersion -32022 with only supportedVersions safe data.”
The pinned2026 TypeScript schema instead requires
`UnsupportedProtocolVersionError.error.data.supported: string[]` and
`requested: string` (schema lines494/498). `DiscoverResult.supportedVersions`
is a different field and remains correct for discovery.

Normative schema SHA256:
`742750af0bb8c716e7030c4977c992b55d1adc4407e9e66997db5846baedc2cd`,
upstream `271ecc9accafdd9b83a3c869fa67c22953b2af80`.
The retained guarded live-wire audit returns exit1: actual error data has only
supportedVersions; required data is supported/requested. The ordinary SDK error
wrapper checks a generic JSON-RPC error, so a passing SDK call does not validate
this particular error variant. No handler runs in this failing audit.

The controller also found a planning defect: plan_up05_requirements.py replaced
its schema variable with the later captured2025 schema. The previously reported
145 declarations/355 fields described2025, not2026. All19 captures were retained,
but that field plan did not fulfill the required modern preconstruction mapping.
It remains immutable historical evidence and cannot establish2026 conformance.
The new explicit SHA-selected prospective plan parses both schemas separately:
2026 has155 declarations/337 field references;2025 has145/355 and is historical
client-compatibility evidence only. Counts describe parsing, not passed assertions.

## Exact proposed correction and prospective rebaseline

1. Supersede only the version-error data instruction: emit error code-32022
   with fixed safe message and data exactly
   `{"supported": ["2026-07-28"], "requested": <this request's protocolVersion>}`.
   Bound/validate the requested version string using the existing individual
   identity budget before use. Echo it only in that request's required wire
   error data. Do not log it, label telemetry with it or expose other metadata,
   headers, arguments, credentials or exception details. Discovery continues
   to use supportedVersions; HeaderMismatch stays-32020 and HTTP400.
2. Recognize the historical preconstruction-plan failure explicitly rather than
   backdating a replacement. Approve prospective-modern-schema-replan.json as
   the new pre-edit plan for the remaining construction phase. Rebaseline the
   current unreviewed18-path draft, re-audit every source module against the
   actual2026 schema and every applicable captured modern clause, then complete
   a field/variant/source/test/command mapping before formal review. No original
   incorrect field-plan artifact or approval/control bytes are rewritten.
3. Within existing scope, correct any dependent-field omissions found by that
   audit. Already identified: requestState must be validated or explicitly refused
   under the unsupported interactive-state role, and emitted text/result MetaObject
   reserved trace fields must be format-validated. MissingRequiredClientCapability
   requires requiredCapabilities if that error is ever emitted; this tools-only
   profile activates no such role and must not emit a malformed reserved variant.
   These are enforcement of the existing complete-field criteria, not optional
   feature expansion, a new provider, a new path, or a checker waiver.

## Product budget, regression proof and gates

The original18 product paths,12 criteria,20 required checks, metadata/dependency
pins, private library environment and guarded fixture permissions remain intact.
Affected existing scoped locations include server/protocol.py, modern.py, HTTP/
stdio error plumbing as needed, the existing new server tests and server guide.
No accepted client/Core/Runtime/Chat/telemetry/config/legacy source may change.
AMEND001's required ttlMs0/private discovery/list behavior remains approved.
No cache engine, optional callbacks, interactive state, Tasks, subscriptions,
OAuth implementation, Langfuse, later unit or remote publication is authorized.

Positive and negative proof must distinguish discovery supportedVersions from
unsupported-version supported/requested, test missing/null/malformed dependent
fields, exact HTTP400 versus header/method errors, zero handler admission,
owner-local data and diagnostic/telemetry privacy. Validate every emitted error
variant against its pinned fields rather than merely its generic code. Actual
SDK stdio/TLS JSON/SSE and raw negatives remain mandatory. Re-audit complete
modern-role fields, retain each failure and repeat the entire20-check profile
with supplemental column/debt/skip/warning/library comparisons on the corrected
stable candidate. A fresh read-only full-unit validator is required before any
completion proposal; maintainer acceptance remains separate.

## Evidence already available, with its limits

All20 original commands completed against the unchanged draft product candidate:
381 focused tests and5125 repository tests passed; accepted baseline4744 passed.
Both runs have identical14 skip locations/reasons and complete15-warning sections.
All changed Python files are Ruff clean, all7 touched source files and the MCP
package pass Mypy. Full Ruff retains the exact327 inherited diagnostic/fix
objects; full Mypy retains the exact four inherited path/line/column/code/message
objects. Before/after all22,009 private library files/192 distributions match,
as do19 metadata and60 accepted product hashes. Raw nonzero inherited-debt exits
and the failing version-error schema audit are retained without rewriting.

Those checks do not cure the schema/authority contradiction or the historical
planning failure, and are not an independent VERIFIED result. No formal validator
finding or remediation cycle has been consumed. The complete original outputs,
controllers, freeze and comparisons are archived by amendment002-artifacts-manifest.json.

## Approval gate

Approve this exact correction and prospective rebaseline before further product
edits. The frozen contract stop rule and AGENTS.md reconciliation requirement are
why approval is needed. This amendment does not waive typing, engineering policy,
full conformance evidence, independent review or acceptance. A later review may
still identify source findings; they follow the existing bounded remediation rules.
'''
af=p/'amendments/AMEND-MCP-UP-005-002-modern-schema-and-version-errors.md';af.write_text(text)
proposal={'initiative':'friday-mcp-protocol-upgrade','work_unit':'MCP-UP-05','amendment':'AMEND-MCP-UP-005-002','status':'proposed','implementation_authority':'not_granted_for_amendment','parent_authority':{'path':str((p/'authority-UP-05-amendment-001.json').relative_to(w)),'sha256':h(p/'authority-UP-05-amendment-001.json')},'amendment_document':{'path':str(af.relative_to(w)),'sha256':h(af)},'corrected_prospective_plan':{'path':str(replan.relative_to(w)),'sha256':h(replan)},'checkpoint':{'path':str((e/'amendment002-construction-checkpoint.json').relative_to(w)),'sha256':h(e/'amendment002-construction-checkpoint.json')},'normative_schema_sha256':plan['controlling_server_schema_sha256'],'existing_unreviewed_product_candidate':head,'override':'Unsupported version error data uses required supported/requested; bounded requested protocolVersion only in own wire error. Explicit prospective rebaseline replaces invalid historical2025-selected field plan for further construction; audit all modern fields before fresh review. AMEND001 and original other requirements remain.','product_paths':a['product_paths'],'acceptance_criteria':a['acceptance_criteria'],'required_checks':a['required_checks'],'permitted_effects':a['permitted_effects'],'prior_incorrect_plan_retained':plan['invalid_prior_plan'],'later_unit_or_delivery_authority':'not granted'};dump(p/'proposals/UP-05-amendment-002-authority-manifest.json',proposal)
sf=p/'execution/current-process-state.json';s=json.loads(sf.read_text());s.update(execution_phase='planning',validation_state='not_ready',unit_completion='not proposed; UP-05 draft stopped for schema/authority reconciliation',builder_product_candidate=head,pending_amendment=str(af.relative_to(w)),construction_stop='authority_conflict_and_invalid_historical_field_plan',next_gate='Maintainer approval of exact AMEND-MCP-UP-005-002 version-error data and prospective2026 schema rebaseline before construction resumes',note='AMEND001 applied and all20 builder checks compared; no source edits after second conflict discovery; full field conformance/independent review not yet established');dump(sf,s)
log=p/'execution-log.md';log.write_text(log.read_text()+'''\n\n## 2026-10-13 - UP-05 draft verification and corrected-schema stop\n\nAMEND001 metadata was implemented within all18 scoped product paths. Stable\ndraft product ed8f8cbdc27b469b389487dd931678b4777b13b9 passed381 focused tests,\n5125 root tests and all clean touched/MCP typing and lint checks. All20 commands\ncompleted; baseline4744/14/15, candidate5125/14/15, full327 Ruff diagnostic/fix\nobjects and four Mypy diagnostics including columns match exactly. Both before\nand after22,009 libraries/192 distributions,19 metadata and60 protected products\nmatch. Raw commands, inherited-debt exits and comparisons are retained.\n\nDuring final schema audit the controller found a second immutable-contract\nconflict: UnsupportedProtocolVersionError requires supported/requested data,\nnot the contract's supportedVersions. A guarded actual-wire audit fails with\nzero handlers/owners. Product edits stopped at discovery. The controller found\nthe cause of missed fields: the preconstruction script overwrote the selected\nmodern schema with a later2025 capture. Its145/355 field counts are historical\n2025 evidence only and do not fulfill modern preconstruction coverage. All\noriginal bytes remain unchanged. An explicit SHA-selected prospective plan now\nparses2026 separately (155 declarations/337 field references), with19 source\ncaptures checked and2025 isolated as historical compatibility evidence.\n\nProposed AMEND-MCP-UP-005-002 corrects version-error data and explicitly\nrebaselines the unreviewed draft for a complete modern field audit before\nfurther construction. RequestState and emitted MetaObject format omissions\nremain to be enforced under existing complete-field criteria. No VERIFIED,\ncompletion, acceptance, formal remediation cycle or publication is claimed.\nAMEND001 remains approved; original18 paths/12 criteria/20 checks/private\neffects and every accepted older unit are protected. Next gate is exact\namendment002 approval, then corrected construction/full profile/fresh review.\n''')
spec=importlib.util.spec_from_file_location('board',w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);board=m.load_board(w);task=next(t for t in board['tasks'] if t['id']=='friday-mcp-protocol-upgrade');task['next_gate']=s['next_gate'];m._append_event(board,task_id=task['id'],actor='Codex',actor_role='agent',action='prepared exact UP-05 schema and version-error amendment',note='Draft profile completed; frozen error-data conflict and invalid historical schema selection prevent conformance. Exact prospective rebaseline proposed; source edits stopped, local only',evidence=str(af.relative_to(w)));m._save_board_and_dashboard(board,w)
paths=[str(f.relative_to(w)) for f in [af,p/'proposals/UP-05-amendment-002-authority-manifest.json',replan,e/'amendment002-artifacts-manifest.json',e/'verification-before-amendment002.json',e/'amendment002-construction-checkpoint.json',sf,log]]+[str(f.relative_to(w)) for f in art.iterdir()]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','commit','-m','Retain MCP server draft checks and propose corrected modern-schema rebaseline'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip())
