"""Public modern-server wire contract: positive and malformed field variants."""
import asyncio
import json
from dataclasses import fields

import pytest

from friday_mcp.server import ModernToolsMCPServer, RegisteredTool, ServerLimits, ToolCallResult
from friday_mcp.server.protocol import PREFIX, VERSION, ServerRequest, ServerWireError, encode


def rpc(method="server/discover", *, params=None, rid=1, meta=None):
    return json.dumps({"jsonrpc": "2.0", "id": rid, "method": method, "params": {"_meta": meta if meta is not None else {PREFIX + "protocolVersion": VERSION, PREFIX + "clientCapabilities": {}}, **(params or {})}}, ensure_ascii=False).encode()


async def echo(args):
    return ToolCallResult.structured(args)


def definition(name="echo", **extra):
    return {"name": name, "description": "Synthetic echo", "inputSchema": {"type": "object"}, **extra}


@pytest.mark.asyncio
async def test_discovery_empty_and_direct_call_no_session():
    server = ModernToolsMCPServer()
    result = (await server.handle(rpc()))["result"]
    assert result == {"resultType": "complete", "supportedVersions": [VERSION], "capabilities": {"tools": {}}, "_meta": {PREFIX + "serverInfo": {"name": "FridayModernTools", "version": "1.0.0"}}}
    assert (await server.handle(rpc("tools/list")))["result"]["tools"] == []
    server.register_tool(definition(), echo)
    assert (await server.handle(rpc("tools/call", params={"name": "echo", "arguments": {"x": 1}})))["result"]["structuredContent"] == {"x": 1}
    await server.stop()


@pytest.mark.asyncio
@pytest.mark.parametrize("raw,code", [(b"{", -32700), (b'{}', -32600), (b'[]', -32600), (b'[{"jsonrpc":"2.0"}]', -32600), (b'{"jsonrpc":"2.0","id":1,"result":{}}', -32600), (b'{"jsonrpc":"2.0","method":"x","method":"y"}', -32700), (b'\xff', -32700)])
async def test_envelope_rejects_without_handlers(raw, code):
    server = ModernToolsMCPServer()
    result = await server.handle(raw)
    assert result["error"]["code"] == code
    assert "id" not in result
    assert server.active_requests == 0


@pytest.mark.asyncio
@pytest.mark.parametrize("rid", [None, True, False, 1.5, [], {}, 2**54, "x" * 257])
async def test_invalid_id_has_no_echo(rid):
    result = await ModernToolsMCPServer().handle(rpc(rid=rid))
    assert result["error"]["code"] == -32600
    assert "id" not in result


@pytest.mark.asyncio
@pytest.mark.parametrize("rid", [0, -1, 2**53 - 1, "", "unicode-世界"])
async def test_valid_ids_echo_only_own_request(rid):
    assert (await ModernToolsMCPServer().handle(rpc(rid=rid)))["id"] == rid


@pytest.mark.asyncio
@pytest.mark.parametrize("key", [PREFIX + "protocolVersion", PREFIX + "clientCapabilities"])
@pytest.mark.parametrize("value", [None, False, 1, [], "bad"])
async def test_required_meta_types(key, value):
    meta = {PREFIX + "protocolVersion": VERSION, PREFIX + "clientCapabilities": {}}
    meta[key] = value
    result = await ModernToolsMCPServer().handle(rpc(meta=meta))
    assert result["error"]["code"] == (-32022 if key.endswith("protocolVersion") and isinstance(value, str) else -32602)
    assert result["id"] == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("key", [PREFIX + "protocolVersion", PREFIX + "clientCapabilities"])
async def test_required_meta_omission(key):
    meta = {PREFIX + "protocolVersion": VERSION, PREFIX + "clientCapabilities": {}}
    del meta[key]
    assert (await ModernToolsMCPServer().handle(rpc(meta=meta)))["error"]["code"] == -32602


@pytest.mark.asyncio
@pytest.mark.parametrize("info", [None, {}, {"name": "x"}, {"version": "x"}, {"name": 3, "version": "x"}, {"name": "x", "version": "x", "title": None}, {"name": "x", "version": "x", "icons": None}, {"name": "x", "version": "x", "icons": [{"src": "x", "theme": "wrong"}]}])
async def test_optional_implementation_malformed(info):
    assert (await ModernToolsMCPServer().handle(rpc(meta={PREFIX + "protocolVersion": VERSION, PREFIX + "clientCapabilities": {}, PREFIX + "clientInfo": info})))["error"]["code"] == -32602


@pytest.mark.asyncio
async def test_optional_implementation_full_fields_unknown_extensions_and_per_request_caps():
    server = ModernToolsMCPServer()
    meta = {PREFIX + "protocolVersion": VERSION, PREFIX + "clientCapabilities": {"sampling": {"context": {}, "tools": {}}, "roots": {}, "elicitation": {"form": {}, "url": {}}, "experimental": {"x": {}}, "extensions": {"example.org/test": {}}}, PREFIX + "clientInfo": {"name": "synthetic", "version": "1", "title": "Title", "description": "Description", "websiteUrl": "https://example.invalid", "icons": [{"src": "data:image/png;base64,AA==", "mimeType": "image/png", "sizes": ["any"], "theme": "light"}]}, "example.org/trace": {"secret": "sentinel"}, "progressToken": 2, PREFIX + "logLevel": "info"}
    assert "result" in await server.handle(rpc(meta=meta))
    assert "result" in await server.handle(rpc())
    meta.pop(PREFIX + "clientCapabilities")
    assert (await server.handle(rpc(meta=meta)))["error"]["code"] == -32602
    assert "sentinel" not in str(server.tools)


@pytest.mark.asyncio
@pytest.mark.parametrize("cap", ["sampling", "roots", "elicitation", "experimental", "extensions"])
@pytest.mark.parametrize("value", [None, True, [], "bad"])
async def test_capability_variants(cap, value):
    assert (await ModernToolsMCPServer().handle(rpc(meta={PREFIX + "protocolVersion": VERSION, PREFIX + "clientCapabilities": {cap: value}})))["error"]["code"] == -32602


@pytest.mark.asyncio
@pytest.mark.parametrize("method", ["initialize", "resources/list", "prompts/list", "subscriptions/listen", "tasks/get", "logging/setLevel", "ping", "unknown"])
async def test_unsupported_methods_exact_wire_code(method):
    result = await ModernToolsMCPServer().handle(rpc(method))
    assert result == {"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}


@pytest.mark.asyncio
async def test_unsupported_version_safe_data():
    result = await ModernToolsMCPServer().handle(rpc(meta={PREFIX + "protocolVersion": "2025-11-25", PREFIX + "clientCapabilities": {}}))
    assert result["error"] == {"code": -32022, "message": "Unsupported protocol version", "data": {"supportedVersions": [VERSION]}}


@pytest.mark.asyncio
async def test_catalog_atomic_deep_snapshots_and_stale_cursors():
    server = ModernToolsMCPServer(limits=ServerLimits(page_tools=1))
    original = definition("a")
    server.register_tool(original, echo)
    original["description"] = "mutated"
    server.register_tool(definition("b"), echo)
    first = (await server.handle(rpc("tools/list")))["result"]
    assert first["tools"][0]["description"] == "Synthetic echo"
    cursor = first["nextCursor"]
    assert (await server.handle(rpc("tools/list", params={"cursor": cursor})))["result"]["tools"][0]["name"] == "b"
    export = server.tools
    export[0]["inputSchema"]["bad"] = True
    assert "bad" not in server.tools[0]["inputSchema"]
    with pytest.raises(ValueError, match="collision"):
        server.replace_tools([RegisteredTool.from_definition(definition("a"), echo)] * 2)
    assert len(server.tools) == 2
    server.remove_tool("b")
    for invalid in (cursor, "forged", "", None, 1, "x" * 257):
        assert (await server.handle(rpc("tools/list", params={"cursor": invalid})))["error"]["code"] == -32602


@pytest.mark.asyncio
async def test_pagination_byte_partition_and_incompatible_limits_are_atomic():
    server = ModernToolsMCPServer(limits=ServerLimits(result_bytes=1500))
    server.replace_tools(RegisteredTool.from_definition(definition(str(i), description="世界" * 100), echo) for i in range(5))
    cursor = None
    names = []
    while True:
        response = await server.handle(rpc("tools/list", params={} if cursor is None else {"cursor": cursor}))
        assert len(encode(response, server.limits)) <= 1500
        names += [t["name"] for t in response["result"]["tools"]]
        cursor = response["result"].get("nextCursor")
        if cursor is None:
            break
    assert names == list(map(str, range(5)))
    before = server.tools
    with pytest.raises((ValueError, ServerWireError)):
        server.register_tool(definition("large", description="x" * 2000), echo)
    assert server.tools == before
    with pytest.raises(ValueError):
        ModernToolsMCPServer(limits=ServerLimits(result_bytes=1))


@pytest.mark.parametrize("schema", [{"type": "object", "$ref": "https://example.invalid"}, {"type": "object", "$ref": "#"}, {"type": "object", "patternProperties": {"(a+)+$": {}}}, {"type": "object", "oneOf": [{}, {}]}, {"type": "object", "properties": {"x": {"type": "string", "pattern": "(a+)+$"}}}, {"type": "object", "$schema": "draft07"}, {"type": "object", "properties": {"x": {"type": "number", "x-mcp-header": "X"}}}, {"type": "object", "items": {"type": "string", "x-mcp-header": "X"}}, {"type": "object", "properties": {"x": {"type": "string", "x-mcp-header": "X"}, "y": {"type": "string", "x-mcp-header": "x"}}}])
def test_unsupported_schema_rejected_without_registration(schema):
    server = ModernToolsMCPServer()
    with pytest.raises((ValueError, ServerWireError)):
        server.register_tool(definition(inputSchema=schema), echo)
    assert server.tools == ()


def test_sync_handler_rejected():
    with pytest.raises(ValueError, match="async"):
        ModernToolsMCPServer().register_tool(definition(), lambda args: ToolCallResult.text("bad"))


@pytest.mark.asyncio
async def test_argument_validation_zero_invocations_and_fixed_failure_privacy():
    calls = []
    async def handler(args):
        calls.append(args)
        raise RuntimeError("secret-peer-token")
    server = ModernToolsMCPServer()
    server.register_tool(definition(inputSchema={"type": "object", "properties": {"x": {"type": "integer", "minimum": 1}}, "required": ["x"], "additionalProperties": False}), handler)
    for args in (None, [], {}, {"x": True}, {"x": 0}, {"x": 1, "extra": "secret"}):
        assert (await server.handle(rpc("tools/call", params={"name": "echo", "arguments": args})))["error"]["code"] == -32602
    assert not calls
    response = await server.handle(rpc("tools/call", params={"name": "echo", "arguments": {"x": 1}}))
    assert len(calls) == 1 and response["result"]["isError"] is True
    assert "secret-peer-token" not in str(response)


@pytest.mark.asyncio
@pytest.mark.parametrize("value", [None, True, 0, 1.5, "世界", [1, None], {"x": 1}])
async def test_structured_arbitrary_json_and_explicit_null(value):
    async def handler(args):
        return ToolCallResult.structured(value, texts=("first", "second"))
    server = ModernToolsMCPServer()
    server.register_tool(definition(), handler)
    result = (await server.handle(rpc("tools/call", params={"name": "echo"})))["result"]
    assert result["structuredContent"] == value
    assert [b["text"] for b in result["content"]] == ["first", "second"]
    assert "structuredContent" not in ToolCallResult.text("text").value()


@pytest.mark.asyncio
async def test_captured_output_schema_during_replacement():
    held = asyncio.Event()
    release = asyncio.Event()
    async def handler(args):
        held.set()
        await release.wait()
        return ToolCallResult.structured(5)
    server = ModernToolsMCPServer()
    server.register_tool(definition(outputSchema={"type": "integer"}), handler)
    issued = asyncio.create_task(server.handle(rpc("tools/call", params={"name": "echo"})))
    await held.wait()
    server.replace_tools([RegisteredTool.from_definition(definition(outputSchema={"type": "string"}), echo)])
    release.set()
    assert (await issued)["result"]["structuredContent"] == 5


@pytest.mark.asyncio
@pytest.mark.parametrize("returned", [ToolCallResult.text("missing"), ToolCallResult.structured("wrong"), ToolCallResult(b'{"content":[{"type":"image","data":"AA==","mimeType":"image/png"}]}'), ToolCallResult(b'{"content":null}'), "wrong"])
async def test_malformed_or_schema_invalid_result_fixed_error(returned):
    calls = 0
    async def handler(args):
        nonlocal calls
        calls += 1
        return returned
    server = ModernToolsMCPServer()
    server.register_tool(definition(outputSchema={"type": "integer"}), handler)
    assert (await server.handle(rpc("tools/call", params={"name": "echo"})))["error"]["code"] == -32603
    assert calls == 1


@pytest.mark.asyncio
async def test_legitimate_tool_error_skips_success_schema_and_oversize_actual_wire():
    async def handler(args):
        return ToolCallResult.text("failure", is_error=True)
    server = ModernToolsMCPServer()
    server.register_tool(definition(outputSchema={"type": "integer"}), handler)
    assert (await server.handle(rpc("tools/call", params={"name": "echo"})))["result"]["isError"] is True
    async def oversized(args):
        return ToolCallResult.text("界" * 21800)
    server.replace_tools([RegisteredTool.from_definition(definition(), oversized)])
    assert (await server.handle(rpc("tools/call", params={"name": "echo"})))["error"]["code"] == -32603


@pytest.mark.parametrize("name", [f.name for f in fields(ServerLimits)])
@pytest.mark.parametrize("value", [True, False, 0, -1, float("inf"), float("nan")])
def test_lower_only_limits_invalid_values(name, value):
    with pytest.raises(ValueError):
        ServerLimits(**{name: value})


@pytest.mark.parametrize("name", [f.name for f in fields(ServerLimits)])
def test_limits_cannot_increase(name):
    with pytest.raises(ValueError):
        ServerLimits(**{name: getattr(ServerLimits(), name) + 1})


@pytest.mark.parametrize("meta", [None, [], {PREFIX + "subscriptionId": None}, {PREFIX + "subscriptionId": True}])
def test_notification_meta_separate_grammar(meta):
    raw = json.dumps({"jsonrpc": "2.0", "method": "notifications/cancelled", "params": {"requestId": 1, "_meta": meta}}).encode()
    with pytest.raises(ServerWireError):
        ServerRequest.parse(raw, ServerLimits())


def test_notification_valid_without_request_metadata():
    for params in ({"requestId": 1}, {"requestId": "a", "reason": "ignored", "_meta": {PREFIX + "subscriptionId": 2}}):
        request = ServerRequest.parse(json.dumps({"jsonrpc": "2.0", "method": "notifications/cancelled", "params": params}).encode(), ServerLimits())
        assert request.request_id is None
