from pathlib import Path
import json,gzip,re,hashlib,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';out=p/'execution/up05';out.mkdir(exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def route(url,text):
 if '/2025-' in url:return ('excluded','Retained client compatibility capture; modern server supports only2026; legacy unchanged','test_legacy_compatibility.py','SRV-AC-09')
 if '/authorization' in url:return ('conditional_exclusion','Administrative supplied bearer gate is not optional delegated OAuth; conditional OAuth roles are deferred with authorization SHOULD tradeoff documented','test_server_security.py','SRV-AC-06')
 if '/tasks' in url:return ('excluded','No Tasks capability or Tasks results/RPC; reject unsupported methods and never advertise Tasks','test_modern_protocol.py','SRV-AC-01')
 if '/streamable-http' in url:return ('applicable_or_conditional','POST JSON/SSE server role; client-only forwarding/fallback and unsupported subscription/MRTR roles must remain explicit exclusions','test_streamable_http.py','SRV-AC-05')
 if '/stdio' in url:return ('applicable_or_conditional','Concurrent newline stdio; client fallback and unsupported server subscription cancellation excluded','test_modern_stdio.py','SRV-AC-04')
 if '/tools' in url:return ('applicable_or_conditional','Explicit tools-only schema/catalog/result/access implementation; media/resources and client UI duties excluded','test_modern_protocol.py','SRV-AC-02')
 if '/mrtr' in url:return ('conditional_exclusion','No input requests emitted or inputResponses accepted; no callbacks or capability inference','test_modern_protocol.py','SRV-AC-01')
 return ('applicable_or_conditional','Complete envelope/version/metadata/discovery, bounded extension objects; no optional roles advertised','test_modern_protocol.py','SRV-AC-01')
clauses=[];sources=[];schema=None
for manifest in ['research-sources/manifest.json','research-sources/up02b/manifest.json','research-sources/up04/manifest.json']:
 mf=p/manifest
 for s in json.loads(mf.read_text())['sources']:
  raw=gzip.decompress((mf.parent/s['artifact']).read_bytes())
  if sha(raw)!=s['sha256']:raise RuntimeError('Capture drift')
  text=raw.decode();sources.append({'url':s['url'],'sha256':sha(raw),'bytes':len(raw)})
  if s['url'].endswith('schema.ts'):schema=(s,text);continue
  for match in re.finditer(r'(?ms)(?:^|(?<=\n\n))([^\n].*?)(?=\n\s*\n|\Z)',text):
   para=match.group(1);tokens=re.findall(r'\b(?:MUST(?: NOT)?|SHOULD(?: NOT)?|SHALL(?: NOT)?|REQUIRED|RECOMMENDED)\b',para)
   if not tokens:continue
   disposition,reason,test,ac=route(s['url'],para)
   # Distinguish duties clearly conditional on unsupported roles instead of carrying client exclusions blindly.
   if re.search(r'\b(?:subscription|input_required|inputRequests|sampling|elicitation)\b',para,re.I) and 'MUST NOT' not in tokens:
    reason+='; conditional optional-role clauses do not activate'
   clauses.append({'id':f'SRV-CLAUSE-{len(clauses)+1:04}','source':s['url'],'sha256':sha(raw),'line':text[:match.start(1)].count('\n')+1,'paragraph':para,'tokens':tokens,'disposition':disposition,'reason':reason,'planned_test':test,'criterion':ac,'variants':['valid present','malformed type/value','omitted mandatory versus optional','explicit null versus omitted'],'command':'server-focused'})
if schema is None:raise RuntimeError('Missing schema')
s,text=schema;declarations=[]
active={'MetaObject','RequestMetaObject','NotificationMetaObject','ResultMetaObject','ProgressToken','Cursor','RequestParams','Request','NotificationParams','Notification','ResultType','Result','Error','RequestId','JSONRPCRequest','JSONRPCNotification','JSONRPCResultResponse','JSONRPCErrorResponse','JSONRPCResponse','ParseError','InvalidRequestError','MethodNotFoundError','InvalidParamsError','InternalError','HeaderMismatchError','UnsupportedProtocolVersionError','MissingRequiredClientCapabilityError','EmptyResult','CancelledNotificationParams','CancelledNotification','DiscoverRequest','DiscoverResult','DiscoverResultResponse','ClientCapabilities','ServerCapabilities','Icon','Icons','BaseMetadata','Implementation','PaginatedRequestParams','PaginatedRequest','PaginatedResult','CacheableResult','ListToolsRequest','ListToolsResult','ListToolsResultResponse','CallToolResult','CallToolResultResponse','CallToolRequestParams','CallToolRequest','ToolAnnotations','Tool','Annotations','TextContent','ContentBlock','InputResponseRequestParams','JSONValue','JSONObject','JSONArray','ClientRequest','ClientNotification','ClientResult','ServerNotification','ServerResult'}
for m in re.finditer(r'^export (interface|type) (\w+)',text,re.M):
 name=m.group(2);following=re.search(r'^export (?:interface|type) ',text[m.end():],re.M);end=m.end()+following.start() if following else len(text);chunk=text[m.start():end]
 # Preserve whole declaration including comments and dependent nested fields; no selected-field-only proof.
 fields=[{'line':text[:m.start()+fm.start()].count('\n')+1,'declaration':fm.group(0).strip(),'variants':['valid','malformed','omitted','null']} for fm in re.finditer(r'^\s*(?:"[^"]+"|[A-Za-z_$][\w$]*)(?:\?)?:[^\n]*',chunk,re.M)]
 declarations.append({'name':name,'line':text[:m.start()].count('\n')+1,'complete_declaration':chunk,'fields':fields,'disposition':'server_boundary' if name in active else 'unsupported_role','reason':'Complete dated envelope/metadata/tools/discovery/cancellation and dependent fields; role-specific optional content/capability inputs validated or excluded from emission' if name in active else 'No resources/prompts/sampling/roots/elicitation/completion/subscriptions/media server APIs; no unsupported advertised capability','planned_tests':['test_modern_protocol.py','test_streamable_http.py','test_server_security.py','test_server_lifecycle.py'],'command':'server-focused'})
plan={'status':'Frozen preconstruction plan; planned assertions are not conformance evidence','source_count':len(sources),'sources':sources,'clauses':clauses,'schema_source':s,'schema_declarations':declarations,'counts':{'paragraphs':len(clauses),'keywords':sum(len(c['tokens']) for c in clauses),'declarations':len(declarations),'fields':sum(len(d['fields']) for d in declarations)},'approval_sha256':sha((p/'approval-UP-05.json').read_bytes()),'authority_sha256':sha((p/'authority-UP-05.json').read_bytes()),'note':'Every source parsed completely. Final actual mapping must resolve each applicable clause/field and document conditional SHOULD decisions explicitly; earlier client-only role exclusions are not imported as server evidence.'}
f=out/'preconstruction-requirement-plan.json';f.write_text(json.dumps(plan,indent=2)+'\n')
state=p/'execution/current-process-state.json';j=json.loads(state.read_text());j['unit_completion']='not proposed; approved UP-05 construction underway';j['note']='Exact CD-MCP-UP-005 approved; server-role requirement plan frozen before source edits';state.write_text(json.dumps(j,indent=2)+'\n')
subprocess.run(['git','add','--',str(f.relative_to(w)),str(state.relative_to(w))],cwd=w,check=True);subprocess.run(['git','commit','-m','Freeze complete MCP tools-server clause and schema construction plan'],cwd=w,check=True,stdout=subprocess.DEVNULL)
print(json.dumps(plan['counts']))
