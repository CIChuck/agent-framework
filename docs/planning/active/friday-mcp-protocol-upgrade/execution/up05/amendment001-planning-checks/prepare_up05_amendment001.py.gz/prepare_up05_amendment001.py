from pathlib import Path
import json,hashlib,gzip,subprocess,importlib.util
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';e=p/'execution/up05';a=p/'amendments';a.mkdir(exist_ok=True)
def h(path):return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
def dump(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
authority=json.loads((p/'authority-UP-05.json').read_text())
for entry in authority['controls']+authority['prior_frozen_manifests']:
 if h(w/entry['path'])!=entry['sha256']:raise RuntimeError('Control drift')
for name in ['metadata_hashes','preserved_product_hashes']:
 for path,digest in authority[name].items():
  if h(w/path)!=digest:raise RuntimeError('Preserved content drift')
art=e/'construction-artifacts';art.mkdir(exist_ok=True);entries=[]
def retain(path,name):
 raw=path.read_bytes();dest=art/(name+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0));entries.append({'artifact':str(dest.relative_to(p)),'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'artifact_sha256':h(dest),'provenance':str(path)})
checks=['up05-approved-board','up05-approved-next','up05-approved-show','up05-approved-docs','up05-approved-render','up05-dev-source-mypy-01','up05-dev-source-mypy-02','up05-dev-protocol-01','up05-dev-http-01','up05-dev-security-lifecycle-01','up05-dev-stdio-registry-01','up05-dev-sdk-01']
results=[]
for label in checks:
 check=b/'checks'/label
 if not (check/'receipt.json').exists():raise RuntimeError('Incomplete check '+label)
 receipt=json.loads((check/'receipt.json').read_text());results.append({'label':label,'exit_code':receipt['exit_code'],'argv':receipt['argv']})
 for file in ['stdout','stderr','receipt.json','preflight.json']:
  if (check/file).is_file():retain(check/file,label+'--'+file)
for entry in authority['product_paths']:
 path=w/entry['path']
 if path.is_file() and h(path)!=entry['baseline_sha256']:retain(path,'partial-product--'+entry['path'].replace('/','--'))
retain(b/'approve_up05.py','approval-controller.py');retain(b/'plan_up05_requirements.py','preconstruction-controller.py')
schema=b/'up05-normative-sources/modelcontextprotocol--modelcontextprotocol--main--schema--2026-07-28--schema.ts'
sdk=b/'venv/lib/python3.13/site-packages/mcp_types/_v2026_07_28/__init__.py'
retain(sdk,'official-sdk-230-dated-wire-models.py')
checkpoint={'status':'Incomplete construction; no stable candidate, full profile or independent review','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'product_paths':[{**x,'current_sha256':h(w/x['path'])} for x in authority['product_paths']],'checks':results,'blocking_conflict':'up05-server-contract.md forbids cache TTL/cacheScope, but pinned TypeScript CacheableResult requires ttlMs/cacheScope and DiscoverResult/ListToolsResult inherit it; official SDK dated wire decoder rejects missing fields','additional_observation':'TLS fixture child SIGTERM returns -15 because public Uvicorn serve restores/re-raises captured signal; successful cleanup/exit assertions still require routine fixture correction under existing scope. No child remains alive. No checker/library change is proposed.','formal_remediation_cycles':0,'source_sha256':h(schema),'sdk_dated_wire_model_sha256':h(sdk),'scope_integrity':{'metadata19':True,'preserved_products60':True},'created_utc':datetime.now(timezone.utc).isoformat()};dump(e/'construction-checkpoint.json',checkpoint);dump(e/'construction-artifacts-manifest.json',{'artifacts':entries,'runtime_private_keys_and_homes':'excluded'})
text='''# AMEND-MCP-UP-005-001: required immediately stale cache metadata

Status: Proposed; not approved. Construction stopped at this authority conflict.
Parent: approved CD-MCP-UP-005 and immutable authority-UP-05.json.

## Concrete conflict and normative basis

The approved up05-server-contract.md says “No caching TTL/cacheScope is supplied
in this profile” and “Never advertise ... subscriptions/caching/logging”. The
pinned complete TypeScript schema at upstream
`271ecc9accafdd9b83a3c869fa67c22953b2af80` instead requires
`CacheableResult.ttlMs: number` and `cacheScope: "public" | "private"`.
`DiscoverResult` and `ListToolsResult` inherit CacheableResult. The source
SHA256 is `742750af0bb8c716e7030c4977c992b55d1adc4407e9e66997db5846baedc2cd`;
CacheableResult is at lines1081–1110, DiscoverResult at678 and
ListToolsResult at1779. These are already captured approved inputs, not a
new spec revision or new dependency.

The actual official SDK2.3.0 Client against Friday subprocess stdio and private
verified TLS JSON/SSE rejects tool-list results: dated ListToolsResult requires
both cacheScope and ttlMs. The internal SDK convenience model defaults do not
make these wire fields optional. Raw failed attempts, actual SDK wire-model
bytes, controller scripts and incomplete product snapshot are retained in
execution/up05/construction-artifacts-manifest.json and construction-checkpoint.json.
No stable candidate or VERIFIED result exists. This is an authority correction,
not a formal validator finding or a consumed remediation cycle.

## Exact proposed override

Supersede only the cache-metadata prohibition for server/discover and tools/list:

- Every complete discovery and tool-list result, including empty and all
  paginated pages, includes exactly `ttlMs: 0` and `cacheScope: "private"`.
- Zero means immediately stale; private disallows sharing across authorization
  contexts. The server implements no result-cache storage, cache reuse or new
  caching RPC. Official counterpart cache remains `None`.
- Tool-call results do not gain cache fields merely because discovery/list need
  them. No positive TTL, public cache scope, cross-user reuse or optional
  capability is introduced. The existing no-caching non-goal refers to a cache
  engine or RPC feature; it does not forbid these mandatory stale wire fields.
- Preserve all original proposal/control bytes. Record this separate amendment,
  approval receipt and superseding execution-authority manifest on approval.

## Exact implementation, verification and unchanged boundaries

Within the same18 product paths, update modern.py discovery/page result
construction, test_modern_protocol.py exact result/page assertions,
test_server_interop.py typed SDK discovery/list and cache-disabled proof,
and the already scoped README/server guide. No new product path, dependency,
lock, checker, private library or fixture permission is needed.

Positive assertions cover empty/nonempty discovery and every byte/count-bounded
catalog page carrying integer0/private. Negative assertions reject missing/null/
malformed dated cache fields through the unmodified official SDK wire decoder;
tool-call results remain complete without those cacheable-only fields. Prove
actual subprocess/TLS requests and handler counters rather than synthesized
SDK discovery. Retain earlier failures. Rerun the entire original20-command
profile, supplemental inherited-debt/warning/skip comparisons and library/hash
integrity on the stable completed candidate. Fresh full-unit read-only review is
still mandatory, followed by separate maintainer acceptance.

All12 original criteria and all other CD-MCP-UP-005/contract/profile requirements
remain controlling. Original18 product budget,19 metadata/60 preserved products,
22,009 libraries/192 distributions, async-only handlers, private guarded fixtures,
provider-neutral telemetry, legacy compatibility and local-only delivery remain.
No UP06, publication, OAuth or Langfuse authority is granted by this amendment.

## Approval gate

Approve this exact amendment and its proposed authority manifest before resuming
product construction. The contract’s stop-on-control-conflict requirement and
AGENTS.md reconciliation rule require this narrow approval; passing raw tests or
an earlier broad instruction cannot silently alter the frozen contract.
'''
af=a/'AMEND-MCP-UP-005-001-cacheable-results.md';af.write_text(text)
proposal={'initiative':'friday-mcp-protocol-upgrade','work_unit':'MCP-UP-05','amendment':'AMEND-MCP-UP-005-001','status':'proposed','implementation_authority':'not_granted_for_amendment','parent_authority':{'path':str((p/'authority-UP-05.json').relative_to(w)),'sha256':h(p/'authority-UP-05.json')},'amendment_document':{'path':str(af.relative_to(w)),'sha256':h(af)},'schema_sha256':h(schema),'checkpoint':{'path':str((e/'construction-checkpoint.json').relative_to(w)),'sha256':h(e/'construction-checkpoint.json')},'override':'Only required ttlMs:0/cacheScope:private for complete server/discover and tools/list results. No cache engine/RPC/positive TTL/public scope. Tool-call results unchanged. Original controls immutable.','product_paths':authority['product_paths'],'required_checks':authority['required_checks'],'criteria':list(authority['acceptance_criteria']),'permitted_effects':authority['permitted_effects'],'later_unit_or_remote_delivery_authority':'not granted','future_execution_rule':'Separate approval receipt and superseding frozen authority bind original controls plus exact amendment; rerun original full profile and fresh validator'};dump(p/'proposals/UP-05-amendment-001-authority-manifest.json',proposal)
sf=p/'execution/current-process-state.json';s=json.loads(sf.read_text());s.update(execution_phase='planning',validation_state='not_ready',unit_completion='not proposed; incomplete UP-05 construction stopped for exact cache-metadata amendment',note='Original CD-MCP-UP-005 approved; pinned CacheableResult contradicts no-cache-fields contract. No product edits after conflict discovery. Partial code stays in private candidate; root receives process packet only.',next_gate='Maintainer approval of exact AMEND-MCP-UP-005-001 required ttlMs:0/cacheScope:private metadata before UP-05 construction resumes',pending_amendment=str(af.relative_to(w)),construction_stop='authority_conflict');dump(sf,s)
log=p/'execution-log.md';log.write_text(log.read_text()+'''\n\n## 2026-10-13 - UP-05 construction and normative cache-metadata stop\n\nExact CD-MCP-UP-005 approval was recorded separately. All19 captures were parsed\nand a preconstruction plan froze316 normative paragraphs/560 keywords and145\nTypeScript declarations/355 field references. Those counts describe planning\ncoverage, not completed conformance. Partial18-path implementation remains private.\nDevelopment HTTP46, security/lifecycle47 and stdio/registry11 tests passed;\nstrict seven-source Mypy passed. Original protocol run had200 passes/one malformed\nenvelope-ID assertion failure; correction is unverified pending rerun. SDK run\nhad3 failures/3 passes: the dated official wire models require missing ttlMs/\ncacheScope, contradicting the contract. TLS child signal cleanup assertions also\nremain unfinished under existing scope. Every original check/controller/partial\nsource snapshot is retained, with no private keys/runtime stores in the archive.\n\nStopped product edits on discovery of the contract/schema conflict. Proposed\nAMEND-MCP-UP-005-001 requires only immediately stale private discovery/list wire\nmetadata, preserving18 paths, all20 checks, immutable controls and independent\nreview. No full profile, stable candidate, VERIFIED or completion is claimed.\nNo live fixture child remains. Original authority and earlier accepted units\nremain intact; no later-unit or remote delivery is authorized.\n''')
spec=importlib.util.spec_from_file_location('board',w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);board=m.load_board(w);task=next(x for x in board['tasks'] if x['id']=='friday-mcp-protocol-upgrade');task['next_gate']=s['next_gate'];m._append_event(board,task_id=task['id'],actor='Codex',actor_role='agent',action='prepared exact UP-05 cache-metadata amendment',note='Pinned schema and official SDK require fields forbidden by approved contract; construction stopped.18 paths/20 checks unchanged, local only',evidence=str(af.relative_to(w)));m._save_board_and_dashboard(board,w)
paths=[str(x.relative_to(w)) for x in [af,p/'proposals/UP-05-amendment-001-authority-manifest.json',sf,log,e/'construction-checkpoint.json',e/'construction-artifacts-manifest.json']]+[str(x.relative_to(w)) for x in art.iterdir()]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','commit','-m','Propose exact MCP server CacheableResult authority correction and retain construction evidence'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip())
