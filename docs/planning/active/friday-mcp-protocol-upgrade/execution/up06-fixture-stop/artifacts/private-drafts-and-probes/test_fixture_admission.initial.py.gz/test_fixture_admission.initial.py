"""Read-only diagnosis: the existing stdio fixture triggers accepted schema rejection."""
import asyncio,importlib.util,json,os,sys
from pathlib import Path
import pytest,yaml
from friday_chat.config import load_friday_py_config
from friday_chat.tools.mcp import MCPChatRegistry
from friday_runtime.config import RuntimeConfig
from friday_runtime.tool_loading import ToolProviderLoadError

ROOT=Path('/private/tmp/friday-mcp-upgrade/work')
FIXTURE=ROOT/'packages/friday-mcp/tests_mcp/fixtures/friday_modern_tools_server.py'

def runtime_helpers():
 spec=importlib.util.spec_from_file_location('up06_diagnostic_helpers',ROOT/'packages/friday-runtime/tests_runtime/test_mcp_http_integration.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

class Native:
 def list_tools(self):return ()
 async def call_tool(self,*args):raise RuntimeError('Native tools must not run')

@pytest.mark.asyncio
@pytest.mark.parametrize('owner',['runtime','chat'])
async def test_existing_stdio_fixture_rejected_by_both_real_loaders(tmp_path,monkeypatch,owner):
 counter=tmp_path/'counter.jsonl';entry={'name':'friday','transport':'stdio','command':sys.executable,'args':[str(FIXTURE),'stdio',str(counter)],'protocol_profile':'modern','required':True,'retry_attempts':0}
 stanza={'enabled':True,'mode':'selected','include_tools':['mcp_friday_echo'],'config':{'servers':[entry]}}
 helper=runtime_helpers()
 if owner=='runtime':
  kernel=helper.kernel_from_yaml(tmp_path,monkeypatch,stanza);start=kernel.start;stop=kernel.stop
 else:
  path=tmp_path/'chat.yaml';path.write_text(yaml.safe_dump({'tools':{'providers':{'mcp':stanza}}}));config=load_friday_py_config(path,env={});bridge=MCPChatRegistry(Native(),config.tools.mcp_provider,str(tmp_path));start=bridge.start;stop=bridge.stop
 try:
  with pytest.raises(ToolProviderLoadError,match='missing_include'):await start()
  provider=kernel.mcp_provider if owner=='runtime' else bridge.provider
  decisions=[{'canonical_name':x.canonical_name,'reason':x.reason,'status':x.status} for x in provider.registration_decisions]
  assert any(x['reason']=='invalid_schema' for x in decisions)
  data=[json.loads(x) for x in counter.read_text().splitlines()]
  assert any(x.get('method')=='tools/list' for x in data)
  assert not any(x['event']=='handler_start' for x in data)
  assert data[-1]=={'event':'server_stopped','active':0}
  print('BUILD_UP06_001',json.dumps({'owner':owner,'decisions':decisions,'handler_starts':0,'last_event':data[-1]}))
 finally:await stop()
