# REM-MCP-UP-003 builder handoff

Stable corrected candidate: `0220500aa8d236d74604f6011bee03a0b13081b7`.
Base: `dabe21258b5e5082e603cfe5e23351c1a7ea523c`. Branch: `feature/friday-mcp-protocol-upgrade`.
Candidate is clean. Exactly one committed path changed: `docs/guides/10-configuration.md`.
Corrected SHA256: `5085a99de6fb7b9417a5eb7c3d19983070eba2ed14052d4e5c085410699056c0`.
Committed diff SHA256: `6352eff5d6db6d12eaaf60b1714bb1e0381ef7dc473053ac5bf12a7dab794698`.

Applied only the literal old/new replacement pinned by authority-REM-MCP-UP-003.json for VAL-UP03-001 under original approved CD-MCP-UP-003 / INT-AC-10. Inspected accepted http_policy.py lines57-72 and99-106 and unchanged guide17 lines218-224: address permissions are additive to eligible public destinations and ports are selected separately. No new behavior or authority was introduced.

All 27 other original products, all 19 metadata/lock files and 107 pinned authority references remain identical. The unscoped accepted HTTP baseline also remains identical. Before each guarded execution, full argv/environment/current source hashes, authority, guard and original runner hashes were frozen; raw stdout/stderr and child receipts are retained. The original policy probe exactly matches its archived gzip source and ran without I/O. It reports listed private127.0.0.1 permitted, different unlisted eligible public93.184.216.34 permitted, and different unlisted private10.0.0.1 denied.

All recorded child checks exited0: board/next/show before and after correction; original address-semantics probe; documentation lifecycle (528 Markdown files); current dashboard render; worktree whitespace; committed correction-range and complete UP-03-range whitespace. Only the exact named guide was staged and committed; commit hooks were disabled. No tests, runtime/transport/policy/configuration products, controls, board/process files or checker rules changed. No installs/sync, public network, ambient credentials, stores, external messaging or publication occurred. No runtime homes/caches/material are included in this directory.

Evidence: exact-one-path.diff and committed-one-path.diff; initial/freeze.json, corrected/freeze.json, final-freeze.json; complete gzip source freezes; exact-replacement.json; semantic-inspection.json; preflight-success.json; checks/*/before-execution.json, receipt.json, stdout, stderr; original-review originals; orchestrator sources and bootstrap diagnostics. evidence-manifest.json enumerates all retained nonruntime evidence files with byte lengths and SHA256, including gzip expanded hashes.

This is a builder handoff, not independent VERIFIED, unit completion, maintainer acceptance or publication. The original CHANGES_REQUESTED report stays immutable. Controller prepares the new process/request freeze and fresh independent finding-delta plus full original UP-03 review.
