from pathlib import Path
from datetime import datetime,timezone
import ast,copy,gzip,hashlib,json,re,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';out=b/'up06-amend2-actual-mcp-mapping';out.mkdir(exist_ok=False)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def dump(f,j):f.write_text(json.dumps(j,indent=2)+'\n')
a=json.loads((p/'authority-UP-06-amendment-002.json').read_text());plan=json.loads((p/'execution/up06/preconstruction-plan.json').read_text());client_path=w/plan['original_client_ledger']['stored_path'];client=json.loads(gzip.decompress(client_path.read_bytes()));server_path=Path(plan['original_server_ledger']['path']);server=json.loads(server_path.read_text());captures={}
for row in plan['primary_captures']:
 f=w/row['artifact'];raw=gzip.decompress(f.read_bytes()) if f.suffix=='.gz' else f.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=row['sha256'] or h(f)!=row['artifact_sha256'] or len(raw)!=row['bytes']:raise RuntimeError('Capture drift')
 captures[row['url']]={'source':row['url'],'sha256':row['sha256'],'artifact':row['artifact'],'text':raw.decode()}
source_hashes={};references={};trees={}
def reference(path,symbol=None):
 f=w/path;digest=h(f);source_hashes[path]=digest;key=path+('::'+symbol if symbol else '')
 if key in references:return key
 text=f.read_text();ref={'path':path,'sha256':digest}
 if symbol:
  tree=trees.setdefault(path,ast.parse(text));nodes=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name==symbol.split('.')[-1]]
  if not nodes:raise RuntimeError('Missing current symbol '+key)
  node=nodes[0];ref.update(symbol=symbol,line=node.lineno,end_line=node.end_lineno,assertions=[{'line':x.lineno,'text':ast.get_source_segment(text,x)} for x in ast.walk(node) if isinstance(x,ast.Assert)],decorators=[ast.get_source_segment(text,x) for x in node.decorator_list],current_body_sha256=hashlib.sha256(ast.get_source_segment(text,node).encode()).hexdigest())
 references[key]=ref;return key
def bind(value):
 result=[]
 if isinstance(value,str):
  if value.startswith('packages/') and '::' in value:
   path,symbol=value.split('::',1);result.append(reference(path,symbol))
  elif value.startswith('packages/') and value.endswith('.py') and (w/value).is_file():result.append(reference(value))
 elif isinstance(value,list):
  for item in value:result+=bind(item)
 elif isinstance(value,dict):
  if isinstance(value.get('path'),str) and value['path'].startswith('packages/') and (w/value['path']).is_file():result.append(reference(value['path'],value.get('symbol')))
  for k,x in value.items():
   if k not in ['path','symbol','source_sha256','paragraph','definition','field','reason','profile_reason','profile_limit','sha256','current_body_sha256']:result+=bind(x)
 return sorted(set(result))
client_bundles={k:{'mapping':v,'current_reference_ids':bind(v),'current_commands':['original-clients','mcp','core-runtime-chat-telemetry','root']} for k,v in client['groups'].items()};server_bundles={k:{'mapping':v,'current_reference_ids':bind(v),'current_commands':v.get('check_ids',['server-focused'])+['mcp','root']} for k,v in server['bundles'].items()}
for path in a['current_accepted_product_hashes']:
 if path.endswith('.py'):reference(path)
new='packages/friday-mcp/tests_mcp/test_upgrade_aggregate.py';tree=ast.parse((w/new).read_text());newrefs=[reference(new,n.name) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
# Reconcile roles at the paragraph identity, not by blindly carrying prior exclusions.
def norm(text):return re.sub(r'\s+',' ',text).strip()
client_by_paragraph={(r['source'],norm(r['paragraph'])):i for i,r in enumerate(client['clauses'])};server_by_paragraph={(r['source'],norm(r['paragraph'])):i for i,r in enumerate(server['clauses'])}
def anchor(row):
 cap=captures[row['source']];paragraph=row['paragraph'];needle=norm(paragraph);whole=norm(cap['text'])
 if needle not in whole:raise RuntimeError('Unmatched paragraph '+row['source']+':'+str(row['line']))
 # Exact paragraph and full source SHA retained for reproducing line/context checks.
 return {'source':row['source'],'capture_sha256':cap['sha256'],'historical_line':row['line'],'paragraph_sha256':hashlib.sha256(paragraph.encode()).hexdigest(),'complete_paragraph':paragraph,'verified_in_complete_capture':True}
def client_group(row):
 text=(row.get('paragraph','')+' '+row.get('name','')+' '+row.get('declaration','')+' '+row.get('field','')).lower()
 if '2025-11-25' in row.get('source',''):return 'compat'
 for words,group in [(('header','base64','mcp-method','mcp-name'),'headers'),(('cancel','disconnect','deadline','timeout'),'cancel'),(('schema','content','result','tool','input_required'),'results'),(('oauth','auth','trace','baggage','consent'),'safety'),(('bound','limit','rate','size'),'limits')]:
  if any(t in text for t in words):return group
 return 'core'
client_clauses=[]
for i,row in enumerate(client['clauses']):
 j=server_by_paragraph.get((row['source'],norm(row['paragraph'])));cp=copy.deepcopy(row);cp.update(aggregate_id=f'AGG-CLIENT-{i+1:04d}',role='2025 HTTP client' if '/2025-11-25/' in row['source'] else '2026 client',capture_anchor=anchor(row),current_reference_ids=bind(row),current_commands=['original-clients','mcp','core-runtime-chat-telemetry','root'],cross_server_inventory_id=None if j is None else f'AGG-SERVER-{j+1:04d}',aggregate_disposition='Client boundary remains independently required; attached current server boundary must also satisfy server obligations' if j is not None else 'Client-only or conditional optional role; prior bounded client disposition is retained with current source/test bindings')
 if j is not None:cp['current_server_bundles']=server['clauses'][j]['bundles']
 cp['new_combined_evidence']=newrefs[:3];client_clauses.append(cp)
server_clauses=[]
for i,row in enumerate(server['clauses']):
 j=client_by_paragraph.get((row['source'],norm(row['paragraph'])));cp=copy.deepcopy(row);group=client_group(row);cp.update(aggregate_id=f'AGG-SERVER-{i+1:04d}',role='2026 server' if '/2026-07-28/' in row['source'] else 'Historical2025 client/other role',capture_anchor=anchor(row),current_server_bundles=row['bundles'],current_reference_ids=sorted(set(key for groupname in row['bundles'] for key in server_bundles[groupname]['current_reference_ids'])),cross_client_inventory_id=None if j is None else f'AGG-CLIENT-{j+1:04d}',current_client_bundles=[group],aggregate_disposition='Historical2025 clauses assessed as client duties against explicit compatibility source/tests, not excluded from aggregate' if '/2025-11-25/' in row['source'] else 'Both client and server duties assessed separately; optional conditional roles only inactive when neither Friday role advertises/activates them',current_commands=['server-focused','server-http','original-clients','mcp','core-runtime-chat-telemetry','root'])
 server_clauses.append(cp)
client_types=[];client_fields=[]
server_names={r['name']:r for r in server['declarations']}
for row in client['selected_schema_interfaces']:
 cp=copy.deepcopy(row);cp.update(current_reference_ids=bind(row),current_commands=['original-clients','mcp','root'],current_server_declaration=row['type'] if row['type'] in server_names else None);client_types.append(cp)
 for field in row['fields']:
  client_fields.append({'interface':row['type'],'source':row['source'],'source_sha256':row['source_sha256'],'field':field,'client_group':row['group'],'current_reference_ids':cp['current_reference_ids'],'server_declaration':cp['current_server_declaration'],'role_boundary':'Send/receive typed client field and independent server definition; omitted/null/bounds/error variants live in referenced parameterized tests; no optional capability activation by field presence alone'})
server_types=[];server_fields=[]
for key,dest in [('declarations',server_types),('fields',server_fields)]:
 for row in server[key]:
  cp=copy.deepcopy(row);group=client_group(row);cp.update(current_reference_ids=bind(row)+sorted(set(k for name in row['bundles'] for k in server_bundles[name]['current_reference_ids'])),current_client_bundles=[group],current_commands=['server-focused','server-http','original-clients','mcp','root'],cross_role_disposition='Independent outgoing/incoming grammar for both roles; server-only/historical excluded fields do not exempt a supported client boundary');dest.append(cp)
# Exact published excerpts; these original bytes are never replaced during capture.
fences=[]
for document in ['docs/guides/17-mcp-client.md','docs/guides/18-mcp-server.md','docs/guides/19-mcp-migration.md','packages/friday-mcp/README.md']:
 text=(w/document).read_text()
 for match in re.finditer(r'^```(yaml|python|bash)\n(.*?)^```',text,re.M|re.S):
  language=match.group(1);excerpt=match.group(2);line=text[:match.start(2)].count('\n')+1;fences.append({'document':document,'document_sha256':h(w/document),'language':language,'line':line,'excerpt':excerpt,'excerpt_sha256':hashlib.sha256(excerpt.encode()).hexdigest(),'proof':'Both public YAML loaders; migration enabled profiles execute retained named fixture peers' if language=='yaml' else 'Compile/public import/signature proof; semantic named Friday/SDK fixtures have handler/terminal/ownership assertions' if language=='python' else 'Provisioning instruction only; deliberately not executed','allowed_substitutions':['interpreter','fixture executable/args','cwd/private application context','literal private endpoint/address/ephemeral port','verifying synthetic CA','synthetic credential environment value'],'unchanged_mcp_policy':'Role/revision/name/selection/required/retry/security/auth keys remain as published; no fallback or TLS weakening','command_ids':['documented-configs','aggregate-examples','mcp','root'] if language!='bash' else []})
criteria={}
for id,requirement in a['acceptance_criteria'].items():criteria[id]={'requirement':requirement,'current_test_reference_ids':newrefs,'current_client_bundles':list(client_bundles),'current_server_bundles':list(server_bundles),'required_checks':[x['id'] for x in a['required_checks']],'decision':'Builder evidence binding; independent whole-feature verdict required; acceptance not granted'}
result={'status':'Current candidate builder mapping; no independent VERIFIED claim','created_utc':datetime.now(timezone.utc).isoformat(),'product_candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'aggregate_base':a['aggregate_branch_base'],'authority_sha256':h(p/'authority-UP-06-amendment-002.json'),'primary_capture_count':len(captures),'primary_capture_hashes':{url:{k:v for k,v in row.items() if k!='text'} for url,row in captures.items()},'prior_index_provenance':{'client':{'path':str(client_path),'sha256':h(client_path)},'server':{'path':str(server_path),'sha256':h(server_path)},'boundary':'Indexes retained to locate exhaustive clauses/fields; bindings recomputed at current candidate. Earlier role exclusions reconciled against both roles. No prior verdict copied.'},'current_reference_index':references,'current_source_hashes':source_hashes,'client_bundles':client_bundles,'server_bundles':server_bundles,'client_clauses':client_clauses,'server_clauses':server_clauses,'client_interfaces':client_types,'client_fields':client_fields,'server_declarations':server_types,'server_fields':server_fields,'published_fences':fences,'aggregate_criteria':criteria,'initiative_to_aggregate_criteria':a['initiative_to_aggregate_criteria'],'counts':{'client_clauses':len(client_clauses),'client_interfaces':len(client_types),'client_field_references':len(client_fields),'server_clauses':len(server_clauses),'server_declarations':len(server_types),'server_field_references':len(server_fields)},'limits':'Dated tools roles only. Conditional OAuth/interactive/agent/Tasks/subscriptions are explicitly inactive; should tradeoffs stay documented. Synthetic fixtures do not prove public deployment. Current raw full profile and independent aggregate inspection still required.'}
dump(out/'final-actual-mapping.json',result);dump(out/'published-excerpts.json',fences);dump(out/'current-binding-integrity.json',{'references':len(references),'source_files':len(source_hashes),'counts':result['counts'],'capture_count':len(captures),'missing_references':[]});print(json.dumps(result['counts']))
