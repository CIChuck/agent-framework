from pathlib import Path
import copy,hashlib,importlib.util,json,subprocess,sys,tempfile
import yaml
w=Path.cwd();p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=json.loads((p/'authority-UP-06-amendment-002.json').read_text());root=Path(tempfile.mkdtemp(prefix='up06-real-board-rehearsal-'));name='up06_rehearsal_board';spec=importlib.util.spec_from_file_location(name,w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);board=copy.deepcopy(m.load_board(w))
def req(ok,msg):
 if not ok:raise RuntimeError(msg)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for lane in m.CURRENT_LANES:(root/'docs/planning'/lane).mkdir(parents=True)
(root/'docs/planning/board.schema.json').write_bytes((w/'docs/planning/board.schema.json').read_bytes())
for t in board['tasks']:
 source=w/t['packet']/'README.md';dest=root/t['packet']/'README.md';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.read_bytes())
packet='docs/planning/active/friday-mcp-protocol-upgrade/';records={}
for c in a['controls']+a['prior_frozen_manifests']+[a['approval'],{'path':str((p/'authority-UP-06-amendment-002.json').relative_to(w)),'sha256':h(p/'authority-UP-06-amendment-002.json')}]:
 path=c['path']
 if not path.startswith(packet):continue
 source=w/path;req(h(source)==c['sha256'],'Current authority drift');destination=root/path;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(source.read_bytes());base=Path(path).name
 kind='index' if path==packet+'README.md' else 'authority' if base.startswith('authority') else 'approval' if base.startswith('approval') or '/acceptance/' in path else 'directive' if '/directives/' in path else 'report' if '/validation/' in path and 'report' in base else 'evidence'
 records[path]={'path':path,'sha256':c['sha256'],'kind':kind}
req({'index','authority','approval','directive','report'} <= {v['kind'] for v in records.values()},'Missing actual historical roles')
t=next(t for t in board['tasks'] if t['id']==a['initiative']);review='docs/planning/review/friday-mcp-protocol-upgrade/';dest=root/review;dest.mkdir();(dest/'README.md').write_text('# Synthetic MCP closeout\n\nStatus: completed\n');mf=dest/'historical-authority.json';mf.write_text(json.dumps({'version':1,'owner':a['initiative'],'packet':packet,'files':list(records.values())},indent=2)+'\n');t.update(work_state='completed',implementation_authority='closed',packet=review,next_gate='synthetic maintainer acceptance',authority_backing_packets=[{'packet':packet,'manifest':str(mf.relative_to(root)),'manifest_sha256':h(mf)}]);t['validation'].append('synthetic rehearsal only; actual full independent review remains pending');m._save_board_and_dashboard(board,root);req(m.validate_board(m.load_board(root),root)==[],'Actual-schema completed board fails')
archive='docs/archive/completed/2026/friday-mcp-protocol-upgrade/';(root/archive).parent.mkdir(parents=True,exist_ok=True);dest.rename(root/archive);staged=m.load_board(root);st=next(x for x in staged['tasks'] if x['id']==a['initiative']);st['authority_backing_packets'][0]['manifest']=archive+'historical-authority.json';(root/'docs/planning/board.yaml').write_text(yaml.safe_dump(staged,sort_keys=False));argv=[sys.executable,str(w/'scripts/friday-dev-board.py'),'--root',str(root),'transition',a['initiative'],'accepted','--packet',archive,'--actor','Synthetic maintainer','--actor-role','maintainer','--note','Synthetic acceptance rehearsal; no actual acceptance','--next-gate','none'];run=subprocess.run(argv,capture_output=True,text=True);req(run.returncode==0,run.stderr);final=m.load_board(root);req(m.validate_board(final,root)==[],'Actual-schema accepted board fails')
for row in records.values():req(h(root/row['path'])==row['sha256'],'Historical bytes changed in rehearsal')
print(json.dumps({'scope':'Synthetic full-current-board closeout rehearsal; no actual completion/acceptance or checkout mutation','tasks':len(board['tasks']),'immutable_actual_records':len(records),'completed_errors':[],'accepted_errors':[],'canonical_review':review,'canonical_archive':archive,'original_backing':packet,'acceptance_cli_exit':run.returncode,'all_original_hashes_unchanged':True,'fixture_root':str(root),'current_policy_sha256':h(w/'docs/reference/policies/development-task-lifecycle.md')},indent=2))
