from pathlib import Path
import json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=json.loads((p/'authority-UP-06-amendment-002.json').read_text());results=[]
for check in a['required_checks']:
 label='up06-amend2-full-'+check['id'];subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP06_amend2.py'),label,check['snapshot'],*check['argv']],check=True);j=json.loads((b/'checks'/label/'receipt.json').read_text());results.append({'id':check['id'],'label':label,'exit_code':j['exit_code'],'success_contract':check['success']})
f=b/'up06-amend2-profile-results.json'
if f.exists():raise RuntimeError('Result overwrite')
f.write_text(json.dumps(results,indent=2)+'\n')
