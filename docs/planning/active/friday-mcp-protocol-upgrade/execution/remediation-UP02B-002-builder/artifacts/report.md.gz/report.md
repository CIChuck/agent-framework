# REM-MCP-UP-002 builder handoff

Candidate: `462fa7cf25b16e67d7a98267733b4d9f56274a93` on `feature/friday-mcp-protocol-upgrade`.
Remediation base: clean `05118298b10a396d5aff5de61f074a4ff251b695`.
Date: 2026-10-12. Role: separate bounded remediator. Status: stable product candidate;
fresh independent finding delta and full CD-MCP-UP-002 work-unit review required.
This report is builder evidence, not an independent verdict or maintainer acceptance.

## Authority and scope

The separate exact maintainer receipt `approval-REM-MCP-UP-002.json` authorizes the immutable proposed directive
SHA256 `bab8e478d5d2e73d3d79818c9984474e5a0ab136ae9230179718487f17197240`
and proposal manifest SHA256 `45a40aa7d241b44b68021ab1d7a0e1dae461bec8350bb3c05627123b706c7873`.
The approved execution manifest, original CD2 authority/prior controls, repository engineering/lifecycle/independent-validation policies,
and frozen 2026-07-28/2025-11-25 sources remain controlling. The original report's decompressed SHA256 is
`e97e199a556be162ff99a46d6d3ec6db75de3ef61cff5985447b47fbd73487c3`.
Its findings appear exactly once in the delta ledger. Board validate/next/show passed before source edits:
started/granted, local delivery, named branch and approved bounded-remediation gate.

Only the authorized six paths changed and were committed:

- `packages/friday-mcp/src/friday_mcp/client/http_protocol.py`
- `packages/friday-mcp/src/friday_mcp/client/http.py`
- `packages/friday-mcp/src/friday_mcp/client/protocol.py`
- `packages/friday-mcp/tests_mcp/client/test_http_protocol.py`
- `packages/friday-mcp/tests_mcp/client/test_http_lifecycle.py`
- `packages/friday-mcp/README.md`

All product work occurred in `/private/tmp/friday-mcp-upgrade/work`.
No shared mixed checkout, process board/index/log, prior report/control, normative ledger, dependency file,
SDK runtime import, provider configuration, suppression or publication was changed by this remediator.
`postcommit.json` records a clean private work tree and exact six-path product-only commit.
`final-inventory.json` reconciles fourteen overall CD2 product paths, 52 unchanged pinned-control records,
18 complete dated captures and 275 original archived artifacts, with no error.
Original allowed httpcore edges remain the only CD2 lock delta; the dependency files are byte-identical to the remediation baseline.

## Findings and resulting behavior

| Finding | Correction and regression evidence |
| --- | --- |
| VAL-UP02B-001 | `contentSchema` and deprecated schema-valued `dependencies` join the schema-bearing traversal audit. Every annotation there is unreachable and excludes the tool, including valid-looking and malformed names/types. Other 2020-12 schema maps/children/arrays have negative coverage; examples/default/const/enum JSON stays opaque. A stalled second catalog page proves tools/bindings/counts remain unpublished until complete validation. Excluded-tool calls issue no request; retained scalar properties still produce exact UTF-8/base64 headers. |
| VAL-UP02B-002 | Lifecycle serialization and generation ownership protect recovery, initialization session writes, refresh publication and failure invalidation. Two issued calls receive controlled 404 ordering: one recovery succeeds, the later old response fails without another handshake or clearing session-2/catalog. Both original calls fail without replay; a subsequent explicit call succeeds. Deadline-expired recovery waiters leave the active recovery intact. Failed/timed-out recovery leaves its own session disconnected; explicit reconnect cleans old owners and restores service. All streams/tasks settle and borrowed connectors remain owned as before. |
| VAL-UP02B-003 | Exact 2025 tools/list rejects any non-supported input `$schema` declaration with fixed `unsupported_schema`. Default and canonical declared 2020-12 use the existing schema validator. Later-page malformed/unknown/draft-07 declarations yield no partial or stale catalog, no tools/call, no schema-URI retrieval and no dependency/dialect expansion. Dedicated tests preserve permissive 2024 input parsing and modern rejection behavior. |
| VAL-UP02B-004 | Exact 2025 selected received envelope/params/result, Tool and TextContent metadata validate object/key grammar. Independent malformed-prefix/slash/name cases cover initialize/list-result/tool/result/text/request-params/notification-params boundaries. Prefixed/unprefixed/empty names and opaque reserved values succeed; structuredContent, arguments and schema data stay opaque. Modern reserved result typing and 2024 permissive metadata remain explicitly tested. Diagnostics omit keys and synthetic payloads. |

The six original independently failing assertions in the immutable private `test_review_probes.py` now pass against the candidate.
The corresponding scenarios also live in the authorized package regression tests. The private probe source was not changed.
README describes the supported 2025 dialect, grammar-versus-opaque-value boundary, schema-bearing annotation exclusion,
atomic catalog publication and generation-owned no-replay recovery.

## Final stable verification

The product hashes, original guarded runner/guard hashes, exact argv, environment template plus deterministic label/snapshot expansion,
and original effect inventory were frozen before final verification in `stable-check-freeze.json` (SHA256
`7bc7a9efa4eaff12d3ec8b42fdbe5d8bb7982062567a8f0bcd25c03b03f3b14d`).
The committed product bytes match that freeze. `derived-frozen-environments.json` expands the pinned runner rule;
all 19 final actual argv/environments reconcile in `environment-reconciliation.json`.
Complete per-command raw stdout/stderr, exits, full allowlisted environments, timestamps and stream hashes are in `checks/` and `command-ledger.json`.
Final gates ran once on the final source without subsequent source changes.

| Final gate | Result |
| --- | --- |
| Original independent reproducers | Exit 0; 6 passed |
| Three HTTP client files | Exit 0; 297 passed |
| Four original client files | Exit 0; 228 passed |
| MCP package | Exit 0; 561 passed |
| Runtime/Chat/Telemetry | Exit 0; 1,211 passed, 5 skipped, 1 warning |
| Root configured pytest | Exit 0; 3,628 passed, 14 skipped, 15 warnings |
| Preserved original pre-CD2 baseline root | Exit 0; 3,331 passed, 14 skipped, 15 warnings |
| Changed/new eleven Python paths Ruff | Exit 0; clean |
| Root Ruff / baseline Ruff | Both exit 1; exact same 327 full normalized diagnostic/fix objects; no added/removed finding |
| Narrow six-client-module Mypy | Exit 0; no issues |
| Full 21-file MCP source Mypy | Exit 0; no issues; inherited ignores remain unchanged |
| Board validate/next/show | Exit 0; 26 tasks; started/granted/local, correct branch/gate |
| Documentation lifecycle / render check / whitespace | Exit 0; 518 Markdown files checked; no error |
| Source/control/dependency/artifact scope | No errors; six remediation paths and fourteen overall product paths |

`baseline-comparison.json` records identical current warning/skip counts and identical normalized full warning sections.
The exact skip-location/reason groups from the preserved earlier independent `-rs` comparison remain referenced separately;
the current final commands use the original exact `-q` profile. Thirteen inherited live LM Studio skips and one inherited missing-scipy graph skip
remain outside deterministic acceptance. Root discovery is the frozen configured profile, not every top-level legacy/lab test.
The final root has 297 more passes than the original pre-CD2 baseline: 198 original HTTP tests plus 99 remediation regressions.

Intermediate failures are retained, not overwritten: first focused run had 8 new pagination-fixture failures because its modern page replies
omitted required cache hints; the corrected focused run passed 283. Development Mypy required one list annotation; Ruff required shortened
new test names. The first stable Ruff attempt caught one remaining 89-character test name and stopped before broader gates.
The final frozen profile passes narrow Ruff/Mypy/tests; historical root Ruff debt stays explicitly nonzero under the original baseline disposition.
No waiver, ignore, new skip or checker weakening was introduced.

## Environment, effects and limits

Private Python 3.13.10; mcp/mcp-types 2.3.0; httpcore 1.0.9; jsonschema 4.25.1; referencing 0.37.0; IDNA 3.20; Ruff 0.14.10.
Guard SHA256 `38f6a7483d66a066336d63c14980f1acfe307ec38848f0761c6928a66989a7a8`;
runner SHA256 `ceec1b2316f4be3bce36fb778eb80b5d472561920d6d6fe35b8b30735e1776f0`.
Only the original named synthetic literal-127.0.0.1 peers and existing cross/root fixtures ran.
Controlled network-policy peers/resolvers do not contact their public-looking test addresses. There was no dependency install/sync,
public DNS/TCP, ambient OTEL, real service/exporter/provider, credential read, user-store access, arbitrary external process or publication.
Private runtime stores and generated synthetic TLS material are excluded from this evidence bundle.

The original normative ledger is preserved. `delta-normative-clause-ledger.json` reconciles all 218 original records and 347 mandatory occurrences,
adds finding-specific evidence and the selected schema/metadata audit; `criterion-clause-delta.md` is its readable navigation.
These remain builder mappings. OAuth, resources/prompts, subscriptions/resumption, task or interactive continuation,
Runtime/Chat remote YAML admission, Friday modern server publication, later MCP units and Langfuse remain separately gated.
No whole-initiative conformance, merge/release readiness, live-provider evidence, completion, acceptance or VERIFIED status is claimed.

The controller should archive this new evidence, preserve the prior report as historical evidence superseded only for the corrected-candidate decision,
and freeze a fresh read-only independent finding-delta followed by full original work-unit review against this product commit.
