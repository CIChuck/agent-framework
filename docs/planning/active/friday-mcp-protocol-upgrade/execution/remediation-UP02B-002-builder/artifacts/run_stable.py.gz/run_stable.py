import json
import shutil
import subprocess
import sys
from pathlib import Path
base = Path('/private/tmp/friday-mcp-upgrade')
d = base / 'remediation-UP02B-002-builder'
f = json.loads((d / 'stable-check-freeze.json').read_text())
keys = sys.argv[1:] or list(f['commands'])
for key in keys:
    snapshot = 'http-baseline' if key.startswith('baseline-') else 'work'
    label = 'rem002-final-' + key
    completed = subprocess.run([str(base / 'venv/bin/python'), str(base / 'run_check.py'), label, snapshot, *f['commands'][key]], capture_output=True, text=True)
    print(completed.stdout.strip(), flush=True)
    if completed.stderr:
        print(completed.stderr, flush=True)
    src = base / 'checks' / label
    if src.exists():
        shutil.copytree(src, d / 'checks' / label)
    receipt = json.loads((src / 'receipt.json').read_text())
    if receipt['exit_code'] != 0 and key not in ('root-ruff', 'baseline-ruff'):
        print('STOP: required gate failed: ' + key, flush=True)
        sys.exit(1)
