from pathlib import Path
import json
b=Path('/private/tmp/friday-mcp-upgrade');d=b/'up06-amend1-builder-evidence-r1';j=json.loads((d/'final-actual-mapping.json').read_text());refs=j['current_reference_index'];new='packages/friday-mcp/tests_mcp/test_upgrade_aggregate.py::'
selectors={
'AGG-AC-01':['test_documented_yaml_loads','test_envelope_rejects','test_profiles_and_exact_wire'],
'AGG-AC-02':['test_friday_client_to_friday_server','test_real_sdk','test_official','test_pinned'],
'AGG-AC-03':['test_runtime_yaml_to_friday_peer','test_chat_real_yaml_factory','test_documented_profiles_execute','test_http_admission_filters','test_real_chat_yaml_factory_selection','test_real_tls_hostname_rejection'],
'AGG-AC-04':['test_documented_'],
'AGG-AC-05':['test_documented_','test_default_manager_keeps_legacy','test_remote_opt_in_and_local','test_profiles_and_exact_wire'],
'AGG-AC-06':['test_cross_transport_cancel','resistant','first_byte','deadline','test_stdio_rejection','test_http_blocked'],
'AGG-AC-07':['test_runtime_yaml_to_friday_peer','test_chat_real_yaml_factory','test_observation','test_borrowed','test_telemetry'],
'AGG-AC-08':['test_friday_client_to_friday_server','test_chat_real_yaml_factory','test_call_keeps_old_output_schema','test_real_chat_malicious_remote_output','test_real_chat_factory_safe_result'],
'AGG-AC-09':['test_documented_'],
'AGG-AC-10':[], 'AGG-AC-11':[], 'AGG-AC-12':[]}
criteria={}
for id,row in j['aggregate_criteria'].items():
 ids=[key for key in refs if '::' in key and any(token in key for token in selectors[id])]
 criteria[id]={'requirement':row['requirement'],'current_reference_ids':ids,'criterion_evidence':['final-actual-mapping.json','published-excerpts.json','current-binding-integrity.json'],'checks':['aggregate-examples','documented-configs','server-focused','server-http','original-clients','mcp','core-runtime-chat-telemetry','root'] if int(id[-2:])<=9 else [r for r in row['required_checks']],'status':'Builder current bindings only; fresh whole-feature independent assessment required' if int(id[-2:])<=10 else 'Pending fresh independent verdict / controller closeout; no self-PASS','explicit_amendment':'Seven-path/75-frozen historical parent wording is prospectively superseded by AMEND001 eight paths/74 frozen.12 criteria/24 commands unchanged.'}
 if int(id[-2:])<=9 and not ids:raise RuntimeError('Missing criterion refs '+id)
(d/'aggregate-criteria.json').write_text(json.dumps({'aggregate_criteria':criteria,'initiative_mapping':j['initiative_to_aggregate_criteria']},indent=2)+'\n')
print({k:len(v['current_reference_ids']) for k,v in criteria.items()})
