from pathlib import Path
import json,collections,re,hashlib,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';base=b/'up06-baseline';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=json.loads((p/'authority-UP-06-amendment-001.json').read_text());checks={};product='72246581'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def req(ok,msg):
 if not ok:raise RuntimeError(msg)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();req(head.startswith(product),'Candidate drift');req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Dirty candidate')
source_paths=sorted(set(a['current_accepted_product_hashes'])|{r['path'] for r in a['product_paths']});allreceipts=[]
for c in a['required_checks']:
 d=b/'checks'/('up06-amend1-full-'+c['id']);j=json.loads((d/'receipt.json').read_text());pre=json.loads((d/'preflight.json').read_text());snap=w if c['snapshot']=='work' else base;expected=1 if 'ruff' in c['id'] and c['id']!='ruff' or c['id'] in {'full-mypy','baseline-full-mypy','full-mypy-columns','baseline-full-mypy-columns'} else 0
 req(j['exit_code']==expected and j['argv']==c['argv'],'Receipt/argv mismatch '+c['id']);req(pre['candidate_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=snap,text=True).strip(),'Snapshot HEAD drift');req(pre['source_hashes']=={x:h(snap/x) for x in source_paths},'Source drift '+c['id']);req(pre['environment']==j['environment'],'Environment drift');req(h(d/'stdout')==j['stdout_sha256'] and h(d/'stderr')==j['stderr_sha256'],'Raw output drift');req(pre['guard_sha256']==a['guard']['sha256'] and pre['UP06_runner_sha256']==a['runner']['UP06_sha256'],'Guard/runner drift');checks[c['id']]={'label':d.name,'exit_code':j['exit_code'],'argv':j['argv'],'started_utc':j['started_utc'],'finished_utc':j['finished_utc'],'stdout_sha256':j['stdout_sha256'],'stderr_sha256':j['stderr_sha256']};allreceipts.append(j)
def norm(v,snap):
 if isinstance(v,str):return v.replace(str(snap),'<snapshot>')
 if isinstance(v,list):return [norm(x,snap) for x in v]
 if isinstance(v,dict):return {k:norm(x,snap) for k,x in v.items()}
 return v
ruff=[norm(json.loads((b/'checks'/('up06-amend1-full-'+key)/'stdout').read_text()),snap) for key,snap in [('root-ruff',w),('baseline-root-ruff',base)]];req(len(ruff[0])==len(ruff[1])==327 and collections.Counter(json.dumps(x,sort_keys=True) for x in ruff[0])==collections.Counter(json.dumps(x,sort_keys=True) for x in ruff[1]),'Complete Ruff diagnostic/fix drift')
columns=[]
for key in ['full-mypy-columns','baseline-full-mypy-columns']:
 text=(b/'checks'/('up06-amend1-full-'+key)/'stdout').read_text();columns.append([x for x in text.splitlines() if ': error:' in x or ': note:' in x])
prior=json.loads((b/'up04-mypy-column-comparison.json').read_text())['diagnostics'];req(columns[0]==columns[1]==prior and len(prior)==4,'Mypy column diagnostic drift')
myplain=[]
for key in ['full-mypy','baseline-full-mypy']:
 text=(b/'checks'/('up06-amend1-full-'+key)/'stdout').read_text();myplain.append([x for x in text.splitlines() if ': error:' in x or ': note:' in x])
req(myplain[0]==myplain[1] and len(myplain[0])==4,'Mypy plain diagnostic drift')
pytest={}
for key,snap in [('root',w),('baseline-root',base)]:
 text=(b/'checks'/('up06-amend1-full-'+key)/'stdout').read_text().replace(str(snap),'<snapshot>');warning=re.search(r'=+ warnings summary =+\n(.*?)\n-- Docs:',text,re.S);req(warning is not None,'Missing warnings section');pytest[key]={'skip_locations_reasons':[l for l in text.splitlines() if l.startswith('SKIPPED')],'complete_warnings':warning[1],'summary':text.splitlines()[-1]}
req(pytest['root']['skip_locations_reasons']==pytest['baseline-root']['skip_locations_reasons'] and pytest['root']['complete_warnings']==pytest['baseline-root']['complete_warnings'],'Skip/warning drift');req(len(pytest['root']['skip_locations_reasons'])==9,'Grouped skips drift')
for x in a['controls']+a['prior_frozen_manifests']+[a['approval'],a['approved_proposal']]:req(h(w/x['path'])==x['sha256'],'Control drift '+x['path'])
for key in ['metadata_hashes','preserved_product_hashes']:
 for path,digest in a[key].items():req(h(w/path)==digest,'Frozen input drift '+path)
libraries=[]
for phase in ['profile-before','profile-after']:
 j=json.loads((b/('up06-library-'+phase+'.json')).read_text());libraries.append(j);req(j['inventory_references']==22009 and j['unique_paths']==21992 and j['distributions']==192 and not j['mismatches'],'Library drift')
req(libraries[0]['finished_utc']<min(j['started_utc'] for j in allreceipts) and libraries[1]['started_utc']>max(j['finished_utc'] for j in allreceipts),'Library samples do not bracket all24');req(libraries[0]['actual_hashes']==libraries[1]['actual_hashes'] and libraries[0]['input_hashes']==libraries[1]['input_hashes'],'Library content drift')
allowed={x['path'] for x in a['product_paths']};changed=set(subprocess.check_output(['git','diff','--name-only',a['execution_baseline']+'..HEAD'],cwd=w,text=True).splitlines());req(all(x in allowed or x.startswith('docs/planning/') for x in changed),'Scope drift');req(len(changed&allowed)==8,'Eight-path construction mismatch')
report={'status':'Builder evidence only; fresh whole-feature independent validation required','product_candidate':head,'checks':checks,'root_test_results':pytest,'root_ruff':{'count':327,'complete_diagnostics_and_fixes_equal':True,'complete_objects':ruff[0]},'full_mypy':{'complete_column_diagnostics':columns[0],'complete_plain_diagnostics':myplain[0],'equal_baseline':True},'library_references':22009,'unique_library_paths':21992,'distributions':192,'accepted_products_frozen':74,'metadata_frozen':19,'changed_product_paths':sorted(changed&allowed),'source_hashes':{x:h(w/x) for x in source_paths},'primary_captures':19,'skip_and_warning_sections_exactly_equal':True,'publication':'none'};dest=b/'up06-amend1-verification-comparison.json';req(not dest.exists(),'Comparison overwrite');dest.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'commands':len(checks),'root':pytest['root']['summary'],'baseline':pytest['baseline-root']['summary'],'ruff':327,'mypy':4,'skips_warnings_exactly_equal':True,'verdict':'independent review pending'}))
