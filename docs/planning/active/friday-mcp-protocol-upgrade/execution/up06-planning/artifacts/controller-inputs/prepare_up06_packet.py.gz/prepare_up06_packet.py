from pathlib import Path
from datetime import datetime,timezone
import copy,gzip,hashlib,importlib.util,json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';e=p/'execution/up06-planning';base='c90ed023a053943b63d085b70452bbbb11dd28e9';branchbase='1302b5fe3091304c08d1df77ea5fb1d2a4ec3666'
def req(c,m):
 if not c:raise RuntimeError(m)
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def dump(f,j):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(j,indent=2)+'\n')
def pin(f):return {'path':str(f.relative_to(w)),'sha256':h(f)}
req(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==base,'Acceptance HEAD drift');req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Private dirty');req(not e.exists(),'Packet overwrite')
sf=p/'execution/current-process-state.json';state=json.loads(sf.read_text());req(len(state['accepted_units'])==5 and state['unit_completion']=='accepted by Chuck Russell','Acceptance chain incomplete')
request=json.loads((p/'validation-request-REM-MCP-UP-006-R1.json').read_text());accepted=request['preserved_product_hashes']|request['product_hashes'];metadata=request['metadata_hashes'];req(len(accepted)==78 and len(metadata)==19,'Inventory mismatch')
for f,d in (accepted|metadata).items():req(h(w/f)==d,'Accepted product/metadata drift '+f)
paths=['README.md','docs/guides/README.md','docs/guides/17-mcp-client.md','docs/guides/18-mcp-server.md','docs/guides/19-mcp-migration.md','packages/friday-mcp/README.md','packages/friday-mcp/tests_mcp/test_upgrade_aggregate.py'];product=[{'path':x,'baseline_sha256':h(w/x),'change':'existing' if (w/x).is_file() else 'new','kind':'test' if x.endswith('.py') else 'documentation'} for x in paths];req(sum(x['change']=='existing' for x in product)==5 and len(product)==7,'Scope mismatch')
protected={x:d for x,d in accepted.items() if x not in paths};req(len(protected)==75,'Preservation budget mismatch')
branch_paths=subprocess.check_output(['git','diff','--name-only',branchbase,base,'--','packages','docs/guides','README.md','pyproject.toml','uv.lock'],cwd=w,text=True).splitlines();req(set(branch_paths).issubset(set(accepted)|set(metadata)),'Unaccounted aggregate product delta')
baseline_info=json.loads((b/'up06-baseline-snapshot.json').read_text());req(baseline_info['revision']==base and len(baseline_info['omitted_before_checkout'])==267,'Baseline isolation mismatch');req(subprocess.check_output(['git','rev-parse','HEAD'],cwd=b/'up06-baseline',text=True).strip()==base,'Baseline HEAD mismatch')
units=[];prior={};fixed_controls=[]
for u in state['accepted_units']:
 receipt=w/u['receipt'];j=json.loads(receipt.read_text());req(j['status']=='accepted' and j['independent_verdict']=='VERIFIED','Unaccepted unit');report=w/j['independent_report'];raw=report.read_bytes();decoded=gzip.decompress(raw) if report.suffix=='.gz' else raw;expected=j.get('independent_report_uncompressed_sha256',j.get('independent_report_sha256'));req(hashlib.sha256(decoded).hexdigest()==expected,'Accepted report drift')
 units.append({'unit':u['unit'],'receipt':pin(receipt),'reviewed_candidate':u['reviewed_candidate'],'original_report':pin(report),'original_report_uncompressed_sha256':expected,'boundary':'Historical accepted scope, not automatic current aggregate conformance'})
 fixed_controls += [pin(receipt),pin(report)]
 for name,d in j.get('controlling_manifests',{}).items():req(h(p/name)==d,'Prior controlling manifest drift');prior[name]=d
 if j.get('prior_authority_manifest'):req(h(w/j['prior_authority_manifest'])==j['prior_authority_manifest_sha256'],'First authority drift');prior[Path(j['prior_authority_manifest']).name]=j['prior_authority_manifest_sha256']
criteria={
'AGG-AC-01':'All five accepted units and original reports/controls remain immutable. Current full branch scope, all eight initiative criteria and every applicable pinned2026 client/server and explicit2025 client clause/field/variant have evidence. Historical wrong-schema/excluded-role labels are not current proof.',
'AGG-AC-02':'Actual Friday client to actual Friday server through named subprocess stdio and private verified TLS HTTP JSON and SSE. Assert2026 discovery/metadata, complete catalog, Unicode custom header, captured output schema and structured result, exactly-once handler counts and terminal cleanup. Preserve independent official SDK counterparts.',
'AGG-AC-03':'Actual YAML loaders to Runtime provider and real Chat MCP registry, using explicitly selected modern stdio and HTTPS JSON/SSE Friday peers. Assert canonical names, include/category filters, per-turn budgets, required/optional admission, ordinary call result/provenance and terminal cleanup without invoking a model/provider.',
'AGG-AC-04':'Test exact published disabled/local legacy/local modern-auto/HTTPS2026/HTTPS2025 YAML excerpts through real Runtime and Chat loaders. Replace only explicitly listed synthetic fixture placeholders; assert disabled/invalid/mixed-field/default/no-I/O behavior, secret-reference privacy and no schema/default change. Every executable fence is compiled/loaded or linked to actual fixture execution.',
'AGG-AC-05':'Accurate role/revision/transport and migration matrix:2024 stdio remains default; modern/auto explicit; HTTPS2026 and explicit2025 client compatibility;2026-only new server; retained separate legacy programmatic SSE. No new integrated SSE/OAuth/agent/interactive capability, auto-HTTP fallback, sessions in2026 or inferred modern YAML server enum.',
'AGG-AC-06':'Combined-client/server call, concurrent unrelated request, cancellation/timeout/disconnect/shutdown with real owned fixtures has exactly-once handler/terminal counters and no replay/orphan. All five server mitigation regressions and accepted client resistant-owner/deadline/session-recovery tests remain required; limits1..4 and fixed safe errors preserved.',
'AGG-AC-07':'Provider-neutral TelemetryInterface injection/borrowed lifetimes, one observation per owned layer, no raw argument/result/schema/token/URL/trace propagation or global provider/exporter change. Existing server-spy tests remain server observation proof; new cross tests may use client/Runtime/Chat spies without modifying the frozen fixture.',
'AGG-AC-08':'Complete bounded catalogs and result fidelity survive real client/server and registry adaptation: structured JSON/Unicode and safe tool error, captured schemas/generations, accepted sanitization/provenance/quarantine/memory opt-in and budget/filter behavior. No peer instructions become authority; no implicit content/URL fetch or storage migration.',
'AGG-AC-09':'README/index/client/server/migration guide agree with current public APIs/YAML and pinned profiles. Correct earlier legacy-only HTTP/interim unit text, link actual modern server and migration guidance, explain controlled upgrade/rollback and dependency choice, distinguish fixture evidence from deployment; do not rewrite immutable planning/control history.',
'AGG-AC-10':'Exactly24 declared commands plus full scope/authority/library inspections. Narrow/changed Ruff and MCP typing clean; root/raw inherited327 Ruff and4 Mypy diagnostics retain exact objects/columns; full skip/warning sections equal fresh accepted UP06 baseline. Current78 accepted products (75 frozen during this unit), all19 metadata and22009 reference/21992 unique path/192dist actual libraries protected.',
'AGG-AC-11':'Stable candidate and fresh-context read-only whole-feature aggregate review from accepted telemetry merge1302b5f, covering all five unit interactions, seven new paths, all eight initiative and12 aggregate criteria, current controls and primary captures; outcome must be VERIFIED before completion proposal. Unit acceptance is not aggregate evidence.',
'AGG-AC-12':'Explicit safe original evidence/manifest, full final actual requirement/field/test/command ledger, scopes/debt/effects/residual risks and accurate migration closeout. After VERIFIED controller may propose initiative completed/local with a review-packet index and preserved frozen historical backing. Whole acceptance/archive/push/merge/release/Langfuse remain separate maintainer gates.'}
correspondence={'UP-AC-01':['AGG-AC-01','AGG-AC-02','AGG-AC-05'],'UP-AC-02':['AGG-AC-02','AGG-AC-03','AGG-AC-05','AGG-AC-06'],'UP-AC-03':['AGG-AC-03','AGG-AC-04','AGG-AC-05'],'UP-AC-04':['AGG-AC-01','AGG-AC-02','AGG-AC-08'],'UP-AC-05':['AGG-AC-03','AGG-AC-04','AGG-AC-08'],'UP-AC-06':['AGG-AC-06','AGG-AC-07','AGG-AC-10'],'UP-AC-07':['AGG-AC-01','AGG-AC-02','AGG-AC-05','AGG-AC-06'],'UP-AC-08':['AGG-AC-04','AGG-AC-09','AGG-AC-10','AGG-AC-11','AGG-AC-12']}
py=str(b/'venv/bin/python');checks=copy.deepcopy(request['required_checks']);changed_py=sorted(x for x in branch_paths if x.endswith('.py'));newtest=paths[-1]
for c in checks:
 if c['snapshot']=='up05-baseline':c['snapshot']='up06-baseline'
 if c['id']=='ruff':c['argv']=[str(b/'venv/bin/ruff'),'check',*changed_py,newtest]
 if c['id']=='whitespace':c['argv']=['git','diff','--check',branchbase,'HEAD']
for c in [x for x in checks if x['id'] in ['full-mypy','baseline-full-mypy']]:
 checks.append({'id':c['id']+'-columns','snapshot':c['snapshot'],'argv':c['argv']+['--show-column-numbers','--no-pretty'],'success':'raw exit1; complete4 inherited path/line/column/severity/code/message objects must equal accepted baseline'})
checks += [{'id':'aggregate-examples','snapshot':'work','argv':[py,'-m','pytest',newtest,'-q'],'success':'exit0, required real Friday-to-Friday transports/public integration evidence; no infrastructure skips'},{'id':'documented-configs','snapshot':'work','argv':[py,'-m','pytest',newtest,'-k','documented','-q'],'success':'exit0 with nonempty documentation-example selection; excerpts/provenance maps and actual load/compile/fixture proof'}];req(len(checks)==24 and len({x['id'] for x in checks})==24,'Command count mismatch')
# Execute narrow/new aggregate and documented examples before broad sequential checks.
checks=[c for c in checks if c['id'] in ['board','next','show','aggregate-examples','documented-configs']]+[c for c in checks if c['id'] not in ['board','next','show','aggregate-examples','documented-configs']]
for c in checks:
 if c['id'] in ['root-ruff','baseline-root-ruff']:c['success']='raw exit1; exactly equal complete327 normalized diagnostic/fix objects versus current accepted baseline'
 if c['id'] in ['full-mypy','baseline-full-mypy']:c['success']='raw exit1; compare complete4 diagnostics plus explicit-column counterparts without checker weakening'
 if c['id']=='baseline-root':c['success']='exit0; fresh accepted baseline5852 tests expected, complete skip location/reason and warning equality required'
e.mkdir(parents=True);dump(e/'accepted-baseline.json',{'product_baseline':base,'aggregate_branch_base':branchbase,'units':units,'current_accepted_product_hashes':accepted,'metadata_hashes':metadata,'private_baseline_snapshot':baseline_info,'private_baseline_snapshot_sha256':h(b/'up06-baseline-snapshot.json'),'prior_current_root':'35d5194cda9108a6753fdd8ccf42a9e5675d98c3','protection':'Original seven unrelated paths/two-task three-event board overlay retained; no protected contents read'})
dump(e/'aggregate-branch-inventory.json',{'aggregate_base':branchbase,'current_accepted_candidate':base,'product_and_metadata_delta_paths':branch_paths,'changed_python_paths':changed_py,'accepted_inventory_paths':len(accepted),'new_unit_paths':product,'frozen_accepted_product_paths':len(protected),'metadata_paths':len(metadata),'boundary':'Whole-branch review includes this complete earlier delta plus exact seven-path UP06 delta; no additional source scope inferred'})
plan={k:{'required_behavior':v,'prospective_test_module':newtest,'commands':['aggregate-examples','documented-configs','server-focused','original-clients','mcp','core-runtime-chat-telemetry','root'],'evidence_rule':'Actual current source/exact assertion/wire or loader/privacy/bounds/command receipts; accepted reports only historical inputs'} for k,v in criteria.items()};dump(e/'prospective-criterion-test-plan.json',{'status':'prospective only before any product edit','criteria':plan,'initiative_to_aggregate_criteria':correspondence,'prospective_new_test_names':['test_friday_client_to_friday_stdio','test_friday_client_to_friday_http','test_runtime_yaml_to_friday_peer','test_chat_yaml_to_friday_peer','test_cross_transport_cancel_and_parallel_call','test_documented_yaml_profiles','test_documented_invalid_config_no_io','test_documented_public_api_fences','test_documented_profile_and_scope_matrix'],'required_variants':{'transport':['2026stdio','2026HTTPSJSON','2026HTTPSSSE'],'loaders':['RuntimeConfig.from_sources','real Friday Chat configuration/registry'],'yaml':['disabled','legacydefault','modernstdio','autostdio','HTTPS2026','explicitHTTPS2025','mixedfieldsinvalid','secretinterpolationinvalid','unsupportedtransport/profile'],'privacy':'synthetic sentinels absent from observer/diagnostics; handler counters and terminal ownership; no real state/model/provider'},'before_product_edits':'Builder must expand complete applicable client/server/2025 field/paragraph variants and actual snippet-to-assertion provenance; historical wrong-schema plan remains unchanged'})
contract=p/'up06-aggregate-contract.md';contract.write_text('''# UP-06 aggregate and migration contract

Status: Proposed; construction authority not granted. No product was changed.
Target remains the approved dated MCP2026-07-28 tools profile plus explicit
2025-11-25 HTTP client compatibility and retained2024 legacy APIs. This is the
final whole-initiative verification slice, not a protocol/dependency redesign.

## Current authority and baseline

[UP-05 acceptance](acceptance/MCP-UP-05.json) records “accepted, continue” and
closes the server unit with all five findings resolved. The complete acceptance
chain is frozen in [accepted baseline](execution/up06-planning/accepted-baseline.json).
All original authority/approval/report bytes remain immutable. AGENTS and
engineering/lifecycle/independent-validation policies control; every new test or
product documentation change waits for exact CD-MCP-UP-006 approval.

Aggregate diff starts at accepted telemetry merge `'''+branchbase+'''`;
UP06 product baseline is all five accepted units at `'''+base+'''`.
The private sibling baseline omits267 tracked protected paths BEFORE checkout.
78 current accepted products and19 metadata are captured;75 accepted products
are frozen because only three accepted docs are in this unit's seven-path budget.
Historical accepted doc hashes remain receipts; newly approved UP06 doc changes
are explicitly prospective supersessions, never retroactive receipt edits.

## Seven-path boundary

Only README/index/client/server/migration documentation and one aggregate test
module may change. All existing source, tests/fixtures outside that one new file,
config templates/defaults/enums, package metadata/lock/dependencies/checkers,
telemetry providers/Core/Runtime/Chat/CLI/memory stay frozen. If actual cross-peer
or loader proof requires a runtime repair, extra fixture/path or effect, stop
and prepare a numbered bounded disposition; do not fix it inside this doc/test unit.
Existing named fixtures are sufficient counterpart candidates; if they prove
insufficient, report the exact gap instead of adding an implicit subprocess.

## Required combined behavior

Use actual Friday public clients with actual Friday modern server subprocesses:
newline stdio and verified private TLS JSON/request-scoped SSE. Named synthetic
`tests_mcp/fixtures/friday_modern_tools_server.py` provides echo/hold/fail and
counter-based handler/terminal proof. Keep accepted independent official SDK
client/server and deterministic legacy/2025 counterpart suites, never replace
that proof with a self-pair. Explicit2025 uses its accepted compatibility peer;
it is not a modern Friday server capability. No auto HTTP fallback/replay.

Connect real Runtime YAML/provider and real Chat YAML/registry paths to those
Friday peers. Load the YAML with current public schemas, not hand-constructed
fake registries. Use canonical tool names, filters/category admission and budgets,
structured Unicode results and accepted provenance/sanitization/memory defaults.
Runtime/Chat testing may keep model/storage services inert via existing testing
seams; no model call, native user tool or real persistence. Assert required/optional
startup disposition and disabled/invalid config causes zero factory/network I/O.
TLS helpers may inject a synthetic CA at the existing accepted test seam; production
verification flags/defaults must remain unchanged. Port/address grants stay
explicit fixture entries, not a public network policy relaxation.

At least one issued held call and an unrelated call in each transport demonstrate
cancellation/timeout isolation, zero mutating replay, completed handler counters,
owner/child exit and retryable shutdown semantics. Existing resistant-owner,
first-byte-frame/deadline and five numbered header/lifecycle mitigation tests remain
mandatory. Do not weaken asserted error categories, IDs, metadata/cache fields,
capabilities, limits or accepted cancellation behavior for a convenient self-pair.

Provider-neutral borrowed observers stay open; no exporter/global environment,
trace/baggage propagation or raw content/credential/schema/session/URL diagnostic
change. Existing server-spy tests remain server-specific observation evidence;
new client/Runtime/Chat spies need not alter a frozen subprocess fixture.

## Documentation and exact example proof

Add a migration guide and update root/package README, guide index, client/server
guides. Reconcile the early legacy-only HTTP paragraph and old unit-interim claims;
do not rewrite historical approved plan/capture/report text. Show exact
`tools.providers.mcp.config.servers` location and global security pair, current
strict transport union, local legacy default versus explicit modern/auto,
HTTPS explicit2026/2025, supplied credential environment REFERENCE, required/optional
peer and include/category selection, privacy/memory/budgets and shutdown ownership.
The configuration happens in YAML; describe only currently supported CLI options.
New modern server APIs are programmatic; legacy `stdio`/`sse` server config enums
are not upgraded automatically. Explain separate server role/security/bind policy,
2026 single POST JSON/SSE versus old HTTP+SSE, unsupported OAuth/interactive/agent
roles and no public-server deployment or live provider proof.

Test the exact published YAML/code fences. Archive original excerpts/source lines,
then only replace a listed interpreter/fixture/cwd/port/CA/synthetic credential
placeholder. Use RuntimeConfig.from_sources and real Chat loader. Disabled and
invalid cases must not perform I/O. Public URI examples remain inert placeholders;
actual execution uses only synthetic private peers. Compile Python fences and
verify exported constructors/keywords; running a documented server/tool example
requires named fixture execution and counter/teardown proof, not compile-only
claims. Associate prose/profile matrix with current source and accepted profile tests.

Explain upgrade/rollback of explicit configuration/profile choices and retaining
legacy compatibility; never migrate/clean user stores, overwrite user's config,
or invent automated protocol/session fallback. Pin Python>=3.13.4, SDK/mcp-types2.3.0
as DEV counterpart, runtime jsonschema/referencing and accepted IDNA3.20 decision;
exact locked edge/artifact proof remains the existing authority. No new dependency
installation/sync/version churn, environment changes or mandatory Langfuse binding.

## Full aggregate evidence and closure

All24 [profile commands](verification-profile-UP-06.json) and exact baseline
comparisons are required. Before the first and after the last required/supplemental
check, rehash actual22009 inventory references/21992 unique paths/192 distributions
from original manifests. Retain exact complete327 normalized Ruff diagnostic/fix
objects, four Mypy path/line/column/severity/code/message objects, full warnings
and nine grouped skip location/reason rows representing14 tests. No counts-only,
checker weakening, new waiver or hidden infrastructure skip. New skips/warnings
or metadata/source/effect drift require reconciliation before completion.

Builder prospectively expands every applicable2026 client/server and2025 client
clause/field/omitted/null/error/privacy/bounds variant and maps all eight initiative
criteria; final actual mapping cites current source/excerpts/tests/assertions/raw
commands. Use all frozen full captures and corrected modern schema plan. A version
string, SDK acceptance, total test count or earlier unit acceptance is not whole
conformance. Explicit optional-role exclusions and documented SHOULD tradeoffs
remain; a mandatory requirement within the declared profile cannot be waived by
calling it unsupported. SDK tracing/caching/retry defaults are not Friday authority.

Commit stable exact-scope candidate; fresh-context read-only validator reviews the
whole feature diff, all five earlier units/interactions and new docs/tests, with
all12 aggregate and eight initiative criteria. Reviewer probes and full before/after
source/control/library snapshots supplement existing ledgers. Preserve original
reports, failed attempts and safe raw evidence; never let builder self-VERIFY.
After VERIFIED controller may propose whole initiative completed/local using a
review-packet index/closeout report linked to immutable active historical authority
and unit archives. Do not move/rehash frozen originals. This preserves canonical
packet-location progression while retaining original authority paths. Maintainer
whole acceptance later archives the current closeout index; delivery/publication
and Langfuse remain separate. No automatic acceptance/merge/release.

## Effects and stop conditions

Unchanged guard and frozen private environment; only accepted named synthetic
stdio SDK/legacy/Friday fixtures, literal127 private verifiedTLS SDK/2025/Friday
fixtures, deterministic peers/ASGI and retained guarded broad/root synthetic
stores/artifacts. Fresh per-command HOME/TMP/checker caches; approved ignored
relative-CWD fixture outputs are retained/disclosed, not all-files-equality targets.
No real user state/keys/providers/public DNS/nonloopback network/service exposure.
TLS keys/runtime stores/HOME/cache/bytecode/.git excluded from explicit safe archive.
Known loopback sandbox escalation may be used; no OS denial needs reenactment.
Unexpected effect, scope/dependency/source drift, undocumented real CLI/API gap or
mandatory conformance failure stops construction. Remediation is bounded and
separately authorized when needed; after two unsuccessful cycles stop for maintainer.
''')
profile={'initiative':'friday-mcp-protocol-upgrade','unit':'MCP-UP-06','directive':'CD-MCP-UP-006','status':'proposed/not_granted','candidate_snapshot':str(w),'baseline_snapshot':str(b/'up06-baseline'),'product_baseline':base,'aggregate_branch_base':branchbase,'required_checks':checks,'guard':request['guard'],'environment':'Reuse private Python3.13.10/SDK2.3.0/IDNA3.20; no installs/sync; frozen allowlisted guard; telemetry/exporters off, unique per-command HOME/TMP/Mypy/Ruff/pytest caches','library_integrity':{'inventory_references':22009,'unique_paths':21992,'distributions':192,'inputs':{str(b/n):h(b/n) for n in ['reused-library-manifest.json','additional-validation-libraries.json']},'rule':'Actual hashes strictly before first and after LAST required/supplemental checks; every expected hash matches;17 identical overlapping references explained'},'baseline_diagnostics':{'root_ruff':327,'full_mypy':4,'mypy_columns':['77:9','82:9','110:9','115:9'],'skips':14,'grouped_skip_rows':9,'warnings':15,'rule':'Exact complete diagnostics/fix objects/full warning sections/skip location-reason rows equal fresh all-five-unit accepted baseline; raw inheritedexit1 retained, no new waiver'},'permitted_effects':request['permitted_effects'],'effect_context_exception':'Retained approved ignored private relative-CWD fixture stores/artifacts do not invalidate GOVERNED TRACKED read-only equality; preserve/disclose, no cleaning or redundant full-profile rerun','required_additional_inspections':['All78 accepted current product paths and19 metadata;75 frozen products outside exact7 path budget','Complete earlier product delta from1302b5f plus7-path UP06 delta, all12 aggregate and8 initiative criteria','Exact snippet/YAML/public API/fixture/real loader provenance with original and substituted excerpts','All applicable client/server2026 and explicit2025 normative fields/clauses/null/absent/errors/privacy/bounds, current corrected schema, unsupported roles','All5 original server findings and accepted client/runtime/header/result/lifecycle/privacy regressions','Actual full library/controls/source before/after and lossless explicit safe artifacts excluding runtime/private keys','Fresh independent whole-initiative aggregate VERIFIED before completion proposal; acceptance and publication separate']};pf=p/'verification-profile-UP-06.json';dump(pf,profile)
rows='\n'.join('| '+k+' | '+v+' |' for k,v in criteria.items());directive=p/'directives/CD-MCP-UP-006-aggregate-migration-closeout.md';directive.write_text('''# CD-MCP-UP-006: MCP migration and whole-initiative aggregate verification

Status: **Proposed; exact maintainer construction approval pending**.
Initiative: friday-mcp-protocol-upgrade. Work unit: MCP-UP-06.

[UP-05 acceptance](../acceptance/MCP-UP-05.json) records “accepted, continue” at
its explicitly named acceptance gate. It authorizes this preparation. The
[aggregate contract](../up06-aggregate-contract.md), [exact24-command profile](../verification-profile-UP-06.json)
and [hashed proposal](../proposals/UP-06-authority-manifest.json) bind the next
construction slice; existing whole-initiative started/granted state does not
authorize new paths before this directive is approved. Original authorities,
reports, approval/acceptance receipts and source captures remain immutable.

## Objective and exact seven-path scope

Complete accurate migration/docs and cross-Friday client/server and real
Runtime/Chat examples, then a fresh independent whole-feature aggregate result
for every applicable mandatory rule of pinned MCP2026-07-28 tools roles, explicit
2025-11-25 HTTP client compatibility and retained2024 APIs. Every approved build
criterion UP-AC-01..08 must have current evidence; this is not a blanket OAuth or
optional-extension claim. Existing runtime implementation and dependencies stay
frozen. Baseline: `'''+base+'''`; aggregate base:
`'''+branchbase+'''`. Existing MCP feature branch/private environment.

'''+''.join('- `'+x['path']+'` ('+x['change']+' '+x['kind']+')\n' for x in product)+'''

Five existing docs, one new migration guide and one new aggregate test module.
Only product docs may reconcile earlier current-user guidance; no frozen approved
packet/receipt is rewritten. No existing production source, test/fixture, template,
YAML enum/default, metadata/lock/checker/provider/memory/CLI path may change. A
necessary runtime fix or extra fixture/path stops this unit for a bounded disposition.
Process state/log/board/dashboard, authority/receipt/ledger/review/archive and final
review-packet index are separately scoped governance/evidence paths, never product
source authorization. No live service/publication or user-config edits.

## Implementation and verification sequence after approval

1. Read board validate/next/show, approved exact authority/receipt and current
   branch/state; verify protected75 products/19 metadata/controls/library pins.
2. Freeze complete prospective role/field/clause and snippet/variant/test/assertion
   plan. Read current public APIs and all pinned captures; old wrong-schema plan
   is historical only. Actual final mapping must reflect new docs/tests and current
   accepted implementation, not copied PASS labels.
3. Build only the seven approved paths. Test actual Friday client/server stdio and
   verified TLS JSON/SSE using existing named fixtures, plus real YAML Runtime/Chat
   assembly. Retain official independent SDK/older counterpart proof. Compile/load
   exact documented examples, original-to-synthetic placeholder provenance and no-I/O
   negatives. No real model/native tools/stores, credentials, public peers or retry.
4. Prove lifecycle/result/privacy/provenance/legacy/default interoperability and
   all five prior server fixes; reconcile stale current README/index guidance.
5. Run all24 exact checks and complete baseline comparisons with strict actual
   before/after libraries/source/control hashes; retain every failed attempt.
6. Commit stable candidate plus final actual mappings/evidence; fresh read-only
   whole-feature aggregate validator reviews all12 aggregate/all8 initiative
   criteria and all earlier accepted interactions. VERIFIED before completion.
7. Controller prepares completed/local whole-initiative review index and closeout
   evidence after VERIFIED, retaining frozen original authority paths. Only new
   maintainer whole acceptance closes the initiative; publication/merge/release and
   Langfuse remain separately authorized.

## Acceptance criteria

| Criterion | Required behavior and proof |
| --- | --- |
'''+rows+'''

## Stops and exclusions

No dependency upgrades/install/sync, checker weakening/suppression/cast workaround,
new production path or role/default, OAuth/sampling/roots/elicitation/Tasks/agent/
resource/prompt exposure, adaptive tool continuity/config includes, Langfuse/provider
binding, secret/user-store access/cleanup or public deployment. New mandatory failure,
effect/scope/metadata/source drift or insufficient fixture stops implementation;
report exact finding and mitigation budget. No opportunistic repairs. Applicable
separate remediator/fresh validator policy and two-unsuccessful-cycle stop apply.

This packet is a concrete planning proposal, not source construction approval,
product VERIFIED, initiative acceptance or delivery authority.
''')
controls=[pin(w/f) for f in ['AGENTS.md','docs/reference/policies/repository-engineering-policy.md','docs/reference/policies/development-task-lifecycle.md','docs/reference/policies/independent-validation-policy.md']]
controls += [pin(p/n) for n in ['README.md','build-plan.md','tactical-plan.md','protocol-contract.md','conformance-matrix.md','research.md','research-sources/manifest.json','up03-integration-contract.md','up04-results-refresh-contract.md','up05-server-contract.md'] if (p/n).is_file()]
controls += fixed_controls + [pin(p/n) for n in sorted(prior)]
controls += request['controls']+[request['authority_manifest'],request['original_authority'],request['verification_profile']]
controls += [pin(x) for x in [contract,pf,directive,e/'accepted-baseline.json',e/'aggregate-branch-inventory.json',e/'prospective-criterion-test-plan.json']]
unique={x['path']:x for x in controls};controls=list(unique.values())
for row in controls:req(h(w/row['path'])==row['sha256'],'Control hash mismatch')
manifest={'initiative':'friday-mcp-protocol-upgrade','work_unit':'MCP-UP-06','directive':'CD-MCP-UP-006','status':'proposed','implementation_authority':'not_granted','approval':None,'branch':'feature/friday-mcp-protocol-upgrade','product_baseline':base,'aggregate_branch_base':branchbase,'product_paths':product,'acceptance_criteria':criteria,'initiative_to_aggregate_criteria':correspondence,'required_checks':checks,'current_accepted_product_hashes':accepted,'preserved_product_hashes':protected,'metadata_hashes':metadata,'controls':controls,'prior_frozen_manifests':[{'path':str((p/n).relative_to(w)),'sha256':d} for n,d in sorted(prior.items())],'accepted_units':units,'full_branch_product_delta_paths':branch_paths,'full_review_scope':'Complete feature delta from accepted telemetry merge plus exact UP06 seven paths; all declared2026 client/server/2025compat roles, every applicable requirement and all accepted security/telemetry semantics','baseline_snapshot':{'path':str(b/'up06-baseline-snapshot.json'),'sha256':h(b/'up06-baseline-snapshot.json'),'head':base,'omitted_protected_paths':267},'guard':request['guard'],'runner':{'original_UP05_path':str(b/'run_check_UP05.py'),'original_UP05_sha256':h(b/'run_check_UP05.py'),'UP06_path':str(b/'run_check_UP06.py'),'rule':'New explicit UP06 freeze/current and full-scope source hashes; unchanged guard/environment/checker flags; fresh per-command output/HOME/TMP/cache; no original runner edits'},'library_integrity':profile['library_integrity'],'permitted_effects':request['permitted_effects'],'governance_process_paths':['docs/planning/active/friday-mcp-protocol-upgrade/','docs/planning/board.yaml','docs/planning/README.md','docs/planning/review/friday-mcp-protocol-upgrade/ (controller completion proposal only afterVERIFIED)','docs/archive/completed/2026/friday-mcp-protocol-upgrade/ (whole maintainer acceptance only)'],'construction_stop':'Exact CD006 approval required before seven product paths; source/dependency/fixture/effect change requires bounded disposition','retained_source_authority':'All earlier approved source contracts/pins/decisions and immutable accepted reports; no construction or waiver broadened by closeout','review_request_requirements':'Stable candidate/exact whole-feature diff/controls/source maps/all12+8criteria/check/effect baseline; fresh-context read-only aggregate verdict; exact safe lossless evidence; no builder reasoning or self-verification'}
mp=p/'proposals/UP-06-authority-manifest.json';dump(mp,manifest)
# New runner keeps the original guard/allowlist/checker settings and adds UP06 pins;
# original runners/guard are copied only as archived inputs, never modified.
original=(b/'run_check_UP05.py').read_text();runner_text=original.replace("output.mkdir(parents=True, exist_ok=True)","output.mkdir(parents=True, exist_ok=False)")
runner_text=runner_text.replace("label, snapshot, *argv = sys.argv[1:]", "label, snapshot, *argv = sys.argv[1:]\nif snapshot not in {'work','up06-baseline'}: raise RuntimeError('Invalid UP06 snapshot')")
runner_text=runner_text.replace("'TMPDIR': str(base / 'tmp')", "'TMPDIR': str(base / 'tmp' / label)").replace("(base / 'tmp').mkdir(exist_ok=True)", "(base / 'tmp' / label).mkdir(parents=True, exist_ok=False)")
start=runner_text.index('profile_path = work / ');end=runner_text.index('started = datetime.now',start)
runner_text=runner_text[:start]+'''profile_path = base / 'work/docs/planning/active/friday-mcp-protocol-upgrade/authority-UP-06.json'
if not profile_path.is_file():
    profile_path = base / 'work/docs/planning/active/friday-mcp-protocol-upgrade/proposals/UP-06-authority-manifest.json'
profile = json.loads(profile_path.read_text())
source_paths = sorted(set(profile['current_accepted_product_hashes']) | {x['path'] for x in profile['product_paths']})
source_hashes = {x: hashlib.sha256((work/x).read_bytes()).hexdigest() if (work/x).is_file() else None for x in source_paths}
controls = profile['controls'] + profile['prior_frozen_manifests']
if profile.get('approval'): controls.append(profile['approval'])
preflight = {'argv': argv, 'environment': environment, 'source_hashes': source_hashes,
 'candidate_commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
 'authority_sha256': hashlib.sha256(profile_path.read_bytes()).hexdigest(),
 'authority_path': str(profile_path),
 'control_hashes': {x['path']: hashlib.sha256((base/'work'/x['path']).read_bytes()).hexdigest() for x in controls},
 'metadata_hashes': {x: hashlib.sha256((work/x).read_bytes()).hexdigest() for x in profile['metadata_hashes']},
 'preserved_product_hashes': {x: hashlib.sha256((work/x).read_bytes()).hexdigest() for x in profile['preserved_product_hashes']},
 'UP05_runner_sha256': hashlib.sha256((base/'run_check_UP05.py').read_bytes()).hexdigest(),
 'UP06_runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'guard_sha256': hashlib.sha256((base/'guard/sitecustomize.py').read_bytes()).hexdigest()}
(output / 'preflight.json').write_text(json.dumps(preflight,indent=2)+'\\n')
''' +runner_text[end:]
rf=b/'run_check_UP06.py';req(not rf.exists(),'Runner overwrite');rf.write_text(runner_text);manifest['runner']['UP06_sha256']=h(rf);dump(mp,manifest)
state.update(unit='MCP-UP-06',execution_phase='planning',validation_state='not_ready',unit_completion='not proposed; exact CD006 construction approval pending',construction_directive='CD-MCP-UP-006',directive_status='proposed',unit_implementation_authority='not_granted',prior_unit_reviewed_candidate='012430089bcd1b60b12c071b8c8220f20d2bac79',prior_unit_independent_report='docs/planning/active/friday-mcp-protocol-upgrade/validation/VAL-UP05-03/report.md',prior_unit_acceptance='docs/planning/active/friday-mcp-protocol-upgrade/acceptance/MCP-UP-05.json',next_directive=str(directive.relative_to(w)),proposal_manifest=str(mp.relative_to(w)),current_execution_authority=None,remediation_status='not_applicable',remediation_implementation_authority='closed',remediation_directive=None,open_findings=[],prior_unsuccessful_remediation_cycles=0,prior_finding_disposition={},next_gate='Review and approve exact CD-MCP-UP-006 seven-path migration/docs and cross-Friday aggregate tests;24 checks plus fresh full-initiative review; no new product authority yet',note='All five earlier units accepted. UP06 proposal prepared only; dated target/defaults/source/dependencies frozen; whole initiative started/local and Langfuse queued')
for obsolete in ['builder_product_candidate','reviewed_candidate','independent_report','independent_report_sha256','remediation_proposal','remediation_product_candidate','pending_amendment','construction_stop','amendment_status']:state.pop(obsolete,None)
dump(sf,state)
log=p/'execution-log.md';log.write_text(log.read_text()+'\n\n## UP-06 migration and whole-initiative aggregate proposal\n\nAll five prior units are accepted. New exact CD006 proposes seven paths: five\ncurrent docs, a migration guide and a cross-Friday client/server/real YAML test\nmodule.75 accepted products/all19 metadata frozen; no runtime source, dependency\nor default/role change.12 aggregate criteria map all8 initiative criteria;24\nexact commands include prior functional/typed/debt gates plus new aggregate and\nexact documented examples. Accepted-baseline sibling excludes267 protected paths\nbefore checkout; fresh new UP06 runner pins whole source/current controls under\nunchanged guard/private per-command context. Original five-unit reports and\nmodern/older primary authority remain immutable. Whole-feature fresh independent\nVERIFIED precedes completion proposal; maintainer whole acceptance/publication\nare separate. Exact CD006 approval required before new docs/tests.\n')
spec=importlib.util.spec_from_file_location('board',w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);board=m.load_board(w);t=next(x for x in board['tasks'] if x['id']=='friday-mcp-protocol-upgrade');t['next_gate']=state['next_gate'];m._append_event(board,task_id=t['id'],actor='Codex controller',actor_role='agent',action='prepared CD-MCP-UP-006 aggregate migration proposal',note='Seven paths/12 criteria/all8 initiative criteria/24 checks; source and dependencies frozen; exact construction approval pending',evidence=str(directive.relative_to(w)));m._save_board_and_dashboard(board,w)
for key,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show',t['id']],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 label='up06-planning-'+key;req(not (b/'checks'/label).exists(),'Check reuse');subprocess.run([py,str(rf),label,'work',py,*args],check=True);req(json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']==0,'Planning check failed')
items=[]
def archive(name,raw):
 f=e/'artifacts'/(name+'.gz');req(not f.exists(),'Archive overwrite');f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(gzip.compress(raw,mtime=0));items.append({'original_path':name,'path':str(f.relative_to(e)),'encoding':'gzip','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(f)})
for folder in sorted((b/'checks').glob('up05-accepted-*'))+sorted((b/'checks').glob('up06-planning-*')):
 for name in ['preflight.json','receipt.json','stdout','stderr']:archive('process-checks/'+folder.name+'/'+name,(folder/name).read_bytes())
for name in ['accept_up05_prepare_up06.py','prepare_up06_packet.initial.py','up06-planning-initial-attempt.json','prepare_up06_packet.py','prepare_up06_baseline.py','up06-baseline-snapshot.json','run_check_UP06.py','run_check_UP05.py','run_check_UP04.py','run_check.py']:archive('controller-inputs/'+name,(b/name).read_bytes())
archive('controller-inputs/guard-sitecustomize.py',(b/'guard/sitecustomize.py').read_bytes());archive('controller-inputs/UP06-runner-change.diff',subprocess.run(['diff','-u',str(b/'run_check_UP05.py'),str(rf)],capture_output=True,check=False).stdout)
summary={'status':'Planning checks only; no product source/docs/tests edited, no conformance result','product_baseline':base,'aggregate_branch_base':branchbase,'accepted_units':5,'product_budget':7,'existing_docs':5,'new_docs':1,'new_test_modules':1,'aggregate_criteria':12,'initiative_criteria':8,'required_commands':24,'accepted_product_inventory':78,'accepted_products_frozen':75,'metadata_frozen':19,'protected_paths_omitted_before_baseline_checkout':267,'new_runner_sha256':h(rf),'original_guard_sha256':h(b/'guard/sitecustomize.py'),'planned_diagnostics':{'Ruff':327,'Mypy':4,'skips':14,'warnings':15},'proposal_sha256':h(mp),'product_edits':0};dump(e/'summary.json',summary);dump(e/'stored-manifest.json',{'artifacts':items,'boundary':'Lossless safe process-only acceptance/planning checks/controller scripts/baseline path-name isolation proof; no generated private runtime/key artifacts; not product validation'})
(e/'report.md').write_text('# UP-06 planning checkpoint\n\nStatus: concrete proposal; no product construction authority or product VERIFIED.\n\nUP-05 is accepted by Chuck Russell. All five accepted units and original reports/\ncontrols remain immutable. CD006 proposes7 product paths/12 aggregate criteria\ncovering8 initiative criteria/24 exact checks;75 accepted products and19 metadata\nfrozen. The planned tests combine actual Friday client/server with real Runtime/\nChat loaders and exact documented example proof. Existing independent SDK and\nlegacy/2025 peers remain required. [Directive](../../directives/CD-MCP-UP-006-aggregate-migration-closeout.md),\n[contract](../../up06-aggregate-contract.md), [profile](../../verification-profile-UP-06.json),\n[proposal manifest](../../proposals/UP-06-authority-manifest.json), [prospective plan](prospective-criterion-test-plan.json),\n[branch inventory](aggregate-branch-inventory.json) and [summary](summary.json)\nare reviewable. [Safe process evidence](stored-manifest.json) retains exact board,\ndocs lifecycle and dashboard checks, acceptance/planning scripts and new runner\ndiff. The sibling accepted baseline omits267 protected paths before checkout.\nOriginal runner/guard/libraries remain unchanged; no install/public peer/provider/\nuser store or source/default change. Seven unrelated root paths and two-task/\nthree-event board overlay are preserved for local transfer.\n\nNext gate: exact maintainer CD006 approval. Whole aggregate validation/acceptance,\npublication and Langfuse remain separate. Historical unit conformance/test counts\nare not current aggregate proof.\n')
for path,d in (accepted|metadata).items():req(h(w/path)==d,'Product changed during planning')
for row in controls:req(h(w/row['path'])==row['sha256'],'Control drift after planning')
for x in product:req(h(w/x['path'])==x['baseline_sha256'],'Premature product construction')
for a in items: req(hashlib.sha256(gzip.decompress((e/a['path']).read_bytes())).hexdigest()==a['sha256'],'Stored evidence drift')
paths_to_stage=[str(x.relative_to(w)) for x in [directive,contract,pf,mp,e,sf,log]]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths_to_stage],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Prepare bounded MCP migration and aggregate verification directive'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(json.dumps({'proposal_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),**summary}))
