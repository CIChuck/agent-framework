import gzip
import hashlib
import json
from pathlib import Path

base = Path('/private/tmp/friday-mcp-upgrade/work/docs/planning/active/friday-mcp-protocol-upgrade/execution/idna-regression')
path = base / 'manifest.json'
manifest = json.loads(path.read_text())
for item in manifest['files']:
    if not item['path'].endswith('.py'):
        continue
    source = base / item['path']
    data = source.read_bytes()
    if hashlib.sha256(data).hexdigest() != item['sha256']:
        raise RuntimeError('Historical process evidence changed')
    encoded = gzip.compress(data, mtime=0)
    target = source.with_name(source.name + '.gz')
    target.write_bytes(encoded)
    source.unlink()
    item['path'] = target.name
    item['sha256'] = hashlib.sha256(encoded).hexdigest()
    item['bytes'] = len(encoded)
    item['encoding'] = 'gzip'
manifest['storage_note'] = 'Lossless compression of original executed process-script evidence, preserving original bytes and SHA256. Archived evidence is not executable repository source; no raw script rewriting or lint waiver.'
path.write_text(json.dumps(manifest, indent=2) + '\n')
