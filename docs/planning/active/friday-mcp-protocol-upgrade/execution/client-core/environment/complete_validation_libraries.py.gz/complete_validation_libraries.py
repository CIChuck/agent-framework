import hashlib
import importlib.metadata
import json
import shutil
import sysconfig
import tomllib
from pathlib import Path

out = Path('/private/tmp/friday-mcp-upgrade')
source = Path(sysconfig.get_paths()['purelib']).resolve()
destination = out / 'venv/lib/python3.13/site-packages'
lock = tomllib.loads((out / 'work/uv.lock').read_text())
versions = {}
for package in lock['package']:
    versions.setdefault(package['name'], set()).add(package['version'])
added = []
for distribution in importlib.metadata.distributions():
    name = distribution.metadata['Name'].lower().replace('_', '-')
    if (destination / distribution._path.name).exists() or distribution.version not in versions.get(name, set()):
        continue
    files = []
    workspace = any(p['name'] == name and 'editable' in p['source'] for p in lock['package'])
    for file in distribution.files or []:
        path = Path(distribution.locate_file(file)).resolve()
        if not path.is_relative_to(source) or path.suffix == '.pyc':
            continue
        relative = path.relative_to(source)
        if workspace and relative.parts[0] != distribution._path.name:
            continue
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            raise RuntimeError('Validation library copy mismatch')
        files.append({'path': str(relative), 'sha256': digest})
    added.append({'name': name, 'version': distribution.version, 'workspace_metadata_only': workspace, 'files': files})
(out / 'additional-validation-libraries.json').write_text(json.dumps({'added': added, 'purpose': 'Reproduce installed locked regression-library set and existing workspace version metadata. No editable .pth links; source resolution exclusively isolated PYTHONPATH.'}, indent=2) + '\n')
print(json.dumps({'additional_distributions': len(added)}))
