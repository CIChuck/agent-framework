"""Independent public-API 2025 recovery / failed explicit refresh overlap."""
import asyncio,json,importlib.util,sys
from pathlib import Path
from friday_mcp.client.adapter import MCPToolAdapter
from friday_mcp.client.protocol import ProtocolLimits
p=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/tests_mcp/client/test_http_lifecycle.py')
spec=importlib.util.spec_from_file_location('review_http_helpers',p);mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
async def main():
 peer=mod.Peer(version='2025-11-25');client,_,_=mod.make_client(peer,limits=ProtocolLimits(concurrent_requests=1));facts={};gate=asyncio.Event();started=asyncio.Event()
 await client.connect();old=(await MCPToolAdapter(client).get_tools())[0]
 def hook(verb,headers,message):
  if message.get('method')=='initialize':
   started.set();return peer.rpc(message,{'protocolVersion':'2025-11-25','capabilities':{'tools':{}},'serverInfo':{'name':'review','version':'1'}},stall=gate)
  return None
 peer.hook=hook;peer.expire_once=True
 running=asyncio.create_task(old.execute())
 await started.wait()
 pending=asyncio.create_task(client.refresh_tool_catalog());await asyncio.sleep(0)
 try:await client.refresh_tool_catalog()
 except Exception as ex:facts['rejected_refresh']=getattr(ex,'failure_code',type(ex).__name__)
 try:await pending
 except Exception as ex:facts['owned_refresh_failure']=getattr(ex,'failure_code',type(ex).__name__)
 facts['snapshot_before_recovery_settles']=client.current_catalog_snapshot is not None
 gate.set()
 try:await running
 except Exception as ex:facts['original_call_failure']=getattr(ex,'failure_code',type(ex).__name__)
 facts['snapshot_after_recovery_settles']=client.current_catalog_snapshot is not None
 before=peer.methods().count('tools/call')
 try:facts['new_direct_value']=await client.call_tool('echo',{})
 except Exception as ex:facts['new_direct_failure']=getattr(ex,'failure_code',type(ex).__name__)
 facts['new_direct_mutating_calls']=peer.methods().count('tools/call')-before
 await client.disconnect();facts['remaining_owners']=client.outstanding_http_owners+client.outstanding_catalog_owners
 print(json.dumps(facts,indent=2))
asyncio.run(main())
