"""Read-only candidate audit and builder evidence; no product/process mutation."""
import ast
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path

BASE = Path('/private/tmp/friday-mcp-upgrade')
WORK = BASE / 'work'
OUT = BASE / 'rem005-builder-evidence'
PACKET = WORK / 'docs/planning/active/friday-mcp-protocol-upgrade'
CANDIDATE = 'a9c913e41cdbd5bd824f36fe7b15001e6c126e17'
EXECUTION_BASE = '447b75cb3bb837466a459fbcf9c7f45bf047d162'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK, text=True)


assert git('rev-parse', 'HEAD').strip() == CANDIDATE
assert git('status', '--porcelain') == ''
authority = json.loads((PACKET / 'authority-REM-MCP-UP-005.json').read_text())
allowed = [item['path'] for item in authority['product_paths']]
changed = git('diff', '--name-only', EXECUTION_BASE, CANDIDATE).splitlines()
assert set(changed) == set(allowed)
products = []
for path, previous in authority['all_original_up04_product_hashes'].items():
    actual = digest(WORK / path)
    if path not in allowed:
        assert actual == previous, path
    products.append({'path': path, 'baseline_sha256': previous,
                     'candidate_sha256': actual, 'authorized_change': path in allowed})
metadata = []
for path, expected in authority['metadata_hashes'].items():
    actual = digest(WORK / path)
    assert actual == expected, path
    metadata.append({'path': path, 'sha256': actual})
controls = []
for item in (authority['controls'] + authority['prior_frozen_manifests']
             + [authority['approval'], authority['approved_proposal']]):
    assert digest(WORK / item['path']) == item['sha256'], item['path']
    controls.append(item)
assert digest(BASE / 'guard/sitecustomize.py') == (
    '38f6a7483d66a066336d63c14980f1acfe307ec38848f0761c6928a66989a7a8')
assert digest(BASE / 'run_check_UP04.py') == (
    '5e5c9901bf66117ee11669d32de857ea2087738add9eef3c7ae6aa6f3c8592a6')
write('scope-preservation.json', {
    'candidate': CANDIDATE, 'execution_base': EXECUTION_BASE,
    'reviewed_base': authority['reviewed_baseline'], 'scope_exact': True,
    'changed_paths': changed, 'products': products, 'metadata': metadata,
    'current_controls': controls,
    'all_other_repository_paths_unchanged_since_approved_execution_base': True,
    'guard_sha256': digest(BASE / 'guard/sitecustomize.py'),
    'UP04_runner_sha256': digest(BASE / 'run_check_UP04.py'),
    'private_runner_sha256': digest(OUT / 'run_check.py'),
})
(OUT / 'candidate.diff').write_text(git('diff', EXECUTION_BASE, CANDIDATE))
(OUT / 'candidate-head').write_text(CANDIDATE + '\n')
(OUT / 'candidate-status').write_text(git('status', '--short', '--branch'))

captures = []
for manifest in [PACKET / 'research-sources/manifest.json',
                 PACKET / 'research-sources/up02b/manifest.json',
                 PACKET / 'research-sources/up04/manifest.json']:
    for item in json.loads(manifest.read_text())['sources']:
        artifact = manifest.parent / item['artifact']
        full = gzip.decompress(artifact.read_bytes())
        assert digest(artifact) == item['artifact_sha256']
        assert hashlib.sha256(full).hexdigest() == item['sha256']
        assert len(full) == item['bytes']
        captures.append({'path': str(artifact.relative_to(WORK)),
                         'compressed_sha256': digest(artifact),
                         'complete_sha256': item['sha256'], 'complete_bytes': len(full)})
assert len(captures) == 19
write('normative-capture-integrity.json', {'captures': captures,
    'purpose': 'Complete byte/hash integrity; no new protocol grammar or capability claim'})

check_results = {}
for receipt in sorted((OUT / 'checks').glob('*/receipt.json')):
    value = json.loads(receipt.read_text())
    for name in ['stdout', 'stderr']:
        assert digest(receipt.parent / name) == value[name + '_sha256']
    check_results[receipt.parent.name] = {'receipt': str(receipt.relative_to(OUT)),
        'exit_code': value['exit_code'], 'argv': value['argv']}
required = ['pre-board', 'pre-next', 'pre-show', 'focused-final', 'ruff-final',
            'narrow-mypy', 'mcp-mypy', 'recovery-overlap',
            'recovery-budgets-corrected-assertion', 'original-constructor',
            'original-instance', 'original-supplemental', 'collect-recovery-matrix']
assert all(check_results[name]['exit_code'] == 0 for name in required)
for name in ['focused-final', 'ruff-final', 'narrow-mypy', 'mcp-mypy']:
    frozen = json.loads((OUT / 'checks' / name / 'preflight.json').read_text())
    assert all(frozen['source_hashes'][path] == digest(WORK / path) for path in allowed)
write('checks-summary.json', {'checks': check_results,
    'focused': '1511 passed; all67 new public recovery variants executed',
    'regression_pre_formatting': '946 passed; only formatting wraps followed',
    'failed_attempts': {'ruff1': 'six E501 lines, corrected without assertion change',
        'recovery-budgets-original': 'unchanged historical assertion expects unsafe1; intentional negative expected result'},
    'pending_controller': 'Full20 stable-commit profile, complete debt/skip/warning/library comparisons and independent review'})

facts = json.loads((OUT / 'checks/recovery-overlap/stdout').read_text())
expected = {'rejected_refresh': 'limit_exceeded', 'owned_refresh_failure': 'RuntimeError',
    'snapshot_before_recovery_settles': False, 'original_call_failure': 'invalid_protocol',
    'snapshot_after_recovery_settles': False, 'new_direct_failure': 'catalog_unavailable',
    'new_direct_mutating_calls': 0, 'remaining_owners': 0}
assert facts == expected
budgets = json.loads((OUT / 'checks/recovery-budgets-corrected-assertion/stdout').read_text())
assert [item['budget'] for item in budgets] == [1, 2, 3, 4]
assert all(item['new_direct_failure'] == 'catalog_unavailable'
    and item['new_direct_mutating_calls'] == 0 and item['remaining_owners'] == 0
    and item['all_streams_closed'] for item in budgets)
for name in ['original-constructor', 'original-instance']:
    old = json.loads((OUT / 'checks' / name / 'stdout').read_text())
    assert old['second_failure'] == 'limit_exceeded'
    assert old['snapshot_still_available'] is False
    assert old['old_wrapper_failure'] == 'catalog_unavailable'
    assert old['old_wrapper_mutating_calls'] == 0
supplemental = json.loads((OUT / 'checks/original-supplemental/stdout').read_text())
assert supplemental['old_wrapper_calls'] == supplemental['pending_after_disconnect'] == 0
for name, result in supplemental['input_required'].items():
    assert result['failure_code'] == ('input_required_unsupported'
        if name.startswith('valid_') else 'invalid_result')
    assert result['calls'] == 1
write('original-probe-comparison.json', {'original_overlap_exact_expected_facts': facts,
    'corrected_budget_facts': budgets,
    'old_probe_assertion_only_change': "new_direct_mutating_calls==1 to ==0; all other bytes preserved",
    'original_budget_assertion_exit': check_results['recovery-budgets-original']['exit_code'],
    'original_constructor_instance_supplemental_safe_outputs_checked': True})

test_path = 'packages/friday-mcp/tests_mcp/client/test_result_refresh.py'
tree = ast.parse((WORK / test_path).read_text())
functions = {node.name: {'path': test_path, 'line': node.lineno, 'end_line': node.end_lineno}
    for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
names = {
 'test_recovery_cannot_restore_catalog_retired_during_handshake': ['REC-01', 'REC-02'],
 'test_budget1_refresh_limit_before_recovery_capture_cannot_restore_admission': ['REC-03'],
 'test_recovery_refresh_failure_ordering_retains_no_stale_raw_admission': ['REC-03', 'REC-04'],
 'test_ordinary_recovery_preserves_only_prior_raw_output_schema': ['REC-06'],
 'test_public_disconnect_supersedes_stalled_recovery_and_new_catalog': ['REC-05'],
 'test_late_expired_call_cannot_overwrite_new_successful_catalog': ['REC-05'],
 'test_issued_http_call_keeps_schema_and_wire_headers_through_refresh': ['REC-07'],
}
nodes = [line for line in (OUT / 'checks/collect-recovery-matrix/stdout').read_text().splitlines()
         if line.startswith('tests_mcp/client/test_result_refresh.py::')]
assert len(nodes) == 67
matrix = []
for node in nodes:
    function = node.split('::')[1].split('[')[0]
    assert function in names
    matrix.append({'nodeid': node, 'proof_ids': names[function],
        'source_assertions': functions[function], 'executed_check': 'focused-final',
        'status': 'passed', 'wire_owner_observations': 'assertions in cited function; no private task/lock/catalog injection'})
inherited = []
for name in ['final-requirement-test-mapping.json', 'actual-variant-matrix.json',
             'capture-read-audit.json', 'preconstruction-plan.md']:
    path = BASE / 'rem004-builder-evidence' / name
    inherited.append({'path': str(path), 'sha256': digest(path),
        'use': 'Retained unchanged prior clause/variant evidence; reexercised by focused-final'})
write('final-requirement-test-mapping.json', {
    'candidate': CANDIDATE, 'finding': 'VAL-UP04-003', 'criteria': ['RES-AC-02', 'RES-AC-03', 'RES-AC-08'],
    'status': 'Actual builder proof; independent verdict and full20 pending',
    'preconstruction_plan': {'path': 'preconstruction-plan.md', 'sha256': digest(OUT / 'preconstruction-plan.md')},
    'actual_variants': matrix, 'new_public_variant_count': 67,
    'source_ownership': {'path': 'packages/friday-mcp/src/friday_mcp/client/http.py',
        'capture': 676, 'transport_recovery': 681, 'catalog_publication_guard': 690,
        'failure_clear_guard': 699,
        'existing_declared_seam': 'base._catalog_generation advanced by virtual _invalidate_catalog'},
    'failure_cleanup_proof_limit': 'While recovery is disconnected, public catalog discovery rejects; successful publication cannot be forced through that interval. Source proves failure cleanup checks catalog ownership; public disconnect/reconnect and late404/newer-success variants prove no older transport clear/overwrite. No private-state injection fabricates an unreachable public publication.',
    'phase_budget_exclusions': 'Before-capture partial/cancel/deadline wire refresh requires budget>=2 because an issued call occupies budget1. Separate budget1 before-capture limit test and all1..4 during/after cases prove safety at that constructor budget.',
    'deadline_ordering': 'Public request_timeout_seconds lower setting binds refresh after original issued call already captured30s; restored afterwards. No original deadline extension.',
    'unchanged_original_requirements': {'all_19_complete_capture_hashes': 'normative-capture-integrity.json',
        'old_raw_count': 349, 'all19_raw_count': 393, 'old347_history': 'preserved terminology discrepancy',
        'retained_mappings': inherited},
    'REC-08': {'checks': 'checks-summary.json', 'scope': 'scope-preservation.json',
        'all_ten_original_criteria': 'Original full20 profile and fresh full-unit independent review remain controller gates; no blanket conformance claim'},
    'effects': 'Synthetic public backend, SDK subprocess and literal127 TLS only; optional interactions/provider/publication remain unsupported',
})
print(json.dumps({'candidate': CANDIDATE, 'scope': changed, 'public_variants': len(matrix),
                  'captures_verified': len(captures), 'mandatory_builder_checks': 'passed'}))
