from pathlib import Path
import hashlib,json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=json.loads((p/'authority-REM-MCP-UP-006.json').read_text());runner=b/'run_check_UP05.py'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def req(v,m):
 if not v:raise RuntimeError(m)
req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Dirty candidate')
controls=a['controls']+[a['approval'],a['approved_proposal']]
for x in controls:req(h(w/x['path'])==x['sha256'],'Control drift')
allowed={x['path'] for x in a['product_paths']};hashes={path:h(w/path) for path in a['full_original_product_hashes']}
for path,digest in a['full_original_product_hashes'].items():
 if path not in allowed:req(h(w/path)==digest,'Other product drift')
for group in ['preserved_product_hashes','metadata_hashes']:
 for path,digest in a[group].items():req(h(w/path)==digest,'Preserved drift')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();pin=h(p/'authority-REM-MCP-UP-006.json');req(h(runner)==a['runner']['UP05_sha256'],'Runner drift');req(h(b/'guard/sitecustomize.py')==a['guard']['sha256'],'Guard drift')
freeze={'candidate':head,'product_hashes':hashes,'authority_sha256':pin,'approval_and_controls':controls,'runner_sha256':h(runner),'checks':a['required_checks']};f=b/'rem006-profile-freeze.json';req(not f.exists(),'Freeze overwrite');f.write_text(json.dumps(freeze,indent=2)+'\n')
for c in a['required_checks']:
 req(head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip() and hashes=={path:h(w/path) for path in hashes} and pin==h(p/'authority-REM-MCP-UP-006.json'),'Candidate drift')
 for x in controls:req(h(w/x['path'])==x['sha256'],'Control drift')
 label='rem006-full-'+c['id'];req(not (b/'checks'/label).exists(),'Label overwrite');subprocess.run([str(b/'venv/bin/python'),str(runner),label,c['snapshot'],*c['argv']],check=True)
 receipt=json.loads((b/'checks'/label/'receipt.json').read_text());print(json.dumps({'id':c['id'],'child_exit':receipt['exit_code']}),flush=True);expected=1 if c['id'] in ['root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy'] else 0
 if receipt['exit_code']!=expected:
  print((b/'checks'/label/'stdout').read_text()[-8000:],flush=True);raise RuntimeError('Required check failed '+c['id'])
print('REM006_FULL20_PROFILE_COMPLETE',flush=True)
