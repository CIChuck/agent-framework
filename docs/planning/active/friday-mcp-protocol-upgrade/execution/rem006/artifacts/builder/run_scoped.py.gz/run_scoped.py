import json,subprocess,sys
from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade');p=b/'work/docs/planning/active/friday-mcp-protocol-upgrade/verification-profile-REM-MCP-UP-006.json';profile=json.loads(p.read_text())
for check in profile['required_checks']:
 if check['id'] in sys.argv[2:]:
  label='rem006-builder-'+check['id']+'-'+sys.argv[1]
  if (b/'checks'/label).exists():raise RuntimeError('refusing reuse')
  subprocess.run([sys.executable,str(b/'run_check_UP05.py'),label,check['snapshot'],*check['argv']],check=True)
  receipt=json.loads((b/'checks'/label/'receipt.json').read_text())
  if receipt['exit_code']!=0:raise RuntimeError('child failure '+label)
