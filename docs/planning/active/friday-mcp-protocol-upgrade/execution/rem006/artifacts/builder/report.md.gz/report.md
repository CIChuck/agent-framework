# REM-MCP-UP-006 separate remediation report

Candidate: `e284ebaf1ec4b596c8e3edb9511a7012c6dfa133`. Base: `cc8725d7af8f00540f264b5052e077a1f6655011`. Branch: `feature/friday-mcp-protocol-upgrade`.

Role: separate security/architecture remediator `/root/rem006_server_remediator`, Codex/GPT-6 agent instance. Date: 2026-10-13T20:49:06.571529+00:00. This is builder evidence; it is not an independent validation verdict or acceptance. Exact maintainer statement “approved continue” is recorded by approval-REM-MCP-UP-006.json.

The committed delta changes exactly the six approved product paths. The other12 original UP05 products,19 metadata files,60 accepted products, original authority/controls, guard and runner remain unchanged. No dependencies, installed libraries, client/legacy/Core/Runtime/Chat/telemetry sources, board, process authority, remote publication or acceptance state changed.

| Finding | Implemented correction and evidence |
| --- | --- |
| VAL-UP05-001 | Rejection tasks have a separate active_requests-bounded pool and serialized output; reader never waits on their delivery. Saturation closes the connection.32 malformed/duplicate/admission/oversize drain/lock cases at limits1..4 assert prompt cancellation, no duplicate handler, EOF settlement and bounded owners; saturation and simultaneous-writer cases assert no unbounded task/queue or overlapping drains. |
| VAL-UP05-002 | Connection state owns a separate internal serving task, dispatchers, rejection output, close wait, native transports and signals. Shutdown retains resistant owners, reports fixed incomplete cleanup and blocks start/serve until settlement. Limits1..4 cover resistant drain/lock/read/close/native-start work. Captured old finalizer and removed signal callback cannot alter replacement streams. Cancelled dispatch cannot emit after a resistant lock is released. |
| VAL-UP05-003 | The first nonempty frame read captures its absolute deadline; fragments, oversize discard, parse/admission/handler and output retain it. Expired partial frames close with zero handler/output effects. Limits1..4 cover partial/oversize expiry, fragmented handler/delivery waits and partial EOF; idle connection still accepts the next frame. |
| VAL-UP05-004 | Malformed/duplicate mirrored Mcp-Param header metadata selects fixed HTTP400/-32020 with no ID before body parsing. Recognized invalid decoded characters reject with the request’s own ID and zero handlers. Equal/conflicting case duplicates, CR/LF/NUL/control/DEL/nonASCII/Base64 negatives, interior-tab positive and access Host/Origin/Bearer status/privacy cases are explicit. Standard headers and Base64 cases remain passing. |

Every finding appears once in final-actual-modern-mapping.json.rem006_findings, with the prospective plan, pinned field/paragraph/variant/source/test/assertion-line/check references. The complete corrected modern mapping still contains155 declarations/337 field references/316 normative paragraphs, with all inherited pointers rebound to current hashes/lines and finding evidence added. Counts are inventory, not proof that every variant has a passing assertion. Existing2025 historical plan and original controls are immutable.

Guarded board validate/next/show ran before edits and passed. The final scoped server command passed582 tests, including real SDK2.3.0 subprocess stdio and verified private TLS JSON/SSE. Scoped16-file Ruff,7-source Mypy, whole28-source MCP Mypy, documentation554-file lifecycle and whitespace checks all passed (suffix006, whitespace-001). Seven corrected independent probes pass with raw observations: cancellation seen within40ms despite blocked rejection, zero expired-frame output, exact header error, retained resistant output owner/restart block and healthy replacement after release/retry.

Original archived probes were preserved byte-for-byte. Corrected probe adaptations are disclosed in probe-adaptation.md; the expired-frame peer no longer feeds a closed StreamReader, and resistant cleanup now asserts blocked restart before release/retry. original-archive-integrity.json verifies all454 stored artifacts:433 reviewer evidence entries plus the reviewer manifest and20 controller closeout raw files. Earlier failed observations were neither changed nor represented as corrected passes.

before-first-check.json and after-last-check.json bracket every builder child command and record all22009 installed library-file byte counts/SHA256 values and192 distributions, unchanged. check-summary.json verifies that chronology and exact preserved hashes. Unique per-command guarded HOME/cache destinations and unchanged runner/guard were used. Runtime HOME/caches/stores and TLS private keys are excluded from evidence.

Development failures are retained in checks/ and described in development-notes.md. No formal remediation cycle result is claimed by these development failures. OS loopback-bind denial was resolved using the exact approved guarded escalation; no public network, DNS, ambient credentials, real provider/user tools/stores, installs or shared environment writes were used.

The guide now explains first-byte frame budgets, bounded rejection saturation, exact custom-header errors and generation-owned retryable shutdown. Public typed async APIs, configured defaults, serialized writes and no replay remain. Cancellation-resistant transport/handler code can prevent settlement; it remains owned and restart stays blocked. This is a tools-only2026 server profile, with no added OAuth/session/Tasks/agent/YAML/optional interaction role.

The controller must run the unchanged full20-check stable-candidate profile and inherited complete Ruff/Mypy/skip/warning comparisons. A fresh read-only remediation delta review followed by full18-path/12-criterion UP05 review remains the next gate; no VERIFIED, completion, acceptance, UP06 or delivery/publication claim is made here.

| Approved changed product | Candidate SHA256 |
| --- | --- |
| `packages/friday-mcp/src/friday_mcp/server/http_policy.py` | `862c38c323c207c105d23ee0d295795f8217e41b4ad3bf77c18a40693d3fe70c` |
| `packages/friday-mcp/src/friday_mcp/server/modern_stdio.py` | `4469f7d8b80b930d1fae963f2f6f7af14ce6bcdac54ed272164b72aca16eed3a` |
| `packages/friday-mcp/tests_mcp/server/test_streamable_http.py` | `01968249fed26f580b0b853cc3d6301d242a851ac91e665aca65a85f90c43bc5` |
| `packages/friday-mcp/tests_mcp/server/test_modern_stdio.py` | `9975a4f81e1a7119e8451ffea1075782d806458ae3af41ea3f9a049da29ab124` |
| `packages/friday-mcp/tests_mcp/server/test_server_lifecycle.py` | `4b6537dc31b2099f84ae10bb194108195d499dfd33f617454f6d9d58d887c08c` |
| `docs/guides/18-mcp-server.md` | `1daa623bff75177f84e952adf4fa7eb32c0c6b0ea2e0b5790bb11fa28425f499` |
