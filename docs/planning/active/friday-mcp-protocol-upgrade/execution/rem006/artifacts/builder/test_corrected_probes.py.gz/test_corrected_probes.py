import asyncio,json,time
import httpx,pytest
from friday_mcp.server import ModernStdioMCPServer,StreamableHTTPMCPServer,ServerLimits,ToolCallResult
P='io.modelcontextprotocol/';V='2026-07-28'
def rpc(method='server/discover',rid=1,**params):
 return json.dumps({'jsonrpc':'2.0','id':rid,'method':method,'params':{'_meta':{P+'protocolVersion':V,P+'clientCapabilities':{}},**params}}).encode()
class Writer:
 def __init__(self,block=False):self.data=[];self.draining=asyncio.Event();self.release=asyncio.Event();self.block=block
 def write(self,data):self.data.append(data)
 async def drain(self):
  self.draining.set()
  if self.block:await self.release.wait()
 def close(self):self.release.set()
 async def wait_closed(self):pass
@pytest.mark.asyncio
async def test_partial_stdio_frame_absolute_deadline():
 s=ModernStdioMCPServer(limits=ServerLimits(timeout_seconds=.03));r=asyncio.StreamReader();w=Writer();serving=asyncio.create_task(s.serve(reader=r,writer=w));raw=rpc();r.feed_data(raw[:20]);await asyncio.sleep(.1);assert r.at_eof();await asyncio.sleep(.01)
 print('PARTIAL_FRAME',json.dumps({'wait_seconds':.1,'configured_timeout':.03,'responses':[json.loads(x) for x in w.data],'active':s.active_requests}))
 await s.stop();await serving
 assert not w.data and s.active_requests==0 and w.release.is_set()
@pytest.mark.asyncio
async def test_blocked_rejection_stalls_stdio_cancellation():
 s=ModernStdioMCPServer(limits=ServerLimits(timeout_seconds=.15));r=asyncio.StreamReader();w=Writer(block=True);started=asyncio.Event();cancelled=asyncio.Event()
 async def held(args):
  started.set()
  try:await asyncio.Event().wait()
  finally:cancelled.set()
 s.register_tool({'name':'hold','inputSchema':{'type':'object'}},held);serving=asyncio.create_task(s.serve(reader=r,writer=w));r.feed_data(rpc('tools/call',rid=1,name='hold')+b'\n');await started.wait();r.feed_data(b'{}\n');await w.draining.wait();r.feed_data(json.dumps({'jsonrpc':'2.0','method':'notifications/cancelled','params':{'requestId':1}}).encode()+b'\n');await asyncio.sleep(.04)
 print('BLOCKED_ERROR_WRITE',json.dumps({'cancel_seen_after_40ms':cancelled.is_set(),'handler_owner_count':s.active_requests,'reader_pending_bytes':len(r._buffer),'configured_timeout':.15}))
 assert cancelled.is_set();w.release.set();await asyncio.wait_for(cancelled.wait(),.05);await s.stop();await serving
@pytest.mark.asyncio
@pytest.mark.parametrize('bad',[b'one\rbroken',b'one\0broken',b'one\nbroken'])
async def test_recognized_header_invalid_char_exact_wire_code(bad):
 s=StreamableHTTPMCPServer();calls=[]
 async def handler(args):calls.append(args);return ToolCallResult.text('done')
 s.register_tool({'name':'echo','inputSchema':{'type':'object','properties':{'x':{'type':'string','x-mcp-header':'X'}}}},handler)
 h=[(b'content-type',b'application/json'),(b'accept',b'application/json, text/event-stream'),(b'mcp-protocol-version',V.encode()),(b'mcp-method',b'tools/call'),(b'mcp-name',b'echo'),(b'mcp-param-x',bad)]
 async with httpx.AsyncClient(transport=httpx.ASGITransport(app=s.create_app()),base_url='http://127.0.0.1:8000') as c:
  res=await c.post('/mcp',headers=h,content=rpc('tools/call',name='echo',arguments={'x':'one'}));print('RECOGNIZED_HEADER_INVALID',json.dumps({'bad_hex':bad.hex(),'status':res.status_code,'body':res.json(),'calls':len(calls)}));assert res.status_code==400 and res.json()['error']['code']==-32020 and not calls
 await s.stop()
@pytest.mark.asyncio
async def test_recognized_duplicate_header_exact_wire_code():
 s=StreamableHTTPMCPServer();calls=[]
 async def handler(args):calls.append(args);return ToolCallResult.text('done')
 s.register_tool({'name':'echo','inputSchema':{'type':'object','properties':{'x':{'type':'string','x-mcp-header':'X'}}}},handler)
 h=[('Content-Type','application/json'),('Accept','application/json, text/event-stream'),('MCP-Protocol-Version',V),('Mcp-Method','tools/call'),('Mcp-Name','echo'),('Mcp-Param-X','one'),('mcp-param-x','two')]
 async with httpx.AsyncClient(transport=httpx.ASGITransport(app=s.create_app()),base_url='http://127.0.0.1:8000') as c:
  res=await c.post('/mcp',headers=h,content=rpc('tools/call',name='echo',arguments={'x':'one'}));print('RECOGNIZED_HEADER_DUPLICATE',json.dumps({'status':res.status_code,'body':res.json(),'calls':len(calls)}));assert res.status_code==400 and res.json()['error']['code']==-32020 and not calls
 await s.stop()
@pytest.mark.asyncio
async def test_resistant_rejection_writer_untracked_shutdown_and_stale_restart():
 class ResistantWriter(Writer):
  def __init__(self):super().__init__();self.closed=False
  async def drain(self):
   self.draining.set()
   while not self.release.is_set():
    try:await self.release.wait()
    except asyncio.CancelledError:continue
  def close(self):self.closed=True
 class NextWriter(Writer):
  def __init__(self):super().__init__();self.closed=False
  def close(self):self.closed=True;super().close()
 s=ModernStdioMCPServer(limits=ServerLimits(timeout_seconds=.03,shutdown_seconds=.01));r=asyncio.StreamReader();w=ResistantWriter();old=asyncio.create_task(s.serve(reader=r,writer=w));r.feed_data(b'{}\n');await w.draining.wait();await asyncio.sleep(.06)
 with pytest.raises(TimeoutError,match='incomplete'):await s.stop()
 generation=s._generation
 print('RESISTANT_REJECTION_STOP_CORRECTED',json.dumps({'old_serving_done':old.done(),'retained_output_owners':len(generation.outputs),'writer_retained':s._writer is w}))
 assert len(generation.outputs)==1 and s._writer is w
 with pytest.raises(RuntimeError):s.start()
 r2=asyncio.StreamReader();w2=NextWriter()
 with pytest.raises(RuntimeError):await s.serve(reader=r2,writer=w2)
 w.release.set();await asyncio.gather(old,return_exceptions=True);await s.stop()
 new=asyncio.create_task(s.serve(reader=r2,writer=w2));r2.feed_data(rpc(rid='new')+b'\n');await w2.draining.wait()
 await s._stop_connection(generation)
 print('STALE_REJECTION_RESTART_CORRECTED',json.dumps({'new_writer_closed':w2.closed,'new_reply':[json.loads(x) for x in w2.data]}))
 assert not w2.closed and json.loads(w2.data[0])['id']=='new'
 await s.stop();await new
