import hashlib,json,sys,subprocess
from datetime import datetime,timezone
from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';e=b/'rem006-r1-builder-evidence';site=b/'venv/lib/python3.13/site-packages'
a=json.loads((w/'docs/planning/active/friday-mcp-protocol-upgrade/authority-REM-MCP-UP-006-R1.json').read_text())
groups=json.loads((b/'reused-library-manifest.json').read_text())['copied']+json.loads((b/'additional-validation-libraries.json').read_text())['added']
rows=[]
for g in groups:
 for r in g['files']:
  f=site/r['path'];h=hashlib.sha256(f.read_bytes()).hexdigest();rows.append({'path':r['path'],'bytes':f.stat().st_size,'sha256':h})
  if h!=r['sha256']:raise RuntimeError('library drift: '+r['path'])
if len(rows)!=22009 or len(groups)!=192:raise RuntimeError('library count drift')
def hashes(paths):return {p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in paths}
controls={r['path']:r['sha256'] for r in a['controls']}
for group in [controls,a['metadata_hashes'],a['preserved_product_hashes']]:
 if hashes(group)!=group:raise RuntimeError('preserved hashes drift')
result={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'candidate_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'libraries':rows,'unique_library_paths':len({r['path'] for r in rows}),'inventory_reference_count':len(rows),'distribution_count':len(groups),'distribution_names':[g.get('name',g.get('distribution')) for g in groups],'controls':hashes(controls),'metadata':hashes(a['metadata_hashes']),'preserved_products':hashes(a['preserved_product_hashes']),'all18_products':hashes(a['full_original_product_hashes']),'guard_sha256':hashlib.sha256((b/'guard/sitecustomize.py').read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256((b/'run_check_UP05.py').read_bytes()).hexdigest()}
p=e/(sys.argv[1]+'.json')
if p.exists():raise RuntimeError('refusing overwrite')
p.write_text(json.dumps(result,indent=2)+'\n');print(p,len(rows),len(groups))
