import json,hashlib,shutil,subprocess
from pathlib import Path
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade');e=b/'rem006-r1-builder-evidence';w=b/'work';a=json.loads((w/'docs/planning/active/friday-mcp-protocol-upgrade/authority-REM-MCP-UP-006-R1.json').read_text());d=json.loads((e/'final-actual-modern-mapping.json').read_text());candidate=d['product_candidate'];checks=[]
for folder in sorted((b/'checks').glob('rem006-r1-builder-*')):
 if not (folder/'receipt.json').is_file():raise RuntimeError('unfinished '+folder.name)
 dst=e/'checks'/folder.name;dst.mkdir(parents=True,exist_ok=True)
 for name in ['preflight.json','receipt.json','stdout','stderr']:shutil.copyfile(folder/name,dst/name)
 r=json.loads((dst/'receipt.json').read_text());checks.append({'label':folder.name,'argv':r['argv'],'exit_code':r['exit_code'],'started_utc':r['started_utc'],'finished_utc':r['finished_utc']})
before=json.loads((e/'before-first-check.json').read_text());after=json.loads((e/'after-last-check.json').read_text())
for key in ['libraries','unique_library_paths','inventory_reference_count','distribution_count','controls','metadata','preserved_products','guard_sha256','runner_sha256']:
 if before[key]!=after[key]:raise RuntimeError('drift '+key)
if not (before['unique_library_paths']==21992 and before['inventory_reference_count']==22009 and before['distribution_count']==192):raise RuntimeError('counts')
for name,h in a['full_original_product_hashes'].items():
 if name not in d['changed_three_products'] and after['all18_products'][name]!=h:raise RuntimeError(name)
if not before['captured_at_utc']<min(x['started_utc'] for x in checks):raise RuntimeError('before chronology')
if not after['captured_at_utc']>max(x['finished_utc'] for x in checks):raise RuntimeError('after chronology')
(e/'check-summary.json').write_text(json.dumps({'candidate_commit':candidate,'checks':checks,'before':before['captured_at_utc'],'after':after['captured_at_utc'],'brackets_every_builder_check':True,'unique_library_paths':21992,'inventory_references':22009,'distributions':192,'metadata19_accepted60_other15_unchanged':True},indent=2)+'\n')
(e/'candidate.diff').write_bytes(subprocess.check_output(['git','diff',d['base_candidate'],candidate,'--',*[x['path'] for x in a['product_paths']]],cwd=w))
(e/'development-notes.md').write_text('All development commands retain raw preflight/receipt/stdout/stderr with unique labels. The sole nonzero R1 builder child is rem006-r1-builder-ruff-001:SIM117 requested combining nested async contexts in the new TLS regression. The test-only formatting correction was made within scope; server-focused-002 and Ruff/Mypy/docs/whitespace-002 are all successful. Original sealed review failures and source/probe bytes remain unchanged. No label was reused, no failure rewritten, no runtime state cleaned and no dependency installed.\n')
archive=json.loads((e/'original-archive-integrity.json').read_text());count=len(archive['entries'])
report=f'''# REM-MCP-UP-006-R1 separate remediation report

Candidate: `{candidate}`. Base: `{d['base_candidate']}`. Branch: `feature/friday-mcp-protocol-upgrade`. Role: separate security/architecture remediator `/root/rem006_server_remediator`, Codex/GPT-6 agent instance. Recorded {datetime.now(timezone.utc).isoformat()}.

This is the already-authorized bounded REM006 continuation, formal remediation cycle2. No new approval, independent VERIFIED result, completion, acceptance, UP06, delivery or publication is claimed. The existing exact maintainer approval and all original controlling artifacts remain immutable.

VAL-UP05-005 is implemented by four added source lines at HTTPServerPolicy.validate: plain Mcp-Method/MCP-Protocol-Version values permit visibleASCII/SP/HTAB only and reject every other byte with fixed400/-32020 before body consumption or RPC routing. Values are neither normalized nor Base64-decoded. Exact matching valid unknown ASCII method remains404/-32601, valid unknown ASCII version remains400/-32022 with supported/requested data. Name/Param Base64, decoded Unicode, custom duplicates and access-specific statuses remain separate and unchanged.

Exactly the three approved product paths changed. All other15 original UP05 products,19 metadata,60 accepted products, original guard/runner, libraries and controls are unchanged. The guide now states the plain-field byte grammar and the separate Name/Param sentinel rules. No public API/default/dependency/checker/optional role, stdio ownership source, accepted client/legacy/Core/Runtime/Chat/telemetry source or board/process authority changed.

The pre-edit prospective-plan.json freezes complete relevant clause/field/byte/variant/source/test/command coverage. final-actual-modern-mapping.json retains all155 declarations/337 field references/316 normative paragraphs, rebinds all inherited pointers to this candidate and adds exactly one R1 finding row with concrete source, field, paragraph, variant, assertion-line and command references. Ten historical _meta field line offsets reported by VAL-UP05-02 are corrected explicitly in this new evidence ledger only; original inventories/reports/captures remain untouched. Inventory counts are not independent conformance verdicts.

Final builder evidence:

- Guarded board validate/next/show passed before edits with started/granted/approved continuation authority.
- Complete scoped server-focused-002:1108 passed, including original ownership/frame fixes, real official SDK2.3.0 stdio and verified privateTLS JSON/SSE.
- Standard HTTP test suite:605 passed. New tests include both fields ×160 forbidden bytes and ×96 permitted bytes, matchingUTF8 boundaries, exact equality without case/whitespace/Base64 normalization, and actual verifiedTLS rawUTF8/no-handler/child-exit assertions.
- Scoped16-file Ruff,7-source Mypy,28-source MCP Mypy, documentation557-file lifecycle and whitespace pass. All child receipt exits were inspected.
- The byte-identical original test_review_edges.py assertion counterpart passes all70 tests, including64 independent original-fix cases and all six new mandatory standard-field negatives.
- Two corrected live probe tests retain every original request and raw observation: app-level UTF8 requests yield exact400/-32020/no-id safe JSON; C0/DEL requests remain h11 pre-ASGI400 fixedplaintext. Both modes have0 handler starts, active_final0 and child_exit0. This disclosed assertion-only distinction follows the sealed review's middleware/app separation; no parser/dependency change or weakened app assertion is used.

Original VAL-UP05-02 report and scripts remain unchanged. Original script copies are byte-identical. original-archive-integrity.json checks all{count} original stored artifacts against stored and decompressed byte counts/hashes. probe-adaptation.md explains the separate live counterpart; all original failures remain preserved.

before-first-check.json and after-last-check.json chronologically bracket every builder child command, with identical actual hashes for21992 unique library paths/22009 inventory references/192 distributions, metadata19, accepted products60, other15 products and frozen controls/guard/runner. check-summary.json records full argv/exits/timestamps and verifies the comparison. Fresh unique guarded HOME/cache destinations and approved loopback escalation were used. Evidence excludes runtime HOME/cache/TMP/store contents and private TLS keys; retained approved relative-CWD synthetic root fixture artifacts were not cleaned.

The sole new development failure is Ruff SIM117 in the new test's nested async contexts. Raw attempt is retained, and its in-scope test formatting correction passes subsequent checks. These development checks are not the independent formal cycle result. No public network/DNS, user credentials/stores, live provider/tools, installation/sync/shared environment write, broad staging or external publication occurred.

Controller must execute the unchanged full20 stable-candidate profile, explicit-column Mypy and complete inherited diagnostic/fix/skip/warning comparisons, then commission fresh read-only remediation delta and full18-path/12-criterion UP05 review. A second unsuccessful formal remediation result requires stopping under policy. Existing cancellation-resistant transport behavior remains honestly owned and blocks unsafe restart; no broader optional/OAuth/server role conformance is claimed.

| Changed product | Candidate SHA256 |
| --- | --- |
'''
for path,h in d['changed_three_products'].items():report+=f'| `{path}` | `{h}` |\n'
(e/'report.md').write_text(report)
entries=[]
for f in sorted(e.rglob('*')):
 if f.is_file() and f.name!='evidence-manifest.json':entries.append({'path':str(f.relative_to(e)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
m={'candidate_commit':candidate,'base_commit':d['base_candidate'],'reviewer_role_identity':'separate REM006-R1 security/architecture remediator /root/rem006_server_remediator; builder evidence','date_utc':datetime.now(timezone.utc).isoformat(),'remediation_cycle':2,'product_hashes':d['changed_three_products'],'finding_disposition':d['rem006_r1_findings'][0]['disposition'],'finding':'VAL-UP05-005','prospective_plan':'prospective-plan.json','final_actual_mapping':'final-actual-modern-mapping.json','report':'report.md','entries':entries,'exclusions':'Runtime HOME/cache/TMP/store data and TLS private keys; no directory/glob allowlist entries','next_gate':'controller unchanged full20 followed by fresh independent cycle2 delta/full UP05 validation'}
(e/'evidence-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for r in entries:
 f=e/r['path']
 if f.stat().st_size!=r['bytes'] or hashlib.sha256(f.read_bytes()).hexdigest()!=r['sha256']:raise RuntimeError('evidence drift')
print('Final safe evidence',len(entries),'entries;0 mismatches;original archive',count,'entries;candidate',candidate)
