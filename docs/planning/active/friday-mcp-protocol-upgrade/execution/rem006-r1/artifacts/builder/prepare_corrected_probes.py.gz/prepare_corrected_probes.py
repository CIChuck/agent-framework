import gzip,json,hashlib,shutil
from pathlib import Path
b=Path('/private/tmp/friday-mcp-upgrade');e=b/'rem006-r1-builder-evidence';p=b/'work/docs/planning/active/friday-mcp-protocol-upgrade/validation/VAL-UP05-02'
d=json.loads((p/'stored-manifest.json').read_text());rows=d.get('artifacts',[]);checked=[]
for row in rows:
 data=(p/row['path']).read_bytes()
 if hashlib.sha256(data).hexdigest()!=row['stored_sha256']:raise RuntimeError(row['path'])
 original=gzip.decompress(data)
 if len(original)!=row['bytes'] or hashlib.sha256(original).hexdigest()!=row['sha256']:raise RuntimeError(row['path'])
 checked.append({'path':row['path'],'bytes':len(data),'sha256':row['stored_sha256']})
(e/'original-archive-integrity.json').write_text(json.dumps({'stored_manifest_sha256':hashlib.sha256((p/'stored-manifest.json').read_bytes()).hexdigest(),'entries':checked},indent=2)+'\n')
shutil.copyfile(e/'original-test_review_edges.py',e/'test_corrected_review_edges.py')
s=(e/'original-test_standard_header_live.py').read_text()
old=" assert all(x['status']==400 and x['body'].get('error',{}).get('code')==-32020 for x in observations)"
new=""" for x in observations:
  assert x['status']==400
  if x['suffix_hex'] in ['01','7f']:
   # Retained h11 middleware rejects these before the application receives them.
   assert x['body']=={'raw_parser_body':'Invalid HTTP request received.'}
  else:
   assert x['body']=={'jsonrpc':'2.0','error':{'code':-32020,'message':'Header mismatch'}}
"""
if old not in s:raise RuntimeError('probe shape changed')
(e/'test_corrected_standard_header_live.py').write_text(s.replace(old,new))
(e/'probe-adaptation.md').write_text('Original VAL-UP05-02 scripts and report remain unchanged. test_corrected_review_edges.py is byte-identical to original:70 original required-behavior assertions run unchanged. test_corrected_standard_header_live.py retains all six raw requests per JSON/SSE fixture, child/owner/zero-handler assertions and complete observation capture. Its assertion-only counterpart explicitly separates the retained h11 pre-ASGI C0/DEL HTTP400 fixed plaintext responses from UTF8 requests reaching the app, which must yield exact HTTP400/-32020/no-id safe JSON. This is the middleware/application distinction already in the sealed report, not a weakening of the application contract or change to the original failed probe.\n')
