import ast,json,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';e=b/'rem006-r1-builder-evidence';p=w/'docs/planning/active/friday-mcp-protocol-upgrade'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def ref(path,name):
 for n in ast.walk(ast.parse((w/path).read_text())):
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name==name:
   return {'path':path,'symbol':name,'line':n.lineno,'end_line':n.end_lineno,'sha256':h(w/path),'assertion_lines':[x.lineno for x in ast.walk(n) if isinstance(x,ast.Assert)]}
 raise RuntimeError(path+' '+name)
d=json.loads((b/'rem006-builder-evidence/final-actual-modern-mapping.json').read_text());a=json.loads((p/'authority-REM-MCP-UP-006-R1.json').read_text())
def rebind(x):
 if isinstance(x,dict):
  if all(k in x for k in ['path','symbol','line','sha256']):x.update(ref(x['path'],x['symbol']))
  for v in x.values():rebind(v)
 elif isinstance(x,list):
  for v in x:rebind(v)
rebind(d)
review=json.loads((b/'independent-review-UP05-002/full-unit-field-clause-assessment.json').read_text());schema=(b/'modelcontextprotocol--modelcontextprotocol--main--schema--2026-07-28--schema.ts').read_text().splitlines()
corrections=[]
for row in review['field_reference_line_offsets_corrected']:
 for field in d['fields']:
  if field['declaration']==row['declaration'] and field['field']==row['field']:
   if schema[row['actual_line']-1].strip()!=field['field']:raise RuntimeError('schema mismatch')
   corrections.append({**row,'prior_inventory_immutable':True})
   field['prior_inventory_schema_line']=field['schema_line'];field['schema_line']=row['actual_line']
d['field_reference_line_offsets_corrected_in_r1']=corrections
testpath='packages/friday-mcp/tests_mcp/server/test_streamable_http.py';source='packages/friday-mcp/src/friday_mcp/server/http_policy.py'
refs=[ref(testpath,n) for n in ['test_plain_standard_header_invalid_byte_sweep_exact_mismatch','test_plain_standard_header_valid_byte_sweep_keeps_routing_category','test_plain_standard_header_raw_utf8_matching_body_exact_mismatch','test_plain_standard_header_equality_does_not_normalize_or_decode','test_real_tls_raw_utf8_standard_headers_exact_mismatch']]
row={'id':'VAL-UP05-005','severity':'medium','number':5,'disposition':'Implemented bounded correction; builder tests passed; fresh independent cycle2 delta/full review pending','criteria':['SRV-AC-01','SRV-AC-05','SRV-AC-06','SRV-AC-12'],'plan_ref':'prospective-plan.json','source':[ref(source,'validate'),ref(source,'validate_rpc_headers'),ref(source,'decode_header')],'assertions':refs,'field_references':[x for x in d['fields'] if x['declaration'] in ['HeaderMismatchError','JSONRPCErrorResponse'] or x['declaration']=='RequestMetaObject' and 'protocolVersion' in x['field']],'paragraph_references':[x for x in d['clauses'] if 'streamable-http' in x['source'] and any(v in x['paragraph'].lower() for v in ['ascii','invalid characters','header validation','-32020','base64'])],'byte_coverage':{'negative_bytes160':[*range(0,9),*range(10,32),*range(127,256)],'positive_bytes96':[9,*range(32,127)],'fields':['mcp-method','mcp-protocol-version'],'matching_rawUTF8':['世界','é'],'non_normalization':['case','SP','HTAB','Base64sentinel']},'check_refs':['checks/rem006-r1-builder-server-focused-002/receipt.json','checks/rem006-r1-builder-corrected-edges-001/receipt.json','checks/rem006-r1-builder-corrected-live-001/receipt.json','checks/rem006-r1-builder-ruff-002/receipt.json','checks/rem006-r1-builder-narrow-mypy-002/receipt.json','checks/rem006-r1-builder-mcp-mypy-002/receipt.json'],'middleware':'Raw C0/DEL rejected by retainedh11 before ASGI stays400 fixedplaintext; app-levelASGI completebyte sweep expects400/-32020; actualTLSUTF8 reachesapp and expects400/-32020; no middleware/dependency change'}
d['rem006_r1_findings']=[row]
for key in ['headers','version','access']:
 d['bundles'][key]['source'].append(ref(source,'validate'));d['bundles'][key]['assertions'].extend(refs)
 d['bundles'][key]['implementation']+=' R1 standard Method/Version byte grammar permits visibleASCII/SP/HTAB only, before body read, exact fixedHeaderMismatch for invalidbytes; positive exact-body equality/routing categories remain.'
d['product_candidate']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();d['base_candidate']='bffa9df1de3be145ec4119ba7337526752a371f1';d['r1_created_utc']=datetime.now(timezone.utc).isoformat();d['authority_rem006_r1_sha256']=h(p/'authority-REM-MCP-UP-006-R1.json');d['prospective_rem006_r1_plan_sha256']=h(e/'prospective-plan.json');d['all18_products']={name:h(w/name) for name in a['full_original_product_hashes']};d['changed_three_products']={x['path']:h(w/x['path']) for x in a['product_paths']};d['guide']['sha256']=h(w/d['guide']['path']);d['required_profile_unchanged']=a['required_checks'];d['status']='REM006-R1 final complete modern inventory with builder evidence; independent verdict pending';d['limitations']+=' R1 preserves original four correction products; original reports/probes/incorrectoffset inventory unchanged. Corrected offsets are explicit evidence-index corrections, not schema changes. Controller unchanged full20 and fresh second-cycle delta/full review required.'
(e/'final-actual-modern-mapping.json').write_text(json.dumps(d,indent=2)+'\n');print('Mapping inventories',len(d['declarations']),len(d['fields']),len(d['clauses']),'explicit offsets',len(corrections))
