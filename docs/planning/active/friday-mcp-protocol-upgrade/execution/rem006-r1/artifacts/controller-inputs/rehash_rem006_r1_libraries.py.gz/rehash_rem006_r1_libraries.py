from pathlib import Path
import hashlib,json,sys
from datetime import datetime,timezone
b=Path('/private/tmp/friday-mcp-upgrade');site=b/'venv/lib/python3.13/site-packages';phase=sys.argv[1]
if phase not in ['before','after']:raise RuntimeError('Invalid phase')
started=datetime.now(timezone.utc).isoformat()
inputs=[b/'reused-library-manifest.json',b/'additional-validation-libraries.json'];groups=json.loads(inputs[0].read_text())['copied']+json.loads(inputs[1].read_text())['added'];bad=[];actual={};count=0
for group in groups:
 for row in group['files']:
  f=site/row['path'];digest=hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None;actual[row['path']]=digest
  if digest!=row['sha256']:bad.append({'path':row['path'],'expected':row['sha256'],'actual':digest})
  else:count+=1
result={'inventory_file_references':count,'unique_library_paths':len(actual),'matching_files':count,'distributions':len(groups),'mismatches':bad,'actual_hashes':actual,'inventory_input_hashes':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in inputs},'phase':phase,'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat()};out=b/('rem006-r1-library-'+phase+'.json')
if out.exists():raise RuntimeError('Evidence overwrite')
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['phase','matching_files','distributions','mismatches']}))
if count!=22009 or len(groups)!=192 or bad:raise RuntimeError('Library drift')
