from pathlib import Path
import json,collections,re,hashlib,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';base=b/'up05-baseline';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=json.loads((p/'authority-REM-MCP-UP-006-R1.json').read_text());freeze=json.loads((b/'rem006-r1-profile-freeze.json').read_text());checks={}
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def require(value,msg):
 if not value:raise RuntimeError(msg)
require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==freeze['candidate'],'Candidate drift')
for c in a['required_checks']:
 d=b/'checks'/('rem006-r1-full-'+c['id']);receipt=json.loads((d/'receipt.json').read_text());pre=json.loads((d/'preflight.json').read_text());snap=w if c['snapshot']=='work' else base;expect=1 if c['id'] in {'root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy'} else 0
 require(receipt['exit_code']==expect and receipt['argv']==c['argv'],'Receipt/argv mismatch '+c['id']);require(pre['candidate_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=snap,text=True).strip(),'HEAD drift')
 require(pre['source_hashes']=={x['path']:h(snap/x['path']) for x in [{'path':path} for path in a['full_original_product_hashes']]},'Product freeze changed');require(receipt['environment']==pre['environment'],'Environment drift');require(pre['guard_sha256']==a['guard']['sha256'],'Guard drift');require(pre['UP05_runner_sha256']==a['runner']['UP05_sha256'],'Runner drift');checks[c['id']]={'exit_code':receipt['exit_code'],'stdout_sha256':receipt['stdout_sha256'],'stderr_sha256':receipt['stderr_sha256']}
def norm(v,snap):
 if isinstance(v,str):return v.replace(str(snap),'<snapshot>')
 if isinstance(v,list):return [norm(x,snap) for x in v]
 if isinstance(v,dict):return {k:norm(x,snap) for k,x in v.items()}
 return v
ruff=[norm(json.loads((b/'checks'/('rem006-r1-full-'+key)/'stdout').read_text()),snap) for key,snap in [('root-ruff',w),('baseline-root-ruff',base)]];require(len(ruff[0])==len(ruff[1])==327 and collections.Counter(json.dumps(x,sort_keys=True) for x in ruff[0])==collections.Counter(json.dumps(x,sort_keys=True) for x in ruff[1]),'Complete Ruff diagnostic/fix drift')
columns=[]
for key in ['full-mypy','baseline-full-mypy']:
 d=b/'checks'/('rem006-r1-'+key+'-columns');require(json.loads((d/'receipt.json').read_text())['exit_code']==1,'Column check wrong exit');columns.append([x for x in (d/'stdout').read_text().splitlines() if ': error:' in x or ': note:' in x])
prior=json.loads((b/'up04-mypy-column-comparison.json').read_text())['diagnostics'];require(columns[0]==columns[1]==prior and len(prior)==4,'Mypy complete diagnostic drift')
pytest={}
for key,snap in [('root',w),('baseline-root',base)]:
 text=(b/'checks'/('rem006-r1-full-'+key)/'stdout').read_text().replace(str(snap),'<snapshot>');warning=re.search(r'=+ warnings summary =+\n(.*?)\n-- Docs:',text,re.S);require(warning is not None,'Missing warning section');pytest[key]={'skip_locations_reasons':[l for l in text.splitlines() if l.startswith('SKIPPED')],'complete_warnings':warning[1],'summary':text.splitlines()[-1]}
require(pytest['root']['skip_locations_reasons']==pytest['baseline-root']['skip_locations_reasons'] and pytest['root']['complete_warnings']==pytest['baseline-root']['complete_warnings'],'Skip/warning drift')
for row in a['controls']+[a['approval'],a['approved_proposal']]:require(h(w/row['path'])==row['sha256'],'Authority drift')
for key in ['metadata_hashes','preserved_product_hashes']:
 for f,digest in a[key].items():require(h(w/f)==digest,'Protected content drift')
libraries=[]
for file in ['rem006-r1-library-before.json','rem006-r1-library-after.json']:
 j=json.loads((b/file).read_text());libraries.append(j);require(j['matching_files']==22009 and j['distributions']==192 and not j['mismatches'],'Library drift')
require(libraries[0]['finished_utc'] <= min(json.loads((b/'checks'/('rem006-r1-full-'+c['id'])/'receipt.json').read_text())['started_utc'] for c in a['required_checks']) and libraries[1]['started_utc'] >= max(json.loads((b/'checks'/('rem006-r1-full-'+c['id'])/'receipt.json').read_text())['finished_utc'] for c in a['required_checks']), 'Library samples do not bracket full profile')
require(libraries[0]['actual_hashes']==libraries[1]['actual_hashes'] and libraries[0]['inventory_input_hashes']==libraries[1]['inventory_input_hashes'],'Library before/after drift')
allowed={x['path'] for x in a['product_paths']};changed=set(subprocess.check_output(['git','diff','--name-only',a['execution_baseline']+'..HEAD'],cwd=w,text=True).splitlines());require(all(x in allowed or x.startswith('docs/planning/') for x in changed),'Scope drift')
report={'status':'Builder verification comparisons only; independent review required','candidate':freeze['candidate'],'checks':checks,'root_test_results':pytest,'root_ruff':{'count':327,'complete_diagnostics_and_fixes_equal':True},'full_mypy':{'diagnostics_with_columns':columns[0],'complete_diagnostics_equal':True},'inventory_file_references':22009,'unique_library_paths':21992,'library_files':22009,'distributions':192,'metadata_hashes_preserved':19,'accepted_product_hashes_preserved':60,'changed_product_paths':len(changed&allowed), 'unchanged_original_product_hashes':len(a['full_original_product_hashes'])-len(changed&allowed),'root_whitespace_exit0':True,'finding_scope':'VAL-UP05-005 correction and original four regressions require fresh independent delta/full review; no controller verdict'};(b/'rem006-r1-verification-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':len(checks),'root':pytest['root']['summary'],'baseline':pytest['baseline-root']['summary'],'ruff':327,'mypy':4,'skips_warnings_exactly_equal':True,'conformance':'independent review pending'}))
