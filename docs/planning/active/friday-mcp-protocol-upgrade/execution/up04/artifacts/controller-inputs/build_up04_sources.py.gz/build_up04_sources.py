from pathlib import Path
p=Path('/private/tmp/friday-mcp-upgrade/work/packages/friday-mcp/src/friday_mcp/client')
f=p/'base.py';s=f.read_text();s=s.replace('from friday_mcp.client.protocol import (','from friday_mcp.client.catalog import MCPCatalogSnapshot\nfrom friday_mcp.client.protocol import (',1).replace('Literal["tool_error"]','Literal["tool_error", "catalog_unavailable", "unsupported_task"]',1)
s=s.replace('        else:\n            super().__init__(-32100, str(ProtocolFailure(failure_code)))','        elif failure_code == "catalog_unavailable":\n            super().__init__(-32101, "MCP tool catalog unavailable")\n        elif failure_code == "unsupported_task":\n            super().__init__(-32102, "MCP task execution is unsupported")\n        else:\n            super().__init__(-32100, str(ProtocolFailure(failure_code)))',1)
s=s.replace('        self._catalog: tuple[ToolDefinition, ...] = ()','''        self._catalog: tuple[ToolDefinition, ...] = ()
        self._catalog_snapshot: MCPCatalogSnapshot | None = None
        self._catalog_generation = 0
        self._catalog_attempted = False
        self._catalog_lock = asyncio.Lock()
        self._refresh_tasks: set[asyncio.Task[MCPCatalogSnapshot]] = set()''',1)
s=s.replace('        self._catalog = ()','        self._invalidate_catalog()',2) # connect and disconnect only
s=s.replace('        receiver = self._receive_task','        self._invalidate_catalog()\n        await self._stop_refreshes()\n        receiver = self._receive_task',1)
start=s.index('    async def list_tools(');end=s.index('    async def list_prompts(',start)
s=s[:start]+'''    @property
    def current_catalog_snapshot(self) -> MCPCatalogSnapshot | None:
        return self._catalog_snapshot

    @property
    def outstanding_catalog_owners(self) -> int:
        return len(self._refresh_tasks)

    def _invalidate_catalog(self) -> None:
        self._catalog_generation += 1
        self._catalog_snapshot = None
        self._catalog = ()

    async def _stop_refreshes(self) -> None:
        tasks = set(self._refresh_tasks)
        for task in tasks:
            task.cancel()
        if tasks:
            _, pending = await asyncio.wait(tasks, timeout=0.5)
            if pending:
                raise RuntimeError("MCP catalog cleanup incomplete")

    async def refresh_tool_catalog(self) -> MCPCatalogSnapshot:
        deadline = asyncio.get_running_loop().time() + self._timeout()
        if len(self._refresh_tasks) >= self.limits.concurrent_requests:
            raise ProtocolFailure("limit_exceeded")
        self._catalog_attempted = True
        task = asyncio.create_task(self._refresh_catalog(deadline), name="mcp-catalog-refresh")
        self._refresh_tasks.add(task)

        def settled(done: asyncio.Task[MCPCatalogSnapshot]) -> None:
            if not done.cancelled():
                done.exception()
            self._refresh_tasks.discard(done)

        task.add_done_callback(settled)
        try:
            return await task
        finally:
            if not task.done():
                task.cancel()

    async def _refresh_catalog(self, deadline: float) -> MCPCatalogSnapshot:
        async with asyncio.timeout_at(deadline), self._catalog_lock:
            self._invalidate_catalog()
            generation = self._catalog_generation
            tools, excluded = await self._discover_catalog(deadline)
            snapshot = self._make_catalog_snapshot(generation, tools, excluded)
            if generation != self._catalog_generation:
                raise MCPToolExecutionError("catalog_unavailable")
            if asyncio.get_running_loop().time() >= deadline:
                raise TimeoutError("MCP catalog timeout")
            self._publish_catalog(snapshot)
            return snapshot

    def _make_catalog_snapshot(
        self, generation: int, tools: tuple[ToolDefinition, ...], excluded: tuple[str, ...]
    ) -> MCPCatalogSnapshot:
        return MCPCatalogSnapshot(generation, tools, len(excluded), excluded_task_names=excluded)

    def _publish_catalog(self, snapshot: MCPCatalogSnapshot) -> None:
        self._catalog = snapshot.definitions
        self._catalog_snapshot = snapshot

    async def _catalog_request(self, params: dict[str, Any], deadline: float) -> dict[str, Any]:
        return await self._request("tools/list", params, timeout=max(0.000001, deadline - asyncio.get_running_loop().time()))

    async def _discover_catalog(
        self, deadline: float
    ) -> tuple[tuple[ToolDefinition, ...], tuple[str, ...]]:
        if "tools" not in self._capabilities.object():
            return (), ()
        tools: list[ToolDefinition] = []
        excluded: list[str] = []
        cursors: set[str] = set()
        names: set[str] = set()
        cursor: str | None = None
        total = 0
        for _ in range(self.limits.catalog_pages):
            response = await self._catalog_request({"cursor": cursor} if cursor is not None else {}, deadline)
            total += response.wire_bytes if isinstance(response, ResultSnapshot) else len(encode_json(response, self.limits, byte_limit=self.limits.frame_bytes))
            if total > self.limits.catalog_bytes:
                raise ProtocolFailure("limit_exceeded")
            page = CatalogPage.parse(FrozenJSON.from_value(response, self.limits).object(), self._selected_version == MODERN_VERSION, self.limits)
            if len(names) + len(page.tools) > self.limits.catalog_tools:
                raise ProtocolFailure("limit_exceeded")
            for tool in page.tools:
                if tool.name in names:
                    raise ProtocolFailure()
                names.add(tool.name)
                execution = tool.definition.object().get("execution")
                if self._selected_version == "2025-11-25" and isinstance(execution, dict) and execution.get("taskSupport") == "required":
                    excluded.append(tool.name)
                else:
                    tools.append(tool)
            cursor = page.cursor
            if cursor is None:
                return tuple(tools), tuple(excluded)
            if cursor in cursors:
                raise ProtocolFailure()
            cursors.add(cursor)
        raise ProtocolFailure("limit_exceeded")

    async def list_tools(self) -> list[dict[str, Any]]:
        return (await self.refresh_tool_catalog()).tools()

    async def call_tool_at_generation(
        self, name: str, arguments: dict[str, Any], generation: int
    ) -> str:
        return await self._call_tool(name, arguments, generation)

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> str:
        return await self._call_tool(name, arguments, None)

    async def _call_tool(
        self, name: str, arguments: dict[str, Any], generation: int | None
    ) -> str:
        snapshot = self.current_catalog_snapshot
        if generation is not None and (type(generation) is not int or snapshot is None or generation != snapshot.generation):
            raise MCPToolExecutionError("catalog_unavailable")
        if snapshot is not None and name in snapshot.excluded_task_names:
            raise MCPToolExecutionError("unsupported_task")
        tool = snapshot.tool(name) if snapshot is not None else None
        if (snapshot is not None and tool is None) or (self._catalog_attempted and snapshot is None):
            raise MCPToolExecutionError("catalog_unavailable")
        output_schema = tool.output_schema if tool is not None else None
        try:
            response = await self._request_tool(name, arguments, snapshot)
            bounded = FrozenJSON.from_value(response, self.limits, byte_limit=self.limits.result_bytes).object()
            result = ToolResult.parse(bounded, self._selected_version == MODERN_VERSION, self.limits, compatibility=self._selected_version == "2025-11-25")
            if bounded.get("isError", False):
                raise MCPToolExecutionError("tool_error")
            if output_schema is not None:
                validate_structured(result.structured, output_schema, self.limits)
            return result.text(self.limits)
        except ProtocolFailure as exc:
            raise MCPToolExecutionError(exc.failure_code) from None

    async def _request_tool(
        self, name: str, arguments: dict[str, Any], snapshot: MCPCatalogSnapshot | None
    ) -> dict[str, Any]:
        return await self._request("tools/call", {"name": name, "arguments": arguments})

'''+s[end:];f.write_text(s)
f=p/'http.py';s=f.read_text().replace('from contextlib import suppress','from contextlib import suppress\nfrom contextvars import ContextVar');s=s.replace('from friday_mcp.client.base import MCPClientBase, MCPError','from friday_mcp.client.base import MCPClientBase, MCPError\nfrom friday_mcp.client.catalog import MCPCatalogSnapshot')
s=s.replace('        self._bindings: dict[str, tuple[HeaderBinding, ...]] = {}','''        self._bindings: dict[str, tuple[HeaderBinding, ...]] = {}
        self._call_bindings: ContextVar[tuple[HeaderBinding, ...] | None] = ContextVar("mcp-call-bindings", default=None)''',1)
s=s.replace('self._catalog = ()','self._invalidate_catalog()')
s=s.replace('                for binding in self._bindings[name]:','                captured = self._call_bindings.get()\n                for binding in (self._bindings[name] if captured is None else captured):')
# Do not consult live catalog membership when this call already captured bindings.
s=s.replace('                    or name not in self._bindings','                    or (self._call_bindings.get() is None and name not in self._bindings)')
start=s.index('    async def list_tools(');end=s.index('    async def call_tool(',start)
s=s[:start]+'''    def _invalidate_catalog(self) -> None:
        super()._invalidate_catalog()
        self._bindings.clear()
        self.rejected_http_tools = 0

    async def _catalog_request(self, params: dict[str, Any], deadline: float) -> dict[str, Any]:
        if not self._connected:
            raise RuntimeError("MCP HTTP disconnected")
        return await self._request_budget("tools/list", params, deadline)

    def _make_catalog_snapshot(
        self, generation: int, tools: tuple[ToolDefinition, ...], excluded: tuple[str, ...]
    ) -> MCPCatalogSnapshot:
        retained: list[ToolDefinition] = []
        bindings_by_name: list[tuple[str, tuple[HeaderBinding, ...]]] = []
        rejected = 0
        for tool in tools:
            schema = tool.definition.object().get("inputSchema")
            if not isinstance(schema, dict):
                raise ProtocolFailure()
            try:
                bindings = header_bindings(schema) if self._selected_version == MODERN_VERSION else ()
            except ProtocolFailure:
                rejected += 1
                continue
            retained.append(tool)
            bindings_by_name.append((tool.name, bindings))
        return MCPCatalogSnapshot(generation, tuple(retained), len(excluded), rejected, excluded, tuple(bindings_by_name))

    def _publish_catalog(self, snapshot: MCPCatalogSnapshot) -> None:
        self._bindings = dict(snapshot.bindings)
        self.rejected_http_tools = snapshot.rejected_http_tools
        super()._publish_catalog(snapshot)

    async def _request_tool(
        self, name: str, arguments: dict[str, Any], snapshot: MCPCatalogSnapshot | None
    ) -> dict[str, Any]:
        token = self._call_bindings.set(snapshot.headers(name) if snapshot is not None else None)
        try:
            return await super()._request_tool(name, arguments, snapshot)
        finally:
            self._call_bindings.reset(token)

'''+s[end:]
# Generation-specific entry must share the HTTP call deadline too.
s+='''
    async def call_tool_at_generation(
        self, name: str, arguments: dict[str, Any], generation: int
    ) -> str:
        deadline = asyncio.get_running_loop().time() + self._timeout()
        async with asyncio.timeout_at(deadline):
            result = await super().call_tool_at_generation(name, arguments, generation)
        if asyncio.get_running_loop().time() >= deadline:
            raise TimeoutError("MCP HTTP timeout")
        return result
'''
s=s.replace('        self._generation += 1\n        async with self._lifecycle:', '        self._generation += 1\n        self._invalidate_catalog()\n        await self._stop_refreshes()\n        async with self._lifecycle:',1)
f.write_text(s)
f=p/'adapter.py';s=f.read_text().replace('from friday_mcp.protocols import MCPClient, ToolDefinition','from friday_mcp.client.catalog import MCPCatalogSnapshot, MCPRefreshClient\nfrom friday_mcp.protocols import MCPClient, ToolDefinition')
s=s.replace('        name_prefix: str = "",\n    )','        name_prefix: str = "",\n        *,\n        catalog_snapshot: MCPCatalogSnapshot | None = None,\n    )',1)
s=s.replace('        self._client = client','''        self._client = client
        self._refresh_client: MCPRefreshClient | None = client if isinstance(client, MCPRefreshClient) else None
        snapshot = catalog_snapshot
        if snapshot is None and self._refresh_client is not None:
            snapshot = self._refresh_client.current_catalog_snapshot
        self._catalog_generation = snapshot.generation if snapshot is not None else None''',1)
s=s.replace('            result = await self._client.call_tool(self._original_name, kwargs)','''            if self._refresh_client is not None and self._catalog_generation is not None:
                result = await self._refresh_client.call_tool_at_generation(self._original_name, kwargs, self._catalog_generation)
            else:
                result = await self._client.call_tool(self._original_name, kwargs)''',1)
s=s.replace('        self._tools_cache: list[MCPToolWrapper] | None = None','''        self._tools_cache: list[MCPToolWrapper] | None = None
        self._cache_generation: int | None = None
        self._refresh_client: MCPRefreshClient | None = client if isinstance(client, MCPRefreshClient) else None
        self._cache_lock = asyncio.Lock()''',1)
start=s.index('        if self._tools_cache is not None and not refresh:');end=s.index('    async def get_tool(',start)
s=s[:start]+'''        async with self._cache_lock:
            current = self._refresh_client.current_catalog_snapshot if self._refresh_client is not None else None
            if self._refresh_client is not None and (current is None or current.generation != self._cache_generation):
                self._tools_cache = None
            if self._tools_cache is not None and not refresh:
                return list(self._tools_cache)
            self._tools_cache = None
            self._cache_generation = None
            if self._refresh_client is not None:
                snapshot = await self._refresh_client.refresh_tool_catalog()
                mcp_tools = snapshot.tools()
            else:
                snapshot = None
                mcp_tools = await self._client.list_tools()
            wrappers = [MCPToolWrapper(self._client, tool_def, self._prefix, catalog_snapshot=snapshot) for tool_def in mcp_tools]
            if self._refresh_client is not None:
                current = self._refresh_client.current_catalog_snapshot
                if current is None or snapshot is None or current.generation != snapshot.generation:
                    return []
            self._tools_cache = wrappers
            self._cache_generation = snapshot.generation if snapshot is not None else None
            logger.debug("Adapted %d MCP tools", len(wrappers))
            return list(wrappers)

'''+s[end:];s=s.replace('        self._tools_cache = None\n', '        self._tools_cache = None\n',1);f.write_text(s)
f=p/'__init__.py';s=f.read_text().replace('from friday_mcp.client.base import MCPClientBase, MCPError','from friday_mcp.client.base import MCPClientBase, MCPError\nfrom friday_mcp.client.catalog import MCPCatalogSnapshot, MCPRefreshClient');s=s.replace('    "MCPClientBase",','    "MCPClientBase",\n    "MCPCatalogSnapshot",\n    "MCPRefreshClient",');f.write_text(s)
