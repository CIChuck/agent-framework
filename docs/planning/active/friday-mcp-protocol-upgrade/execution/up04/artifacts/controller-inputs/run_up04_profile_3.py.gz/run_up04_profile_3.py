from pathlib import Path
import json,subprocess,hashlib
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';profile=json.loads((p/'verification-profile-UP-04.json').read_text());j=json.loads((p/'authority-UP-04.json').read_text());runner=b/'run_check_UP04.py'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for x in j['controls']+j['prior_frozen_manifests']:
 if h(w/x['path'])!=x['sha256']:raise RuntimeError('Control drift')
for path,digest in j['metadata_hashes'].items():
 if h(w/path)!=digest:raise RuntimeError('Metadata drift')
freeze={'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'authority_sha256':h(p/'authority-UP-04.json'),'profile_sha256':h(p/'verification-profile-UP-04.json'),'runner_sha256':h(runner),'original_runner_sha256':h(b/'run_check.py'),'guard_sha256':h(b/'guard/sitecustomize.py'),'environment_delta':'Per-check fresh private MYPY_CACHE_DIR/RUFF_CACHE_DIR/pytest cache; frozen concrete argv/env/source hashes in each preflight','checks':profile['checks']}
(b/'up04-profile-freeze-3.json').write_text(json.dumps(freeze,indent=2)+'\n')
for c in profile['checks']:
 label='up04-full3-'+c['id'];subprocess.run([str(b/'venv/bin/python'),str(runner),label,c['snapshot'],*c['argv']],check=True)
 receipt=json.loads((b/'checks'/label/'receipt.json').read_text());print(json.dumps({'id':c['id'],'child_exit':receipt['exit_code']}),flush=True)
 if receipt['exit_code'] and c['id'] not in ['root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy']:
  print((b/'checks'/label/'stdout').read_text()[-7000:],flush=True);raise RuntimeError('Required check failed: '+c['id'])
print('UP04_PROFILE_COMMANDS_COMPLETE',flush=True)
