from pathlib import Path
import json,hashlib,re,gzip
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';e=p/'execution/up04'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
base='packages/friday-mcp/tests_mcp/client/test_result_refresh.py::';interop='packages/friday-mcp/tests_mcp/client/test_result_refresh_interop.py::'
criteria={
'RES-AC-01':(['test_failed_refresh_retires_cached_and_validated_wrappers_before_io','test_existing_base_subclass_raw_virtual_methods_are_not_bypassed'],['test_reconnect_removed_tool_and_failed_schema_cannot_issue_calls']),
'RES-AC-02':(['test_serial_refresh_returns_own_generation_after_failure'],['test_failed_refresh_retires_cached_and_validated_wrappers_before_io','test_refresh_wait_deadline_and_disconnect_settle_owned_tasks']),
'RES-AC-03':(['test_call_keeps_old_output_schema_across_successful_refresh','test_modern_http_headers_and_schema_are_captured_before_scheduling_exchange','test_2025_raw_call_recovery_keeps_schema_and_retires_wrappers'],['test_reconnect_removed_tool_and_failed_schema_cannot_issue_calls']),
'RES-AC-04':(['test_modern_structured_values_and_2025_object_only_are_explicit','test_error_shape_validation_precedes_success_schema_and_error_disposition'],['test_malformed_error_content_is_invalid_before_error_disposition']),
'RES-AC-05':(['test_2025_required_task_tools_excluded_without_enabling_tasks','test_valid_input_requests_remain_unsupported_without_continuation'],['test_valid_unsupported_content_is_not_fetched_or_silently_dropped','test_malformed_input_requests_and_unsolicited_task_results_are_never_promoted']),
'RES-AC-06':(['test_modern_structured_values_and_2025_object_only_are_explicit'],['test_malformed_error_content_is_invalid_before_error_disposition','test_refresh_wait_deadline_and_disconnect_settle_owned_tasks']),
'RES-AC-07':([],[]),
'RES-AC-08':(['test_refresh_wait_deadline_and_disconnect_settle_owned_tasks'],['test_serial_refresh_returns_own_generation_after_failure','test_reconnect_removed_tool_and_failed_schema_cannot_issue_calls']),
'RES-AC-09':([],[]),
'RES-AC-10':([],[])}
source_paths=['packages/friday-mcp/src/friday_mcp/client/'+n+'.py' for n in ['catalog','adapter','base','http','protocol']]
ledger={}
for k,(positive,negative) in criteria.items():
 refs=[base+x for x in positive+negative]
 for ref in refs:
  file,name=ref.split('::')
  if not re.search(r'\bdef '+re.escape(name)+r'\(', (w/file).read_text()):raise RuntimeError('Missing test '+ref)
 ledger[k]={'positive':[base+x for x in positive],'negative':[base+x for x in negative],'source_paths':source_paths,'check_ids':['focused','mcp','core-runtime-chat-telemetry','root'],'scope':'New evidence supplements unchanged accepted transport/assembly requirement mapping; all required checks and complete source/schema reconciliation control.'}
for k in ['RES-AC-01','RES-AC-02','RES-AC-03','RES-AC-07','RES-AC-08']:
 ledger[k]['positive'].extend(interop+x for x in ['test_real_sdk_stdio_failed_removed_and_reconnected_catalog','test_real_tls_refresh_failure_removal_reconnect_no_stale_calls'])
 ledger[k]['negative'].extend(ledger[k]['positive'][-2:])
old=json.loads((p/'execution/up03/criterion-ledger.json').read_text())
for k in ['RES-AC-06','RES-AC-09','RES-AC-10']:
 for item in old.values():
  ledger[k]['positive'].extend(item.get('positive',[]));ledger[k]['negative'].extend(item.get('negative',[]))
# Retain each applicable accepted clause's positive/negative mapping and add explicit
# actual tests against this unit's generation/result obligations.
plan=e/'preconstruction-requirement-plan.json';j=json.loads(plan.read_text())
j['status']='Builder actual source/test mapping; independent review pending';j['preconstruction_plan_sha256']=h(plan)
for c in j['clauses']:
 c['criteria']=c['planned_criteria'];c['source_paths']=source_paths;c['check_ids']=['focused','http','original','mcp','core-runtime-chat-telemetry','root']
 c['positive']=list(dict.fromkeys(c.get('positive',[])+[ref for k in c['criteria'] for ref in ledger[k]['positive']]))
 c['negative']=list(dict.fromkeys(c.get('negative',[])+[ref for k in c['criteria'] for ref in ledger[k]['negative']]))
 for key in ['planned_positive','planned_negative']:c.pop(key,None)
for item in j['selected_schema_interfaces']:
 item['criteria']=item['planned_criteria'];item['source_paths']=source_paths
 item['actual_evidence']={k:ledger[k] for k in item['criteria']};item.pop('planned_evidence',None)
(e/'criterion-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');j['criterion_ledger_sha256']=h(e/'criterion-ledger.json')
(e/'normative-clause-ledger.json').write_text(json.dumps(j,indent=2)+'\n')
print(json.dumps({'clauses':len(j['clauses']),'schemas':len(j['selected_schema_interfaces']),'fields':j['selected_schema_fields'],'criteria':len(ledger)}))
