from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=json.loads((p/'authority-UP-03.json').read_text());prefix=sys.argv[1];selected=set(sys.argv[2:]);profile=json.loads((p/'verification-profile-UP-03.json').read_text());h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert h(b/'run_check.py')==profile['runner']['sha256'];assert h(b/'guard/sitecustomize.py')==profile['guard']['sha256']
checks=[item for item in profile['checks'] if not selected or item['id'] in selected]
for item in checks:
 label=prefix+'-'+item['id'];home=b/'homes'/label;snapshot=b/item['snapshot'];env={'PATH':str(b/'venv/bin')+':/opt/homebrew/bin:/usr/bin:/bin','HOME':str(home),'TMPDIR':str(b/'tmp'),'PYTHONPATH':':'.join([str(b/'guard')]+[str(x) for x in sorted((snapshot/'packages').glob('*/src'))]+[str(snapshot/'packages/friday-chat/tests_chat')]),'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0','PYTEST_ADDOPTS':'--import-mode=importlib','UV_CACHE_DIR':str(b/'cache'),'UV_NO_SYNC':'1','UV_OFFLINE':'1','UV_PROJECT_ENVIRONMENT':str(b/'venv'),'VIRTUAL_ENV':str(b/'venv'),'FRIDAY_TELEMETRY_ENABLED':'false','ANONYMIZED_TELEMETRY':'false','TOKENIZERS_PARALLELISM':'false','XDG_CACHE_HOME':str(home/'.cache'),'MPLCONFIGDIR':str(home/'mpl')}
 d=b/'checks'/label
 if d.exists():raise RuntimeError('Evidence label already exists')
 d.mkdir(parents=True)
 frozen={'recorded_utc':datetime.now(timezone.utc).isoformat(),'check':item,'environment':env,'product_hashes':{f['path']:h(w/f['path']) for f in a['product_paths']},'authority_sha256':h(p/'authority-UP-03.json'),'effects_sha256':h(p/'execution/up03/effects-and-check-profile.json'),'runner_sha256':h(b/'run_check.py'),'guard_sha256':h(b/'guard/sitecustomize.py'),'source_branch':subprocess.check_output(['git','branch','--show-current'],cwd=w,text=True).strip(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'baseline_manifest_sha256':h(b/'up03-baseline-snapshot.json')}
 (d/'before-execution.json').write_text(json.dumps(frozen,indent=2)+'\n')
 subprocess.run([str(b/'venv/bin/python'),str(b/'run_check.py'),label,item['snapshot'],*item['argv']],check=True)
 receipt=json.loads((d/'receipt.json').read_text());assert receipt['environment']==env and receipt['argv']==item['argv']
 assert {f['path']:h(w/f['path']) for f in a['product_paths']}==frozen['product_hashes'],'Product changed during verification'
 expected=1 if item['id'] in {'root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy'} else 0
 if receipt['exit_code']!=expected:
  print('UNEXPECTED CHILD EXIT '+label,flush=True);sys.exit(2)
print('Required selected profile child exits match; exact debt and skips need separate comparison.',flush=True)
