from pathlib import Path
import json,subprocess,hashlib
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';profile=json.loads((p/'verification-profile-REM-MCP-UP-004.json').read_text());a=json.loads((p/'authority-REM-MCP-UP-004.json').read_text());runner=b/'run_check_UP04.py'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def require(c,msg):
 if not c:raise RuntimeError(msg)
require(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Dirty candidate')
for x in a['controls']+a['prior_frozen_manifests']+[a['approval'],a['approved_proposal']]:require(h(w/x['path'])==x['sha256'],'Authority drift')
for path,d in a['metadata_hashes'].items():require(h(w/path)==d,'Metadata drift')
allowed={x['path'] for x in a['product_paths']}
for path,d in a['all_original_up04_product_hashes'].items():
 if path not in allowed:require(h(w/path)==d,'Other product drift')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();hashes={path:h(w/path) for path in a['all_original_up04_product_hashes']}
require(h(runner)=='5e5c9901bf66117ee11669d32de857ea2087738add9eef3c7ae6aa6f3c8592a6','Runner drift');require(h(b/'guard/sitecustomize.py')=='38f6a7483d66a066336d63c14980f1acfe307ec38848f0761c6928a66989a7a8','Guard drift')
freeze={'candidate':head,'product_hashes':hashes,'authority_sha256':h(p/'authority-REM-MCP-UP-004.json'),'profile_sha256':h(p/'verification-profile-REM-MCP-UP-004.json'),'runner_sha256':h(runner),'original_runner_sha256':h(b/'run_check.py'),'guard_sha256':h(b/'guard/sitecustomize.py'),'checks':profile['checks']};(b/'rem004-profile-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for c in profile['checks']:
 require(head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip() and hashes=={path:h(w/path) for path in hashes},'Candidate drift')
 label='rem004-full-'+c['id'];require(not (b/'checks'/label).exists(),'Evidence label exists')
 subprocess.run([str(b/'venv/bin/python'),str(runner),label,c['snapshot'],*c['argv']],check=True)
 receipt=json.loads((b/'checks'/label/'receipt.json').read_text());print(json.dumps({'id':c['id'],'child_exit':receipt['exit_code']}),flush=True)
 expected=1 if c['id'] in ['root-ruff','baseline-root-ruff','full-mypy','baseline-full-mypy'] else 0
 if receipt['exit_code']!=expected:print((b/'checks'/label/'stdout').read_text()[-7000:],flush=True);raise RuntimeError('Required check failed '+c['id'])
print('REM004_PROFILE_COMMANDS_COMPLETE',flush=True)
