from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,importlib.util
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';root=Path('/Users/chuckrussell/Dev/gendev/agent-framework');p=w/'docs/planning/active/friday-mcp-protocol-upgrade';expected='6ac560af176c50d432761c53204e765985348066'
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
def dump(f,j):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(j,indent=2)+'\n')
for repo in [w,root]:
 if subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()!=expected:raise RuntimeError('HEAD drift')
if subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip():raise RuntimeError('Private dirty')
proposal=p/'proposals/REM-MCP-UP-004-authority-manifest.json';j=json.loads(proposal.read_text())
for x in j['controls']+j['prior_frozen_manifests']:
 if h(w/x['path'])!=x['sha256']:raise RuntimeError('Control drift')
for path,d in (j['all_original_up04_product_hashes']|j['metadata_hashes']).items():
 if h(w/path)!=d:raise RuntimeError('Product or metadata drift')
preserve=b/'rem004-root-preservation';preserve.mkdir(exist_ok=False)
for name in ['board.yaml','README.md']:(preserve/name).write_bytes((root/'docs/planning'/name).read_bytes())
known=json.loads((b/'up04-execution-root-preservation/preservation.json').read_text())
for path,d in known.items():
 if h(root/path)!=d:raise RuntimeError('Unrelated root path drift')
dump(preserve/'preservation.json',known)
spec=importlib.util.spec_from_file_location('board',w/'scripts/friday-dev-board.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);board=m.load_board(w);dirty=m.load_board(root);clean={x['id']:x for x in board['tasks']};overlay={'tasks':{x['id']:x for x in dirty['tasks'] if x['id'] not in clean or x!=clean[x['id']]},'events':[x for x in dirty['events'] if x not in board['events']]}
if set(overlay['tasks'])!={'friday-telemetry-rewire','friday-tool-manifest-continuity'} or len(overlay['events'])!=3:raise RuntimeError('Unexpected overlay')
dump(preserve/'board-overlay.json',overlay)
rf=p/'approval-REM-MCP-UP-004.json';dump(rf,{'directive':'REM-MCP-UP-004','work_unit':'MCP-UP-04','status':'approved','approved_by':'Chuck Russell','maintainer_statement':'approved , continue','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'proposal_commit':expected,'proposal_manifest_sha256':h(proposal),'scope':'Exact three product files, both independent findings, bound full20-check profile, separate security remediator and fresh delta plus full-unit independent review','later_unit_or_delivery_authority':'not granted'})
a=dict(j);a.update(status='approved_execution',implementation_authority='granted',approval={'path':str(rf.relative_to(w)),'sha256':h(rf)},approved_proposal={'path':str(proposal.relative_to(w)),'sha256':h(proposal)},execution_baseline=expected);dump(p/'authority-REM-MCP-UP-004.json',a)
sf=p/'execution/current-process-state.json';s=json.loads(sf.read_text());s.update(remediation_status='approved',remediation_implementation_authority='granted',validation_state='not_ready',note='Exact REM-MCP-UP-004 approval recorded; separate security remediator authorized for three product files; original controls retained',next_gate='Separate remediator resolves both findings within three-file scope; freeze corrected candidate, repeat full checks, then fresh delta and full UP-04 independent review');dump(sf,s)
log=p/'execution-log.md';log.write_text(log.read_text()+'\n\n## 2026-10-13 - exact REM-MCP-UP-004 approved\n\nChuck Russell stated “approved , continue” in response to the complete three-file\nremediation packet. Separate approval and execution authority bind the immutable\nproposal/profile, both findings, a separate security remediator and fresh delta\nplus full-unit review. Original reports and controls remain retained. No later\nunit, dependency change or publication authority is inferred.\n')
t=next(x for x in board['tasks'] if x['id']=='friday-mcp-protocol-upgrade');t['next_gate']=s['next_gate'];m._append_event(board,task_id=t['id'],actor='Chuck Russell',actor_role='maintainer',action='approved exact REM-MCP-UP-004',note='Exact statement: approved , continue. Three product files; separate security remediator; full checks and fresh independent review; local only',evidence=str(rf.relative_to(w)));m._save_board_and_dashboard(board,w)
for label,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show','friday-mcp-protocol-upgrade'],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 subprocess.run([str(b/'venv/bin/python'),str(b/'run_check.py'),'rem004-approved-'+label,'work',str(b/'venv/bin/python'),*args],check=True)
 if json.loads((b/'checks'/('rem004-approved-'+label)/'receipt.json').read_text())['exit_code']:raise RuntimeError('Process check failed')
paths=[str((p/x).relative_to(w)) for x in ['approval-REM-MCP-UP-004.json','authority-REM-MCP-UP-004.json','execution/current-process-state.json','execution-log.md']]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths],cwd=w,check=True);subprocess.run(['git','commit','-m','Record exact MCP UP-04 remediation approval'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip())
