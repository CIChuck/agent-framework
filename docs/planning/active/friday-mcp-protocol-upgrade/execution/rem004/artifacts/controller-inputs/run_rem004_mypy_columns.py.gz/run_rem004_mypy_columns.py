from pathlib import Path
import subprocess,json
b=Path('/private/tmp/friday-mcp-upgrade');p=b/'work/docs/planning/active/friday-mcp-protocol-upgrade';checks=json.loads((p/'verification-profile-REM-MCP-UP-004.json').read_text())['checks']
for key in ['full-mypy','baseline-full-mypy']:
 c=next(x for x in checks if x['id']==key);label='rem004-'+key+'-columns'
 if (b/'checks'/label).exists():raise RuntimeError('Evidence exists')
 subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP04.py'),label,c['snapshot'],*c['argv'],'--show-column-numbers','--no-pretty'],check=True)
 if json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']!=1:raise RuntimeError('Wrong inherited diagnostic exit')
