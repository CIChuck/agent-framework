from pathlib import Path
import gzip,hashlib,importlib.util,json,subprocess
b=Path('/private/tmp/friday-mcp-upgrade');w=b/'work';p=w/'docs/planning/active/friday-mcp-protocol-upgrade';a=json.loads((p/'authority-UP-05-amendment-002.json').read_text());request=json.loads((p/'validation-request-UP05.json').read_text());review=p/'validation/VAL-UP05-01';original=json.loads((b/'independent-review-UP05-001/evidence-manifest.json').read_text());state=p/'execution/current-process-state.json';s=json.loads(state.read_text());planning_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def req(v,m):
 if not v:raise RuntimeError(m)
def dump(f,j):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(j,indent=2)+'\n')
req(original['outcome']=='CHANGES_REQUESTED' and s['validation_state']=='changes_requested','Review disposition not appropriate');req(not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip(),'Dirty checkout');req(h(review/'report.md')==s['independent_report_sha256'],'Report drift')
paths=['packages/friday-mcp/src/friday_mcp/server/http_policy.py','packages/friday-mcp/src/friday_mcp/server/modern_stdio.py','packages/friday-mcp/tests_mcp/server/test_streamable_http.py','packages/friday-mcp/tests_mcp/server/test_modern_stdio.py','packages/friday-mcp/tests_mcp/server/test_server_lifecycle.py','docs/guides/18-mcp-server.md']
req(set(paths).issubset(request['product_paths']),'Scope exceeds original unit')
findings=original.get('findings',[]);req({x['id'] for x in findings}=={'VAL-UP05-001','VAL-UP05-002','VAL-UP05-003','VAL-UP05-004'},'Reconcile findings before exact scope freeze')
directive=p/'directives/REM-MCP-UP-006-server-boundary-and-stdio-ownership.md';profile=p/'verification-profile-REM-MCP-UP-006.json';proposal=p/'proposals/REM-MCP-UP-006-authority-manifest.json'
report=review/'report.md';manifest=review/'stored-manifest.json'
text='''# REM-MCP-UP-006: Server header errors and stdio ownership

Status: **proposed; remediation implementation authority not granted**.

This is a bounded correction of the fresh full-unit MCP-UP-05 review in
[VAL-UP05-01](../validation/VAL-UP05-01/report.md). The original report and raw
probes remain immutable. The approved CD-MCP-UP-005 and AMEND001/002 continue to
control all unaffected behavior; no scope or specification exception is added.
The reviewer-reproduced findings below are the sole remediation objectives.

## Separation and authorization

A separate remediator is required for the security/resource-lifecycle/architecture
finding under [independent validation policy](../../../../reference/policies/independent-validation-policy.md).
The original builder may prepare this packet and preserve evidence, but will not
repair these sources or approve the result. Exact maintainer approval of this
directive/profile/manifest is the final prerequisite for source changes.

## Exact product scope

Only these six existing paths may change; all are already within the original
18-path UP-05 budget:

'''+''.join('- `'+x+'`\n' for x in paths)+'''
No other product file, client/legacy server/Core/Runtime/Chat/telemetry source,
metadata, dependency, guard, runner or installed distribution may change.
Process-only preconstruction/final mappings, reports and raw receipts are allowed
in this packet. Preserve the six unrelated shared-checkout hashes and two-task/
three-event board overlay. No broad stage/reset/stash/clean or protected-state read.

## Required bounded corrections

1. VAL-UP05-004: Recognized mirrored parameter headers with CR/LF/NUL, invalid characters or
   duplicates must fail closed before any handler and return exact HTTP400 with
   JSON-RPC HeaderMismatch -32020. Retain byte bounds, authentication, Host/Origin,
   TLS, Base64 decoding and standard-header/body equality. Do not leak header
   values or relax generic HTTP/access validation to satisfy a code assertion.
2. VAL-UP05-003: Capture the stdio frame's original absolute deadline when its first byte is
   received. Partial/oversized frame accumulation and completion cannot refresh
   the budget. A late completed frame must not invoke a handler. Preserve idle
   connection behavior, fragmentation, subsequent valid frames where safe, EOF
   cleanup, actual wire caps and the configured lower-only budgets.
3. VAL-UP05-001: Error/oversize/rejection response writes must not block the
   stdio reader's processing of cancellation or EOF. Use explicitly bounded
   connection-owned output work with serialized writes and original deadlines.
   No unbounded queue/executor, task shedding or handler replay.
4. VAL-UP05-002: Track the serving loop and every asynchronous write/owner under
   its captured connection generation and owned signal registrations, including cancellation-resistant drains
   and lock waits. Shutdown must report incomplete settlement and block restart
   while old owners remain. An old serve finalizer, write callback, EOF or
   cancellation must never clear, stop, close or publish into a newer connection.
   Require connection-token ownership checks for teardown as well as response
   emission and ID-map removal. No false quiescence or stale cleanup.

## Preconstruction and regression evidence

Before changing source, the separate remediator reads the exact authority chain,
reviewed candidate/diff, both changed source modules and their public lifecycle/
protocol dependencies, all six allowed files and the review's original probes.
Freeze a prospective finding-to-field/clause/source/test/command plan. Extend the
corrected modern2026 actual mapping without modifying original controls or the
historical wrong2025 plan. Each finding appears once in the finding ledger below.

Tests must independently reproduce malformed recognized parameter headers with
zero-handler counts and exact wire codes; partial frames spanning a short original
deadline with zero invocation; cancellation received while an error/oversize/
rejection write is blocked; cancellation-resistant error drain and truthful owners;
failed stop/restart blocking until settlement; released old owners unable to close
or corrupt the new connection; EOF/partial-start/native subprocess shutdown and
multiple simultaneous writers/operations under budgets1..4. Use events/counters
and actual synthetic streams, not an assertion that mirrors a helper implementation.
Keep existing positive fragmentation, JSON-only stdout, handler output, real SDK
stdio/TLS JSON/SSE, and cancellation-isolation regressions.

## Verification and acceptance criteria

Each numbered finding must resolve with concrete new regression assertions and
preserved original probe evidence. All12 original SRV-AC criteria remain required.
Repeat the unchanged20-check profile on a stable committed corrected candidate,
plus explicit-column Mypy comparisons, the supplemental finding probes and all
22009 library-file/192-distribution hashes captured before the first check and
after the last check. The corrected-candidate review must independently satisfy
this chronology; historical samples taken during checks are not before-first evidence. Exact327 root Ruff full
objects/fixes,4 Mypy diagnostics including columns, full skip locations/reasons
and warnings must match the freshly executed accepted baseline; changed/narrow
Ruff and Mypy remain clean. Preserve19 metadata and60 accepted product hashes.

A **fresh-context read-only remediation delta review followed by full UP-05 review**
must return VERIFIED before any unit completion proposal. Validator receives all
18 current product paths, all12 criteria and all20 checks, not just six correction
files. Acceptance belongs to the maintainer. Whole MCP/UP06 aggregate closeout,
Langfuse and remote delivery remain later gates.

## Effects, non-goals and stop conditions

Only already-approved synthetic Friday subprocess stdio, literal127.0.0.1 ephemeral
verified TLS JSON/SSE and deterministic/ASGI fixtures under the unchanged private
guard/environment may run. No public DNS/network, user stores/real tools/providers,
ambient secrets, install/sync/shared environment writes, non-loopback listener,
OAuth/session/Tasks/callback features, new metadata, publication or deployment.
Store exact raw failures/results and safe explicit evidence allowlists; exclude
runtime caches/stores/private keys. Do not edit any prior report/control/source
capture or rewrite a failure into a pass. Stop on scope ambiguity/unexpected
external effects and after two unsuccessful formal remediation cycles.

## Original numbered finding ledger

'''
for finding in findings:text+='```json\n'+json.dumps(finding,indent=2)+'\n```\n\n'
directive.write_text(text)
prof={'initiative':a['initiative'],'unit':'MCP-UP-05','directive':'REM-MCP-UP-006','status':'proposed/not_granted','required_checks':a['required_checks'],'acceptance_criteria':a['acceptance_criteria'],'finding_regressions':findings,'guard':a['guard'],'runner':a['runner'],'permitted_effects':a['permitted_effects'],'additional_required_evidence':['Supplemental explicit-column Mypy complete4-object comparison','Exact327 normalized Ruff complete diagnostic/fix object comparison','Root full warning and skip location/reason comparison against fresh accepted baseline','22009 library files/192 distributions before/after unchanged','Original failed independent probes and new corrected reruns preserved losslessly','Prospective finding-specific modern schema/paragraph/variant plan and final actual mapping','Fresh separate validator remediation delta then complete18-path/12-criterion work-unit review']};dump(profile,prof)
controls=request['controls']+[request['authority_manifest'],{'path':str(report.relative_to(w)),'sha256':h(report)},{'path':str(manifest.relative_to(w)),'sha256':h(manifest)},{'path':str(directive.relative_to(w)),'sha256':h(directive)},{'path':str(profile.relative_to(w)),'sha256':h(profile)}]
m={'initiative':a['initiative'],'work_unit':'MCP-UP-05','directive':'REM-MCP-UP-006','status':'proposed','implementation_authority':'not_granted','required_separate_remediator':True,'reviewed_baseline':original['candidate_commit'],'planning_baseline':planning_head,'original_product_baseline':a['product_baseline'],'branch':'feature/friday-mcp-protocol-upgrade','findings':findings,'product_paths':[{'path':x,'baseline_sha256':h(w/x)} for x in paths],'full_original_product_hashes':request['product_hashes'],'original_acceptance_criteria':a['acceptance_criteria'],'required_checks':a['required_checks'],'controls':controls,'preserved_product_hashes':a['preserved_product_hashes'],'metadata_hashes':a['metadata_hashes'],'guard':a['guard'],'runner':a['runner'],'permitted_effects':a['permitted_effects'],'non_goals':a['non_goals'],'approval_gate':'Maintainer exact REM006 directive/profile/manifest approval before separate remediator source changes','review_gate':'Fresh-context read-only remediation delta then full18-path UP05 review; VERIFIED required before completion; maintainer acceptance and UP06 separate','prior_unsuccessful_remediation_cycles':0};dump(proposal,m)
s.update(execution_phase='planning',validation_state='changes_requested',remediation_directive=str(directive.relative_to(w)),remediation_status='proposed',remediation_implementation_authority='not_granted',remediation_proposal=str(proposal.relative_to(w)),note='Original independent CHANGES_REQUESTED preserved; exact six-path correction packet prepared; separate remediator required',next_gate='Maintainer approval of REM-MCP-UP-006 exact six-path server header/deadline/ownership correction, then separate remediator and fresh delta/full UP-05 review');dump(state,s)
log=p/'execution-log.md';log.write_text(log.read_text()+'\n\n## REM-MCP-UP-006 bounded correction proposal\n\nFresh UP05 CHANGES_REQUESTED findings are recorded exactly once in proposed\nREM-MCP-UP-006. Six existing product paths, unchanged original12 criteria/20 checks,\nexisting private effects and original modern schema constraints. Security/lifecycle/\narchitecture requires a separate remediator. No source change made or authority\ngranted; exact maintainer approval is required. Original report/probes/controls\nremain immutable; acceptance/UP06/publication remain later gates.\n')
spec=importlib.util.spec_from_file_location('board',w/'scripts/friday-dev-board.py');bm=importlib.util.module_from_spec(spec);spec.loader.exec_module(bm);board=bm.load_board(w);t=next(x for x in board['tasks'] if x['id']==a['initiative']);t['next_gate']=s['next_gate'];bm._append_event(board,task_id=t['id'],actor='Codex controller',actor_role='agent',action='prepared exact REM-MCP-UP-006 proposal',note='Six-path correction of independent UP05 findings; separate remediator required; implementation not granted; started/local',evidence=str(directive.relative_to(w)));bm._save_board_and_dashboard(board,w)
for key,args in {'board':['scripts/friday-dev-board.py','validate'],'next':['scripts/friday-dev-board.py','next'],'show':['scripts/friday-dev-board.py','show',a['initiative']],'docs':['scripts/check-documentation-lifecycle.py'],'render':['scripts/friday-dev-board.py','render','--check']}.items():
 label='rem006-planning-'+key;subprocess.run([str(b/'venv/bin/python'),str(b/'run_check_UP05.py'),label,'work',str(b/'venv/bin/python'),*args],check=True);req(json.loads((b/'checks'/label/'receipt.json').read_text())['exit_code']==0,'Planning check failed')
evidence=p/'execution/rem006-planning';entries=[]
for key in ['board','next','show','docs','render']:
 for name in ['preflight.json','receipt.json','stdout','stderr']:
  raw=(b/'checks'/('rem006-planning-'+key)/name).read_bytes();out=evidence/'checks'/key/(name+'.gz');req(not out.exists(),'Planning evidence overwrite');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));entries.append({'path':str(out.relative_to(evidence)),'original_path':'rem006-planning-'+key+'/'+name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(out),'encoding':'gzip'})
raw=Path(__file__).read_bytes();out=evidence/'prepare_rem006_packet.py.gz';out.write_bytes(gzip.compress(raw,mtime=0));entries.append({'path':out.name,'original_path':'prepare_rem006_packet.py','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':h(out),'encoding':'gzip'})
dump(evidence/'manifest.json',{'status':'proposed/not_granted','proposal_sha256':h(proposal),'product_hashes':request['product_hashes'],'original_report_sha256':h(report),'entries':entries,'boundary':'Process-only proposal and five checks; no source changes or approval inferred'})
for x in entries:req(hashlib.sha256(gzip.decompress((evidence/x['path']).read_bytes())).hexdigest()==x['sha256'],'Planning archive drift')
for path,digest in request['product_hashes'].items():req(h(w/path)==digest,'Unauthorized product edit')
for x in controls:req(h(w/x['path'])==x['sha256'],'Control drift')
paths_to_stage=[str(x.relative_to(w)) for x in [directive,profile,proposal,state,log,evidence]]+['docs/planning/board.yaml','docs/planning/README.md'];subprocess.run(['git','add','--',*paths_to_stage],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);subprocess.run(['git','commit','-m','Propose bounded separate modern MCP server remediation'],cwd=w,check=True,stdout=subprocess.DEVNULL);print(json.dumps({'proposal_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'product_paths':6,'source_edits':0,'implementation_authority':'not_granted','separate_remediator':True,'findings':len(findings)}))
