from pathlib import Path
import importlib.util,json,subprocess,sys,time,datetime
P=Path('/private/tmp/telem-04/REM-005/readiness');spec=importlib.util.spec_from_file_location('h',P/'prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.OUT=P;h.GUARD=P/'network-guard'
root=P/'authority'
def run(label,args,cwd=root,timeout=180):
 stem=P/label
 if stem.with_suffix('.json').exists():raise RuntimeError('retain old receipt')
 env=h.environment(root,label);started=time.time();command=['uv','run','--no-sync',*args] if args[0] not in ('git','uv') else args
 result=subprocess.run(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
 (P/(label+'.stdout')).write_bytes(result.stdout);(P/(label+'.stderr')).write_bytes(result.stderr)
 h.save(label+'.json',dict(command=command,cwd=str(cwd),environment=env,exit=result.returncode,started_utc=datetime.datetime.fromtimestamp(started,datetime.timezone.utc).isoformat(),seconds=time.time()-started,stdout_sha256=h.sha(result.stdout),stderr_sha256=h.sha(result.stderr)))
 print(label,result.returncode,flush=True);return result
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='docs-initial':run('docs-original-initial',['python','scripts/check-documentation-lifecycle.py'],h.REPO)
 if mode=='checks':
  run('tool-resolution',['python',str(P/'tool_resolution.py')]);run('metadata-sdk',['python',str(P/'metadata.py')])
  run('root-ruff',['ruff','check','.','--output-format','json'])
  for label in ('unit','aggregate'):
   scope=json.loads((P/(label+'-scope.json')).read_text());run(label+'-ruff',['ruff','check',*scope['python']]);run(label+'-mypy',['mypy','--python-version','3.13',*scope['source']])
  for mode,args in [('validate',[]),('next',[]),('show',['friday-telemetry-rewire']),('render',['--check'])]:
   run('board-original-'+mode,['python','scripts/friday-dev-board.py',mode,*args],h.REPO)
  run('lock',['uv','lock','--check','--offline','--no-build','--no-python-downloads'])
  run('docs-authority-initial',['python','scripts/check-documentation-lifecycle.py'])
