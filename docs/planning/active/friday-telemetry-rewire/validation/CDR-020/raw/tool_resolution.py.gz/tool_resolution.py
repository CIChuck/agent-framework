import hashlib,importlib.metadata,importlib.util,json,pathlib,shutil,sys
names=['ruff','mypy','pytest','pydantic','opentelemetry-api','opentelemetry-sdk']
result={'python':sys.version,'executable':sys.executable,'executables':{n:shutil.which(n) for n in ['uv','ruff','mypy','pytest']},'distributions':{}}
for name in names:
    distribution=importlib.metadata.distribution(name)
    result['distributions'][name]={'version':distribution.version,'location':str(distribution.locate_file('')),'metadata_sha256':hashlib.sha256(distribution.read_text('METADATA').encode()).hexdigest()}
for name in ['friday_chat','friday_llm','friday_telemetry','ruff','mypy','pytest']:
    spec=importlib.util.find_spec(name);path=pathlib.Path(spec.origin)
    result.setdefault('modules',{})[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
print(json.dumps(result,indent=2))
