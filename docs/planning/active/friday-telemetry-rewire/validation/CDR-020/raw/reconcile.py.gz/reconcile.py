from pathlib import Path
import importlib.util,json,hashlib,gzip,subprocess,ast
P=Path('/private/tmp/telem-04/REM-005/readiness');R=Path('/Users/chuckrussell/Dev/gendev/agent-framework');prefix='docs/planning/active/friday-telemetry-rewire/'
spec=importlib.util.spec_from_file_location('h',P/'prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.OUT=P;h.GUARD=P/'network-guard'
h.save('original-before.json',h.original_state())
m=json.loads((R/prefix/'authority-manifest-REM-005.yaml').read_text());checks=[]
for pin in m['authority']:
 actual=h.sha((R/pin['path']).read_bytes());checks.append(dict(**pin,actual=actual,match=actual==pin['sha256']))
if len(checks)!=46 or not all(x['match'] for x in checks):raise RuntimeError('authority drift')
products={}
for p,digest in m['product_base_sha256'].items():
 frozen=h.sha(h.git('show',m['base']+':'+p));current=h.sha((R/p).read_bytes());products[p]=dict(expected=digest,frozen=frozen,current=current,match=digest==frozen==current)
if len(products)!=15 or not all(v['match'] for v in products.values()):raise RuntimeError('product drift')
report=gzip.decompress((R/prefix/'validation/VAL-009/raw/report.md.gz').read_bytes());report_sha=h.sha(report)
if report_sha!=m['original_report_sha256']:raise RuntimeError('report drift')
(P/'original-VAL-009-report.md').write_bytes(report)
a=json.loads((R/prefix/'validation/VAL-009/original-artifact-manifest.json').read_text());raw=R/prefix/'validation/VAL-009/raw';records=[]
for name,v in a['artifacts'].items():
 stored=raw/(name+'.gz');data=gzip.decompress(stored.read_bytes());actual=h.sha(data)
 records.append(dict(name=name,match=actual==v['sha256'] and len(data)==v['bytes'],sha256=actual,bytes=len(data)))
if not all(v['match'] for v in records):raise RuntimeError('original artifact drift')
h.save('authority-reconciliation.json',dict(manifest_sha256=h.sha((R/prefix/'authority-manifest-REM-005.yaml').read_bytes()),authority=checks,authority_count=46,products=products,product_count=15,original_report_sha256=report_sha,original_artifacts=records))
for name,rev in [('authority','3e07707d13f1db7c023d660d721e0b817661bdad'),('frozen-product',m['base']),('unit-base',m['unit_base']),('aggregate-base',m['aggregate_base'])]:
 h.prepare(name,rev)
for label,base in [('unit',m['unit_base']),('aggregate',m['aggregate_base'])]:
 names=h.git('diff','--name-only',base,m['base']).decode().splitlines();h.save(label+'-scope.json',dict(paths=names,python=[p for p in names if p.endswith('.py')],source=[p for p in names if p.endswith('.py') and '/src/' in p]))
print('46 authority pins;15 exact products;base revisions;original artifact bytes PASS;4 sanitized snapshots ready')
