from pathlib import Path
import sys,json,hashlib,shutil,importlib.metadata,tomllib,ast
P=Path('/private/tmp/telem-04/REM-005/readiness');R=P/'authority';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results={}
for name in ['python','ruff','mypy','pytest','uv']:
 p=Path(sys.executable if name=='python' else shutil.which(name));results[name]=dict(path=str(p),resolved=str(p.resolve()),sha256=sha(p))
floors={}
for p in sorted(R.glob('packages/*/pyproject.toml')):
 data=tomllib.loads(p.read_text());floor=data.get('project',{}).get('requires-python');floors[str(p.relative_to(R))]=floor
 if floor!='>=3.13.4':raise RuntimeError('floor drift')
scopes={l:json.loads((P/(l+'-scope.json')).read_text()) for l in ('unit','aggregate')}
for l,v in scopes.items():
 for name in v['source']:ast.parse((R/name).read_text(),feature_version=(3,13))
print(json.dumps(dict(binaries=results,package_floors=floors,package_count=len(floors),source_ast_python313=True,unit_sources=len(scopes['unit']['source']),aggregate_sources=len(scopes['aggregate']['source']),mypy_configuration=tomllib.loads((R/'pyproject.toml').read_text())['tool']['mypy']),indent=2))
