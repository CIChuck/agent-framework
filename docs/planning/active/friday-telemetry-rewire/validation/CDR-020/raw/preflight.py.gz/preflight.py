from pathlib import Path
import json,hashlib,ast
P=Path('/private/tmp/telem-04/REM-005/readiness');R=P/'authority';prefix='docs/planning/active/friday-telemetry-rewire/';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/prefix/'authority-manifest-REM-005.yaml').read_text());effect=json.loads((R/prefix/'execution/TELEM-04-planning/listener-scope.json').read_text());new={};fixtures={}
for p,digest in effect['fixture_hashes'].items():
 if sha(R/p)!=digest:raise RuntimeError('fixture drift '+p)
 fixtures[p]=dict(sha256=digest)
for p in m['product_manifest']['tests']:
 tree=ast.parse((R/p).read_text());imports=[ast.unparse(n) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))];calls=sorted({ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n,ast.Call)})
 suspicious=[s for s in imports+calls if any(x in s for x in ('grpc.','create_telemetry','socket.','HTTPServer','Chroma','os.environ','opentelemetry'))]
 if suspicious:raise RuntimeError('new test effect ambiguity '+p+repr(suspicious))
 new[p]=dict(sha256=sha(R/p),imports=imports,calls=calls,fake_only=True)
conftests={str(p.relative_to(R)):dict(sha256=sha(p),imports=[ast.unparse(n) for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,(ast.Import,ast.ImportFrom))]) for p in R.rglob('conftest.py') if '.git' not in p.parts}
probe=Path('/private/tmp/telem-04/VAL-009/sdk_probe.py');original=json.loads((R/prefix/'validation/VAL-009/original-artifact-manifest.json').read_text())
if sha(probe)!=original['artifacts']['sdk_probe.py']['sha256']:raise RuntimeError('sdk probe drift')
result=dict(effect_nodes=effect['existing_nodes'],count=len(effect['existing_nodes']),fixture_pins=fixtures,new_fake_tests=new,conftests=conftests,guard_sha256=sha(P/'network-guard/sitecustomize.py'),sdk_probe_sha256=sha(probe),sdk_allowance='Owned in-memory exporter/processor+Debug/two-child Composite;console exporter patched before create;global set forbidden;handle shutdown;zero workers and closed exporter checked;no transport;caller ownership retained',http='11 named existing synthetic127.0.0.1 ephemeral server/client nodes;synthetic placeholder;finite Chat10s retry0;LLM default finite timeout;server shutdown/server_close/thread join2s',grpc='2 named existing nodes;literal127.0.0.1 ephemeral;intercepted exact target/options;proxy0 retry0;finite request_timeout;TLS/credentials forbidden;channel owner close/server stop1s/executor shutdown/worker absence',limitation='Python audit guard cannot cover native gRPC I/O;fixed native target/options/owned cleanup independently audited',preflight='PASS')
(P/'effect-preflight.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS:46 approved pins;13 unchanged nodes;4 fixture hashes;6 fake-only new tests;owned SDK probe allowance;guard matched')
