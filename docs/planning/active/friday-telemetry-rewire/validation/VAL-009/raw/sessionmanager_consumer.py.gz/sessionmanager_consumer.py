from friday_cli.session import SessionManager
class Parent: pass
class Child(Parent): pass
def parent_to_child(value: SessionManager[Parent]) -> SessionManager[Child]:
    return value
def child_to_parent(value: SessionManager[Child]) -> SessionManager[Parent]:
    return value
