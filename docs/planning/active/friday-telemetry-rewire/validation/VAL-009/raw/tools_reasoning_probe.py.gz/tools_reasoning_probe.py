import asyncio,json
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.turns.telemetry import turn_scope
from friday_chat.tools.loop import ToolLoop
from friday_chat.tools.registry import FakeToolRegistry
from friday_chat.tools.schemas import ToolDefinition
from friday_chat.tools.output import MCPOutputPolicy
from friday_core.mcp import MCPToolMetadata
from friday_chat.runtime import build_runtime,FakeChatModel
from friday_chat.config import FridayChatConfig
from friday_chat.turns.models import ChatModelResponse,ToolCallRequest
from friday_chat.turns.processor import TurnProcessor

NAME='mcp_peer_private';metadata=MCPToolMetadata(canonical_name=NAME,server_name='peer',original_name='private',transport='stdio',trust_level='local')
class Registry(FakeToolRegistry):
 def __init__(self):super().__init__();self.dispatches=[]
 def is_mcp_tool(self,name):return name==NAME
 async def call_tool_record(self,name,arguments,**kwargs):
  self.dispatches.append(name)
  if name==NAME:return MCPOutputPolicy(4096).checked_record(metadata,'safeid','safe',arguments)
  return await super().call_tool(name,arguments)
async def main():
 o=ChatTelemetryObserver(enabled=True,session_id='PRIVATE_SESSION');registry=Registry()
 with turn_scope(o,'completion'):
  await ToolLoop(registry,observer=o).run([{'tool_calls':[{'name':NAME}]}],[ToolDefinition('echo','safe')],mcp_tool_names=frozenset({NAME}))
 rejection=next(dict(e.attributes) for e in o.snapshot().events if e.name=='execution.selection')
 assert not registry.dispatches and not o._spans
 findings=[]
 if rejection['rejected_native']!=0 or rejection['rejected_mcp']!=1:findings.append(dict(issue='known_disallowed_mcp_misclassified_as_native',selection=rejection,actual_dispatches=registry.dispatches))
 r=build_runtime(FridayChatConfig.model_validate({'llm':{'model':'fake/test'},'telemetry':{'enabled':True}}));r.tools=Registry()
 # Valid native return is a ToolCallRecord, MCP returns accepted checked provenance.
 from friday_chat.tools.schemas import ToolCallRecord
 native=r.tools.call_tool_record
 async def call_tool_record(name,args,**kw):
  if name!=NAME:return ToolCallRecord(name,args,'native safe',kw.get('call_id'))
  return await native(name,args,**kw)
 r.tools.call_tool_record=call_tool_record
 initial=ChatModelResponse(tool_calls=(ToolCallRequest('echo',{'text':'PRIVATE_NATIVE'},'nativeid'),ToolCallRequest(NAME,{'PRIVATE_ARG':'PRIVATE'},'mcpid')),reasoning_content='PRIVATE_REASONING1')
 r.chat_llm=FakeChatModel('fake',responses=[ChatModelResponse(tool_calls=(ToolCallRequest('echo',{'text':'safe'},'nativeid2'),),reasoning_content='PRIVATE_REASONING2'),ChatModelResponse.from_text('done')])
 with turn_scope(r.telemetry,'completion'):
  result,records=await TurnProcessor(r)._complete_tool_turn([{'role':'user','content':'PRIVATE_PROMPT'}],initial,(ToolDefinition('echo','safe'),ToolDefinition(NAME,'PRIVATE_SCHEMA')),mcp_names=frozenset({NAME}))
 histories=[dict(e.attributes) for e in r.telemetry.snapshot().events if e.name=='execution.reasoning_history']
 assert [(h['present'],h['preserved'],h['eligible']) for h in histories]==[(True,False,False),(True,True,True)]
 assert result.content=='done' and len(records)==3
 assert all('required' not in h for h in histories) and 'PRIVATE' not in repr(r.telemetry.snapshot())
 print(json.dumps(dict(rejection=rejection,reasoning=histories,model_dispatches=len(r.chat_llm.calls),tool_dispatches=len(records),issues=findings),indent=2))
asyncio.run(main())
