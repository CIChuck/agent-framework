from pathlib import Path
import importlib.util,json,hashlib,subprocess
P=Path('/private/tmp/telem-04/VAL-009')
spec=importlib.util.spec_from_file_location('isolation', '/private/tmp/telem-02/builder-baseline/prepare.py')
h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h); h.OUT=P
request=json.loads(Path('/private/tmp/telem-04/construction/validation-request-VAL-009.json').read_text())
h.save('request.json',request)
h.save('original-before.json',h.original_state())
root,receipt=h.prepare('candidate',request['candidate'])
base,basereceipt=h.prepare('unit-base',request['unit_base'])
aggregate,aggreceipt=h.prepare('aggregate-base',request['aggregate_base'])
authority=[]
for pin in request['authority']:
 actual=h.sha((root/pin['path']).read_bytes()); assert actual==pin['sha256'],pin['path']; authority.append(dict(**pin,verified=True))
assert h.sha((root/request['authority_manifest']).read_bytes())==request['authority_manifest_sha256']
assert h.sha((h.GUARD/'sitecustomize.py').read_bytes())=='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81'
h.save('authority-reconciliation.json',dict(authority=authority,manifest_sha256=request['authority_manifest_sha256'],count=len(authority)))
for label,b in [('unit',request['unit_base']),('aggregate',request['aggregate_base'])]:
 (P/(label+'.diff')).write_bytes(h.git('diff','--no-ext-diff',b,request['candidate']))
 names=h.git('diff','--name-only',b,request['candidate']).decode().splitlines(); h.save(label+'-scope.json',dict(paths=names,python=[p for p in names if p.endswith('.py')],source=[p for p in names if p.endswith('.py') and '/src/' in p]))
print(root)
