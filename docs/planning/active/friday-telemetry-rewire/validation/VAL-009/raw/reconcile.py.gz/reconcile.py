from pathlib import Path
import json,ast,hashlib,subprocess,tomllib,importlib.util
P=Path('/private/tmp/telem-04/VAL-009');root=P/'candidate';base=P/'unit-base';agg=P/'aggregate-base'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
req=json.loads((P/'request.json').read_text());a=json.loads((root/req['authority_manifest']).read_text())
assert a['authority']==req['authority'] and len(a['authority'])==40
for kind,ni,ns in [('unit',19,12),('aggregate',133,81)]:
 scope=json.loads((P/(kind+'-scope.json')).read_text());assert len(scope['python'])==ni;assert len(scope['source'])==ns
 assert set(req['required_commands'][5 if kind=='unit' else 6][2:])==set(scope['python'])
 assert set(req['required_commands'][8 if kind=='unit' else 9][3:])==set(scope['source'])
 for p in scope['python']: ast.parse((root/p).read_text(),feature_version=(3,13))
allowed={p for xs in a['product_manifest'].values() for p in xs}
unit=json.loads((P/'unit-scope.json').read_text());products=[p for p in unit['paths'] if p.startswith('packages/')];assert set(products)<=allowed
w=json.loads((root/'docs/planning/active/friday-telemetry-rewire/validation/WVR-006-telem04-lint-scope.json').read_text())
raw=json.loads((P/'command-08.stdout').read_text())
norm=[dict(path=str(Path(d['filename']).relative_to(root)),code=d['code'],location=d['location'],end_location=d['end_location'],message=d['message']) for d in raw]
# Scope stores a canonical path/code/start/end/message sort.
key=lambda d:json.dumps(d,sort_keys=True)
assert sorted(norm,key=key)==sorted(w['diagnostics'],key=key) and len(raw)==327
for p,h in {**w['archived_files'],**w['lint_configurations']}.items():assert sha(root/p)==sha(base/p)==h,p
reg='packages/friday-cli/src/friday_cli/commands.py';assert sha(root/reg)==sha(base/reg)==w['command_registry_source_sha256']
cls=next(n for n in ast.parse((root/reg).read_text()).body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry')
clsh=hashlib.sha256(ast.dump(cls,include_attributes=False).encode()).hexdigest();assert clsh==w['command_registry_class_ast_sha256']
assert tomllib.loads((root/'pyproject.toml').read_text())['tool']['ruff']['target-version']=='py313'
# Every metadata/template/config file and accepted interface/event/persistence unit input is unchanged by TELEM04.
fixed=[p for p in json.loads((P/'candidate-snapshot.json').read_text())['tracked_hashes'] if p.endswith(('pyproject.toml','uv.lock','.example.yaml','.example.yml','.example.toml'))]
for p in fixed:assert sha(root/p)==sha(base/p),p
floors={str(p.relative_to(root)):tomllib.loads(p.read_text())['project']['requires-python'] for p in root.rglob('pyproject.toml') if 'project' in tomllib.loads(p.read_text())}
assert len(floors)==18 and all(v=='>=3.13.4' for v in floors.values())
accepted=[]
for prefix in ['packages/friday-llm/src/','packages/friday-telemetry/src/friday_telemetry/interface.py','packages/friday-telemetry/src/friday_telemetry/models/llm_events.py','packages/friday-telemetry/src/friday_telemetry/models/mcp.py','packages/friday-chat/src/friday_chat/memory_mcp.py','packages/friday-chat/src/friday_chat/tools/output.py','packages/friday-chat/src/friday_chat/transcripts.py']:
 for p in json.loads((P/'candidate-snapshot.json').read_text())['tracked_hashes']:
  if p.startswith(prefix): assert sha(root/p)==sha(base/p),p;accepted.append(p)
new_suppressions=[];new_skips=[]
for p in unit['python']:
 before=(base/p).read_text().splitlines() if (base/p).exists() else [];after=(root/p).read_text().splitlines()
 for line in after:
  if line not in before:
   if any(x in line for x in ('type: ignore','noqa','mypy:','ignore-errors','disable-error-code')):new_suppressions.append([p,line])
   if any(x in line for x in ('pytest.skip','pytest.mark.skip','pytest.importorskip')):new_skips.append([p,line])
assert not new_suppressions and not new_skips
# Full source/test diff retained separately, stripping governance archives without using builder results.
diff=subprocess.check_output(['git','--no-optional-locks','-C',str(root),'diff',req['aggregate_base'],req['candidate'],'--',*json.loads((P/'aggregate-scope.json').read_text())['python']])
(P/'aggregate-python.diff').write_bytes(diff)
(P/'reconciliation.json').write_text(json.dumps(dict(authority_count=40,unit_python=19,unit_source=12,aggregate_python=133,aggregate_source=81,unit_product_paths=products,allowed29=sorted(allowed),ruff=dict(raw_exit=1,count=327,identities_equal=True,registry_source=sha(root/reg),registry_ast=clsh,archive_hashes=w['archived_files'],lint_configurations=w['lint_configurations'],target='py313'),python_floors=floors,unit_unchanged_metadata=fixed,accepted_unchanged=accepted,new_suppressions=new_suppressions,new_skips=new_skips,aggregate_python_diff_sha256=hashlib.sha256(diff).hexdigest()),indent=2)+'\n')
print('RECONCILED:40 authority pins;19/12 unit and133/81 aggregate exact command scope;29 allowed targets;327 exact Ruff identities + registryAST +17 configs +4 archives;18 floors;unchanged accepted contracts/metadata;no new suppressions/skips')
