import asyncio,json,threading
from unittest.mock import patch
from opentelemetry import trace
from opentelemetry.sdk.trace.export import SpanExporter,SpanExportResult
from friday_telemetry import CompositeProvider,DebugTelemetryRecorder,TelemetryFactoryConfig,OTelConfig,create_telemetry
from friday_chat.runtime import build_runtime
from friday_chat.config import FridayChatConfig
from friday_chat.turns.processor import TurnProcessor
observed=[];spans=[];exporters=[];initial=set(threading.enumerate());global_before=trace.get_tracer_provider()
class Exporter(SpanExporter):
 def __init__(self,stream):self.closed=False;exporters.append(self)
 def export(self,batch):spans.extend(batch);return SpanExportResult.SUCCESS
 def shutdown(self):self.closed=True
class Unprintable(RuntimeError):
 def __str__(self):raise AssertionError('private exception must not be stringified')
async def main(handle):
 for cancel in (False,True):
  debug=DebugTelemetryRecorder();r=build_runtime(FridayChatConfig.model_validate({'llm':{'model':'fake/test'},'tools':{'enabled':False}}),telemetry=CompositeProvider([debug,handle.telemetry]));error=asyncio.CancelledError() if cancel else Unprintable()
  async def fail(chunk):raise error
  try:await TurnProcessor(r).process_streaming('PRIVATE_PROMPT',on_chunk=fail)
  except BaseException as primary:assert primary is error
  assert r.telemetry.correlation.current() is None and not r.telemetry._spans and not handle.snapshot().active_spans
  assert all(s.end_time is not None for s in debug.spans.values())
  observed.append(dict(cancel=cancel,primary_preserved=True,all_spans_closed=True,borrowed_sink_still_open=not handle.snapshot().closed))
 assert handle.flush().status=='success'
with patch('friday_telemetry.providers._otel_exporter.SafeConsoleExporter',Exporter),patch.object(trace,'set_tracer_provider',side_effect=AssertionError('global registration forbidden')):
 handle=create_telemetry(TelemetryFactoryConfig(provider='otel',otel=OTelConfig(exporter='console')))
 try:asyncio.run(main(handle))
 finally:result=handle.shutdown()
assert result.status=='success' and not handle.snapshot().worker_alive and all(e.closed for e in exporters)
assert trace.get_tracer_provider() is global_before and not [t for t in threading.enumerate() if t not in initial]
print(json.dumps(dict(observed=observed,sdk_spans=len(spans),worker_leaks=0,global_unchanged=True,owned_cleanup='success'),indent=2))
