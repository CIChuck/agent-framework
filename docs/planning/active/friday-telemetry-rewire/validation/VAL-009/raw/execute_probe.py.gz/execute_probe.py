from pathlib import Path
import importlib.util,json,sys
P=Path('/private/tmp/telem-04/VAL-009')
spec=importlib.util.spec_from_file_location('run',str(P/'run_checks.py'));r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.run(sys.argv[1],['python',str(P/sys.argv[2])])
