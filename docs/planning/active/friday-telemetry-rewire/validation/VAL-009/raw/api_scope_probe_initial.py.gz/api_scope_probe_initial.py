from pathlib import Path
import ast,json,hashlib,importlib.util,tomllib,re,subprocess
P=Path('/private/tmp/telem-04/VAL-009');root=P/'candidate';base=P/'unit-base';aggregate=P/'aggregate-base'
spec=importlib.util.spec_from_file_location('h','/private/tmp/telem-02/builder-baseline/prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
reports={label:h.source_baseline(P/label) for label in ['aggregate-base','unit-base','candidate']}
assert reports['unit-base']['api']==reports['candidate']['api']
assert reports['unit-base']['legacy_default_expressions']==reports['candidate']['legacy_default_expressions']
old=set(reports['unit-base']['public_exports']);new=set(reports['candidate']['public_exports']);assert old<=new and new-old=={'ExecutionEvent','ExecutionContext','CorrelationScope'}
# Interface and old defaults also remain stable throughout the aggregate.
assert reports['aggregate-base']['legacy_default_expressions']==reports['candidate']['legacy_default_expressions']
iface='packages/friday-telemetry/src/friday_telemetry/interface.py';assert (root/iface).read_bytes()==(aggregate/iface).read_bytes()
for p in root.rglob('pyproject.toml'):
 rel=p.relative_to(root)
 if (aggregate/rel).exists():
  a=tomllib.loads((aggregate/rel).read_text());b=tomllib.loads(p.read_text())
  assert a.get('project',{}).get('dependencies')==b.get('project',{}).get('dependencies')
  assert a.get('project',{}).get('optional-dependencies')==b.get('project',{}).get('optional-dependencies')
# AST-aware whole aggregate inventory includes every Python artifact, including non-package files.
paths=json.loads((P/'aggregate-scope.json').read_text())['python'];inventory=[]
for rel in paths:
 current=(root/rel).read_text();prior=(aggregate/rel).read_text() if (aggregate/rel).exists() else ''
 tree=ast.parse(current,feature_version=(3,13));oldtree=ast.parse(prior,feature_version=(3,13))
 symbols={n.name:hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
 prior_symbols={n.name:hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in oldtree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
 changed=[name for name,v in symbols.items() if prior_symbols.get(name)!=v]
 tests=[n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
 inventory.append(dict(path=rel,sha256=h.sha((root/rel).read_bytes()),prior_sha256=h.sha((aggregate/rel).read_bytes()) if prior else None,changed_symbols=changed,test_cases=tests,full_ast_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
# Defaults of new correlation fields None, existing positional dataclass fields retained.
for rel,name in [('packages/friday-chat/src/friday_chat/runtime.py','PendingExtractionTurn'),('packages/friday-chat/src/friday_chat/turns/processor.py','TurnResult')]:
 def fields(path):
  cls=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.ClassDef) and n.name==name)
  return [(n.target.id,ast.unparse(n.annotation),ast.unparse(n.value) if n.value else None) for n in cls.body if isinstance(n,ast.AnnAssign)]
 b=fields(base/rel);c=fields(root/rel);assert c[:-1]==b and c[-1][0]=='correlation_context' and c[-1][-1]=='None'
(P/'api-and-full-aggregate-review.json').write_text(json.dumps(dict(api=reports,unit_exports_added=sorted(new-old),aggregate_dependencies_unchanged=True,interface_byte_identical=True,aggregate_inventory=inventory,additive_dataclass_defaults=True),indent=2)+'\n')
print('API/SCOPE:full133 Python AST+symbol inventory;interface/defaults/dependencies stable;3 additive exports;optional last dataclass fields defaultNone')
