from pathlib import Path
import importlib.util,json,re
P=Path('/private/tmp/telem-04/VAL-009');spec=importlib.util.spec_from_file_location('r',str(P/'run_checks.py'));r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
imports={'CommandRegistry':'friday_cli.commands','SessionContext':'friday_cli.session','SessionManager':'friday_cli.session','ToolAdapter':'friday_core.interfaces.tools','MoltbookResponse':'friday_moltbook.responses','MemoryMetric':'friday_chat.memory_views'}
consumers=[]
for name,mod in imports.items():
 f=P/(name.lower()+'_consumer.py');f.write_text(f'''from {mod} import {name}
class Parent: pass
class Child(Parent): pass
def parent_to_child(value: {name}[Parent]) -> {name}[Child]:
    return value
def child_to_parent(value: {name}[Child]) -> {name}[Parent]:
    return value
''');consumers.append(str(f))
for label,cwd in [('candidate',P/'candidate'),('aggregate-base',P/'aggregate-base')]:
 args=['mypy','--python-version','3.13',*consumers]
 # Give static checking an explicit source map; imported dependency debt is separate.
 args += [p for p in json.loads((P/'request.json').read_text())['required_commands'][9][3:] if (cwd/p).exists()]
 r.run('generic-r2-'+label,args,cwd=cwd)
 text=(P/('command-generic-r2-'+label+'.stdout')).read_text()
 diagnostics=[line for line in text.splitlines() if '_consumer.py:' in line and 'error:' in line]
 assert len(diagnostics)==12,(label,diagnostics)
 r.h.save('generic-'+label+'-comparison.json',dict(negative_diagnostics=diagnostics,count=len(diagnostics),expected_rejections=['Parent to Child','Child to Parent'],source=imports))
