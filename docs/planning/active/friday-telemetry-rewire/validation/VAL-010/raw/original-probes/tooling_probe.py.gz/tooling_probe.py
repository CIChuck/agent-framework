import importlib.util,importlib.metadata,sys,json,hashlib,ast
from pathlib import Path
P=Path('/private/tmp/telem-04/VAL-009');root=P/'candidate'
spec=importlib.util.spec_from_file_location('h','/private/tmp/telem-02/builder-baseline/prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
metadata=h.metadata_baseline()
metadata['pytest']=importlib.metadata.version('pytest')
import friday_chat,friday_telemetry,friday_llm,friday_core,friday_memory,friday_cli
mods=[friday_chat,friday_telemetry,friday_llm,friday_core,friday_memory,friday_cli]
metadata['source_resolution']={m.__name__:m.__file__ for m in mods}
for m in mods:assert str(root) in m.__file__
assert sys.version_info[:3]==(3,13,10) and metadata['versions']['ruff']['version']=='0.14.10' and metadata['versions']['mypy']['version']=='1.19.1' and metadata['pytest']=='9.0.2'
for name in ('python','ruff','mypy','pytest'):
 p=Path(sys.executable).parent/name;metadata[name+'_binary_sha256']=h.sha(p.read_bytes())
print(json.dumps(metadata,indent=2))
