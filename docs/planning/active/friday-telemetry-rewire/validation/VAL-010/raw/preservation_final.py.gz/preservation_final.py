import prepare_validator as p
import json,datetime
from pathlib import Path
before=json.loads((p.OUT/'original-before.json').read_text());after=p.state()
def statuses(x):return set(bytes.fromhex(x['status_hex']).decode().split('\0'))-{''}
added=sorted(statuses(after)-statuses(before));removed=sorted(statuses(before)-statuses(after))
assert all(before[k]==after[k] for k in ('head','branch','index_sha256'))
assert not removed
allowed=['docs/planning/active/friday-telemetry-rewire/README.md','docs/planning/active/friday-telemetry-rewire/execution-log.md','docs/planning/active/friday-telemetry-rewire/execution/REM-005-final/','docs/planning/active/friday-telemetry-rewire/execution/REM-005-candidate/']
unknown=[entry for entry in added if not any(a in entry for a in allowed)]
assert unknown in ([],['?? .claude/']),unknown
snaps={}
for label in ('candidate','rem-base','unit-base','aggregate-base'):
 s=json.loads((p.OUT/(label+'-snapshot.json')).read_text());root=Path(s['root'])
 altered=[f for f,h in s['tracked_hashes'].items() if not (root/f).is_file() or p.sha((root/f).read_bytes())!=h]
 assert not altered,altered
 assert all(not (root/f).exists() for f in s['omitted_before_checkout'])
 snaps[label]=dict(revision=s['revision'],root=s['root'],tracked_files_checked=len(s['tracked_hashes']),all_unchanged=True,excluded_protected_paths=267,protected_materialized=0,dirty_overlay=[])
checks=[]
for receipt in sorted(p.OUT.glob('*-receipt.json')):
 x=json.loads(receipt.read_text())
 for suffix in ('stdout','stderr'):
  raw=p.OUT/(receipt.name.replace('-receipt.json','.'+suffix));assert p.sha(raw.read_bytes())==x[suffix+'_sha256']
 checks.append(receipt.name)
helper=json.loads((p.OUT/'api-history-preservation.json').read_text())['helpers']
assert all(p.sha(Path(path).read_bytes())==h for path,h in helper.items())
authority=json.loads((p.OUT/'authority-receipt.json').read_text())
# Request authority pins are candidate-bound; check original controller edits never altered controls.
req=p.REQUEST
pins=[]
for x in req['authority']:
 path=x['path'];h=x['sha256'];actual=p.sha((p.REPO/path).read_bytes());assert actual==h,(path,actual,h);pins.append(path)
products=[]
for section in ('source','tests','documentation'):
 for path in req['product_manifest'].get(section,[]):
  assert p.sha((p.REPO/path).read_bytes())==p.sha((p.OUT/'candidate'/path).read_bytes()),path
  products.append(path)
p.save('original-after-final.json',after)
p.save('preservation-final.json',dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_head_branch_index_unchanged=True,original_preexisting_status_retained=True,concurrent_controller_status_additions=added,unattributed_clean_environment_status=unknown,controller_exception='Concurrent parent controller storage of builder/public review packets and in_review README/execution-log metadata; reviewer performed no original-worktree writes.',snapshots=snaps,raw_receipts_checked=checks,helper_hashes_unchanged=helper,original_control_pins_unchanged=pins,original_product_paths_unchanged=products,prior_attempt='probe-preservation retained exit1 for transient .claude untracked status addition, absent from immediate next status; no contents read, no attribution inferred.',dirty_content_limit='Preexisting unrelated dirty payloads were not read or hashed; this receipt proves status/HEAD/index and source/control identity, not a byte-level survey of unrelated dirty content.'))
print('preservation passed',len(checks),'raw receipts',len(pins),'control pins',len(products),'product paths; concurrent additions',added)
