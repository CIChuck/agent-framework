from pathlib import Path
import ast, hashlib, importlib, importlib.metadata as md, json, sys
root=Path.cwd();out=Path('/private/tmp/telem-04/REM-005/VAL-010')
def sha(b):return hashlib.sha256(b).hexdigest()
r=json.loads((out/'request.json').read_text());inv=json.loads((root/r['effect_inventory']).read_text())
fixtures={p:dict(expected=h,actual=sha((root/p).read_bytes())) for p,h in inv['fixture_hashes'].items()}
assert all(v['actual']==v['expected'] for v in fixtures.values()); assert len(inv['existing_nodes'])==13
inventory={}
files=list(root.rglob('conftest.py'))+[root/p for p in r['product_manifest']['tests']]+[root/p for p in inv['fixture_hashes']]
for p in files:
 t=ast.parse(p.read_text(),feature_version=(3,13));inventory[str(p.relative_to(root))]=dict(sha256=sha(p.read_bytes()),imports=[ast.unparse(n) for n in ast.walk(t) if isinstance(n,(ast.Import,ast.ImportFrom))],effect_calls=[ast.unparse(n.func) for n in ast.walk(t) if isinstance(n,ast.Call) and any(x in ast.unparse(n.func) for x in ('server','channel','create_task','Thread','socket','provider','Exporter','Database'))])
versions={}
for n in ('ruff','mypy','pytest','pydantic','opentelemetry-api','opentelemetry-sdk','opentelemetry-exporter-otlp-proto-grpc','opentelemetry-proto','grpcio','protobuf'):
 d=md.distribution(n);versions[n]=dict(version=d.version,metadata_sha256=sha(d.read_text('METADATA').encode()),location=str(d.locate_file('')))
site=Path(md.distribution('opentelemetry-sdk').locate_file(''))
sdk_paths=['opentelemetry/sdk/trace/__init__.py','opentelemetry/sdk/trace/export/__init__.py','opentelemetry/sdk/_shared_internal/__init__.py','opentelemetry/sdk/resources/__init__.py','opentelemetry/sdk/trace/sampling.py','opentelemetry/trace/__init__.py','opentelemetry/context/__init__.py','opentelemetry/exporter/otlp/proto/grpc/exporter.py','grpc/_channel.py']
sdk={p:dict(sha256=sha((site/p).read_bytes()),ast_valid=True) for p in sdk_paths}
for p in sdk_paths:ast.parse((site/p).read_text())
for n in ('friday_chat.telemetry','friday_llm','friday_telemetry','friday_memory','friday_runtime','friday_core'):importlib.import_module(n)
resolved={n:str(m.__file__) for n,m in sys.modules.items() if n.startswith('friday_') and getattr(m,'__file__',None)}
assert all(p.startswith(str(root)) for p in resolved.values()),resolved
v=dict(python=sys.version,executable=sys.executable,versions=versions,fixtures=fixtures,nodes=inv['existing_nodes'],imports_and_effects=inventory,sdk_sources=sdk,friday_resolution=resolved,guard_sha256=sha((out/'network-guard/sitecustomize.py').read_bytes()),helper_sha256=sha((out/'prepare_validator.py').read_bytes()))
(out/'preflight-final.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(dict(python=sys.version,versions={k:x['version'] for k,x in versions.items()},fixtures_matched=True,approved_nodes=13,all_friday_imports_sanitized=True,files_audited=len(files)),indent=2))
