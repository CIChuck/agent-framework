import prepare_validator as p
from pathlib import Path
import subprocess,json,sys,time,datetime
label,script,snapshot=sys.argv[1:];root=p.OUT/snapshot;path=Path(script);stem='probe-'+label
if (p.OUT/(stem+'-receipt.json')).exists():raise RuntimeError('New label required')
env=p.environment(root,stem);cmd=['uv','run','--no-sync','python',str(path)]
t=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
(p.OUT/(stem+'.stdout')).write_bytes(r.stdout);(p.OUT/(stem+'.stderr')).write_bytes(r.stderr)
p.save(stem+'-receipt.json',dict(command=cmd,cwd=str(root),environment=env,started=started,seconds=time.monotonic()-t,exit_code=r.returncode,script_sha256=p.sha(path.read_bytes()),runner_sha256=p.sha(Path(__file__).read_bytes()),stdout_sha256=p.sha(r.stdout),stderr_sha256=p.sha(r.stderr)))
print(stem,r.returncode,r.stdout.decode(errors='replace')[-250:],r.stderr.decode(errors='replace')[-200:])
