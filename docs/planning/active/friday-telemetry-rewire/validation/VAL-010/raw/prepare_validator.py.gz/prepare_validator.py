from pathlib import Path
import subprocess, json, hashlib, os
REPO=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT=Path('/private/tmp/telem-04/REM-005/VAL-010')
REQUEST=json.loads((OUT/'request.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','--no-optional-locks','-c','core.hooksPath=/dev/null','-C',str(REPO),*a])
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def protected(p):return any(p.startswith(x) for x in ('tests/integration/memory/.friday/','tests/integration/memory/vector/','tests/integration/memory/vector2_bak/','tests/integration/memory/vector_bak/','tests/integration/memory/.doltcfg/','experiments/provider_memory_smoke/memory/')) or '.friday' in Path(p).parts or Path(p).name=='.env'
def state():return dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),index_sha256=sha((REPO/'.git/index').read_bytes()),status_hex=git('status','--porcelain=v1','-z').hex())
def environment(root,label):
 t=OUT/'tmp'/label;t.mkdir(parents=True,exist_ok=True)
 return dict(PATH=f'{REPO}/.venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',UV_PROJECT_ENVIRONMENT=str(REPO/'.venv'),UV_CACHE_DIR=str(t/'uv'),UV_NO_SYNC='true',UV_OFFLINE='true',UV_PYTHON_DOWNLOADS='never',LITELLM_LOCAL_MODEL_COST_MAP='true',ANONYMIZED_TELEMETRY='False',TERM='xterm-256color',PYTHONPATH=os.pathsep.join([str(OUT/'network-guard')]+[str(p) for p in sorted((root/'packages').glob('*/src'))]+[str(root/'packages/friday-chat/tests_chat'),str(root)]),TMPDIR=str(t),PYTHONDONTWRITEBYTECODE='1',RUFF_CACHE_DIR=str(t/'ruff'),MYPY_CACHE_DIR=str(t/'mypy'))
def prepare(label,rev):
 root=OUT/label
 if root.exists():raise RuntimeError('Fresh snapshot required')
 names=git('ls-tree','-r','--name-only',rev).decode().splitlines();omit=[p for p in names if protected(p)]
 if len(omit)!=267 or any(p.endswith(('.py','.toml','.yaml','.yml')) for p in omit):raise RuntimeError('Protected scope drift')
 subprocess.run(['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout','--quiet',str(REPO),str(root)],check=True)
 for key,val in [('core.sparseCheckout','true'),('core.sparseCheckoutCone','false')]:subprocess.run(['git','-C',str(root),'config',key,val],check=True)
 (root/'.git/info/sparse-checkout').write_text('/*\n'+''.join('!/'+p+'\n' for p in omit))
 subprocess.run(['git','-c','core.hooksPath=/dev/null','-C',str(root),'checkout','--quiet','--detach',rev],check=True)
 if any((root/p).exists() for p in omit):raise RuntimeError('Runtime data materialized')
 save(label+'-snapshot.json',dict(root=str(root),revision=rev,omitted_before_checkout=omit,omitted_count=len(omit),dirty_overlay=[],tracked_hashes={p:sha((root/p).read_bytes()) for p in names if not protected(p) and (root/p).is_file()}))
if __name__=='__main__':
 save('original-before.json',state());(OUT/'network-guard').mkdir()
 b=git('show',REQUEST['candidate']+':docs/planning/active/friday-telemetry-rewire/execution/REM-004-final/controller/network-guard/sitecustomize.py')
 if sha(b)!='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81':raise RuntimeError('Guard drift')
 (OUT/'network-guard/sitecustomize.py').write_bytes(b)
 for label,key in [('candidate','candidate'),('rem-base','rem_base'),('unit-base','unit_base'),('aggregate-base','aggregate_base')]:prepare(label,REQUEST[key])
 print('4 sanitized snapshots ready')
