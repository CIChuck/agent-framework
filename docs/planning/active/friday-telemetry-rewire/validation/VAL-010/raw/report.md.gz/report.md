# VAL-010 independent validation

**VERIFIED** — frozen candidate `5c3a0e6dc8ba995bad9e7dfb8c574f5dfd335bc8` satisfies approved REM-005 and the complete TELEM-04/aggregate verification profile within its stated exceptions. No new product finding remains open. This is verification, not maintainer acceptance, delivery, release, or approval for TELEM-05.

Reviewer: independent Codex agent `/root/rem005_product_validator` (GPT-6 based; exact deployed model identifier is not exposed), fresh-context read-only review, 2026-10-11. Original source checkout: `/Users/chuckrussell/Dev/gendev/agent-framework`, branch `feature/friday-telemetry-rewire`. Evidence root: `/private/tmp/telem-04/REM-005/VAL-010`. No original source, board, authority, index, or git mutation was performed by this reviewer. No repair, commit, push, merge, release, or acceptance action was performed.

## Inputs, authority and independence

The exact public request is preserved as [request.json](request.json), including all commands, scope lists, supplemental requirements, effect inventory, and hashes. Committed authority was read at the frozen candidate, rather than using dirty controls. [authority-receipt.json](authority-receipt.json) verifies the authority manifest (`d14b38d5350641373363c49e8953578ec46a60871f899b9b98f341993315c337`) and all 46 pinned controls. The review includes AGENTS, engineering/lifecycle/independent-validation policies, REM-005 directive/profile/approval reconciliation, CD-004, complete TELEM-04 contract/profile, accepted TELEM-01–03 inputs, CD-003, waiver narratives/inventories, local telemetry contract, build and tactical plans. Explicit maintainer REM approval authorizes this telemetry review despite pending queue work.

The original independent VAL-009 report was preserved unchanged as [original-findings.md](original-findings.md), decompressed hash `6368a6cb61b16d77fb145a5504cddb23db9fe3cc8e98c917ebb22877f6c15393`; compressed source hash `1a8f23365359c872ede380ea145081d2af51a517afd154f922ad0f7a3d5e3cab` matched. Its original independent behavioral scripts were extracted into `original-probes`, audited, and executed independently. Builder/private construction reports, reasoning and pass claims were not used as verification evidence. The full public frozen diff includes packet assertions and metadata; these were treated as scope context, not behavioral proof. Historical accepted evidence hashes were checked without adopting builder conclusions. All findings and conclusions below come from this review's source inspection and execution.

## Snapshot and effect boundary

[prepare_validator.py](prepare_validator.py) is the independently audited private adaptation, not an execution of obsolete helper defaults. Four fresh shared, detached, sanitized snapshots exclude exactly 267 protected tracked runtime/data/credential paths through sparse exclusions **before checkout**. None were materialized; no dirty overlays or original runtime state/imports were used. Revisions and complete tracked-file hashes are in `candidate-snapshot.json`, `rem-base-snapshot.json`, `unit-base-snapshot.json`, and `aggregate-base-snapshot.json`:

- REM base: `1547fae7cac6450ec9ad7440f19d1f1162598fe2`.
- Unit base: `e6209e3156216afde1655758e280690229f7d3e6`.
- Aggregate base: `2155a0fc51f5b20dea4e35c6cfc70f1d52002735`.

The helper, fixture/import and installed SDK preflight occurred before collection/effectful execution and is preserved in [preflight.json](preflight.json), its stdout/stderr and script. A separately named final preflight confirms identical pins with a complete command receipt. Python 3.13.10, Ruff 0.14.10, Mypy 1.19.1, Pytest 9.0.2, Pydantic 2.12.5, OTel API/SDK/encoder 1.39.1, grpcio 1.67.1 and protobuf 6.33.2 were used. Imported Friday modules resolved only to the sanitized snapshot.

The clean environment is enumerated in every execution receipt: installed original `.venv`, `uv run --no-sync`, offline/no-install/no-download, private caches/temp, no inherited HOME, credentials, proxy, OTEL/GRPC or certificate override variables. The exact accepted guard hash is `6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81`. The archived/helper template hash independently matches `cd3963d50f55b5c2c18f2cf83f38a1ac4e13cb9bfc8ae3b3e31522d8492a9586`.

All 13 unchanged preapproved synthetic localhost nodes and four fixture hashes were reconciled before collection. The 11 HTTP and two native gRPC fixtures bind literal 127.0.0.1 ephemeral ports, finite timeouts, native retry/proxy disabled, and own/close server, channel, exporter and executor. New candidate tests are fake/in-memory; separate actual installed SDK probes own their in-memory exporter and tracer/handle, Debug and two-child Composite, with no network or global provider registration. Sandbox command-02's 13 listener setup permission failures remain intact; its normal-user rerun and commands 04/05 were escalated only under that existing fixture authorization.

## Full scope and compatibility review

The complete REM, unit and aggregate frozen diffs are retained. [scope-waiver-api-final.json](scope-waiver-api-final.json) independently derives and matches the exact request scopes: REM 15 product files (7 sources, 6 tests, 2 docs), unit 19 Python/12 source files, aggregate 133 Python/81 source files, including non-package Python and all 13 owning trees. All 133 changed Python ASTs parse as Python 3.13; symbol/import/test inventories are retained. Review covered the seven REM sources, complete unit processor/adapters/tool loop/observer/scopes/models/background/runtime/app/diagnostics, and aggregate provider/factory/lifecycle/exporter/config/composite, LLM completion/stream/embedding/pricing, assembly injection, generic migrations, other package/experiment/tooling changes and package documentation. Mandatory owning and root suites cover the aggregate beyond telemetry's narrow delta.

[api-history-preservation-final.json](api-history-preservation-final.json) verifies unchanged three-method TelemetryInterface, stable existing OpenTelemetryProvider public argument shapes, unchanged legacy TelemetryConfig defaults, unchanged unit Chat config, original TurnResult/PendingExtractionTurn positional fields with additive final None correlation fields, and only the three intended unit exports. Accepted LLM/MCP models, source payload boundaries, unit LLM services/embeddings, MCP persistence coordinator, config template and lock are unchanged from the unit base. Aggregate declared dependency/optional-dependency lists are unchanged; aggregate metadata and lock migrate the approved Python floor, so aggregate lock-byte equality is not claimed. All 18 metadata floors are `>=3.13.4`; the actual run is 3.13.10, not a floor-version test.

The aggregate keeps optional keyword-only injection and established factory defaults, including shared service roles and legacy extraction/compaction alias roles. Default-disabled assembly preserves prior call shapes; caller override remains borrowed. Safe LLM accounting still distinguishes actual attempts/batches, reported zero/unknown usage and estimates from billing; accepted MCP receipt/publication truth is preserved. Legacy unsafe standalone hooks remain outside the closed observer guarantee. Headless adoption, remote/TLS activation, OTel Meter integration and Langfuse remain separately governed.

Six independent generic consumer files check both assignment directions for CommandRegistry, SessionContext, SessionManager, ToolAdapter, MoltbookResponse and MemoryMetric. Candidate and aggregate-base reject the same 12 intentional incompatible returns. Candidate has no unrelated errors; base has three separately visible historical source errors. Mandatory Mypy remains a genuine pass. Supplemental verbose `--no-incremental` runs prove all 12/81 exact source inputs and 293/354 resolved Friday source modules use the private snapshot, with zero original-worktree source leaks. See [mypy-isolation-generics.json](mypy-isolation-generics.json), consumer scripts and raw supplemental receipts.

## Required commands

All 19 exact commands in the request were executed. Receipt files provide exact argv, cwd, allowlisted environment, start/duration, raw exit, script and output hashes. The following table summarizes results; the numbered raw receipt/stdout/stderr remain authoritative.

| # | Gate | Result |
| --- | --- | --- |
| 01 | Six new modules | exit 0; 132 passed |
| 02 | Full Chat/LLM/Telemetry | exit 0; 1,247 passed, 5 warnings; original sandbox attempt retained separately |
| 03 | Root importlib collection | exit 0; 3,129 collected |
| 04 | Safe root importlib suite | exit 0; 3,128 passed, 1 allowed SciPy skip, 15 warnings |
| 05 | All 13 aggregate owning trees | exit 0; 3,110 passed, same 1 allowed skip, 15 warnings |
| 06 | Exact unit Ruff, 19 files | exit 0 |
| 07 | Exact aggregate Ruff, 133 files | exit 0 |
| 08 | Raw root Ruff JSON | **exit 1**, exactly 327 approved WVR-006 identities |
| 09 | Exact genuine unit Mypy | exit 0; 12 source files |
| 10 | Exact genuine aggregate Mypy | exit 0; 81 source files |
| 11 | Offline lock check | exit 0; 201 packages |
| 12 | Board validate | exit 0; 24 tasks |
| 13 | Board next | exit 0; frozen committed candidate reports memory-v2 awaiting approval |
| 14 | Board show | exit 0; telemetry started/local pending at candidate |
| 15 | Board render check | exit 0; current |
| 16 | Documentation validation | exit 0; 488 Markdown files |
| 17 | Unit diff check | exit 0 |
| 18 | Aggregate diff check | exit 0 |
| 19 | REM diff check | exit 0 |

The only test exclusions are `packages/friday-chat/tests_chat/test_live_lmstudio.py` and `packages/friday-llm/tests_llm/test_live_lmstudio.py`. The only skip is the existing optional SciPy adapter test at test_graph.py:250. Raw root Ruff is not relabeled a lint pass: every path/code/start/end/message matches the exact 327 waiver identities, all four archive hashes, CLI CommandRegistry whole-source/class AST hashes, 17 lint-config hashes, tool version and py313 target match. No additional waiver, suppression, skip, or typing exception was applied.

## AC04-01–08 findings and evidence

| Criterion | Independently reviewed result and evidence |
| --- | --- |
| AC04-01 | PASS. Frozen extra-forbid strict execution model revalidation rejects unknown/nested fields, bad refs/enums, bool counts, signed64 overflow, NaN/Inf and forged models before records, metrics or sink. Version is actual integer 1. Candidate schema probe and own privacy-bounds probe exercise 19 invalid cases and zero contribution. Accepted interface/models and MCP payload equality verified. Sentinels absent from serialized local records, summaries, metrics, Debug and actual SDK spans. |
| AC04-02 | PASS. Both turn paths have exactly one start/terminal for normal, selection/circuit blocks, timeout, exhausted retry, failed callback and cancellation. Independent fake matrix covers retrieval/model/tool/persistence failures and cancellation; SDK probes exercise nested/concurrent sessions/operations and task-context restoration. Stream-cancel probe's 18 direct/legacy/typed retained-upstream cases verify awaited close, no read-ahead, first-chunk ordering and primary exception identity/Cancel arguments despite cleanup error/cancel. All spans close; existing public generator buffering remains unchanged. |
| AC04-03 | PASS. Tool source and full suites preserve native unknown/disallowed/KeyError and MCP succeeded/failed/blocked/timeout semantics, accepted redaction/provenance/ID repair. Original tools_reasoning probe verifies known rejected MCP is MCP, zero dispatch; mixed three actual dispatches and correct failed records. Failed/blocked MCP returns are not successful tool contributions. |
| AC04-04 | PASS. Independent fake probe checks retrieval/store/ingest success, returned counts, empty/failure/cancel and per-item extraction. SDK probe and own SDK-lineage probe check active/finished foreground handoff, mixed valid/None origins, concurrent and nested items, preemption/cancel/requeue/resume/shutdown flush. Each None item is session-only and cannot borrow the foreground. No-extractor/empty are skipped. Completed-under-cancellation remains completed persistence plus cancelled outcome and correct retry/requeue behavior. |
| AC04-05 | PASS. Independent fake probe's 28 staged failure/cancellation cases and complete Chat persistence/MCP suites cover memory, transcript, context log and interaction persistence. Earlier completion remains partial after later failure; turn success waits for the complete existing path. Accepted receipt_committed, pending/publication/skipped/disabled and raw capture behavior remain distinct. No atomic rollback or unavailable commit guarantee was introduced. |
| AC04-06 | PASS. Two actual follow-up dispatches in tools_reasoning show first MCP reasoning present but ineligible/not preserved, then native reasoning eligible/preserved, by inspecting actual outgoing history; no reasoning text exported or inferred provider mandate. Accepted LLM event payloads remain unmodified. Own privacy-bounds probe verifies LLM/MCP links only within valid scope, exact MCP original source_sequence/payload, no invalid-original links, and no accounting from originals/links. |
| AC04-07 | PASS. Complete diagnostics tests preserve /debug and /timing, including failed turns without result and failing/off exporter. Own probe drives 400 terminal turns/operations with failed sinks: 256 records, 32 summaries, 128 open-span admission, fixed closed labels, signed64 saturation, single terminal contribution, all spans closed. Actual installed SDK/Debug/two-child Composite probes verify span/event parentage, owned active children, independent background roots, outer caller stack restoration, exception/cancel exits, no global-provider change or worker leak, borrowed sink remains open, explicit owner cleanup success. No Meter or new exporter was added. |
| AC04-08 | PASS. All 19 commands, exact waiver reconciliation, isolated verbose typing, generic consumers, API/defaults and 59 accepted nested authority/evidence pins pass. Full REM/unit/aggregate source review and stable candidate hashes are preserved. Original HEAD/branch/index, all 46 control pins and all 15 product files match; four sanitized tracked snapshots remain unchanged with protected paths absent. Historical link and preservation limitations below are explicit. |

Primary raw behavior: `probe-candidate-fake`, `probe-candidate-closure`, `probe-candidate-schema`, `probe-candidate-tools_reasoning`, `probe-candidate-sdk`, `probe-candidate-sdk_exception`; stronger independent probes: [sdk_lineage_probe.py](sdk_lineage_probe.py), [stream_cancel_probe.py](stream_cancel_probe.py), [privacy_bounds_probe.py](privacy_bounds_probe.py), with matching stdout/stderr/receipt files. All exit 0 and candidate issue lists are empty.

## Original numbered finding disposition

The unchanged independent probes were executed first against REM-base, then candidate; original outputs remain separate. Original SDK exception cases are supplementary successful baselines, not falsely described as base failures.

1. **VAL-009-F01 — resolved.** REM-base SDK output reproduces active foreground inheritance by background extraction. Candidate and own actual SDK lineage probe show background roots, valid explicit active-child parentage and correct event placement under private delivery contexts for both Composite children, with restored caller context.
2. **VAL-009-F02 — resolved.** REM-base fake probe reproduces explicit absent origin borrowing foreground correlation/accounting. Candidate mixed valid/None probes produce uncorrelated session-only facts and no foreground contribution.
3. **VAL-009-F03 — resolved.** REM-base tools probe reproduces known rejected MCP classified native. Candidate classifies it MCP from trusted membership and performs zero dispatch, preserving rejection reason/history behavior.
4. **VAL-009-F04 — resolved.** REM-base retained iterator is not closed before primary exception returns. Candidate closes it before return. Own 18 adapter-chain cases broaden callback/cancellation and failing cleanup verification without relying on garbage collection or loop teardown.
5. **VAL-009-F05 — resolved.** REM-base admits bool/float versions and aggregates them. Candidate rejects them before records/sink/metrics, including model_construct-forged instances; genuine integer 1 remains valid.

No newly discovered product finding requires changes.

## Preservation, attempts and limits

[preservation-final2.json](preservation-final2.json) records unchanged HEAD/branch/index, all original preexisting status entries retained, 46 control pins/15 product files equal the candidate, four private tracked trees unchanged, and raw-output/helper hash reconciliation. Concurrent controller writes are limited to the declared packet README/execution log/candidate report/final and review-request storage and are not reviewer writes. The clean-environment git status also reports `?? .claude/`, whereas an immediate ordinary checkout status did not. Its payload was never read, hashed, imported, removed or copied; no unknown actor is attributed. This status difference does not affect frozen source/control hashes, but a byte-level guarantee for unrelated dirty/untracked payload is not claimed. Protected original runtime/data/credential content was deliberately not read for preservation hashes.

All original attempts are retained, not silently overwritten: sandbox command-02's permission failures; initial preservation and r2's status assertions; r3 and final's receipt-parser setup error (authority-receipt is not a stdout/stderr command receipt); final2's corrected, separately named successful reconciliation. Script hashes and raw receipts distinguish every attempt. Initial preflight/static reconciliations are retained alongside separately named final command-receipted repetitions. These setup failures did not produce a product failure or source edit.

The five exact historical source/control files restored under `/private/tmp/telem-01/review` keep six VAL-001 absolute links live and match historical git revision `0c7b6d4c416402443d140a5ee09abed70be34c69` and CDR020 recovery hashes. Historical reports were not rewritten. These external temporary source links remain nonportable and not self-contained evidence; liveness today does not eliminate that limitation.

Remaining profile limits: no live LMStudio/provider calls; optional SciPy unavailable; no Python 3.13.4 execution; OTel compatibility demonstrated only at installed 1.39.1 boundary; native gRPC probes cover the approved local collectors, not real remote TLS/trust/filesystem/connectivity. Python guards cannot intercept every native gRPC operation, so audited explicit destination/options/finite deadline/ownership evidence is required and retained. Generic arbitrary scalar caller payload and historical unsafe helpers are not covered by the closed Chat content guarantee. Existing warning output remains raw. Composite's documented lifetime reservation of published span IDs remains an accepted cumulative retention limitation.

The artifact manifest inventories every evidence file, including scripts, all attempts, raw outputs, receipts, controls and private caches. Only the four snapshot directory trees are excluded from file-level inventory, with complete revision/exclusion/tracked-hash provenance receipts; the manifest excludes itself to avoid recursion. Report and manifest originals are frozen for controller hash verification and immutable storage.

Manifest setup attempt 1 rejected a private pytest symlink entry and wrote no manifest. Its failing generator and explicit error-summary receipt remain retained. The separately named r2 generator inventories symlink target bytes without following them, preserving complete private-cache evidence without reading target payloads.
