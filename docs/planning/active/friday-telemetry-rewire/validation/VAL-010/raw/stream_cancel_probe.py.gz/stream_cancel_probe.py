"""Independent retained iterator cancellation/adapter/backpressure checks."""
import asyncio,json
from friday_chat.runtime import build_runtime
from friday_chat.config import FridayChatConfig,LegacyLLMExecutionConfig
from friday_chat.adapters import FrameworkChatModel
from friday_chat.turns.processor import TurnProcessor
from friday_llm import TextDeltaEvent
rows=[]
class Unprintable(RuntimeError):
 def __str__(self):raise AssertionError('no stringify')
class Iterator:
 def __init__(self,typed,cleanup):self.typed=typed;self.cleanup=cleanup;self.entered=asyncio.Event();self.closed=False;self.closes=0;self.reads=0
 def __aiter__(self):return self
 async def __anext__(self):
  self.reads+=1
  if self.reads==1:return TextDeltaEvent(text='first') if self.typed else 'first'
  self.entered.set();await asyncio.Event().wait()
 async def aclose(self):
  self.closes+=1;await asyncio.sleep(0);self.closed=True
  if self.cleanup:raise self.cleanup
async def main():
 for path in ('direct','legacy','typed'):
  for failure in ('read_cancel','callback'):
   for cleanupkind in ('success','error','cancel'):
    cfg=FridayChatConfig.model_validate({'llm':{'model':'fake/test','transport_target':{'provider':'openai_compatible','dialect':'openai_chat_completions','serving_engine':'lm_studio'},'model_target':{'model_id':'fake/test','family':'qwen3_8','revision':'fake'}},'tools':{'enabled':False},'telemetry':{'enabled':True}})
    r=build_runtime(cfg);cleanup=Unprintable() if cleanupkind=='error' else asyncio.CancelledError('cleanup') if cleanupkind=='cancel' else None
    upstream=Iterator(path=='typed',cleanup)
    class Service:
     def chat_completion_stream(self,**kw):return upstream
     def chat_completion_events(self,request):return upstream
     def stream_complete(self,*a,**kw):return upstream
    r.chat_llm=Service() if path=='direct' else FrameworkChatModel(Service(),cfg,LegacyLLMExecutionConfig(0,None,None) if path=='legacy' else cfg.llm.resolve_execution())
    primary=Unprintable();chunks=[]
    async def callback(chunk):
     chunks.append(chunk);assert upstream.reads==1
     if failure=='callback':raise primary
    task=asyncio.create_task(TurnProcessor(r).process_streaming('PRIVATE',on_chunk=callback))
    if failure=='read_cancel':await asyncio.wait_for(upstream.entered.wait(),1);task.cancel('validator-primary')
    try:await task;raise AssertionError('primary missing')
    except BaseException as caught:
     assert isinstance(caught,asyncio.CancelledError) and caught.args==('validator-primary',) if failure=='read_cancel' else caught is primary
    assert upstream.closed and upstream.closes==1 and chunks==['first']
    assert upstream.reads==(2 if failure=='read_cancel' else 1)
    assert not r.telemetry._spans and r.telemetry.correlation.current() is None
    terminals=[e for e in r.telemetry.snapshot().events if e.name=='execution.turn_finish'];assert len(terminals)==1
    assert 'PRIVATE' not in repr(r.telemetry.snapshot())
    rows.append(dict(path=path,failure=failure,cleanup=cleanupkind,closed_before_return=True,close_count=1,read_count=upstream.reads,primary_preserved=True,terminal_count=1))
 print(json.dumps(rows,indent=2))
asyncio.run(main())
