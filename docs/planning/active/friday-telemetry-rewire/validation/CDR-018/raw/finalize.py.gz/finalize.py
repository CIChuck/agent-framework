import datetime
import hashlib
import json
from pathlib import Path

O=Path(__file__).parent
e=json.loads((O/'checks.json').read_text())
sha=lambda d: hashlib.sha256(d).hexdigest()
candidate=O/'candidate'
prefix=Path('docs/planning/active/friday-telemetry-rewire')
m=json.loads((O/'raw/manifest.stdout').read_text())
p=json.loads((O/'raw/proposal-manifest.stdout').read_text())
current={x['path']:x['sha256'] for x in m['authority']}
prior={x['path']:x['sha256'] for x in p['authority']}
e['pin_delta']={'changed':[q for q in prior if current[q]!=prior[q]],'added':sorted(set(current)-set(prior)),'removed':sorted(set(prior)-set(current))}
inventory=json.loads((O/'raw/authority-20.stdout').read_text())
e['inventory_hashes']=[dict(path=q,expected_sha256=v['sha256'],actual_sha256=sha((candidate/q).read_bytes()),matches=sha((candidate/q).read_bytes())==v['sha256']) for q,v in inventory['sources'].items()]
e['tools']=[{'path':str(q),'resolved_path':str(q.resolve()),'sha256':sha(q.read_bytes())} for q in [Path('/Users/chuckrussell/Dev/gendev/agent-framework/.venv/bin/ruff'),Path('/Users/chuckrussell/Dev/gendev/agent-framework/.venv/bin/python'),Path('/opt/homebrew/bin/uv')]]
e['checks'].update(inventory_source_hashes=all(q['matches'] for q in e['inventory_hashes']),source_delta_empty=(O/'raw/source-from-preparation.stdout').read_bytes()==b'',accepted_delta_empty=(O/'raw/accepted-archives-delta.stdout').read_bytes()==b'',delta_whitespace_zero=(O/'raw/delta-check.stdout').read_bytes()==b'',effective_ruff_target_py313='linter.unresolved_target_version = 3.13' in (O/'raw/ruff-target-settings.stdout').read_text(),source_test_doc_counts={k:len(v) for k,v in m['product_manifest'].items()}=={'source':11,'tests':14,'documentation':3})
if not all(e['checks'].values()):raise RuntimeError(e['checks'])
e.update(verdict='READY',lint_authority_verdict='READY',approved_authority_verdict='READY',completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),findings=[],advisories=[{'id':'T03-A01','severity':'advisory','topic':'Managed OTel probe route','source':['directives/CD-003-safe-llm-metrics.md:103','directives/CD-003-safe-llm-metrics.md:142','verification-profile-TELEM-03.md:13-16','verification-profile-TELEM-03.md:56-58'],'assessment':'Restrictions explicitly address new tests/their fixtures, while the next profile sentence explicitly permits owned in-memory actual SDK evidence and later requires consumer probes. They can be fulfilled together with fake-only new pytest fixtures and separate in-memory actual managed OTel consumer evidence probes. This reading preserves literal wording and does not authorize provider/network construction in new fixtures.','guidance':'Before executing the later required consumer evidence, identify the separate probe route and freeze its synthetic-exporter/preflight/cleanup evidence. Do not infer extra listeners, channels, remote/TLS/public-root/credential effects or exporter/factory changes.'},{'id':'T03-A02','severity':'low advisory','topic':'Stale index explanation','source':['README.md:43'],'assessment':'The explanatory sentence still says Header planning/not_ready, while the operative header now says planning/pending. Board, header and execution log agree on current pending readiness, so this historical/stale sentence does not grant conflicting authority.'}],limitations=['Reused independent reviewer instance from TELEM02, not a fresh-context product validator; no participation in TELEM03 generation and no earlier PASS conclusion relied upon.','This review ran only static lint/AST/hash/governance checks. No pytest collection/tests, product imports, SDK/provider/exporter/channel/thread/listener construction, behavioral baseline probes or live/network experiments.','Pre-build behavioral probes, final fixture/helper/import/effect reconciliation, candidate product validation and fresh-context unit+aggregate VERIFIED remain required.','Original protected/runtime/credential/unrelated dirty contents were not read or copied. Sparse exclusion preceded checkout;267 paths omitted in each fresh snapshot. Original HEAD unchanged; no source or original git metadata mutation performed.','Board next reports AWAITING_APPROVAL memory-v2; explicit active maintainer direction governs this TELEM03 review. Board show separately confirms TELEM03 initiative started/granted/local and pending review/probes next gate.','Only WVR005 renewal for TELEM03 is assessed; WVR004 remains expired, expiry and mandatory zero changed-unit/aggregate gates preserved.'])
e['advisories'][1]['source']=['README.md:44']
(O/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
report='''# READY — TELEM-03 approved-authority and lint-renewal readiness

Reviewer: `/root/telem02_a02_approved_readiness`, GPT-6 Codex (exact build unavailable). Date: 2026-10-07 America/New_York. **This independent reviewer instance is reused from a historical TELEM-02 review.** It did not participate in TELEM-03 generation. All checks below were performed anew; no prior PASS conclusion is inherited. This is not a fresh-context product validation review.

Frozen candidate: `7bb6256f38d1f51b48f1c15fc0beefd591d26c3d`. Proposal: `22c86517986f10d72d0ce8df99c1a5045639266a`. Preparation base: `4ca9baecdcdcf26fc5e8055b326c3a54cda36cb7`. Manifest and every input/receipt hash appear in `evidence.json`.

## Verdict

**READY** for approved authority, and separately **READY** for WVR-005 exact lint renewal. The explicit Chuck Russell decision, "i approve cd-003, wvr-005 - proceed to next steps", binds the concrete proposal and both separate decisions. True pre-build behavioral probes and final effect/import reconciliation still precede source construction. This result verifies neither product nor acceptance.

## Reproducible checks

| Check | Result and exact evidence |
| --- | --- |
| Current authority | All24 SHA-256 pins match frozen git objects. All22 proposal pins independently match their frozen proposal; approval evidence preserves exactly that list and the unchanged28-path manifest. `raw/manifest.stdout`, `raw/proposal-manifest.stdout`, `raw/authority-*.stdout`, `raw/proposal-control-*.stdout`; `evidence.json: pins/proposal_pins/pin_delta`. |
| Transition/scope | Entire proposal-to-candidate delta reviewed:12 governance/planning paths; substantive contract/profile remain unchanged except approval labels/decision bindings. Exactly11 source,14 test,3 docs allowed. No package source change from preparation to candidate; no accepted archive/control change. `raw/proposal-to-candidate.stdout`, `raw/delta-paths.stdout`, `raw/source-from-preparation.stdout`, `raw/accepted-archives-delta.stdout`. Diff check exit0. |
| Accepted controls | Accepted TELEM-01 and TELEM-02 manifests and each19 control pins independently match; unchanged from proposal. Accepted evidence remains history, not reused product proof. `raw/telem01-*.stdout`, `raw/telem02-*.stdout`. |
| Safe snapshots | Two new sparse tracked snapshots,267 protected paths omitted before checkout, no dirty overlay, omitted paths absent; all tracked hashes unchanged afterward. `base-snapshot.json`, `candidate-snapshot.json`, `evidence.json: snapshot_preservation`. Reused helper exact bytes/hash recorded in `reused-prepare.py` and artifact manifest. |
| Raw lint | Both preparation and candidate root Ruff exit **1**, each with327 exact path/code/start/end/message identities matching the approved multiset, with no extra or missing identity. This is disposed debt, not raw lint PASS. `raw/base-root-ruff.stdout`, `raw/candidate-root-ruff.stdout`; command/env/exit receipts in `evidence.json`. |
| Covered inputs | At both snapshots: all4 archive and17 configuration hashes match, registry source and recomputed `ast.dump(CommandRegistry, include_attributes=False)` SHA-256 match. Ruff0.14.10 independently reported; effective target3.13/py313 inspected. Tool executable hashes recorded. `evidence.json: lint/tools`; `raw/*-ruff-version.stdout`, `raw/ruff-target-settings.stdout`. |
| Effects/inventory | Exactly13 existing unique nodes, no new nodes; all4 fixture hashes match. Listener bytes/status remain frozen proposal evidence explicitly approved by decision record. All14 inventoried source hashes match candidate. `raw/authority-21.stdout`, `raw/authority-22.stdout`, `evidence.json: listener_hashes/inventory_hashes`. No effect executed. |
| Board/docs | validate, next, show, render --check and documentation lifecycle all exit0. Board show confirms started/granted/local and pending authority review/pre-build probes. `next` reports memory-v2 awaiting approval; this review follows explicit active maintainer direction. `raw/board-*.stdout`, `raw/docs-lifecycle.stdout`. |

WVR-005 preserves its scope, owner, follow-ups and expiry at TELEM-03 acceptance or covered identity/content/AST/tool/target/config drift. WVR-004 remains expired. Changed-unit/aggregate lint/types and all other gates still require their normal zero/pass results.

## Findings and interpretation

No mandatory finding prevents this readiness result.

**T03-A01 — advisory: distinguish new test fixtures from actual SDK evidence probes.** CD-003 AC03-07 requires actual managed OTel consumer evidence (line103). Its effects paragraph (lines142–143) prohibits provider/channel/listener construction in all new tests. The profile likewise prohibits SDK exporter/thread/channel from new-unit fixtures (lines13–15), but its immediately following sentence expressly permits owned synthetic in-memory actual SDK evidence with explicit close/no network (lines15–16), and lines56–58 require actual managed OTel consumer probes. Those scoped statements can be satisfied together: keep new pytest fixtures fake-only, and collect the separately required actual managed OTel evidence through in-memory consumer probes under the permitted initiative evidence scope. This is a reading of the frozen allowance, not a new permission. Do not put actual managed-provider construction into those new fixtures, replace real evidence with mocks, add listener/channel/remote/TLS/credential effects, or modify accepted exporter/factory code. Freeze the separate probe's preflight/owned cleanup before execution. No such probe was run here.

**T03-A02 — low advisory: stale index explanation.** README line44 still refers to Header planning/not_ready although its operative header is now planning/pending. The actual header, board and latest log agree; this does not change authorization. It may be clarified in normal authorized governance reconciliation.

## Residual limits

No pytest collection/test, product import, provider/SDK/exporter/worker/channel/listener construction, protected-state/credential read, network test, installation, source edit, original checkout/index/git-metadata mutation or commit occurred. Static governance scripts and Ruff ran only in the fresh isolated snapshots. Original HEAD stayed frozen. Required pre-build behavioral probes and later fresh-context product delta plus complete2155a0f aggregate verification remain outstanding. Acceptance and external/delivery actions are separate.

`artifact-manifest.json` hashes reviewer-created evidence/scripts/raw receipts (excluding itself and the sparse snapshot trees); snapshot receipts independently pin each safe tracked snapshot file. All reports and artifacts are in the private requested directory.
'''
(O/'report.md').write_text(report)
art={'reviewer':e['reviewer'],'candidate':e['candidate'],'verdict':'READY','exclusions':['artifact-manifest.json (self-reference)','base/ and candidate/ sparse trees; exact safe tracked hashes in snapshot receipts; private clone git metadata excluded'],'files':[]}
for f in sorted(O.rglob('*')):
    relative=f.relative_to(O)
    if relative.parts[0] in ['base','candidate','tmp'] or not f.is_file() or f.name=='artifact-manifest.json':continue
    d=f.read_bytes();art['files'].append({'path':relative.as_posix(),'bytes':len(d),'sha256':sha(d)})
(O/'artifact-manifest.json').write_text(json.dumps(art,indent=2)+'\n')
print(json.dumps({'verdict':'READY','candidate':e['candidate'],'report_sha256':sha((O/'report.md').read_bytes()),'evidence_sha256':sha((O/'evidence.json').read_bytes()),'artifacts':len(art['files']),'checks':e['checks']},indent=2))
