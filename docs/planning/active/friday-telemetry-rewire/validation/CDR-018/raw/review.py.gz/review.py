import ast
from collections import Counter
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path('/private/tmp/telem-03/approved-readiness')
REPO = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
C = '7bb6256f38d1f51b48f1c15fc0beefd591d26c3d'
P = '22c86517986f10d72d0ce8df99c1a5045639266a'
B = '4ca9baecdcdcf26fc5e8055b326c3a54cda36cb7'
PREFIX = 'docs/planning/active/friday-telemetry-rewire/'
(OUT/'raw').mkdir(parents=True, exist_ok=True)
receipts = []
def sha(d): return hashlib.sha256(d).hexdigest()
def run(label, argv, cwd=REPO, env=None):
    start = time.time()
    p = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, timeout=60)
    for suffix,d in [('stdout',p.stdout),('stderr',p.stderr)]: (OUT/'raw'/f'{label}.{suffix}').write_bytes(d)
    receipts.append(dict(label=label,argv=argv,cwd=str(cwd),environment=env,exit_code=p.returncode,started_epoch=start,finished_epoch=time.time(),stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr)))
    return p
def git(label,*args):
    p=run(label,['git','--no-optional-locks','-c','core.hooksPath=/dev/null',*args])
    if p.returncode: raise RuntimeError(label)
    return p.stdout
head = git('original-head-before','rev-parse','HEAD').decode().strip()
manifest_bytes = git('manifest','show', C+':'+PREFIX+'authority-manifest-TELEM-03.yaml')
m = json.loads(manifest_bytes)
prior = json.loads(git('proposal-manifest','show',P+':'+PREFIX+'authority-manifest-TELEM-03.yaml'))
pins=[]
for n,e in enumerate(m['authority']):
    data=git(f'authority-{n:02d}','show',C+':'+e['path'])
    pins.append(dict(**e,actual_sha256=sha(data),matches=sha(data)==e['sha256']))
git('proposal-to-candidate','diff',P+'..'+C)
delta = git('delta-paths','diff','--name-status',P+'..'+C).decode()
git('delta-check','diff','--check',P+'..'+C)
git('source-from-preparation','diff',B+'..'+C,'--','packages')
git('accepted-archives-delta','diff',P+'..'+C,'--','docs/archive/completed/2026/friday-telemetry-rewire-telem-01','docs/archive/completed/2026/friday-telemetry-rewire-telem-02',PREFIX+'authority-manifest.yaml',PREFIX+'authority-manifest-TELEM-02.yaml')
for n,path in enumerate([PREFIX+'README.md',PREFIX+'execution-log.md','docs/planning/board.yaml','docs/planning/README.md']):git(f'state-{n}','show',C+':'+path)
accepted=[]
for label,path in [('telem01',PREFIX+'authority-manifest.yaml'),('telem02',PREFIX+'authority-manifest-TELEM-02.yaml')]:
    d=git(label+'-manifest','show',C+':'+path)
    controls=json.loads(d)['authority'] if d.startswith(b'{') else [{'path':p,'sha256':h} for p,h in re.findall(r'^- path: (.+)\n  sha256: ([0-9a-f]{64})$',d.decode(),re.M)]
    results=[]
    for n,e in enumerate(controls):
        h=sha(git(f'{label}-control-{n:02d}','show',C+':'+e['path']))
        results.append(dict(**e,actual_sha256=h,matches=h==e['sha256']))
    accepted.append(dict(label=label,path=path,manifest_sha256=sha(d),controls=results))
evidence=json.loads((OUT/'raw/authority-23.stdout').read_text())
proposal_pins=[]
for n,e in enumerate(evidence['proposal_authority']):
    h=sha(git(f'proposal-control-{n:02d}','show',P+':'+e['path']))
    proposal_pins.append(dict(**e,actual_sha256=h,matches=h==e['sha256']))
spec=importlib.util.spec_from_file_location('review_snapshot_helper','/private/tmp/telem-02/builder-baseline/prepare.py')
helper=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.OUT=OUT
(OUT/'reused-prepare.py').write_bytes(Path(spec.origin).read_bytes())
roots={}
for label,rev in [('base',B),('candidate',C)]:
    roots[label],_ = helper.prepare(label,rev)
checks={}
scope=json.loads((roots['candidate']/PREFIX/'validation/WVR-005-telem03-lint-scope.json').read_text())
def identities(ds,root=None):
    return Counter((str(Path(d['filename']).relative_to(root)) if root else d['path'],d['code'],d['location']['row'],d['location']['column'],d['end_location']['row'],d['end_location']['column'],d['message']) for d in ds)
expected=identities(scope['diagnostics'])
lint=[]
for label,root in roots.items():
    env=helper.environment(root,label+'-static')
    v=run(label+'-ruff-version',['/opt/homebrew/bin/uv','run','--no-sync','ruff','--version'],root,env)
    p=run(label+'-root-ruff',['/opt/homebrew/bin/uv','run','--no-sync','ruff','check','.','--output-format','json'],root,env)
    ds=json.loads(p.stdout)
    actual=identities(ds,root)
    covered=[]
    for group in ['archived_files','lint_configurations']:
        for path,h in scope[group].items():
            d=(root/path).read_bytes(); covered.append(dict(group=group,path=path,expected_sha256=h,actual_sha256=sha(d),matches=sha(d)==h))
    source=(root/'packages/friday-cli/src/friday_cli/commands.py').read_bytes()
    cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry')
    ah=sha(ast.dump(cls,include_attributes=False).encode())
    lint.append(dict(label=label,count=len(ds),raw_exit=p.returncode,multiset_matches=actual==expected,extra=list((actual-expected).elements()),missing=list((expected-actual).elements()),ruff_version=v.stdout.decode().strip(),covered_hashes=covered,registry_source_sha256=sha(source),registry_source_matches=sha(source)==scope['command_registry_source_sha256'],registry_class_ast_sha256=ah,registry_class_ast_matches=ah==scope['command_registry_class_ast_sha256']))
root=roots['candidate']; env=helper.environment(root,'board-doc-static')
for lane in ['active','queued','review','blocked','deferred','backlog']:(root/'docs/planning'/lane).mkdir(exist_ok=True)
for label,args in [('board-validate',['validate']),('board-next',['next']),('board-show',['show','friday-telemetry-rewire']),('board-render-check',['render','--check'])]:
    p=run(label,['/opt/homebrew/bin/uv','run','--no-sync','python','scripts/friday-dev-board.py',*args],root,env);checks[label]=p.returncode==0
p=run('docs-lifecycle',['/opt/homebrew/bin/uv','run','--no-sync','python','scripts/check-documentation-lifecycle.py'],root,env);checks['docs-lifecycle']=p.returncode==0
run('python-version',['/opt/homebrew/bin/uv','run','--no-sync','python','--version'],root,env)
run('ruff-target-settings',['/opt/homebrew/bin/uv','run','--no-sync','ruff','check','packages/friday-cli/src/friday_cli/commands.py','--show-settings'],root,env)
listeners=json.loads((root/PREFIX/'execution/TELEM-03-planning/listener-scope.json').read_text())
listener_hashes=[dict(path=p,expected_sha256=h,actual_sha256=sha((root/p).read_bytes()),matches=sha((root/p).read_bytes())==h) for p,h in listeners['fixture_hashes'].items()]
snapshot_preservation=[]
for label,root in roots.items():
    s=json.loads((OUT/(label+'-snapshot.json')).read_text()); bad=[p for p,h in s['tracked_hashes'].items() if sha((root/p).read_bytes())!=h]
    snapshot_preservation.append(dict(label=label,omitted_count=s['omitted_count'],all_omitted_absent=all(not (root/p).exists() for p in s['omitted_before_checkout']),tracked_count=len(s['tracked_hashes']),changed_paths=bad))
checks.update(all24pins=len(pins)==24 and all(e['matches'] for e in pins),all_proposal22pins=len(proposal_pins)==22 and all(e['matches'] for e in proposal_pins),approved_evidence_proposal_pins_equal=evidence['proposal_authority']==prior['authority'],product_manifest_unchanged=m['product_manifest']==prior['product_manifest']==evidence['product_manifest'],accepted_pins=all(len(a['controls'])==19 and all(e['matches'] for e in a['controls']) for a in accepted),all327=all(x['count']==327 and x['raw_exit']==1 and x['multiset_matches'] for x in lint),allcoveredhashes=all(all(e['matches'] for e in x['covered_hashes']) and x['registry_source_matches'] and x['registry_class_ast_matches'] for x in lint),ruff_version=all(x['ruff_version']=='ruff '+scope['ruff_version'] for x in lint),listener_hashes=all(x['matches'] for x in listener_hashes),exact13listeners=len(listeners['existing_nodes'])==len(set(listeners['existing_nodes']))==13 and listeners['new_nodes']==[],snapshots_preserved=all(x['changed_paths']==[] and x['all_omitted_absent'] and x['omitted_count']==267 for x in snapshot_preservation))
after=git('original-head-after','rev-parse','HEAD').decode().strip();checks['original_head_unchanged']=head==after==C
result=dict(reviewer='/root/telem02_a02_approved_readiness',model='GPT-6 Codex; exact build unavailable',review_date=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate=C,proposal=P,base=B,manifest_sha256=sha(manifest_bytes),mode='new independent read-only approved-authority/lint-renewal readiness; not product verification',context='Reused independent reviewer instance from historical TELEM02; no involvement in TELEM03 generation. All TELEM03 checks performed anew; not a fresh-context product validator.',pins=pins,proposal_pins=proposal_pins,accepted=accepted,lint=lint,listeners=listeners,listener_hashes=listener_hashes,snapshot_preservation=snapshot_preservation,checks=checks,receipts=receipts,delta_paths=delta)
(OUT/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':checks,'lint_summary':[{k:x[k] for k in ['label','count','raw_exit','multiset_matches','registry_class_ast_matches']} for x in lint],'candidate':C},indent=2))
