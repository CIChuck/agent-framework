from pathlib import Path
import ast,json,hashlib,importlib.util,subprocess,time,tomllib
P=Path('/private/tmp/telem-04/CDR-019');R=P/'approved-snapshot';l=json.loads((R/'docs/planning/active/friday-telemetry-rewire/validation/WVR-006-telem04-lint-scope.json').read_text());raw=json.loads((P/'root-ruff.stdout').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,v): (P/n).write_text(json.dumps(v,indent=2)+'\n')
normalized=[dict(path=str(Path(d['filename']).relative_to(R)),code=d['code'],location=d['location'],end_location=d['end_location'],message=d['message']) for d in raw]
key=lambda d:(d['path'],d['code'],d['location']['row'],d['location']['column'],d['end_location']['row'],d['end_location']['column'],d['message'])
normalized.sort(key=key); expected=sorted(l['diagnostics'],key=key); regpath=next(d['path'] for d in expected if not d['path'].startswith('docs/'));source=(R/regpath).read_bytes();cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry');dump=ast.dump(cls,include_attributes=False).encode()
save('lint-final-reconciliation.json',dict(normalized_count=len(normalized),exact_identities=normalized==expected,new_identities=[d for d in normalized if d not in expected],missing_identities=[d for d in expected if d not in normalized],archive_count=sum(d['path'].startswith('docs/') for d in normalized),live_count=sum(not d['path'].startswith('docs/') for d in normalized),registry_path=regpath,registry_source_sha256=sha(source),registry_source_matches=sha(source)==l['command_registry_source_sha256'],registry_class_ast_sha256=sha(dump),registry_class_ast_matches=sha(dump)==l['command_registry_class_ast_sha256'],correction='Initial static-reconciliation.json mistakenly selected the Chat registry; raw receipt retained. This recheck derives the historical CLI CommandRegistry path from the pinned lint identity.',target=tomllib.loads((R/'pyproject.toml').read_text())['tool']['ruff']['target-version']))
save('root-ruff-exact-identities.json',normalized)
spec=importlib.util.spec_from_file_location('prep','/private/tmp/telem-02/builder-baseline/prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.OUT=P
env=h.environment(R,'source-resolution');py=str(h.REPO/'.venv/bin/python')
code="""import sys,json,importlib.metadata,importlib.util,pathlib,hashlib,shutil
names=['ruff','mypy','pytest']; o={'python':sys.version,'executable':sys.executable,'uv':shutil.which('uv'),'ruff_executable':shutil.which('ruff'),'mypy_executable':shutil.which('mypy'),'distributions':{}}
for name in names:
 d=importlib.metadata.distribution(name); spec=importlib.util.find_spec(name); p=pathlib.Path(spec.origin); o['distributions'][name]={'version':d.version,'location':str(d.locate_file('')),'module_origin':str(p),'module_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'metadata_sha256':hashlib.sha256(d.read_text('METADATA').encode()).hexdigest()}
print(json.dumps(o,indent=2))"""
for label,args in [('source-resolution',[py,'-c',code]),('ruff-target',['/opt/homebrew/bin/uv','run','--no-sync','ruff','check','--show-settings',regpath])]:
 started=time.time();result=subprocess.run(args,cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(P/(label+'.stdout')).write_bytes(result.stdout);(P/(label+'.stderr')).write_bytes(result.stderr);save(label+'-receipt.json',dict(command=args,cwd=str(R),revision='b8d885f3a7e2665257047c7758fd33c94a3338e4',environment=env,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(started)),exit_code=result.returncode,seconds=time.time()-started,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
print(json.dumps(json.loads((P/'lint-final-reconciliation.json').read_text()),indent=2))
