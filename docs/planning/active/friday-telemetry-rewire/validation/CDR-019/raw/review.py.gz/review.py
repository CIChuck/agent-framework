from pathlib import Path
import ast, importlib.util, json, subprocess, time, hashlib, concurrent.futures, tomllib, sys
OUT=Path('/private/tmp/telem-04/CDR-019')
spec=importlib.util.spec_from_file_location('preparer','/private/tmp/telem-02/builder-baseline/prepare.py'); h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h); h.OUT=OUT
C='b8d885f3a7e2665257047c7758fd33c94a3338e4'; P='1c463368a8d4b741111c28f7ee5210e5b7d26a48'; B='e6209e3156216afde1655758e280690229f7d3e6'; A='2155a0fc51f5b20dea4e35c6cfc70f1d52002735'
PREFIX='docs/planning/active/friday-telemetry-rewire/'
def save(n,v): h.save(n,v)
def blob(rev,path): return h.git('show',rev+':'+path)
def jblob(rev,path): return json.loads(blob(rev,path))
def run(label,args,root):
 env=h.environment(root,label); started=time.time(); result=subprocess.run(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (OUT/(label+'.stdout')).write_bytes(result.stdout); (OUT/(label+'.stderr')).write_bytes(result.stderr)
 save(label+'-receipt.json',dict(command=args,cwd=str(root),revision=C,environment=env,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(started)),exit_code=result.returncode,seconds=time.time()-started,stdout_sha256=h.sha(result.stdout),stderr_sha256=h.sha(result.stderr)))
 print(label,result.returncode,flush=True); return result
save('original-before.json',h.original_state())
root,snap=h.prepare('approved-snapshot',C)
manifest=jblob(C,PREFIX+'authority-manifest-TELEM-04.yaml'); original=jblob(P,PREFIX+'authority-manifest-TELEM-04.yaml'); approval=jblob(C,PREFIX+'directives/CD-004-approval-evidence.json')
authority=[]
for row in manifest['authority']:
 authority.append(dict(**row,actual_sha256=h.sha(blob(C,row['path'])),matches=h.sha(blob(C,row['path']))==row['sha256']))
original_pins=[]
for row in original['authority']:
 original_pins.append(dict(**row,proposal_sha256=h.sha(blob(P,row['path'])),matches=h.sha(blob(P,row['path']))==row['sha256']))
products=[v for vs in manifest['product_manifest'].values() for v in vs]
changes=h.git('diff','--name-only',P,C).decode().splitlines(); delta=h.git('diff',P,C).decode(); (OUT/'proposal-approved.diff').write_text(delta)
accepted_paths=[p for p in h.git('ls-tree','-r','--name-only',P).decode().splitlines() if p.startswith(('docs/archive/completed/2026/friday-telemetry-rewire-telem-','docs/archive/completed/2026/friday-mcp/')) or p in [row['path'] for row in original['authority'][:27]]]
accepted={p:h.sha(blob(C,p))==h.sha(blob(P,p)) for p in accepted_paths}
inv=jblob(C,PREFIX+'execution/TELEM-04-planning/source-inventory.json'); listeners=jblob(C,PREFIX+'execution/TELEM-04-planning/listener-scope.json'); lint=jblob(C,PREFIX+'validation/WVR-006-telem04-lint-scope.json')
registry='packages/friday-chat/src/friday_chat/commands/registry.py'; tree=ast.parse((root/registry).read_text()); cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry')
class_hash=h.sha(ast.dump(cls,include_attributes=False).encode())
configs={p: h.sha((root/p).read_bytes())==digest for p,digest in lint['lint_configurations'].items()}
archives={p: h.sha((root/p).read_bytes())==digest for p,digest in lint['archived_files'].items()}
fixtures={p:h.sha((root/p).read_bytes())==digest for p,digest in listeners['fixture_hashes'].items()}
source={p:h.sha((root/p).read_bytes())==d['sha256'] for p,d in inv['existing'].items()}
source_ast={p:h.public_ast(root/p)==d['public_api'] for p,d in inv['existing'].items()}
new_absent={p:not (root/p).exists() for p in inv['new_paths_absent']}
lock_equal=h.sha(blob(C,'uv.lock'))==h.sha(blob(B,'uv.lock'))
save('static-reconciliation.json',dict(candidate=C,proposal=P,preparation_base=B,aggregate_base=A,branch=h.git('branch','--show-current').decode().strip(),authority_count=len(authority),authority=authority,original_authority_count=len(original_pins),original_authority=original_pins,approval_original_matches=approval['original_authority']==original['authority'],product_count=len(products),product_categories={k:len(v) for k,v in manifest['product_manifest'].items()},product_unchanged=manifest['product_manifest']==original['product_manifest']==approval['product_manifest']==inv['manifest'],proposal_approved_paths=changes,product_delta=[p for p in changes if p.startswith('packages/')],accepted_count=len(accepted),accepted_unchanged=accepted,configs=configs,archives=archives,registry_source_matches=h.sha((root/registry).read_bytes())==lint['command_registry_source_sha256'],registry_class_ast_actual=class_hash,registry_class_ast_matches=class_hash==lint['command_registry_class_ast_sha256'],fixture_matches=fixtures,listener_count=len(listeners['existing_nodes']),listener_new_count=len(listeners['new_nodes']),source_hash_matches=source,source_api_matches=source_ast,new_paths_absent=new_absent,lock_unchanged=lock_equal,guard_matches=h.sha((h.GUARD/'sitecustomize.py').read_bytes())=='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81'))
UV='/opt/homebrew/bin/uv'; py=str(h.REPO/'.venv/bin/python'); existing=manifest['product_manifest']['existing_source']
commands=[('tool-python',[py,'--version']),('tool-ruff',[UV,'run','--no-sync','ruff','--version']),('tool-mypy',[UV,'run','--no-sync','mypy','--version']),('tool-pytest',[UV,'run','--no-sync','pytest','--version']),('prospective-ruff',[UV,'run','--no-sync','ruff','check',*existing]),('prospective-mypy',[UV,'run','--no-sync','mypy','--python-version','3.13',*existing]),('root-ruff',[UV,'run','--no-sync','ruff','check','.','--output-format','json']),('lock',[UV,'lock','--offline','--check','--no-python-downloads','--no-build']),('docs',[UV,'run','--no-sync','python','scripts/check-documentation-lifecycle.py']),('unit-diff',['git','diff','--check',B,C]),('aggregate-diff',['git','diff','--check',A,C])]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 results=list(pool.map(lambda pair:run(pair[0],pair[1],root),commands))
for label,args in [('board-validate',['validate']),('board-next',['next']),('board-show',['show','friday-telemetry-rewire']),('board-render',['render','--check'])]: run(label,[UV,'run','--no-sync','python','scripts/friday-dev-board.py',*args],root)
raw=json.loads((OUT/'root-ruff.stdout').read_text()); print('lint fields',list(lint['diagnostics'][0]),flush=True)
normalized=[]
for d in raw:
 normalized.append(dict(path=str(Path(d['filename']).relative_to(root)),code=d['code'],start=[d['location']['row'],d['location']['column']],end=[d['end_location']['row'],d['end_location']['column']],message=d['message']))
save('root-ruff-normalized.json',sorted(normalized,key=lambda d:(d['path'],d['code'],d['start'],d['end'],d['message'])))
save('snapshot-preservation.json',dict(tracked_unchanged=all(h.sha((root/p).read_bytes())==v for p,v in snap['tracked_hashes'].items()),protected_absent=all(not (root/p).exists() for p in snap['omitted_before_checkout'])))
save('original-after.json',h.original_state())
print('checks complete',flush=True)
