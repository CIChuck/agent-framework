from original import MoltbookResponse as Original
from final import MoltbookResponse as Final
from pydantic import BaseModel
class Parent(BaseModel):
    value: str
class Child(Parent):
    extra: int
def old_parent_child(value: Original[Parent]) -> Original[Child]:
    return value

def old_child_parent(value: Original[Child]) -> Original[Parent]:
    return value

def final_parent_child(value: Final[Parent]) -> Final[Child]:
    return value

def final_child_parent(value: Final[Child]) -> Final[Parent]:
    return value

