import asyncio,contextvars,io,json,sys,threading,time
from dataclasses import asdict
from pathlib import Path
import hashlib
from friday_telemetry import create_telemetry,TelemetryFactoryConfig,CompositeProvider,TelemetryOperationError
from friday_chat.runtime import build_runtime
from friday_chat.config import FridayChatConfig
from friday_chat.app import FridayChatApp,ListInputSource
from opentelemetry import trace
async def main():
 stream=io.StringIO();old=sys.stdout;global_provider=trace.get_tracer_provider();before=set(threading.enumerate());sys.stdout=stream
 first=create_telemetry(TelemetryFactoryConfig(provider='otel'));second=create_telemetry(TelemetryFactoryConfig(provider='otel'))
 try:
  runtime=build_runtime(FridayChatConfig(),telemetry=CompositeProvider([first.telemetry,second.telemetry]),session_id='PRIVATE_VALIDATOR_SESSION')
  result=await FridayChatApp(runtime=runtime,input_source=ListInputSource([])).run();assert result.exit_reason=='eof';assert not first.snapshot().closed and not second.snapshot().closed
  parent=first.telemetry.start_span('validator.parent')
  async def child(name):
   child_id=first.telemetry.start_span(name);await asyncio.sleep(0);first.telemetry.capture_event('validator.event',{'boolean':True,'count':1});first.telemetry.end_span(child_id)
  await asyncio.gather(child('validator.child.one'),child('validator.child.two'))
  contextvars.Context().run(first.telemetry.end_span,parent)
  first.telemetry.capture_event('validator.standalone',{'min':-(2**63),'max':2**63-1})
  assert first.flush().status==second.flush().status=='success'
  closed1=first.shutdown();closed2=second.shutdown();assert first.shutdown() is closed1;assert not first.snapshot().worker_alive and not second.snapshot().worker_alive
  runtime.telemetry.emit('application_stop');assert runtime.telemetry.snapshot().state=='failed'
 finally:
  first.shutdown();second.shutdown();sys.stdout=old
 raw=stream.getvalue();assert 'PRIVATE_VALIDATOR_SESSION' not in raw;decoder=json.JSONDecoder();spans=[];s=raw.strip()
 while s:
  value,pos=decoder.raw_decode(s);spans.append(value);s=s[pos:].lstrip()
 parent=next(x for x in spans if x['name']=='validator.parent');children=[x for x in spans if x['name'].startswith('validator.child.')];assert len(children)==2;assert all(x['parent_id']==parent['context']['span_id'] and x['context']['trace_id']==parent['context']['trace_id'] for x in children)
 standalone=next(x for x in spans if x['name']=='validator.standalone');assert standalone['parent_id'] is None
 lifecycle=[e['name'] for x in spans for e in x['events'] if e['name'].startswith('chat.')];assert lifecycle.count('chat.runtime_ready')==2 and lifecycle.count('chat.application_start')==2 and lifecycle.count('chat.application_stop')==2
 assert trace.get_tracer_provider() is global_provider;assert not any(t not in before and t.name=='FridayTelemetryExporter' for t in threading.enumerate())
 imports={}
 for name,module in tuple(sys.modules.items()):
  path=getattr(module,'__file__',None)
  if isinstance(path,str) and name.startswith(('friday_','opentelemetry','grpc')):
   resolved=Path(path).resolve();assert not resolved.is_relative_to(Path('/Users/chuckrussell/Dev/gendev/agent-framework')) or resolved.is_relative_to(Path('/Users/chuckrussell/Dev/gendev/agent-framework/.venv'));imports[name]={'path':str(resolved),'sha256':hashlib.sha256(resolved.read_bytes()).hexdigest()}
 print(json.dumps({'source_resolution':imports,'actual_sdk_console_spans':spans,'app_exit_reason':result.exit_reason,'borrowed_ownership':True,'global_unchanged':True,'worker_cleanup':True,'postclose_observer_state':runtime.telemetry.snapshot().state,'first_shutdown':asdict(closed1),'second_shutdown':asdict(closed2)},indent=2))
asyncio.run(main())
