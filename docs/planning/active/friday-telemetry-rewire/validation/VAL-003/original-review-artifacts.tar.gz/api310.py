import asyncio, collections, copy, dataclasses, hashlib, inspect, json, typing, uuid
import pydantic
from pydantic import BaseModel, ConfigDict, Field, ValidationError
class Probe(BaseModel):
    model_config=ConfigDict(extra='forbid',frozen=True,strict=True,hide_input_in_errors=True)
    name:typing.Literal['fixed']='fixed'
    ref:str=Field(pattern=r'^[a-f0-9]{16}$')
    count:int=Field(default=0,ge=0,le=1000000)
p=Probe.model_validate({'ref':'a'*16})
assert p.model_dump(exclude={'name'},exclude_none=True)=={'ref':'a'*16,'count':0}
try:Probe.model_validate({'ref':'PRIVATE_SENTINEL'})
except ValidationError as e:
    assert 'PRIVATE_SENTINEL' not in str(e)
    assert all('input' not in d for d in e.errors(include_input=False,include_url=False))
else:raise RuntimeError('invalid value accepted')
print(json.dumps({'python_api_sources':{name:inspect.getsourcefile(module) for name,module in [('collections',collections),('dataclasses',dataclasses),('copy',copy),('typing',typing),('uuid',uuid),('asyncio',asyncio)]},'pydantic_version':pydantic.__version__,'pydantic_source':pydantic.__file__,'apis_passed':['deque(maxlen)','dataclass(frozen)','deepcopy','hashlib.sha256','encode(errors=surrogatepass)','typing.Literal','uuid4.hex','asyncio.CancelledError','BaseModel.model_validate','BaseModel.model_dump(exclude/exclude_none)','ConfigDict(extra/frozen/strict/hide_input_in_errors)','Field(pattern/ge/le)','ValidationError.errors(include_input/include_url)']},indent=2))
