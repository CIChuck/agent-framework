import base64, hashlib, importlib.metadata as m, json, sys, typing
from collections import deque
from dataclasses import dataclass
from uuid import uuid4
from asyncio import CancelledError
inventory=[]
for d in sorted(m.distributions(),key=lambda x:x.metadata['Name'].lower()):
    bad=[]; checked=0
    for f in d.files or []:
        if f.hash and f.hash.mode=='sha256':
            p=d.locate_file(f)
            if not p.is_file(): bad.append(str(f)+': missing'); continue
            actual=base64.urlsafe_b64encode(hashlib.sha256(p.read_bytes()).digest()).rstrip(b'=').decode()
            checked+=1
            if actual!=f.hash.value: bad.append(str(f)+': hash mismatch')
    inventory.append({'name':d.metadata['Name'],'version':d.version,'requires_python':d.metadata.get('Requires-Python'),'path':str(d._path),'record_checked':checked,'record_mismatches':bad,'direct_url':d.read_text('direct_url.json')})
@dataclass(frozen=True)
class Frozen: n:int
q=deque(maxlen=2); q.extend([1,2,3])
print(json.dumps({'version':sys.version,'executable':sys.executable,'stdlib_api_smoke':{'deque_maxlen':list(q)==[2,3],'dataclass_frozen':Frozen(1).n==1,'sha256_surrogatepass':len(hashlib.sha256('\ud800'.encode('utf-8',errors='surrogatepass')).hexdigest())==64,'typing_literal':hasattr(typing,'Literal'),'uuid4_hex':bool(uuid4().hex),'cancelled_baseexception':issubclass(CancelledError,BaseException),'typing_NotRequired':hasattr(typing,'NotRequired')},'distributions':inventory},indent=2))
