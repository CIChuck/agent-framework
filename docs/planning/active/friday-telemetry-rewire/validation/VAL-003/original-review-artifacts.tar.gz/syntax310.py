import ast
import sys
from pathlib import Path
for filename in sys.argv[1:]:
    ast.parse(Path(filename).read_text(encoding='utf-8'),filename=filename,feature_version=(3,10))
print('Python 3.10 syntax parses:',len(sys.argv)-1,'files')
