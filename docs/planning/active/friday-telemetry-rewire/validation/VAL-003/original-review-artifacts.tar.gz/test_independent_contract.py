import asyncio
from types import SimpleNamespace
import pytest
from friday_telemetry import CompositeProvider, TelemetryInterface, DebugTelemetryRecorder
from friday_telemetry.providers.composite import CompositeDeliveryError
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.config import FridayChatConfig, load_friday_py_config, FridayChatConfigError
from friday_chat.runtime import build_runtime
from friday_chat.app import FridayChatApp, ListOutputSink

class Local(TelemetryInterface):
    def __init__(self, ids, *, fail_start=False, fail_end=False, mutate=False):
        self.ids=iter(ids); self.started=[]; self.ends=[]; self.events=[]; self.fail_start=fail_start; self.fail_end=fail_end; self.mutate=mutate
    def start_span(self,name,parent_id=None):
        if self.fail_start: raise RuntimeError('SECRET_START')
        sid=next(self.ids); self.started.append((sid,name,parent_id)); return sid
    def end_span(self,sid,data=None):
        self.ends.append((sid,data))
        if self.mutate and data: data['nested']['text']='MUTATED'
        if self.fail_end: raise RuntimeError('SECRET_END')
    def capture_event(self,name,data):
        self.events.append((name,data))
        if self.mutate: data['nested']['text']='MUTATED'

@pytest.mark.parametrize('old_first',[True,False])
def test_active_replacement_and_stale_end(old_first):
    a,b=Local(['local','child']),Local(['local','child']); c=CompositeProvider([a]); old=c.start_span('old'); c.remove_provider(a); c.add_provider(b); new=c.start_span('new',old); child=c.start_span('child',new)
    assert old=='local' and old!=new!=child
    assert b.started==[('local','new',None),('child','child','local')]
    first,last=(old,new) if old_first else (new,old)
    c.end_span(first); c.end_span(first); c.end_span(child); c.end_span(last); c.end_span(last); c.end_span('unknown')
    assert len(a.ends)==1 and a.ends[0][0]=='local'
    assert [x[0] for x in b.ends] in [['local','child'],['child','local']]

def test_completed_and_generated_reservation(monkeypatch):
    monkeypatch.setattr('friday_telemetry.providers.composite.uuid4',lambda:SimpleNamespace(hex='ns'))
    a=Local(['ns:1','ns:1','ns:2']); c=CompositeProvider([a]); old=c.start_span('one'); c.end_span(old); new=c.start_span('two'); assert new=='ns:2'; c.end_span(old); assert len(a.ends)==1
    c.end_span(new); third=c.start_span('three'); assert third=='ns:3'; c.end_span(new); assert len(a.ends)==2; c.end_span(third)
    empty=CompositeProvider([]); prior=empty.start_span('empty'); empty.end_span(prior); b=Local([prior]); empty.add_provider(b); now=empty.start_span('new'); empty.end_span(prior); assert not b.ends; empty.end_span(now); assert b.ends[0][0]==prior

def test_nested_payload_and_membership_snapshot():
    bad,good,new=Local(['a','aa'],mutate=True),Local(['b','bb']),Local(['c'])
    c=CompositeProvider([bad,good]); p=c.start_span('parent'); c.remove_provider(bad); c.add_provider(new); nested=c.start_span('nested',p)
    assert good.started[-1][2]=='b' and new.started[-1][2] is None
    c.end_span(p,{'nested':{'text':'SAFE'}}); assert good.ends[0][1]=={'nested':{'text':'SAFE'}} and not new.ends
    c.end_span(nested)
    c=CompositeProvider([bad,good]); data={'nested':{'text':'SAFE'}}; c.capture_event('event',data); assert data['nested']['text']=='SAFE' and good.events[-1][1]==data

def test_start_rollback_and_end_fanout_failures():
    fail=Local([],fail_start=True); opened_bad=Local(['a'],fail_end=True); opened_good=Local(['b']); c=CompositeProvider([opened_bad,fail,opened_good])
    with pytest.raises(CompositeDeliveryError) as e:c.start_span('attempt')
    assert e.value.failure_count==2 and 'SECRET' not in str(e.value); assert len(opened_bad.ends)==len(opened_good.ends)==1
    bad,good=Local(['a'],fail_end=True),Local(['b']); c=CompositeProvider([bad,good]); p=c.start_span('parent')
    with pytest.raises(CompositeDeliveryError):c.end_span(p)
    c.end_span(p); assert len(bad.ends)==len(good.ends)==1

def test_observer_rejects_payload_and_keeps_bounded_failed_state():
    class Bad(DebugTelemetryRecorder):
        def capture_event(self,name,data): raise RuntimeError('PRIVATE_SENTINEL')
    o=ChatTelemetryObserver(enabled=False,session_id='PRIVATE_SENTINEL',provider=Bad()); assert o.enabled
    o.capture_event('mcp.tool_call_finish',{'tool_ref':'b'*16,'reason':'success','count':1}); o.capture_event('mcp.tool_call_finish',{'name':'tool_call_start'}); o.capture_event('chat.runtime_ready',{'session_ref':'0'*16,'outcome':'succeeded'})
    for _ in range(300):o.emit('runtime_ready')
    s=o.snapshot(); assert s.provider=='injected' and not s.configured and s.state=='failed' and len(s.events)==256 and s.rejected_count==2 and s.failure_count==303 and s.dropped_count==348
    assert 'PRIVATE_SENTINEL' not in repr(s)
    last=s.events[-1].sequence; o.emit('application_stop'); assert s.events[-1].sequence==last and o.snapshot().events[-1].sequence==last+2

def test_strict_config_compatibility_and_safe_error(tmp_path):
    assert FridayChatConfig().telemetry.enabled is False
    for body in ['enabled: 1','provider: PRIVATE_SENTINEL','PRIVATE_SENTINEL: PRIVATE_SENTINEL']:
        p=tmp_path/'config.yaml'; p.write_text('llm:\n  model: fake/model\ntelemetry:\n  '+body+'\n')
        with pytest.raises(FridayChatConfigError) as e:load_friday_py_config(p,env={})
        assert 'PRIVATE_SENTINEL' not in str(e.value)

@pytest.mark.asyncio
async def test_cancelled_operation_waits_for_cleanup_and_reports_cleanup_failure(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path); entered=asyncio.Event(); closing=asyncio.Event(); release=asyncio.Event()
    class Input:
        async def read(self):entered.set(); await asyncio.Event().wait()
    a,b=DebugTelemetryRecorder(),DebugTelemetryRecorder(); r=build_runtime(FridayChatConfig(),session_id='PRIVATE_SENTINEL',telemetry=CompositeProvider([a,b]))
    async def close():
        closing.set(); await release.wait(); assert 'chat.application_stop' not in a.event_names; raise RuntimeError('PRIVATE_SENTINEL')
    monkeypatch.setattr(r.async_clients,'close',close)
    task=asyncio.create_task(FridayChatApp(runtime=r,input_source=Input(),output_sink=ListOutputSink()).run()); await entered.wait(); task.cancel(); await closing.wait(); assert 'chat.application_stop' not in a.event_names; release.set()
    with pytest.raises(asyncio.CancelledError):await task
    assert a.get_event('chat.application_stop')==b.get_event('chat.application_stop'); stop=a.get_event('chat.application_stop'); assert stop['outcome']=='cancelled' and stop['reason']=='shutdown_failed'; assert 'PRIVATE_SENTINEL' not in repr(r.telemetry.snapshot())

def test_real_runtime_is_observed_before_construction(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path); fake=build_runtime(FridayChatConfig()); sink=DebugTelemetryRecorder(); seen=[]
    def assemble(config,*,session_identity,maintenance_layout,telemetry):
        seen.append(telemetry); assert telemetry.snapshot().events==(); telemetry.capture_event('mcp.connection_finish',{'count':1,'reason':'connected'}); return fake
    monkeypatch.setattr('friday_chat.runtime._build_framework_runtime',assemble)
    r=build_runtime(FridayChatConfig(),fake=False,telemetry=sink)
    assert r.telemetry is seen[0] and sink.event_names==['mcp.connection_finish','chat.runtime_ready']
