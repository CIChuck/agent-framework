import socket, subprocess, sys
try: socket.getaddrinfo('nonloopback.invalid',80)
except RuntimeError: print('parent external DNS denied')
else: raise RuntimeError('guard missing')
p=subprocess.run([sys.executable,'-c',"import socket; socket.getaddrinfo('nonloopback.invalid',80)"],capture_output=True,text=True)
assert p.returncode!=0 and 'Non-loopback DNS prohibited' in p.stderr
print('child guard inherited')
