import ast, hashlib, json, os, pathlib, subprocess, sys, time
import yaml
OUT=pathlib.Path('/private/tmp/telem-01/VAL-003')
REQUEST=yaml.safe_load((OUT/'request.yaml').read_text())
ROOTS={'candidate':pathlib.Path(REQUEST['checkout']),'baseline':pathlib.Path(REQUEST['baseline_checkout'])}
UV='/opt/homebrew/bin/uv'
GUARD=pathlib.Path(REQUEST['network_guard']['path'])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*args): return subprocess.check_output(['/usr/bin/git','-C',str(root),*args],text=True)
def state(root):
    paths=git(root,'ls-files','-z').split('\0')
    return {'head':git(root,'rev-parse','HEAD').strip(),'status':git(root,'status','--porcelain=v1','--untracked-files=all'),'tracked':{p:sha(root/p) for p in paths if p and (root/p).is_file()},'diff':git(root,'diff'),'cached_diff':git(root,'diff','--cached')}
def env(root, label, name):
    tmp=OUT/'tmp'/label/name; tmp.mkdir(parents=True,exist_ok=True)
    paths=[str(GUARD.parent)]+[str(p) for p in sorted((root/'packages').glob('*/src'))]+[str(root/'packages/friday-chat/tests_chat'),str(root)]
    return {'PATH':'/Users/chuckrussell/Dev/gendev/agent-framework/.venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','UV_PROJECT_ENVIRONMENT':'/Users/chuckrussell/Dev/gendev/agent-framework/.venv','UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_NO_SYNC':'true','UV_OFFLINE':'true','LITELLM_LOCAL_MODEL_COST_MAP':'true','ANONYMIZED_TELEMETRY':'False','TERM':'xterm-256color','PYTHONPATH':os.pathsep.join(paths),'TMPDIR':str(tmp),'PYTHONDONTWRITEBYTECODE':'1','RUFF_CACHE_DIR':str(tmp/'ruff-cache'),'MYPY_CACHE_DIR':str(tmp/'mypy-cache'),'PYTEST_ADDOPTS':'-o cache_dir='+str(tmp/'pytest-cache')}
def run(label,name,args):
    root=ROOTS[label]; e=env(root,label,name)
    log=OUT/f'{label}-{name}.log'; t=time.time()
    with log.open('w') as f: r=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
    record={'label':label,'name':name,'command':args,'cwd':str(root),'revision':git(root,'rev-parse','HEAD').strip(),'environment':e,'exit_code':r.returncode,'seconds':round(time.time()-t,3),'log':str(log),'sha256':sha(log)}
    (OUT/f'{label}-{name}.json').write_text(json.dumps(record,indent=2))
    print(label,name,r.returncode,round(time.time()-t,1),flush=True)
    return record
if __name__=='__main__':
    action=sys.argv[1]
    if action=='pin':
        records=[]
        for item in REQUEST['authority']:
            actual=sha(ROOTS['candidate']/item['path']); records.append({**item,'actual':actual,'matches':actual==item['sha256']})
        actual=sha(ROOTS['candidate']/REQUEST['authority_manifest']); records.append({'path':REQUEST['authority_manifest'],'expected':REQUEST['authority_manifest_sha256'],'actual':actual,'matches':actual==REQUEST['authority_manifest_sha256']})
        actual=sha(GUARD); records.append({'path':str(GUARD),'expected':REQUEST['network_guard']['sha256'],'actual':actual,'matches':actual==REQUEST['network_guard']['sha256']})
        (OUT/'pins.json').write_text(json.dumps(records,indent=2)); assert all(x['matches'] for x in records)
        for label,root in ROOTS.items():
            (OUT/f'{label}-before.json').write_text(json.dumps(state(root),indent=2))
            inventory=[]
            for p in sorted(list((root/'packages').glob('*/tests_*/**/*.py'))+list((root/'experiments').glob('*/tests/**/*.py'))):
                s=p.read_text(); tree=ast.parse(s); imports=[ast.unparse(n) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))]
                inventory.append({'path':str(p.relative_to(root)),'sha256':sha(p),'imports':imports})
            (OUT/f'{label}-preflight.json').write_text(json.dumps({'revision':git(root,'rev-parse','HEAD').strip(),'testpaths':['packages/*/tests_*','experiments/*/tests'],'modules':inventory,'no_env_or_state':not any((root/p).exists() for p in ['.env','.friday','chroma_db']), 'network_guard_sha256':sha(GUARD)},indent=2))
        print('all 12 authority hashes, manifest, guard pinned; complete tracked state and import inventory retained')
    elif action=='collect':
        for label in ROOTS: run(label,'root-collect',[UV,'run','pytest','--import-mode=importlib',*['--ignore='+p for p in REQUEST['exclusions'][:0]],'--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py','--collect-only'])
    elif action=='static':
        for label,root in ROOTS.items():
            sources=[p for p in REQUEST['exact_changed_source'] if (root/p).exists()]
            python=[p for p in REQUEST['exact_changed_python'] if (root/p).exists()]
            checks=[('versions',[UV,'run','python','-c','import sys,importlib.metadata as m; print(sys.version); print({n:m.version(n) for n in ["pytest","ruff","mypy","pydantic","litellm"]})']),('root-ruff',[UV,'run','ruff','check','.']),('changed-ruff',[UV,'run','ruff','check',*python]),('mypy310',[UV,'run','mypy','--python-version','3.10',*sources]),('mypy313',[UV,'run','mypy','--python-version','3.13',*sources]),('syntax310',[UV,'run','python',REQUEST['required_checks']['syntax_script'],*sources]),('board',[UV,'run','python','scripts/friday-dev-board.py','validate']),('docs',[UV,'run','python','scripts/check-documentation-lifecycle.py']),('diff-check',['/usr/bin/git','diff','--check'])]
            for name,args in checks: run(label,name,args)
    elif action=='focused':
        for label,root in ROOTS.items():
            tests=['packages/friday-chat/tests_chat/'+p for p in ['test_telemetry.py','test_cli.py','test_runtime.py','test_app_lifecycle.py','compat/test_config_compatibility.py']]+['packages/friday-telemetry/tests_telemetry/test_providers.py']
            run(label,'focused',[UV,'run','pytest',*[p for p in tests if (root/p).exists()]])
            run(label,'packages',[UV,'run','pytest','packages/friday-chat/tests_chat','packages/friday-telemetry/tests_telemetry'])
    elif action=='root':
        for label in ROOTS: run(label,'root-execution',[UV,'run','pytest','--import-mode=importlib','--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py'])
    elif action=='after':
        for label,root in ROOTS.items():
            after=state(root); (OUT/f'{label}-after.json').write_text(json.dumps(after,indent=2)); before=json.loads((OUT/f'{label}-before.json').read_text()); print(label,'tracked_same',before['tracked']==after['tracked'],'git_same',all(before[k]==after[k] for k in ['head','diff','cached_diff']),'status',after['status'])
