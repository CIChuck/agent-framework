from run_validation import *
P='/private/tmp/telem-01/REM-002/python310/bin/python'
run('candidate','python310-inventory',[P,str(OUT/'runtime310_inventory.py')])
for label in ROOTS:
    run(label,'python310-telemetry-import',[P,'-c','from friday_telemetry import CompositeProvider, DebugTelemetryRecorder; s=DebugTelemetryRecorder(); c=CompositeProvider([s]); p=c.start_span("synthetic"); c.end_span(p); print("genuine composite lifecycle passed")'])
    code='from friday_chat.runtime import build_runtime; from friday_chat.config import FridayChatConfig; r=build_runtime(FridayChatConfig()); print("genuine runtime import passed")'
    if label=='candidate': code='from friday_chat.telemetry import ChatTelemetryObserver; from friday_telemetry import DebugTelemetryRecorder; o=ChatTelemetryObserver(enabled=True,session_id="synthetic",provider=DebugTelemetryRecorder()); o.emit("runtime_ready"); p=o.start_span("chat.runtime"); o.end_span(p); print("genuine observer lifecycle passed")'
    run(label,'python310-chat-import',[P,'-c',code])
