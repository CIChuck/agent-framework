from run_validation import *
ROOTS['baseline']=pathlib.Path('/private/tmp/telem-01/VAL-003-baseline')
# Pin complete tracked files and controlling inputs again after all test commands.
checks={}
for label,root in ROOTS.items():
    before=json.loads((OUT/('baseline-fresh-before.json' if label=='baseline' else 'candidate-before.json')).read_text())
    after=state(root); (OUT/f'{label}-after-all.json').write_text(json.dumps(after,indent=2))
    checks[label]={'tracked_count':len(after['tracked']),'unchanged_tracked':before['tracked']==after['tracked'],'unchanged_head':before['head']==after['head'],'unchanged_diff':before['diff']==after['diff'] and before['cached_diff']==after['cached_diff'],'unchanged_status':before['status']==after['status']}
    assert all(v for k,v in checks[label].items() if k!='tracked_count')
for row in json.loads((OUT/'pins.json').read_text()):
    p=pathlib.Path(row['path']) if row['path'].startswith('/') else ROOTS['candidate']/row['path']
    assert sha(p)==row['actual']
checks['controlling_hashes_unchanged']=True
checks['request_sha256']=sha(OUT/'request.yaml'); checks['operational_addendum_sha256']=sha(OUT/'operational-addendum.yaml')
checks['no_product_delta_from_3a69050']=not git(ROOTS['candidate'],'diff','--name-only',REQUEST['delta_base'],REQUEST['candidate'],'--','packages').strip()
(out:=OUT/'final-state-comparison.json').write_text(json.dumps(checks,indent=2)); print(checks)
# Complete command records retain every nonzero result, including reviewer probe errors.
records=[]
for p in sorted(OUT.glob('*.json')):
    if p.name=='evidence.json':continue
    try:d=json.loads(p.read_text())
    except ValueError:continue
    if isinstance(d,dict) and 'command' in d and 'exit_code' in d:records.append(d)
evidence={'validation_id':'VAL-003','outcome':'CHANGES_REQUESTED','reviewer':'fresh subagent /root/telem01_rem002_validator','model':'GPT-6 (session identity; exact backend version unavailable)','date':'2026-10-05','review_mode':'fresh-context read-only REM-002 execution delta followed by full aggregate TELEM-01','candidate':REQUEST['candidate'],'base':REQUEST['base'],'delta_base':REQUEST['delta_base'],'authority_pins':'pins.json','state_comparison':checks,'commands':records,'findings':[{'id':'VAL-003-F01','severity':'high','criterion':'AC-06','summary':'Mandatory aggregate verification gates remain nonzero or incomplete without an approved waiver','dispositions':['Root Ruff337 unchanged exact logs','Package PTY failure + three unprivileged listener errors, matched baseline','Root16 failures +11 listener errors, matched baseline','Python3.10 Chat observer runtime incomplete: frozen LiteLLM NotRequired import fails baseline and candidate; Composite genuine lifecycle passes']}],'exclusions':['packages/friday-chat/tests_chat/test_live_lmstudio.py','packages/friday-llm/tests_llm/test_live_lmstudio.py'],'privileged_tests':REQUEST['permitted_privileged_tests'],'shared_context_exceptions':['Frozen request and raw inventories supplied by controller only; no builder implementation or prior conformance report read','Controller operational addendum changes baseline path only and permits reviewed fake-provider synthetic ignored audit artifacts; not conformance evidence'],'test_effects':['Synthetic temp files under VAL-003/tmp','Exactly one ignored synthetic prompt-transcript-audit artifact per isolated root checkout, path/hash manifests retained','Unchanged synthetic OTel console fixture locally captured; close-file exporter warning retained at both revisions'],'nonzero_probe_corrections':['independent-probes v1 had reviewer arithmetic error:604 total records minus256 capacity is348 drops; corrected probe passes9. v1 source/log retained','guard-check v1 was reviewer quoting SyntaxError before execution; corrected file-backed parent/child DNS denial probe passes. Original command/log retained'],'limitations':['No 3.10 Chat observer runtime pass','No root/package PASS; privileged3-node passes do not override broad failures','No additional live exclusions or unapproved privilege','No source/docs/test/config/authority/Git mutations; no credential/vendor/real-user-state access','Original A01 default-root failure retained historically as request context, not rerun or independently claimed here']}
(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2))
