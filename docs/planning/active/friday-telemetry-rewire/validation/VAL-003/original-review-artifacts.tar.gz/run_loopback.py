from run_validation import *
ROOTS['baseline']=pathlib.Path('/private/tmp/telem-01/VAL-003-baseline')
label=sys.argv[1]
run(label,'approved-three-loopback',[UV,'run','pytest',*REQUEST['permitted_privileged_tests']])
