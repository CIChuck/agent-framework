from run_validation import *
ROOTS['baseline']=pathlib.Path('/private/tmp/telem-01/VAL-003-baseline')
old=json.loads((OUT/'baseline-before.json').read_text())
fresh=state(ROOTS['baseline']); (OUT/'baseline-fresh-before.json').write_text(json.dumps(fresh,indent=2))
assert fresh['head']==REQUEST['base'] and not fresh['status'] and old['tracked']==fresh['tracked']
for label,root in ROOTS.items():
    paths=sorted((root/'experiments/prompt_transcript_audit/artifacts').glob('*'))
    assert all(p.name=='.gitkeep' for p in paths)
    (OUT/f'{label}-synthetic-artifact-before.json').write_text(json.dumps({str(p):sha(p) for p in paths if p.is_file()},indent=2))
# Candidate collection already passed on this immutable checkout; fresh base repeated before any root execution.
run('baseline','root-collect-fresh',[UV,'run','pytest','--import-mode=importlib','--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py','--collect-only'])
for label in ROOTS:
    run(label,'root-execution',[UV,'run','pytest','--import-mode=importlib','--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py'])
for label,root in ROOTS.items():
    (OUT/f'{label}-synthetic-artifact-after.json').write_text(json.dumps({str(p):sha(p) for p in sorted((root/'experiments/prompt_transcript_audit/artifacts').glob('*')) if p.is_file()},indent=2))
    after=state(root); (OUT/f'{label}-final-state.json').write_text(json.dumps(after,indent=2))
    before=json.loads((OUT/('baseline-fresh-before.json' if label=='baseline' else 'candidate-before.json')).read_text())
    print(label,'unchanged_tracked',before['tracked']==after['tracked'],'unchanged_head',before['head']==after['head'],'status',after['status'],flush=True)
