from snapshot import *
from datetime import datetime,timezone
OUT.mkdir(exist_ok=True)
save('original-before.json', original_state())
save('reviewer.json',dict(identity='/root/telem03_product_validator',model='GPT-6 inherited parent model',fresh_context=True,mode='read-only independent unit and complete aggregate',date=datetime.now(timezone.utc).isoformat(),accepted_helpers=['/private/tmp/telem-02/builder-baseline/prepare.py','/private/tmp/telem-02/builder-execution/pytest_source_audit.py'],private_reasoning_read=False))
REV='dd543fd6a6819ec0c4fb2529fa384fea886f5509'
root,receipt=prepare('candidate',REV)
base,br=prepare('unit-base','4ca9baecdcdcf26fc5e8055b326c3a54cda36cb7')
manifest=json.loads((root/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-03.yaml').read_text())
checks=[dict(**a,actual=sha((root/a['path']).read_bytes()),original_actual=sha((REPO/a['path']).read_bytes())) for a in manifest['authority']]
save('authority-check.json',checks)
if len(checks)!=24 or any(a['sha256']!=a['actual'] or a['sha256']!=a['original_actual'] for a in checks):raise RuntimeError('Authority drift')
if receipt['guard_sha256']!='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81':raise RuntimeError('guard drift')
paths={}
for label,rev in [('unit','4ca9baecdcdcf26fc5e8055b326c3a54cda36cb7'),('aggregate','2155a0fc51f5b20dea4e35c6cfc70f1d52002735')]:
 names=git('diff','--name-only',rev,REV).decode().splitlines()
 py=[p for p in names if p.endswith('.py') and not protected(p)]
 source=[p for p in py if '/src/' in p]
 packages=sorted({p.split('/')[1] for p in source if p.startswith('packages/')})
 owning=sorted(str(p.relative_to(root)) for pkg in packages for p in (root/'packages'/pkg).glob('tests_*') if p.is_dir())
 paths[label]=dict(base=rev,names=names,python=py,source=source,owning_tests=owning)
 (OUT/(label+'-product.patch')).write_bytes(git('diff',rev,REV,'--','packages','pyproject.toml','uv.lock','main.py','scripts','experiments','tests',':(exclude)tests/integration/memory/.friday',':(exclude)tests/integration/memory/vector',':(exclude)tests/integration/memory/vector2_bak',':(exclude)tests/integration/memory/vector_bak',':(exclude)tests/integration/memory/.doltcfg',':(exclude)experiments/provider_memory_smoke/memory'))
save('expanded-paths.json',paths)
allowed=set(sum(manifest['product_manifest'].values(),[]))
unit_product=[p for p in paths['unit']['names'] if not p.startswith('docs/planning/')]
save('unit-scope.json',dict(product=unit_product,extra=sorted(set(unit_product)-allowed)))
for label in paths:print(label,{k:len(v) for k,v in paths[label].items() if isinstance(v,list)})
print('AUTHORITY',len(checks),'PROTECTED',receipt['omitted_count'],'SCOPE',set(unit_product)-allowed)
