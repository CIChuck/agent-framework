from boundary import SessionContext
class Parent:pass
class Child(Parent):pass
def assignments(parent: SessionContext[Parent], child: SessionContext[Child]) -> None:
 parent = child
 child = parent
