from boundary import CommandRegistry
class Parent:pass
class Child(Parent):pass
def assignments(parent: CommandRegistry[Parent], child: CommandRegistry[Child]) -> None:
 parent = child
 child = parent
