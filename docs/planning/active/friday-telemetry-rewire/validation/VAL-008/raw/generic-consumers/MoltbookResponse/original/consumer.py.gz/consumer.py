from boundary import MoltbookResponse
class Parent:pass
class Child(Parent):pass
def assignments(parent: MoltbookResponse[Parent], child: MoltbookResponse[Child]) -> None:
 parent = child
 child = parent
