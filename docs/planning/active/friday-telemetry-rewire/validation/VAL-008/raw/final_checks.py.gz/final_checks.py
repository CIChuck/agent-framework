from snapshot import *
import yaml,importlib.metadata
ROOT=OUT/'candidate'
manifest=json.loads((ROOT/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-03.yaml').read_text())
approval=json.loads((ROOT/'docs/planning/active/friday-telemetry-rewire/directives/CD-003-approval-evidence.json').read_text())
checks=[dict(**a,actual=sha(git('show',approval['proposal_revision']+':'+a['path']))) for a in approval['proposal_authority']]
assert len(checks)==22 and all(a['sha256']==a['actual'] for a in checks)
assert approval['product_manifest']==manifest['product_manifest']
save('approval-proposal-checks.json',checks)
checks=[]
for manifestpath in ['docs/planning/active/friday-telemetry-rewire/authority-manifest.yaml','docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-02.yaml']:
 d=yaml.safe_load((ROOT/manifestpath).read_text())
 for a in d['authority']:
  checks.append(dict(manifest=manifestpath,**a,actual=sha((ROOT/a['path']).read_bytes())))
assert all(a['sha256']==a['actual'] for a in checks)
save('accepted-nested-authority-checks.json',checks)
versions={}
for name in ['ruff','mypy','pytest','opentelemetry-api','opentelemetry-sdk','grpcio','pydantic']:
 d=importlib.metadata.distribution(name);versions[name]=dict(version=d.version,metadata_sha256=sha(d.read_text('METADATA').encode()))
versions['python']=dict(version=sys.version,executable=sys.executable,executable_sha256=sha(Path(sys.executable).read_bytes()))
save('tooling-hashes.json',versions)
original=original_state();save('original-after.json',original)
before=json.loads((OUT/'original-before.json').read_text())
controls=[dict(path=a['path'],sha256=a['sha256'],current=sha((REPO/a['path']).read_bytes())) for a in manifest['authority']]
assert all(a['sha256']==a['current'] for a in controls)
source=[dict(path=p,current_sha256=sha((REPO/p).read_bytes()),candidate_sha256=sha((ROOT/p).read_bytes())) for p in manifest['product_manifest']['source']]
assert all(a['current_sha256']==a['candidate_sha256'] for a in source)
save('final-stability.json',dict(original_head_equal=original['head']==before['head'],original_branch_equal=original['branch']==before['branch'],original_index_equal=original['index_sha256']==before['index_sha256'],status_names_equal=original['status_names_hex']==before['status_names_hex'],tracking_drift='Controller notified preauthorized noncontrolling packet/index/telemetry-only board/dashboard updates during validation. Frozen24controls and candidate product hashes unchanged.',controls=controls,source=source,original_unrelated_payloads_read=False,installed_environment_writes=False))
print('PROPOSAL22/NESTED_AUTHORITY'+str(len(checks))+'/FINAL24_CONTROL_PRODUCT_STABILITY_PASS')
