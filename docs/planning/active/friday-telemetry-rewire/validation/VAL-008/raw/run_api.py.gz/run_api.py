from run_gate import *
save('api-probe-r1-freeze.json',dict(probe_sha256=sha((OUT/'api_probe.py').read_bytes()),runner_sha256=sha(Path(__file__).read_bytes())))
COMMANDS['api-probe']=['python',str(OUT/'api_probe.py')]
run('api-probe-r1','api-probe')
