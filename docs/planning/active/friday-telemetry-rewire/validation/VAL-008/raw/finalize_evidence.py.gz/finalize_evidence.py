from snapshot import *
from datetime import datetime,timezone
ROOT=OUT/'candidate'
paths=json.loads((OUT/'expanded-paths.json').read_text())
manifest=json.loads((ROOT/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-03.yaml').read_text())
# Retain names only for current process/evidence commit; never read builder report.
current=git('rev-parse','HEAD').decode().strip();drift=git('diff','--name-only','dd543fd6a6819ec0c4fb2529fa384fea886f5509',current).decode().splitlines()
assert all(p.startswith('docs/planning/') for p in drift)
assert not set(drift)&{a['path'] for a in manifest['authority']}
save('tracking-commit-drift.json',dict(frozen_product='dd543fd6a6819ec0c4fb2529fa384fea886f5509',current_head=current,paths=drift,product_or_controls_changed=False,controller_notice='Preauthorized tracking/evidence commit55de75; builder report content not read.'))
receipts={p.name:json.loads(p.read_text()) for p in OUT.glob('*-receipt.json')}
pytest={}
for label in ['new-tests-r1','unit-owning-r2-normal-user','root-collect-r1','root-tests-r2-normal-user','aggregate-owning-r2-normal-user']:
 stdout=(OUT/(label+'.stdout')).read_text();summaries=[s for s in stdout.splitlines() if 'passed' in s and s.startswith('=') or 'tests collected' in s and s.startswith('=')]
 skips=[s for s in stdout.splitlines() if s.startswith('SKIPPED')]
 audit=json.loads((OUT/(label+'-source-audit.json')).read_text())
 assert not audit['original_product_import_leaks'] and not audit['owned_workers_remaining']
 pytest[label]=dict(summary=summaries[-1],skip_details=skips,exit=receipts[label+'-receipt.json']['exit'],no_source_leaks=True,no_owned_workers=True)
 optional='packages/friday-memory/tests_memory/test_adapters/test_graph.py::TestElementXGraphStore::test_rank_nodes_pagerank'
save('gate-summary.json',dict(pytest=pytest,mandatory={k:dict(exit=v['exit'],command=v['command'],cwd=v['cwd'],candidate=v['candidate'],stdout_sha256=v['stdout_sha256'],stderr_sha256=v['stderr_sha256']) for k,v in receipts.items()},optional_skip_node=optional,only_live_file_exclusions=['packages/friday-chat/tests_chat/test_live_lmstudio.py','packages/friday-llm/tests_llm/test_live_lmstudio.py'],restricted_failures='Only13authorizedbindsetupfailures; complete corresponding normaluser-r2 gates exitzero.',reviewer_helper_attempt='sdk_consumer_probe.py v1 expected an unallowlisted synthetic span; its private count assertion failed. Preserved source/result. v2 uses accepted chat.application span and passes; no source fix.'))
# Retain all snapshot source hashes and complete original raw reviewer artifacts, excluding private caches and snapshots.
include=[p for p in OUT.rglob('*') if p.is_file() and not any(part in ('candidate','unit-base','tmp','__pycache__') for part in p.relative_to(OUT).parts) and p.name!='original-raw-artifact-manifest.json']
save('original-raw-artifact-manifest.json',dict(reviewer='/root/telem03_product_validator',created=datetime.now(timezone.utc).isoformat(),artifacts={str(p.relative_to(OUT)):dict(sha256=sha(p.read_bytes()),size=p.stat().st_size) for p in sorted(include)},excluded='Snapshots are retained and covered by candidate/unit-base-snapshot.json tracked hashes. Private caches/pycache not evidence.'))
print('FINAL',len(include),'RAW_ARTIFACTS',pytest)
