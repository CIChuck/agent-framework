from boundary import MemoryMetric
class Parent:pass
class Child(Parent):pass
def assignments(parent: MemoryMetric[Parent], child: MemoryMetric[Child]) -> None:
 parent = child
 child = parent
