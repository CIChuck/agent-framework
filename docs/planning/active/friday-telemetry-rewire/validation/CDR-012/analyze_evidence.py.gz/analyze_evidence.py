from review_runner import *
scope=json.loads(blob(REQ['candidate'],REQ['lint_scope']))
def normalize(root,label):
 vals=json.loads((OUT/label).read_text())
 return [dict(path=str(Path(v['filename']).relative_to(root)),code=v['code'],location=v['location'],end_location=v['end_location'],message=v['message']) for v in vals]
def identity(d): return json.dumps(d,sort_keys=True)
raw={n:normalize(OUT/n,n+'-root-ruff.stdout') for n in ['candidate','baseline']}
expected=collections.Counter(map(identity,scope['diagnostics']))
actual=collections.Counter(map(identity,raw['candidate']))
removed=collections.Counter(map(identity,raw['baseline']))-actual
pack=json.loads(blob(REQ['candidate'],REQ['packaging_record']))
per_path=collections.Counter(json.loads(x)['path'] for x,count in removed.items() for _ in range(count))
reg='packages/friday-cli/src/friday_cli/commands.py'
source=blob(REQ['candidate'],reg); node=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry')
checks=dict(raw_counts={n:len(v) for n,v in raw.items()},multiset_matches=actual==expected,extra=list((actual-expected).elements()),missing=list((expected-actual).elements()),removed_count=sum(removed.values()),removed_per_path=dict(per_path),all_removed_paths_packaged=set(per_path)<=set(pack['files']),packaging_counts_match=all(per_path[p]==v['diagnostics_removed_from_discovery'] for p,v in pack['files'].items()),archive_hashes={p:sha(blob(REQ['candidate'],p))==h for p,h in scope['archived_files'].items()},config_hashes={p:sha(blob(REQ['candidate'],p))==h for p,h in scope['lint_configurations'].items()},registry_source_hash=sha(source),registry_source_matches=sha(source)==scope['command_registry_source_sha256'],registry_ast_hash=sha(ast.dump(node,include_attributes=False).encode()),registry_ast_matches=sha(ast.dump(node,include_attributes=False).encode())==scope['command_registry_class_ast_sha256'])
save('lint-analysis.json',checks)
print(json.dumps(checks,indent=2))
sdkroot=REPO/'.venv/lib/python3.13/site-packages'
modules=['opentelemetry/sdk/trace/__init__.py','opentelemetry/sdk/trace/export/__init__.py','opentelemetry/sdk/_shared_internal/__init__.py','opentelemetry/sdk/resources/__init__.py','opentelemetry/sdk/trace/sampling.py','opentelemetry/trace/__init__.py','opentelemetry/context/__init__.py','opentelemetry/context/contextvars_context.py','opentelemetry/exporter/otlp/proto/grpc/exporter.py','opentelemetry/exporter/otlp/proto/grpc/trace_exporter/__init__.py','opentelemetry/exporter/otlp/proto/common/trace_encoder.py','opentelemetry/exporter/otlp/proto/common/_internal/trace_encoder/__init__.py','opentelemetry/exporter/otlp/proto/common/_internal/__init__.py','opentelemetry/proto/collector/trace/v1/trace_service_pb2_grpc.py','opentelemetry/proto/collector/trace/v1/trace_service_pb2.py','grpc/__init__.py','grpc/_channel.py']
hashes={}
for p in modules:
 f=sdkroot/p; hashes[p]=sha(f.read_bytes())
 dest=OUT/'installed-sources'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.read_bytes())
versions={}
for name in ['opentelemetry_api','opentelemetry_sdk','opentelemetry_exporter_otlp_proto_grpc','opentelemetry_exporter_otlp_proto_common','opentelemetry_proto','grpcio','protobuf','ruff','mypy']:
 found=list(sdkroot.glob(name+'-*.dist-info/METADATA'))
 if len(found)==1:
  lines=found[0].read_text().splitlines(); versions[name]=next(x[9:] for x in lines if x.startswith('Version: '))
save('installed-source-evidence.json',dict(module_hashes=hashes,versions=versions,inventory_sdk_matches={p:hashes[p]==h for p,h in json.loads(blob(REQ['candidate'],PKT+'execution/TELEM-02-planning/source-inventory.json'))['sdk_source_hashes'].items()}))
for name in ['candidate','baseline']:
 root=OUT/name
 record=json.loads((OUT/(name+'-snapshot.json')).read_text())
 save(name+'-snapshot-after.json',dict(unchanged=all(sha((root/p).read_bytes())==h for p,h in record['tracked'].items()),protected_absent=all(not(root/p).exists() for p in record['omitted'])))
cmd=['git','--no-optional-locks','-C',str(REPO),'diff','--check',REQ['diff']]
r=subprocess.run(cmd,capture_output=True);(OUT/'diff-check.stdout').write_bytes(r.stdout);(OUT/'diff-check.stderr').write_bytes(r.stderr);save('diff-check.json',dict(command=cmd,exit_code=r.returncode))
save('original-after.json',original())
print('original unchanged',json.loads((OUT/'original-before.json').read_text())==original())
