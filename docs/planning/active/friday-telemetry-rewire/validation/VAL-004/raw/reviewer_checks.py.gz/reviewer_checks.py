import ast, hashlib, json, os, pathlib, subprocess, sys, time, tomllib
from packaging.specifiers import SpecifierSet
OUT=pathlib.Path('/private/tmp/telem-01/REM-003/validation'); ROOT=OUT.parent/'candidate-checkout'; REPO=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); PY=REPO/'.venv/bin/python'; UV='/opt/homebrew/bin/uv'; GUARD=OUT.parent.parent/'REM-001/network-guard'; REQUEST=json.loads((OUT.parent/'validation-request.json').read_text()); COMMIT=REQUEST['candidate']; BASE=REQUEST['delta_base']; AGG=REQUEST['aggregate_base']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def tracked(root):return {p:sha(root/p) for p in git('ls-tree','-r','--name-only',COMMIT).decode().splitlines() if (root/p).is_file()}
def env(name):
 tmp=OUT/'tmp'/name;tmp.mkdir(parents=True,exist_ok=True)
 return {'PATH':str(REPO/'.venv/bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','UV_PROJECT_ENVIRONMENT':str(REPO/'.venv'),'UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_NO_SYNC':'true','UV_OFFLINE':'true','LITELLM_LOCAL_MODEL_COST_MAP':'true','ANONYMIZED_TELEMETRY':'False','TERM':'xterm-256color','PYTHONPATH':os.pathsep.join([str(GUARD)]+[str(p) for p in sorted((ROOT/'packages').glob('*/src'))]+[str(ROOT/'packages/friday-chat/tests_chat'),str(ROOT)]),'TMPDIR':str(tmp),'PYTHONDONTWRITEBYTECODE':'1','RUFF_CACHE_DIR':str(tmp/'ruff'),'MYPY_CACHE_DIR':str(tmp/'mypy'),'PYTEST_ADDOPTS':'-o cache_dir='+str(tmp/'pytest')}
def run(name,args):
 e=env(name); log=OUT/(name+'.log'); started=time.time()
 with log.open('w') as f:result=subprocess.run([str(x) for x in args],cwd=ROOT,env=e,stdout=f,stderr=subprocess.STDOUT)
 record={'command':[str(x) for x in args],'cwd':str(ROOT),'revision':COMMIT,'environment':e,'exit_code':result.returncode,'seconds':round(time.time()-started,3),'log_sha256':sha(log)}
 (OUT/(name+'.json')).write_text(json.dumps(record,indent=2));print(name,result.returncode,record['seconds'],flush=True)
DELTA=git('diff','--name-only',BASE,COMMIT).decode().splitlines(); ALL=git('diff','--name-only',AGG,COMMIT).decode().splitlines(); SOURCES=[p for p in ALL if p.endswith('.py') and '/src/' in p]; CHANGED=[p for p in ALL if p.endswith('.py')]; FOCUS=['packages/friday-chat/tests_chat/'+p for p in ['test_telemetry.py','test_cli.py','test_runtime.py','test_app_lifecycle.py','compat/test_config_compatibility.py']]+['packages/friday-telemetry/tests_telemetry/test_providers.py']; ROOT_ARGS=['--import-mode=importlib','--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py']
if sys.argv[1]=='metadata':
 before=tracked(ROOT);(OUT/'tracked-before.json').write_text(json.dumps(before,indent=2)); (OUT/'original-tracked-before.json').write_text(json.dumps(tracked(REPO),indent=2))
 hashes=[{'path':a['path'],'expected':a['sha256'],'actual':sha(ROOT/a['path'])} for a in REQUEST['authority']]; hashes += [{'path':REQUEST['manifest_path'],'expected':REQUEST['manifest_sha256'],'actual':sha(ROOT/REQUEST['manifest_path'])},{'path':str(GUARD/'sitecustomize.py'),'expected':REQUEST['guard']['sha256'],'actual':sha(GUARD/'sitecustomize.py')}]
 assert all(a['expected']==a['actual'] for a in hashes);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==COMMIT
 projects=[ROOT/'pyproject.toml',*sorted((ROOT/'packages').glob('*/pyproject.toml')),ROOT/'tests/lab/pyproject.toml'];rows=[]
 for p in projects:
  rel=str(p.relative_to(ROOT));current=tomllib.loads(p.read_text());prior=tomllib.loads(git('show',BASE+':'+rel).decode());s=SpecifierSet(current['project']['requires-python']); rejects=['3.10','3.11','3.12','3.13.0','3.13.1','3.13.2','3.13.3'];accepts=['3.13.4','3.13.10'];assert str(s)=='>=3.13.4';assert all(v not in s for v in rejects);assert all(v in s for v in accepts)
  for field in ['dependencies','optional-dependencies']:assert prior['project'].get(field)==current['project'].get(field)
  assert prior.get('dependency-groups')==current.get('dependency-groups');assert prior.get('tool',{}).get('uv')==current.get('tool',{}).get('uv');rows.append({'path':rel,'requirement':str(s),'rejects':rejects,'accepts':accepts})
 assert len(projects)==18
 old=tomllib.loads(git('show',BASE+':uv.lock').decode());new=tomllib.loads((ROOT/'uv.lock').read_text());key=lambda p:(p['name'],p.get('version'),json.dumps(p.get('source'),sort_keys=True)); oldmap={key(p):p for p in old['package']}; added=[];artifact_changes=[]
 for p in new['package']:
  k=key(p)
  if k not in oldmap:added.append(k);continue
  prev=oldmap[k]
  if prev.get('sdist')!=p.get('sdist'):artifact_changes.append((k,'sdist'))
  if not all(w in prev.get('wheels',[]) for w in p.get('wheels',[])):artifact_changes.append((k,'wheels'))
 assert not added and not artifact_changes;assert [p['version'] for p in new['package'] if p['name']=='litellm']==['1.100.1'];assert new['requires-python']=='>=3.13.4';assert not [p for p in DELTA if '/src/' in p or '/tests_' in p]
 (OUT/'metadata.json').write_text(json.dumps({'authority_hashes':hashes,'projects':rows,'lock':{'old_count':len(old['package']),'new_count':len(new['package']),'removed':sorted(set(oldmap)-{key(p) for p in new['package']}),'added_or_changed_versions_sources':added,'artifact_changes':artifact_changes,'litellm':'1.100.1'},'delta_files':DELTA,'aggregate_python_files':CHANGED,'aggregate_sources':SOURCES},indent=2));print('18 metadata checks and frozen surviving lock identities/artifacts PASS')
 (OUT/'delta.diff').write_bytes(git('diff',BASE,COMMIT,'--',*[p for p in DELTA if 'implementation-report' not in p and '/validation/' not in p and 'execution-log' not in p]));print('authority hashes match')
elif sys.argv[1]=='static':
 run('lock',[UV,'lock','--offline','--check','--no-python-downloads','--no-build']);run('changed-ruff',[UV,'run','--no-sync','ruff','check',*CHANGED]);run('mypy313',[UV,'run','--no-sync','mypy','--python-version','3.13',*SOURCES]);run('syntax313',[PY,'-c','import ast,pathlib,sys;[ast.parse(pathlib.Path(p).read_text(),filename=p,feature_version=(3,13)) for p in sys.argv[1:]];print(sys.version)',*SOURCES]);run('root-ruff',[UV,'run','--no-sync','ruff','check','.','--output-format','json']);run('board',[PY,'scripts/friday-dev-board.py','validate']);run('docs',[PY,'scripts/check-documentation-lifecycle.py']);run('diff-check',['git','diff','--check',BASE,COMMIT])
elif sys.argv[1]=='suites':
 run('focused',[UV,'run','--no-sync','pytest',*FOCUS]);run('packages',[UV,'run','--no-sync','pytest','packages/friday-chat/tests_chat','packages/friday-telemetry/tests_telemetry']);run('root-collect',[UV,'run','--no-sync','pytest',*ROOT_ARGS,'--collect-only']);run('root',[UV,'run','--no-sync','pytest',*ROOT_ARGS])
elif sys.argv[1]=='smoke':run('smoke',[PY,str(OUT/'reviewer_smoke.py')])
elif sys.argv[1]=='after':
 after=tracked(ROOT);(OUT/'tracked-after.json').write_text(json.dumps(after,indent=2));orig=tracked(REPO);(OUT/'original-tracked-after.json').write_text(json.dumps(orig,indent=2));assert after==json.loads((OUT/'tracked-before.json').read_text());assert orig==json.loads((OUT/'original-tracked-before.json').read_text());print('candidate and original tracked hashes unchanged')
