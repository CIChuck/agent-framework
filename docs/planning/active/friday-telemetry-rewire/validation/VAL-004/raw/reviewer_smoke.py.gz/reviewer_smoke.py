import asyncio,json,pathlib,sys,tempfile
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import build_runtime
from friday_chat.app import FridayChatApp,ListInputSource,ListOutputSink
from friday_telemetry import CompositeProvider,TelemetryInterface
class Recorder(TelemetryInterface):
 def __init__(self):self.events=[];self.starts=[];self.ends=[];self.closed=False
 def capture_event(self,name,data):self.events.append((name,data))
 def start_span(self,name,parent_id=None):
  sid=f'span-{len(self.starts)}';self.starts.append((sid,name,parent_id));return sid
 def end_span(self,sid,data=None):self.ends.append((sid,data))
 def close(self):self.closed=True
async def main():
 with tempfile.TemporaryDirectory() as d:
  first,second=Recorder(),Recorder(); comp=CompositeProvider([first,second]);observer=ChatTelemetryObserver(enabled=False,session_id='PRIVATE_SENTINEL',provider=comp)
  parent=observer.start_span('chat.runtime');child=observer.start_span('chat.application',parent);observer.end_span(child,{'outcome':'succeeded','count':1});observer.end_span(parent);observer.end_span(parent)
  for r in [first,second]:
   assert r.starts[1][2]==r.starts[0][0];assert len(r.ends)==2
  old=comp.start_span('old');comp.remove_provider(first);replacement=Recorder();comp.add_provider(replacement);new=comp.start_span('new',old);assert old!=new;assert replacement.starts[0][2] is None;comp.end_span(old);comp.end_span(new);comp.end_span(old)
  cfg=FridayChatConfig.model_validate({'llm':{'model':'fake/test'},'memory':{'persist_directory':str(pathlib.Path(d)/'memory')},'transcript':{'export_directory':str(pathlib.Path(d)/'transcript')}});runtime=build_runtime(cfg,fake=True,session_id='PRIVATE_SENTINEL',telemetry=comp);assert runtime.telemetry is not None;await FridayChatApp(runtime=runtime,input_source=ListInputSource([]),output_sink=ListOutputSink()).run();snap=runtime.telemetry.snapshot();assert [e.name for e in snap.events]==['chat.runtime_ready','chat.application_start','chat.application_stop'];assert dict(snap.events[-1].attributes)['outcome']=='succeeded';assert 'PRIVATE_SENTINEL' not in repr(snap);assert not any(r.closed for r in [first,second,replacement]);assert first.events==second.events[:len(first.events)]
  print(json.dumps({'python':sys.version,'chat':sys.modules['friday_chat.runtime'].__file__,'observer':sys.modules['friday_chat.telemetry'].__file__,'composite':sys.modules['friday_telemetry.providers.composite'].__file__,'checks':['real public observer','synthetic fake Chat lifecycle','two sink parent mapping and exactly once end','replacement collision','caller-owned sinks preserved','safe snapshots']},indent=2))
asyncio.run(main())
