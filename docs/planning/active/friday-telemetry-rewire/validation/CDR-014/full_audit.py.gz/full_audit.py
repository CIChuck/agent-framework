from review_runner import *
import tomllib
req_manifest=json.loads(blob(REQ['candidate'],REQ['manifest_path']))
save('manifest-consistency.json',dict(authority_matches=req_manifest['authority']==REQ['authority'],base_matches=req_manifest['base']==REQ['base'],unit_matches=req_manifest['work_unit']==REQ['work_unit'],status=req_manifest['status']))
pack=json.loads(blob(REQ['candidate'],REQ['packaging_record']))
accepted=[]
for sub in ['execution/REM-004-final/','validation/VAL-006/']:
 for p in git('ls-tree','-r','--name-only',REQ['base'],'--',PKT+sub).decode().splitlines():
  old=blob(REQ['base'],p)
  if p in pack['files']: new=gzip.decompress(blob(REQ['candidate'],pack['files'][p]['storage'])); kind='gzip byte preserved'
  elif p==PKT+sub+'artifact-manifest.json': new=blob(REQ['candidate'],PKT+sub+'artifact-manifest.pre-packaging.json');kind='original manifest retained'
  else: new=blob(REQ['candidate'],p);kind='unchanged'
  accepted.append(dict(path=p,kind=kind,base_sha256=sha(old),candidate_original_sha256=sha(new),preserved=old==new))
save('accepted-artifact-preservation.json',dict(count=len(accepted),all_preserved=all(x['preserved'] for x in accepted),files=accepted))
checks=[]
for sub in ['execution/REM-004-final/','validation/VAL-006/']:
 manifest=json.loads(blob(REQ['candidate'],PKT+sub+'artifact-manifest.json'))
 for p,d in manifest.items():
  b=blob(REQ['candidate'],PKT+sub+p)
  checks.append(dict(path=PKT+sub+p,stored_matches=sha(b)==d['sha256'],original_matches=sha(gzip.decompress(b) if p.endswith('.gz') else b)==d.get('original_sha256',sha(gzip.decompress(b) if p.endswith('.gz') else b))))
save('accepted-manifest-hashes.json',dict(count=len(checks),all_match=all(x['stored_matches'] and x['original_matches'] for x in checks),files=checks))
prev_manifest=json.loads(blob(REQ['candidate'],PKT+'validation/CDR-012/artifact-manifest.json'))
prev=[]
for item in prev_manifest['files']:
 b=blob(REQ['candidate'],PKT+'validation/CDR-012/'+item['stored']);raw=gzip.decompress(b) if item['stored'].endswith('.gz') else b
 prev.append(dict(path=item['stored'],stored_matches=sha(b)==item['stored_sha256'],original_matches=sha(raw)==item['original_sha256']))
save('prior-review-storage-hashes.json',dict(count=len(prev),all_match=all(x['stored_matches'] and x['original_matches'] for x in prev),files=prev))
inventory=json.loads(blob(REQ['candidate'],PKT+'execution/TELEM-02-planning/source-inventory.json'))
lock=tomllib.loads(blob(REQ['candidate'],'uv.lock').decode())
lockpins={d['name']:d['version'] for d in lock['package'] if d['name'].startswith('opentelemetry')}
save('source-inventory-checks.json',dict(source_hashes={p:sha(blob(REQ['candidate'],p))==h for p,h in inventory['source_hashes'].items()},lock_pins={p:lockpins.get(p)==v for p,v in inventory['lock_otel_pins'].items()},lock_sha256=sha(blob(REQ['candidate'],'uv.lock'))))
listener=json.loads(blob(REQ['candidate'],PKT+'execution/TELEM-02-planning/listener-scope.json'))
save('listener-analysis.json',dict(existing_count=len(listener['existing_nodes']),new_count=len(listener['new_nodes']),unique=len(set(listener['existing_nodes']+listener['new_nodes']))==13,fixture_hashes={p:sha(blob(REQ['candidate'],p))==h for p,h in listener['existing_fixture_hashes'].items()},future_precollection_required=True,native_guard_limitation=True))
# Read every changed blob; classify full diff without executing any stored code.
changed=git('diff','--name-only',REQ['diff']).decode().splitlines(); files=[]
for p in changed:
 status='deleted'
 try: b=blob(REQ['candidate'],p);status='present'
 except subprocess.CalledProcessError:
  b=blob(REQ['base'],p)
 kind='text';raw=b
 if p.endswith('.gz'):kind='gzip';raw=gzip.decompress(b)
 if p.endswith('.json'):
  json.loads(raw)
 if p.endswith('.py') or p.endswith('.py.gz'):
  ast.parse(raw)
 files.append(dict(path=p,status=status,kind=kind,bytes=len(b),sha256=sha(b),raw_bytes=len(raw),raw_sha256=sha(raw)))
save('full-diff-inventory.json',dict(count=len(files),all_paths_planning=all(x['path'].startswith('docs/planning/') for x in files),files=files))
for label,args in [('tool-python',['python','--version']),('tool-ruff',['ruff','--version']),('tool-mypy',['mypy','--version'])]:run(OUT/'candidate',label,args)
save('original-final.json',original())
print(json.dumps(dict(accepted=len(accepted),accepted_preserved=all(x['preserved'] for x in accepted),manifest_hashed=len(checks),manifest_all_match=all(x['stored_matches'] and x['original_matches'] for x in checks),previous_hashed=len(prev),previous_all_match=all(x['stored_matches'] and x['original_matches'] for x in prev),changed=len(changed),original_unchanged=original()==json.loads((OUT/'original-before.json').read_text())),indent=2))
