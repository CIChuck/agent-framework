from pathlib import Path
import ast, collections, gzip, hashlib, json, os, re, subprocess, time
REPO=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT=Path('/private/tmp/telem-02/approved-readiness')
REQ=json.loads(Path('/private/tmp/telem-02/approved-request.json').read_text())
GUARD=Path('/private/tmp/telem-01/REM-001/network-guard')
PKT='docs/planning/active/friday-telemetry-rewire/'
def sha(b): return hashlib.sha256(b).hexdigest()
def save(n,v): (OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def git(*a): return subprocess.check_output(['git','--no-optional-locks','-C',str(REPO),*a])
def blob(rev,p): return git('show',rev+':'+p)
def omitted(p):
 return any(p.startswith(x) for x in ['tests/integration/memory/.friday/','tests/integration/memory/vector/','tests/integration/memory/vector2_bak/','tests/integration/memory/vector_bak/','tests/integration/memory/.doltcfg/','experiments/provider_memory_smoke/memory/']) or '.friday' in Path(p).parts or Path(p).name=='.env'
def original():
 return dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),index_sha256=sha((REPO/'.git/index').read_bytes()),status_hex=git('status','--porcelain=v1','-z').hex())
def prepare(rev,name):
 root=OUT/name
 if root.exists(): raise RuntimeError('fresh snapshot needed')
 names=git('ls-tree','-r','--name-only',rev).decode().splitlines(); omit=[p for p in names if omitted(p)]
 if len(omit)!=267 or any(p.endswith(('.py','.toml','.yaml')) for p in omit): raise RuntimeError('protected omission drift')
 subprocess.run(['git','clone','--shared','--no-checkout','--quiet',str(REPO),str(root)],check=True)
 subprocess.run(['git','-C',str(root),'config','core.sparseCheckout','true'],check=True)
 subprocess.run(['git','-C',str(root),'config','core.sparseCheckoutCone','false'],check=True)
 (root/'.git/info/sparse-checkout').write_text('/*\n'+''.join('!/'+p+'\n' for p in omit))
 subprocess.run(['git','-C',str(root),'checkout','--quiet','--detach',rev],check=True)
 if any((root/p).exists() for p in omit): raise RuntimeError('runtime materialized')
 for lane in ['active','queued','review','blocked','deferred','backlog']: (root/'docs/planning'/lane).mkdir(exist_ok=True)
 hashes={p:sha((root/p).read_bytes()) for p in names if not omitted(p) and (root/p).is_file()}
 save(name+'-snapshot.json',dict(root=str(root),revision=rev,omitted=omit,tracked=hashes,overlay=[],guard_sha256=sha((GUARD/'sitecustomize.py').read_bytes())))
 return root

def run(root,label,args):
 tmp=OUT/'tmp'/label; tmp.mkdir(parents=True,exist_ok=True)
 env=dict(PATH=f'{REPO}/.venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',UV_PROJECT_ENVIRONMENT=str(REPO/'.venv'),UV_CACHE_DIR=str(tmp/'uv'),UV_NO_SYNC='true',UV_OFFLINE='true',UV_PYTHON_DOWNLOADS='never',LITELLM_LOCAL_MODEL_COST_MAP='true',ANONYMIZED_TELEMETRY='False',TERM='xterm-256color',PYTHONPATH=os.pathsep.join([str(GUARD)]+[str(p) for p in sorted((root/'packages').glob('*/src'))]+[str(root/'packages/friday-chat/tests_chat'),str(root)]),TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1',RUFF_CACHE_DIR=str(tmp/'ruff'),MYPY_CACHE_DIR=str(tmp/'mypy'),PYTEST_ADDOPTS=f'-o cache_dir={tmp}/pytest')
 if sha((GUARD/'sitecustomize.py').read_bytes())!='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81': raise RuntimeError('guard drift')
 cmd=['/opt/homebrew/bin/uv','run','--no-sync']+args
 start=time.time(); res=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 (OUT/(label+'.stdout')).write_bytes(res.stdout); (OUT/(label+'.stderr')).write_bytes(res.stderr)
 save(label+'.json',dict(command=cmd,cwd=str(root),environment=env,exit_code=res.returncode,seconds=time.time()-start,stdout_sha256=sha(res.stdout),stderr_sha256=sha(res.stderr)))
 print(label,res.returncode,len(res.stdout),flush=True)
 return res

if __name__=='__main__':
 save('original-before.json',original())
 pin=[]
 for a in REQ['authority']+[dict(path=REQ['manifest_path'],sha256=REQ['manifest_sha256'])]:
  b=blob(REQ['candidate'],a['path']); actual=sha(b)
  pin.append(dict(**a,actual_sha256=actual,matches=actual==a['sha256']))
  dest=OUT/'sources'/a['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 save('pin-checks.json',pin)
 diff=git('diff','--name-status',REQ['diff']).decode(); (OUT/'diff-name-status.txt').write_text(diff)
 (OUT/'candidate.diff').write_bytes(git('diff',REQ['diff']))
 pack=json.loads(blob(REQ['candidate'],REQ['packaging_record'])); proofs=[]
 for p,v in pack['files'].items():
  before=blob(REQ['base'],p); compressed=blob(REQ['candidate'],v['storage']); after=gzip.decompress(compressed)
  proofs.append(dict(path=p,storage=v['storage'],exact_bytes=before==after,uncompressed_sha256=sha(after),stored_sha256=sha(compressed),hashes_match=sha(after)==v['uncompressed_sha256'] and sha(compressed)==v['stored_sha256']))
 manifests=[]
 for d in ['execution/REM-004-final/','validation/VAL-006/']:
  manifests.append(dict(path=PKT+d+'artifact-manifest.json',retained_exact_bytes=blob(REQ['base'],PKT+d+'artifact-manifest.json')==blob(REQ['candidate'],PKT+d+'artifact-manifest.pre-packaging.json')))
 product=git('diff','--name-only',REQ['base'],REQ['candidate'],'--','packages','uv.lock','pyproject.toml','AGENTS.md','docs/reference').decode().splitlines()
 authtext=blob(REQ['base'],PKT+'authority-manifest.yaml').decode(); auth1={'authority':[dict(path=p,sha256=h) for p,h in re.findall(r'- path: (\S+)\n  sha256: (\S+)',authtext)]}; accept=[]
 for a in auth1['authority']:
  accept.append(dict(path=a['path'],unchanged=blob(REQ['base'],a['path'])==blob(REQ['candidate'],a['path']),pinned=sha(blob(REQ['candidate'],a['path']))==a['sha256']))
 for p in [PKT+'authority-manifest.yaml',PKT+'validation/VAL-006/report.md',PKT+'validation/VAL-006/evidence.json',PKT+'execution/REM-004-final/report.md']:
  accept.append(dict(path=p,unchanged=blob(REQ['base'],p)==blob(REQ['candidate'],p)))
 save('packaging-proof.json',dict(scripts=proofs,manifests=manifests,product_diff=product,accepted_telem01=accept))
 roots={n:prepare(REQ[r],n) for n,r in [('candidate','candidate'),('baseline','base')]}
 for n,root in roots.items():
  for label,args in [('board',['python','scripts/friday-dev-board.py','validate']),('docs',['python','scripts/check-documentation-lifecycle.py']),('root-ruff',['ruff','check','.','--output-format=json'])]:run(root,n+'-'+label,args)
  for label,args in [('next',['python','scripts/friday-dev-board.py','next']),('show',['python','scripts/friday-dev-board.py','show','friday-telemetry-rewire'])]: run(root,n+'-'+label,args)
 save('original-after-checks.json',original())
