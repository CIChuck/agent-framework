import pathlib, subprocess, json, hashlib, tarfile, io, os
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); O=pathlib.Path('/private/tmp/telem-01/REM-004/approved-execution/a06-authority-readiness'); Q=json.loads((O.parent/'a06-authority-request.json').read_text()); C=Q['candidate']
def git(*a): return subprocess.check_output(['/usr/bin/git','-C',str(R),*a])
def sha(b): return hashlib.sha256(b).hexdigest()
def snap():
 st=git('status','--porcelain=v1','-z'); paths=git('diff','--name-only','-z').decode().split('\0'); hashes={p:sha((R/p).read_bytes()) if (R/p).is_file() else 'absent' for p in paths if p}; return {'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'status_sha256':sha(st),'status':st.decode().replace('\0','\n'),'index_sha256':sha((R/'.git/index').read_bytes()),'tracked_diff_sha256':sha(git('diff','--binary')),'staged_diff_sha256':sha(git('diff','--cached','--binary')),'dirty_path_hashes':hashes}
if not (O/'before.json').exists(): (O/'before.json').write_text(json.dumps(snap(),indent=2))
# Export only committed tree; inspect paths before materializing. No original runtime state.
t=tarfile.open(fileobj=io.BytesIO(git('archive','--format=tar',C)))
bad=[m.name for m in t.getmembers() if any(x in {'.env','.friday','chroma_db'} for x in pathlib.PurePosixPath(m.name).parts) or '..' in pathlib.PurePosixPath(m.name).parts or m.issym() or m.islnk()]
members=[m for m in t.getmembers() if m.name not in bad]
D=O/'candidate'; D.mkdir(exist_ok=True); t.extractall(D,members=members)
checks=[]
for x in Q['authority']+[{'path':Q['manifest_path'],'sha256':Q['manifest_sha256']}]:
 b=(D/x['path']).read_bytes(); checks.append({**x,'actual':sha(b),'match':sha(b)==x['sha256'],'worktree_match':sha((R/x['path']).read_bytes())==x['sha256']})
(O/'input-checks.json').write_text(json.dumps(checks,indent=2)); assert all(x['match'] and x['worktree_match'] for x in checks)
(O/'candidate-diff.patch').write_bytes(git('diff',Q['base'],C)); (O/'candidate-diff-stat.txt').write_bytes(git('diff','--stat',Q['base'],C))
(O/'tracked-export.json').write_text(json.dumps({'candidate':C,'blobs':len([m for m in t.getmembers() if m.isfile()]),'excluded_original_state':True,'excluded_paths':bad},indent=2))
print(json.dumps({'pin_checks':len(checks),'all_match':True,'snapshot':'before.json','export':str(D)}))
