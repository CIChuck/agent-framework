import sitecustomize
import sys
sys.path.append('/Users/chuckrussell/Dev/gendev/agent-framework/.venv/lib/python3.13/site-packages')
import pathlib, subprocess, hashlib, json, re, yaml, collections, datetime
R=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); O=pathlib.Path('/private/tmp/telem-01/REM-004/approved-execution/a06-authority-readiness'); D=O/'candidate'; Q=json.loads((O.parent/'a06-authority-request.json').read_text()); C=Q['candidate']; P='docs/planning/active/friday-telemetry-rewire/'
sha=lambda b:hashlib.sha256(b).hexdigest()
G=pathlib.Path('/private/tmp/telem-01/REM-001/network-guard/sitecustomize.py'); assert sha(G.read_bytes())=='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81'
ENV={'PATH':'/usr/bin:/bin','PYTHONPATH':str(G.parent),'PYTHONDONTWRITEBYTECODE':'1','UV_NO_SYNC':'true','UV_OFFLINE':'true','UV_PYTHON_DOWNLOADS':'never','UV_CACHE_DIR':str(O/'uv-cache'),'RUFF_CACHE_DIR':str(O/'ruff-cache'),'TMPDIR':str(O/'tmp'),'LITELLM_LOCAL_MODEL_COST_MAP':'true','ANONYMIZED_TELEMETRY':'False','TERM':'xterm-256color'}
(O/'tmp').mkdir(exist_ok=True)
checks=[]
def run(name,args,cwd=D):
 p=subprocess.run(args,cwd=cwd,env=ENV,capture_output=True); (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr); checks.append({'name':name,'argv':args,'cwd':str(cwd),'exit':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)}); return p
PYTHON=str(R/'.venv/bin/python'); WRAP="import sitecustomize,sys,runpy;sys.path.append('/Users/chuckrussell/Dev/gendev/agent-framework/.venv/lib/python3.13/site-packages');sys.argv=sys.argv[1:];runpy.run_path(sys.argv[0],run_name='__main__')"
for name,cwd in [('candidate',D),('current',R)]:
 for command in [['validate'],['next'],['show','friday-telemetry-rewire']]: run(name+'-board-'+command[0],[PYTHON,'-S','-c',WRAP,str(D/'scripts/friday-dev-board.py'),'--root',str(cwd),*command])
v=run('ruff-version',[str(R/'.venv/bin/ruff'),'--version']); assert v.stdout.strip()==b'ruff 0.14.10'
r=run('root-ruff',[str(R/'.venv/bin/ruff'),'check','.','--output-format','json']); assert r.returncode==1
s=json.loads((D/(P+'remediation/REM-004-scope.json')).read_text()); w=json.loads((D/(P+'validation/WVR-003-command-registry-scope.json')).read_text()); manifest=yaml.safe_load((D/Q['manifest_path']).read_text()); assert manifest['authority']==Q['authority']
diags=json.loads(r.stdout)
def normalize(d): return {k: (str(pathlib.Path(d['filename']).relative_to(D)) if k=='path' and 'filename' in d else d[k]) for k in ['path','code','location','end_location','message']}
actual=[normalize(d) for d in diags]
raw=s['root_ruff']; expected=raw.get('diagnostics',raw.get('diagnostic_multiset',[]))
print('root-scope-keys',list(raw),'expected',len(expected))
arch=[x for x in actual if x['path'] in s['archived_files']]; live=[x for x in actual if x['path'] not in s['archived_files']]
expected_arch=[x for x in expected if x['path'] in s['archived_files']]
canon=lambda x: sorted(json.dumps(d,sort_keys=True) for d in x)
assert len(actual)==459 and len(arch)==326 and len(live)==133
assert len([x for x in actual if x==w['diagnostic']])==1
if expected: assert canon(actual)==canon(expected)
config=json.loads(re.search(r'```json\n(.*?)\n```',(D/(P+'validation/WVR-002-archived-probe-lint.md')).read_text(),re.S).group(1)); assert len(config)==17
hash_checks=[]
for kind,inventory in [('archive',s['archived_files']),('lint_config',config),('command_registry',{'packages/friday-cli/src/friday_cli/commands.py':w['source_sha256']})]:
 for path,h in inventory.items():
  a=sha((D/path).read_bytes()); assert a==h; assert sha((R/path).read_bytes())==h; hash_checks.append({'kind':kind,'path':path,'sha256':h,'candidate_and_current_match':True})
assert 'target-version = "py313"' in (D/'pyproject.toml').read_text()
extras=['packages/friday-agent/tests_agent/conftest.py','packages/friday-runtime/tests_runtime/test_di.py','packages/friday-tools/tests_tools/test_filesystem_readers.py','packages/friday-tools/src/friday_tools/web/validators.py','packages/friday-tools/tests_tools/test_web_validators.py','packages/friday-tools/tests_tools/test_web_reader.py','packages/friday-chat/tests_chat/test_reorganization_terminal.py','packages/friday-core/tests_core/test_interfaces.py','packages/friday-cli/tests_cli/test_cancellation.py','packages/friday-memory/tests_memory/test_llm_completion.py','packages/friday-chat/tests_chat/test_llm_adapter_migration.py']
allowed=sorted(set(s['live_lint_files'])|set(extras)); assert len(allowed)==91 and all((D/p).is_file() for p in allowed)
for path in [P+'remediation/REM-004-scope.json',*config,*s['archived_files'],'packages/friday-cli/src/friday_cli/commands.py']:
 b=subprocess.check_output(['/usr/bin/git','-C',str(R),'show',Q['base']+':'+path]);assert sha(b)==sha((D/path).read_bytes())
current=yaml.safe_load((R/'docs/planning/board.yaml').read_text()); frozen=yaml.safe_load((D/'docs/planning/board.yaml').read_text()); task=lambda b:next(t for t in b['tasks'] if t['id']=='friday-telemetry-rewire'); assert task(current)==task(frozen); t=task(current);assert t['work_state']=='started' and t['implementation_authority']=='granted' and t['branch']=='feature/friday-telemetry-rewire'
partial=[p for p in extras if (R/p).read_bytes()!=(D/p).read_bytes()]; assert len(partial)==6
for p in partial: assert subprocess.check_output(['/usr/bin/git','-C',str(R),'diff','--cached','--',p])==b''
for args in [['diff','--check',Q['base'],C],['diff','--check','2155a0fc51f5b20dea4e35c6cfc70f1d52002735',C]]: assert run('diff-check-'+str(len(checks)),['/usr/bin/git','-C',str(R),*args]).returncode==0
assert all(c['exit']==0 for c in checks if 'board' in c['name'])
E={'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':C,'base':Q['base'],'request':Q,'input_checks':json.loads((O/'input-checks.json').read_text()),'guard':{'path':str(G),'sha256':sha(G.read_bytes()),'unchanged':True},'environment':ENV,'tool_versions':{'python':sys.version,'ruff':v.stdout.decode().strip()},'commands':checks,'hash_checks':hash_checks,'root_ruff':{'raw_exit':r.returncode,'total':len(actual),'archival':len(arch),'live':len(live),'one_wvr003_exact_identity':True,'expected_full_baseline_match':bool(expected),'final_required_total':327,'remaining_live_to_fix':132},'allowed_product_paths':allowed,'partial_uncommitted_paths':partial,'board_task':t,'tracked_export':json.loads((O/'tracked-export.json').read_text()),'readiness_only':True}
(O/'probe-evidence.json').write_text(json.dumps(E,indent=2)); print(json.dumps({'pins':20,'hash_checks':len(hash_checks),'scope':len(allowed),'partial':len(partial),'root':len(actual),'archives':len(arch),'live':len(live),'board_checks':6}))
