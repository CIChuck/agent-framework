from pathlib import Path
import csv,email,hashlib,io,json,os,shutil,subprocess,tarfile,tomllib,urllib.request,zipfile

O=Path('/private/tmp/telem-01/REM-002/environment');O.mkdir(exist_ok=True)
C=Path('/private/tmp/telem-01/REM-002/corrected-review')
p=next(p for p in tomllib.loads((C/'uv.lock').read_text())['package'] if p['name']=='pypika')
url=p['sdist']['url'];digest=p['sdist']['hash'].removeprefix('sha256:')
if not url.startswith('https://files.pythonhosted.org/packages/'):raise RuntimeError('Unexpected download origin')
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
with opener.open(url,timeout=30) as response:
 if not response.url.startswith('https://files.pythonhosted.org/packages/'):raise RuntimeError('Unexpected redirect')
 data=response.read()
if hashlib.sha256(data).hexdigest()!=digest:raise RuntimeError('Locked source hash failed')
source=O/'PyPika-0.48.9.tar.gz';source.write_bytes(data)
cached=Path('/private/tmp/friday-uv-cache/sdists-v9/pypi/pypika/0.48.9/BCRyDNHPghcb0DlgiEZIO/pypika-0.48.9-py2.py3-none-any.whl')
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
 sourcefiles={m.name.split('/',1)[1]:t.extractfile(m).read() for m in t.getmembers() if m.isfile() and '/' in m.name}
allowedmeta={'METADATA','WHEEL','top_level.txt','RECORD','licenses/LICENSE.txt'}
checked={}
with zipfile.ZipFile(cached) as z:
 for name in z.namelist():
  blob=z.read(name)
  if name.startswith('pypika/'):
   if name not in sourcefiles or sourcefiles[name]!=blob:raise RuntimeError('Cached package differs from locked source: '+name)
   checked[name]=hashlib.sha256(blob).hexdigest()
  elif name.startswith('pypika-0.48.9.dist-info/'):
   if name.split('/',1)[1] not in allowedmeta:raise RuntimeError('Unexpected wheel metadata member')
  else:raise RuntimeError('Unexpected wheel member: '+name)
 meta=email.message_from_bytes(z.read('pypika-0.48.9.dist-info/METADATA'))
 if meta['Name'].lower()!='pypika' or meta['Version']!=p['version'] or meta.get_all('Requires-Dist'):raise RuntimeError('Cached dependency metadata differs')
 if b'Root-Is-Purelib: true' not in z.read('pypika-0.48.9.dist-info/WHEEL'):raise RuntimeError('Not a portable pure Python wheel')
 if {n for n in sourcefiles if n.startswith('pypika/') and n.endswith('.py')}!={n for n in checked if n.endswith('.py')}:raise RuntimeError('Cached wheel omits locked Python modules')
artifact=O/cached.name;shutil.copyfile(cached,artifact);wheelhash=hashlib.sha256(artifact.read_bytes()).hexdigest()
req=O/'cached-pypika-requirement.txt';req.write_text('pypika @ '+artifact.as_uri()+' --hash=sha256:'+wheelhash+'\n')
env=dict(PATH='/opt/homebrew/bin:/usr/bin:/bin',UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_PYTHON_DOWNLOADS='never',TMPDIR=str(O/'tmp'),PYTHONDONTWRITEBYTECODE='1')
command=['/opt/homebrew/bin/uv','pip','install','--no-config','--offline','--no-index','--no-python-downloads','--python','/private/tmp/telem-01/REM-002/python310/bin/python','--require-hashes','--no-deps','--no-build','-r',str(req)]
result=subprocess.run(command,cwd=C,env=env,capture_output=True,text=True)
(O/'cached-pypika-install.log').write_text(result.stdout+result.stderr)
(O/'cached-pypika-install.json').write_text(json.dumps(dict(download_url=url,locked_source_sha256=digest,cached_wheel_sha256=wheelhash,source_verified=True,all_package_files_match_locked_source=checked,metadata_name=meta['Name'],metadata_version=meta['Version'],dependencies=[],new_build_executed=False,command=command,environment=env,exit=result.returncode),indent=2)+'\n')
print('Verified all',len(checked),'cached package files against locked source; no build or unlocked dependency.')
print(result.stdout+result.stderr)
if result.returncode:raise SystemExit(result.returncode)
