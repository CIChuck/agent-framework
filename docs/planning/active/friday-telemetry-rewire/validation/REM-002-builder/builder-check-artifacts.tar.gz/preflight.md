# REM-002 execution safety preflight

Before pytest collection, rechecked every raw module hash in the independent
VAL-002 AST/import/hazard/subprocess inventories against new authority candidate
362b66c and unchanged preparation base2155a0f. All621 candidate and619 baseline
inventory modules are unchanged; root discovery/config and helper/fixture code
are unchanged. No product files changed. Exact counts/hashes are in
preflight-state-before.json. The previous raw preflight remains inventory/effect
evidence; prior validator conformance conclusions are not execution evidence.

A03 prepends only isolated Chat tests_chat for existing sibling helper imports;
root uses importlib mode and exactly the two live LM Studio module exclusions.
Collect both roots fully before root execution. No credentials, inherited endpoint
settings, activation flags, copied .env/.friday/transcript/Chroma state or dirty
source files are supplied. Temporary test/cache paths are external.

Original network guard bytes are unchanged (6f61ea4c...e9e81), rejecting all
non-loopback DNS/connect/sendto in CPython tests and inherited subprocesses.
Approved privileged runs are exactly three nodes of test_llm_adapter_migration.py
sharing ThreadingHTTPServer(("127.0.0.1",0)) and shutdown/close/join cleanup;
all other tests remain unprivileged. No extra exclusions or normal suite PASS
substitution follows from a successful privileged listener rerun.

Unchanged explicitly required OTel synthetic console-export fixture may emit
captured local console output. No runtime exporter/vendor endpoint is activated.
Potential unmocked public DNS in existing Web validator tests is blocked by guard;
retain any resulting failures instead of changing the guard or tests.

Existing Python3.10 provisioning is separate from execution: locked exported
requirements, hashes and public PyPI-only cache-first installer with no-build
prevent unconstrained source/build dependencies; existing shared environment and
metadata/lock stay unchanged. Package installation is not a passing compatibility
check. Run genuine imports/lifecycle afterward with the execution network guard.
