from pathlib import Path
import importlib.metadata,sys

root=Path(sys.argv[1]).resolve()
if sys.version_info[:2]!=(3,10): raise RuntimeError('Wrong interpreter')
import friday_chat,friday_telemetry
from friday_telemetry import CompositeProvider,DebugTelemetryRecorder
for module,subpath in [(friday_chat,'packages/friday-chat/src'),(friday_telemetry,'packages/friday-telemetry/src')]:
 if not Path(module.__file__).resolve().is_relative_to(root/subpath): raise RuntimeError('Source resolution escaped isolated checkout')
first,second=DebugTelemetryRecorder(),DebugTelemetryRecorder()
composite=CompositeProvider([first,second])
parent=composite.start_span('synthetic-parent');child=composite.start_span('synthetic-child',parent)
composite.end_span(child,{'count':1});composite.end_span(parent)
for provider in (first,second):
 if len(provider.spans)!=2 or any(s.end_time is None for s in provider.spans.values()): raise RuntimeError('Composite lifecycle failed')
 p=provider.get_span_by_name('synthetic-parent');c=provider.get_span_by_name('synthetic-child')
 parent_id=next(k for k,s in provider.spans.items() if s.name=='synthetic-parent')
 if p is None or c is None or c.parent_id!=parent_id: raise RuntimeError('Parent mapping failed')
if (root/'packages/friday-chat/src/friday_chat/telemetry.py').exists():
 from friday_chat.telemetry import ChatTelemetryObserver
 observer=ChatTelemetryObserver(enabled=True,session_id='synthetic',provider=composite)
 observer.emit('runtime_ready');observer.emit('application_start');observer.emit('application_stop')
 snapshot=observer.snapshot()
 if len(snapshot.events)!=3 or snapshot.failure_count or snapshot.rejected_count: raise RuntimeError('Observer lifecycle failed')
 disabled=ChatTelemetryObserver(enabled=False,session_id='synthetic')
 disabled.emit('runtime_ready')
 if disabled.snapshot().events or disabled.snapshot().state!='disabled': raise RuntimeError('Disabled observer failed')
 print('Genuine Python 3.10 observer/composite import and lifecycle PASS')
else:
 print('Preparation base composite import/lifecycle PASS; observer module absent as expected')
print(sys.version)
print('pydantic',importlib.metadata.version('pydantic'))
print('sources',friday_chat.__file__,friday_telemetry.__file__)
