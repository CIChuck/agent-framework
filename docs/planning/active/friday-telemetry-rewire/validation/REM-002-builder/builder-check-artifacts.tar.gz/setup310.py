from pathlib import Path
import hashlib,json,subprocess,sys,time

O=Path('/private/tmp/telem-01/REM-002');C=O/'corrected-review'
UV='/opt/homebrew/bin/uv';P='/Users/chuckrussell/.local/share/uv/python/cpython-3.10.19-macos-aarch64-none/bin/python3.10'
mode=sys.argv[1];out=O/'environment';out.mkdir(exist_ok=True)
env=dict(PATH='/opt/homebrew/bin:/usr/bin:/bin',UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_PYTHON_DOWNLOADS='never',UV_KEYRING_PROVIDER='disabled',UV_DEFAULT_INDEX='https://pypi.org/simple',TMPDIR=str(out/'tmp'),PYTHONDONTWRITEBYTECODE='1')
Path(env['TMPDIR']).mkdir(exist_ok=True)
requirements=out/'requirements310.txt'
commands={
 'export':[UV,'export','--frozen','--offline','--no-config','--package','friday-chat','--no-emit-workspace','--no-dev','--no-header','--output-file',str(requirements)],
 'create':[UV,'venv','--no-config','--no-python-downloads','--python',P,str(O/'python310')],
 'offline':[UV,'pip','install','--no-config','--offline','--no-python-downloads','--python',str(O/'python310/bin/python'),'--require-hashes','--no-deps','--no-build','-r',str(requirements)],
 'online':[UV,'pip','install','--no-config','--no-python-downloads','--python',str(O/'python310/bin/python'),'--require-hashes','--no-deps','--no-build','--default-index','https://pypi.org/simple','--keyring-provider','disabled','-r',str(requirements),'--verbose'],
 'inventory':[str(O/'python310/bin/python'),'-c','import importlib.metadata as m,json,sys; print(json.dumps({"python":sys.version,"installed":sorted((d.metadata["Name"],d.version) for d in m.distributions())},indent=2))'],
}
if mode in ('offline','online'):
 text=requirements.read_text()
 if any(s in text for s in ['git+','file://','http://','@ https://']):raise RuntimeError('Unexpected dependency origin')
 if '--hash=sha256:' not in text:raise RuntimeError('No frozen hashes')
lock=C/'uv.lock';before=hashlib.sha256(lock.read_bytes()).hexdigest();cmd=commands[mode];log=out/(mode+'.log');start=time.time()
with log.open('w') as f:r=subprocess.run(cmd,cwd=C,env=env,stdout=f,stderr=subprocess.STDOUT)
after=hashlib.sha256(lock.read_bytes()).hexdigest()
if before!=after:raise RuntimeError('Lock changed')
record=dict(mode=mode,command=cmd,cwd=str(C),environment=env,exit=r.returncode,seconds=round(time.time()-start,2),lock_sha256=before,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),requirements_sha256=hashlib.sha256(requirements.read_bytes()).hexdigest() if requirements.exists() else None,origin='cached first; locked public PyPI only if online',builds='no-build; no unlocked build dependencies')
(out/(mode+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True);print(log.read_text()[-2400:],flush=True)
