from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess,tarfile,yaml

root=Path.cwd();packet=root/'docs/planning/active/friday-telemetry-rewire';O=Path('/private/tmp/telem-01/REM-002')
review=packet/'validation/CDR-005';review.mkdir(exist_ok=True)
original=Path('/private/tmp/telem-01/CDR-005');files=sorted(f for f in original.iterdir() if f.is_file())
for n in ['request.yaml','report.md','evidence.yaml']:shutil.copyfile(original/n,review/n)
with tarfile.open(review/'original-review-artifacts.tar.gz','w:gz') as t:
 for f in files:t.add(f,arcname=f.name,recursive=False)
(review/'original-sha256.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files},indent=2)+'\n')
builder=packet/'validation/REM-002-builder';builder.mkdir(exist_ok=True)
selected=sorted([f for f in O.iterdir() if f.is_file()]+[f for f in (O/'environment').iterdir() if f.is_file() and f.suffix in ['.json','.log','.txt']]+[f for d in (O/'checks').iterdir() if d.is_dir() for f in d.iterdir() if f.is_file()])
with tarfile.open(builder/'builder-check-artifacts.tar.gz','w:gz') as t:
 for f in selected:t.add(f,arcname=str(f.relative_to(O)),recursive=False)
hashes={str(f.relative_to(O)):hashlib.sha256(f.read_bytes()).hexdigest() for f in selected}
hashes['builder-check-artifacts.tar.gz']=hashlib.sha256((builder/'builder-check-artifacts.tar.gz').read_bytes()).hexdigest()
(builder/'sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
(packet/'execution/REM-002-implementation-report.md').write_text('''# REM-002 verification execution report

Status: executed under approved A03; mandatory aggregate gates remain failed.
This is builder evidence, not implementation VERIFIED or maintainer acceptance.
Authority candidate: `362b66c720ad3681e556aef8fa1a4a069deb8a1f` after fresh
CDR-005 READY. Reviewed product remains `3a69050`; preparation base `2155a0f`.
No product source/test body/deadline/config, package metadata or lock changed.

## Matched retrospective results

| Required check | Candidate | Preparation baseline |
| --- | --- | --- |
| A03 root collect, importlib + isolated Chat helper entry | 2727 collected, exit0 | 2679 collected, exit0 |
| A03 complete root pytest, exact two live exclusions | 2699 passed,16 failed,11 errors,1 skipped; exit1 | 2651 passed, same16 failed/11 errors/1 skipped; exit1 |
| Root Ruff | 337 diagnostics, exit1 | Identical337 diagnostics, exit1 |
| Changed Python Ruff | 10 files, pass | 9 existing files, pass |
| Source mypy3.10 and3.13 | Both6 files, pass | Both5 existing files, pass |
| 3.10 syntax and unchanged API review | Pass; genuine package import failure retained separately | Pass for5 existing files |
| Focused pytest | 135 passed, exit0 | 87 passed, exit0; observer source/tests absent |
| Complete Chat + telemetry pytest | 724 passed,1 failed,3 errors,5 skipped; exit1 | 676 passed, same failure/errors/skips; exit1 |
| Approved privileged localhost rerun, exactly three nodes | 3 passed, exit0 | 3 passed, exit0 |
| Actual installed3.10 package smoke | Exit1: locked LiteLLM imports unavailable typing.NotRequired; lifecycle not reached | Identical import failure; lifecycle not reached |
| Board/docs checks | Pass:24 tracked tasks/403 Markdown files | Existing absent active-lane failure; exit1 |
| Whitespace/state/authority/preservation | Pass; unchanged tracked review files/12 pins/64 preserved entries | Frozen tracked baseline unchanged |

Root failure/error identifiers and normalized lint diagnostic tuples match exactly,
not merely counts. Root collection now exposes baseline defects/environment
limits that could not run under A01's default duplicate-module import failure.
The original A01 failure remains in VAL-002, not erased or turned into PASS.
Root failures: one unchanged0.8s PTY acknowledgement, seven runtime/native-tool
registration tests, two optional DOCX/XLSX dependency expectation tests, six Web
validation tests under the non-loopback guard. Eleven listener setup errors are
three Chat and eight LLM wire-capture nodes. Only the three approved Chat nodes
were rerun with privilege; broad nonzero suites remain failed. No extra live
exclusion, test change, guard weakening or broad privilege was introduced.

## Python3.10 provisioning and stop condition

Created a separate environment using existing CPython3.10.19. Frozen uv export
preserved lock hash `53efa78379fb81d3089aea9f64e73b0355eb6b292b61ca2bf902cd28babf9272`.
Offline cache-first installation found missing packages; the sandbox blocked
public DNS, then already-approved bounded network permission fetched locked
public PyPI artifacts. No interpreter download, re-resolution, source build or
unlocked build dependency was used. The locked PyPika0.48.9 has no public wheel:
reused its existing pure-Python cached wheel after comparing all16 package files
byte-for-byte with the exact hash-checked locked source archive and verifying
its name/version/no-dependencies metadata. Recorded derived wheel SHA-256 and
installed it offline with --require-hashes. Installed127 locked distributions;
all public artifact URLs/hashes, chosen versions, scripts and failed attempts
are retained. Original PyPika cache files remained unchanged.

Both real package smoke imports then fail at locked LiteLLM1.100.1
`llms/anthropic/experimental_pass_through/context_management/editors/compact.py:17`:
`from typing import ... NotRequired ...` is unavailable on Python3.10. No stub,
monkeypatch, dependency replacement, constraint edit or minimum-version raise
was attempted. This reaches REM-002's incompatibility stop condition. Python3.10
observer/composite lifecycle PASS is not claimed. The remaining permitted checks
are independent evidence and do not substitute for this missing runtime gate.
The existing3.13 test environment uses approved no-sync execution; its versions
are separate from the newly provisioned frozen3.10 dependency set. Its195
installed version/RECORD hashes and pyvenv config remain unchanged.

## Evidence and unresolved disposition

Raw commands, expanded lists, revisions, environment allowlists, exits, logs,
artifact provenance and before/after hashes are losslessly archived in
`validation/REM-002-builder/builder-check-artifacts.tar.gz` with sha256.json.
Temporary test state, caches, database trees and package binaries are excluded.
Safety preflight rechecked621 candidate/619 baseline raw inventory modules;
all are unchanged from the reviewed product. Synthetic tests use isolated
sources, temporary state and the unchanged network guard; no real .friday,
transcript/Chroma data, provider credentials, vendor calls or runtime exporters.
The required historical console OTel fixture's shutdown output exception is
retained; it is not a remote exporter/runtime success claim.

REM-002 setup/reruns are performed, but AC-06 is unresolved. Existing337 lint
diagnostics, root baseline failures, listener permission limits, timing and the
newly exposed frozen dependency incompatibility remain unwaived. Work remains
started, local, validation pending for fresh delta/aggregate independent review.
No source VERIFIED, completion, acceptance, delivery or exception is inferred.
''')
gate='fresh REM-002 execution and aggregate TELEM-01 review; reconcile unwaived baseline and frozen 3.10 dependency gates'
index=packet/'README.md';s=index.read_text().replace('next_gate: fresh A03 readiness review; execute approved REM-002 verification setup and rerun gates','next_gate: '+gate)
s += '\n[CDR-005](validation/CDR-005/report.md) returned READY for corrected A03.\nApproved REM-002 setup/reruns are recorded in the\n[execution report](execution/REM-002-implementation-report.md). Root collection\nis complete, three permitted localhost tests pass, and all broad failures match\nbaseline. The frozen3.10 dependency set installs but genuine imports fail on\nLiteLLM typing.NotRequired, identically at base/candidate. No dependency change,\nwaiver or runtime3.10 PASS is claimed. Fresh independent review is pending.\n';index.write_text(s)
with (packet/'execution-log.md').open('a') as f:f.write('''
## 2026-10-05 — CDR-005 READY; REM-002 verification executed

Fresh CDR-005 READY at362b66c verified all12 pins, manifest SHA and2,091
unchanged tracked files. Evidence is retained verbatim in validation/CDR-005.
Approved setup now collects2727 candidate/2679 baseline tests. Root execution
has2699/2651 passes and exactly matching16 failures,11 listener errors,1 skip.
Root Ruff exactly matches337 diagnostics; source lint, both typing targets,
syntax/API and focused135/87 checks pass. Full affected724/676 passes retain
same timing failure,3 listener errors and5 skips. Exact three privileged
localhost nodes pass at both revisions; no broader privilege is inferred.

Temporary installed3.10 environment contains127 locked distributions, with
public artifact URLs/hashes and verified cached PyPika reuse. Both genuine
imports fail on locked LiteLLM1.100.1 importing typing.NotRequired. Incompatibility
stop condition reached: no dependency/lock/metadata or shared environment edit.
Existing3.13 environment195 version/RECORD hashes, original cached PyPika files,
frozen source/checkouts and64 preserved entries remain unchanged.
All failures are retained without waiver. Stable metadata candidate and fresh
independent execution-delta/aggregate review are next. Work remains started.
''')
spec=importlib.util.spec_from_file_location('board_cli',root/'scripts/friday-dev-board.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
def amend(b):
 t=next(t for t in b['tasks'] if t['id']=='friday-telemetry-rewire');t['next_gate']=gate
 for n in ['report.md','evidence.yaml']:t['validation'].append(str((review/n).relative_to(root)))
 b['events'].append(dict(task='friday-telemetry-rewire',at='2026-10-05',actor='Codex',actor_role='agent',action='REM-002 verification reruns prepared for independent review',note='CDR-005 READY; root collection succeeds, exact permitted localhost nodes pass. Broad failures match baseline; locked3.10 LiteLLM import incompatible. No waiver, dependency/product edit, completion or acceptance.',evidence=str((packet/'execution/REM-002-implementation-report.md').relative_to(root))))
 return b
working=amend(yaml.safe_load((root/'docs/planning/board.yaml').read_text()));(root/'docs/planning/board.yaml').write_text(mod._dump_board(working));(root/'docs/planning/README.md').write_text(mod.render_dashboard(working))
candidate=amend(yaml.safe_load(subprocess.check_output(['git','show','HEAD:docs/planning/board.yaml'],text=True)))
(O/'execution-board.yaml').write_text(mod._dump_board(candidate));(O/'execution-dashboard.md').write_text(mod.render_dashboard(candidate))
print('Archived CDR-005 and',len(selected),'selected builder artifacts; accurate nonzero report prepared.')
