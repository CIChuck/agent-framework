from pathlib import Path
import subprocess, hashlib, json, ast, re
O=Path('/private/tmp/telem-01/VAL-002'); C=Path('/private/tmp/telem-01/VAL-002-review'); B=Path('/private/tmp/telem-01/REM-001/preparation-base')
request=O/'request.yaml'
paths=[]
for line in request.read_text().splitlines():
 if line.startswith('- path: '): paths.append(line[8:])
hashes=re.findall(r'^  sha256: (\w+)$',request.read_text(),re.M)
authority=[dict(path=p,expected=h,actual=hashlib.sha256((C/p).read_bytes()).hexdigest()) for p,h in zip(paths,hashes)]
assert all(x['expected']==x['actual'] for x in authority)
(O/'authority-hashes.json').write_text(json.dumps(authority,indent=2))
def snap(root):
 names=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
 return dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True),files={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names})
(O/'state-before.json').write_text(json.dumps({str(r):snap(r) for r in [C,B]},indent=2))
changed=subprocess.check_output(['git','diff','--name-only','2155a0f..HEAD'],cwd=C,text=True).splitlines()
(O/'changed-paths.json').write_text(json.dumps({p:hashlib.sha256((C/p).read_bytes()).hexdigest() for p in changed},indent=2))
substantive=[p for p in changed if p.startswith('packages/') or p in paths or p in ['docs/planning/board.yaml','docs/planning/README.md','docs/planning/active/friday-telemetry-rewire/README.md','docs/planning/active/friday-telemetry-rewire/authority-manifest.yaml']]
(O/'substantive.diff').write_bytes(subprocess.check_output(['git','diff','2155a0f..HEAD','--',*substantive],cwd=C))
(O/'delta.diff').write_bytes(subprocess.check_output(['git','diff','98cc9e7..HEAD','--','packages/friday-telemetry'],cwd=C))
for root,label in [(C,'candidate'),(B,'baseline')]:
 tests=sorted(set(p for pattern in ['packages/*/tests_*/**/*.py','experiments/*/tests/**/*.py'] for p in root.glob(pattern)))
 helpers=[root/'tests/integration/mcp_fake_server.py',root/'tests/integration/mcp_execution_fake_server.py']
 source=list(root.glob('packages/*/src/**/*.py'))+list(root.glob('experiments/**/*.py'))
 # Parse every collected module and every repository package/experiment imported-helper candidate before any collection.
 inventory=[]
 for p in sorted(set(tests+source+helpers)):
  if not p.is_file(): continue
  tree=ast.parse(p.read_text()); inventory.append(dict(path=str(p.relative_to(root)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),imports=[ast.unparse(n) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))],top_level_calls=[ast.unparse(n)[:500] for n in tree.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call)]))
 (O/f'{label}-preflight-inventory.json').write_text(json.dumps(inventory,indent=2))
 assert not any((root/p).exists() for p in ['.env','.friday','chroma_db'])
print('Authority 11/11 matched; candidate/base clean; complete tracked snapshots and independent parse/import inventory captured.')
