import run_checks as r
from pathlib import Path
import subprocess,json,hashlib
r.run(r.C,'candidate','independent',['pytest','/private/tmp/telem-01/VAL-002/test_independent.py'])
for root,label in [(r.C,'candidate'),(r.B,'baseline')]:
 script='import friday_telemetry; import friday_chat; from friday_telemetry import CompositeProvider,DebugTelemetryRecorder; a,b=DebugTelemetryRecorder(),DebugTelemetryRecorder(); c=CompositeProvider([a,b]); p=c.start_span("parent"); s=c.start_span("child",p); c.end_span(s); c.end_span(p); print("3.10 lifecycle smoke passed")'
 command=['/Users/chuckrussell/.local/share/uv/python/cpython-3.10.19-macos-aarch64-none/bin/python3.10','-c',script]
 log=r.O/f'{label}-runtime310.log'
 with log.open('w') as f: result=subprocess.run(command,cwd=root,env=r.env(root,label),stdout=f,stderr=subprocess.STDOUT)
 (r.O/f'{label}-runtime310.json').write_text(json.dumps(dict(command=command,cwd=str(root),exit=result.returncode,log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest()),indent=2))
 print(label,'runtime310',result.returncode,flush=True)
r.run(r.C,'candidate','origins',['python','-c','import friday_chat,friday_telemetry; print(friday_chat.__file__); print(friday_telemetry.__file__)'])
