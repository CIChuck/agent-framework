import asyncio
from types import SimpleNamespace
import weakref, gc
import pytest
from friday_telemetry import CompositeProvider, TelemetryInterface
from friday_telemetry.providers.composite import CompositeDeliveryError
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import build_runtime
from friday_chat.app import FridayChatApp, ListInputSource, ListOutputSink

class Sink(TelemetryInterface):
 def __init__(self, ids=None, fail=None): self.ids=iter(ids) if ids else None; self.started=[]; self.ended=[]; self.events=[]; self.fail=fail
 def start_span(self,name,parent_id=None):
  if self.fail=='start': raise RuntimeError('PRIVATE_CANARY')
  sid=next(self.ids) if self.ids else f'local-{len(self.started)}'; self.started.append((sid,name,parent_id)); return sid
 def end_span(self,sid,data=None):
  self.ended.append((sid,data))
  if self.fail=='end': raise RuntimeError('PRIVATE_CANARY')
 def capture_event(self,name,data):
  self.events.append((name,data))
  if self.fail=='event': raise RuntimeError('PRIVATE_CANARY')

@pytest.mark.parametrize('end_old_first',[False,True])
def test_active_replacement_and_nested(end_old_first):
 old,new=Sink(['span-0']),Sink(['span-0','span-1']); c=CompositeProvider([old]); a=c.start_span('old'); c.remove_provider(old); c.add_provider(new); b=c.start_span('new',a); d=c.start_span('nested',b)
 assert a=='span-0' and b!=a and len({a,b,d})==3
 assert new.started[0][2] is None and new.started[1][2]=='span-0'
 if end_old_first: c.end_span(a); assert old.ended==[('span-0',None)] and new.ended==[]
 c.end_span(d); c.end_span(b); c.end_span(a); c.end_span(b); c.end_span(a)
 assert old.ended==[('span-0',None)] and [v[0] for v in new.ended]==['span-1','span-0']

def test_completed_replacement_retention_release():
 old=Sink(['same']); ref=weakref.ref(old); c=CompositeProvider([old]); a=c.start_span('old'); c.end_span(a); c.remove_provider(old); del old; gc.collect(); assert ref() is None
 new=Sink(['same']); c.add_provider(new); b=c.start_span('new',a); assert b!=a and new.started[-1][2] is None
 c.end_span(a); assert not new.ended; c.end_span(b); assert new.ended==[('same',None)]

def test_generated_native_collision(monkeypatch):
 monkeypatch.setattr('friday_telemetry.providers.composite.uuid4',lambda:SimpleNamespace(hex='fixed'))
 c=CompositeProvider([]); a=c.start_span('empty'); assert a=='fixed:1'; c.end_span(a)
 s=Sink(['fixed:1','fixed:2']); c.add_provider(s); b=c.start_span('x'); d=c.start_span('y',b); assert b=='fixed:2' and d=='fixed:3'; c.end_span(a); assert not s.ended; c.end_span(d); c.end_span(b)
 assert [v[0] for v in s.ended]==['fixed:2','fixed:1']

@pytest.mark.parametrize('phase',['start','end','event'])
def test_fanout_and_rollback(phase):
 bad,ok=Sink(fail=phase),Sink(); c=CompositeProvider([bad,ok])
 with pytest.raises(CompositeDeliveryError) as e:
  if phase=='event': c.capture_event('safe',{})
  elif phase=='start': c.start_span('x')
  else: sid=c.start_span('x'); c.end_span(sid)
 assert 'PRIVATE_CANARY' not in str(e.value) and e.value.failure_count==1
 if phase=='event': assert len(ok.events)==1
 else: assert len(ok.ended)==1
 if phase=='end': c.end_span(sid); assert len(ok.ended)==1

def test_nested_payload_isolation():
 class Mutator(Sink):
  def capture_event(self,name,data): data['nested']['value']='changed'
  def end_span(self,sid,data=None): data['nested']['value']='changed'
 a,b=Mutator(),Sink(); c=CompositeProvider([a,b]); payload={'nested':{'value':'original'}}; c.capture_event('safe',payload); sid=c.start_span('x'); c.end_span(sid,payload)
 assert payload['nested']['value']=='original' and b.events[0][1]['nested']['value']=='original' and b.ended[0][1]['nested']['value']=='original'

@pytest.mark.asyncio
async def test_content_boundary_and_failure_lifecycle():
 sink=Sink(fail='event'); runtime=build_runtime(FridayChatConfig(),telemetry=sink,session_id='PRIVATE_CANARY'); observer=runtime.telemetry
 observer.capture_event('mcp.tool_call_finish',{'tool_ref':'0'*16,'reason':'success','count':2})
 observer.capture_event('mcp.tool_call_finish',{'reason':'PRIVATE_CANARY'})
 await FridayChatApp(runtime=runtime,input_source=ListInputSource([]),output_sink=ListOutputSink()).run()
 snap=observer.snapshot(); assert snap.state=='failed' and snap.rejected_count==1 and 'PRIVATE_CANARY' not in repr(snap) and 'PRIVATE_CANARY' not in repr(sink.events)
 assert dict([e for e in snap.events if e.name=='chat.application_stop'][-1].attributes)['outcome']=='succeeded'

@pytest.mark.asyncio
async def test_cancelled_cleanup_then_event():
 entered=asyncio.Event()
 class Blocking:
  async def read(self): entered.set(); await asyncio.Event().wait()
 runtime=build_runtime(FridayChatConfig(),telemetry=Sink()); app=FridayChatApp(runtime=runtime,input_source=Blocking(),output_sink=ListOutputSink()); task=asyncio.create_task(app.run()); await entered.wait(); task.cancel()
 with pytest.raises(asyncio.CancelledError): await task
 assert runtime.async_clients.close_calls==1 and not app.started
 stop=runtime.telemetry.snapshot().events[-1]; assert stop.name=='chat.application_stop' and dict(stop.attributes)['outcome']=='cancelled'
