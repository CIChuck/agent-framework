from pathlib import Path
import os, subprocess, json, hashlib, time, sys
O=Path('/private/tmp/telem-01/VAL-002'); C=Path('/private/tmp/telem-01/VAL-002-review'); B=Path('/private/tmp/telem-01/REM-001/preparation-base'); V=Path('/Users/chuckrussell/Dev/gendev/agent-framework/.venv'); G=Path('/private/tmp/telem-01/REM-001/network-guard'); UV='/opt/homebrew/bin/uv'
assert hashlib.sha256((G/'sitecustomize.py').read_bytes()).hexdigest()=='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81'
changed_py=[p for p in subprocess.check_output(['git','diff','--name-only','2155a0f..HEAD'],cwd=C,text=True).splitlines() if p.startswith('packages/') and p.endswith('.py')]; source=[p for p in changed_py if '/src/' in p]
focused=['packages/friday-chat/tests_chat/test_telemetry.py','packages/friday-chat/tests_chat/test_cli.py','packages/friday-chat/tests_chat/test_runtime.py','packages/friday-chat/tests_chat/test_app_lifecycle.py','packages/friday-chat/tests_chat/compat/test_config_compatibility.py','packages/friday-telemetry/tests_telemetry/test_providers.py']
def env(root,label):
 temp=O/'tmp'/label; temp.mkdir(parents=True,exist_ok=True)
 return dict(PATH=str(V/'bin')+':/opt/homebrew/bin:/usr/bin:/bin',UV_PROJECT_ENVIRONMENT=str(V),UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_NO_SYNC='true',UV_OFFLINE='true',LITELLM_LOCAL_MODEL_COST_MAP='true',ANONYMIZED_TELEMETRY='False',TERM='xterm-256color',PYTHONPATH=os.pathsep.join([str(G),*map(str,sorted(root.glob('packages/*/src'))),str(root)]),TMPDIR=str(temp),PYTHONDONTWRITEBYTECODE='1',RUFF_CACHE_DIR=str(O/'cache'/label/'ruff'),MYPY_CACHE_DIR=str(O/'cache'/label/'mypy'),PYTEST_ADDOPTS='-o cache_dir='+str(O/'cache'/label/'pytest'))
def run(root,label,name,args):
 command=[UV,'run',*args]; start=time.time(); log=O/f'{label}-{name}.log'
 with log.open('w') as f: r=subprocess.run(command,cwd=root,env=env(root,label),stdout=f,stderr=subprocess.STDOUT)
 record=dict(command=command,cwd=str(root),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),environment=env(root,label),exit=r.returncode,seconds=round(time.time()-start,2),log=str(log),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 (O/f'{label}-{name}.json').write_text(json.dumps(record,indent=2)); print(label,name,r.returncode,flush=True)
if __name__ == "__main__":
 mode=sys.argv[1]
 for root,label in [(C,'candidate'),(B,'baseline')]:
  py=[p for p in changed_py if (root/p).exists()]; src=[p for p in source if (root/p).exists()]
  if mode=='static':
   checks=[('versions',['python','-c','import sys,importlib.metadata as m; print(sys.version); print({n:m.version(n) for n in ["pydantic","pytest","mypy","ruff"]})']),('root-ruff',['ruff','check','.']),('changed-ruff',['ruff','check',*py]),('mypy310',['mypy','--python-version','3.10',*src]),('mypy313',['mypy','--python-version','3.13',*src]),('syntax310',['python','/private/tmp/telem-01/REM-001/syntax310.py',*src]),('root-pytest',['pytest','--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py']),('board',['python','scripts/friday-dev-board.py','validate']),('docs',['python','scripts/check-documentation-lifecycle.py'])]
  elif mode=='tests': checks=[('focused',['pytest',*[p for p in focused if (root/p).exists()]]),('package',['pytest','packages/friday-chat/tests_chat','packages/friday-telemetry/tests_telemetry'])]
  else: raise ValueError(mode)
  for name,args in checks: run(root,label,name,args)
