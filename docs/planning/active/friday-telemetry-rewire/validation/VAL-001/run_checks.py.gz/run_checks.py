import os,pathlib,subprocess,json,sys
root=pathlib.Path('/private/tmp/telem-01/review'); out=pathlib.Path('/private/tmp/telem-01/VAL-001')
env=os.environ.copy()
for key in list(env):
 if any(token in key.upper() for token in ('API_KEY','TOKEN','SECRET','PASSWORD','LANGFUSE','OTEL_EXPORTER')): env.pop(key,None)
env.update(UV_PROJECT_ENVIRONMENT='/Users/chuckrussell/Dev/gendev/agent-framework/.venv',UV_CACHE_DIR='/private/tmp/friday-uv-cache',LITELLM_LOCAL_MODEL_COST_MAP='true',PYTHONPATH=os.pathsep.join(map(str,sorted(root.glob('packages/*/src')))),PYTHONPYCACHEPREFIX=str(out/'pycache'),MYPY_CACHE_DIR=str(out/'mypy-cache'),RUFF_CACHE_DIR=str(out/'ruff-cache'))
changed=subprocess.check_output(['git','diff','--name-only','2155a0fc51f5b20dea4e35c6cfc70f1d52002735..HEAD','--','packages'],cwd=root,text=True).splitlines()
py=[x for x in changed if x.endswith('.py')]; src=[x for x in py if '/src/' in x]
checks={
 'focused':['uv','run','--no-sync','pytest','-p','no:cacheprovider','packages/friday-chat/tests_chat/test_telemetry.py','packages/friday-chat/tests_chat/test_cli.py','packages/friday-chat/tests_chat/test_runtime.py','packages/friday-chat/tests_chat/test_app_lifecycle.py','packages/friday-chat/tests_chat/compat/test_config_compatibility.py','packages/friday-telemetry/tests_telemetry/test_providers.py'],
 'aggregate':['uv','run','--no-sync','pytest','-p','no:cacheprovider','packages/friday-chat/tests_chat','packages/friday-telemetry/tests_telemetry'],
 'ruff':['uv','run','--no-sync','ruff','check',*py],
 'mypy':['uv','run','--no-sync','mypy','--python-version','3.13',*src],
 'board':['uv','run','--no-sync','python','scripts/friday-dev-board.py','validate'],
 'docs':['uv','run','--no-sync','python','scripts/check-documentation-lifecycle.py'],
 'diff-check':['git','diff','--check','2155a0fc51f5b20dea4e35c6cfc70f1d52002735..0c7b6d4c416402443d140a5ee09abed70be34c69'],
 'origins':['uv','run','--no-sync','python','-c','import friday_chat,friday_telemetry,friday_mcp,friday_runtime; print("\\n".join(x.__file__ for x in [friday_chat,friday_telemetry,friday_mcp,friday_runtime]))']
}
if __name__=='__main__':
 name=sys.argv[1]; cmd=checks[name]
 with (out/(name+'.log')).open('w') as f:
  p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 result={'name':name,'command':cmd,'exit_code':p.returncode}
 (out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result)); print((out/(name+'.log')).read_text()[-8000:])
