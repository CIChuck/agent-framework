import asyncio
import pytest
from friday_chat.app import FridayChatApp,ListInputSource,ListOutputSink
from friday_chat.config import FridayChatConfig,load_friday_py_config,FridayChatConfigError
from friday_chat.runtime import build_runtime
from friday_chat.telemetry import ChatTelemetryObserver
from friday_telemetry import DebugTelemetryRecorder,CompositeProvider,MCPEvent
from friday_telemetry.providers.composite import CompositeDeliveryError

SECRET='probe_private_prompt_response_reasoning_memory_arguments_results_schema_exception_path'

class Mutator(DebugTelemetryRecorder):
 def capture_event(self,name,data):
  data['reason']=SECRET

class Broken(DebugTelemetryRecorder):
 def capture_event(self,name,data): raise RuntimeError(SECRET)

def test_mixed_composite_observer_isolated_delivery_and_diagnostics():
 good=DebugTelemetryRecorder(); observer=ChatTelemetryObserver(enabled=False,session_id=SECRET,provider=CompositeProvider([Mutator(),Broken(),good]))
 observer.emit('runtime_ready'); snap=observer.snapshot()
 assert snap.configured is False and snap.provider=='injected' and snap.state=='failed'
 assert snap.failure_count==1 and len(good.events)==1
 assert SECRET not in repr(snap) and SECRET not in repr(good.events)
 assert dict(snap.events[0].attributes)['outcome']=='succeeded'
 assert dict(snap.events[1].attributes)['reason']=='sink_failed'

@pytest.mark.parametrize('payload',[None,False,1,SECRET,[],{'enabled':None},{'provider':None},{SECRET:SECRET}])
def test_loader_section_failures_do_not_expose_content(tmp_path,payload):
 import yaml
 path=tmp_path/'synthetic.yaml'; path.write_text(yaml.safe_dump({'telemetry':payload}))
 with pytest.raises(FridayChatConfigError) as error: load_friday_py_config(path)
 assert SECRET not in str(error.value)

def test_all_public_mcp_event_names_remain_equivalent_and_invalid_fields_rejected():
 from typing import get_args
 from friday_telemetry.models.mcp import MCPEventName
 good=DebugTelemetryRecorder(); observer=ChatTelemetryObserver(enabled=True,session_id=SECRET,provider=good)
 for name in get_args(MCPEventName):
  data=MCPEvent(name=name,server_ref='a'*16,tool_ref='b'*16,reason='unknown',count=1,required=True).attributes()
  observer.capture_event('mcp.'+name,data)
  assert good.get_event('mcp.'+name)==data
  for field in ('prompt','response','reasoning','memory','arguments','results','schema','exception','path'):
   observer.capture_event('mcp.'+name,{**data,field:SECRET})
 snap=observer.snapshot(); assert snap.rejected_count==15*9; assert len(good.events)==15
 assert SECRET not in repr(snap) and SECRET not in repr(good.events)

@pytest.mark.asyncio
async def test_stop_observation_follows_every_cleanup_and_borrowed_provider_never_closes(monkeypatch):
 class Borrowed(DebugTelemetryRecorder):
  closed=False
  def close(self): self.closed=True
  def shutdown(self): self.closed=True
 good=Borrowed(); config=FridayChatConfig.model_validate({'telemetry':{'enabled':True},'session':{'flush_on_exit':True,'lifecycle_on_exit':True}})
 runtime=build_runtime(config,session_id=SECRET,telemetry=good); order=[]
 targets=[(runtime,'stop_mcp_tools','mcp'),(runtime.maintenance,'flush_pending_extraction','extraction'),(runtime.maintenance,'flush_memory','memory'),(runtime.maintenance,'run_lifecycle','lifecycle'),(runtime.transcript,'finalize','transcript'),(runtime.async_clients,'close','client')]
 for target,attr,label in targets:
  async def step(label=label):
   assert 'chat.application_stop' not in good.event_names
   order.append(label)
  monkeypatch.setattr(target,attr,step)
 result=await FridayChatApp(runtime=runtime,input_source=ListInputSource([]),output_sink=ListOutputSink()).run()
 assert result.exit_reason=='eof' and order==['mcp','extraction','memory','lifecycle','transcript','client']
 assert good.get_event('chat.application_stop')['outcome']=='succeeded' and not good.closed
 assert SECRET not in repr(runtime.telemetry.snapshot())

@pytest.mark.asyncio
async def test_cancel_then_failed_client_preserves_cancellation_and_shutdown_failure(monkeypatch):
 entered=asyncio.Event()
 class Waiting:
  async def read(self): entered.set(); await asyncio.Event().wait()
 runtime=build_runtime(FridayChatConfig.model_validate({'telemetry':{'enabled':True}}));
 async def broken_close(): raise RuntimeError(SECRET)
 monkeypatch.setattr(runtime.async_clients,'close',broken_close)
 task=asyncio.create_task(FridayChatApp(runtime=runtime,input_source=Waiting(),output_sink=ListOutputSink()).run())
 await entered.wait(); task.cancel()
 with pytest.raises(asyncio.CancelledError): await task
 stop=runtime.telemetry.snapshot().events[-1]
 assert dict(stop.attributes)['outcome']=='cancelled' and dict(stop.attributes)['reason']=='shutdown_failed'
 assert SECRET not in repr(runtime.telemetry.snapshot())

def test_composite_partial_start_rollback_attempts_every_open_child():
 class StartBad(DebugTelemetryRecorder):
  def start_span(self,name,parent_id=None): raise RuntimeError(SECRET)
 class EndBad(DebugTelemetryRecorder):
  ends=0
  def end_span(self,span_id,data=None): self.ends+=1; raise RuntimeError(SECRET)
 first,last=DebugTelemetryRecorder(),DebugTelemetryRecorder(); endbad=EndBad(); composite=CompositeProvider([first,StartBad(),endbad,last])
 with pytest.raises(CompositeDeliveryError) as error: composite.start_span('synthetic')
 assert error.value.failure_count==2 and endbad.ends==1
 assert first.get_span_by_name('synthetic').end_time and last.get_span_by_name('synthetic').end_time
 assert SECRET not in str(error.value)

def test_membership_replacement_cannot_overwrite_preexisting_child_ownership():
 class LocalIDs(DebugTelemetryRecorder):
  def __init__(self): super().__init__(); self.next_id=0; self.ends=[]; self.parents=[]
  def start_span(self,name,parent_id=None):
   value=f'span-{self.next_id}'; self.next_id+=1; self.parents.append((value,parent_id)); return value
  def end_span(self,span_id,data=None): self.ends.append(span_id)
 old,new=LocalIDs(),LocalIDs(); composite=CompositeProvider([old])
 original=composite.start_span('old-parent')
 composite.remove_provider(old); composite.add_provider(new)
 try: replacement=composite.start_span('new-parent')
 except CompositeDeliveryError:
  composite.end_span(original)
  assert old.ends==['span-0'] and new.ends==['span-0']
 else:
  composite.end_span(original); composite.end_span(replacement)
  assert old.ends==['span-0'], 'Removing a provider stranded its previously open span'
  assert new.ends==['span-0']
