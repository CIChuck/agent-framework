from run_checks import env,root,out
import sys,subprocess,json,pathlib
name=sys.argv[1]; check_env=env.copy(); check_root=root
if name=='baseline':
 check_root=out/'base'; check_env['PYTHONPATH']=':'.join(map(str,sorted(check_root.glob('packages/*/src')))); check_env['PYTHONPYCACHEPREFIX']=str(out/'base-pycache')
if name=='controlled':
 check_env['TERM']='xterm-256color'; check_env.pop('NO_COLOR',None)
paths=['packages/friday-chat/tests_chat','packages/friday-telemetry/tests_telemetry']
if name=='loopback': paths=['packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_chat_adapter_controls_reach_final_http_json','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_chat_adapter_typed_stream_reuses_generation_defaults','packages/friday-chat/tests_chat/test_llm_adapter_migration.py::test_provider_option_target_mismatch_fails_before_http']
cmd=['uv','run','--no-sync','pytest','-p','no:cacheprovider',*paths]
with (out/(name+'.log')).open('w') as f: p=subprocess.run(cmd,cwd=check_root,env=check_env,stdout=f,stderr=subprocess.STDOUT)
r={'name':name,'command':cmd,'exit_code':p.returncode,'cwd':str(check_root),'TERM':check_env.get('TERM'),'NO_COLOR_present':'NO_COLOR' in check_env}
(out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n'); print(json.dumps(r)); print((out/(name+'.log')).read_text()[-4500:])
