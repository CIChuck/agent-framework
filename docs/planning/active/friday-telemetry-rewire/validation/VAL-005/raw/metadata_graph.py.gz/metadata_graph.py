exec(open('/private/tmp/telem-01/REM-003/validation-corrected/review.py').read().split("if sys.argv[1]=='prepare':")[0])
paths=['pyproject.toml']+[str(p.relative_to(R)) for p in sorted((R/'packages').glob('*/pyproject.toml'))]+['tests/lab/pyproject.toml']; rows=[]
for p in paths:
 a=tomllib.loads(subprocess.check_output(['git','-C',str(R),'show','09fe690:'+p]).decode()); b=tomllib.loads((R/p).read_text());s=SpecifierSet(b['project']['requires-python']); rows.append(dict(path=p,requires=b['project']['requires-python'],rejected={v:v not in s for v in ['3.10','3.11','3.12','3.13.0','3.13.1','3.13.2','3.13.3']},accepted={v:v in s for v in ['3.13.4','3.13.10','3.14.0']},dependencies_unchanged=all(a.get('project',{}).get(k)==b.get('project',{}).get(k) for k in ['dependencies','optional-dependencies']),build_unchanged=a.get('build-system')==b.get('build-system'),groups_unchanged=a.get('dependency-groups')==b.get('dependency-groups')))
save('metadata',rows)
old=tomllib.loads(subprocess.check_output(['git','-C',str(R),'show','09fe690:uv.lock']).decode());new=tomllib.loads((R/'uv.lock').read_text())
(O/'baseline.lock').write_text(subprocess.check_output(['git','-C',str(R),'show','09fe690:uv.lock']).decode())
def key(p):return p['name'],p.get('version'),json.dumps(p['source'],sort_keys=True)
def active(p,e):return not p.get('resolution-markers') or any(Marker(m).evaluate(e) for m in p['resolution-markers'])
def reach(lock,e,mode):
 idx={};
 for p in lock['package']:
  if active(p,e):idx.setdefault(p['name'],[]).append(p)
 roots=[p for p in lock['package'] if 'editable' in p['source'] or 'virtual' in p['source']];queue=[(p,tuple(p.get('optional-dependencies',{})) if mode=='all' else ()) for p in roots]; seen=set(); edges=set();errs=[]
 while queue:
  p,extras=queue.pop();state=(key(p),extras)
  if state in seen:continue
  seen.add(state)
  deps=list(p.get('dependencies',[]))
  for x in extras:deps+=p.get('optional-dependencies',{}).get(x,[])
  if mode=='all':
   for ds in p.get('dev-dependencies',{}).values():deps+=ds
  for d in deps:
   if d.get('marker') and not any(Marker(d['marker']).evaluate(dict(e,extra=x)) for x in ('',)+extras):continue
   matches=[q for q in idx.get(d['name'],[]) if (not d.get('version') or q['version']==d['version']) and (not d.get('source') or q['source']==d['source'])]
   if len(matches)!=1:errs.append(dict(parent=key(p),dependency=d,matches=[key(q) for q in matches]));continue
   q=matches[0];edges.add((key(p),key(q),tuple(d.get('extras',[]))));queue.append((q,tuple(d.get('extras',[]))))
 return set(s[0] for s in seen),edges,errs
contexts=[]
platforms=[('linux','posix','Linux',m) for m in ['x86_64','aarch64','armv7l','i686','ppc64le','s390x']]+[('darwin','posix','Darwin',m) for m in ['arm64','x86_64']]+[('win32','nt','Windows',m) for m in ['AMD64','x86','ARM64']]
for v,(plat,on,system,m),mode in itertools.product(['3.13.4','3.13.10','3.13.99','3.14.0','3.14.10','3.14.99','3.15.0'],platforms,['default','all']):
 e=default_environment();e.update(python_version='.'.join(v.split('.')[:2]),python_full_version=v,implementation_version=v,sys_platform=plat,os_name=on,platform_system=system,platform_machine=m,implementation_name='cpython',platform_python_implementation='CPython');a,ae,err1=reach(old,e,mode);b,be,err2=reach(new,e,mode)
 contexts.append(dict(version=v,platform=plat,machine=m,mode=mode,old_reachable=len(a),new_reachable=len(b),removed=sorted(a-b),added=sorted(b-a),removed_edges=sorted(ae-be),added_edges=sorted(be-ae),errors=err1+err2,grpcio=sorted(k[1] for k in b if k[0]=='grpcio')))
old_idx={key(p):p for p in old['package']};artifact_drift=[];new_packages=[];removed_artifacts=0;retained=0
for p in new['package']:
 k=key(p)
 if k not in old_idx:new_packages.append(k);continue
 a=old_idx[k];arts={x['url']:x for x in a.get('wheels',[])}
 if a.get('sdist'):arts[a['sdist']['url']]=a['sdist']
 bb=p.get('wheels',[])+([p['sdist']] if p.get('sdist') else [])
 retained+=len(bb);removed_artifacts+=len(arts)-len(bb)
 for x in bb:
  if x['url'] not in arts or x!=arts[x['url']]:artifact_drift.append(dict(package=k,artifact=x))
save('lock-graph',dict(contexts=contexts,context_count=len(contexts),all_selections_edges_preserved=all(not x['removed'] and not x['added'] and not x['errors'] and not x['removed_edges'] and not x['added_edges'] for x in contexts),new_package_keys=new_packages,artifact_drift=artifact_drift,retained_artifacts=retained,removed_artifacts=removed_artifacts,manifest_unchanged=old['manifest']==new['manifest'],litellm=[p['version'] for p in new['package'] if p['name']=='litellm']))
print('metadata projects',len(rows));print('contexts',len(contexts),'drifting',len([c for c in contexts if c['removed'] or c['added'] or c['errors'] or c['removed_edges'] or c['added_edges']]));print('artifacts',retained,'drift',len(artifact_drift),'new packages',new_packages)
