import json,pathlib,collections,re,hashlib,subprocess
O=pathlib.Path('/private/tmp/telem-01/REM-003/validation-corrected');D=O.parent
base=json.loads((D/'baseline-root-ruff.log').read_text());cand=json.loads((O/'root-ruff.log').read_text())
def norm(row,root):return (row['filename'].removeprefix(str(root)+'/'),row['code'],row['location']['row'],row['location']['column'],row['message'])
a=set(norm(r,D/'baseline-checkout') for r in base);b=set(norm(r,D/'corrected-checkout') for r in cand)
ruff=dict(baseline_count=len(base),candidate_count=len(cand),baseline_rules=dict(collections.Counter(r['code'] for r in base)),candidate_rules=dict(collections.Counter(r['code'] for r in cand)),introduced=sorted(b-a),removed=sorted(a-b))
(O/'ruff-comparison.json').write_text(json.dumps(ruff,indent=2));print('Ruff',len(base),len(cand),'introduced',len(b-a),'removed',len(a-b))
if (O/'root.json').exists():
 rows=[]
 for n in ['focused','packages','root']:
  a=(D/('baseline-'+n+'.log')).read_text();b=(O/(n+'.log')).read_text()
  def ids(s):return sorted(re.findall(r'^(?:FAILED|ERROR) (\S+)',s,re.M))
  def totals(s):return re.findall(r'^=+ .*\b(?:passed|failed|collected)\b.* =+$',s,re.M)
  rows.append(dict(check=n,baseline_ids=ids(a),candidate_ids=ids(b),identical_failures=ids(a)==ids(b),baseline_summary=totals(a),candidate_summary=totals(b)))
 (O/'pytest-comparison.json').write_text(json.dumps(rows,indent=2));print(rows)
