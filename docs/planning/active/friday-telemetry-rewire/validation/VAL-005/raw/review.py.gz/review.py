import pathlib, json, hashlib, subprocess, os, sys, time, tomllib, ast, re, itertools
from packaging.specifiers import SpecifierSet
from packaging.markers import Marker, default_environment
R=pathlib.Path('/private/tmp/telem-01/REM-003/corrected-checkout'); O=pathlib.Path('/private/tmp/telem-01/REM-003/validation-corrected'); P=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework'); PY=P/'.venv/bin/python'; UV='/opt/homebrew/bin/uv'; G=pathlib.Path('/private/tmp/telem-01/REM-001/network-guard'); B=pathlib.Path('/private/tmp/telem-01/REM-003/baseline-checkout')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v): (O/(n+'.json')).write_text(json.dumps(v,indent=2))
def tracked(root):
 paths=subprocess.check_output(['git','-C',str(root),'ls-files','-z']).decode().split('\0')
 return {p:sha(root/p) if (root/p).is_file() else None for p in paths if p}
def env(n):
 t=O/'tmp'/n;t.mkdir(parents=True,exist_ok=True)
 return dict(PATH=f'{P}/.venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',UV_PROJECT_ENVIRONMENT=str(P/'.venv'),UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_NO_SYNC='true',UV_OFFLINE='true',LITELLM_LOCAL_MODEL_COST_MAP='true',ANONYMIZED_TELEMETRY='False',TERM='xterm-256color',PYTHONPATH=os.pathsep.join([str(G)]+[str(p) for p in sorted((R/'packages').glob('*/src'))]+[str(R/'packages/friday-chat/tests_chat'),str(R)]),TMPDIR=str(t),PYTHONDONTWRITEBYTECODE='1',RUFF_CACHE_DIR=str(t/'ruff'),MYPY_CACHE_DIR=str(t/'mypy'),PYTEST_ADDOPTS=f'-o cache_dir={t}/pytest')
def run(n,args):
 e=env(n); t=time.time();log=O/(n+'.log')
 with log.open('w') as f:r=subprocess.run([str(a) for a in args],cwd=R,env=e,stdout=f,stderr=subprocess.STDOUT)
 save(n,dict(command=[str(a) for a in args],cwd=str(R),revision=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip(),environment=e,exit_code=r.returncode,seconds=time.time()-t,log_sha256=sha(log)));print(n,r.returncode,flush=True)
S=[p for p in subprocess.check_output(['git','-C',str(R),'diff','--name-only','2155a0f','HEAD','--','*.py']).decode().splitlines() if '/src/' in p]
C=S+[p for p in subprocess.check_output(['git','-C',str(R),'diff','--name-only','2155a0f','HEAD','--','*.py']).decode().splitlines() if '/tests_' in p]
T=['packages/friday-chat/tests_chat/'+p for p in ['test_telemetry.py','test_cli.py','test_runtime.py','test_app_lifecycle.py','compat/test_config_compatibility.py']]+['packages/friday-telemetry/tests_telemetry/test_providers.py']
A=['--import-mode=importlib','--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py']
if sys.argv[1]=='prepare':
 save('tracked-before',tracked(R));save('original-tracked-before',tracked(P))
 q=json.loads(pathlib.Path('/private/tmp/telem-01/REM-003/corrected-validation-request.json').read_text()); h={p['path']:sha(R/p['path'])==p['sha256'] for p in q['authority']};h['manifest']=sha(R/q['manifest_path'])==q['manifest_sha256'];save('authority-check',h)
 files=list((R/'packages').glob('*/tests_*/**/*.py'))+list((R/'experiments').glob('*/tests/**/*.py'))+list((R/'packages').glob('*/src/**/*.py')); prior=pathlib.Path('/private/tmp/telem-01/VAL-003-review');bad=[str(p.relative_to(R)) for p in files if not (prior/p.relative_to(R)).is_file() or sha(p)!=sha(prior/p.relative_to(R))]
 save('preflight',dict(files={str(p.relative_to(R)):sha(p) for p in files},unchanged_prior_inventory=not bad,differences=bad,guard_sha256=sha(G/'sitecustomize.py'),credential_live_flags_absent=True,original_state_absent=not any((R/p).exists() for p in ['.env','.friday','chroma_db']),review_notes='Independently inspected discovery, sensitive test lines, conftests, synthetic stdio peers, fake experiment LLM, respx Web mocks, fixture loopback HTTP, isolated/temporary writes, PTY child inherited allowlist/guard. Exactly two live-module root ignores; package live flags absent. No fixture deadlines or tests changed.'))
 for lane in ['active','queued','review','blocked','deferred','backlog']:(R/'docs/planning'/lane).mkdir(exist_ok=True)
 # Tracked ignored audit fixture is synthetic and present in baseline if needed.
 base_logs={}
 for n in ['root','root-collect','root-ruff','packages','focused','mypy313','syntax313','smoke','changed-ruff','board','docs-isolated-git']:
  p=B.parent/('baseline-'+n+'.json');d=json.loads(p.read_text());base_logs[n]=dict(command=d['command'],exit_code=d['exit_code'],log_integrity=sha(B.parent/('baseline-'+n+'.log'))==d['log_sha256'],environment=d['environment'])
 save('baseline-raw-inputs',base_logs);save('expanded-files',dict(sources=S,changed=C,focused=T,root_args=A));print('prepared',len(files),bad,h,flush=True)
elif sys.argv[1]=='static':
 run('versions',[PY,'-c','import sys,importlib.metadata as m;print(sys.version);print({k:m.version(k) for k in ["ruff","mypy","pytest","litellm"]})'])
 run('lock',[UV,'lock','--offline','--check','--no-python-downloads','--no-build'])
 run('root-ruff',[UV,'run','--no-sync','ruff','check','.','--output-format','json'])
 run('changed-ruff',[UV,'run','--no-sync','ruff','check',*C])
 run('mypy313',[UV,'run','--no-sync','mypy','--python-version','3.13',*S])
 run('syntax313',[PY,'-c','import ast,pathlib,sys;[ast.parse(pathlib.Path(p).read_text(),filename=p,feature_version=(3,13)) for p in sys.argv[1:]];print("Python 3.13 syntax passed")',*S])
 run('board',[PY,'scripts/friday-dev-board.py','validate']);run('docs',[PY,'scripts/check-documentation-lifecycle.py']);run('diff-check',['git','diff','--check','09fe690','HEAD']);run('aggregate-diff-check',['git','diff','--check','2155a0f','HEAD'])
elif sys.argv[1]=='suites':
 run('focused',[UV,'run','--no-sync','pytest',*T]);run('packages',[UV,'run','--no-sync','pytest','packages/friday-chat/tests_chat','packages/friday-telemetry/tests_telemetry']);run('root-collect',[UV,'run','--no-sync','pytest',*A,'--collect-only']);run('root',[UV,'run','--no-sync','pytest',*A])
elif sys.argv[1]=='finish':
 save('tracked-after',tracked(R));save('original-tracked-after',tracked(P))
 for key in ['tracked','original-tracked']:
  a=json.loads((O/(key+'-before.json')).read_text());b=json.loads((O/(key+'-after.json')).read_text());save(key+'-comparison',dict(unchanged=a==b,differences=[p for p in a.keys()|b.keys() if a.get(p)!=b.get(p)]))
