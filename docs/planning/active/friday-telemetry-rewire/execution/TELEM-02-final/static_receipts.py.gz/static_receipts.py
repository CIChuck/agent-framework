"""Verify approved root lint identity and immutable configuration/source metadata."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import sys
import tomllib

OUT = Path('/private/tmp/telem-02/builder-execution')
ROOT = OUT / sys.argv[1]
sha = lambda data: hashlib.sha256(data).hexdigest()
scope = json.loads((ROOT/'docs/planning/active/friday-telemetry-rewire/validation/WVR-004-telem02-lint-scope.json').read_text())
raw = json.loads((OUT/'final-root-ruff-json.log').read_text())
def normalized(d):
    return dict(path=str(Path(d['filename']).relative_to(ROOT)), code=d['code'],
                location=d['location'], end_location=d['end_location'], message=d['message'])
actual = [normalized(d) for d in raw]
ordered = lambda ds: sorted(json.dumps(d, sort_keys=True) for d in ds)
assert len(actual) == 327 and ordered(actual) == ordered(scope['diagnostics'])
hashes = {}
for path, expected in scope['archived_files'].items() | scope['lint_configurations'].items():
    value = sha((ROOT/path).read_bytes())
    assert value == expected
    hashes[path] = value
registry = ROOT/'packages/friday-cli/src/friday_cli/commands.py'
assert sha(registry.read_bytes()) == scope['command_registry_source_sha256']
cls = next(n for n in ast.parse(registry.read_text()).body if isinstance(n, ast.ClassDef) and n.name == 'CommandRegistry')
assert sha(ast.dump(cls, include_attributes=False).encode()) == scope['command_registry_class_ast_sha256']
assert scope['ruff_version'] == '0.14.10' and scope['target'] == 'py313'
root_config = tomllib.loads((ROOT/'pyproject.toml').read_text())
assert root_config['tool']['ruff']['target-version'] == 'py313'
lint_record = dict(raw_exit=1, exact_327_identities=True, disposition='WVR-004 exact approved temporary debt; raw root Ruff is not PASS', diagnostic_count=327, configuration_hash_count=len(scope['lint_configurations']), archive_hash_count=len(scope['archived_files']), hashes=hashes, registry_source_sha256=sha(registry.read_bytes()), registry_ast_sha256=sha(ast.dump(cls, include_attributes=False).encode()), tool_version='0.14.10', target='py313')
(OUT/'final-root-lint-disposition.json').write_text(json.dumps(lint_record,indent=2)+'\n')
base = Path('/private/tmp/telem-02/builder-baseline/preparation-base')
snapshot = json.loads((OUT/(ROOT.name+'-snapshot.json')).read_text())
projects = [ROOT/p for p in sorted(snapshot['tracked_hashes']) if Path(p).name == 'pyproject.toml']
floors = {str(p.relative_to(ROOT)):tomllib.loads(p.read_text()).get('project',{}).get('requires-python') for p in projects}
assert len(floors) == 18 and all(v == '>=3.13.4' for v in floors.values())
metadata = {str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in projects+[ROOT/'uv.lock']}
assert all(sha((base/p).read_bytes()) == h for p,h in metadata.items())
spec = importlib.util.spec_from_file_location('baseline_prepare', '/private/tmp/telem-02/builder-baseline/prepare.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
current = helper.metadata_baseline()
prior = json.loads(Path('/private/tmp/telem-02/builder-baseline/tooling-and-sdk-source.json').read_text())
assert current == prior
authority = json.loads((ROOT/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-02.yaml').read_text())
pins = [dict(path=p['path'],matches=sha((ROOT/p['path']).read_bytes()) == p['sha256'],sha256=p['sha256']) for p in authority['authority']]
assert len(pins) == 19 and all(p['matches'] for p in pins)
record = dict(all_18_python_floors=floors, dependency_metadata_and_lock_hashes=metadata, unchanged_from_preparation_base=True, installed_tool_dependency_sdk_source_metadata_unchanged=True, current_installed_metadata=current, authority_pins=pins, current_authority_manifest_sha256=sha((ROOT/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-02.yaml').read_bytes()))
(OUT/'final-metadata-authority-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print('Exact raw327WVR004 matched;17lintconfigs/4archives/registrysource+AST;18floors/lock/dependencyhashes;19authoritypins andinstalledSDKsource/toolmetadata unchanged')
