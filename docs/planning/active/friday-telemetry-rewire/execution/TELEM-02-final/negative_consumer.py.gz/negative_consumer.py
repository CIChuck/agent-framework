"""Two intended public boundary errors: borrowed providers need no lifecycle."""
from friday_telemetry import TelemetryInterface, TelemetryLifecycle

def borrowed(provider: TelemetryInterface) -> None:
    provider.flush()
    lifecycle: TelemetryLifecycle = provider
