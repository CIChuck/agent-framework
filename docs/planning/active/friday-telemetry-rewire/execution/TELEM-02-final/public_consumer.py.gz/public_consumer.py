"""Positive public consumer: borrowed adapters need no lifecycle extension."""
from typing import Any, assert_type
from friday_telemetry import (
    TelemetryInterface, TelemetryFactoryConfig, create_telemetry,
    OpenTelemetryProvider, TelemetryLifecycle, LifecycleResult,
)

class Borrowed(TelemetryInterface):
    def capture_event(self, event_name: str, data: dict[str, Any]) -> None:
        pass
    def start_span(self, name: str, parent_id: str | None = None) -> str:
        return 'synthetic'
    def end_span(self, span_id: str, data: dict[str, Any] | None = None) -> None:
        pass

def consumer(provider: TelemetryInterface) -> str:
    return provider.start_span('synthetic')

borrowed: TelemetryInterface = Borrowed()
handle = create_telemetry(TelemetryFactoryConfig())
assert_type(handle.telemetry, TelemetryInterface)
assert_type(handle.shutdown(), LifecycleResult)
owned: TelemetryLifecycle = OpenTelemetryProvider('synthetic')
consumer(borrowed)
