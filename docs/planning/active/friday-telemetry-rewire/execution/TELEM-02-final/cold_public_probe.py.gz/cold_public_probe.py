"""Fresh-process default/debug/API consumer probe with optional imports forbidden."""
import builtins
import inspect
import json
import sys
import threading
from pathlib import Path

original_import = builtins.__import__
before = set(threading.enumerate())

def no_optional(name, *args, **kwargs):
    if name.startswith(('opentelemetry', 'grpc')):
        raise RuntimeError('forbidden_optional_dependency_import')
    return original_import(name, *args, **kwargs)

builtins.__import__ = no_optional
try:
    import friday_telemetry as public
    from friday_telemetry.providers import otel

    with public.create_telemetry() as disabled:
        assert isinstance(disabled.telemetry, public.TelemetryInterface)
        parent = disabled.telemetry.start_span('synthetic.root')
        child = disabled.telemetry.start_span('synthetic.child', parent)
        disabled.telemetry.capture_event('synthetic.event', {'count': 1})
        disabled.telemetry.end_span(child)
        disabled.telemetry.end_span(parent)
        assert not disabled.snapshot().available
    with public.create_telemetry(public.TelemetryFactoryConfig(provider='debug')) as debug:
        debug.telemetry.capture_event('synthetic', {'count': 1})
        assert debug.flush().status == 'success'
    assert public.TelemetryInterface.__abstractmethods__ == {'capture_event','start_span','end_span'}
    signature = inspect.signature(public.OpenTelemetryProvider)
    assert list(signature.parameters) == ['service_name','endpoint']
    assert signature.parameters['endpoint'].default is None
    assert set(threading.enumerate()) == before
    assert not any(m.startswith(('opentelemetry','grpc')) for m in sys.modules)
    root = Path.cwd()
    assert Path(public.__file__).is_relative_to(root)
    assert Path(otel.__file__).is_relative_to(root)
    print(json.dumps(dict(cold_import_disabled_debug_no_optional_modules=True,
                          threads_unchanged=True, abstract_methods=sorted(public.TelemetryInterface.__abstractmethods__),
                          constructor=str(signature), public_source=public.__file__, adapter_source=otel.__file__,
                          public_export_count=len(public.__all__))))
finally:
    builtins.__import__ = original_import
