"""Intended two assignment errors; verify invariant public registry is preserved."""
from friday_cli.commands import CommandRegistry

class Parent:
    pass

class Child(Parent):
    pass

def invariant(parent: CommandRegistry[Parent], child: CommandRegistry[Child]) -> None:
    parent = child
    child = parent
