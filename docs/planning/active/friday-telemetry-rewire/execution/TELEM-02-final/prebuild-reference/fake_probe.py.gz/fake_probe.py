"""Retrospective old-source probe. Every OTel dependency is an in-memory fake."""
from pathlib import Path
import builtins
import importlib.util
import inspect
import json
import sys
import threading
import types
from unittest.mock import patch

root = Path(sys.argv[1])
prefix = root / 'packages/friday-telemetry/src/friday_telemetry'
before_threads = tuple(threading.enumerate())
before_sdk = sorted(m for m in sys.modules if m.startswith(('opentelemetry', 'grpc')))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

class Span:
    def __init__(self, name):
        self.name = name
        self.events = []
        self.attributes = {}
        self.ended = False
    def is_recording(self):
        return not self.ended
    def add_event(self, name, attributes):
        self.events.append((name, attributes))
    def set_attribute(self, key, value):
        self.attributes[key] = value
    def end(self):
        self.ended = True

def scenario(block_exporter=False, block_sdk=False):
    calls = dict(resource_create=[], providers=[], processors=[], global_registration=[], tracer_starts=[], console_constructions=0)
    class Tracer:
        def start_span(self, *args, **kwargs):
            calls['tracer_starts'].append(dict(args=list(args), kwargs=kwargs))
            return Span(args[0])
    class Resource:
        @classmethod
        def create(cls, attributes):
            calls['resource_create'].append(attributes)
            return dict(attributes)
    class Provider:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            calls['providers'].append(self)
        def add_span_processor(self, processor):
            calls['processors'].append(processor)
    class Processor:
        def __init__(self, exporter):
            self.exporter = exporter
    class Console:
        def __init__(self):
            calls['console_constructions'] += 1
    class Exporter:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
    modules = {name: types.ModuleType(name) for name in ['friday_telemetry', 'opentelemetry', 'opentelemetry.trace', 'opentelemetry.sdk', 'opentelemetry.sdk.resources', 'opentelemetry.sdk.trace', 'opentelemetry.sdk.trace.export', 'opentelemetry.exporter', 'opentelemetry.exporter.otlp', 'opentelemetry.exporter.otlp.proto', 'opentelemetry.exporter.otlp.proto.grpc', 'opentelemetry.exporter.otlp.proto.grpc.trace_exporter']}
    for module in modules.values():
        module.__path__ = []
    trace = modules['opentelemetry.trace']
    tracer = Tracer()
    current = [None]
    trace.set_tracer_provider = lambda provider: calls['global_registration'].append(provider)
    trace.get_tracer = lambda name: tracer
    trace.get_current_span = lambda: current[0]
    modules['opentelemetry'].trace = trace
    modules['opentelemetry.sdk.resources'].Resource = Resource
    modules['opentelemetry.sdk.trace'].TracerProvider = Provider
    modules['opentelemetry.sdk.trace.export'].BatchSpanProcessor = Processor
    modules['opentelemetry.sdk.trace.export'].ConsoleSpanExporter = Console
    modules['opentelemetry.exporter.otlp.proto.grpc.trace_exporter'].OTLPSpanExporter = Exporter
    original_import = builtins.__import__
    def scoped_import(name, *args, **kwargs):
        if (block_sdk and name.startswith('opentelemetry')) or (block_exporter and name == 'opentelemetry.exporter.otlp.proto.grpc.trace_exporter'):
            raise ImportError('synthetic unavailable dependency')
        return original_import(name, *args, **kwargs)
    with patch.dict(sys.modules, modules), patch('builtins.__import__', scoped_import):
        interface = load('friday_telemetry.interface', prefix / 'interface.py')
        adapter = load('baseline_old_otel', prefix / 'providers/otel.py')
        provider = adapter.OpenTelemetryProvider('synthetic-baseline', 'http://127.0.0.1:4317' if block_exporter else None)
        if block_sdk:
            span_id = provider.start_span('noop')
            provider.capture_event('noop.event', {'safe': 1})
            provider.end_span(span_id)
            result = dict(uninitialized_noop=not provider._initialized, opaque_id_type=type(span_id).__name__, active_spans=len(provider._active_spans))
        elif block_exporter:
            result = dict(requested_otlp_fell_back_to_console=calls['console_constructions'] == 1, global_registration_calls=len(calls['global_registration']))
        else:
            provider.capture_event('standalone.event', {'count': 1})
            standalone_lost = not calls['tracer_starts']
            parent_id = provider.start_span('parent')
            child_id = provider.start_span('child', parent_id=parent_id)
            child = provider._active_spans[child_id]
            provider.capture_event('current.logical.event', {'count': 1})
            logical_lost = not child.events
            ambient = Span('synthetic.foreign.ambient')
            current[0] = ambient
            class Marker:
                def __str__(self):
                    return 'SYNTHETIC_OBJECT'
            data = {'boolean': True, 'integer': 7, 'float': 1.5, 'nested': {'synthetic': 1}, 'object': Marker()}
            provider.capture_event('foreign.ambient.event', data)
            provider.end_span(child_id, data)
            provider.end_span(parent_id)
            result = dict(explicit_parent_ignored=calls['tracer_starts'][1]['kwargs'] == {}, omitted_parent_uses_no_explicit_context=calls['tracer_starts'][0]['kwargs'] == {}, standalone_event_lost=standalone_lost, logical_current_event_lost=logical_lost, event_routed_to_foreign_ambient=ambient.events[0][0] == 'foreign.ambient.event', event_value_types={k: type(v).__name__ for k, v in ambient.events[0][1].items()}, end_value_types={k: type(v).__name__ for k, v in child.attributes.items()}, unsupported_object_stringified=child.attributes['object'] == 'SYNTHETIC_OBJECT', nested_container_stringified=isinstance(child.attributes['nested'], str), global_registration_calls=len(calls['global_registration']), resource_create_calls=calls['resource_create'], sdk_shutdown_on_exit_not_supplied='shutdown_on_exit' not in calls['providers'][0].kwargs, provider_has_no_shutdown=not hasattr(provider, 'shutdown'), provider_does_not_retain_owned_sdk_provider=not any(value is calls['providers'][0] for value in vars(provider).values()), provider_does_not_retain_owned_processor=not any(value is calls['processors'][0] for value in vars(provider).values()), active_spans_after_end=len(provider._active_spans), constructor_signature=str(inspect.signature(adapter.OpenTelemetryProvider)), interface_abstract_methods=sorted(interface.TelemetryInterface.__abstractmethods__), imported_source=adapter.__file__)
    return result

output = dict(normal=scenario(), missing_exporter=scenario(block_exporter=True), missing_sdk=scenario(block_sdk=True), safe_effects=dict(real_sdk_imports_before=before_sdk, real_sdk_imports_after=sorted(m for m in sys.modules if m.startswith(('opentelemetry', 'grpc'))), threads_unchanged=tuple(threading.enumerate()) == before_threads, fake_global_registration_only=True, no_environment_writes=True, no_real_sdk_thread_channel_listener_or_provider=True, pytest_executed=False))
assert output['normal']['explicit_parent_ignored']
assert output['normal']['standalone_event_lost']
assert output['normal']['logical_current_event_lost']
assert output['normal']['global_registration_calls'] == 1
assert output['normal']['unsupported_object_stringified']
assert output['normal']['provider_has_no_shutdown']
assert output['missing_exporter']['requested_otlp_fell_back_to_console']
assert output['missing_sdk']['uninitialized_noop']
assert output['safe_effects']['threads_unchanged']
assert not output['safe_effects']['real_sdk_imports_after']
print(json.dumps(output, indent=2))
