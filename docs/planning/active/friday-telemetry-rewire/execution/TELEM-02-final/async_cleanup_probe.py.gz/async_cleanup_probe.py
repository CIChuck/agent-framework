"""Actual console SDK async/provider lifecycle probe; no native channel/listener."""
import asyncio
import io
import json
import sys
import threading
from friday_telemetry import CompositeProvider, TelemetryFactoryConfig, create_telemetry

initial_threads = set(threading.enumerate())
original_stdout = sys.stdout
stream = io.StringIO()
sys.stdout = stream

async def probe():
    initial_tasks = set(asyncio.all_tasks())
    settings = TelemetryFactoryConfig(provider='otel')
    with create_telemetry(settings) as first, create_telemetry(settings) as second:
        composite = CompositeProvider([first.telemetry, second.telemetry])
        parent = composite.start_span('synthetic.root')
        async def child(name):
            span = composite.start_span(name, parent)
            await asyncio.sleep(0)
            composite.capture_event('synthetic.event', {'count': 1})
            composite.end_span(span, {'complete': True})
        await asyncio.gather(child('synthetic.one'), child('synthetic.two'))
        assert set(asyncio.all_tasks()) == initial_tasks
        composite.end_span(parent)
        assert first.flush().status == second.flush().status == 'success'
    assert not first.snapshot().worker_alive and not second.snapshot().worker_alive
    assert set(asyncio.all_tasks()) == initial_tasks
    return dict(no_new_pending_tasks=True, both_provider_workers_reaped=True,
                first_exported=first.snapshot().exported_spans,
                second_exported=second.snapshot().exported_spans,
                no_native_channel_or_listener_created=True)

try:
    result = asyncio.run(probe())
    assert set(threading.enumerate()) == initial_threads
    assert not stream.closed
    result['all_threads_restored'] = True
finally:
    sys.stdout = original_stdout
print(json.dumps(result))
