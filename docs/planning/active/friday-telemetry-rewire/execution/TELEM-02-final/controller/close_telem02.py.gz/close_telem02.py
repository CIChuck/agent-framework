from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();pkt=root/'docs/planning/active/friday-telemetry-rewire';o=Path('/private/tmp/telem-02');sha=lambda b:hashlib.sha256(b).hexdigest();e=json.loads((pkt/'validation/VAL-007/evidence.json').read_text());candidate='45f3114173a7e9ada128c7950fe1f7e63cb2ff28';assert e['outcome']=='VERIFIED' and e['candidate']==candidate and not e['findings'];m=pkt/'authority-manifest-TELEM-02.yaml';assert sha(m.read_bytes())==e['authority_manifest_sha256'];assert all(sha((root/x['path']).read_bytes())==x['sha256'] for x in json.loads(m.read_text())['authority']);assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==candidate
oldgate='TELEM-02 implementation and mandatory delta plus aggregate product validation';newgate='maintainer acceptance of VERIFIED TELEM-02; then TELEM-03 directive preparation'
summary='''Current TELEM-02 result: fresh independent [VAL-007](validation/VAL-007/report.md)
returns **VERIFIED** for product candidate `45f3114`, reviewing the full CD-002 unit
and complete `2155a0f` aggregate. The [builder closeout](execution/TELEM-02-final/report.md)
preserves separate construction evidence and exact source/command receipts.
Root2,891, Chat+Telemetry828 and owning-tree2,873 tests pass; unchanged optional/live
skips remain explicit. Changed-unit/aggregate lint and typing pass. Raw root Ruff
exits1 with exactly327 approved WVR-004 identities; raw root lint does not pass.

Approved [A02](directives/CD-002-A02-native-retry-disable.md) was released after
fresh [CDR-017](validation/CDR-017/report.md) READY, before fixed native retries0
implementation and the two already approved collector nodes. No product finding
remains. TELEM-02 is ready for maintainer acceptance, which is not recorded here.
The initiative remains started for later units; delivery remains local. After
acceptance, the next planning gate is TELEM-03's safe LLM metrics and role-service
injection construction directive. Its implementation requires separate authority.

'''
r=pkt/'README.md';s=r.read_text();assert s.count('next_gate: '+oldgate)==1;s=s.replace('next_gate: '+oldgate,'next_gate: '+newgate,1).replace('execution_phase: implementation','execution_phase: closeout',1).replace('validation_state: pending','validation_state: verified',1).replace('Current TELEM-01 result:','Accepted TELEM-01 historical result:',1)
needle='Accepted TELEM-01 historical result:';assert s.count(needle)==1;s=s.replace(needle,summary+needle,1).replace('initiative remains started for TELEM-02 through TELEM-05; next is the TELEM-02\ndirective decision and scoped lint-policy follow-ups. Delivery remains local.','initiative remains started for the remaining separately governed units.\nDelivery remains local.');r.write_text(s)
l=pkt/'execution-log.md';l.write_text(l.read_text()+'''\n## 2026-10-06 — TELEM-02 independent VERIFIED; acceptance pending

Separate builder committed exact13 product paths at45f3114173a7e9ada128c7950fe1f7e63cb2ff28;
seven source/five test files plus README. Builder receipts are frozen separately
from fresh independent VAL-007, which returns VERIFIED with no numbered findings
for the full unit and complete2155a0f aggregate. All19 current controls and accepted
TELEM-01 controls remain unchanged. A02 approval and CDR-017 READY preceded retries0
implementation/native tests. ActualSDK/protobuf/Chat/concurrency/privacy/lifecycle
and exact13 native/HTTP listener effects passed with owned cleanup.

Root2891passed/1unchangedSciPyskip, Chat+Telemetry828passed/5unchangedlive skips,
owning13trees2873passed/1unchangedSciPyskip. Unit12/7 and aggregate110/70 Ruff/Mypy
exit0; AST/API/registry invariance,18floors/offline lock, board/docs and whitespace
pass. Raw root Ruff remains exit1/exact327 approved WVR-004 identities; never PASS.
Independent retrospective baseline comparisons retain old closed-console shutdown
error, absent in candidate. They are not labelled true pre-build tests.

Reports/raw receipts/original manifests and scripts are byte-preserved; compressed
raw Python/logs avoid introducing lint discovery debt. Controller's evidence-only
untracked execution/TELEM-02-final addition during review was disclosed/reconciled;
no reviewed HEAD/index/product/control changed. Named unrelated dirty work remains
preserved. Readable report derivatives retain exact originals in gzip.

execution_phase: closeout; validation_state: verified. TELEM-02 completion is
proposed for maintainer acceptance, not accepted automatically. Initiative remains
started; delivery local. Next: explicit TELEM-02 acceptance, then TELEM-03 directive
preparation for safe LLM metrics/role-service injection; no later implementation,
remote/TLS/vendor activation, push/merge/release/deploy is granted by this result.
''')
refs='''  - docs/planning/active/friday-telemetry-rewire/validation/CDR-017/report.md
  - docs/planning/active/friday-telemetry-rewire/validation/CDR-017/evidence.json
  - docs/planning/active/friday-telemetry-rewire/validation/VAL-007/report.md
  - docs/planning/active/friday-telemetry-rewire/validation/VAL-007/evidence.json
  - docs/planning/active/friday-telemetry-rewire/execution/TELEM-02-final/report.md
'''
events='''- task: friday-telemetry-rewire
  at: '2026-10-06'
  actor: Chuck Russell
  actor_role: maintainer
  action: approved CD-002 A02 fixed native retry disablement
  note: Explicit approved response; one fixed grpc.enable_retries=0 option, unchanged13 listener effects and WVR-004 expiry. Fresh CDR-017 READY preceded implementation.
  evidence: docs/planning/active/friday-telemetry-rewire/directives/CD-002-A02-approval-record.md
- task: friday-telemetry-rewire
  at: '2026-10-06'
  actor: Codex
  actor_role: agent
  action: proposed TELEM-02 completion after independent verification
  note: VAL-007 VERIFIED full unit and complete2155a0f aggregate at45f3114; no findings. Root2891, Chat828 and owning2873passed; exact raw327 lint disposition retained. Acceptance pending, initiative started, delivery local, later units separately governed.
  evidence: docs/planning/active/friday-telemetry-rewire/validation/VAL-007/report.md
'''
def board(s):
 assert s.count('  next_gate: '+oldgate)==1;s=s.replace('  next_gate: '+oldgate,'  next_gate: '+newgate,1)
 start=s.index('- id: friday-telemetry-rewire\n');stop=s.index('\nevents:',start);section=s[start:stop];assert section.count('  approved_by:')==1;section=section.replace('  approved_by:',refs+'  approved_by:',1);return s[:start]+section+s[stop:]+events
for path,name in [('docs/planning/board.yaml','board.index'),('docs/planning/README.md','dashboard.index')]:
 clean=subprocess.check_output(['git','show','HEAD:'+path]).decode();working=(root/path).read_text()
 if path.endswith('.yaml'):clean=board(clean);working=board(working)
 else:
  assert clean.count(oldgate)==1 and working.count(oldgate)==1;clean=clean.replace(oldgate,newgate,1);working=working.replace(oldgate,newgate,1)
 (o/name).write_text(clean);(root/path).write_text(working)
paths=[str(r.relative_to(root)),str(l.relative_to(root)),str((pkt/'execution/TELEM-02-final').relative_to(root)),str((pkt/'validation/VAL-007').relative_to(root))];(o/'closeout-paths.json').write_text(json.dumps(paths));print('Verified outcome recorded; candidate source/19controls unchanged; unit acceptance pending')
