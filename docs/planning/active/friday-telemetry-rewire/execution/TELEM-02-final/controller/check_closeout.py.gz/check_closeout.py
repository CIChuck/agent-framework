from pathlib import Path
import importlib.util,json,shutil,hashlib
spec=importlib.util.spec_from_file_location('safe_runner','/private/tmp/telem-02/builder-execution/runner.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner);out=Path('/private/tmp/telem-02/controller-closeout');out.mkdir(exist_ok=True);runner.OUT=out;runner.helper.OUT=out
root=runner.prepare('metadata-check','45f3114173a7e9ada128c7950fe1f7e63cb2ff28');pkt='docs/planning/active/friday-telemetry-rewire';overlay={}
for path,source in [('docs/planning/board.yaml','/private/tmp/telem-02/board.index'),('docs/planning/README.md','/private/tmp/telem-02/dashboard.index'),(pkt+'/README.md',pkt+'/README.md'),(pkt+'/execution-log.md',pkt+'/execution-log.md')]:
 b=Path(source).read_bytes();(root/path).write_bytes(b);overlay[path]=hashlib.sha256(b).hexdigest()
for suffix in ['execution/TELEM-02-final','validation/VAL-007']:
 source=Path(pkt)/suffix;dest=root/pkt/suffix;shutil.copytree(source,dest)
 for f in source.rglob('*'):
  if f.is_file():overlay[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
p=out/'metadata-check-snapshot.json';r=json.loads(p.read_text());r['metadata_overlay']=overlay;r['tracked_hashes'].update(overlay);p.write_text(json.dumps(r,indent=2)+'\n')
for label,args in [('closeout-board',['python','scripts/friday-dev-board.py','validate']),('closeout-next',['python','scripts/friday-dev-board.py','next']),('closeout-show',['python','scripts/friday-dev-board.py','show','friday-telemetry-rewire']),('closeout-docs',['python','scripts/check-documentation-lifecycle.py']),('closeout-root-ruff',['ruff','check','.','--output-format=json'])]:
 result=runner.run('metadata-check',label,args);assert result==(1 if label=='closeout-root-ruff' else 0),(label,result)
findings=json.loads((out/'closeout-root-ruff.log').read_text());scope=json.loads((root/pkt/'validation/WVR-004-telem02-lint-scope.json').read_text());print('root findings',len(findings),'frozen closeout overlay',len(overlay))
