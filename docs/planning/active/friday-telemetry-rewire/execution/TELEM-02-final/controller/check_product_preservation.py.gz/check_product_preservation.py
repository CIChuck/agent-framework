from pathlib import Path
import collections,difflib,hashlib,json,subprocess,sys
r=Path.cwd();o=Path('/private/tmp/telem-02');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();orig=json.loads(Path('/private/tmp/telem-01/REM-004/approved-execution/preserved.json').read_text());checks={}
for p,v in orig.items():
 if p in {'docs/planning/board.yaml','docs/planning/README.md'}:continue
 if isinstance(v,dict):
  now={str(f.relative_to(r)):sha(f) for f in (r/p).rglob('*') if f.is_file()}
  checks[p]=now==v
 elif v is None:checks[p]=not (r/p).exists()
 else:checks[p]=sha(r/p)==v
for p,basefile in [('docs/planning/board.yaml','board.before'),('docs/planning/README.md','dashboard.before')]:
 b=subprocess.check_output(['git','show','e8b075a:'+p]).decode();c=(o/('board.index' if p.endswith('.yaml') else 'dashboard.index')).read_text() if '--prepared-index' in sys.argv else subprocess.check_output(['git','show','HEAD:'+p]).decode()
 def changed(a,z):return collections.Counter(x for x in difflib.unified_diff(a.splitlines(),z.splitlines(),n=0) if (x.startswith('+') or x.startswith('-')) and not x.startswith(('+++','---')))
 checks[p+' unrelated dirty edits']=changed(b,(o/basefile).read_text())==changed(c,(r/p).read_text())
req=json.loads(Path('/private/tmp/telem-01/REM-004/approved-execution/product-validation-request.json').read_text())
checks['accepted19pins_and_manifest']=all(sha(r/a['path'])==a['sha256'] for a in req['authority']) and sha(r/req['manifest_path'])==req['manifest_sha256']
product_paths=set(subprocess.check_output(['git','diff','--name-only','e8b075a','HEAD','--','packages','uv.lock','pyproject.toml','AGENTS.md','docs/reference/policies']).decode().splitlines())
allowed_sources=['__init__.py','config.py','factory.py','lifecycle.py','providers/otel.py','providers/_otel_exporter.py','providers/_otel_processor.py']
allowed_tests=['test_providers.py','test_mcp_telemetry.py','test_otel_contract.py','test_telemetry_factory.py','test_otlp_collector.py']
allowed={'packages/friday-telemetry/README.md',*('packages/friday-telemetry/src/friday_telemetry/'+x for x in allowed_sources),*('packages/friday-telemetry/tests_telemetry/'+x for x in allowed_tests)}
checks['product_delta_only_exact_CD002_paths']=product_paths<=allowed
checks['all19_current_unit_authority_pins']=all(sha(r/a['path'])==a['sha256'] for a in json.loads((r/'docs/planning/active/friday-telemetry-rewire/authority-manifest-TELEM-02.yaml').read_text())['authority'])
checks['empty_index']=not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
if not all(checks.values()):raise RuntimeError(checks)
(o/'controller-preservation.json').write_text(json.dumps(dict(candidate=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),checks=checks,scope='named nonprotected dirty paths and original user board/dashboard diff; accepted controlling authority; product delta constrained to exact approved CD002 manifest',protected_payloads_read=False),indent=2)+'\n')
print(json.dumps(checks,indent=2))
