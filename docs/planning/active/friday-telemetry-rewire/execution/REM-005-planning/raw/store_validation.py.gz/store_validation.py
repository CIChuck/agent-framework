from pathlib import Path
import gzip,hashlib,json
repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');source=Path('/private/tmp/telem-04/VAL-009');dest=repo/'docs/planning/active/friday-telemetry-rewire/validation/VAL-009';dest.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
report=source/'report.md';original=source/'artifact-manifest.json'
if sha(report.read_bytes())!='6368a6cb61b16d77fb145a5504cddb23db9fe3cc8e98c917ebb22877f6c15393' or sha(original.read_bytes())!='600ced2de3d81d78c6d98bd3dbbcaffb22176725c5887532beab32f31bc0e0e1':raise RuntimeError('Original validation drift')
m=json.loads(original.read_text());records=[]
for path,record in m['artifacts'].items():
    data=(source/path).read_bytes()
    if sha(data)!=record['sha256'] or len(data)!=record['bytes']:raise RuntimeError('Reviewer artifact drift '+path)
    compressed=gzip.compress(data,mtime=0);target=dest/'raw'/(path+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(compressed)
    records.append({'original':str(source/path),'stored':str(target.relative_to(dest)),'original_sha256':sha(data),'stored_sha256':sha(compressed),'bytes':len(data)})
(dest/'original-artifact-manifest.json').write_bytes(original.read_bytes())
(dest/'stored-artifact-manifest.json').write_text(json.dumps({'review_id':'VAL-009','candidate':m['candidate'],'verdict':m['verdict'],'original_report_sha256':sha(report.read_bytes()),'original_manifest_sha256':sha(original.read_bytes()),'artifacts':records},indent=2)+'\n')
(dest/'report.md').write_text('''# VAL-009 controller storage record

Fresh-context read-only validator `/root/telem04_product_validator` returns
**CHANGES_REQUESTED** for frozen product1547fae, full TELEM-04 unit and complete
2155a0f aggregate. All18 mandatory commands ran independently. Root3,050,
owning3,032 and Chat/LLM/Telemetry1,169 pass; the unchanged optional SciPy skip
and exact two live exclusions remain explicit. Genuine source typing and changed
lint pass. Raw root Ruff exits1 with exact327 approved WVR-006 identities.

| Finding | Severity | Required repair |
| --- | --- | --- |
| VAL-009-F01 |High |Isolate background SDK parent/context from an active foreground span |
| VAL-009-F02 |High |Keep legacy None-origin extraction explicitly uncorrelated |
| VAL-009-F03 |Medium |Classify rejected known MCP calls as MCP, with zero dispatches |
| VAL-009-F04 |High |Explicitly close retained model/adapter iterators before terminal return; preserve primary exceptions |
| VAL-009-F05 |Medium |Reject non-integer execution schema versions before records, sink or metrics |

These supplemental probes expose mandatory gaps despite passing suites. F04
also reproduces at the unit base; current closure criteria still require its fix.
No source remediation was performed. Task remains started/local, unverified and
unaccepted. The next gate is the separately bound REM-005 remediation directive.

The [unaltered independent report](raw/report.md.gz) has SHA256
6368a6cb61b16d77fb145a5504cddb23db9fe3cc8e98c917ebb22877f6c15393.
[Original manifest](original-artifact-manifest.json) has SHA256
600ced2de3d81d78c6d98bd3dbbcaffb22176725c5887532beab32f31bc0e0e1.
[Stored artifact manifest](stored-artifact-manifest.json) binds156 originals and
gzip copies, including failed supplemental setup attempts and corrected reruns.
This concise controller view does not replace the original report or its findings.

The original records a late shared-context implementation-proposal message after
independent defect reproduction; it was not used for a PASS or candidate repair.
All candidate snapshots stayed unchanged. Controller evidence packaging and a
transient unrelated .claude/ status addition are explicit metadata exceptions;
the validator did not read their payloads. All preexisting status entries, original
HEAD/index/branch and protected omissions stayed unchanged. The remediation's
future validator must receive only frozen authority/candidate/requirements.
''')
print('Stored original independent artifacts',len(records),'CHANGES_REQUESTED; no source changes')
