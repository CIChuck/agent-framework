from pathlib import Path
import importlib.util,json,hashlib,datetime
OUT=Path('/private/tmp/telem-04/REM-005/builder')
spec=importlib.util.spec_from_file_location('h',OUT/'prepare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
h.OUT=OUT;h.GUARD=Path('/private/tmp/telem-04/REM-005/readiness/network-guard')
assert h.sha((OUT/'prepare.py').read_bytes())=='cd3963d50f55b5c2c18f2cf83f38a1ac4e13cb9bfc8ae3b3e31522d8492a9586'
assert h.sha((h.GUARD/'sitecustomize.py').read_bytes())=='6f61ea4ca34c7abef9e0c709eb1e1feb0f3cf7733cbc59bc465d6b01182e9e81'
h.save('original-before.json',h.original_state())
root,receipt=h.prepare('candidate','3e07707d13f1db7c023d660d721e0b817661bdad')
manifest=json.loads((root/'docs/planning/active/friday-telemetry-rewire/authority-manifest-REM-005.yaml').read_text())
for p,s in manifest['product_base_sha256'].items():assert h.sha((root/p).read_bytes())==s,p
for pin in manifest['authority']:assert h.sha((root/pin['path']).read_bytes())==pin['sha256'],pin['path']
original=json.loads((root/'docs/planning/active/friday-telemetry-rewire/validation/VAL-009/original-artifact-manifest.json').read_text())
probes=['sdk_probe.py','fake_probe.py','tools_reasoning_probe.py','closure_probe.py','schema_probe.py']
for name in probes:
 source=Path('/private/tmp/telem-04/VAL-009')/name
 assert h.sha(source.read_bytes())==original['artifacts'][name]['sha256'],name
 (OUT/name).write_bytes(source.read_bytes())
h.save('preparation-audit.json',dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),helper_sha256=h.sha((OUT/'prepare.py').read_bytes()),guard_sha256=receipt['guard_sha256'],authority_pins_verified=len(manifest['authority']),product_pins_verified=len(manifest['product_base_sha256']),frozen_product='1547fae7cac6450ec9ad7440f19d1f1162598fe2',snapshot_head=receipt['revision'],product_bytes_identical=True,probe_hashes={n:h.sha((OUT/n).read_bytes()) for n in probes},helper_audit='267protected omissions before checkout; no dirty overlay; allowlisted credential-free env; private cache; no provisioning; recovered exact historical helper and guard; original missing-path failure retained in session'))
print(root)
