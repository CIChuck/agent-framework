from pathlib import Path
r=Path('/private/tmp/telem-04/REM-005/builder/candidate')
def append(p,s):
 p=r/p;p.write_text(p.read_text()+'\n\n'+s.strip()+'\n')
append('packages/friday-telemetry/tests_telemetry/test_execution_events.py','''
@pytest.mark.parametrize("version", [True, False, 1.0, "1", 0, 2])
def test_version_requires_actual_integer_even_for_forged_instances(version):
    data = {**IDENTITY, "operation_kind": "native_tool", "outcome": "succeeded",
            "duration_ms": 0.0, "schema_version": version}
    with pytest.raises(ValidationError):
        OperationFinish.model_validate(data)
    forged = OperationFinish.model_construct(**data)
    with pytest.raises(ValidationError):
        OperationFinish.model_validate(forged)
    with pytest.raises(ValidationError):
        ExecutionEvent.model_validate(forged)
    with pytest.raises(ValidationError):
        ExecutionEvent.model_validate(ExecutionEvent.model_construct(root=forged))


@pytest.mark.parametrize("explicit", [False, True])
def test_default_and_exact_integer_version_preserved(explicit):
    data = {**IDENTITY, "operation_kind": "native_tool", "outcome": "succeeded", "duration_ms": 0.0}
    if explicit:
        data["schema_version"] = 1
    event = OperationFinish.model_validate(data)
    assert type(event.schema_version) is int and event.schema_version == 1
    assert ExecutionEvent.model_validate(event).attributes()["schema_version"] == 1
''')
append('packages/friday-telemetry/tests_telemetry/test_correlation.py','''
def test_private_delivery_contexts_do_not_change_caller_or_siblings():
    from contextvars import ContextVar
    value = ContextVar("fake_sink_stack", default=())
    value.set(("caller",))
    scope = CorrelationScope("a" * 16)
    with scope.bind(scope.context(turn=True)) as parent:
        parent.delivery_context.run(value.set, ("parent",))
        left = parent.delivery_context.copy()
        right = parent.delivery_context.copy()
        with scope.bind(parent.context.child(), delivery_context=left) as child:
            child.delivery_context.run(value.set, ("parent", "left"))
        assert right.run(value.get) == ("parent",)
        assert parent.delivery_context.run(value.get) == ("parent",)
        assert value.get() == ("caller",)
    assert scope.current() is None
''')
append('packages/friday-chat/tests_chat/test_telemetry_diagnostics.py','''
@pytest.mark.parametrize("version", [True, False, 1.0, "1", 0, 2])
@pytest.mark.parametrize("entry", ["dictionary", "forged", "forged_root"])
def test_invalid_versions_rejected_before_record_delivery_and_metrics(version, entry):
    from friday_telemetry.models.execution import ExecutionEvent
    sink = DebugTelemetryRecorder()
    o = ChatTelemetryObserver(enabled=True, session_id="private", provider=sink)
    with operation_scope(o, "native_tool"):
        frame = o.correlation.current()
        data = {**frame.context.identity().model_dump(), "schema_version": version,
                "operation_kind": "native_tool", "outcome": "succeeded", "duration_ms": 0.0}
        before = o.execution_snapshot()
        delivered = len(sink.events)
        if entry == "dictionary":
            o.capture_event("execution.operation_finish", data)
        else:
            forged = OperationFinish.model_construct(**data)
            o.execution(forged if entry == "forged" else ExecutionEvent.model_construct(root=forged))
        assert o.execution_snapshot() == before
        assert len(sink.events) == delivered
        assert not frame.terminal
        assert o.snapshot().rejected_count == 1
        assert not any(e.name == "execution.operation_finish" for e in o.snapshot().events)
    assert o.execution_snapshot().counters == (("native_tool", "succeeded", 1),)
''')
append('packages/friday-chat/tests_chat/test_tool_telemetry.py','''
@pytest.mark.asyncio
async def test_mixed_rejections_use_trusted_membership_without_extra_lookups():
    o = ChatTelemetryObserver(enabled=True, session_id="private")
    mcp = "mcp_peer_private"
    class Registry(FakeToolRegistry):
        def __init__(self):
            super().__init__()
            self.lookups = []
            self.dispatches = []
        def is_mcp_tool(self, name):
            self.lookups.append(name)
            return name == mcp
        async def call_tool_record(self, name, arguments, **kwargs):
            self.dispatches.append(name)
            raise AssertionError("rejected call must not dispatch")
    registry = Registry()
    with turn_scope(o, "completion"):
        result = await ToolLoop(registry, observer=o, max_iterations=10).run(
            [{"tool_calls": [{"name": mcp}, {"name": "echo"}, {"name": "unknown"}, {"name": []}]}],
            [ToolDefinition("allowed", "safe")])
    rows = [dict(e.attributes) for e in o.snapshot().events if e.name == "execution.selection"]
    assert [(x["rejected_native"], x["rejected_mcp"]) for x in rows] == [(0, 1), (1, 0), (1, 0), (1, 0)]
    assert all(x["selected_native"] == x["selected_mcp"] == 0 and x["rejection_count"] == 1 for x in rows)
    assert set(registry.lookups) == {mcp, "echo", "unknown", "allowed"}
    assert len(registry.lookups) == 4 and not registry.dispatches and not result.tool_calls
    assert not any(e.name == "execution.operation_start" for e in o.snapshot().events)
    assert o.execution_snapshot().turns[-1].completed_tools == 0
''')
append('packages/friday-chat/tests_chat/test_memory_telemetry.py','''
class ContextSink:
    """Fake sink models the accepted immutable task-local logical span stack."""
    def __init__(self):
        from contextvars import ContextVar
        self.stack = ContextVar("fake_sink_stack", default=())
        self.spans = {}
        self.events = []
    def start_span(self, name, parent_id=None):
        stack = tuple(x for x in self.stack.get() if not self.spans[x]["closed"])
        key = str(len(self.spans))
        self.spans[key] = {"name": name, "parent": parent_id if parent_id is not None else stack[-1] if stack else None,
                           "closed": False, "events": []}
        self.stack.set((*stack, key))
        return key
    def capture_event(self, name, data):
        stack = tuple(x for x in self.stack.get() if not self.spans[x]["closed"])
        self.events.append((name, data, stack[-1] if stack else None))
        if stack:
            self.spans[stack[-1]]["events"].append((name, data))
    def end_span(self, key, data=None):
        self.spans[key]["closed"] = True
        self.stack.set(tuple(x for x in self.stack.get() if x != key and not self.spans[x]["closed"]))


@pytest.mark.asyncio
@pytest.mark.parametrize("mode", ["success", "retry", "none"])
async def test_explicit_none_mixed_origins_isolate_active_foreground_and_accounting(mode):
    from friday_telemetry import CompositeProvider
    sinks = [ContextSink(), ContextSink()]
    o = ChatTelemetryObserver(enabled=True, session_id="private", provider=CompositeProvider(sinks))
    origins = [o.correlation.context(turn=True), None, o.correlation.context(turn=True)]
    seen = []
    attempts = 0
    class Extractor:
        async def extract(self, turn):
            nonlocal attempts
            attempts += 1
            seen.append(o.correlation.current().context.turn_ref)
            if mode == "retry" and attempts == 2:
                raise RuntimeError("PRIVATE_PRIMARY")
            return {}
    adapter = FrameworkMaintenanceAdapter(config(), "private", None, None, None, {}, {},
        extractor=None if mode == "none" else Extractor(), observer=o)
    items = [PendingExtractionTurn(str(i), "PRIVATE_U", "PRIVATE_A", origin) for i, origin in enumerate(origins)]
    adapter.pending_extraction = items.copy()
    with turn_scope(o, "completion"):
        foreground = o.correlation.current()
        with suppress(RuntimeError):
            await adapter.flush_pending_extraction()
        assert o.correlation.current() is foreground
        assert foreground.accounting.completed_tools == foreground.accounting.failed_tools == 0
        assert foreground.accounting.persistence == "not_started"
        if mode == "retry":
            assert adapter.pending_extraction == items[1:]
            assert adapter.pending_extraction[0] is items[1]
            await adapter.flush_pending_extraction()
        assert not adapter.pending_extraction
        assert all(s.stack.get() == () for s in sinks)
    finishes = [dict(e.attributes) for e in o.snapshot().events if e.name == "execution.operation_finish"]
    expected = [origins[0].turn_ref, None, None, origins[2].turn_ref] if mode == "retry" else [origins[0].turn_ref, None, origins[2].turn_ref]
    assert [e.get("turn_ref") for e in finishes] == expected
    assert not o._spans and o.correlation.current() is None
    for sink in sinks:
        extraction = [s for s in sink.spans.values() if any(n == "execution.operation_start" for n, d in s["events"])]
        assert len(extraction) == len(expected) and all(s["parent"] is None and s["closed"] for s in extraction)
        assert "PRIVATE" not in repr(sink.events)


@pytest.mark.asyncio
async def test_context_sink_active_background_preemption_resume_shutdown_and_nested_siblings():
    from friday_chat.turns.telemetry import operation_scope
    from friday_telemetry import CompositeProvider
    sinks = [ContextSink(), ContextSink()]
    o = ChatTelemetryObserver(enabled=True, session_id="private", provider=CompositeProvider(sinks))
    r = build_runtime(config())
    r.telemetry = o
    entered = asyncio.Event()
    attempt = 0
    class Extractor:
        async def extract(self, turn):
            nonlocal attempt
            attempt += 1
            entered.set()
            if attempt == 1:
                await asyncio.Event().wait()
            return {}
    values = config().model_dump()
    values["extraction"]["interval"] = 0
    adapter = FrameworkMaintenanceAdapter(FridayChatConfig.model_validate(values), "private", None, None, None, {}, {},
        extractor=Extractor(), observer=o)
    r.maintenance = adapter
    manager = BackgroundTaskManager()
    coordinator = BackgroundWorkCoordinator(r, manager)
    try:
        with turn_scope(o, "completion") as origin:
            parent = o.correlation.current()
            coordinator.schedule_after_turn(turn_count=1, user_message="PRIVATE_U", assistant_message="PRIVATE_A", correlation_context=origin)
            await entered.wait()
            assert await coordinator.preempt_extraction_for_foreground_turn()
            assert adapter.pending_extraction[0].correlation_context is origin
            assert coordinator.resume_preempted_extraction()
            await manager.wait_for_all()
            async def sibling():
                with operation_scope(o, "native_tool"):
                    await asyncio.sleep(0)
            await asyncio.gather(sibling(), sibling())
            with turn_scope(o, "completion"), operation_scope(o, "model_call"):
                pass
            assert o.correlation.current() is parent
            assert all(s.stack.get() == () for s in sinks)
        coordinator.schedule_after_turn(turn_count=2, user_message="PRIVATE_U", assistant_message="PRIVATE_A", correlation_context=origin)
        await manager.wait_for_all()
        adapter.pending_extraction.append(PendingExtractionTurn("private", "PRIVATE_U", "PRIVATE_A", None))
        assert await adapter.flush_pending_extraction() == 1
    finally:
        await manager.close()
    assert manager.closed and not o._spans and o.correlation.current() is None
    for sink in sinks:
        assert all(s["closed"] for s in sink.spans.values())
        for name, data, key in sink.events:
            if name == "execution.operation_start":
                span = sink.spans[key]
                if data["operation_kind"] == "memory_extract":
                    assert span["parent"] is None
                else:
                    assert span["parent"] is not None
            if name in {"execution.operation_start", "execution.operation_finish"}:
                assert sink.spans[key]["name"] == "chat.operation"
''')
append('packages/friday-chat/tests_chat/test_turn_telemetry.py','''
class RetainedStream:
    def __init__(self, values, cleanup=None, primary=None):
        self.values = iter(values)
        self.cleanup = cleanup
        self.primary = primary
        self.close_attempts = 0
        self.closed = False
    def __aiter__(self):
        return self
    async def __anext__(self):
        if self.primary is not None:
            raise self.primary
        try:
            return next(self.values)
        except StopIteration:
            raise StopAsyncIteration from None
    async def aclose(self):
        self.close_attempts += 1
        await asyncio.sleep(0)
        self.closed = True
        if self.cleanup is not None:
            raise self.cleanup


@pytest.mark.asyncio
@pytest.mark.parametrize("path", ["direct", "legacy", "typed"])
@pytest.mark.parametrize("failure", ["normal", "callback", "callback_cancel", "model_cancel"])
@pytest.mark.parametrize("cleanup", ["normal", "error", "cancel"])
async def test_retained_actual_stream_cleanup_before_terminal_and_primary_identity(path, failure, cleanup):
    from friday_chat.adapters import FrameworkChatModel
    from friday_chat.config import LegacyLLMExecutionConfig
    from friday_llm import TextDeltaEvent
    r = runtime()
    primary = asyncio.CancelledError() if failure in {"callback_cancel", "model_cancel"} else RuntimeError("PRIVATE_PRIMARY")
    cleanup_error = RuntimeError("PRIVATE_CLEANUP") if cleanup == "error" else asyncio.CancelledError() if cleanup == "cancel" else None
    upstream = RetainedStream([TextDeltaEvent(text="first"), TextDeltaEvent(text="second")] if path == "typed" else ["first", "second"],
                              cleanup_error, primary if failure == "model_cancel" else None)
    class Service:
        def chat_completion_stream(self, **kwargs):
            return upstream
        def chat_completion_events(self, request):
            return upstream
    if path == "direct":
        class Model:
            def stream_complete(self, *args, **kwargs):
                return upstream
        r.chat_llm = Model()
    else:
        cfg = FridayChatConfig.model_validate({"llm": {"model": "fake/test", "generation": {}}})
        execution = LegacyLLMExecutionConfig(0.0, None, None) if path == "legacy" else cfg.llm.resolve_execution()
        r.chat_llm = FrameworkChatModel(Service(), cfg, execution)
    chunks = []
    async def capture(chunk):
        chunks.append(chunk)
        if failure.startswith("callback"):
            raise primary
    expected = primary if failure != "normal" else cleanup_error
    if expected is None:
        result = await TurnProcessor(r).process_streaming("PRIVATE", on_chunk=capture)
        assert result.assistant_message == "firstsecond" and chunks == ["first", "second"]
    else:
        with pytest.raises(type(expected)) as caught:
            await TurnProcessor(r).process_streaming("PRIVATE", on_chunk=capture)
        assert caught.value is expected
    assert upstream.close_attempts == 1 and upstream.closed
    terminal, = events(r, "turn_finish")
    assert terminal["outcome"] == ("succeeded" if expected is None else "cancelled" if isinstance(expected, asyncio.CancelledError) else "failed")
    assert not r.telemetry._spans and r.telemetry.correlation.current() is None
    assert "PRIVATE" not in repr(r.telemetry.snapshot())


@pytest.mark.asyncio
@pytest.mark.parametrize("path", ["legacy", "typed"])
@pytest.mark.parametrize("cleanup", [None, "error", "cancel"])
async def test_public_adapter_early_close_awaits_retained_upstream(path, cleanup):
    from friday_chat.adapters import FrameworkChatModel
    from friday_chat.config import LegacyLLMExecutionConfig
    from friday_llm import TextDeltaEvent
    cfg = FridayChatConfig.model_validate({"llm": {"model": "fake/test", "generation": {}}})
    upstream = RetainedStream([TextDeltaEvent(text="first"), TextDeltaEvent(text="second")] if path == "typed" else ["first", "second"],
                              RuntimeError("PRIVATE") if cleanup == "error" else asyncio.CancelledError() if cleanup == "cancel" else None)
    class Service:
        def chat_completion_stream(self, **kwargs):
            return upstream
        def chat_completion_events(self, request):
            return upstream
    model = FrameworkChatModel(Service(), cfg, LegacyLLMExecutionConfig(0.0, None, None) if path == "legacy" else cfg.llm.resolve_execution())
    iterator = model.stream_complete([])
    assert await anext(iterator) == "first"
    await iterator.aclose()  # GeneratorExit remains primary if cleanup also fails.
    assert upstream.close_attempts == 1 and upstream.closed
''')
for p,s in [('packages/friday-chat/README.md','''
Execution spans deliver synchronous sink calls in private per-frame contexts.
Active owned children retain explicit parents; independent background items,
including explicit absent origins, cannot inherit a foreground sink stack. None
origins emit session-only facts and do not contribute to foreground accounting.
Known rejected MCP calls use trusted membership for their closed rejection counts.
Execution schema versions require actual integer1, including forged-instance entry.
Acquired close-capable model iterators are explicitly awaited before terminal return
through direct, legacy and typed stream paths. Cleanup preserves an active callback,
model or cancellation exception; chunk ordering, heartbeat and buffering stay intact.
'''),('packages/friday-telemetry/README.md','''
Execution schema_version accepts actual integer1 only; bool, float, string and
forged-instance versions are rejected before recording, sink delivery or metrics.
Chat delivery contexts are private active-frame state, never exported lineage.
Independent frames and copied active child contexts keep provider stack bindings
isolated while explicit owned parents preserve legitimate nesting. Per-item absent
origins remain session-only. Close-capable upstream iterators are awaited through
Chat's stream wrapper chain before terminal return, preserving primary exceptions.
''')]:append(p,s)
print('Six authorized regression modules and two package READMEs updated')
