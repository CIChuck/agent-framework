from pathlib import Path
import importlib.util,importlib.metadata,hashlib,json,sys,shutil,tomllib
r=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();modules={}
for src in r.glob('packages/*/src'):
 for p in src.iterdir():
  if p.is_dir() and (p/'__init__.py').exists():
   spec=importlib.util.find_spec(p.name)
   assert spec is not None and spec.origin is not None and Path(spec.origin).resolve()==(p/'__init__.py').resolve(),(p.name,spec)
   modules[p.name]=dict(file=spec.origin,sha256=sha(Path(spec.origin)))
versions={n:dict(version=importlib.metadata.version(n),metadata_sha256=hashlib.sha256(importlib.metadata.distribution(n).read_text('METADATA').encode()).hexdigest()) for n in ['ruff','mypy','pytest','opentelemetry-sdk','opentelemetry-api','pydantic']}
assert sys.version_info[:3]==(3,13,10)
assert {n:versions[n]['version'] for n in ['ruff','mypy','pytest','opentelemetry-sdk']}=={'ruff':'0.14.10','mypy':'1.19.1','pytest':'9.0.2','opentelemetry-sdk':'1.39.1'}
binaries={n:dict(path=shutil.which(n),sha256=sha(Path(shutil.which(n)))) for n in ['python','ruff','mypy','pytest','uv']}
import sitecustomize
print(json.dumps(dict(python=sys.version,executable=sys.executable,modules=modules,versions=versions,binaries=binaries,guard=sitecustomize.__file__,guard_sha256=sha(Path(sitecustomize.__file__))),indent=2))
