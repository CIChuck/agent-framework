import run,json,sys,ast
r=run.OUT/'candidate'
manifest=json.loads((r/'docs/planning/active/friday-telemetry-rewire/authority-manifest-REM-005.yaml').read_text())
allowed=sum(manifest['product_manifest'].values(),[])
def paths(base):
 names=run.subprocess.check_output(['git','-C',str(r),'diff','--name-only',base]).decode().splitlines()
 return dict(paths=names,python=[p for p in names if p.endswith('.py')],source=[p for p in names if p.endswith('.py') and '/src/' in p])
unit=paths('e6209e3156216afde1655758e280690229f7d3e6');aggregate=paths('2155a0fc51f5b20dea4e35c6cfc70f1d52002735');rem=paths('1547fae7cac6450ec9ad7440f19d1f1162598fe2')
changed=run.subprocess.check_output(['git','-C',str(r),'diff','--name-only']).decode().splitlines();assert set(changed)==set(allowed)
for name,scope in [('unit',unit),('aggregate',aggregate),('rem',rem)]:run.h.save(name+'-scope.json',scope)
fixtures=json.loads((r/'docs/planning/active/friday-telemetry-rewire/execution/TELEM-04-planning/listener-scope.json').read_text())
for p,h in fixtures['fixture_hashes'].items():assert run.h.sha((r/p).read_bytes())==h,p
for p in manifest['product_manifest']['tests']:
 s=(r/p).read_text();ast.parse(s,feature_version=(3,13));assert not any(x in s for x in ('HTTPServer(','grpc.server(','PersistentClient(','TracerProvider(','BatchSpanProcessor(','socket.bind(')),p
run.h.save('effect-preflight-builder.json',dict(nodes=fixtures['existing_nodes'],fixture_hashes=fixtures['fixture_hashes'],six_new_modules_fake_only=True,new_tests_noSDK_listener_storage=True,guard_sha256=run.h.sha((run.h.GUARD/'sitecustomize.py').read_bytes()),readiness='CDR-020 READY original helper/source effects audited; same13 acceptedloopbacknodes; ownedsdkseparate'))
ignore=['--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py']
owners=sorted({p.split('/')[1] for p in aggregate['paths'] if p.startswith('packages/')});trees=[]
for owner in owners:
 trees.extend(str(p.relative_to(r)) for p in (r/'packages'/owner).glob('tests_*') if p.is_dir())
run.h.save('owning-trees.json',trees)
commands={
 'test-chat-llm-telemetry':['pytest','packages/friday-chat/tests_chat','packages/friday-llm/tests_llm','packages/friday-telemetry/tests_telemetry',*ignore,'-rA'],
 'test-root-collect':['pytest','--import-mode=importlib',*ignore,'--collect-only'],
 'test-root':['pytest','--import-mode=importlib',*ignore,'-rA'],
 'test-owning':['pytest','--import-mode=importlib',*trees,*ignore,'-rA'],
 'ruff-rem':['ruff','check',*changed] if False else ['ruff','check',*[p for p in changed if p.endswith('.py')]],
 'ruff-unit':['ruff','check',*unit['python']],
 'ruff-aggregate':['ruff','check',*aggregate['python']],
 'ruff-root':['ruff','check','.','--output-format','json'],
 'mypy-unit':['mypy','--python-version','3.13',*unit['source']],
 'mypy-aggregate':['mypy','--python-version','3.13',*aggregate['source']],
 'offline-lock':['uv','lock','--offline','--check','--no-python-downloads','--no-build'],
 'docs':['python','scripts/check-documentation-lifecycle.py'],
 'board-validate-final':['python','scripts/friday-dev-board.py','validate'],
 'board-next-final':['python','scripts/friday-dev-board.py','next'],
 'board-show-final':['python','scripts/friday-dev-board.py','show','friday-telemetry-rewire'],
 'board-render-final':['python','scripts/friday-dev-board.py','render','--check'],
 'diff-rem':['git','diff','--check','1547fae7cac6450ec9ad7440f19d1f1162598fe2'],
 'diff-unit':['git','diff','--check','e6209e3156216afde1655758e280690229f7d3e6'],
 'diff-aggregate':['git','diff','--check','2155a0fc51f5b20dea4e35c6cfc70f1d52002735'],
}
run.h.save('expanded-commands.json',commands)
for label in sys.argv[1:]:run.run(label,commands[label])
