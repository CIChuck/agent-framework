import run,json,ast,hashlib
r=run.OUT/'candidate';manifest=json.loads((run.OUT/'final-product-manifest-v2.json').read_text())
for p,h in manifest['files'].items():assert run.h.sha((r/p).read_bytes())==h,p
changed=run.subprocess.check_output(['git','-C',str(r),'diff','--name-only']).decode().splitlines();assert set(changed)==set(manifest['files'])
def node(path,cls,name=None):
 now=ast.parse((r/path).read_text());old=ast.parse(run.subprocess.check_output(['git','-C',str(r),'show','HEAD:'+path]).decode())
 def get(t):
  c=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name==cls)
  return next(n for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name) if name else c
 return ast.dump(get(now),include_attributes=False)==ast.dump(get(old),include_attributes=False)
proof={
 'ExecutionContext_unchanged':node('packages/friday-telemetry/src/friday_telemetry/helpers/correlation.py','ExecutionContext'),
 'TurnResult_unchanged':node('packages/friday-chat/src/friday_chat/turns/processor.py','TurnResult'),
 'aggregation_labels_accounting_unchanged':node('packages/friday-chat/src/friday_chat/telemetry.py','ChatTelemetryObserver','_aggregate'),
 'FrameworkChatModel_complete_unchanged':node('packages/friday-chat/src/friday_chat/adapters.py','FrameworkChatModel','complete')}
assert all(proof.values())
source=[p for p in changed if '/src/' in p]
diff=run.subprocess.check_output(['git','-C',str(r),'diff','--',*source]).decode()
added=[s[1:] for s in diff.splitlines() if s.startswith('+') and not s.startswith('+++')]
assert not any(x in s for s in added for x in ['# type: ignore','# mypy: ignore-errors','# noqa','create_task(', 'ensure_future(', 'set_tracer_provider(', 'TracerProvider(', 'HTTPServer(', 'asyncio.shield('])
run.h.save('final-source-audit.json',dict(final_manifest='final-product-manifest-v2.json',candidate='5c3a0e6dc8ba995bad9e7dfb8c574f5dfd335bc8',product_hashes_stable=True,exact_changed_paths=changed,unchanged_AST_contracts=proof,no_new_suppressions_tasks_SDK_registration_listener_or_prefetch=True,all_other_tracked_bytes_unchanged='scope-api-privacy-audit.json',schema_revalidation='focused-final-r2; model and forgedRootModel negatives',privacy='final originalfake/SDK probes plus132fake regressions'))
for label,base in [('rem','1547fae7cac6450ec9ad7440f19d1f1162598fe2'),('unit','e6209e3156216afde1655758e280690229f7d3e6'),('aggregate','2155a0fc51f5b20dea4e35c6cfc70f1d52002735')]:
 args=['git','-C',str(run.h.REPO),'diff','--check',base,'5c3a0e6dc8ba995bad9e7dfb8c574f5dfd335bc8'];assert run.run('committed-diff-'+label,args)==0
 (run.OUT/(label+'-final.diff')).write_bytes(run.subprocess.check_output(['git','-C',str(r),'diff','--no-ext-diff','--binary',base]))
print('Frozen product source audit and three controller-committed diffchecks pass')
