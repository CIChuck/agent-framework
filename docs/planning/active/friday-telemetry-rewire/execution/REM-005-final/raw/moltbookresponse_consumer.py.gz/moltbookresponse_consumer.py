from friday_moltbook.responses import MoltbookResponse
class Parent: pass
class Child(Parent): pass
def parent_to_child(value: MoltbookResponse[Parent]) -> MoltbookResponse[Child]:
    return value
def child_to_parent(value: MoltbookResponse[Child]) -> MoltbookResponse[Parent]:
    return value
