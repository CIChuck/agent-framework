"""Independent owned SDK consumer; no network/global registration or borrowed close."""
import asyncio,json,threading
from unittest.mock import patch
from friday_telemetry import DebugTelemetryRecorder,CompositeProvider,OTelConfig,TelemetryFactoryConfig,create_telemetry
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.turns.telemetry import turn_scope,operation_scope
from friday_chat.runtime import build_runtime,PendingExtractionTurn
from friday_chat.config import FridayChatConfig
from friday_chat.adapters import FrameworkMaintenanceAdapter
from friday_chat.background import BackgroundTaskManager,BackgroundWorkCoordinator
from opentelemetry import trace
from opentelemetry.sdk.trace.export import SpanExporter,SpanExportResult

spans=[];exporters=[];initial_threads=set(threading.enumerate());global_before=trace.get_tracer_provider();observations={}
class MemoryExporter(SpanExporter):
 def __init__(self,stream): self.closed=False;exporters.append(self)
 def export(self,batch): spans.extend(batch);return SpanExportResult.SUCCESS
 def shutdown(self): self.closed=True

def config():return FridayChatConfig.model_validate({'llm':{'model':'fake/test'},'tools':{'enabled':False},'telemetry':{'enabled':True},'extraction':{'interval':0}})
async def main(handle,debug):
 composite=CompositeProvider([debug,handle.telemetry]);o=ChatTelemetryObserver(enabled=True,session_id='SDK_PRIVATE_SESSION',provider=composite)
 r=build_runtime(config());r.telemetry=o
 from friday_chat.turns.processor import TurnProcessor
 await TurnProcessor(r).process('PRIVATE_PROMPT')
 async def nested(label):
  with turn_scope(o,'completion') as origin:
   with operation_scope(o,'model_call'):
    await asyncio.sleep(0)
    with operation_scope(o,'native_tool'): await asyncio.sleep(0)
   return origin.turn_ref
 observations['concurrent_turns']=await asyncio.gather(nested('one'),nested('two'))
 # While foreground provider span is active, background must start its own root.
 seen=[]
 class Extractor:
  async def extract(self,turn):
   seen.append(o.correlation.current().context.turn_ref);return {}
 adapter=FrameworkMaintenanceAdapter(config(),'PRIVATE_SESSION',None,None,None,{}, {},extractor=Extractor(),observer=o);r.maintenance=adapter
 manager=BackgroundTaskManager();coordinator=BackgroundWorkCoordinator(r,manager)
 with turn_scope(o,'completion') as origin:
  observations['active_origin']=origin.turn_ref
  coordinator.schedule_after_turn(turn_count=1,user_message='PRIVATE_U',assistant_message='PRIVATE_A',correlation_context=origin)
  await manager.wait_for_all()
  observations['active_foreground_restored']=o.correlation.current().context.turn_ref==origin.turn_ref
 # Post-close origin must be causal metadata, no ended SDK parent.
 observations['closed_origin']=origin.turn_ref
 coordinator.schedule_after_turn(turn_count=2,user_message='PRIVATE_U',assistant_message='PRIVATE_A',correlation_context=origin)
 await manager.wait_for_all()
 # Preemption/cancellation/requeue/resume plus shutdown flush.
 entered=asyncio.Event();release=asyncio.Event();attempt=0
 class DelayedExtractor:
  async def extract(self,turn):
   nonlocal attempt
   attempt+=1;entered.set()
   if attempt==1: await release.wait()
   return {}
 adapter.extractor=DelayedExtractor();preempt_origin=o.correlation.context(turn=True)
 observations['preempt_origin']=preempt_origin.turn_ref
 coordinator.schedule_after_turn(turn_count=3,user_message='PRIVATE_U',assistant_message='PRIVATE_A',correlation_context=preempt_origin)
 await entered.wait();observations['preempted']=await coordinator.preempt_extraction_for_foreground_turn()
 observations['requeued_origin']=adapter.pending_extraction[0].correlation_context.turn_ref
 observations['resumed']=coordinator.resume_preempted_extraction();await manager.wait_for_all()
 # Pending buffered turns drained on shutdown path, using preserved origin.
 adapter.pending_extraction.append(PendingExtractionTurn('PRIVATE_TURN','PRIVATE_U','PRIVATE_A',preempt_origin))
 observations['shutdown_flushed']=await adapter.flush_pending_extraction()
 await manager.close();observations['manager_closed']=manager.closed
 observations['all_chat_spans_closed']=not o._spans
 observations['all_composite_spans_closed']=not composite._spans
 observations['all_debug_spans_closed']=all(s.end_time is not None for s in debug.spans.values())
 observations['provider_still_owned_and_open']=not handle.snapshot().closed
 observations['correlation_restored']=o.correlation.current() is None
 observations['safe_events']=all('PRIVATE' not in repr(e.data) for e in debug.events)
 observations['debug_events']=[{'name':e.name,'data':e.data} for e in debug.events]
 assert handle.flush().status=='success'

with patch('friday_telemetry.providers._otel_exporter.SafeConsoleExporter',MemoryExporter),patch.object(trace,'set_tracer_provider',side_effect=AssertionError('global forbidden')):
 handle=create_telemetry(TelemetryFactoryConfig(provider='otel',otel=OTelConfig(exporter='console')))
 debug=DebugTelemetryRecorder()
 try: asyncio.run(main(handle,debug))
 finally: observations['shutdown_status']=handle.shutdown().status
observations['global_unchanged']=trace.get_tracer_provider() is global_before
observations['workers_remaining']=[t.name for t in threading.enumerate() if t not in initial_threads]
observations['exporter_closed']=all(e.closed for e in exporters)
observations['sdk_spans']=[{'name':s.name,'span_id':s.context.span_id,'trace_id':s.context.trace_id,'parent_id':s.parent.span_id if s.parent else None,'attributes':dict(s.attributes),'events':[{'name':e.name,'data':dict(e.attributes)} for e in s.events]} for s in spans]
# Independent expected lineage comparison against actual SDK.
byid={s['span_id']:s for s in observations['sdk_spans']};issues=[]
for s in observations['sdk_spans']:
 starts=[e['data'] for e in s['events'] if e['name']=='execution.operation_start']
 for e in starts:
  if e.get('operation_kind')=='memory_extract' and s['parent_id'] is not None:
   parent=byid[s['parent_id']];issues.append({'issue':'background_sdk_span_inherits_foreground','operation':e,'sdk_span':s['span_id'],'parent_name':parent['name'],'parent_span':s['parent_id']})
observations['issues']=issues
assert not observations['workers_remaining'] and observations['global_unchanged'] and observations['exporter_closed']
assert observations['all_chat_spans_closed'] and observations['all_debug_spans_closed'] and observations['correlation_restored']
print(json.dumps(observations,indent=2))
