from pathlib import Path
r=Path('/private/tmp/telem-04/REM-005/builder/candidate')
def edit(p,f):
 p=r/p;s=p.read_text();t=f(s);assert t!=s,p;p.write_text(t)
prefix='packages/friday-telemetry/src/friday_telemetry/'
edit(prefix+'helpers/correlation.py',lambda s:s.replace('from contextvars import ContextVar','from contextvars import Context, ContextVar').replace('    terminal: bool = False','    terminal: bool = False\n    delivery_context: Context = field(default_factory=Context, repr=False)').replace('             accounting: TurnAccounting | None = None) -> Iterator[CorrelationFrame]:','             accounting: TurnAccounting | None = None,\n             delivery_context: Context | None = None) -> Iterator[CorrelationFrame]:').replace('        frame = CorrelationFrame(context, span_id, accounting)','        frame = CorrelationFrame(context, span_id, accounting,\n                                 delivery_context=delivery_context if delivery_context is not None else Context())'))
edit(prefix+'models/execution.py',lambda s:s.replace('    model_validator,','    field_validator,\n    model_validator,').replace('    @model_validator(mode="after")\n    def validate_parent','    @field_validator("schema_version", mode="before")\n    @classmethod\n    def integer_version(cls, value: object) -> object:\n        if type(value) is not int:\n            raise ValueError("schema version requires an integer")\n        return value\n\n    @model_validator(mode="after")\n    def validate_parent'))
p='packages/friday-chat/src/friday_chat/'
edit(p+'telemetry.py',lambda s:s.replace('                self._sink.capture_event(event_name, dict(attributes))','                frame = self.correlation.current()\n                if frame is None:\n                    self._sink.capture_event(event_name, dict(attributes))\n                else:\n                    frame.delivery_context.run(self._sink.capture_event, event_name, dict(attributes))').replace('                sink_id = self._sink.start_span(\n                    name, self._spans.get(parent_id) if parent_id else None\n                )','                sink_parent = self._spans.get(parent_id) if parent_id else None\n                frame = self.correlation.current()\n                sink_id = (self._sink.start_span(name, sink_parent) if frame is None else\n                           frame.delivery_context.run(self._sink.start_span, name, sink_parent))').replace('                self._sink.end_span(sink_id, attributes)','                frame = self.correlation.current()\n                if frame is None:\n                    self._sink.end_span(sink_id, attributes)\n                else:\n                    frame.delivery_context.run(self._sink.end_span, sink_id, attributes)'))
edit(p+'turns/telemetry.py',lambda s:s.replace('from collections.abc import Iterator','from collections.abc import AsyncIterator, Iterator').replace('from contextlib import contextmanager','from contextlib import asynccontextmanager, contextmanager\nfrom contextvars import Context').replace('from dataclasses import dataclass','from dataclasses import dataclass\nfrom enum import Enum').replace('from typing import TYPE_CHECKING, Literal','from typing import TYPE_CHECKING, Literal, Protocol, runtime_checkable').replace('    span = observer.start_span("chat.turn")','    parent = observer.correlation.current()\n    delivery = parent.delivery_context.copy() if parent is not None else Context()').replace('    with observer.correlation.bind(context, span_id=span, accounting=accounting):','    with observer.correlation.bind(context, accounting=accounting, delivery_context=delivery) as frame:\n        span = observer.start_span("chat.turn", parent.span_id if parent is not None else None)\n        frame.span_id = span').replace('@contextmanager\ndef operation_scope','class _InheritedOrigin(Enum):\n    INHERIT = "inherit"\n\n\n@contextmanager\ndef operation_scope').replace('*, origin: ExecutionContext | None = None)', '*, origin: ExecutionContext | None | _InheritedOrigin = _InheritedOrigin.INHERIT)').replace('    parent = observer.correlation.current()\n    if origin is not None and not observer.correlation.accepts(origin):','    parent = observer.correlation.current() if origin is _InheritedOrigin.INHERIT else None\n    if isinstance(origin, ExecutionContext) and not observer.correlation.accepts(origin):').replace('    context = (origin or (parent.context if parent else observer.correlation.context())).child()','    base = origin if isinstance(origin, ExecutionContext) else parent.context if parent else observer.correlation.context()\n    context = base.child()').replace('    span = observer.start_span("chat.operation", parent.span_id if parent and origin is None else None)\n    accounting = parent.accounting if parent and origin is None else None\n    with observer.correlation.bind(context, span_id=span, accounting=accounting):','    accounting = parent.accounting if parent is not None else None\n    delivery = parent.delivery_context.copy() if parent is not None else Context()\n    with observer.correlation.bind(context, accounting=accounting, delivery_context=delivery) as frame:\n        span = observer.start_span("chat.operation", parent.span_id if parent is not None else None)\n        frame.span_id = span')+'''\n\n@runtime_checkable\nclass AsyncIteratorClosure(Protocol):\n    """Optional declared cleanup capability of an acquired model iterator."""\n\n    async def aclose(self) -> None: ...\n\n\n@asynccontextmanager\nasync def closing_stream[T](iterator: AsyncIterator[T]) -> AsyncIterator[AsyncIterator[T]]:\n    """Await owned iterator cleanup without replacing an active primary exception."""\n    primary = False\n    try:\n        yield iterator\n    except BaseException:\n        primary = True\n        raise\n    finally:\n        if isinstance(iterator, AsyncIteratorClosure):\n            try:\n                await iterator.aclose()\n            except BaseException:\n                if not primary:\n                    raise\n''')
edit(p+'tools/loop.py',lambda s:s.replace('"selected_native": 0, "selected_mcp": 0, "rejected_native": 1,\n                                    "rejected_mcp": 0,','"selected_native": 0, "selected_mcp": 0,\n                                    "rejected_native": int(not (isinstance(name, str) and name in mcp_names)),\n                                    "rejected_mcp": int(isinstance(name, str) and name in mcp_names),'))
edit(p+'turns/processor.py',lambda s:s.replace('from friday_chat.turns.telemetry import operation_scope, turn_scope','from friday_chat.turns.telemetry import closing_stream, operation_scope, turn_scope').replace('''                    async for chunk in self._runtime.chat_llm.stream_complete(
                        prepared.messages,
                        tools=(),
                    ):
                        if not assistant_chunks:
                            stop_heartbeat_once()
                        assistant_chunks.append(chunk)
                        await on_chunk(chunk)''','''                    iterator = aiter(self._runtime.chat_llm.stream_complete(prepared.messages, tools=()))
                    async with closing_stream(iterator):
                        async for chunk in iterator:
                            if not assistant_chunks:
                                stop_heartbeat_once()
                            assistant_chunks.append(chunk)
                            await on_chunk(chunk)'''))
def adapters(s):
 s=s.replace('from friday_chat.turns.telemetry import operation_scope','from friday_chat.turns.telemetry import closing_stream, detached_scope, operation_scope')
 s=s.replace('''            async for chunk in self.service.chat_completion_stream(
                messages=message_values,
                tools=tool_values,
                temperature=self.execution.temperature,
                max_tokens=self.execution.max_tokens,
                timeout=self.config.llm.timeout_seconds,
            ):
                yield chunk''','''            iterator = aiter(self.service.chat_completion_stream(
                messages=message_values,
                tools=tool_values,
                temperature=self.execution.temperature,
                max_tokens=self.execution.max_tokens,
                timeout=self.config.llm.timeout_seconds,
            ))
            async with closing_stream(iterator):
                async for chunk in iterator:
                    yield chunk''')
 start=s.index('        async for event in self.service.chat_completion_events(request):');end=s.index('\n\n\n@dataclass\nclass FrameworkEmbeddingService',start)
 block=s[start:end].replace('        async for event in self.service.chat_completion_events(request):','        async for event in iterator:')
 s=s[:start]+'        iterator = aiter(self.service.chat_completion_events(request))\n        async with closing_stream(iterator):\n'+''.join('    '+line+'\n' for line in block.splitlines()).rstrip()+s[end:]
 s=s.replace('with operation_scope(self.observer, "memory_extract", origin=','with detached_scope(self.observer), operation_scope(self.observer, "memory_extract", origin=')
 return s
edit(p+'adapters.py',adapters)
print('Seven authorized source files modified in private snapshot')
