import run,json
root,receipt=run.h.prepare('frozen-baseline','1547fae7cac6450ec9ad7440f19d1f1162598fe2')
for name in ['fake_probe.py','tools_reasoning_probe.py','closure_probe.py','schema_probe.py']:
 run.run('baseline-'+name[:-3],['python',str(run.OUT/name)],root)
for label,args in [('board-validate',['python','scripts/friday-dev-board.py','validate']),('board-next',['python','scripts/friday-dev-board.py','next']),('board-show',['python','scripts/friday-dev-board.py','show','friday-telemetry-rewire'])]:run.run(label,args)
