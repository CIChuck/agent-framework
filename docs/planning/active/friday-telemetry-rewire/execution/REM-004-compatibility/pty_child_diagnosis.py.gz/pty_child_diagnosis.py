import ast,subprocess,sys,textwrap
from pathlib import Path
source=Path('packages/friday-chat/tests_chat/test_reorganization_terminal.py').read_text()
tree=ast.parse(source)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_provider_free_pty'))
call=next(n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='dedent')
script=textwrap.dedent(call.args[0].value)
r=subprocess.run([sys.executable,'-c',script],input=b'G',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
print('Exact child diagnostic exit',r.returncode);print(r.stdout.decode());sys.exit(r.returncode)
