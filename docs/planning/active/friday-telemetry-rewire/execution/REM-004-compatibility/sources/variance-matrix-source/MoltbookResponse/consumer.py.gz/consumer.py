from original import MoltbookResponse as Original
from converted import MoltbookResponse as Converted
from pydantic import BaseModel
class Parent(BaseModel):
    value: str
class Child(Parent):
    extra: int
def original_parent_to_child(value: Original[Parent]) -> Original[Child]:
    return value

def original_child_to_parent(value: Original[Child]) -> Original[Parent]:
    return value

def converted_parent_to_child(value: Converted[Parent]) -> Converted[Child]:
    return value

def converted_child_to_parent(value: Converted[Child]) -> Converted[Parent]:
    return value
