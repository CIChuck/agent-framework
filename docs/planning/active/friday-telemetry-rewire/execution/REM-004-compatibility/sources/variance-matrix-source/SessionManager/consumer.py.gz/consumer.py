from original import SessionManager as Original
from converted import SessionManager as Converted
class Parent: pass
class Child(Parent): pass
def original_parent_to_child(value: Original[Parent]) -> Original[Child]:
    return value

def original_child_to_parent(value: Original[Child]) -> Original[Parent]:
    return value

def converted_parent_to_child(value: Converted[Parent]) -> Converted[Child]:
    return value

def converted_child_to_parent(value: Converted[Child]) -> Converted[Parent]:
    return value
