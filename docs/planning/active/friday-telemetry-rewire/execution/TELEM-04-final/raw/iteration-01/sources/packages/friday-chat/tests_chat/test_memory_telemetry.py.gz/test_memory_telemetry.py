import asyncio

import pytest
from friday_chat.adapters import FrameworkMaintenanceAdapter, FrameworkMemoryAdapter
from friday_chat.background import BackgroundTaskManager, BackgroundWorkCoordinator
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import PendingExtractionTurn, build_runtime
from friday_chat.telemetry import ChatTelemetryObserver
from friday_chat.turns.processor import TurnProcessor
from friday_chat.turns.telemetry import turn_scope
from friday_memory import ExtractionCommitCompletedUnderCancellation


def config():
    return FridayChatConfig.model_validate({"llm": {"model": "fake/test"}, "tools": {"enabled": False},
        "telemetry": {"enabled": True}, "extraction": {"interval": -1}})


@pytest.mark.asyncio
@pytest.mark.parametrize("mode", ["success", "failure", "cancel", "committed_cancel", "none"])
async def test_mixed_origins_and_existing_requeue_truth(mode):
    o = ChatTelemetryObserver(enabled=True, session_id="private")
    origins = [o.correlation.context(turn=True), o.correlation.context(turn=True)]
    seen = []
    class Extractor:
        async def extract(self, turn):
            seen.append(o.correlation.current().context.turn_ref)
            if len(seen) == 1:
                if mode == "failure":
                    raise RuntimeError("PRIVATE_FAILURE")
                if mode == "cancel":
                    raise asyncio.CancelledError()
                if mode == "committed_cancel":
                    raise ExtractionCommitCompletedUnderCancellation()
            return {}
    adapter = FrameworkMaintenanceAdapter(config(), "private", None, None, None, {}, {},
        extractor=None if mode == "none" else Extractor(), observer=o)
    adapter.pending_extraction = [PendingExtractionTurn(str(i), "PRIVATE_U", "PRIVATE_A", origin) for i, origin in enumerate(origins)]
    try:
        await adapter.extract_buffered_turns(trigger_reason="safe")
    except (RuntimeError, asyncio.CancelledError):
        pass
    if mode in {"success", "none"}:
        assert not adapter.pending_extraction
    else:
        assert [t.turn_id for t in adapter.pending_extraction] == (["1"] if mode == "committed_cancel" else ["0", "1"])
    finishes = [dict(e.attributes) for e in o.snapshot().events if e.name == "execution.operation_finish"]
    assert finishes[0]["turn_ref"] == origins[0].turn_ref
    if mode == "committed_cancel":
        assert finishes[0]["outcome"] == "cancelled" and finishes[0]["persistence_state"] == "completed"
    elif mode == "none":
        assert all(e["outcome"] == "skipped" and e["count"] == 0 for e in finishes)
    elif mode == "success":
        assert [e["turn_ref"] for e in finishes] == [c.turn_ref for c in origins]
    assert o.correlation.current() is None and not o._spans
    assert "PRIVATE_U" not in repr(o.snapshot())


@pytest.mark.asyncio
async def test_ingestion_count_and_background_handoff():
    r = build_runtime(config())
    result = await TurnProcessor(r).process("safe")
    manager = BackgroundTaskManager()
    coordinator = BackgroundWorkCoordinator(r, manager)
    coordinator.schedule_after_turn(turn_count=1, user_message="private", assistant_message="private", correlation_context=result.correlation_context)
    assert r.maintenance.pending_extraction[0].correlation_context is result.correlation_context
    observed = []
    async def background():
        observed.append(r.telemetry.correlation.current())
    with turn_scope(r.telemetry, "completion"):
        await coordinator._run_shared("synthetic", background)
        assert r.telemetry.correlation.current() is not None
    assert observed == [None]
    await manager.close()
    class Controller:
        async def store_document(self, *args, **kwargs):
            return None
    a = FrameworkMemoryAdapter(Controller(), None, config(), "private", None, None, observer=r.telemetry)
    assert await a.ingest_document(source_path="PRIVATE_PATH", description="PRIVATE", content="PRIVATE_DOC") == 1
    finish = next(dict(e.attributes) for e in reversed(r.telemetry.snapshot().events)
                  if e.name == "execution.operation_finish")
    assert finish["count"] == 1 and "turn_ref" not in finish
    assert "PRIVATE_PATH" not in repr(r.telemetry.snapshot())
