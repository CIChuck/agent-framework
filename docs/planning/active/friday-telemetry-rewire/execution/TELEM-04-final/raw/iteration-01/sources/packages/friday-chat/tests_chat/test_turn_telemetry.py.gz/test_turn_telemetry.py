import asyncio
from uuid import uuid4

import pytest
from friday_chat.config import FridayChatConfig
from friday_chat.runtime import (
    FakeChatModel,
    build_runtime,
)
from friday_chat.turns.models import ChatModelResponse, ToolCallRequest
from friday_chat.turns.processor import TurnProcessor
from friday_telemetry.models.llm_events import RequestStart


def runtime(*, tools=False, enabled=True):
    return build_runtime(FridayChatConfig.model_validate({"llm": {"model": "fake/test", "timeout_seconds": 0.01},
        "tools": {"enabled": tools}, "telemetry": {"enabled": enabled},
        "transcript": {"capture_raw_prompts": True}}))


def events(r, name):
    return [dict(e.attributes) for e in r.telemetry.snapshot().events if e.name == "execution." + name]


@pytest.mark.asyncio
@pytest.mark.parametrize("streaming", [False, True])
async def test_whole_turn_links_and_persistence(streaming):
    r = runtime()
    class Model(FakeChatModel):
        async def complete(self, messages, *, tools=()):
            event = RequestStart(request_id=uuid4().hex, model_ref=uuid4().hex,
                                 operation="chat", api="legacy_completion", service_role="primary")
            r.telemetry.capture_event(event.name, event.attributes())
            return await super().complete(messages, tools=tools)
    r.chat_llm = Model("fake")
    chunks = []
    async def capture(chunk):
        chunks.append(chunk)
    p = TurnProcessor(r)
    result = await p.process_streaming("PRIVATE_PROMPT", on_chunk=capture) if streaming else await p.process("PRIVATE_PROMPT")
    start, = events(r, "turn_start")
    finish, = events(r, "turn_finish")
    link, = events(r, "llm_link")
    assert finish["outcome"] == "succeeded" and finish["persistence"] == "completed"
    assert start["turn_ref"] == finish["turn_ref"] == link["turn_ref"] == result.correlation_context.turn_ref
    assert link["operation_ref"] in {e["operation_ref"] for e in events(r, "operation_start")}
    assert r.telemetry.correlation.current() is None and not r.telemetry._spans
    assert "PRIVATE_PROMPT" not in repr(r.telemetry.snapshot())
    if streaming:
        assert "".join(chunks) == result.assistant_message


@pytest.mark.asyncio
@pytest.mark.parametrize("stage", ["retrieve", "model", "record_turn", "record_context_log", "record_interaction", "speech"])
@pytest.mark.parametrize("cancel", [False, True])
async def test_failures_at_each_boundary_preserve_primary(stage, cancel):
    r = runtime()
    class Unprintable(RuntimeError):
        def __str__(self):
            raise AssertionError("must not stringify")
    error = asyncio.CancelledError() if cancel else Unprintable()
    async def fail(*args, **kwargs):
        raise error
    if stage == "retrieve":
        r.memory.retrieve = fail
    elif stage == "model":
        r.chat_llm.complete = fail
    elif stage == "speech":
        r.speech.speak = fail
    else:
        setattr(r.transcript, stage, fail)
    with pytest.raises(BaseException):
        await TurnProcessor(r).process("PRIVATE")
    terminal, = events(r, "turn_finish")
    assert terminal["outcome"] == ("cancelled" if cancel else "failed")
    assert terminal["persistence"] == ("completed" if stage == "speech" else "not_started" if stage in {"retrieve", "model"} else "cancelled" if cancel else "failed")
    assert r.telemetry.correlation.current() is None and not r.telemetry._spans
    assert not any(e["outcome"] == "succeeded" for e in events(r, "turn_finish"))


@pytest.mark.asyncio
async def test_block_timeout_callback_and_disabled():
    r = runtime()
    with pytest.raises(Exception):
        await TurnProcessor(r, circuit_breaker_open=True).process("safe")
    assert events(r, "turn_finish")[0]["outcome"] == "blocked"
    r = runtime()
    r.chat_llm.delay_seconds = 0.1
    with pytest.raises(Exception):
        await TurnProcessor(r).process("safe")
    assert events(r, "turn_finish")[0]["reason"] == "timeout"
    r = runtime()
    async def bad_chunk(chunk):
        raise RuntimeError("PRIVATE_CALLBACK")
    with pytest.raises(RuntimeError):
        await TurnProcessor(r).process_streaming("safe", on_chunk=bad_chunk)
    assert events(r, "turn_finish")[0]["outcome"] == "failed"
    disabled = runtime(enabled=False)
    result = await TurnProcessor(disabled).process("safe")
    assert result.correlation_context is None and not events(disabled, "turn_start")


@pytest.mark.asyncio
async def test_native_followup_reasoning_and_concurrent_turns():
    r = runtime(tools=True)
    r.chat_llm = FakeChatModel("fake", responses=[ChatModelResponse(
        tool_calls=(ToolCallRequest("echo", {"text": "safe"}, "RAW_CALL"),), reasoning_content="PRIVATE_REASONING"),
        ChatModelResponse.from_text("done")])
    await TurnProcessor(r).process("echo")
    reason, = events(r, "reasoning_history")
    assert reason["present"] and reason["preserved"] and reason["eligible"]
    assert events(r, "turn_finish")[0]["completed_tools"] == 1
    assert "PRIVATE_REASONING" not in repr(r.telemetry.snapshot())
    r = runtime()
    r.chat_llm.delay_seconds = 0.001
    await asyncio.gather(TurnProcessor(r).process("one"), TurnProcessor(r).process("two"))
    refs = {e["turn_ref"] for e in events(r, "turn_finish")}
    assert len(refs) == 2
    assert {e["turn_ref"] for e in events(r, "operation_finish")} == refs
    assert not r.telemetry._spans


@pytest.mark.asyncio
async def test_public_iterator_holds_no_scope_at_yield():
    r = runtime()
    iterator = TurnProcessor(r).stream_process("safe")
    await anext(iterator)
    assert r.telemetry.correlation.current() is None and not r.telemetry._spans
    await iterator.aclose()
