from pathlib import Path
import ast,hashlib,json,subprocess,sys,tomllib,yaml

repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
out=Path('/private/tmp/telem-04/construction');root=out/sys.argv[1];label=sys.argv[2]
pkt='docs/planning/active/friday-telemetry-rewire/'
m=json.loads((root/pkt/'authority-manifest-TELEM-04.yaml').read_text());base=m['base']
sha=lambda data:hashlib.sha256(data).hexdigest()
historical=lambda p:subprocess.check_output(['git','--no-optional-locks','-C',str(repo),'show',base+':'+p])
controls={}
for manifest in ['authority-manifest.yaml','authority-manifest-TELEM-02.yaml','authority-manifest-TELEM-03.yaml','authority-manifest-TELEM-04.yaml']:
    data=yaml.safe_load((root/pkt/manifest).read_text())
    for pin in data['authority']:
        if sha((root/pin['path']).read_bytes())!=pin['sha256'] or sha((repo/pin['path']).read_bytes())!=pin['sha256']:
            raise RuntimeError('Authority drift '+pin['path'])
    controls[manifest]={'pins':len(data['authority']),'sha256':sha((root/pkt/manifest).read_bytes())}
def signatures(data):
    tree=ast.parse(data,feature_version=(3,13));result={}
    def walk(nodes,prefix=''):
        for n in nodes:
            if isinstance(n,ast.ClassDef):walk(n.body,prefix+n.name+'.')
            elif isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and (not n.name.startswith('_') or n.name=='__init__'):
                result[prefix+n.name]=n.args
    walk(tree.body);return result
optional=[]
for p in m['product_manifest']['existing_source']:
    before=signatures(historical(p));after=signatures((root/p).read_bytes())
    for name,args in before.items():
        if name not in after:raise RuntimeError('Removed public API '+p+':'+name)
        now=after[name]
        if [a.arg for a in args.posonlyargs+args.args]!=[a.arg for a in now.posonlyargs+now.args]:raise RuntimeError('Positional drift '+name)
        if ast.dump(ast.Module(body=args.defaults,type_ignores=[]))!=ast.dump(ast.Module(body=now.defaults,type_ignores=[])):raise RuntimeError('Positional default drift '+name)
        old={a.arg:ast.unparse(d) if d is not None else None for a,d in zip(args.kwonlyargs,args.kw_defaults,strict=True)}
        new={a.arg:ast.unparse(d) if d is not None else None for a,d in zip(now.kwonlyargs,now.kw_defaults,strict=True)}
        if any(new.get(k)!=v for k,v in old.items()):raise RuntimeError('Keyword default drift '+name)
        added={k:v for k,v in new.items() if k not in old}
        if any(k not in ['observer','correlation_context'] or v!='None' for k,v in added.items()):raise RuntimeError('Unapproved keyword '+name)
        if added:optional.append({'path':p,'method':name,'optional_keywords':added})
tracked=subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','--name-only',base]).decode().splitlines()
unchanged=[p for p in tracked if (p.startswith('packages/friday-llm/src/') or p.startswith('packages/friday-mcp/src/') or p=='packages/friday-chat/src/friday_chat/turns/memory_mcp.py' or p.startswith('packages/friday-telemetry/src/friday_telemetry/models/mcp') or p.endswith('friday_telemetry/interface.py'))]
metadata=[p for p in tracked if p.endswith('pyproject.toml')]
if len(metadata)!=18:raise RuntimeError('Metadata inventory drift')
for p in metadata:
    if tomllib.loads((root/p).read_text())['project']['requires-python']!='>=3.13.4':raise RuntimeError('Python floor drift')
unchanged+=metadata+['uv.lock','packages/friday-chat/config.example.yaml','packages/friday-chat/src/friday_chat/config_templates/config.example.yaml']
for p in unchanged:
    if (root/p).read_bytes()!=historical(p):raise RuntimeError('Unapproved accepted boundary/dependency change '+p)
q=json.loads((out/'gate-paths.json').read_text())
for p in q['aggregate_python']:ast.parse((root/p).read_bytes(),feature_version=(3,13))
for p in q['unit_python']:
    if p in tracked:
        a=historical(p).decode().splitlines();b=(root/p).read_text().splitlines()
    else:a=[];b=(root/p).read_text().splitlines()
    suppressions=lambda lines:[s.strip() for s in lines if any(t in s for t in ['noqa','type: ignore','mypy: ignore','pytest.mark.skip','pytest.skip('])]
    if suppressions(a)!=suppressions(b):raise RuntimeError('Suppression/skip drift '+p)
preserved=json.loads(Path('/private/tmp/telem-04/planning/unrelated-before.json').read_text())
for p,digest in preserved.items():
    path=repo/p
    if digest is None:
        if path.exists():raise RuntimeError('Deleted original restored '+p)
    elif sha(path.read_bytes())!=digest:raise RuntimeError('Unrelated dirty bytes changed '+p)
clean=yaml.safe_load(Path('/private/tmp/telem-04/approved/clean-board.yaml').read_text());live=yaml.safe_load((repo/'docs/planning/board.yaml').read_text())
extra=json.loads(Path('/private/tmp/telem-04/approved/unrelated-board-objects.json').read_text())
if {k:[v for v in live[k] if v not in clean[k]] for k in ['tasks','events']}!=extra:raise RuntimeError('Unrelated board object drift')
(out/(label+'-contracts.json')).write_text(json.dumps({'authority':controls,'public_optional_keywords':optional,'unchanged_sources_and_metadata':unchanged,'aggregate_ast_count':len(q['aggregate_python']),'preserved_unrelated':preserved,'unrelated_board_objects_unchanged':True,'new_suppressions':[]},indent=2)+'\n')
print('Contract/API/AST/privacy-boundary/dependency/preservation PASS')
