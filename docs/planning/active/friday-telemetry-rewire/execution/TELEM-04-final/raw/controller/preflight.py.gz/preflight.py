from pathlib import Path
import ast,hashlib,json,sys
out=Path('/private/tmp/telem-04/construction');root=out/sys.argv[1];p='docs/planning/active/friday-telemetry-rewire/';sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
m=json.loads((root/p/'authority-manifest-TELEM-04.yaml').read_text())
for pin in m['authority']:
 if sha(root/pin['path'])!=pin['sha256']:raise RuntimeError('Control drift '+pin['path'])
effects=json.loads((root/p/'execution/TELEM-04-planning/listener-scope.json').read_text())
for path,digest in effects['fixture_hashes'].items():
 if sha(root/path)!=digest:raise RuntimeError('Listener fixture drift')
new={}
for path in m['product_manifest']['new_tests']:
 tree=ast.parse((root/path).read_text());imports=[ast.unparse(n) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))];calls=sorted({ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n,ast.Call)})
 if any(any(s in v for s in ['grpc.','OTel','create_telemetry','socket.','HTTPServer','Chroma','os.environ']) for v in imports+calls):raise RuntimeError('Extra fixture effects')
 new[path]=dict(sha256=sha(root/path),imports=imports,calls=calls,effects='fake-only, in-memory; no listener/provider/SDK construction')
conftests={str(path.relative_to(root)):sha(path) for path in root.rglob('conftest.py') if '.git' not in path.parts}
(out/(sys.argv[1]+'-preflight.json')).write_text(json.dumps(dict(authority_pins=40,approved_record_sha256=sha(root/p/'directives/CD-004-approval-record.md'),listeners=effects,new_tests=new,conftests=conftests,guard_sha256=sha(Path('/private/tmp/telem-01/REM-001/network-guard/sitecustomize.py')),normal_user_loopback_scope='13 named existing nodes; no extra listeners; native grpc retries/proxy disabled and literal127.0.0.1 finite owned cleanup checked in frozen fixture source'),indent=2)+'\n')
print('Preflight:40controls,13existing loopback nodes,sixfake new modules')
