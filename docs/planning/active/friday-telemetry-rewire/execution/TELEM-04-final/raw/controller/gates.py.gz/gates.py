from pathlib import Path
import importlib.util,json,sys
spec=importlib.util.spec_from_file_location('runner','/private/tmp/telem-02/builder-execution/runner.py');x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x)
x.OUT=Path('/private/tmp/telem-04/construction');x.helper.OUT=x.OUT;original=x.helper.environment
def environment(root,label):
 env=original(root,label);env['PYTHONPATH']+=':'+str(x.OUT);return env
x.helper.environment=environment
p=json.loads((x.OUT/'unit-paths.json').read_text());ignore=['--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py']
commands={'new':['pytest',*p['new_tests'],'-rA'],'unit-mypy':['mypy','--python-version','3.13',*p['source']],'unit-ruff':['ruff','check',*p['python']],
 'package':['pytest','packages/friday-chat/tests_chat','packages/friday-llm/tests_llm','packages/friday-telemetry/tests_telemetry',*ignore,'-rA'],
 'collect':['pytest','--import-mode=importlib',*ignore,'--collect-only'],
 'root':['pytest','--import-mode=importlib',*ignore,'-rA'],
 'root-ruff':['ruff','check','.','--output-format','json']}
if (x.OUT/'gate-paths.json').exists():
 q=json.loads((x.OUT/'gate-paths.json').read_text());commands.update({'aggregate-ruff':['ruff','check',*q['aggregate_python']],'aggregate-mypy':['mypy','--python-version','3.13',*q['aggregate_source']],'owning':['pytest','--import-mode=importlib',*q['owning_trees'],*ignore,'-rA']})
sys.exit(x.run(sys.argv[1],sys.argv[2],commands[sys.argv[3]]))
