"""Owned actual SDK consumer; patched dispatch, no global registration or channel."""
import asyncio
from collections import Counter
import json
from pathlib import Path
import sys
import threading
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch

import litellm

async def forbidden(**kwargs):
    raise RuntimeError('Unexpected provider dispatch')
litellm.acompletion = forbidden
litellm.aembedding = forbidden
from friday_chat.adapters import FrameworkChatModel
from friday_chat.config import FridayChatConfig, LegacyLLMExecutionConfig
from friday_chat.runtime import build_runtime
from friday_chat.turns.processor import TurnProcessor
from friday_chat.turns.telemetry import operation_scope, turn_scope
from friday_llm import LiteLLMService, ResilienceConfig
from friday_telemetry import CompositeProvider, DebugTelemetryRecorder, OTelConfig, TelemetryFactoryConfig, create_telemetry
from opentelemetry import trace
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
from friday_telemetry.providers import _otel_exporter

secret='PRIVATE_SDK_CONTENT_SENTINEL'
recorded=[]
exporters=[]
initial=set(threading.enumerate())
global_before=trace.get_tracer_provider()
class Recording(SpanExporter):
    def __init__(self, stream):
        self.closed=False
        exporters.append(self)
    def export(self, batch):
        recorded.extend(batch)
        return SpanExportResult.SUCCESS
    def shutdown(self):
        self.closed=True

raw=NS(choices=[NS(message=NS(content=secret, reasoning_content=secret, tool_calls=[]),finish_reason='stop')],
       usage=NS(prompt_tokens=3,completion_tokens=4,total_tokens=7),model=secret,id=secret)
async def main():
    with patch.object(_otel_exporter,'SafeConsoleExporter',Recording), patch.object(trace,'set_tracer_provider',side_effect=RuntimeError('No global registration')):
        handle=create_telemetry(TelemetryFactoryConfig(provider='otel',otel=OTelConfig(exporter='console')))
        try:
            debug=DebugTelemetryRecorder()
            composite=CompositeProvider([debug,handle.telemetry])
            config=FridayChatConfig.model_validate({'llm':{'model':'fake/test'},'tools':{'enabled':False},'telemetry':{'enabled':True}})
            runtimes=[build_runtime(config,telemetry=composite) for _ in range(2)]
            for runtime in runtimes:
                runtime.chat_llm=FrameworkChatModel(LiteLLMService(model_name='gpt-4',telemetry=runtime.telemetry,resilience=ResilienceConfig(max_retries=0)),config,LegacyLLMExecutionConfig(0.0,None,None))
            observer=runtimes[0].telemetry
            with patch.object(litellm,'acompletion',AsyncMock(return_value=raw)) as dispatch:
                results=await asyncio.gather(*(TurnProcessor(runtime).process(secret) for runtime in runtimes))
                assert len({r.correlation_context.turn_ref for r in results})==2
                assert dispatch.await_count==2
                with turn_scope(observer,'completion'):
                    outer=observer.correlation.current()
                    with operation_scope(observer,'model_call'):
                        parent=observer.correlation.current()
                        with operation_scope(observer,'memory_retrieve'):
                            assert observer.correlation.current().context.parent_operation_ref==parent.context.operation_ref
                            await asyncio.sleep(0)
                        assert observer.correlation.current() is parent
                    assert observer.correlation.current() is outer
                    await TurnProcessor(runtimes[0]).process(secret)
                    assert observer.correlation.current() is outer
                assert observer.correlation.current() is None
                # A delayed item carries causal identity, never a closed SDK parent.
                with operation_scope(observer,'memory_extract',origin=results[0].correlation_context) as fact:
                    fact.count=1;fact.count_kind='turns';fact.persistence_state='completed'
                # Accepted originals outside execution retain their old behavior without links.
                links_before=len(debug.get_all_events('execution.llm_link'))
                await runtimes[0].chat_llm.service.chat_completion([{'role':'user','content':secret}])
                assert len(debug.get_all_events('execution.llm_link'))==links_before
            assert all(runtime.telemetry.correlation.current() is None and not runtime.telemetry._spans for runtime in runtimes)
            assert handle.flush().status=='success'
            assert trace.get_tracer_provider() is global_before
            sdk_events=[(e.name,dict(e.attributes)) for span in recorded for e in span.events]
            expected=[(e.name,e.data) for e in debug.events]
            canonical=lambda pairs:Counter(json.dumps([n,d],sort_keys=True) for n,d in pairs)
            assert canonical(sdk_events)==canonical(expected)
            sdk_ids={span.context.span_id for span in recorded}
            assert all(span.parent is None or span.parent.span_id in sdk_ids for span in recorded)
            operation_spans=[span for span in recorded if span.name=='chat.operation']
            extraction=next(span for span in operation_spans if any(e.name=='execution.operation_start' and e.attributes['operation_kind']=='memory_extract' for e in span.events))
            assert extraction.parent is None
            assert any(span.parent is not None for span in operation_spans)
            assert all(span.end_time is not None for span in debug.spans.values())
            assert len(debug.get_all_events('execution.turn_start'))==len(debug.get_all_events('execution.turn_finish'))==4
            assert len(debug.get_all_events('execution.llm_link'))==3
            serialized=json.dumps({'events':sdk_events,'sdk_spans':[{'name':s.name,'attributes':dict(s.attributes)} for s in recorded],
                'diagnostics':[str(r.telemetry.execution_snapshot()) for r in runtimes]})
            assert secret not in serialized
            result={'sdk_event_count':len(sdk_events),'exported_spans':len(recorded),'correlated_requests':3,'turns':4,
                'scalars_match_debug_and_composite':True,'nested_concurrent_context_restored':True,'detached_origin_has_no_closed_sdk_parent':True,
                'global_provider_unchanged':True,'raw_content_absent':True,'events':sdk_events,
                'span_tree':[{'name':s.name,'span_id':s.context.span_id,'parent':s.parent.span_id if s.parent else None,'attributes':dict(s.attributes)} for s in recorded]}
        finally:
            closed=handle.shutdown()
            if closed.status!='success' or handle.snapshot().worker_alive:
                raise RuntimeError('Owned shutdown failed')
    assert all(e.closed for e in exporters)
    assert not [t for t in threading.enumerate() if t not in initial and t.name=='FridayTelemetryExporter']
    result.update(owned_exporters_closed=True,owned_workers_remaining=False,transport_channels_created=0,borrowed_sink_not_closed_by_observer=True)
    Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
    print('ACTUAL SDK PASS',result['sdk_event_count'],'events',result['exported_spans'],'spans; owned worker closed')
asyncio.run(main())
