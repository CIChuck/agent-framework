from pathlib import Path
import hashlib,json,subprocess
repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');out=Path('/private/tmp/telem-04/construction');pkt='docs/planning/active/friday-telemetry-rewire/'
git=lambda *args,**kw:subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-C',str(repo),*args],**kw)
if git('diff','--cached','--name-only').strip():raise RuntimeError('Index not empty')
paths=json.loads((out/'actual-product-paths.json').read_text())+[pkt+'README.md',pkt+'execution-log.md']
for folder in ['validation/CDR-019','execution/TELEM-04-baseline']:
    paths += [str(p.relative_to(repo)) for p in (repo/pkt/folder).rglob('*') if p.is_file()]
git('add','--',*sorted(paths))
for name in ['board.yaml','README.md']:
    data=(Path('/private/tmp/telem-04/approved')/('clean-'+name)).read_bytes();digest=git('hash-object','-w','--stdin',input=data).decode().strip();git('update-index','--cacheinfo','100644',digest,'docs/planning/'+name)
staged=git('diff','--cached','--name-only').decode().splitlines()
if set(staged)!=set(paths+['docs/planning/board.yaml','docs/planning/README.md']):raise RuntimeError('Staged scope drift')
git('diff','--cached','--check')
previous=git('rev-parse','HEAD').decode().strip();git('commit','-q','-m','Add correlated Chat execution telemetry and diagnostics');candidate=git('rev-parse','HEAD').decode().strip()
(out/'candidate.json').write_text(json.dumps({'candidate':candidate,'previous':previous,'product_paths':json.loads((out/'actual-product-paths.json').read_text()),'commit_paths':staged,'local_only':True},indent=2)+'\n')
print('Stable candidate',candidate,'product paths',21,'all exact owned commit paths',len(staged))
