from pathlib import Path
import datetime
import difflib
import gzip
import hashlib
import importlib.util
import json
import subprocess
import sys
import yaml

repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
out=Path('/private/tmp/telem-04/planning')
pkt=repo/'docs/planning/active/friday-telemetry-rewire'
dest=pkt/'execution/TELEM-04-planning';dest.mkdir(parents=True,exist_ok=True)
archive=repo/'docs/archive/completed/2026/friday-telemetry-rewire-telem-03';archive.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
git=lambda *args:subprocess.check_output(['git','--no-optional-locks','-C',str(repo),*args])
base=git('rev-parse','HEAD').decode().strip()
if base!='e6209e3156216afde1655758e280690229f7d3e6':raise RuntimeError('Preparation base changed')
accepted=json.loads((pkt/'authority-manifest-TELEM-03.yaml').read_text())
for pin in accepted['authority']:
 if sha((repo/pin['path']).read_bytes())!=pin['sha256']:raise RuntimeError('Accepted control drift '+pin['path'])
paths=['.DS_Store','family-tree.md','packages/friday-chat/config.example.yaml','packages/friday-sandbox/docker/Dockerfile.audit']
for folder in ['docker-bench-security','docs/planning/queued/friday-tool-manifest-continuity']:
 paths += [str(p.relative_to(repo)) for p in (repo/folder).rglob('*') if p.is_file()]
preserved={p:sha((repo/p).read_bytes()) if (repo/p).is_file() else None for p in paths}
save(out/'unrelated-before.json',preserved)
files=['validation/VAL-008/report.md','validation/VAL-008/stored-artifact-manifest.json','validation/VAL-008/original-raw-artifact-manifest-final.json','validation/VAL-008/raw/report.md.gz','validation/VAL-008/controller-closeout-evidence.json','execution/TELEM-03-final/report.md','execution/TELEM-03-final/artifact-manifest.json','authority-manifest-TELEM-03.yaml']
evidence={
 'work_unit':'TELEM-03','status':'accepted','accepted_by':'Chuck Russell','accepted_date':'2026-10-07','timezone':'America/New_York','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'explicit_response':'lets continue with telem-04',
 'decision_context':'Maintainer explicitly directs progression to TELEM-04 after completed VERIFIED TELEM-03 was explained and acceptance identified as recording sign-off. This records that move-on decision; it is not inferred from validation alone.',
 'product_candidate':'dd543fd6a6819ec0c4fb2529fa384fea886f5509','evidence_closeout_commit':base,'aggregate_base':accepted['aggregate_base'],'verdict':'VERIFIED','authority':accepted['authority'],
 'frozen_evidence':[dict(path=str((pkt/p).relative_to(repo)),sha256=sha((pkt/p).read_bytes())) for p in files],
 'original_reviewer_report_sha256':'602796deea2fffa681820bd0ed68ff67a2fa2f60b9c722d96361b39b51676654',
 'lint_disposition':{'id':'WVR-005','status':'expired after TELEM-03 acceptance','raw_exit':1,'findings':327,'scope_sha256':sha((pkt/'validation/WVR-005-telem03-lint-scope.json').read_bytes()),'historical_coverage':'Accepted TELEM-03 only; no renewal to TELEM-04'},
 'initiative_work_state':'started','delivery_state':'local','next_gate':'approve proposed CD-004 and separately WVR-006; then independent authority review and pre-build baseline'}
save(archive/'acceptance-evidence.json',evidence)
(archive/'README.md').write_text('''# TELEM-03 accepted: safe LLM metrics and role-service injection

Status: accepted work unit. Accepted by Chuck Russell on2026-10-07.
Decision: **"lets continue with telem-04"**, following the verified-result report
and the explanation that acceptance records sign-off before the next unit.
This record attributes acceptance to that explicit progression instruction,
not to independent verification alone.

Product candidate: `dd543fd6a6819ec0c4fb2529fa384fea886f5509`.
Evidence closeout: `e6209e3156216afde1655758e280690229f7d3e6`.
[Exact decision, approved controls and frozen evidence hashes](acceptance-evidence.json).
[Independent VAL-008 VERIFIED](../../../../planning/active/friday-telemetry-rewire/validation/VAL-008/report.md).
[Builder evidence](../../../../planning/active/friday-telemetry-rewire/execution/TELEM-03-final/report.md).
[Continuing initiative](../../../../planning/active/friday-telemetry-rewire/README.md).

Accepted behavior: safe typed/legacy/stream/embedding request/attempt/batch events,
truthful usage/cost provenance and borrowed provider-neutral injection through
Chat role-service factories. Root2,996 and owning2,978 tests passed with the
unchanged optional SciPy skip; Chat/LLM/telemetry1,115 and new105 passed without
skips. Changed-unit/aggregate lint and typing passed. Raw root Ruff remained
exit1 with exactly327 findings under approved WVR-005.

WVR-005 now expires under its existing terms. Frozen approved controls, contracts,
validation reports and raw evidence stay unchanged at their original locations;
no carry-forward authority is granted. REM-004-HIST-01 and REM-004-GENERIC-01
remain maintainer-owned follow-ups. No new product/delivery/live effects occur.
The continuing initiative remains started/local. TELEM-04 planning is authorized;
its new exact construction scope and lint disposition are separate proposals.
''')
close=pkt/'closeout-TELEM-03.md'
text=close.read_text().replace('# TELEM-03 completion proposal','# TELEM-03 accepted closeout').replace('Status: independently VERIFIED; ready for maintainer acceptance,2026-10-07.','Status: independently VERIFIED and accepted by Chuck Russell,2026-10-07.')
start=text.index('TELEM-03 completion is proposed, not accepted.')
text=text[:start]+'''Chuck Russell directed "lets continue with telem-04" after the verified-result
report and acceptance explanation. The archived
[acceptance record](../../../archive/completed/2026/friday-telemetry-rewire-telem-03/README.md)
records that explicit progression decision and exact candidate/evidence hashes.
The continuing initiative stays started/local. WVR-005 expires under its terms;
it supplies no TELEM-04 authority. Next is approval of the prepared CD-004 scope
and separate WVR-006 proposal. No new product or delivery action is authorized
by this closeout record.
'''
close.write_text(text)
index=pkt/'README.md';text=index.read_text()
text=text.replace('next_gate: maintainer acceptance of VERIFIED TELEM-03 candidate dd543fd','next_gate: approve proposed CD-004 and separately WVR-006 for TELEM-04').replace('execution_phase: closeout','execution_phase: preparation').replace('validation_state: verified','validation_state: pending')
start=text.index('Current gate:');end=text.index('\nTELEM-03 construction authority:',start)
text=text[:start]+'''Current gate: TELEM-04 planning is prepared for maintainer scope approval.
The [CD-004 proposal](directives/CD-004-correlated-execution.md),
[execution contract](telem04-contract.md), [verification profile](verification-profile-TELEM-04.md)
and separate [WVR-006 proposal](validation/WVR-006-telem04-lint-disposition.md)
bind29 product targets and the unchanged327 historical lint identities.
[Planning evidence](execution/TELEM-04-planning/report.md) separates static checks
from future behavior/independent review. No TELEM-04 product construction is approved.

TELEM-03 is **accepted** at `dd543fd` under fresh independent VAL-008 VERIFIED
with no findings. Chuck Russell's "lets continue with telem-04", after the result
and acceptance explanation, supplies the progression decision recorded in the
[archive](../../../archive/completed/2026/friday-telemetry-rewire-telem-03/README.md).
WVR-005 expired; no earlier waiver is inherited. The initiative stays started/local
for TELEM-04/05. Header pending describes the new unit, not TELEM-03's verified result.
'''+text[end:]
text=text.replace('[Completion is proposed](closeout-TELEM-03.md); maintainer acceptance\nremains pending.','[Accepted closeout](closeout-TELEM-03.md).')
text=text.replace('only maintainer acceptance remains for this unit. Later-unit construction and\ndelivery require their separate authority.','maintainer acceptance is recorded in the separate archive. Later-unit construction\nand delivery require their separate authority.')
index.write_text(text)
log=pkt/'execution-log.md'
with log.open('a') as f:f.write('''

## 2026-10-07 — TELEM-03 progression accepted; TELEM-04 planning prepared

Chuck Russell instructed "lets continue with telem-04" after the independently
VERIFIED TELEM-03 result and the explanation of acceptance as sign-off. The
separate archived TELEM-03 acceptance record attributes the progression decision
to that instruction and pins product dd543fd, closeout e6209e3 and VAL-008 evidence.
It does not derive acceptance from tests or the validator. WVR-005 expires under
its unchanged terms; all24 frozen controls and earlier accepted units stay fixed.

The same instruction authorizes documentation-only TELEM-04 preparation. Proposed
CD-004 binds12 source,15 test and2 package-doc targets for closed execution events,
turn/model/native-MCP/memory/persistence scopes, background origin handoff, safe
reasoning-history booleans and bounded local diagnostic counters/histograms.
Accepted LLM/MCP events/interfaces and persistence algorithms remain unchanged.
Headless assembly, Langfuse, remote activation and OTel Meter adoption are separate.

Fresh credential-free tracked preparation snapshot at e6209e3 omits267 protected
runtime paths before checkout. Board validate/next/show/render, documentation,
offline lock check and genuine prospective-source Ruff/Mypy pass. Raw root Ruff
exits1 with exactly327 prior identities; source/class/config/archive hashes match.
WVR-006 proposes only that exact new-unit disposition, not an inherited approval.
Planning checks are static, not behavioral baseline or product VERIFIED. No source,
test, config, dependency, actual SDK, listener or provider construction occurred.

Planning-only exemption: authorized maintainer Chuck Russell,2026-10-07, exact
initiative directive/contract/profile/manifest/evidence and board/dashboard/index/
log/TELEM-03 closeout/archive metadata. Runtime behavior cannot change; validate
links, board, manifests, source/accepted-input hashes and unrelated dirty preservation.
Execution_phase preparation; validation_state pending; initiative started/local.
Next gate: explicit CD-004 and separate WVR-006 decision, required independent
approved-authority reconciliation and fake pre-build baseline before source edits.
''')
for name in ['source-inventory.json','lint-comparison.json']:
 (dest/name).write_bytes((out/name).read_bytes())
(pkt/'validation/WVR-006-telem04-lint-scope.json').write_bytes((out/'WVR-006-telem04-lint-scope.json').read_bytes())
effects=json.loads((pkt/'execution/TELEM-03-planning/listener-scope.json').read_text())
effects['status']='proposed for TELEM-04; not approved; no prior effect approval inherited'
effects['effects']=effects['effects'].replace('TELEM03','TELEM04')
save(dest/'listener-scope.json',effects)
spec=importlib.util.spec_from_file_location('boardctl',repo/'scripts/friday-dev-board.py');ctl=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ctl;spec.loader.exec_module(ctl)
boardpath='docs/planning/board.yaml';dashpath='docs/planning/README.md'
clean=yaml.safe_load(git('show','HEAD:'+boardpath));live=yaml.safe_load((repo/boardpath).read_text())
extra_before={k:[v for v in live[k] if v not in clean[k]] for k in ['tasks','events']}
save(out/'planning-dirty-before.json',extra_before)
for b in [clean,live]:
 task=next(t for t in b['tasks'] if t['id']=='friday-telemetry-rewire')
 task['next_gate']='approve proposed CD-004 and separately WVR-006 for TELEM-04'
 for path in ['docs/archive/completed/2026/friday-telemetry-rewire-telem-03/README.md','docs/planning/active/friday-telemetry-rewire/execution/TELEM-04-planning/report.md']:
  if path not in task['validation']:task['validation'].append(path)
 ctl._append_event(b,task_id='friday-telemetry-rewire',action='checkpoint',actor='controller',actor_role='agent',note='Record maintainer-directed TELEM-03 progression acceptance and prepare unapproved CD-004/WVR-006; preserve continuing started/local state.',evidence='docs/archive/completed/2026/friday-telemetry-rewire-telem-03/README.md')
extra_after={k:[v for v in live[k] if v not in clean[k]] for k in ['tasks','events']}
if extra_before!=extra_after:raise RuntimeError('Unrelated board objects changed')
for name,b in [('clean',clean),('live',live)]:
 (out/(name+'-board.yaml')).write_text(ctl._dump_board(b))
 (out/(name+'-README.md')).write_text(ctl.render_dashboard(b))
(repo/boardpath).write_bytes((out/'live-board.yaml').read_bytes());(repo/dashpath).write_bytes((out/'live-README.md').read_bytes())
package_diff_paths=git('diff','--name-only','HEAD','--','packages').decode().splitlines()
if package_diff_paths!=['packages/friday-chat/config.example.yaml']:raise RuntimeError('Unexpected package modification')
save(out/'planning-dirty-preservation.json',dict(unrelated_board_objects_identical=True,unrelated_board_objects=extra_after,unrelated_files=preserved,source_candidate_unchanged=True,unchanged_original_dirty_package_path=package_diff_paths))
print('Recorded archive, packet and clean/live board metadata; no staging')
