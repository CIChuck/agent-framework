from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import subprocess
import time
import yaml

spec=importlib.util.spec_from_file_location('baseline','/private/tmp/telem-02/builder-baseline/prepare.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.OUT=Path('/private/tmp/telem-04/planning')
repo=h.REPO;pkt=repo/'docs/planning/active/friday-telemetry-rewire';dest=pkt/'execution/TELEM-04-planning'
base='e6209e3156216afde1655758e280690229f7d3e6'
root,receipt=h.prepare('proposal-r2',base)
paths=[pkt/'README.md',pkt/'closeout-TELEM-03.md',pkt/'execution-log.md',pkt/'authority-manifest-TELEM-04.yaml',pkt/'telem04-contract.md',pkt/'verification-profile-TELEM-04.md',pkt/'directives/CD-004-correlated-execution.md',pkt/'validation/WVR-006-telem04-lint-disposition.md',pkt/'validation/WVR-006-telem04-lint-scope.json']
paths += [p for p in dest.rglob('*') if p.is_file()]
paths += [p for p in (repo/'docs/archive/completed/2026/friday-telemetry-rewire-telem-03').rglob('*') if p.is_file()]
overlays={}
for source in paths:
 rel=str(source.relative_to(repo));target=root/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes());overlays[rel]=h.sha(source.read_bytes())
for name,target in [('clean-board.yaml','docs/planning/board.yaml'),('clean-README.md','docs/planning/README.md')]:
 data=(h.OUT/name).read_bytes();(root/target).write_bytes(data);overlays[target]=h.sha(data)
h.save('proposal-overlay.json',dict(base=base,overlays=overlays,excluded_original_dirty_payloads=True))
commands=[('proposal-r2-board-'+name,['uv','run','--no-sync','python','scripts/friday-dev-board.py',*args]) for name,args in [('validate',['validate']),('next',['next']),('show',['show','friday-telemetry-rewire']),('render',['render','--check'])]]
commands += [('proposal-r2-docs',['uv','run','--no-sync','python','scripts/check-documentation-lifecycle.py']),('proposal-r2-diff-check',['git','diff','--check']),('proposal-r2-root-ruff',['uv','run','--no-sync','ruff','check','.','--output-format','json'])]
results=[]
for name,command in commands:
 env=h.environment(root,name);started=time.time();r=subprocess.run(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
 (h.OUT/(name+'.stdout')).write_bytes(r.stdout);(h.OUT/(name+'.stderr')).write_bytes(r.stderr)
 v=dict(command=command,cwd=str(root),revision=base,overlay_sha256=h.sha((h.OUT/'proposal-overlay.json').read_bytes()),environment=env,exit_code=r.returncode,seconds=time.time()-started,stdout_sha256=h.sha(r.stdout),stderr_sha256=h.sha(r.stderr))
 h.save(name+'-receipt.json',v);results.append(dict(name=name,exit_code=r.returncode));print(name,r.returncode,r.stdout.decode()[-150:] if name!='proposal-r2-root-ruff' else '')
 if r.returncode!=(1 if name=='proposal-r2-root-ruff' else 0):raise RuntimeError('Proposal metadata gate failed')
m=json.loads((pkt/'authority-manifest-TELEM-04.yaml').read_text())
for pin in m['authority']:
 if h.sha((repo/pin['path']).read_bytes())!=pin['sha256'] or h.sha((root/pin['path']).read_bytes())!=pin['sha256']:raise RuntimeError('Controlling hash mismatch '+pin['path'])
old=json.loads((pkt/'authority-manifest-TELEM-03.yaml').read_text())
for pin in old['authority']:
 if h.sha((repo/pin['path']).read_bytes())!=pin['sha256']:raise RuntimeError('Accepted hash changed')
targets=[p for group in m['product_manifest'].values() for p in group]
if len(targets)!=len(set(targets)) or len(targets)!=29:raise RuntimeError('Manifest duplicate/count')
inventory=json.loads((dest/'source-inventory.json').read_text())
for p,v in inventory['existing'].items():
 if h.sha((repo/p).read_bytes())!=v['sha256']:raise RuntimeError('Source changed')
for p,absent in inventory['new_paths_absent'].items():
 if not absent or (repo/p).exists():raise RuntimeError('Product generation before approval')
for p,digest in json.loads((h.OUT/'unrelated-before.json').read_text()).items():
 current=h.sha((repo/p).read_bytes()) if (repo/p).is_file() else None
 if current!=digest:raise RuntimeError('Unrelated work changed '+p)
clean=yaml.safe_load((h.OUT/'clean-board.yaml').read_text());live=yaml.safe_load((repo/'docs/planning/board.yaml').read_text())
extra={k:[v for v in live[k] if v not in clean[k]] for k in ['tasks','events']}
if extra!=json.loads((h.OUT/'planning-dirty-before.json').read_text()):raise RuntimeError('Unrelated board objects changed')
raw=json.loads((h.OUT/'proposal-r2-root-ruff.stdout').read_text());scope=json.loads((pkt/'validation/WVR-006-telem04-lint-scope.json').read_text())
actual=[dict(path=str(Path(d['filename']).relative_to(root)),code=d['code'],location=d['location'],end_location=d['end_location'],message=d['message']) for d in raw]
key=lambda d:json.dumps(d,sort_keys=True)
if sorted(actual,key=key)!=sorted(scope['diagnostics'],key=key):raise RuntimeError('Proposal lint drift')
for rel,digest in receipt['tracked_hashes'].items():
 expected=overlays.get(rel,digest)
 if h.sha((root/rel).read_bytes())!=expected:raise RuntimeError('Snapshot changed unexpectedly '+rel)
artifacts=json.loads((dest/'artifact-manifest.json').read_text())
for a in artifacts['artifacts']:
 stored=(dest/a['stored']).read_bytes()
 if h.sha(stored)!=a['stored_sha256'] or h.sha(gzip.decompress(stored))!=a['original_sha256']:raise RuntimeError('Static artifact corruption')
metadata=dict(base=base,checks=results,controls_match=len(m['authority']),accepted_telem03_controls_match=len(old['authority']),product_paths_unique=29,product_source_unchanged=True,new_product_absent=True,raw_root_ruff_exit=1,exact_historical_findings=327,unrelated_files_preserved=True,unrelated_board_objects_identical=True,proposal_snapshot_unchanged_outside_overlay=True,scope_approval=False,independent_verdict=None)
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
save(dest/'metadata-checks.json',metadata)
for source in sorted(h.OUT.iterdir()):
 if not source.is_file() or not (source.name.startswith('proposal-') or source.name.startswith('check_proposal')):continue
 data=source.read_bytes();target=dest/'receipts'/(source.name+'.gz');zipped=gzip.compress(data,mtime=0);target.write_bytes(zipped)
 artifacts['artifacts'].append(dict(original=str(source),stored=str(target.relative_to(dest)),original_sha256=h.sha(data),stored_sha256=h.sha(zipped),bytes=len(data)))
artifacts['artifacts']=list({a['stored']:a for a in artifacts['artifacts']}.values())
save(dest/'artifact-manifest.json',artifacts)
print('Proposal integrity and preservation checks PASS; no independent verdict')
