from pathlib import Path
import importlib.util
import json
import subprocess
import time

spec = importlib.util.spec_from_file_location('baseline', '/private/tmp/telem-02/builder-baseline/prepare.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.OUT = Path('/private/tmp/telem-04/planning')
helper.OUT.mkdir(parents=True, exist_ok=True)
revision = helper.git('rev-parse', 'HEAD').decode().strip()
helper.save('original-before.json', helper.original_state())
root, snapshot = helper.prepare('baseline', revision)
commands = [(name, ['uv', 'run', '--no-sync', 'python', 'scripts/friday-dev-board.py', *args]) for name, args in [('board-validate',['validate']),('board-next',['next']),('board-show',['show','friday-telemetry-rewire']),('board-render',['render','--check'])]]
commands += [('root-ruff', ['uv','run','--no-sync','ruff','check','.','--output-format','json'])]
for name, command in commands:
    env = helper.environment(root, name)
    started = time.time()
    result = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
    (helper.OUT/(name+'.stdout')).write_bytes(result.stdout)
    (helper.OUT/(name+'.stderr')).write_bytes(result.stderr)
    helper.save(name+'-receipt.json',dict(command=command,cwd=str(root),revision=revision,environment=env,exit_code=result.returncode,seconds=time.time()-started,stdout_sha256=helper.sha(result.stdout),stderr_sha256=helper.sha(result.stderr)))
    print(name, result.returncode)
    if result.returncode != (1 if name == 'root-ruff' else 0):
        raise RuntimeError('Unexpected gate result')
if not all(helper.sha((root/p).read_bytes()) == h for p,h in snapshot['tracked_hashes'].items()):
    raise RuntimeError('Snapshot content changed')
helper.save('original-after.json',helper.original_state())
if json.loads((helper.OUT/'original-before.json').read_text()) != json.loads((helper.OUT/'original-after.json').read_text()):
    raise RuntimeError('Original worktree/index changed')
