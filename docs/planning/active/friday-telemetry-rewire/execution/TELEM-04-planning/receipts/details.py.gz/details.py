from pathlib import Path
import ast
import importlib.util
import json
import subprocess
import time

spec=importlib.util.spec_from_file_location('baseline','/private/tmp/telem-02/builder-baseline/prepare.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
h.OUT=Path('/private/tmp/telem-04/planning')
root=h.OUT/'baseline'
prefix='packages/friday-chat/src/friday_chat/'
manifest={
 'existing_source':['packages/friday-telemetry/src/friday_telemetry/__init__.py']+[prefix+p for p in ['telemetry.py','turns/processor.py','tools/loop.py','runtime.py','adapters.py','background.py','app.py','commands/registry.py']],
 'new_source':['packages/friday-telemetry/src/friday_telemetry/models/execution.py','packages/friday-telemetry/src/friday_telemetry/helpers/correlation.py',prefix+'turns/telemetry.py'],
 'existing_tests':['packages/friday-chat/tests_chat/'+p for p in ['test_telemetry.py','test_turn_processing.py','test_background_work.py','test_app_lifecycle.py','test_runtime.py','test_command_foundations.py','test_command_production_adapters.py','test_mcp_execution_transcript.py','test_mcp_memory.py']],
 'new_tests':['packages/friday-telemetry/tests_telemetry/test_execution_events.py','packages/friday-telemetry/tests_telemetry/test_correlation.py','packages/friday-chat/tests_chat/test_turn_telemetry.py','packages/friday-chat/tests_chat/test_tool_telemetry.py','packages/friday-chat/tests_chat/test_memory_telemetry.py','packages/friday-chat/tests_chat/test_telemetry_diagnostics.py'],
 'documentation':['packages/friday-telemetry/README.md','packages/friday-chat/README.md']}
h.save('product-manifest.json',manifest)
inventory={}
for path in manifest['existing_source']:
 source=(root/path).read_text();tree=ast.parse(source,feature_version=(3,13))
 inventory[path]={'sha256':h.sha(source.encode()),'public_api':h.public_ast(root/path),'definitions':[{'name':n.name,'line':n.lineno,'end_line':n.end_lineno} for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))],'existing_suppressions':[{'line':i,'text':s.strip()} for i,s in enumerate(source.splitlines(),1) if 'type: ignore' in s or 'mypy:' in s or 'noqa' in s]}
h.save('source-inventory.json',dict(base=h.git('rev-parse','HEAD').decode().strip(),manifest=manifest,existing=inventory,new_paths_absent={p:not(root/p).exists() for p in manifest['new_source']+manifest['new_tests']}))
old=json.loads((root/'docs/planning/active/friday-telemetry-rewire/validation/WVR-005-telem03-lint-scope.json').read_text())
raw=json.loads((h.OUT/'root-ruff.stdout').read_text())
actual=[]
for d in raw:
 path=str(Path(d['filename']).relative_to(root))
 actual.append(dict(path=path,code=d['code'],location=d['location'],end_location=d['end_location'],message=d['message']))
key=lambda d:json.dumps(d,sort_keys=True)
if sorted(actual,key=key)!=sorted(old['diagnostics'],key=key):raise RuntimeError('Lint identity drift')
for group in ['archived_files','lint_configurations']:
 for p,digest in old[group].items():
  if h.sha((root/p).read_bytes())!=digest:raise RuntimeError('Lint input drift: '+p)
registry=root/'packages/friday-cli/src/friday_cli/commands.py'
cls=next(n for n in ast.parse(registry.read_text()).body if isinstance(n,ast.ClassDef) and n.name=='CommandRegistry')
if h.sha(registry.read_bytes())!=old['command_registry_source_sha256'] or h.sha(ast.dump(cls,include_attributes=False).encode())!=old['command_registry_class_ast_sha256']:raise RuntimeError('Registry drift')
old.update(base=h.git('rev-parse','HEAD').decode().strip(),work_unit='TELEM-04',status='proposed; not approved; WVR-005 is not inherited')
h.save('WVR-006-telem04-lint-scope.json',old)
h.save('lint-comparison.json',dict(exact_identity_match=True,count=len(actual),archive_count=326,live_count=1,archive_config_source_ast_match=True,raw_exit=1,approval=False))
for name,command in [('prospective-mypy',['uv','run','--no-sync','mypy','--python-version','3.13',*manifest['existing_source']]),('prospective-ruff',['uv','run','--no-sync','ruff','check',*manifest['existing_source']]),('lock',['uv','lock','--offline','--check','--no-python-downloads','--no-build']),('docs',['uv','run','--no-sync','python','scripts/check-documentation-lifecycle.py'])]:
 env=h.environment(root,name);started=time.time()
 result=subprocess.run(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 (h.OUT/(name+'.stdout')).write_bytes(result.stdout);(h.OUT/(name+'.stderr')).write_bytes(result.stderr)
 h.save(name+'-receipt.json',dict(command=command,cwd=str(root),revision=old['base'],environment=env,exit_code=result.returncode,seconds=time.time()-started,stdout_sha256=h.sha(result.stdout),stderr_sha256=h.sha(result.stderr)))
 print(name,result.returncode,result.stdout.decode()[-1200:])
snapshot=json.loads((h.OUT/'baseline-snapshot.json').read_text())
if not all(h.sha((root/p).read_bytes())==v for p,v in snapshot['tracked_hashes'].items()):raise RuntimeError('Tracked snapshot changed')
h.save('details-preservation.json',dict(snapshot_tracked_unchanged=True,original_unchanged=h.original_state()==json.loads((h.OUT/'original-before.json').read_text())))
