from pathlib import Path
import datetime
import difflib
import gzip
import hashlib
import importlib.util
import json
import subprocess
import sys
import yaml

repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
out=Path('/private/tmp/telem-04/planning')
pkt=repo/'docs/planning/active/friday-telemetry-rewire'
dest=pkt/'execution/TELEM-04-planning';dest.mkdir(parents=True,exist_ok=True)
archive=repo/'docs/archive/completed/2026/friday-telemetry-rewire-telem-03';archive.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
git=lambda *args:subprocess.check_output(['git','--no-optional-locks','-C',str(repo),*args])
base=git('rev-parse','HEAD').decode().strip()
if base!='e6209e3156216afde1655758e280690229f7d3e6':raise RuntimeError('Preparation base changed')
preserved=json.loads((out/'unrelated-before.json').read_text())
spec=importlib.util.spec_from_file_location('boardctl',repo/'scripts/friday-dev-board.py');ctl=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ctl;spec.loader.exec_module(ctl)
boardpath='docs/planning/board.yaml';dashpath='docs/planning/README.md'
clean=yaml.safe_load(git('show','HEAD:'+boardpath));live=yaml.safe_load((repo/boardpath).read_text())
extra_before={k:[v for v in live[k] if v not in clean[k]] for k in ['tasks','events']}
save(out/'planning-dirty-before.json',extra_before)
for b in [clean,live]:
 task=next(t for t in b['tasks'] if t['id']=='friday-telemetry-rewire')
 task['next_gate']='approve proposed CD-004 and separately WVR-006 for TELEM-04'
 for path in ['docs/archive/completed/2026/friday-telemetry-rewire-telem-03/README.md','docs/planning/active/friday-telemetry-rewire/execution/TELEM-04-planning/report.md']:
  if path not in task['validation']:task['validation'].append(path)
 ctl._append_event(b,task_id='friday-telemetry-rewire',action='checkpoint',actor='controller',actor_role='agent',note='Record maintainer-directed TELEM-03 progression acceptance and prepare unapproved CD-004/WVR-006; preserve continuing started/local state.',evidence='docs/archive/completed/2026/friday-telemetry-rewire-telem-03/README.md')
extra_after={k:[v for v in live[k] if v not in clean[k]] for k in ['tasks','events']}
if extra_before!=extra_after:raise RuntimeError('Unrelated board objects changed')
for name,b in [('clean',clean),('live',live)]:
 (out/(name+'-board.yaml')).write_text(ctl._dump_board(b))
 (out/(name+'-README.md')).write_text(ctl.render_dashboard(b))
(repo/boardpath).write_bytes((out/'live-board.yaml').read_bytes());(repo/dashpath).write_bytes((out/'live-README.md').read_bytes())
package_diff_paths=git('diff','--name-only','HEAD','--','packages').decode().splitlines()
if package_diff_paths!=['packages/friday-chat/config.example.yaml']:raise RuntimeError('Unexpected package modification')
save(out/'planning-dirty-preservation.json',dict(unrelated_board_objects_identical=True,unrelated_board_objects=extra_after,unrelated_files=preserved,source_candidate_unchanged=True,unchanged_original_dirty_package_path=package_diff_paths))
print('Recorded archive, packet and clean/live board metadata; no staging')
