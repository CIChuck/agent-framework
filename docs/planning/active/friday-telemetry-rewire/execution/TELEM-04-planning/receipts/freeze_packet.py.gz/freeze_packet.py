from pathlib import Path
import gzip
import hashlib
import importlib.metadata
import json
import platform
import subprocess

repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');out=Path('/private/tmp/telem-04/planning')
pkt=repo/'docs/planning/active/friday-telemetry-rewire';dest=pkt/'execution/TELEM-04-planning'
sha=lambda b:hashlib.sha256(b).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
versions={'python':platform.python_version(),'tools':{n:importlib.metadata.version(n) for n in ['ruff','mypy','pytest','pydantic','opentelemetry-sdk']}}
save(out/'versions.json',versions)
records=[]
for source in sorted(out.iterdir()):
 if not source.is_file() or source.name.startswith(('live-','clean-')):continue
 data=source.read_bytes();target=dest/'receipts'/(source.name+'.gz');target.parent.mkdir(exist_ok=True)
 zipped=gzip.compress(data,mtime=0);target.write_bytes(zipped)
 records.append(dict(original=str(source),stored=str(target.relative_to(dest)),original_sha256=sha(data),stored_sha256=sha(zipped),bytes=len(data)))
save(dest/'artifact-manifest.json',dict(base='e6209e3156216afde1655758e280690229f7d3e6',mode='controller static preparation; no independent verdict',gzip_mtime=0,artifacts=records))
old=json.loads((pkt/'authority-manifest-TELEM-03.yaml').read_text())
paths=[p['path'] for p in old['authority']]
paths += [str((pkt/p).relative_to(repo)) for p in ['authority-manifest-TELEM-03.yaml','telem03-contract.md','verification-profile-TELEM-03.md','directives/CD-003-approval-record.md','directives/CD-003-approval-evidence.json','validation/VAL-008/report.md','validation/VAL-008/stored-artifact-manifest.json','directives/CD-004-correlated-execution.md','telem04-contract.md','verification-profile-TELEM-04.md','validation/WVR-006-telem04-lint-disposition.md','validation/WVR-006-telem04-lint-scope.json','execution/TELEM-04-planning/listener-scope.json','execution/TELEM-04-planning/source-inventory.json','execution/TELEM-04-planning/source-inventory.md','execution/TELEM-04-planning/report.md']]
paths += ['docs/archive/completed/2026/friday-telemetry-rewire-telem-03/'+p for p in ['README.md','acceptance-evidence.json']]
paths=list(dict.fromkeys(paths))
manifest=dict(initiative='friday-telemetry-rewire',work_unit='TELEM-04',directive='CD-004',status='proposed; construction not approved; WVR-006 requires separate approval and independent reconciliation',base='e6209e3156216afde1655758e280690229f7d3e6',aggregate_base=old['aggregate_base'],branch=old['branch'],authority=[dict(path=p,sha256=sha((repo/p).read_bytes())) for p in paths],product_manifest=json.loads((out/'product-manifest.json').read_text()),acceptance_criteria=['AC04-'+f'{i:02d}' for i in range(1,9)],review_mode='fresh-context read-only full unit and complete aggregate after stable construction candidate',external_services='proposed exact13 existing synthetic loopback nodes only; owned in-memory SDK consumer; no real provider/state/remote service',lint_disposition='WVR-006 proposed; not approved; WVR-005 expired',future_product_review='Mandatory AGENTS.md independent validation; no product generation until approved construction directive')
save(pkt/'authority-manifest-TELEM-04.yaml',manifest)
print('Frozen',len(paths),'proposal controls,',sum(len(v) for v in manifest['product_manifest'].values()),'product targets,',len(records),'static artifacts')
