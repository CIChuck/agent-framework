from pathlib import Path
import ast
import hashlib
import json
import subprocess
import tomllib

repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
root=Path('/private/tmp/telem-03/construction/iteration-05')
out=root.parent
pkt='docs/planning/active/friday-telemetry-rewire/'
m=json.loads((root/pkt/'authority-manifest-TELEM-03.yaml').read_text())
base=m['base']
sha=lambda b:hashlib.sha256(b).hexdigest()
def historical(p):return subprocess.check_output(['git','--no-optional-locks','-C',str(repo),'show',base+':'+p])
def public(data):
 tree=ast.parse(data,feature_version=(3,13)); result={}
 def signatures(nodes,prefix=''):
  for n in nodes:
   if isinstance(n,ast.ClassDef):signatures(n.body,prefix+n.name+'.')
   elif isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and (not n.name.startswith('_') or n.name=='__init__'):
    result[prefix+n.name]=n.args
 signatures(tree.body);return result
changes=[]
for p in m['product_manifest']['source']:
 ast.parse((root/p).read_text(),feature_version=(3,13))
 if p.endswith(('llm_events.py','safe_llm.py','friday_llm/telemetry.py')):continue
 old=public(historical(p));new=public((root/p).read_text())
 for name,args in old.items():
  if name not in new:raise RuntimeError('Public function removed '+p+':'+name)
  now=new[name]
  if [a.arg for a in args.posonlyargs+args.args]!=[a.arg for a in now.posonlyargs+now.args]:raise RuntimeError('Positional call shape drift '+name)
  if ast.dump(ast.Module(body=args.defaults,type_ignores=[]))!=ast.dump(ast.Module(body=now.defaults,type_ignores=[])):raise RuntimeError('Positional defaults drift '+name)
  before={a.arg:ast.unparse(d) if d is not None else None for a,d in zip(args.kwonlyargs,args.kw_defaults,strict=True)}
  after={a.arg:ast.unparse(d) if d is not None else None for a,d in zip(now.kwonlyargs,now.kw_defaults,strict=True)}
  if any(after.get(k)!=v for k,v in before.items()):raise RuntimeError('Keyword default drift '+name)
  added={k:v for k,v in after.items() if k not in before}
  if added and (not set(added)<= {'telemetry','service_role'} or any(v not in ['None',"'unspecified'"] for v in added.values())):raise RuntimeError('Unapproved required public keyword '+name)
  if added:changes.append(dict(path=p,method=name,optional_keyword_additions=added))
# Existing public request/protocol/stream and legacy compatibility sources unchanged.
compat=[
 'packages/friday-telemetry/src/friday_telemetry/interface.py',
 'packages/friday-telemetry/src/friday_telemetry/helpers/llm.py',
 'packages/friday-telemetry/src/friday_telemetry/models/llm.py',
 'packages/friday-llm/src/friday_llm/protocol.py',
 'packages/friday-llm/src/friday_llm/telemetry_helper.py',
 'packages/friday-llm/src/friday_llm/telemetry_models.py',
]
# Resolve actual filenames from the frozen inventory/tree instead of guessing.
tracked=subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','--name-only',base]).decode().splitlines()
compat=[p for p in compat if p in tracked]
compat+= [p for p in tracked if p.startswith('packages/friday-llm/src/friday_llm/') and any(t in Path(p).name for t in ['request','protocol','stream','completion']) and p not in m['product_manifest']['source']]
for p in compat:
 if (root/p).read_bytes()!=historical(p):raise RuntimeError('Compatibility source drift '+p)
metadata=sorted(p for p in tracked if p.endswith('pyproject.toml'))
if len(metadata)!=18:raise RuntimeError('Python floor inventory changed')
for p in metadata:
 if (root/p).read_bytes()!=historical(p):raise RuntimeError('Metadata/dependency drift '+p)
 if tomllib.loads((root/p).read_text())['project']['requires-python']!='>=3.13.4':raise RuntimeError('Python floor drift '+p)
for p in ['uv.lock','packages/friday-chat/config.example.yaml']:
 if (root/p).read_bytes()!=historical(p):raise RuntimeError('Unapproved lock/config edit '+p)
preserved=json.loads(Path('/private/tmp/telem-01/REM-004/approved-execution/preserved.json').read_text())
result={}
for p,value in preserved.items():
 if p in ['docs/planning/board.yaml','docs/planning/README.md']:continue
 mapping=value if isinstance(value,dict) else {p:value}
 for file,h in mapping.items():
  current=repo/file
  if h is None:
   if current.exists():raise RuntimeError('Original deletion lost '+file)
  elif sha(current.read_bytes())!=h:raise RuntimeError('Unrelated original data changed '+file)
  result[file]=h
# Preserve planning's unrelated dirty patch exactly, without staging it.
planning={p:sha(subprocess.check_output(['git','-C',str(repo),'diff','--',p])) for p in ['docs/planning/board.yaml','docs/planning/README.md']}
(out/'iteration-05-contracts.json').write_text(json.dumps(dict(base=base,public_optional_keyword_changes=changes,compatibility_sources=compat,python_floors=metadata,dependency_lock_config_unchanged=True,preserved_unrelated_hashes=result,unrelated_planning_patch_hashes=planning,new_suppressions=[],external_pricing_lookup=False),indent=2)+'\n')
print('CONTRACT/PRESERVATION PASS: public call compatibility, unchanged request/stream/legacy boundaries,18 floors and dirty work')
