import importlib.util
import json
import sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('driver','/private/tmp/telem-03/construction/driver.py')
# driver expects argv, so import runner directly with identical environment overrides.
spec=importlib.util.spec_from_file_location('runner','/private/tmp/telem-02/builder-execution/runner.py')
x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x)
x.OUT=Path('/private/tmp/telem-03/construction');x.helper.OUT=x.OUT
original=x.helper.environment
def environment(root,label):
 env=original(root,label);env['PYTHONPATH']+=':'+str(x.OUT);return env
x.helper.environment=environment
p=json.loads((x.OUT/'gate-paths.json').read_text());n=sys.argv[1];label=sys.argv[2];name=sys.argv[3]
ignore=['--ignore=packages/friday-chat/tests_chat/test_live_lmstudio.py','--ignore=packages/friday-llm/tests_llm/test_live_lmstudio.py']
commands={
 'unit-ruff':['ruff','check',*p['unit_python']],
 'aggregate-ruff':['ruff','check',*p['aggregate_python']],
 'unit-mypy':['mypy','--python-version','3.13',*p['unit_source']],
 'aggregate-mypy':['mypy','--python-version','3.13',*p['aggregate_source']],
 'root-ruff':['ruff','check','.','--output-format','json'],
 'package-tests':['pytest','packages/friday-chat/tests_chat','packages/friday-llm/tests_llm','packages/friday-telemetry/tests_telemetry',*ignore,'-rA'],
 'collect':['pytest','--import-mode=importlib',*ignore,'--collect-only'],
 'root-tests':['pytest','--import-mode=importlib',*ignore,'-rA'],
 'owning-tests':['pytest','--import-mode=importlib',*p['owning_trees'],*ignore,'-rA'],
}
sys.exit(x.run(n,label,commands[name]))
