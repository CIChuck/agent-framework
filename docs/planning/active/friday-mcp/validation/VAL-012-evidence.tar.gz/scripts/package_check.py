from pathlib import Path
import subprocess,os,json,zipfile,email,importlib.metadata as md,shutil,hashlib
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name
OUT=Path('/private/tmp/VAL-012-independent-20260928');ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework');INPUT=OUT/'runtime/candidate';WHEELS=OUT/'wheels';WHEELS.mkdir(exist_ok=True)
env=os.environ.copy();env.update({'PYTHONDONTWRITEBYTECODE':'1','UV_CACHE_DIR':'/private/tmp/friday-uv-cache','UV_OFFLINE':'true'})
records=[]
def run(name,argv):
 with (OUT/f'logs/package-{name}.log').open('wb') as log:r=subprocess.run(argv,cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'argv':argv,'environment':{k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','UV_CACHE_DIR','UV_OFFLINE']},'cwd':str(OUT),'exit':r.returncode};records.append(record);print(name,r.returncode,flush=True);return r.returncode
run('tools',['uv','--version'])
for package in ['telemetry','core','transcript']:
 if run('build-'+package,['uv','build','--offline','--wheel',str(INPUT/f'packages/friday-{package}'),'--out-dir',str(WHEELS)]):raise RuntimeError('Required build unavailable')
metadata={};framework={}
EXTRACTED=OUT/'runtime/extracted-wheels';EXTRACTED.mkdir(exist_ok=True)
for wheel in sorted(WHEELS.glob('*.whl')):
 with zipfile.ZipFile(wheel) as z:
  text=z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))).decode();m=email.message_from_string(text)
  name=canonicalize_name(m['Name']);framework[name]=m.get_all('Requires-Dist',[])
  metadata[wheel.name]={'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'metadata':text,'requires_dist':framework[name]};z.extractall(EXTRACTED)
assert any(Requirement(r).name=='friday-framework-core' for r in framework['friday-framework-transcript'])
(OUT/'wheel-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
VENV=OUT/'runtime/wheel-venv';run('venv',['uv','venv','--offline',str(VENV)])
install=run('install',['uv','pip','install','--offline','--python',str(VENV/'bin/python'),*[str(p) for p in sorted(WHEELS.glob('*.whl'))]])
dependencies={};pending=[Requirement(r) for reqs in framework.values() for r in reqs];selected={}
while pending:
 req=pending.pop(0)
 if req.marker and not req.marker.evaluate({'extra':''}):continue
 name=canonicalize_name(req.name)
 if name in framework:continue
 dist=md.distribution(req.name);assert req.specifier.contains(dist.version,prereleases=True),(req,dist.version)
 if name in selected:continue
 selected[name]=dist;pending.extend(Requirement(r) for r in dist.requires or [])
THIRD=OUT/'runtime/declared-dependencies';THIRD.mkdir(exist_ok=True)
for name,dist in selected.items():
 files={}
 for file in dist.files or []:
  if '..' in file.parts or '__pycache__' in file.parts or str(file).endswith(('.pyc','.pth')):continue
  src=Path(dist.locate_file(file));target=THIRD/str(file)
  if not src.is_file():continue
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target);files[str(file)]=hashlib.sha256(src.read_bytes()).hexdigest()
 dependencies[name]={'version':dist.version,'requirements':dist.requires or [],'copied_file_hashes':files}
(OUT/'declared-dependencies.json').write_text(json.dumps(dependencies,indent=2)+'\n')
run('isolated-import',[str(VENV/'bin/python'),'-I',str(OUT/'scripts/wheel_import.py'),str(EXTRACTED),str(THIRD)])
(OUT/'package-commands.json').write_text(json.dumps(records,indent=2)+'\n')
