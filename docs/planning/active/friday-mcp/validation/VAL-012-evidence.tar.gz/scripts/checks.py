from pathlib import Path
import os, json, subprocess, datetime, concurrent.futures
import yaml
ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework'); OUT=Path('/private/tmp/VAL-012-independent-20260928')
req=yaml.safe_load((ROOT/'docs/planning/active/friday-mcp/validation/VAL-012-request.yaml').read_text())
for p in ['logs','runtime/tmp','runtime/mypy-cache','runtime/ruff-cache']: (OUT/p).mkdir(parents=True,exist_ok=True)
extras={'PYTEST_ADDOPTS':'-p no:cacheprovider','MYPY_CACHE_DIR':str(OUT/'runtime/mypy-cache'),'RUFF_CACHE_DIR':str(OUT/'runtime/ruff-cache'),'TMPDIR':str(OUT/'runtime/tmp')}
env=os.environ.copy();env.update(extras)
for name in list(env):
 if any(x in name.upper() for x in ['API_KEY','ACCESS_TOKEN','SECRET','AUTHORIZATION']): env.pop(name)
def run(n):
 command=req['required_checks'][n-1]
 record={'number':n,'command':command,'cwd':str(ROOT),'extra_environment':extras,'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (OUT/f'logs/required-{n:02}.log').open('wb') as log:
  p=subprocess.run(command,shell=True,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit=p.returncode,end=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (OUT/f'logs/required-{n:02}.json').write_text(json.dumps(record,indent=2)+'\n')
 print(f'required {n:02} exit {p.returncode}',flush=True)
run(1)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: list(pool.map(run,range(2,19)))
