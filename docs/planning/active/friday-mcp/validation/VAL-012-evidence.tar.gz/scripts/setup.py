from pathlib import Path
import json, subprocess, tarfile, io, shutil
ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework'); OUT=Path('/private/tmp/VAL-012-independent-20260928')
f=json.loads((ROOT/'docs/planning/active/friday-mcp/validation/VAL-012-frozen-inputs.json').read_text())
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
for item in [f['request'],*f['authority'],*f['candidate_reports']]:
 p=OUT/'inputs'/item['path']; p.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(ROOT/item['path'],p)
p=OUT/'inputs/docs/planning/active/friday-mcp/validation/VAL-012-frozen-inputs.json'; shutil.copyfile(ROOT/p.relative_to(OUT/'inputs'),p)
for mode,base in [('delta',f['remediation_base_commit']),('aggregate',f['base_commit'])]:
 for name,args in [('diff',['diff','--binary']),('name-status.txt',['diff','--name-status'])]:
  (OUT/f'{mode}.{name}').write_bytes(git(*args,f"{base}..{f['candidate_commit']}"))
for label,rev in [('candidate',f['candidate_commit']),('original-base',f['base_commit']),('remediation-base',f['remediation_base_commit'])]:
 dst=OUT/'runtime'/label; dst.mkdir(parents=True,exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(git('archive',rev))) as tar: tar.extractall(dst,filter='data')
 for p in (dst/'packages').glob('*/src'):
  pass
 source_paths=sorted(str(p) for p in (dst/'packages').glob('*/src'))
 (OUT/f'{label}-imports.json').write_text(json.dumps({'revision':rev,'root':str(dst),'pythonpath':source_paths},indent=2)+'\n')
allowed=set()
import yaml
req=yaml.safe_load((ROOT/f['request']['path']).read_text())
for key in ['allowed_product_paths','allowed_dependency_paths','allowed_test_paths']: allowed.update(req[key])
allowed.add(req['allowed_implementation_report']); allowed.add(req['allowed_remediation_report'])
scope={}
for mode,base in [('delta',f['remediation_base_commit']),('aggregate',f['base_commit'])]:
 changed=git('diff','--name-only',f"{base}..{f['candidate_commit']}").decode().splitlines()
 product=[p for p in changed if p.startswith(('packages/','tests/')) or p in ['pyproject.toml','uv.lock']]
 scope[mode]={'all_changed':changed,'product_changed':product,'unexpected':sorted(set(product)-allowed)}
outside=[]
for p in f['tracked_product_bytes']:
 if p in allowed: continue
 try:
  if git('show',f"{f['base_commit']}:{p}")!=(ROOT/p).read_bytes(): outside.append(p)
 except subprocess.CalledProcessError: outside.append(p)
scope['outside_allowed_changed']=outside
scope['candidate_to_head']=git('diff','--name-only',f['candidate_commit'],'HEAD').decode().splitlines()
(OUT/'scope.json').write_text(json.dumps(scope,indent=2)+'\n')
print(json.dumps({m:{'all_changed':len(scope[m]['all_changed']),'product_changed':len(scope[m]['product_changed']),'unexpected':scope[m]['unexpected']} for m in ['delta','aggregate']}))
print('outside changed',outside)
