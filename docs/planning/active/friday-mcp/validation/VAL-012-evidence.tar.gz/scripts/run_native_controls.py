from pathlib import Path
import subprocess,json,os
OUT=Path('/private/tmp/VAL-012-independent-20260928');ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
env=os.environ.copy();env.update({'LITELLM_LOCAL_MODEL_COST_MAP':'true','PYTHONDONTWRITEBYTECODE':'1'})
for label in ['remediation-base','candidate','original-base']:
 imports=json.loads((OUT/f'{label}-imports.json').read_text());env['PYTHONPATH']=str(OUT/'scripts')+':'+':'.join(imports['pythonpath'])
 command=[str(ROOT/'.venv/bin/python'),str(OUT/'scripts/native_controls.py'),label]
 with (OUT/f'logs/native-controls-{label}.log').open('wb') as log:r=subprocess.run(command,cwd=imports['root'],env=env,stdout=log,stderr=subprocess.STDOUT)
 (OUT/f'logs/native-controls-{label}.json').write_text(json.dumps({'argv':command,'environment':{k:env[k] for k in ['LITELLM_LOCAL_MODEL_COST_MAP','PYTHONDONTWRITEBYTECODE','PYTHONPATH']},'cwd':imports['root'],'exit':r.returncode},indent=2)+'\n');print(label,r.returncode,flush=True)
