"""Independent exact F-001/F-002 and native malformed-name comparison."""
from pathlib import Path
import asyncio,json,sys
from unittest.mock import patch
from probe_common import *
from friday_chat.turns.processor import TurnProcessor
from friday_chat.tools.loop import ToolLoop
from friday_chat.tools.registry import FakeToolRegistry
async def main(label):
 children=[];initial=set(asyncio.all_tasks());bridges=[];spawn=asyncio.create_subprocess_exec
 async def track(*a,**kw):p=await spawn(*a,**kw);children.append(p);return p
 directory=OUT/'runtime'/('findings-'+label);directory.mkdir(parents=True,exist_ok=True)
 observations={'label':label,'imports':{k:__import__(k).__file__ for k in ['friday_chat','friday_core','friday_transcript']},'native_malformed':[]}
 try:
  with patch('asyncio.create_subprocess_exec',track):
   runtime,bridge,store=await setup(directory);bridges.append(bridge)
   runtime.chat_llm=Model([ChatModelResponse(tool_calls=(ToolCallRequest('mcp_alpha_probe_read',{},'privacy'),)),ChatModelResponse.from_text('done')])
   result=await TurnProcessor(runtime).process('synthetic')
   session=await store.get_session('independent');artifacts=await exports(store,'independent',directory)
   observations['privacy']={'session_env_present':ENV in json.dumps(session.config_snapshot),'session_header_present':HEADER in json.dumps(session.config_snapshot),'session_launch_present':LAUNCH in json.dumps(session.config_snapshot),'export_sentinels':{k:{s:s in text for s in [ENV,HEADER,LAUNCH]} for k,text in artifacts.items()}}
   before=await store.count_entries('independent')
   runtime.chat_llm=Model([ChatModelResponse(tool_calls=(ToolCallRequest('mcp_alpha_probe_read',{},'shared'),)),ChatModelResponse(tool_calls=(ToolCallRequest('echo',{'text':'native benign'},'shared'),)),ChatModelResponse.from_text('done')])
   failure=None;result=None
   try:result=await TurnProcessor(runtime).process('synthetic')
   except Exception as exc:failure=type(exc).__name__
   retained=runtime.chat_llm.current
   observations['collision']={'exception_type':failure,'persisted_entries_added':await store.count_entries('independent')-before,'continuation_tool_ids':[m.get('tool_call_id') for m in retained if m.get('role')=='tool'],'request_ids':[c.get('id') for m in retained if m.get('role')=='assistant' for c in m.get('tool_calls',[])],'record_ids':[r.call_id for r in result.tool_calls] if result else None}
   observations['audit']=[json.loads(l) for l in (directory/'audit-alpha.jsonl').read_text().splitlines()]
   observations['public_cleanup']=await public_clean(bridge,children)
  registry=FakeToolRegistry();schema=registry.list_tools()
  for shape in ['flat','function']:
   for name in [{'invalid':1},['invalid']]:
    raw={'id':'native-present','name':name,'arguments':{}} if shape=='flat' else {'id':'native-present','type':'function','function':{'name':name,'arguments':'{}'}}
    error=None;calls=None
    try:r=await ToolLoop(registry,max_iterations=1).run([{'role':'assistant','tool_calls':[raw]}],schema);calls=len(r.tool_calls)
    except Exception as exc:error=type(exc).__name__+': '+str(exc)
    observations['native_malformed'].append({'shape':shape,'name_type':type(name).__name__,'exception':error,'executed':calls})
 finally:
  observations['defensive_cleanup_errors']=await settle(bridges,children,initial)
 (OUT/f'finding-facts-{label}.json').write_text(json.dumps(observations,indent=2)+'\n');print(json.dumps(observations,indent=2))
if __name__=='__main__':asyncio.run(main(sys.argv[1]))
