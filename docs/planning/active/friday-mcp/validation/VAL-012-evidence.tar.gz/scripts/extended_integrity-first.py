from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re,yaml
ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=Path('/private/tmp/VAL-012-independent-20260928')
f=json.loads((OUT/'inputs/docs/planning/active/friday-mcp/validation/VAL-012-frozen-inputs.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
result={}
with tarfile.open(fileobj=io.BytesIO(git('archive',f['candidate_commit']))) as tar:
 actual={m.name:sha(tar.extractfile(m).read()) for m in tar.getmembers() if m.isfile() and m.name in f['tracked_product_bytes']}
assert actual==f['tracked_product_bytes']
result['candidate_git_product_count']=len(actual);result['all_candidate_product_blobs_match']=True
for label,archive,manifest in [
 ('ws05-builder','docs/planning/active/friday-mcp/execution/WS-05-builder-evidence.tar.gz','docs/planning/active/friday-mcp/execution/WS-05-builder-evidence.yaml'),
 ('val011','docs/planning/active/friday-mcp/validation/VAL-011-evidence.tar.gz','docs/planning/active/friday-mcp/validation/VAL-011-artifact-manifest.json'),
 ('rem006','docs/planning/active/friday-mcp/execution/REM-006-evidence.tar.gz','docs/planning/active/friday-mcp/execution/REM-006-artifact-manifest.json')]:
 data=(ROOT/manifest).read_text();declared=json.loads(data) if manifest.endswith('.json') else yaml.safe_load(data)
 entries=declared.get('entries',declared.get('members'))
 with tarfile.open(ROOT/archive,'r:gz') as tar:
  members={m.name:tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
  checks=[]
  for item in entries:
   name=item.get('member',item.get('path'));body=members[name]
   checks.append({'member':name,'bytes_match':len(body)==item['bytes'],'hash_match':sha(body)==item['sha256']})
  assert all(c['bytes_match'] and c['hash_match'] for c in checks)
 result[label]={'archive_sha256':sha((ROOT/archive).read_bytes()),'archive_members':len(members),'declared_checked':len(checks),'all_declared_exact':True,'checks':checks,'additional_members':sorted(set(members)-{c['member'] for c in checks})}
old=json.loads((ROOT/'docs/planning/active/friday-mcp/validation/VAL-011-frozen-inputs.json').read_text())
checks=[]
for group in ['authority','candidate_reports','tracked_product_bytes']:
 if group=='tracked_product_bytes':
  checks.append({'group':group,'count':len(old[group]),'same_original_git_blobs':all(sha(git('show',old['candidate_commit']+':'+p))==h for p,h in old[group].items())})
 else:
  checks.append({'group':group,'count':len(old[group]),'same_original_git_blobs':all(sha(git('show',x['revision']+':'+x['path']))==x['sha256'] for x in old[group])})
assert all(c['same_original_git_blobs'] for c in checks);result['old_freeze_original_blobs']=checks
cmd=['git','diff','--exit-code',f['base_commit']+'..'+f['candidate_commit'],'--','packages/friday-chat/tests_chat/test_reorganization_terminal.py','packages/friday-chat/tests_chat/test_llm_adapter_migration.py','tests/integration/test_development_board.py','pyproject.toml']
r=subprocess.run(cmd,cwd=ROOT,capture_output=True);assert r.returncode==0
result['unchanged_baseline_inputs']={'argv':cmd,'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
readlist=[{'path':x['path'],'revision':x['revision'],'sha256':x['sha256'],'read_completely':True} for x in f['authority']+f['candidate_reports']]
result['reading_inventory']=readlist
(OUT/'extended-integrity.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k in ['candidate_git_product_count','all_candidate_product_blobs_match']});print({k:(v['archive_members'],v['declared_checked']) for k,v in result.items() if isinstance(v,dict) and 'archive_members' in v})
