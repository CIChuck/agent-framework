from pathlib import Path
import subprocess,json,os,datetime
OUT=Path('/private/tmp/VAL-012-independent-20260928');ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
imports=json.loads((OUT/'candidate-imports.json').read_text())
extras={'PYTHONPATH':str(OUT/'scripts')+':'+':'.join(imports['pythonpath']),'LITELLM_LOCAL_MODEL_COST_MAP':'true','PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(OUT/'runtime/tmp')}
env=os.environ.copy();env.update(extras)
cmd=[str(ROOT/'.venv/bin/python'),'-m','pytest',str(OUT/'scripts/test_supplement.py'),'-q','-p','no:cacheprovider','--basetemp',str(OUT/'runtime/supplement')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUT/'logs/independent-supplement.log').open('wb') as log:r=subprocess.run(cmd,cwd=imports['root'],env=env,stdout=log,stderr=subprocess.STDOUT)
(OUT/'logs/independent-supplement.json').write_text(json.dumps({'argv':cmd,'environment':extras,'cwd':imports['root'],'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode},indent=2)+'\n')
print(r.returncode)
