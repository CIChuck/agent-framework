import asyncio,json
from dataclasses import replace
import pytest
from test_independent import owned
from probe_common import *
from friday_chat.turns.models import InteractionTurn,TurnMetrics
from friday_chat.turns.processor import TurnProcessor
from friday_chat.tools.output import MCPOutputPolicy
from friday_chat.tools.loop import ToolLoop
from friday_chat.tools.schemas import ToolDefinition,ToolCallRecord
from friday_core.mcp import MCPToolCallProvenance,MCPToolMetadata
from friday_transcript import TranscriptEntry,ToolCall,ToolResult
from pydantic import ValidationError
RESULTS={}
def note(k,v):RESULTS[k]=v;(OUT/'supplement-results.json').write_text(json.dumps(RESULTS,indent=2)+'\n')

@pytest.mark.asyncio
async def test_public_cleanup_failure_owner_retry_and_restart(owned,monkeypatch):
 create,children,directory=owned;runtime,bridge,store=await create()
 owner=bridge.provider;manager=owner.manager;original=manager.disconnect_all
 async def obstruct():raise RuntimeError('synthetic cleanup obstruction')
 monkeypatch.setattr(manager,'disconnect_all',obstruct)
 try:
  with pytest.raises(RuntimeError):await bridge.stop()
  assert runtime.mcp_tools is bridge and bridge.provider is owner and owner.manager is manager
  assert not bridge.tool_metadata and not owner.owned_tool_names and manager.connected_servers==['alpha']
 finally:monkeypatch.setattr(manager,'disconnect_all',original)
 await public_clean(bridge,children);await bridge.start();assert bridge.tool_metadata
 note('cleanup-obstruction',{'owner_retained':True,'public_retry_restart':True,'public_cleanup':await public_clean(bridge,children)})

@pytest.mark.asyncio
async def test_stop_during_memory_preserves_pending_capture_policy(owned):
 create,children,directory=owned;runtime,bridge,store=await create();original=runtime.memory.retrieve
 async def stop(query,*,token_limit):await public_clean(bridge,children);return await original(query,token_limit=token_limit)
 runtime.memory.retrieve=stop;runtime.chat_llm=Model([ChatModelResponse(content=ARG,tool_calls=(ToolCallRequest('mcp_alpha_probe_read',{'payload':ARG},'bad/'+ARG),))])
 r=await TurnProcessor(runtime).process('synthetic')
 assert not r.tool_calls and ARG not in repr(r)+repr(await store.get_entries('independent'))+repr(await store.get_context_log_for_session('independent'))
 assert json.loads(r.raw_response)['tool_calls'][0]['arguments']=={}
 audits=[json.loads(l) for l in (directory/'audit-alpha.jsonl').read_text().splitlines()];assert not any(a['event']=='call' for a in audits)
 note('stop-before-model',{'capture_names_retained':True,'unexecuted_not_fabricated':True,'public_cleanup':await public_clean(bridge,children)})

@pytest.mark.asyncio
@pytest.mark.parametrize('invalid',['arguments','id','unchecked','size','correlation','entry'])
async def test_actual_adapter_negative_contracts_before_store(tmp_path,invalid):
 tool=MCPToolMetadata(canonical_name='mcp_alpha_probe_read',server_name='alpha',original_name='Probe.Read',transport='stdio',trust_level='local')
 r=MCPOutputPolicy(256).checked_record(tool,'safe','benign',{});entry='entry'
 if invalid=='arguments':r=replace(r,arguments={'payload':ARG})
 elif invalid=='id':r=replace(r,call_id='other')
 elif invalid=='entry':entry='bad/'+ARG
 else:
  key,value={'unchecked':('output_sanitization_state','not_checked'),'size':('model_result_size_bytes',1),'correlation':('transcript_correlation_id','other')}[invalid]
  r=replace(r,mcp_provenance=r.mcp_provenance.model_copy(update={key:value}))
 cfg=configuration(tmp_path);store=SQLiteTranscriptStore(tmp_path/'negative.sqlite');adapter=FrameworkTranscriptAdapter(store,cfg,'negative')
 with pytest.raises(ValueError) as caught:await adapter.record_interaction(InteractionTurn(entry,'user','assistant','p','c',(),TurnMetrics(0,0,0,0),tool_calls=(r,)))
 assert ARG not in str(caught.value) and await store.count_entries('negative')==0
 note('adapter-'+invalid,{'rejected_before_entry':True,'safe_error':True})

def test_strict_actual_correlation_mismatch_entryid_and_pairfacts():
 tool=MCPToolMetadata(canonical_name='mcp_alpha_probe_read',server_name='alpha',original_name='Probe.Read',transport='stdio',trust_level='local');r=MCPOutputPolicy(256).checked_record(tool,'safe','benign',{})
 facts=MCPToolCallProvenance.model_validate({**r.mcp_provenance.model_dump(),'transcript_correlation_id':'entry'})
 call=ToolCall(id='safe',name=tool.canonical_name,mcp_provenance=facts);result=ToolResult(tool_call_id='safe',output=r.result,mcp_provenance=facts)
 for entry in ['other','bad/'+ARG]:
  with pytest.raises(ValidationError) as caught:TranscriptEntry(id=entry,session_id='s',turn_number=1,tool_calls=[call],tool_results=[result])
  assert ARG not in str(caught.value)
 changed=MCPToolCallProvenance.model_validate({**facts.model_dump(),'result_size_bytes':100})
 with pytest.raises(ValidationError):TranscriptEntry(id='entry',session_id='s',turn_number=1,tool_calls=[call],tool_results=[ToolResult(tool_call_id='safe',output=r.result,mcp_provenance=changed)])
 note('entry-negative',{'invalid_entry_correlation_and_different_facts_rejected':True})

@pytest.mark.asyncio
async def test_broken_public_recording_boundary_rejects_without_payload():
 class Broken:
  def is_mcp_tool(self,name):return True
  async def call_tool(self,name,arguments):return ARG
  async def call_tool_record(self,name,arguments,**kw):return ToolCallRecord(name,arguments,ARG,'id')
 with pytest.raises(RuntimeError,match='checked per-call provenance') as caught:await ToolLoop(Broken()).run([{'tool_calls':[{'name':'mcp_alpha_probe_read','id':'id','arguments':{'payload':ARG}}]}],[ToolDefinition('mcp_alpha_probe_read','safe')])
 assert ARG not in str(caught.value)
 note('broken-recorder',{'safe_explicit_rejection':True})
