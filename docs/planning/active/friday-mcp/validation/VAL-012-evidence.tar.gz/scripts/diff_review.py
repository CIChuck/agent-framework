from pathlib import Path
import subprocess,json,shutil,hashlib,tarfile,io
ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework');OUT=Path('/private/tmp/VAL-012-independent-20260928')
f=json.loads((OUT/'inputs/docs/planning/active/friday-mcp/validation/VAL-012-frozen-inputs.json').read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
scope=json.loads((OUT/'scope.json').read_text());results={}
for mode,base in [('delta',f['remediation_base_commit']),('aggregate',f['base_commit'])]:
 paths=scope[mode]['all_changed']
 groups={'source':[p for p in paths if '/src/' in p or p.endswith(('pyproject.toml','uv.lock'))],'tests':[p for p in paths if p.startswith(('packages/','tests/')) and p not in paths if False]}
 groups['tests']=[p for p in paths if p.startswith(('packages/','tests/')) and p not in groups['source']]
 groups['process']=[p for p in paths if p not in groups['source']+groups['tests']]
 for group,names in groups.items():
  b=git('diff',f"{base}..{f['candidate_commit']}",'--',*names)
  (OUT/f'{mode}-{group}.diff').write_bytes(b)
  print(mode,group,'lines',len(b.splitlines()),'paths',len(names))
 for p in scope[mode]['product_changed']:
  target=OUT/'sources'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(git('show',f"{f['candidate_commit']}:{p}"))
 for p in groups['process']:
  if p.endswith('.tar.gz'):continue
  target=OUT/'process'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(git('show',f"{f['candidate_commit']}:{p}"))
for item in f['historical_evidence']+f['builder_evidence']:
 if not item['path'].endswith('.tar.gz'):continue
 b=(ROOT/item['path']).read_bytes()
 members=[]
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as tar:
  for m in tar.getmembers():
   assert not m.name.startswith('/') and '..' not in Path(m.name).parts
   if m.isfile():
    data=tar.extractfile(m).read();members.append({'member':m.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 results[item['path']]={'sha256':hashlib.sha256(b).hexdigest(),'matches_pinned':hashlib.sha256(b).hexdigest()==item['sha256'],'members':members}
(OUT/'prior-archives-integrity.json').write_text(json.dumps(results,indent=2)+'\n')
