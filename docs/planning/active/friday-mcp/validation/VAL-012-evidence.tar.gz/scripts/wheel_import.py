import sys,json
from pathlib import Path
root=Path(sys.argv[1]);third=Path(sys.argv[2]);sys.path[:0]=[str(root),str(third)]
import friday_transcript,friday_core,friday_telemetry
from friday_core.mcp import MCPToolMetadata,MCPToolCallProvenance
from friday_transcript import TranscriptEntry,ToolCall,ToolResult,SQLiteTranscriptStore,JSONLExporter,CSVExporter,MarkdownExporter
paths={m.__name__:m.__file__ for m in [friday_core,friday_telemetry,friday_transcript]}
assert all(Path(p).is_relative_to(root) for p in paths.values())
assert not any('/Dev/gendev/agent-framework' in p for p in sys.path)
tool=MCPToolMetadata(canonical_name='mcp_peer_read',server_name='peer',original_name='Read',transport='stdio',trust_level='local')
facts=MCPToolCallProvenance(tool=tool,call_id='id1',status='succeeded',output_sanitization_state='sanitized',model_result_size_bytes=2,transcript_correlation_id='entry1')
entry=TranscriptEntry(id='entry1',session_id='s',turn_number=1,tool_calls=[ToolCall(id='id1',name=tool.canonical_name,mcp_provenance=facts)],tool_results=[ToolResult(tool_call_id='id1',output='ok',mcp_provenance=facts)])
assert TranscriptEntry.model_validate_json(entry.model_dump_json())==entry
print(json.dumps({'paths':paths,'sys_path':sys.path,'typed_roundtrip':True,'public_storage_export_imports':True,'python':sys.version},indent=2))
