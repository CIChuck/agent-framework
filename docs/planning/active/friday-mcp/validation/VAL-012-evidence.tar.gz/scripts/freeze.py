from pathlib import Path
import hashlib, json, subprocess, sys

ROOT=Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT=Path('/private/tmp/VAL-012-independent-20260928')
manifest_path=ROOT/'docs/planning/active/friday-mcp/validation/VAL-012-frozen-inputs.json'
f=json.loads(manifest_path.read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def fingerprint(name):
    p=ROOT/name
    if not p.exists() and not p.is_symlink(): return {'state':'absent'}
    files=sorted([p] if p.is_file() or p.is_symlink() else [x for x in p.rglob('*') if x.is_file() or x.is_symlink()])
    h=hashlib.sha256()
    for q in files:
        h.update(q.relative_to(ROOT).as_posix().encode()+b'\0')
        h.update(('symlink:'+str(q.readlink())).encode() if q.is_symlink() else q.read_bytes())
        h.update(b'\0')
    return {'files':len(files),'sha256':h.hexdigest(),'state':'present'}
def verify(stage):
    checks=[]
    groups={'request':[f['request']], **{g:f[g] for g in ['authority','candidate_reports','historical_evidence','builder_evidence']}}
    for group,entries in groups.items():
        for item in entries:
            b=(ROOT/item['path']).read_bytes()
            actual=sha(b)
            c={'group':group,'path':item['path'],'actual':actual,'expected':item['sha256'],'ok':actual==item['sha256']}
            if item.get('revision'):
                c['git_sha256']=sha(git('show',f"{item['revision']}:{item['path']}"))
                c['git_ok']=c['git_sha256']==item['sha256']
            checks.append(c)
    for name,expected in f['tracked_product_bytes'].items():
        actual=sha((ROOT/name).read_bytes())
        checks.append({'group':'tracked_product_bytes','path':name,'actual':actual,'expected':expected,'ok':actual==expected})
    preserved={name:fingerprint(name) for name in f['preserved_unrelated']}
    r={'stage':stage,'candidate_commit':f['candidate_commit'],'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'status':git('status','--short','--untracked-files=normal').decode(),'manifest_sha256':sha(manifest_path.read_bytes()),'checks':checks,'preserved_unrelated':preserved,'preserved_ok':preserved==f['preserved_unrelated']}
    r['all_ok']=all(x['ok'] and x.get('git_ok',True) for x in checks) and r['preserved_ok']
    (OUT/f'freeze-{stage}.json').write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:r[k] for k in ['stage','head','branch','manifest_sha256','all_ok','preserved_ok']}))
    print('checked',len(checks),'files; mismatches', [x for x in checks if not x['ok'] or not x.get('git_ok',True)])
if __name__=='__main__': verify(sys.argv[1])
