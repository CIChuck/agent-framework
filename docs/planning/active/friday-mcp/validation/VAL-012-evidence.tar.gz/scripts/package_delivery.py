from pathlib import Path
import json,hashlib,tarfile,io,gzip,re,shutil,datetime
OUT=Path('/private/tmp/VAL-012-independent-20260928')
def sha(b):return hashlib.sha256(b).hexdigest()
# Preserve every own synthetic audit from every attempted probe revision.
for p in sorted((OUT/'runtime').rglob('audit-*.jsonl')):
 if not p.is_file():continue
 target=OUT/'audits'/p.relative_to(OUT/'runtime');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
excluded={'artifact-manifest.json','delivery.json','archive-verification.json','VAL-012-evidence.tar.gz'}
files=[p for p in sorted(OUT.rglob('*')) if p.is_file() and p.relative_to(OUT).parts[0]!='runtime' and '__pycache__' not in p.parts and p.name not in excluded]
entries=[{'member':p.relative_to(OUT).as_posix(),'source_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]
manifest={'validation_id':'VAL-012','archive_filename':'VAL-012-evidence.tar.gz','entries':entries,'excluded_scratch':['runtime databases','cache/venv/extracted source and wheel trees','temporary export trees','unrelated paths','credentials'],'self_hash_policy':'Manifest excludes itself; archive includes it, delivery hashes it separately.'}
(OUT/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files.append(OUT/'artifact-manifest.json')
with (OUT/'VAL-012-evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for p in sorted(files):
    name=p.relative_to(OUT).as_posix();body=p.read_bytes();member=tarfile.TarInfo(name);member.size=len(body);member.mtime=0;member.mode=0o755 if p.name=='git' else 0o644;member.uid=member.gid=0;member.uname=member.gname='';tar.addfile(member,io.BytesIO(body))
with tarfile.open(OUT/'VAL-012-evidence.tar.gz','r:gz') as tar:
 members={m.name:tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
assert set(members)=={e['member'] for e in entries}|{'artifact-manifest.json'}
checks=[{'member':e['member'],'bytes_match':len(members[e['member']])==e['bytes'],'sha256_match':sha(members[e['member']])==e['sha256']} for e in entries]
assert all(c['bytes_match'] and c['sha256_match'] for c in checks)
links=re.findall(r'\]\(VAL-012-evidence\.tar\.gz#([^)]*)\)',(OUT/'report.md').read_text());assert all(n in members for n in links)
# Markdown tables are contiguous and have a fixed number of unescaped columns.
tables=[];current=[]
for line in (OUT/'report.md').read_text().splitlines()+['']:
 if line.startswith('|'):current.append(line)
 elif current:
  counts=[len(re.split(r'(?<!\\)\|',line)) for line in current];assert len(set(counts))==1,counts;tables.append({'rows':len(current),'columns':counts[0]-2});current=[]
verification={'all_member_hashes_verified':True,'member_count':len(members),'checks':checks,'report_links':len(links),'all_report_links_resolve':True,'markdown_tables':tables,'all_markdown_tables_valid':True}
(OUT/'archive-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
def artifact(name):
 p=OUT/name;return {'path':str(p),'member':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
delivery={'validation_id':'VAL-012','candidate':'f24ed20f82eac0cbce17e4b86615497cc9993921','review_modes':{'delta':'CHANGES_REQUESTED','work_unit_aggregate':'CHANGES_REQUESTED'},'overall_outcome':'CHANGES_REQUESTED','findings':[{'id':'VAL-012-F-001','severity':'Medium'}],'original_findings':{'VAL-011-F-001':'Closed','VAL-011-F-002':'Closed'},'report':artifact('report.md'),'manifest':artifact('artifact-manifest.json'),'archive':artifact('VAL-012-evidence.tar.gz'),'verification':artifact('archive-verification.json'),'archive_members':len(members),'all_member_hashes_verified':True,'report_archive_links_checked':len(links),'all_report_links_resolve':True,'governed_workspace_read_only':True,'final_freeze_all_ok':json.loads((OUT/'freeze-closeout.json').read_text())['all_ok'],'self_hash_policy':'delivery.json and archive-verification.json external to archive; manifest self-excluded from its own entries.'}
(OUT/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n');print(json.dumps(delivery,indent=2))
