from pathlib import Path
import os,subprocess,time,json,yaml,shlex,signal
root=Path('/private/tmp/VAL-010-independent-20260928')
r=yaml.safe_load((root/'request.yaml').read_text())
env=os.environ.copy();env.update(UV_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
results=[]
for i,cmd in enumerate(r['required_checks'],1):
 log=root/f'check-{i:02}.log';start=time.monotonic();print(f'START {i}: {cmd}',flush=True)
 with log.open('w') as f:
  p=subprocess.Popen(cmd,shell=True,executable='/bin/zsh',cwd='/Users/chuckrussell/Dev/gendev/agent-framework',env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=600)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
   code=124
 elapsed=time.monotonic()-start
 results.append(dict(number=i,command=cmd,exit=code,seconds=round(elapsed,3),log=log.name))
 (root/'required-checks.json').write_text(json.dumps(results,indent=2))
 print(f'END {i} exit={code} seconds={elapsed:.3f}',flush=True)
 print('\n'.join(log.read_text().splitlines()[-6:]),flush=True)
