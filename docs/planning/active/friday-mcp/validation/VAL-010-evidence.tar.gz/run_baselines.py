from pathlib import Path
import os,subprocess,json,time,tarfile,io
root=Path('/private/tmp/VAL-010-independent-20260928');repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');base='acd1fd1e736a38134fac40d7fdb35cd1f32cf683'
pre=root/'predecessor';pre.mkdir(exist_ok=True)
data=subprocess.check_output(['git','archive',base,'packages','tests','scripts','docs','pyproject.toml','uv.lock','AGENTS.md'],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(data)) as tf:tf.extractall(pre,filter='data')
env=os.environ.copy();env.update(LITELLM_LOCAL_MODEL_COST_MAP='true',UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1');exe=str(repo/'.venv/bin/python')
commands=[('chat',[exe,'-m','pytest','packages/friday-chat/tests_chat','-q','--tb=short'],True),('board',[exe,'-m','pytest','tests/integration/test_development_board.py','-q','--tb=short'],True),('mypy',[exe,'-m','mypy','packages/friday-chat','packages/friday-runtime','packages/friday-memory','--cache-dir',str(root/'baseline-mypy-cache')],False)]
results=[]
for name,argv,archived_imports in commands:
 runenv=env.copy()
 if archived_imports:runenv['PYTHONPATH']=os.pathsep.join(str(p) for p in sorted(pre.glob('packages/*/src')))
 else:
  runenv.pop('PYTHONPATH',None);runenv.pop('MYPYPATH',None)
 print('START baseline',name,flush=True);start=time.monotonic()
 with (root/f'baseline-{name}.log').open('w') as f:
  cp=subprocess.run(argv,cwd=pre,env=runenv,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 results.append(dict(name=name,argv=argv,cwd=str(pre),exit=cp.returncode,seconds=round(time.monotonic()-start,3),PYTHONPATH=runenv.get('PYTHONPATH'),log=f'baseline-{name}.log'))
 (root/'baseline-results.json').write_text(json.dumps(results,indent=2));print('END',name,cp.returncode,flush=True);print('\n'.join((root/f'baseline-{name}.log').read_text().splitlines()[-6:]),flush=True)
