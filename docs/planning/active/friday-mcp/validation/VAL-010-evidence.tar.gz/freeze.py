from pathlib import Path
import subprocess,hashlib,json,yaml,datetime,sys,tarfile
root=Path('/private/tmp/VAL-010-independent-20260928');repo=Path('/Users/chuckrussell/Dev/gendev/agent-framework');request=repo/'docs/planning/active/friday-mcp/validation/VAL-010-request.yaml';r=yaml.safe_load(request.read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def digest(b):return hashlib.sha256(b).hexdigest()
m={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'candidate':r['candidate_commit'],'request_sha256':digest(request.read_bytes()),'request_head_sha256':digest(git('show','HEAD:'+str(request.relative_to(repo)))),'pinned':[],'product_tracked':{},'unrelated':{},'comparisons':{}}
for section in ('authority','candidate_report_hashes'):
 for row in r[section]:
  actual=digest((repo/row['path']).read_bytes());blob=digest(git('show',r['candidate_commit']+':'+row['path']));m['pinned'].append({**row,'actual':actual,'candidate_blob':blob,'match':row['sha256']==actual==blob})
for path in git('ls-files','packages','tests','pyproject.toml','uv.lock').decode().splitlines():
 f=repo/path;m['product_tracked'][path]=digest(f.read_bytes()) if f.is_file() else 'MISSING'
for q in r['preserved_unrelated_paths']:
 p=repo/q
 if p.is_dir():m['unrelated'][q]={str(f.relative_to(repo)):digest(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file()}
 else:m['unrelated'][q]={q:digest(p.read_bytes()) if p.is_file() else 'MISSING'}
m['status']=git('status','--porcelain=v1').decode()
for label,args in [('candidate-product',['diff','--exit-code',r['candidate_commit'],'--','packages','tests','pyproject.toml','uv.lock']),('candidate-reports',['diff','--exit-code',r['candidate_commit'],'--',*[x['path'] for x in r['candidate_report_hashes']]]),('aggregate-whitespace',['diff','--check',r['diff_range']]),('unchanged-baseline-inputs',['diff','--exit-code',r['base_commit']+'..'+r['candidate_commit'],'--','tests/integration/test_development_board.py','packages/friday-chat/tests_chat/test_reorganization_terminal.py','packages/friday-chat/tests_chat/test_llm_adapter_migration.py','pyproject.toml','uv.lock'])]:
 cp=subprocess.run(['git',*args],cwd=repo,text=True,capture_output=True);m['comparisons'][label]={'argv':['git',*args],'exit':cp.returncode,'stdout':cp.stdout,'stderr':cp.stderr}
m['ws04_authorization_hash']=digest(git('show',r['work_unit_authorization_commit']+':docs/planning/active/friday-mcp/directives/ws-04-friday-chat-context-budget.md'))
m['postcandidate_diff_paths']=git('diff','--name-only',r['candidate_commit']+'..HEAD').decode().splitlines()
start=json.loads((root/'freeze-start.json').read_text());m['start_comparison']={'same_request':m['request_sha256']==start['request_sha256'],'same_pinned':[(x['path'],x['actual']) for x in m['pinned']]==[(x['path'],x['actual']) for x in start['pinned']],'same_product':m['product_tracked']==start['product_tracked'],'same_branch':m['branch']==start['branch'],'same_status':m['status']==start['status']}
name=sys.argv[1] if len(sys.argv)>1 else 'freeze-closeout.json';(root/name).write_text(json.dumps(m,indent=2));assert all(x['match'] for x in m['pinned']);assert all(m['start_comparison'].values());assert all(c['exit']==0 for c in m['comparisons'].values());print(json.dumps({k:v for k,v in m.items() if k not in ('product_tracked','unrelated','pinned')},indent=2));print('pinned',len(m['pinned']),'product',len(m['product_tracked']),'unrelated_files',sum(len(d) for d in m['unrelated'].values()))
