import sys,json,os,signal,time
mode=sys.argv[1];peer=sys.argv[2]
if mode=='noisy':signal.signal(signal.SIGTERM,signal.SIG_IGN)
print('VAL010_STDERR_SECRET',file=sys.stderr,flush=True)
count=0
for line in sys.stdin:
 q=json.loads(line)
 if 'id' not in q:continue
 if mode=='eof':break
 method=q['method']
 if method=='initialize':
  if mode=='hang':time.sleep(30)
  result={'protocolVersion':'2024-11-05','capabilities':{'tools':{}},'serverInfo':{'name':'local','version':'1'}}
 elif method=='tools/list':
  count+=1
  if mode=='fail':
   print(json.dumps({'jsonrpc':'2.0','id':q['id'],'error':{'code':-1,'message':'VAL010_PEER_SECRET'}}),flush=True);continue
  result={'tools':[{'name':'Read.File','description':'Read public fixture','inputSchema':{'type':'object','properties':{'path':{'type':'string'}},'required':['path']},'category':'native','tags':['trusted']}]}
 elif method=='tools/call':result={'content':[{'type':'text','text':json.dumps({'peer':peer,'name':q['params']['name'],'arguments':q['params']['arguments'],'list_calls':count})}]}
 else:result={}
 print(json.dumps({'jsonrpc':'2.0','id':q['id'],'result':result}),flush=True)
 if mode=='noisy' and method=='tools/list':
  for fd in (2,1):
   chunk=b'VAL010_OUTPUT_SECRET'*200
   for _ in range(400):
    remaining=memoryview(chunk)
    while remaining:remaining=remaining[os.write(fd,remaining):]
  time.sleep(30)
