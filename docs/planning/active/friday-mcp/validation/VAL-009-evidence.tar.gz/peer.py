import json
import os
import signal
import sys
import time

catalog = json.load(open(sys.argv[1]))
identity, mode = sys.argv[2:4]
if mode.startswith('noisy'):
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
print('VAL009-STDERR-SECRET', file=sys.stderr, flush=True)
calls = 0
for line in sys.stdin:
    request = json.loads(line)
    if 'id' not in request:
        continue
    method = request['method']
    if method == 'initialize':
        result = {'protocolVersion': '2024-11-05', 'capabilities': {'tools': {}}, 'serverInfo': {'name': 'local', 'version': '1'}}
    elif method == 'tools/list':
        calls += 1
        result = {'tools': catalog}
    elif method == 'tools/call':
        result = {'content': [{'type': 'text', 'text': json.dumps({'identity': identity, 'name': request['params']['name'], 'arguments': request['params']['arguments'], 'list_calls': calls})}]}
    else:
        result = {}
    reply = {'jsonrpc': '2.0', 'id': request['id'], 'result': result}
    if method == 'tools/list' and mode == 'noisy_fail':
        reply.pop('result')
        reply['error'] = {'code': -1, 'message': 'VAL009-PEER-SECRET'}
    print(json.dumps(reply), flush=True)
    if method == 'tools/list' and mode.startswith('noisy'):
        chunk = b'VAL009-NOISY-SECRET' * 200
        for descriptor in (2, 1):
            for _ in range(400):
                remaining = memoryview(chunk)
                while remaining:
                    remaining = remaining[os.write(descriptor, remaining):]
        time.sleep(30)
