import asyncio
import dataclasses
import hashlib
import json
from unittest.mock import patch

import probes
from friday_agent import DefaultToolRegistry
from friday_mcp.client.manager import MCPClientManager
from friday_runtime.mcp_loading import RuntimeMCPProvider
from friday_runtime.mcp_registration import MCPRegistrationError, prepare_registration
from friday_runtime.tool_loading import ToolProviderLoadError

async def main():
    # Same first-24 masked shape: only full-original fingerprints distinguish.
    names = ('-' * 20000 + 'Read.File', '-' * 20000 + 'Read-File')
    try:
        prepare_registration(probes.cfg(mode='selected'), probes.entries([probes.raw(n) for n in names]), {}, [])
    except MCPRegistrationError as failure:
        collision = failure.decisions[-1].collision
        a, b = collision.first.original_name_summary, collision.second.original_name_summary
        assert a.shape == b.shape == '-' * 24 and a.length == b.length == '9999+'
        assert a.fingerprint != b.fingerprint
        assert a.fingerprint == hashlib.sha256(names[0].encode()).hexdigest()[:12]
        for target, attr, value in [(collision, 'canonical_name', 'changed'), (collision.first, 'provider', 'native')]:
            try: setattr(target, attr, value)
            except dataclasses.FrozenInstanceError: pass
            else: raise AssertionError('mutable nested collision record')
    else: raise AssertionError('same-shape collision missed')
    probes.record('same_shape_fingerprint', complete_original_hashed=True, frozen_nested_record=True)

    # New optional discovery failure must erase old collision rather than reuse it.
    clients = []; mode = {'failed': False}; catalog = [probes.raw('Read.File'), probes.raw('Read-File')]
    def create(manager, config):
        c = probes.Client(config.name, catalog, 'list_fail' if mode['failed'] else 'good'); clients.append(c); return c
    provider = RuntimeMCPProvider(probes.cfg(mode='selected'), str(probes.OUT))
    with patch.object(MCPClientManager, '_create_client', create):
        try:
            await provider.start()
            try: await provider.register_tools(DefaultToolRegistry())
            except ToolProviderLoadError: pass
            history = provider.registration_decisions
            assert history[-1].collision
            mode['failed'] = True
            await provider.start()
            assert not provider.registration_decisions and provider.diagnostics.failed_servers == 2
            assert history[-1].collision
            await provider.stop()
            assert not provider.manager.connected_servers
        finally:
            for c in clients: c.fail_cleanup = False
            await provider.stop()
    probes.record('optional_failure_attempt_reset', old_collision_cleared=True, snapshot_retained=True)

    # Public kernel startup failure / retry preserves provider and manager identity.
    clients = []; obstruct = {'enabled': True}
    def factory(manager, config):
        c = probes.Client(config.name, [probes.raw('good')], 'list_fail' if config.name == 'bad' and obstruct['enabled'] else 'good')
        c.fail_cleanup = config.name == 'bad' and obstruct['enabled']; clients.append(c); return c
    async with probes.local_kernel({'good': [probes.raw('good')], 'bad': [probes.raw('bad')]}) as (kernel, processes, snaps, initial):
        with patch.object(MCPClientManager, '_create_client', factory):
            try:
                for attempt in range(2):
                    try: await kernel.start()
                    except ToolProviderLoadError: pass
                    else: raise AssertionError('cleanup-failed startup not rejected')
                    if attempt == 0: owner = kernel.mcp_provider; manager = owner.manager
                    assert kernel.mcp_provider is owner and owner.manager is manager
                    assert not owner.tool_metadata and not owner.prepared_tools
                    assert len(clients) == 2 and not clients[0].is_connected and clients[1].is_connected
                    assert manager.connected_servers == ['bad']
                obstruct['enabled'] = False; clients[1].fail_cleanup = False
                await kernel.stop()
                assert not manager.connected_servers and kernel.mcp_provider is owner
                await kernel.start()
                assert kernel.mcp_provider is owner and set(owner.tool_metadata) == {'mcp_good_good', 'mcp_bad_good'}
                await kernel.stop()
                await probes.assert_public_clean(kernel, processes, snaps, initial)
                assert all(not c.is_connected for c in clients)
            finally:
                obstruct['enabled'] = False
                for c in clients: c.fail_cleanup = False
                await kernel.stop()
    probes.record('public_kernel_startup_owner_retry', identity_retained=True, successful_peer_drained=True, public_recovery=True)

    # Canceled retry cleanup retains the owner; then public stop settles it.
    clients = []; entered = asyncio.Event(); release = asyncio.Event(); blocked = {'enabled': False}
    class PausedClient(probes.Client):
        async def disconnect(self):
            if blocked['enabled']:
                entered.set(); await release.wait()
            await super().disconnect()
    def factory(manager, config):
        c = PausedClient(config.name, [probes.raw('good')]); clients.append(c); return c
    provider = RuntimeMCPProvider(probes.cfg(), str(probes.OUT))
    task = None
    with patch.object(MCPClientManager, '_create_client', factory):
        try:
            await provider.start(); await provider.register_tools(DefaultToolRegistry()); owner = provider.manager
            clients[0].fail_cleanup = True
            try: await provider.stop()
            except ToolProviderLoadError: pass
            clients[0].fail_cleanup = False; blocked['enabled'] = True
            task = asyncio.create_task(provider.start()); await asyncio.wait_for(entered.wait(), 1)
            task.cancel()
            try: await task
            except asyncio.CancelledError: pass
            else: raise AssertionError('retry cancellation lost')
            assert provider.manager is owner and owner.connected_servers
            blocked['enabled'] = False; release.set(); await provider.stop()
            assert not owner.connected_servers and all(not c.is_connected for c in clients)
        finally:
            blocked['enabled'] = False; release.set()
            for c in clients: c.fail_cleanup = False
            if task is not None:
                if not task.done(): task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            await provider.stop()
    probes.record('canceled_retry_owner', cancellation_propagated=True, retained_public_owner=True, public_stop_recovers=True)

    # Intentional scratch assertion: validates defensive fixture settlement only.
    witnessed = None; initial = asyncio.all_tasks()
    try:
        async with probes.local_kernel({'peer': [probes.raw()]}, modes={'peer': 'noisy_success'}) as (kernel, processes, snaps, initial):
            await kernel.start(); witnessed = processes
            raise AssertionError('deliberate scratch fixture control')
    except AssertionError as failure:
        assert str(failure) == 'deliberate scratch fixture control'
    assert witnessed and all(p.returncode is not None and p.stdout.at_eof() and p.stderr.at_eof() for p in witnessed)
    assert not [t for t in asyncio.all_tasks() - initial if not t.done()]
    probes.record('assertion_failure_defensive_settlement', deliberately_injected_assertion=True, reaped_and_drained=True, tasks_settled=True, not_public_cleanup_evidence=True)

if __name__ == '__main__': asyncio.run(main())
