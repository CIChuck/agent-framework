import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/chuckrussell/Dev/gendev/agent-framework')
OUT = Path('/private/tmp/val009-20260928')
START = json.loads((OUT / 'start.json').read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def digest(value):
    return hashlib.sha256(value).hexdigest()

manifest = {}
for name, prior in START['manifest'].items():
    actual = digest((ROOT / name).read_bytes())
    committed = digest(git('show', START['candidate'] + ':' + name))
    manifest[name] = {'expected': prior['expected'], 'actual': actual,
                      'committed': committed,
                      'match': actual == committed == prior['expected']}

source_paths = git('ls-files', '-z', '--', 'packages', 'tests', 'pyproject.toml', 'uv.lock').decode().split('\0')
source = {name: digest((ROOT / name).read_bytes()) for name in source_paths if name}
unrelated = {}
for name in START['unrelated']:
    path = ROOT / name
    files = [path] if path.is_file() else sorted(p for p in path.rglob('*') if p.is_file()) if path.is_dir() else []
    unrelated[name] = {str(p.relative_to(ROOT)): digest(p.read_bytes()) for p in files}

request = 'docs/planning/active/friday-mcp/validation/VAL-009-request.yaml'
snapshot = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': git('rev-parse', 'HEAD').decode().strip(),
    'branch': git('branch', '--show-current').decode().strip(),
    'candidate': START['candidate'],
    'request_sha256': digest((ROOT / request).read_bytes()),
    'request_commit_sha256': digest(git('show', '34a457a540ca5e092c332431c824a537dcf7a8b0:' + request)),
    'manifest': manifest, 'source': source, 'unrelated': unrelated,
    'status': git('status', '--porcelain=v1').decode(),
}
snapshot['stability'] = {key: snapshot[key] == START[key] for key in
                         ['head', 'branch', 'candidate', 'request_sha256', 'manifest', 'source', 'unrelated', 'status']}
snapshot['all_pinned_match'] = all(item['match'] for item in manifest.values())
snapshot['request_matches_frozen_blob'] = snapshot['request_sha256'] == snapshot['request_commit_sha256']
snapshot['candidate_product_diff_exit'] = subprocess.run(
    ['git', 'diff', '--exit-code', START['candidate'], '--', 'packages', 'tests', 'pyproject.toml', 'uv.lock'],
    cwd=ROOT, capture_output=True).returncode
snapshot['candidate_reports_diff_exit'] = subprocess.run(
    ['git', 'diff', '--exit-code', START['candidate'], '--',
     'docs/planning/active/friday-mcp/execution/REM-005-implementation-report.md',
     'docs/planning/active/friday-mcp/execution/WS-03-implementation-report.md'],
    cwd=ROOT, capture_output=True).returncode
snapshot['all_stable'] = all(snapshot['stability'].values()) and snapshot['all_pinned_match'] and snapshot['request_matches_frozen_blob'] and snapshot['candidate_product_diff_exit'] == 0 and snapshot['candidate_reports_diff_exit'] == 0
(OUT / 'closeout.json').write_text(json.dumps(snapshot, indent=2) + '\n')
print(json.dumps({key: snapshot[key] for key in ['utc', 'head', 'branch', 'request_sha256', 'stability', 'all_pinned_match', 'request_matches_frozen_blob', 'candidate_product_diff_exit', 'candidate_reports_diff_exit', 'all_stable']}, indent=2))
assert snapshot['all_stable']
