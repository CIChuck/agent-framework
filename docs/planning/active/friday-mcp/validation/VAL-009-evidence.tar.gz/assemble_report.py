import hashlib
import json
from pathlib import Path
import re
import shlex

OUT = Path('/private/tmp/val009-20260928')
start = json.loads((OUT / 'start.json').read_text())
close = json.loads((OUT / 'closeout.json').read_text())
checks = json.loads((OUT / 'required-checks.json').read_text())
baselines = json.loads((OUT / 'baseline-results.json').read_text())
probes = json.loads((OUT / 'all-probe-results.json').read_text())
body = (OUT / 'report-body.md').read_text()
main, residual = body.split('## Documentation/configuration and remaining gates', 1)
parts = [main]

def add(value=''):
    parts.append(value + '\n')

add('## Required commands, exact exits and results\n')
add('All 17 request commands were independently run in the governed workspace. Recorded command strings below are exact; process-level `UV_OFFLINE=true` and `PYTHONDONTWRITEBYTECODE=1` were also supplied. Required local LiteLLM cost-map and UV-cache prefixes were retained. No error filtering, import-silent substitute or remote call was used. Wall seconds are subprocess elapsed times; pytest times are its own reported times. Twelve commands exited 0; five failed as explicitly recorded. Complete logs and structured records are preserved in [required-checks.json](required-checks.json).\n')
outcomes = {
 1: '173 passed in 5.82s.',
 2: '459 passed in 52.22s; complete affected WS-00/01/02/03 and REM-003/004 regression targets.',
 3: '233 passed, 2 failed, 1 warning in 11.82s. Same invalid-ZIP DOCX/XLSX fixtures as predecessor; baseline B1.',
 4: '46 passed in 1.39s.',
 5: '69 passed, 1 failed in 50.02s. Board-count assertion expects 22, canonical output 23; baseline B2.',
 6: 'All checks passed.',
 7: 'Installed NumPy __init__.pyi:737 syntax unsupported under default Python 3.10 target; 1 error prevents further project checking. Baseline B3.',
 8: 'Exactly four untouched profiles.py no-any-return errors at 77/82/110/115; checked 1 root source file. Baseline B5.',
 9: 'Success: no issues found in 45 source files.',
10: 'Exactly same four profiles.py errors; checked 46 root source files. Baselines B4/B5 and supplemental fresh-core run.',
11: 'Development board validation passed: 23 tasks.',
12: 'Planning dashboard is current.',
13: 'Documentation lifecycle validation passed: 342 Markdown files.',
14: 'Clean original aggregate whitespace diff.',
15: 'Working packages/tests/configuration equal frozen candidate; no diff.',
16: 'Clean bounded remediation whitespace diff.',
17: 'Both working implementation reports equal frozen candidate; no diff.',
}
add('| # | Exact command | Exit | Wall seconds | Result | Full log |\n| --- | --- | ---: | ---: | --- | --- |')
for item in checks:
    name = Path(item['log']).name
    add(f"| {item['id']} | `{item['command']}` | {item['exit']} | {item['seconds']:.3f} | {outcomes[item['id']]} | [{name}]({name}) |")
add()
add('## Independently established predecessor baselines\n')
add('Accepted predecessor `a257f041d1d68f8aea2f5b9773df1b88acd82379` was extracted read-only with `git archive a257f041d1d68f8aea2f5b9773df1b88acd82379 packages tests scripts docs pyproject.toml uv.lock AGENTS.md` into `/private/tmp/val009-20260928/predecessor`; no branch/worktree change. Runs use the existing `.venv/bin/python` at its original path (not its resolved interpreter symlink), same installed dependencies, local cost map, requested UV cache, offline flag and bytecode-disabled flag. For the two pytest runs only, `PYTHONPATH` is the exact sorted archived source path list below so editable imports load predecessor packages; warning source paths confirm archived imports. Mypy runs use the standard import environment with neither an added `PYTHONPATH` nor `MYPYPATH`, and explicit fresh scratch caches. This avoids a baseline changed by an artificial type-discovery environment. [baseline-results.json](baseline-results.json) records exact argv, cwd, test import paths, exits, times and logs.\n')
add('Exact baseline process environment additions: `LITELLM_LOCAL_MODEL_COST_MAP=true UV_CACHE_DIR=/private/tmp/friday-uv-cache UV_OFFLINE=true PYTHONDONTWRITEBYTECODE=1`. Cwd for every B command: `/private/tmp/val009-20260928/predecessor`. B1/B2 additionally use:\n')
add('```text\nPYTHONPATH=' + baselines[0]['source_import_paths'] + '\n```\n')
bresults = {
1: '233 passed, 2 failed, 1 warning in 12.27s; exactly TestDocxReader::test_docx_reader_missing_dependency and TestXlsxReader::test_xlsx_reader_missing_dependency. Same assertions at test_filesystem_readers.py:286/306: “Failed to read DOCX: File is not a zip file” / “Failed to read Excel file: File is not a zip file”.',
2: '10 passed, 1 failed in 1.77s; same test_development_board.py:75 expects “22 tasks” and receives successful canonical “23 tasks”.',
3: 'Same NumPy __init__.pyi:737 Type statement only supported in Python 3.12+ syntax error under default target; further checking prevented.',
4: 'Same four no-any-return errors at profiles.py:77/82 (VectorStoreAdapter), 110/115 (GraphStoreAdapter); checked 32 source files.',
5: 'Same four profiles.py errors with exact core MCP root; checked 1 root source file.',
}
add('| Baseline | Exact argv rendered as command | Exit | Wall seconds | Result | Full log |\n| --- | --- | ---: | ---: | --- | --- |')
for item in baselines:
    name = Path(item['log']).name
    command = shlex.join(item['command'])
    add(f"| B{item['id']} | `{command}` | {item['exit']} | {item['seconds']:.3f} | {bresults[item['id']]} | [{name}]({name}) |")
add()
add('Baseline classifications are established by these new predecessor runs, not by builder/remediator or historical reviewer reports. An additional exact diff verifies native tool source/tests, profiles.py, the board test, pyproject.toml and uv.lock are unchanged from accepted predecessor. Current fresh-cache full-core typing returns the same four errors; no new touched-source error is observed. The default-target typing command supplies no project type assurance because dependency syntax prevents checking. The passing 45-file run and source/annotation review supply narrower meaningful type evidence. Full required commands still fail with their exact original codes.\n')

additional = json.loads((OUT / 'supplemental-checks.json').read_text())
additional += [
 {'name':'candidate-core-fresh', 'command':'LITELLM_LOCAL_MODEL_COST_MAP=true UV_CACHE_DIR=/private/tmp/friday-uv-cache UV_OFFLINE=true uv run mypy --python-version 3.13 packages/friday-core --cache-dir /private/tmp/val009-20260928/candidate-core-fresh', 'exit':1, 'result':'Same four profiles.py errors; checked 32 files; fresh cache, standard unfiltered import environment.', 'log':'candidate-core-fresh.log'},
 {'name':'independent-probes', 'command':'LITELLM_LOCAL_MODEL_COST_MAP=true UV_CACHE_DIR=/private/tmp/friday-uv-cache UV_OFFLINE=true PYTHONDONTWRITEBYTECODE=1 uv run python /private/tmp/val009-20260928/probes.py > /private/tmp/val009-20260928/probes.log 2>&1', 'exit':0, 'result':'21 independent groups PASS.', 'log':'probes.log'},
 {'name':'supplemental-probes', 'command':'LITELLM_LOCAL_MODEL_COST_MAP=true UV_CACHE_DIR=/private/tmp/friday-uv-cache UV_OFFLINE=true PYTHONDONTWRITEBYTECODE=1 uv run python /private/tmp/val009-20260928/supplement.py > /private/tmp/val009-20260928/supplement.log 2>&1', 'exit':0, 'result':'5 supplemental groups PASS, including deliberate assertion-failure defensive settlement.', 'log':'supplement.log'},
 {'name':'closeout-freeze', 'command':'PYTHONDONTWRITEBYTECODE=1 python3 /private/tmp/val009-20260928/freeze.py', 'exit':0, 'result':'All start/closeout inputs identical; all pinned hash checks and candidate product/report comparisons pass.', 'log':'closeout.json'},
]
additional[0].update(result='Full delta whitespace clean.', log='delta-whitespace.log')
additional[1].update(result='No changes in declared baseline source/configuration inputs.', log='unchanged-baseline-inputs.log')
(OUT / 'additional-command-results.json').write_text(json.dumps(additional, indent=2) + '\n')
add('## Supplemental command evidence\n')
add('| Check | Exact command | Exit | Result | Evidence |\n| --- | --- | ---: | --- | --- |')
for item in additional:
    add(f"| {item['name']} | `{item['command']}` | {item['exit']} | {item['result']} | [{item['log']}]({item['log']}) |")
add()
add('## All independent probe groups\n')
add('Every group below completed PASS with no unexpected harness exception. Full logs preserve observations; [all-probe-results.json](all-probe-results.json) preserves nested descriptors, counts and other structured evidence. The two main commands and their exit codes are above.\n')
add('| # | Executable group | Result | Recorded independent evidence | Log |\n| --- | --- | --- | --- | --- |')
for n, item in enumerate(probes, 1):
    evidence = dict(item['evidence'])
    if 'descriptors' in evidence:
        evidence['descriptors'] = 'All six exact nested public descriptors in all-probe-results.json; both F-001 variants described above.'
    rendered = json.dumps(evidence, ensure_ascii=True, separators=(',', ':')).replace('|', '&#124;')
    name = Path(item['log']).name
    add(f"| {n} | `{item['name']}` | {item['outcome']} | `{rendered}` | [{name}]({name}) |")
add()
add('## Frozen-input start/closeout evidence\n')
add(f"Formal start: `{start['utc']}`. Final snapshot: `{close['utc']}`. Both snapshots independently hash all 22 authorities and both implementation reports against the request and candidate blobs, all 968 tracked packages/tests/pyproject/uv.lock files, and all files under the five unrelated path manifests (60 existing files; deleted family-tree remains absent). [start.json](start.json) and [closeout.json](closeout.json) preserve every path/hash and exact porcelain. [freeze.py](freeze.py) is the executable closeout snapshot implementation.\n")
add('| Freeze item | Start | Closeout | Result |\n| --- | --- | --- | --- |')
for key in ['head', 'branch', 'candidate', 'request_sha256']:
    add(f"| {key} | `{start[key]}` | `{close[key]}` | Identical |")
add('| Request frozen commit blob | `34a457a540ca5e092c332431c824a537dcf7a8b0` | Same SHA256 as working request | MATCH |')
add('| Pinned authority/report manifest | 24 exact expected/working/candidate matches | Same 24 exact matches | MATCH |')
add('| Product source/tests/configuration | 968 tracked file hashes | Same paths and hashes; candidate diff exit 0 | IDENTICAL |')
add('| Both implementation reports | Frozen expected hashes | Same hashes; candidate diff exit 0 | IDENTICAL |')
add('| Unrelated paths | Five path manifests, 60 existing file hashes and preserved deletion | Same paths/hashes/deletion | IDENTICAL |')
add('| Git status | Five unrelated dirty entries only | Exact same porcelain | IDENTICAL |')
add()
add('All 22 authority rows below were read completely; their SHA256 values match the request, candidate committed content, working content at formal start and working content at closeout. The two report rows also match all four sources. Original 20 authorities also match previous candidate contents; approved WS-03 and REM-005 directive blobs match their authorization commits.\n')
add('| Input | SHA256 | Start/candidate/closeout vs request |\n| --- | --- | --- |')
for path, value in start['manifest'].items():
    add(f"| `{path}` | `{value['expected']}` | MATCH / MATCH / MATCH |")
add()
add('Unrelated preservation manifest:\n\n```text\n' + close['status'].rstrip() + '\n```\n')
add('`family-tree.md` remains deleted exactly as found; `.DS_Store` modification and all three untracked path roots remain byte-for-byte unchanged. No broad stage or cleanup occurred. [diff-and-integrity.json](diff-and-integrity.json) records complete diff path sets, diff hashes, authorization hash equality, original-authority equality and all 33 immutable historical evidence hash results.\n')
add('## Documentation/configuration and remaining gates' + residual)
add('## Evidence delivery\n')
add('Repository artifact links identify original members of the controller archive `VAL-009-evidence.tar.gz`. Restoring the archive’s sibling layout exposes the exact named artifacts. This navigation adjustment makes no claim of independent verification of controller packaging.\n')
add('Complete report: `/private/tmp/val009-20260928/report.md`. Machine-readable evidence/artifact SHA256 manifest: `/private/tmp/val009-20260928/evidence.json`. Exact command/result manifests, all logs, executable probes/fake peer, complete diffs and start/closeout snapshots are retained beside this report. No repository write is needed to consume this review. The controller may archive these bytes without changing the reviewed implementation inputs.\n')
report = '\n'.join(parts)
report = re.sub(r'(?m)(^\|[^\n]*\|)\n(?:[ \t]*\n)+(?=\|)', r'\1\n', report)
report = re.sub(
    r'\[([^\]]+)\]\(([^)]+)\)',
    lambda match: match.group(0) if match.group(2).startswith(('/', '#', 'http:', 'https:'))
    else f'[{match.group(1)}](VAL-009-evidence.tar.gz#{match.group(2)})',
    report,
)
assert report.count('Overall outcome:') == 1
assert len(checks) == 17 and len(probes) == 26
assert close['all_stable']
(OUT / 'report.md').write_text(report)

# Include each delivered top-level file plus bounded synthetic run inputs/outputs.
# Exclude dependency caches and the archived predecessor tree; reproduce that tree
# with its exact commit/archive instruction and use recorded baseline import paths.
artifacts = sorted(p for p in OUT.iterdir() if p.is_file() and p.name != 'evidence.json')
artifacts += sorted(p for folder in OUT.glob('run-*') if folder.is_dir() for p in folder.rglob('*') if p.is_file())
evidence = {
 'id':'VAL-009', 'reviewer':'/root/mcp_ws03_val009', 'read_only':True,
 'review_modes':{'delta':'VERIFIED', 'work_unit_aggregate':'VERIFIED'},
 'overall_outcome':'VERIFIED', 'findings':[], 'candidate':start['candidate'],
 'request_commit':'34a457a540ca5e092c332431c824a537dcf7a8b0',
 'request_sha256':start['request_sha256'], 'head':start['head'],
 'start_utc':start['utc'], 'closeout_utc':close['utc'],
 'all_frozen_inputs_stable':close['all_stable'],
 'required_checks':checks, 'baseline_runs':baselines,
 'additional_commands':additional, 'probes':probes,
 'authorities_and_reports':start['manifest'],
 'artifact_note':'evidence.json excludes its own hash; predecessor extraction and type caches are reproducible scratch inputs, not delivered evidence. probe-results.json is supplemental-only; all-probe-results.json and both logs are complete.',
 'artifacts':{str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in artifacts},
}
(OUT / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
print(json.dumps({'report_bytes':len(report.encode()),'report_sha256':hashlib.sha256(report.encode()).hexdigest(),'artifacts':len(artifacts),'evidence_sha256':hashlib.sha256((OUT/'evidence.json').read_bytes()).hexdigest()},indent=2))
