import pathlib,subprocess,json,hashlib
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');d=json.loads((root/'docs/planning/active/friday-mcp/validation/REM-008-maintainer-frozen-inputs.json').read_text());bad=[];checked=0
for group in ('authority','candidate_reports','historical_evidence','builder_evidence'):
 for item in d[group]:
  rev=item.get('revision')
  if not rev or len(rev)!=40:continue
  try:data=subprocess.check_output(['git','show',f'{rev}:{item["path"]}'],cwd=root,stderr=subprocess.DEVNULL)
  except subprocess.CalledProcessError:bad.append({'group':group,'path':item['path'],'issue':'missing pinned blob'});continue
  checked+=1
  if hashlib.sha256(data).hexdigest()!=item['sha256']:bad.append({'group':group,'path':item['path'],'issue':'pinned Git mismatch'})
  if (root/item['path']).read_bytes()!=data:bad.append({'group':group,'path':item['path'],'issue':'worktree differs pinned Git'})
for path,sha in d['tracked_product_bytes'].items():
 try:data=subprocess.check_output(['git','show',f'{d["candidate_commit"]}:{path}'],cwd=root,stderr=subprocess.DEVNULL)
 except subprocess.CalledProcessError:bad.append({'group':'product','path':path,'issue':'missing candidate blob'});continue
 checked+=1
 if hashlib.sha256(data).hexdigest()!=sha:bad.append({'group':'product','path':path,'issue':'candidate Git mismatch'})
 if (root/path).read_bytes()!=data:bad.append({'group':'product','path':path,'issue':'worktree differs candidate Git'})
rem=subprocess.check_output(['git','diff','--name-only',d['remediation_base']+'..'+d['candidate_commit'],'--','packages','tests','pyproject.toml','uv.lock'],cwd=root,text=True).splitlines();expected=set(d['allowed_remediation_paths'])-{'docs/planning/active/friday-mcp/execution/REM-008-implementation-report.md'};report=expected==set(rem);result={'pinned_git_and_worktree_comparisons':checked,'mismatches':bad,'remediation_product_paths':rem,'exact_eight_products':report,'new_report_in_diff':'docs/planning/active/friday-mcp/execution/REM-008-implementation-report.md' in subprocess.check_output(['git','diff','--name-only',d['remediation_base']+'..'+d['candidate_commit']],cwd=root,text=True).splitlines()};pathlib.Path('/private/tmp/val015-independent/revision-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checked':checked,'mismatches':len(bad),'scope':report,'report':result['new_report_in_diff']},indent=2))
