import asyncio,sys,json,pathlib
from friday_chat.adapters import FrameworkMemoryAdapter,FrameworkTranscriptAdapter
from friday_chat.config import FridayChatConfig
from friday_chat.memory_mcp import persist_mcp_interaction
from friday_chat.tools.output import MCPOutputPolicy
from friday_chat.turns.models import InteractionTurn,TurnMetrics
from friday_core.mcp import MCPIngestionPolicy,MCPToolMetadata
from friday_memory import CollectionManager,MemoryController,InMemoryEpisodicStore,NullGraphStore
from friday_transcript import SQLiteTranscriptStore
class Embeddings:
 async def embed_documents(self,texts):return [[1.,0.,0.,0.] for _ in texts]
 async def embed_query(self,text):return [1.,0.,0.,0.]
async def main():
 root=pathlib.Path(sys.argv[1]);root.mkdir(exist_ok=True);cfg=FridayChatConfig();manager=CollectionManager(Embeddings(),path=str(root/'vectors'));episodic=InMemoryEpisodicStore();graph=NullGraphStore();controller=MemoryController(manager.short_term,graph,episodic,manager);memory=FrameworkMemoryAdapter(controller,manager,cfg,'retry-repro',episodic,graph);store=SQLiteTranscriptStore(root/'transcript.sqlite');transcript=FrameworkTranscriptAdapter(store,cfg,'retry-repro');policy=MCPIngestionPolicy(long_term_memory_enabled=True,opted_in_servers=('peer',));meta=MCPToolMetadata(canonical_name='mcp_peer_read',server_name='peer',original_name='read',transport='stdio',trust_level='local');call=MCPOutputPolicy(256).checked_record(meta,'owned-call','benign',{});turn=InteractionTurn('owned-entry','user','answer','','',(),TurnMetrics(0,0,0,0),tool_calls=(call,));first=await persist_mcp_interaction(memory,transcript,policy,turn);original=first[0].mcp_provenance.memory_correlation_id;error=None
 try:await persist_mcp_interaction(memory,transcript,policy,turn)
 except RuntimeError as exc:error=str(exc)
 rows=await manager.get_all();observation={'original_memory_id':original,'retry_error':error,'records':[{'id':r['id'],'state':r['metadata']['mcp_state']} for r in rows],'entry_count':len(await store.get_entries('retry-repro')),'retrievable_count':len((await manager.query('benign'))['short_term']),'pending_tasks':[t.get_name() for t in asyncio.all_tasks() if t is not asyncio.current_task() and not t.done()]};(root/'observation.json').write_text(json.dumps(observation,indent=2)+'\n');print(json.dumps(observation,indent=2),flush=True)
 if len(rows)!=1 or rows[0]['id']!=original or error is not None:raise SystemExit(1)
asyncio.run(main())
