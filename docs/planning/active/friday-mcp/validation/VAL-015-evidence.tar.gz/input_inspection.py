import pathlib,json,tarfile,hashlib
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework');d=json.loads((root/'docs/planning/active/friday-mcp/validation/REM-008-maintainer-frozen-inputs.json').read_text());rows={}
for group in ('authority','candidate_reports','historical_evidence','builder_evidence'):
 rows[group]=[]
 for item in d[group]:
  path=root/item['path'];raw=path.read_bytes();row={'path':item['path'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  if path.name.endswith('.tar.gz'):
   with tarfile.open(path,'r:gz') as t:row['archive_members']=len(t.getmembers());row['member_head']=[m.name for m in t.getmembers()[:10]]
  elif path.suffix=='.json':
   try:
    parsed=json.loads(raw);row['top_level_keys']=list(parsed)[:30] if isinstance(parsed,dict) else []
   except json.JSONDecodeError:row['json_error']=True
  else:
   content=raw.decode('utf8');row['headings']=[x.strip() for x in content.splitlines() if x.startswith('#')][:25];row['line_count']=len(content.splitlines())
  rows[group].append(row)
pathlib.Path('/private/tmp/val015-independent/input-inspection.json').write_text(json.dumps(rows,indent=2)+'\n');print({k:len(v) for k,v in rows.items()})
