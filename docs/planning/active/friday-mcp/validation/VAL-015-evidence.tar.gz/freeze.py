import hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path('/Users/chuckrussell/Dev/gendev/agent-framework')
d=json.loads((root/'docs/planning/active/friday-mcp/validation/REM-008-maintainer-frozen-inputs.json').read_text())
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
res={'phase':sys.argv[1], 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(), 'candidate':d['candidate_commit'], 'groups':{},'tracked_product_mismatches':[], 'unrelated':{}, 'diff_scope':{}}
for g in ('authority','candidate_reports','historical_evidence','builder_evidence'):
 bad=[]
 for x in d[g]:
  p=root/x['path']
  if not p.is_file() or h(p)!=x['sha256']:bad.append(x['path'])
 res['groups'][g]={'count':len(d[g]),'mismatches':bad}
for path,expected in d['tracked_product_bytes'].items():
 p=root/path
 if not p.is_file() or h(p)!=expected:res['tracked_product_mismatches'].append(path)
for path,x in d['unrelated'].items():
 p=root/path
 if x['state']=='absent': res['unrelated'][path]={'state':'absent' if not p.exists() else 'present','match':not p.exists()}
 else:
  fs=[p] if p.is_file() else sorted(q for q in p.rglob('*') if q.is_file())
  manifest=b''.join(str(q.relative_to(root)).encode()+b'\0'+(q.read_bytes() if q.is_file() else b'symlink:'+os.readlink(q).encode())+b'\0' for q in fs)
  digest=hashlib.sha256(manifest).hexdigest()
  res['unrelated'][path]={'files':len(fs),'sha256_manifest':digest,'expected_sha256':x['sha256'],'match':len(fs)==x['files'] and digest==x['sha256']}
for name,base in [('remediation',d['remediation_base']),('aggregate',d['original_work_unit_base'])]:
 out=subprocess.check_output(['git','diff','--name-only',base+'..'+d['candidate_commit']],cwd=root,text=True).splitlines()
 res['diff_scope'][name]=out
res['request_hash_match']=h(root/'docs/planning/active/friday-mcp/validation/REM-008-maintainer-frozen-inputs.json')=='763e2f3d5007f5edf0d35714aaec6d66901009a2255b9b7f4d76768c690da43d'
path=pathlib.Path('/private/tmp/val015-independent')/f'freeze-{sys.argv[1]}.json';path.write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({k:v for k,v in res.items() if k not in ('tracked_product_mismatches','diff_scope')},indent=2));print('tracked_mismatches',len(res['tracked_product_mismatches']));print('diff_scope',res['diff_scope'])
