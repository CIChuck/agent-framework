"""Independent public Chroma/SQLite retry and failure probes for VAL-015."""
import asyncio,json,pathlib,sys
from dataclasses import replace
from friday_chat.adapters import FrameworkMemoryAdapter,FrameworkTranscriptAdapter
from friday_chat.config import FridayChatConfig
from friday_chat.memory_mcp import persist_mcp_interaction
from friday_chat.tools.output import MCPOutputPolicy
from friday_chat.tools.schemas import ToolCallRecord
from friday_chat.turns.models import InteractionTurn,TurnMetrics
from friday_core.mcp import MCPIngestionPolicy,MCPToolMetadata
from friday_memory import CollectionManager,MemoryController,InMemoryEpisodicStore,NullGraphStore
from friday_memory.ingestion.mcp import MCPMemoryIngester
from friday_transcript import SQLiteTranscriptStore
ROOT=pathlib.Path(sys.argv[1]); ROOT.mkdir(exist_ok=True,parents=True);ROWS=[]
class Embeddings:
 def __init__(self):self.writes=0
 async def embed_documents(self,texts):self.writes+=len(texts);return [[1.,0.,0.,0.] for _ in texts]
 async def embed_query(self,text):return [1.,0.,0.,0.]
def setup(name,enabled=True):
 p=ROOT/name;p.mkdir(exist_ok=True);emb=Embeddings();cfg=FridayChatConfig();m=CollectionManager(emb,path=str(p/'vectors'));epi=InMemoryEpisodicStore();graph=NullGraphStore();controller=MemoryController(m.short_term,graph,epi,m);mem=FrameworkMemoryAdapter(controller,m,cfg,name,epi,graph);store=SQLiteTranscriptStore(p/'transcript.sqlite');trans=FrameworkTranscriptAdapter(store,cfg,name);policy=MCPIngestionPolicy(long_term_memory_enabled=enabled,opted_in_servers=('peer',));return mem,trans,m,store,policy,emb
META=MCPToolMetadata(canonical_name='mcp_peer_read',server_name='peer',original_name='read',transport='stdio',trust_level='local')
def call(cid='call',value='benign'):return MCPOutputPolicy(256).checked_record(META,cid,value,{})
def turn(entry='entry',calls=None):return InteractionTurn(entry,'user','answer','','',(),TurnMetrics(0,0,0,0),tool_calls=calls or (call(),))
def assert_(b,msg):
 if not b:raise AssertionError(msg)
async def run(name,fn):
 try:detail=await fn();row={'name':name,'status':'PASS','detail':detail}
 except BaseException as e:row={'name':name,'status':'FAIL','error':type(e).__name__+': '+str(e)}
 ROWS.append(row);(ROOT/'retry-probes.json').write_text(json.dumps(ROWS,indent=2)+'\n');print(row,flush=True)
async def success_mixed():
 mem,trans,m,store,p,emb=setup('mixed');t=turn(calls=(call('one'),ToolCallRecord('native',{'k':'safe'},'native-result','native'),call('two')))
 a=await persist_mcp_interaction(mem,trans,p,t);e=(await store.get_entry('entry')).model_dump();b=await persist_mcp_interaction(mem,trans,p,t)
 assert_(a==b,'identical returned facts');assert_(emb.writes==2 and await m.short_term.count()==2,'no extra record or embedding');assert_(await store.count_entries('mixed')==1 and (await store.get_entry('entry')).model_dump()==e,'immutable entry');assert_(a[1]==t.tool_calls[1],'native unchanged')
 return {'ids':[a[0].mcp_provenance.memory_correlation_id,a[2].mcp_provenance.memory_correlation_id],'writes':emb.writes}
async def partial(kind):
 mem,trans,m,store,p,emb=setup(kind);t=turn();original_record=trans.record_mcp_interaction;original_append=store.append_entry;original_read=store.get_entry;original_publish=mem.publish_mcp_memory
 if kind=='false_append':
  async def fault(entry):return False
  store.append_entry=fault
 elif kind=='ambiguous':
  async def fault(value):await original_record(value);raise RuntimeError('RAW_PRIVATE_FAILURE')
  trans.record_mcp_interaction=fault
 elif kind=='readback':
  appended=False
  async def append(entry):
   nonlocal appended
   result=await original_append(entry);appended=True;return result
  async def read(entry_id):
   if appended:raise RuntimeError('RAW_PRIVATE_FAILURE')
   return await original_read(entry_id)
  store.append_entry=append;store.get_entry=read
 elif kind=='publication':
  async def fault(snapshot):return False
  mem.publish_mcp_memory=fault
 elif kind=='cancel_after_append':
  async def fault(value):await original_record(value);raise asyncio.CancelledError()
  trans.record_mcp_interaction=fault
 error=None
 try:await persist_mcp_interaction(mem,trans,p,t)
 except BaseException as ex:error=type(ex).__name__+': '+str(ex)
 rows=await m.get_all();assert_(len(rows)==1 and rows[0]['metadata']['mcp_state']=='pending' or kind=='ambiguous' and len(rows)==1 and rows[0]['metadata']['mcp_state']=='committed','safe initial record state');owned=rows[0]['id'];before=emb.writes
 if kind in ('false_append','readback','cancel_after_append'):
  assert_(error is not None,'expected propagated failure')
 if kind=='ambiguous':assert_(error is None,'post-commit ambiguity reconciled')
 store.append_entry=original_append;store.get_entry=original_read;trans.record_mcp_interaction=original_record;mem.publish_mcp_memory=original_publish
 retry=await persist_mcp_interaction(mem,trans,p,t);assert_(retry[0].mcp_provenance.memory_correlation_id==owned,'owned id reused');assert_(emb.writes==before==1 and await m.short_term.count()==1,'no new embedding or record');assert_(await store.count_entries(kind)==1,'one entry');assert_((await m.get_mcp_snapshot(owned)).state=='committed','published after valid receipt')
 return {'initial_error':error,'record_id':owned,'embeddings':emb.writes}
async def conflicts():
 mem,trans,m,store,p,emb=setup('conflict');t=turn();a=await persist_mcp_interaction(mem,trans,p,t);prior=(await store.get_entry('entry')).model_dump();failures=[]
 for label,newturn,newpolicy in [('payload',turn(calls=(call(value='changed'),)),p),('policy',t,p.model_copy(update={'max_ingested_bytes':32768})),('native',turn(calls=(ToolCallRecord('native',{},'native-result','native'),)),p),('facts',turn(calls=(replace(call(),mcp_provenance=call().mcp_provenance.model_copy(update={'result_truncated':True})),)),p)]:
  try:await persist_mcp_interaction(mem,trans,newpolicy,newturn)
  except RuntimeError as ex:failures.append((label,str(ex)));assert_('RAW_' not in str(ex),'fixed safe error')
 assert_(len(failures)==4,'all conflicts rejected');assert_(emb.writes==1 and await m.short_term.count()==1,'no new writes');assert_((await store.get_entry('entry')).model_dump()==prior,'immutable receipt');return {'rejected':failures,'record':a[0].mcp_provenance.memory_correlation_id}
async def concurrent():
 mem,trans,m,store,p,emb=setup('concurrent');t=turn();a,b=await asyncio.gather(persist_mcp_interaction(mem,trans,p,t),persist_mcp_interaction(mem,trans,p,t));assert_(a==b and emb.writes==1 and await m.short_term.count()==1 and await store.count_entries('concurrent')==1,'concurrent matching stable');return {'record':a[0].mcp_provenance.memory_correlation_id,'writes':emb.writes}
async def pending_competitor():
 mem,trans,m,store,p,emb=setup('pending-competitor');t=turn();prep=await mem.prepare_mcp_memory(t.tool_calls[0],t.turn_id,p);assert_(prep.snapshot is not None,'pending owner');before=prep.snapshot.record_id
 try:await persist_mcp_interaction(mem,trans,p,turn(calls=(call(value='different'),)))
 except RuntimeError:pass
 else:raise AssertionError('conflict accepted')
 assert_((await m.get_mcp_snapshot(before)).state=='pending' and await store.count_entries('pending-competitor')==0,'owner retained');done=await persist_mcp_interaction(mem,trans,p,t);assert_(done[0].mcp_provenance.memory_correlation_id==before and emb.writes==1,'owner reused');return {'record':before}
async def disabled():
 mem,trans,m,store,p,emb=setup('disabled',False);t=turn();a=await persist_mcp_interaction(mem,trans,p,t);assert_(not a[0].mcp_provenance.memory_ingested and emb.writes==0 and await m.short_term.count()==0,'zero writes');assert_(await store.count_entries('disabled')==1,'safe transcript');return {'writes':0}
async def native_id_collision():
 mem,trans,m,store,p,emb=setup('native-id-collision');await m.add_to_short_term(['native fact'],[{'type':'insight'}],['native-owned-id']);t=turn();result=await MCPMemoryIngester(m).prepare(t.tool_calls[0].mcp_provenance,t.tool_calls[0].result,t.turn_id,p,record_id='native-owned-id');assert_(result.snapshot is None and result.decision=='storage_failed','explicit native ID refused');native=await m.short_term.get_by_id('native-owned-id');assert_(native['text']=='native fact' and native['metadata']['type']=='insight','native record intact');assert_(await store.count_entries('native-id-collision')==0,'no forged receipt');return {'decision':result.decision,'native_text':native['text']}
async def main():
 await run('success-mixed-repeat',success_mixed)
 for k in ['false_append','ambiguous','readback','publication','cancel_after_append']:await run(k,lambda k=k:partial(k))
 await run('conflicts',conflicts);await run('concurrent-matching',concurrent);await run('pending-competing-owner',pending_competitor);await run('disabled-default',disabled);await run('native-id-collision',native_id_collision)
 pending=[x.get_name() for x in asyncio.all_tasks() if x is not asyncio.current_task() and not x.done()];(ROOT/'cleanup.json').write_text(json.dumps({'pending_tasks':pending},indent=2)+'\n');assert_(not pending,'pending tasks');assert_(all(r['status']=='PASS' for r in ROWS),'probe failure');print('TOTAL',len(ROWS),'PASS',flush=True)
asyncio.run(main())
