import concurrent.futures,json,os,subprocess,time
from pathlib import Path
out=Path('/private/tmp/ws04-baseline');out.mkdir(exist_ok=True)
checks={
'chat': 'uv run pytest packages/friday-chat/tests_chat -q',
'memory': 'uv run pytest packages/friday-memory/tests_memory -q',
'ruff': 'uv run ruff check packages/friday-chat packages/friday-runtime packages/friday-memory',
'mypy': 'uv run mypy packages/friday-chat packages/friday-runtime packages/friday-memory',
'focused-typing':'uv run mypy --python-version 3.13 packages/friday-chat/src/friday_chat/config.py packages/friday-chat/src/friday_chat/tools/selection.py packages/friday-chat/src/friday_chat/turns/processor.py packages/friday-chat/src/friday_chat/runtime.py packages/friday-chat/src/friday_chat/app.py packages/friday-chat/src/friday_chat/commands/tools.py',
}
env=dict(os.environ,LITELLM_LOCAL_MODEL_COST_MAP='true',UV_CACHE_DIR='/private/tmp/friday-uv-cache',UV_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
def run(item):
 name,cmd=item;t=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd.split(),stdout=f,stderr=subprocess.STDOUT,env=env)
 result={'name':name,'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-t,3),'log':str(out/(name+'.log'))}
 (out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(run,checks.items()))
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
