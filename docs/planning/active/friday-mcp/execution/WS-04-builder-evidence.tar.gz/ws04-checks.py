import concurrent.futures, json, os, subprocess, time
from pathlib import Path

out = Path('/private/tmp/ws04-checks')
out.mkdir(exist_ok=True)
checks = {
    'chat': 'uv run pytest packages/friday-chat/tests_chat -q --tb=short',
    'runtime': 'uv run pytest packages/friday-runtime/tests_runtime -q',
    'memory': 'uv run pytest packages/friday-memory/tests_memory -q',
    'accepted-mcp': 'uv run pytest packages/friday-core/tests_core packages/friday-mcp/tests_mcp packages/friday-runtime/tests_runtime tests/integration/test_mcp_registry.py tests/integration/test_mcp_runtime_lifecycle.py -q',
    'integration': 'uv run pytest tests/integration -q --tb=short',
    'ruff': 'uv run ruff check packages/friday-chat packages/friday-runtime packages/friday-memory',
    'mypy': 'uv run mypy packages/friday-chat packages/friday-runtime packages/friday-memory',
    'focused-typing': 'uv run mypy --python-version 3.13 packages/friday-chat/src/friday_chat/config.py packages/friday-chat/src/friday_chat/tools/selection.py packages/friday-chat/src/friday_chat/tools/mcp.py packages/friday-chat/src/friday_chat/turns/processor.py packages/friday-chat/src/friday_chat/runtime.py packages/friday-chat/src/friday_chat/app.py packages/friday-chat/src/friday_chat/commands/tools.py',
    'board': 'uv run python scripts/friday-dev-board.py validate',
    'dashboard': 'uv run python scripts/friday-dev-board.py render --check',
    'docs': 'uv run python scripts/check-documentation-lifecycle.py',
}
env = dict(os.environ, LITELLM_LOCAL_MODEL_COST_MAP='true', UV_CACHE_DIR='/private/tmp/friday-uv-cache', UV_OFFLINE='true', PYTHONDONTWRITEBYTECODE='1')

def run(item):
    name, command = item
    started = time.monotonic()
    with (out / (name + '.log')).open('w') as log:
        result = subprocess.run(command.split(), stdout=log, stderr=subprocess.STDOUT, env=env)
    record = {'name': name, 'command': command, 'exit': result.returncode, 'seconds': round(time.monotonic() - started, 3), 'log': str(out / (name + '.log'))}
    (out / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    return record

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(run, checks.items()))
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
