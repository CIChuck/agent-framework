import hashlib, json, subprocess
from pathlib import Path

root = Path.cwd()
old = json.loads(Path('/private/tmp/val009-20260928/closeout.json').read_text())
allowed = set('''packages/friday-chat/src/friday_chat/app.py
packages/friday-chat/src/friday_chat/config.py
packages/friday-chat/src/friday_chat/commands/tools.py
packages/friday-chat/src/friday_chat/runtime.py
packages/friday-chat/src/friday_chat/tools/selection.py
packages/friday-chat/src/friday_chat/turns/processor.py
packages/friday-chat/tests_chat/test_mcp_config_compatibility.py'''.splitlines())
for name, record in old['manifest'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == record['expected'], name
for name, digest in old['source'].items():
    if name not in allowed:
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
expected = {'.DS_Store': {'files': 1, 'sha256': '726abde51b913404c3c5af3bf5ec36210f129b89ca33a0efc24dd4cd73fe98a9', 'state': 'present'}, 'docker-bench-security/': {'files': 57, 'sha256': 'd7215d8bafcc427e5dde801fd1f80f88438fa5bc4215ff3262f86bfcea870f85', 'state': 'present'}, 'family-tree.md': {'state': 'absent'}, 'packages/friday-chat/config.example.yaml.pre-typed-llm-20260828.bak': {'files': 1, 'sha256': 'b9164e100cf67ff37ff860ed82c5987981ed740e2fec88f8bcc25e815a9c7cea', 'state': 'present'}, 'packages/friday-sandbox/docker/Dockerfile.audit': {'files': 1, 'sha256': '8904c2cd686fb4acb2612f00b875f8bb03e4a284c3f2b4e4cb440ab7e2739884', 'state': 'present'}}
actual = {}
for name in expected:
    path = root / name
    if not path.exists() and not path.is_symlink():
        actual[name] = {'state': 'absent'}
        continue
    paths = sorted(path.rglob('*')) if path.is_dir() else [path]
    h = hashlib.sha256()
    count = 0
    for f in paths:
        if f.is_symlink():
            data = ('symlink:' + str(f.readlink())).encode()
        elif f.is_file():
            data = f.read_bytes()
        else:
            continue
        h.update(str(f.relative_to(root)).encode() + b'\0' + data + b'\0')
        count += 1
    actual[name] = {'files': count, 'sha256': h.hexdigest(), 'state': 'present'}
assert actual == expected, actual
result = {'prior_pinned_inputs_unchanged': len(old['manifest']), 'prior_product_files_unchanged_outside_scope': len(old['source']) - len(allowed), 'unrelated': actual, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()}
Path('/private/tmp/ws04-checks/preservation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'unrelated'}))
